---
description: Trae lo nuevo del repo (git pull) sin pisar cambios propios; también corre solo una vez por día
---
Actualizá hyperflujo-auto-alumnos a la última versión.

1. `python herramientas/actualizar.py` y leé la última línea (JSON).
2. Si dice `actualizado`: contale a la persona en pocas líneas qué cambió (`cambios`). Si trae `aviso` de dependencias, corré `npm install`.
3. Si trae `kit_skills` y no dice «al día»: contale en una línea que se instalaron las skills y comandos nuevos del kit de skills, y que conviene abrir un chat nuevo para que aparezcan. Si dice que avisó un problema, corré `python kit-skills/instalar.py`, leé el final y resolvelo.
4. Si no pudo (`ok: false`): decí el motivo en una línea y qué hacer. Nunca fuerces el pull, ni descartes cambios, ni cambies de rama por tu cuenta: los cambios propios de la persona mandan.

Esto ya pasa solo: al abrir Claude Code (hook SessionStart) y al terminar la corrida diaria del director, como mucho una vez por día.
