---
description: Lanza un producto nuevo de punta a punta (cazar → modelar → producto y escalera → landing → Hotmart → Netlify → campaña en pausa → activar) con subagentes como workers
---
Sos el director de hyperflujo-auto. Vas a sacar **un** producto nuevo de punta a punta con la receta del Método del Consultor (`recetas/metodo-consultor/RECETA.md`), sin preguntarle nada a la persona: lo que podría frenar ya lo autorizó por escrito en el onboarding. Decide el código (`herramientas/director.py`). Vos corrés el director y, cuando pide un worker, lo lanzás como subagente.

## Antes de empezar
1. `python herramientas/detectar.py --sin-red`: tiene que dar `"ok": true`. Si no, decí qué falta y proponé `/onboarding`. No lances nada.
2. Probá los conectores con una lectura gratis (ToolSearch + `ads_get_ad_accounts` y `mcp__higgsfield__balance`) y anotalos (`detectar.py --sin-red --anotar …`). Sin el conector de Meta no hay campaña.
3. Si existe `estado/freno.json`, no se lanza nada: decilo y terminá.

## El ciclo
Primera vuelta, abre el producto (el número lo elige el director):
```
python herramientas/director.py --modo principal --via sesion --solo nuevo
```
Vueltas siguientes, sobre ese producto (`OF-NNN` sale de la primera vuelta):
```
python herramientas/director.py --modo pulso --via sesion --solo OF-NNN
```
Cada vuelta imprime `OF-NNN estado → acción | motivo` y un JSON final con `"pedidos"`. Por cada pedido:
- Lanzá **un** subagente (Agent, `subagent_type: general-purpose`), con el modelo del pedido (`opus`, `sonnet` o `haiku`; nunca `fable`) y este prompt:
  «Sos un worker de hyperflujo-auto. Leé `<prompt del pedido>` y hacé exactamente eso, solo esa etapa y solo ese producto. Al terminar escribí tu JSON final en `<salida del pedido>` y devolvelo.»
- Uno por vez: esperá a que termine antes de la vuelta siguiente. Si dos pedidos son de productos distintos, pueden ir en paralelo.
- No le corrijas el trabajo a mano ni edites su salida: si salió mal, la vuelta siguiente lo ve por artefacto y decide (reintento o `fallida`).

Después de cada worker, otra vuelta del director. Pará cuando:
- el producto esté en `activo` (terminó: la campaña se activó con la autorización escrita);
- el estado sea de espera: `hotmart_enviado` mientras Hotmart aprueba (lo retoma solo el vigía horario o `/lanzar` más tarde), o `campana_en_pausa` esperando la medianoche si así lo dice el motivo;
- la activación espera por E3 (compuerta del sitio publicado): si el motivo es «falta la confirmación escrita del checkout abierto desde el país», es el único paso humano por mercado nuevo. Decile a la persona: con una VPN de ese país, abrir el checkout del producto, mirar precio y moneda, y correr `python herramientas/firmar.py checkout` en su terminal. Cualquier otro rechazo de la compuerta (relleno, legales, píxel, testimonios) no se corrige a mano: va un worker de corrección por la vuelta siguiente;
- `bloqueada_humano` o `fallida`: el motivo dice qué falta. Si es un paso humano (sesión de Hotmart vencida, OAuth), dale a la persona **un** paso con el lugar exacto y terminá;
- lleves 30 vueltas: algo no avanza. Decilo con el último motivo; no sigas a ciegas (regla 14).

## Reglas
- Antes de publicar la landing (y cada vez que una herramienta antes bloqueada, como Higgsfield, queda libre) repasá `ofertas/OF-NNN/landing/pendientes_medios.json`: los pendientes de medios se generan en esa vuelta con un worker de corrección y se marcan resueltos. La compuerta no deja publicar con pendientes. No ofrezcas «¿lo arranco?» ni «te lo muestro antes de publicar»: si hay un problema, se corrige y se sigue.
- No tocás productos que no sean el de esta corrida (`--solo`). Las landings publicadas y las campañas vivas de otros productos no se tocan (D118).
- No escribís en Meta, Hotmart ni Netlify fuera de un worker con ticket del plan: lo frena el guardián, y está bien que lo frene.
- Nada de testimonios ni reseñas (D119).
- Al final: mostrá el informe (`estado/informes/<fecha>-pulso.md`) en cinco líneas: qué producto, en qué estado quedó, qué se gastó (real o «nulo») y qué espera, si espera algo.
