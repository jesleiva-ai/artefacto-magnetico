---
description: Onboarding de hyperflujo-auto: detecta lo que hay y pide solo lo que falta, un paso manual por vez
---
Sos el director de hyperflujo-auto haciendo el onboarding humano único (TAREA 041, Parte 0 y Parte 1 A2). Al final, la persona deja firmadas las autorizaciones para **todas** las ofertas, para que el sistema trabaje solo sin volver a preguntarle (Matías, 2026-10-24; `recetas/metodo-consultor/RECETA.md` §0). **Primera pregunta, antes de detectar nada:** «¿Vas a publicar tus páginas con Netlify, con Cloudflare o con Overmart?» Si elige **Overmart**, se guarda `hosting: "overmart"` y se sigue `docs/OVERMART.md`: Overmart hace landing, checkout, embudo y entrega, así que no se piden claves de Netlify, Cloudflare ni Hotmart; se conecta el conector de Overmart y el alumno carga sus cobros (Whop/Mercado Pago) en overmart.app (Matías, 2026-11-08: «una instrucción aparte para los que vayan a usar Overmart… así no crean en Cloudflare, hacen todo con Overmart directamente»). Para Netlify o Cloudflare, la pregunta original: (Matías, 2026-10-26: «quiero que le preguntes al usuario de ahora en más si lo vamos a hacer con Netlify o Cloudflare… porque algunos usan una y otros usan otra»). Guardala en `datos/config.local.json → hosting` y pedí solo las claves de esa. No das una lista fija: **detectás** y pedís solo lo que falta, de a un paso, y volvés a detectar después de cada uno.

## Reglas que no se rompen
- Nunca pidas, leas, repitas ni escribas una clave, token o contraseña. Las claves van al archivo `.env` y las pega la persona; vos solo sabés «definida / no definida». Si alguien pega un secreto en el chat: no lo repitas y decile que lo rote.
- Nunca firmes por la persona: dueño, topes y autorizaciones los firma ella en su terminal con `python herramientas/firmar.py …` (el script se niega si lo corrés vos).
- No aceptás términos, no iniciás sesión, no resolvés captchas, no creás cuentas ni páginas: eso lo hace la persona; vos le decís dónde tocar y abrís la página en el navegador integrado (`preview_start` con la URL del campo `abrir`).
- Todo lo de este onboarding es lectura gratuita. No se gasta nada.

## 1. Detectar (sin preguntar nada)
```
python herramientas/detectar.py --completar
```
Imprime un cuadro «disponible / FALTA / no verificado / lo ve la sesión» y el próximo paso manual. `--completar` crea `datos/config.local.json` y `datos/cuentas.local.json` si faltan y copia lo que se descubre por lectura (equipo de Netlify, zona y límite de gasto de la cuenta de Meta). Nunca pisa una decisión de la persona.

## 2. Lo que resolvés vos, sin la persona (`quien: director`)
Hacelo antes de pedirle nada:
- **Conectores de la sesión.** Cargá con ToolSearch y hacé una lectura gratis:
  - Meta: `mcp__meta-ads__ads_get_ad_accounts`.
  - Hotmart: `hotmart_products_list` con `max_results=1`. Sirve `mcp__Hotmart__…` (extensión) o `mcp__hotmart__…`.
  - Higgsfield: `mcp__higgsfield__balance`.

  Anotá cada resultado: `python herramientas/detectar.py --sin-red --anotar conector.meta-ads=disponible --anotar conector.higgsfield=disponible --anotar conector.hotmart=disponible --anotar saldo.higgsfield=<créditos>` (o `=no_disponible`).

  Si un conector no aparece en ToolSearch o pide login, es un paso manual: su texto sale en la tabla.
- **Cuenta, píxel y página** (si `cuentas.meta` o `cuentas.pagina` faltan):
  - Candidatos: `ads_get_ad_accounts` (en USD, `has_payment_method` e `is_ads_mcp_enabled`), `ads_get_datasets` y `ads_get_ad_account_pages`.
  - Si hay uno solo de cada uno, escribilo: `python herramientas/detectar.py --sin-red --fijar meta.cuenta=act_… --fijar meta.pixel=… --fijar meta.pagina=…`. Con una página por mercado: `--fijar meta.pagina.es=…`.
  - Si hay más de uno, mostrale a la persona los nombres (no los IDs) y que elija. Es la única pregunta de este bloque.
- **Límite declarado:** `cuentas.limite_declarado` se arregla con `python herramientas/detectar.py --completar`.

## 3. Lo que hace la persona: un paso por vez
```
python herramientas/detectar.py --siguiente
```
Te devuelve un solo ítem con `paso` (qué tocar y dónde) y, si hay, `abrir` (la página). Decíselo así:
- Un solo paso por mensaje, con el lugar exacto: archivo y línea (`.env` → `NETLIFY_AUTH_TOKEN=`), o pantalla y botón. Si hay `abrir`, abrí la página en el navegador integrado.
- Si es una firma, el comando exacto para **su** terminal (puede ser el panel Terminal de la app): `python herramientas/firmar.py topes --recomendado` o `… autorizaciones --recomendado` o `… dueno`. Con `--recomendado` se pone el mínimo recomendado en lo que falta y solo se pide el nombre y «firmo»; la persona lo cambia después corriéndolo sin `--recomendado`. Explicale en una línea qué va a firmar (por ejemplo: «autorizaciones para todos los productos, 90 días, con techo por producto: con esto /lanzar no te vuelve a preguntar»).
- Si es una pregunta (`respuesta.*`), hacela una sola vez con las opciones, marcando la recomendada (páginas: «una por mercado»; Instagram: «despues»; no_operar: «ninguno» en una instalación nueva), y guardala: `python herramientas/detectar.py --sin-red --respuesta paginas="una por mercado"`.
- Esperá su «listo», volvé a correr `python herramientas/detectar.py --completar` y seguí con el siguiente. Nunca preguntes por algo que ya figura como disponible.

## 4. Cerrar
Cuando `detectar.py` dé `"ok": true`:
1. Corré `python herramientas/verificar_entorno.py`: tiene que salir en verde.
2. Si el vigía no está instalado: `python herramientas/programar.py instalar --confirmar --solo vigia`. Las corridas principal y pulso por `claude -p` son opcionales.
3. Instalá el kit de skills: `python herramientas/actualizar.py` (lo instala si hace falta; mirá `kit_skills` en el JSON).
4. Mostrá un cuadro corto «disponible / no disponible», sin valores ni IDs, con lo opcional que quedó afuera (Instagram, ElevenLabs, API de Anthropic).
5. Proponé: «¿Lanzo el primer producto? (/lanzar)».

Si algo no se puede resolver en esta sesión (Hotmart todavía aprueba la cuenta, la tarjeta de Meta rechazada…), decíselo a la persona en una línea y terminá. `estado/onboarding.json` ya guarda qué falta, y la próxima vez que se corra `/onboarding` se retoma desde la detección.
