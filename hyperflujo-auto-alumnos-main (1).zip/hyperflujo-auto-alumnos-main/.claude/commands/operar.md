---
description: Operación diaria: lee gasto y ventas, aplica las reglas de Matías (receta del Método del Consultor §9) a los productos activos y ejecuta solo lo autorizado
---
Sos el director de hyperflujo-auto en la corrida diaria. Decide el código: el director cruza gasto de Meta con ventas netas de Hotmart y aplica las reglas (`docs/REGLAS_META_ADS.md` y `recetas/metodo-consultor/RECETA.md` §9: cuándo tocar, qué anuncio reemplazar, con qué nivel y ángulo, y cómo escalar). Vos corrés el director y lanzás los workers que pida.

1. `python herramientas/detectar.py --sin-red`: si falta algo obligatorio, decilo y proponé `/onboarding`.
2. Primero, en seco: `python herramientas/director.py --modo pulso --solo-lectura`. Leé el informe `estado/informes/<fecha>-pulso-solo-lectura.md` y contale a la persona, en pocas líneas, qué haría hoy y por qué regla.
3. Después, de verdad: `python herramientas/director.py --modo pulso --via sesion`.
   - No abre productos nuevos.
   - Ejecuta solo las acciones sin modelo (pausar, bajar).
   - Deja `"pedidos"` para lo que necesita un worker (escalar, reemplazar, reponer, activar). Lanzalos igual que en `/lanzar`: un subagente por pedido, con el modelo del pedido, leyendo su prompt y escribiendo su salida. Después, otra vuelta del director, hasta que no queden pedidos (máximo 10 vueltas).
   - Lo que la autorización escrita no cubre (`escalar`, `reemplazar`) queda como **propuesta** en el informe, sin ejecutar.
4. Los productos de `no_operar` (la respuesta del onboarding: los opera otra persona) no se tocan. El director ya los saltea.
5. Cerrá con el informe en pocas líneas: por producto, gasto, neto de Hotmart, ROAS, qué se hizo y qué quedó propuesto. Nunca inventes un 0: lo que no se leyó es «nulo».
