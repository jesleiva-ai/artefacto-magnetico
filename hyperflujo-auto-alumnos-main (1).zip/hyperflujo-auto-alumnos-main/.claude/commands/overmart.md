---
description: Muestra cómo usar el Hyperflujo con Overmart (sin Netlify, Cloudflare ni Hotmart)
---
Leé `docs/OVERMART.md` completo y explicale a la persona, en pocas líneas y en su idioma, cómo se trabaja con Overmart: qué tiene que preparar una sola vez (cuenta y tienda, conector en versión 2026-11-15 o más nueva, cobros con Whop o Mercado Pago, píxel y Clarity, cuenta publicitaria en Métricas, subdominio, recuperación de carritos y avisos) y cómo es el paso a paso de un lanzamiento. Dejale claro que si algo falla lo anota en `ofertas/OF-xxx/TRABAS_OVERMART.md` y se lo pasa a Matías (§5). Si todavía no eligió Overmart en el onboarding, guardá `hosting: "overmart"` en `datos/config.local.json`. Después preguntale si arranca con la preparación.
