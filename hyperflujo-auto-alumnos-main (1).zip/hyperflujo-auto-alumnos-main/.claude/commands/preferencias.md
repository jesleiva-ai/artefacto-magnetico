---
description: Muestra, agrega o quita las preferencias del dueño (cómo quiere usar su hyperflujo); quedan guardadas para siempre
---
Preferencias del dueño: `~/.hyperflujo/preferencias.md` (Regla 0 bis de `CLAUDE.md`). En Mac, `python3` en lugar de `python`.

- Sin más indicaciones: `python herramientas/preferencias.py ver` y mostralas numeradas, en pocas líneas.
- Si la persona dice qué quiere cambiar: `python herramientas/preferencias.py agregar "…"` con sus palabras, y si choca con una anterior, `python herramientas/preferencias.py quitar <n>` de la vieja.
- Si la preferencia tiene un archivo de configuración (topes, autorizaciones, `datos/config.local.json`), aplicala también ahí.
- Una skill nueva que quiera sumar va a `~/.claude/skills/<nombre>/SKILL.md`; una skill del repo que no quiera usar se anota como preferencia, no se borra.

Cerrá en una línea: qué quedó guardado y que vale para todos los chats y carpetas de esta computadora.
