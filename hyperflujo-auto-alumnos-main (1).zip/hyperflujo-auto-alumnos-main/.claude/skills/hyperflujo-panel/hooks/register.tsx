// Panel de hyperflujo (Ramiro, 2026-10-30): al lado del chat, cómo va cada producto, el gasto de Meta contra las ventas
// netas de Hotmart, el freno, el plan del día y la actualización; arriba del prompt, una línea con lo del día; y un aviso
// por cada venta nueva. Solo lee: nunca escribe en estado/ ni toca Meta, Hotmart o Netlify.
import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { Resumen } from '../types'
import { resumir, usd } from './resumen'
import type { Archivos } from './resumen'

const PANEL = 'hyperflujo'
const CADA_MS = 5 * 60 * 1000
const resumen = atom({ plugin: 'hyperflujo-panel', key: 'resumen' } as const, null, { shape: 'resumen-1' })
const bandaOculta = atom({ plugin: 'hyperflujo-panel', key: 'bandaOculta' } as const, false)

const NOMBRES: Record<string, string> = {
  por_cazar: 'buscando producto', candidato: 'candidato', producido: 'producido', en_revision: 'en revisión',
  hotmart_enviado: 'esperando a Hotmart', lista_para_activar: 'listo para activar', campana_en_pausa: 'campaña en pausa',
  activo: 'activo', escalando: 'escalando', rechazo_meta: 'rechazado por Meta', pausada_tecnica: 'pausado',
  en_baja: 'dado de baja', bloqueada_humano: 'espera tu decisión', fallida: 'falló',
}

async function leer($: EngineInterface, ruta: string): Promise<string | undefined> {
  try {
    return await $.fs.read(ruta)
  } catch {
    return undefined
  }
}

async function esHyperflujo($: EngineInterface): Promise<boolean> {
  return (await $.fs.exists('herramientas/director.py').catch(() => false)) && (await $.fs.exists('estado').catch(() => false))
}

async function carpetaPreferencias($: EngineInterface): Promise<string | undefined> {
  const propia = await $.env.get('HYPERFLUJO_PREFS')
  if (propia) return propia
  const casa = (await $.env.get('USERPROFILE')) || (await $.env.get('HOME'))
  return casa ? `${casa}/.hyperflujo` : undefined
}

async function refrescar($: EngineInterface, avisar: boolean): Promise<Resumen | null> {
  if (!(await esHyperflujo($))) return null
  const ahora = await $.clock.now()
  const config = await leer($, 'datos/config.local.json')
  const prefs = await carpetaPreferencias($)
  const a: Archivos = {
    productos: await leer($, 'estado/productos.json'),
    config,
    topes: await leer($, 'datos/topes.local.json'),
    freno: await leer($, 'estado/freno.json'),
    actualizacion: await leer($, 'estado/actualizacion.json'),
    vigia: await leer($, 'estado/vigia_ultimo.json'),
    preferencias: prefs ? await leer($, `${prefs}/preferencias.md`) : undefined,
  }
  const hoy = resumir(a, ahora).hoy
  a.plan = await leer($, `estado/planes/${hoy}.json`)
  const r = resumir(a, ahora)

  // Ventas nuevas desde la última vez que se miró (también las que entraron con Claude cerrado).
  const vistas = Number(await $.store.get('ventasVistas'))
  if (avisar && Number.isFinite(vistas) && r.ventasTotal > vistas) {
    const n = r.ventasTotal - vistas
    const texto = n === 1 ? '¡Nueva venta en Hotmart!' : `¡${n} ventas nuevas en Hotmart!`
    $.ui.toast(`${texto} Hoy: ${r.ventasHoy ?? '—'} ventas, neto ${usd(r.netoHoy)}`, { timeoutMs: 10000 })
    void $.ui.notify(texto, { title: 'hyperflujo' }).catch(() => undefined)
  }
  if (!Number.isFinite(vistas) || r.ventasTotal !== vistas) await $.store.set('ventasVistas', r.ventasTotal)

  await update($, resumen, () => r)
  return r
}

// Solo donde hay una pantalla: en los workers `claude -p` no se dibuja nada y el mod no lee (si leyera, marcaría como
// vistas las ventas y el aviso no le llegaría al dueño). La app de escritorio arranca la sesión como el SDK
// (isInteractive false, sin superficie) y la pantalla se suma después (session.attach): por eso se arranca ahí, y al
// final de cada turno si todavía no arrancó (también tras recargar el mod, que deja estas variables en cero).
let arrancado = false
let comando = false

async function arrancar($: EngineInterface): Promise<void> {
  if (!comando) {
    comando = true
    await $.command.register({ name: 'panel', description: 'Abre el panel de hyperflujo: productos, gasto, ventas y freno' })
  }
  if (arrancado || (await $.session.surfaces()).length === 0) return
  arrancado = true
  const r = await refrescar($, true)
  if (!r) return
  void $.ui.open({ id: PANEL, title: 'Hyperflujo hoy' })
  $.clock.every(CADA_MS, () => void refrescar($, true))
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    const r = await next(e)
    await arrancar($)
    return r
  })

  on('session.attach', async ($, e, next) => {
    const r = await next(e)
    await arrancar($)
    return r
  })

  on('command.run', { command: 'panel' }, async $ => {
    const r = await refrescar($, false)
    if (!r) return { text: 'Esta carpeta no es un hyperflujo: abrí Claude en la carpeta de tu hyperflujo para ver el panel.' }
    await update($, bandaOculta, () => false)
    await $.ui.open({ id: PANEL, title: 'Hyperflujo hoy', focus: true })
    return { text: 'Panel de hyperflujo abierto.' }
  })

  // Al terminar cada turno se relee: si el worker o el director cambiaron algo, el panel lo muestra enseguida.
  on('turn.complete', async ($, e, next) => {
    if (arrancado) void refrescar($, true)
    else await arrancar($)
    return next(e)
  })

  on('ui.render', { component: 'Pane', requestId: PANEL }, async ($, e) => {
    const { Box, Text, Button } = $.ui.resolve(e)
    const r = await read($, resumen)
    if (!r) return <Text dimColor>Abrí Claude en la carpeta de tu hyperflujo para ver el panel.</Text>
    const sobreTope = r.metaHoy !== null && r.topeDiario !== null && r.metaHoy > r.topeDiario
    return (
      <Box flexDirection="column" gap={1}>
        <Box flexDirection="column">
          <Text bold>Hoy, {r.hoy}</Text>
          {r.freno && <Text color="error" bold>Freno puesto: {r.freno}. Solo se permite pausar.</Text>}
          {r.bloqueados > 0 && <Text color="warning">{r.bloqueados} producto(s) esperan tu decisión.</Text>}
          <Text color={sobreTope ? 'error' : undefined}>
            Meta hoy: {usd(r.metaHoy)}{r.topeDiario !== null ? ` de ${usd(r.topeDiario)} de tope diario` : ''}
          </Text>
          <Text>Ventas hoy: {r.ventasHoy ?? '—'} · neto Hotmart {usd(r.netoHoy)}</Text>
          <Text dimColor>
            {r.vigia ? `Última lectura del vigía: ${r.vigia.slice(11, 16)}` : 'El vigía todavía no leyó Meta ni Hotmart.'}
          </Text>
        </Box>

        <Box flexDirection="column">
          <Text bold>Productos</Text>
          {r.productos.length === 0 && <Text dimColor>Todavía no hay productos. Pedile a Claude: «lanzá un producto».</Text>}
          {r.productos.map(p => (
            <Box key={p.of} flexDirection="column">
              <Text>
                <Text bold>{p.of}</Text> {p.nombre.length > 40 ? p.nombre.slice(0, 39) + '…' : p.nombre}
              </Text>
              <Text dimColor={p.gasto === null && p.ventas === null}>
                {'  '}{NOMBRES[p.estado] ?? p.estado} · gasto {usd(p.gasto)} · {p.ventas ?? '—'} ventas · neto {usd(p.neto)}
                {p.roas !== null && (
                  <Text color={p.roas >= 2 ? 'success' : p.roas < 1 ? 'error' : 'warning'}> · ROAS {p.roas.toFixed(2)}</Text>
                )}
              </Text>
            </Box>
          ))}
          {r.retirados > 0 && <Text dimColor>{r.retirados} retirado(s) no se muestran.</Text>}
        </Box>

        <Box flexDirection="column">
          <Text dimColor>
            Plan del día: {r.planAcciones} acción(es){r.planEnCurso ? `, ${r.planEnCurso} en curso` : ''}
          </Text>
          {r.actualizacion && (
            <Text dimColor={r.actualizacion.ok} color={r.actualizacion.ok ? undefined : 'warning'}>
              Actualización: {r.actualizacion.ok ? `al día (${r.actualizacion.fecha})` : `falló el ${r.actualizacion.fecha}: ${r.actualizacion.motivo}`}
            </Text>
          )}
          <Text dimColor>
            Preferencias guardadas: {r.preferencias}{r.preferencias ? '' : ' (decile a Claude cómo querés usarlo)'}
          </Text>
        </Box>

        <Button key="refrescar" label="Actualizar" onPress={() => refrescar($, false)} />
      </Box>
    )
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const r = await read($, resumen)
    if (e.props.hasSurvey || r === null) return next(e)
    const alerta = r.freno ? `Freno puesto: ${r.freno}` : r.bloqueados ? `${r.bloqueados} producto(s) esperan tu decisión` : null
    if (!alerta && (await read($, bandaOculta))) return next(e)
    const { Box, Button, Text } = $.ui.resolve(e)
    return (
      <Box gap={1}>
        {alerta ? (
          <Text color="error">{alerta}</Text>
        ) : (
          <Text dimColor>
            Hyperflujo · Meta hoy {usd(r.metaHoy)}{r.topeDiario !== null ? ` / ${usd(r.topeDiario)}` : ''} · {r.ventasHoy ?? '—'} ventas · neto {usd(r.netoHoy)}
          </Text>
        )}
        <Button key="panel" label="Panel" onPress={() => $.ui.open({ id: PANEL, title: 'Hyperflujo hoy', focus: true })} />
        {!alerta && <Button key="ocultar" label="Ocultar" onPress={() => update($, bandaOculta, () => true)} />}
      </Box>
    )
  })
}
