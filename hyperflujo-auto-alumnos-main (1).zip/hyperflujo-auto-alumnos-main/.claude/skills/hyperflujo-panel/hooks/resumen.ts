// Lee el estado de hyperflujo tal como lo dejan el director y el vigía (estado/productos.json, planes, freno,
// actualización) y lo resume para el panel. Sin Python: el mismo en Mac y en Windows. Medición desconocida = null,
// nunca 0 (regla 8 del taller): un total con un día sin leer queda null, como estado.acumulado().
import type { Producto, Resumen } from '../types'

export type Archivos = {
  productos?: string
  config?: string
  topes?: string
  freno?: string
  plan?: string
  actualizacion?: string
  vigia?: string
  preferencias?: string
}

type Medicion = { gasto?: number | null; ventas?: number | null; ingresos?: number | null }
type ProductoCrudo = { of: string; nombre?: string; estado?: string; ficticio?: boolean; mediciones?: Record<string, Medicion> }

const ORDEN = ['escalando', 'activo', 'campana_en_pausa', 'lista_para_activar', 'hotmart_enviado', 'en_revision', 'producido',
  'candidato', 'por_cazar', 'bloqueada_humano', 'rechazo_meta', 'pausada_tecnica', 'en_baja', 'fallida']

function json<T>(texto: string | undefined): T | null {
  if (texto === undefined) return null
  try {
    return JSON.parse(texto) as T
  } catch {
    return null
  }
}

export function fechaEn(zona: string | undefined, ahoraMs: number): string {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: zona || undefined, year: 'numeric', month: '2-digit', day: '2-digit' })
      .format(new Date(ahoraMs))
  } catch {
    return new Date(ahoraMs).toISOString().slice(0, 10)
  }
}

function suma(valores: (number | null | undefined)[]): number | null {
  if (valores.length === 0 || valores.some(v => v === null || v === undefined)) return null
  return (valores as number[]).reduce((a, b) => a + b, 0)
}

export function resumir(a: Archivos, ahoraMs: number): Resumen {
  const config = json<{ zona?: string }>(a.config)
  const hoy = fechaEn(config?.zona, ahoraMs)
  const base = json<{ productos?: Record<string, ProductoCrudo> }>(a.productos)
  const crudos = Object.values(base?.productos ?? {}).filter(p => !p.ficticio)
  const vivos = crudos.filter(p => p.estado !== 'retirado')

  const productos: Producto[] = vivos.map(p => {
    const ms = Object.values(p.mediciones ?? {})
    const dia = p.mediciones?.[hoy]
    const gasto = suma(ms.map(m => m.gasto))
    const neto = suma(ms.map(m => m.ingresos))
    return {
      of: p.of,
      nombre: p.nombre ?? '',
      estado: p.estado ?? '?',
      gasto,
      ventas: suma(ms.map(m => m.ventas)),
      neto,
      roas: gasto !== null && neto !== null && gasto > 0 ? neto / gasto : null,
      gastoHoy: dia ? dia.gasto ?? null : null,
      ventasHoy: dia ? dia.ventas ?? null : null,
    }
  })
  productos.sort((x, y) => ORDEN.indexOf(x.estado) - ORDEN.indexOf(y.estado) || x.of.localeCompare(y.of))

  const conHoy = crudos.filter(p => p.mediciones?.[hoy])
  const delDia = (k: keyof Medicion) => (conHoy.length ? suma(conHoy.map(p => p.mediciones?.[hoy]?.[k])) : null)
  const ventasTotal = crudos.reduce((t, p) => t + Object.values(p.mediciones ?? {}).reduce((s, m) => s + (m.ventas ?? 0), 0), 0)

  const plan = json<{ acciones?: { estado?: string }[] }>(a.plan)
  const acciones = plan?.acciones ?? []
  const act = json<{ fecha?: string; ok?: boolean; motivo?: string }>(a.actualizacion)
  const vigia = json<{ hora?: string; generado_en?: string }>(a.vigia)
  const freno = a.freno === undefined ? null : json<{ motivo?: string }>(a.freno)?.motivo || 'freno del dueño'

  return {
    hoy,
    freno,
    metaHoy: delDia('gasto'),
    ventasHoy: delDia('ventas'),
    netoHoy: delDia('ingresos'),
    topeDiario: json<{ tope_diario_global_usd?: number }>(a.topes)?.tope_diario_global_usd ?? null,
    ventasTotal,
    productos,
    retirados: crudos.length - vivos.length,
    bloqueados: vivos.filter(p => p.estado === 'bloqueada_humano').length,
    planAcciones: acciones.length,
    planEnCurso: acciones.filter(x => x.estado === 'en_curso' || x.estado === 'pendiente').length,
    actualizacion: act?.fecha ? { fecha: act.fecha, ok: act.ok === true, motivo: act.motivo ?? '' } : null,
    vigia: vigia?.hora ?? vigia?.generado_en ?? null,
    preferencias: (a.preferencias ?? '').split('\n').filter(l => l.startsWith('- ')).length,
  }
}

export function usd(n: number | null): string {
  return n === null ? '—' : 'USD ' + n.toFixed(2).replace('.', ',')
}
