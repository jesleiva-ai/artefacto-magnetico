import { expect, test } from 'claude-code/testing'

import { resumir } from '../hooks/resumen'

const HOY = Date.UTC(2026, 9, 30, 15, 0)
const PRODUCTOS = JSON.stringify({
  productos: {
    'OF-006': { of: 'OF-006', nombre: 'Paso a Clic', estado: 'activo', mediciones: {
      '2026-10-29': { gasto: 10, ventas: 1, ingresos: 8.88 },
      '2026-10-30': { gasto: 4.5, ventas: 2, ingresos: 17.76 },
    } },
    'OF-007': { of: 'OF-007', nombre: 'Korbklassiker', estado: 'en_revision', mediciones: {
      '2026-10-30': { gasto: null, ventas: 0, ingresos: 0 },
    } },
    'OF-001': { of: 'OF-001', nombre: 'Tejer', estado: 'retirado', mediciones: {} },
    'OF-099': { of: 'OF-099', nombre: 'Ensayo', estado: 'activo', ficticio: true, mediciones: {} },
  },
})

test('el resumen suma por producto y un día sin leer queda nulo', async () => {
  const r = resumir({ productos: PRODUCTOS, config: '{"zona":"America/Argentina/Buenos_Aires"}',
    topes: '{"tope_diario_global_usd":30}', freno: '{"motivo":"vacaciones"}' }, HOY)
  expect(r.hoy).toBe('2026-10-30')
  expect(r.productos.map(p => p.of)).toEqual(['OF-006', 'OF-007'])
  expect(r.productos[0]?.gasto).toBe(14.5)
  expect(r.productos[0]?.roas?.toFixed(2)).toBe('1.84')
  expect(r.productos[1]?.gasto).toBe(null)
  expect(r.metaHoy).toBe(null)
  expect(r.ventasHoy).toBe(2)
  expect(r.ventasTotal).toBe(3)
  expect(r.retirados).toBe(1)
  expect(r.topeDiario).toBe(30)
  expect(r.freno).toBe('vacaciones')
})

const ARCHIVOS: Record<string, string> = {
  'estado/productos.json': PRODUCTOS,
  'datos/topes.local.json': '{"tope_diario_global_usd":30}',
}

test('el panel muestra cada producto en todas las superficies', async ($, on) => {
  on('fs.exists', () => ({ value: true }))
  on('fs.read', (_, e) => {
    const clave = Object.keys(ARCHIVOS).find(k => String(e.path).replaceAll('\\', '/').endsWith(k))
    const texto = clave === undefined ? undefined : ARCHIVOS[clave]
    if (texto === undefined) throw new Error('ENOENT')
    return { value: texto }
  })
  on('clock.now', () => ({ value: HOY }))
  on('clock.every', () => ({ value: undefined }))
  on('env.get', () => ({ value: undefined }))
  on('store.get', () => ({ value: undefined }))
  on('store.set', () => ({ value: undefined }))
  on('session.surfaces', () => ({ value: ['desktop'] }))
  on('command.register', () => ({ value: { command: 'panel' } }))
  on('ui.open', () => ({ value: { isPlaced: true } }))
  on('session.start', (_, e) => ({ cwd: e.cwd }))

  await $.session.start({ cwd: '/', surface: 'desktop', isInteractive: true })

  for (const surface of ['terminal', 'desktop'] as const) {
    const ui = await $.ui.mount({
      plugin: 'hyperflujo-panel', component: 'Pane', requestId: 'hyperflujo', surface,
      props: { title: 'Hyperflujo hoy', isFocused: false, bodyColumns: 60, placement: 'dock', scroll: { offset: 0, bodyRows: 40 }, view: {} },
    })
    expect(await ui.find({ type: 'Text', text: /OF-006/ })).toBeDefined()
    expect(await ui.find({ type: 'Text', text: /ROAS 1\.84/ })).toBeDefined()
    expect(await ui.find({ type: 'Text', text: /1 retirado/ })).toBeDefined()
    await ui.unmount()
  }
})
