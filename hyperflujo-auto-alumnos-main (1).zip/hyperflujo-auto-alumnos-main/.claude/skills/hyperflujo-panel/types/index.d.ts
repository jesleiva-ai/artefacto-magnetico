export type Producto = {
  of: string
  nombre: string
  estado: string
  gasto: number | null
  ventas: number | null
  neto: number | null
  roas: number | null
  gastoHoy: number | null
  ventasHoy: number | null
}

export type Actualizacion = { fecha: string; ok: boolean; motivo: string }

export type Resumen = {
  hoy: string
  freno: string | null
  metaHoy: number | null
  ventasHoy: number | null
  netoHoy: number | null
  topeDiario: number | null
  ventasTotal: number
  productos: Producto[]
  retirados: number
  bloqueados: number
  planAcciones: number
  planEnCurso: number
  actualizacion: Actualizacion | null
  vigia: string | null
  preferencias: number
}

declare module 'claude-code' {
  interface PluginState {
    'hyperflujo-panel': {
      resumen: Shaped<Resumen | null>
      bandaOculta: boolean
    }
  }
}
