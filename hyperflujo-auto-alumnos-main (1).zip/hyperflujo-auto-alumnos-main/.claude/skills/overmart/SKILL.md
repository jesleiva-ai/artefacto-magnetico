---
name: overmart
description: Guía del Hyperflujo para quien vende con Overmart (la plataforma de Matías) en vez de Netlify/Cloudflare + Hotmart. Usar siempre que la persona diga Overmart, «overmart.app», «landing libre», «Whop», o haya elegido hosting overmart; también cuando pregunte dónde están las instrucciones de Overmart.
---
# Overmart

La guía completa está en **`docs/OVERMART.md`**. Leela entera antes de hacer nada y seguila.

En corto:
- Con Overmart **no** se usa Netlify, Cloudflare ni Hotmart. Overmart hace la landing (siempre **landing libre**, para que corran el píxel, Clarity y el conversor), el checkout (Whop en USD, Mercado Pago en ARS), el embudo (hasta 3 bumps y 3 upsells por conector; los downsells en el estudio web) y la entrega (PDF y/o portal).
- Se opera con el **conector de Overmart** (permisos leer, publicar, webhooks y tiendas), **versión 2026-11-15 o más nueva** (`tienda` → `conector.version_conector`; si es vieja o faltan `subdominio`, `carritos` o `avisos`, desconectar y conectar). Las claves de cobro las carga la persona en overmart.app, nunca en el chat.
- Además del producto, la landing y el embudo: precio en pesos de los extras (`embudo` → `precio`), subdominio (`subdominio`), recuperación de carritos (`carritos`), avisos, checkout de Whop revisado (`checkout_donde_se_ve`) y métricas por anuncio (`metricas_anuncios`).
- Las reglas del método son las mismas: Profesor 9+, Director de Videos, sin precio en anuncios, Clarity, sin aviso de cookies, Cash Trap.
- Overmart está en prueba. **Si algo falla, se anota y se le pasa a Matías** («que si algo falla, que lo anote y me lo pase»): en `ofertas/OF-xxx/TRABAS_OVERMART.md`, con fecha, versión del conector, herramienta, error y qué se esperaba, y después se le manda a Matías (guía §5).
