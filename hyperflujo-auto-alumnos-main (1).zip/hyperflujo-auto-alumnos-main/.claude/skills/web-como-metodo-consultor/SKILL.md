---
name: web-como-metodo-consultor
description: Regla de armado de toda página de venta nueva: la estructura simple y compacta del Método del Consultor (promesa con números, mockup grande, dolores, beneficios, lo que trae, bonus de regalo, oferta bien presentada, preguntas frecuentes), con 2 o 3 botones de compra solo desde la oferta, marketinera, animada y con 4 a 6 videos hiperrealistas de la temática del nicho. Dice también cómo publicar una web con anuncios activos sin romperla. Usar siempre que se arme, modele, corrija o revise una landing o web de venta, aunque no se nombre esta skill: «armá la web», «hacé la página», «modelá la landing», «la web quedó larga», «por qué no vende la página». Va junto con `landing-modelada` y la corrige el Profesor (`profesor-web`).
---

# Web como Método del Consultor

Matías, 2026-11-09: «la estructura que tiene la promesa, dolores, beneficios, presentación de la oferta con los bonos de regalo, pregunta frecuente y listo. […] hay otras webs que no están vendiendo bien porque se te hicieron muy largas. […] Si bien la web está simple, porque es blanca, yo no quiero que te quedes con eso. Quiero que te quedes con la estructura de la web, y que te quedes con que la web está bien compacta y que además está bien presentada la oferta. En resumen, la gente no se pierde y tiene buenos mockups».

La idea: quien llega del anuncio entiende en segundos qué se vende, baja sin perderse y llega a una oferta que se ve irresistible. Todo lo que no empuja hacia ahí se saca.

**Cuándo manda:** en toda landing nueva. `landing-modelada` dice cómo se trabaja (desarme, imágenes, técnica); esta skill dice cómo tiene que quedar. Si chocan, gana esta.

**Cuándo no se aplica:**
- **Calco a otro idioma de una web propia que ya vende:** es copia exacta, no se compacta ni se reordena.
- **Webs ya publicadas:** esta skill no autoriza a tocarlas. Sin el OK del dueño para ese cambio, se anota qué cambiar y se le pasa.
- Páginas de upsell, downsell, gracias y portal: tienen su propio formato.

## Qué se copia del Consultor y qué no

| Se copia | No se copia |
|---|---|
| El orden simple de los bloques | El fondo blanco: va la paleta del nicho |
| Una sola idea por bloque | Sus 10 links al checkout y la barra fija que compra |
| La oferta bien presentada, con los bonus | Su largo: unas 30 pantallas de celular |
| Mockups que venden | Los 5 videos seguidos, que suman unas 4 pantallas |

Medido el 2026-11-09 en sus 12 idiomas, a 390 × 844 px: entre 27 y 31 pantallas y 10 links al checkout, el primero recién después de la pantalla 6. Es la web que más vende, pero es anterior a la regla del 2026-11-09 y **no es la vara de largo ni de botones**. La vara son los números de abajo.

## La estructura, en este orden y sin agregar secciones

| # | Bloque | Cómo tiene que ser | Pantallas |
|---|---|---|---|
| 1 | **Promesa** | Primer título de la página. Verbo, resultado y números con plazo real, sacados de la ficha. | juntos, 1 a 1,5 |
| 2 | **Mockup grande del producto** | Lo más grande de la primera pantalla. La persona usándolo, chiquita o nada. | |
| 3 | **Botón que desliza a la oferta** | Parece un botón de compra, pero lleva a `#oferta`. Nunca al checkout. | |
| 4 | **Dolores** | De 3 a 5 tarjetas cortas que aparecen de a una. | hasta 2 |
| 5 | **Beneficios** | De 3 a 6, con ícono o emoji del tema. | hasta 2 |
| 6 | **Lo que trae** | Qué recibe y un solo carrusel de páginas reales. | hasta 3 |
| 7 | **Bonus de regalo** | De 2 a 5, cada uno con su mockup, y «de regalo» bien visible. | hasta 3 |
| 8 | **Presentación de la oferta** (`id="oferta"`) | Nombre de la oferta, imagen animada con el producto y **todos** los bonus juntos, lo que incluye, precio, reloj a fecha real y garantía de 7 días. | hasta 3 |
| 9 | **Botón de compra** | Grande y vivo, pegado a la oferta. | |
| 10 | **Preguntas frecuentes** | De 4 a 6, desplegables. | hasta 1,5 |
| 11 | **Botón de compra** | El último, el más llamativo. | |

Después, solo el pie con los avisos legales.

Lo que pedía la receta vieja no suma bloques: «cómo funciona» entra en una línea dentro de *Lo que trae*; «para quién es» y la tabla «No es otro…» se sacan. Las **opiniones reales**, si existen, son la única excepción: una tira corta entre la oferta y las preguntas, con su fuente y sus marcadores `OPINIONES-REALES`. Nunca se inventan, y si no hay, no va el bloque.

## Los números que se miden

Corré `node <esta skill>/scripts/medir_web.mjs <carpeta, index.html o URL>` desde la raíz del repo. Mide en celular y devuelve `"ok": true` o la lista de fallas.

| Regla | Meta | Falla si |
|---|---|---|
| Largo a 390 × 844 | 16 pantallas o menos (unos 13.500 px) | más de 20 (unos 17.000 px) |
| Bloques | 11 | más de 12 secciones |
| Palabras | 1.500 o menos | aviso desde 1.800 |
| Botones al checkout | 2 o 3 | menos de 2 o más de 3 |
| Primer botón al checkout | dentro de la oferta o después | antes de `#oferta`, o dentro de una barra fija |
| Botón que desliza | antes de la pantalla 2 | no hay un link a `#oferta` arriba |
| Alto del botón de compra | 64 px o más | menos de 64 px o sin animación |
| Título | con un número | sin números |
| Mockup de arriba | 300 px o más de ancho en celular | más chico, o no hay |

El Profesor corre esta misma medición. Los topes de largo son una vara de trabajo, no un dato de ventas: si el dueño decide otros, se cambian acá.

## Mockups

- Hiperrealistas y hechos con IA (Higgsfield `gpt_image_2_5`, calidad alta, 2K), con las tapas reales como referencia. Nunca armados con código sobre una foto.
- Uno grande arriba, **uno por cada bonus** y uno de la oferta con todo junto. Parecen una colección: misma tapa, mismos colores.
- Sin texto inventado adentro: el texto va con código.
- Imágenes en alta: de 720 a 750 px de ancho, AVIF con calidad 55 a 60. Nunca se achican para que entren.
- Lo que no se pudo generar va a `pendientes_medios.json`. Con pendientes no se publica.

## Videos en la web (obligatorios)

Matías, 2026-11-10: las webs que mejor venden (Consultor y Sueldo Claro) tienen videos; toda web nueva lleva videos y las que no tenían se los sumaron.

- **Cuántos y dónde:** de 4 a 6 videos cortos, repartidos de a uno donde suman: en los dolores, en lo que vas a poder hacer o los beneficios, en lo que trae (el producto por dentro) y en la oferta (el pack completo con todos los bonus, con movimiento). Nunca varios seguidos.
- **Cómo se hacen:** hiperrealistas, con IA. Primero una foto inicial (Higgsfield `gpt_image_2_5`, alta) y después imagen a video (Kling, Seedance o el que dé mejor), de 4 a 6 s, sin texto quemado y sin audio.
- **Pantallas y productos adentro de la foto:** si el video muestra una app, una pantalla, una tapa o el libro, eso tiene que estar dentro de la foto inicial, con la imagen real como referencia. **Nunca se pega una pantalla con código encima del video**: no sigue el movimiento de la mano y se nota (Matías lo marcó en Sueldo Claro, 2026-11-10).
- **La temática del nicho:** los videos siguen la línea visual de la página y del producto. Si la web es de historia, los videos son épicos e históricos; si es para maestras, son de aula. Nada genérico ni moderno que rompa la línea.
- **Revisión cuadro por cuadro:** manos con cinco dedos, caras que no cambian, nada traslúcido, letras sin deformar. Si la IA deforma un texto o una mano, se corta el video antes de ese momento o se descarta. Mejor un video menos que uno mal hecho.
- **Técnica:** mp4 h264 de 720 × 1280 (vertical; el de la oferta puede ser horizontal), de 300 a 800 KB, con póster AVIF. `<video data-src="…" poster="…" muted loop playsinline preload="none">`: se cargan al acercarse, se pausan fuera de pantalla y con `prefers-reduced-motion` no arrancan. Cada archivo con `?v=N` y se sube el número cuando cambia.

## Publicar una web que ya tiene anuncios

- Se publica **en su dirección de siempre**. Nunca se muda, se renombra la ruta ni se cambia el dominio: los anuncios activos apuntan ahí.
- Antes de publicar, bajá la versión en vivo y compará: solo tiene que cambiar lo pedido. Si hay cambios del dueño que no tenés, no se pisan.
- No se toca el píxel ni la medición si el pedido no es ese.
- Publicá sumando archivos, sin borrar lo que hay en el sitio. Después comprobá en vivo que los archivos nuevos son los mismos que revisaste y que el resto del sitio sigue abriendo.

## Marketinera y animada

El fondo blanco del Consultor no es parte del modelo. La web tiene que entrar por los ojos:

- Paleta del mundo del nicho, de 4 a 6 colores en `:root`, y dos fuentes elegidas.
- Usá `assets/kit-animaciones.css`: título que cambia de tono, imágenes que flotan desfasadas, bloques que aparecen de a uno al bajar. Con `prefers-reduced-motion`, todo queda quieto.
- La imagen de la oferta se mueve: flota con brillo, o es un video corto.

## Botones

- **Deslizar:** el de arriba, el del encabezado y el de la barra fija llevan a `#oferta`, con `html{scroll-behavior:smooth}`. Un botón de compra antes de la oferta genera pagos iniciados falsos y confunde a Meta.
- **Comprar:** 2 o 3 en total, desde la oferta para abajo. Ancho completo, 64 px o más de alto, y **titila y late**: fondo que corre, latido y brillo. Texto «QUIERO + verbo», con una línea chica abajo: «Pago único · acceso inmediato».
- **Barra fija abajo (opcional):** una línea con el descuento real y el reloj; desliza a la oferta, no compra.
- **Encabezado:** solo la marca y «Ver oferta», que desliza.

## Lo que va siempre

- **Precio:** la caja con precio va solo en la oferta. Todo precio lleva `data-usd` y conversor de moneda por IP.
- **Garantía de 7 días**, nunca otra.
- **Sin aviso de cookies**: el píxel y Clarity cargan al abrir la página.
- **Sin order bumps en la web**: se ofrecen en el checkout.
- **Reloj** solo a la fecha real de fin del lanzamiento; sin fecha real, no hay reloj. Nada de cupos ni compradores inventados.
- Todo dato sale de la ficha.

## Antes de entregar

1. `medir_web.mjs` da `"ok": true`.
2. Tiene de 4 a 6 videos revisados cuadro por cuadro, con la temática del nicho y nada pegado encima.
3. Mirala en el celular como un cliente: ¿se entiende qué se vende en la primera pantalla? ¿Alguna parte se podría sacar sin perder la venta? Sacala.
4. Pasala por el Profesor (`profesor-web`). Quien arma no se corrige a sí mismo.
