// medir_web.mjs: mide una landing en celular contra las reglas de la skill web-como-metodo-consultor.
// Uso (desde la raíz del repo, que tiene playwright): node <skill>/scripts/medir_web.mjs <carpeta | index.html | URL>
// Solo lee. Bloquea píxel y Clarity para no ensuciar las mediciones. Sale con código 1 si hay fallas.
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const VIEW = { width: 390, height: 844 };
const TOPE_PANTALLAS = 20, META_PANTALLAS = 16, TOPE_SECCIONES = 12, META_PALABRAS = 1500, AVISO_PALABRAS = 1800;
const COMPRA = /pay\.hotmart\.com|hotmart\.com\/[a-z-]*\/?checkout|checkoutMode=|whop\.com\/checkout|\/checkout\b/i;

const objetivo = process.argv[2];
if (!objetivo) { console.error('Falta la carpeta, el index.html o la URL.'); process.exit(2); }
let url = objetivo;
if (!/^https?:|^file:/.test(objetivo)) {
  let ruta = path.resolve(objetivo);
  if (fs.existsSync(ruta) && fs.statSync(ruta).isDirectory()) ruta = path.join(ruta, 'index.html');
  if (!fs.existsSync(ruta)) { console.error('No existe: ' + ruta); process.exit(2); }
  url = pathToFileURL(ruta).href;
}

let chromium;
try { ({ chromium } = createRequire(process.cwd() + '/')('playwright')); }
catch { console.error('Falta playwright: corré esto desde la raíz del repo, después de npm install.'); process.exit(2); }

const navegador = await chromium.launch({ channel: 'chrome' }).catch(() => chromium.launch());
const ctx = await navegador.newContext({ viewport: VIEW, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
const p = await ctx.newPage();
await p.route(/facebook|fbcdn|clarity\.ms/, r => r.abort());
await p.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
await p.waitForTimeout(1500);
for (let i = 0, fin = 0; i < 60; i++) {
  fin = await p.evaluate(() => { scrollBy(0, 700); return scrollY + innerHeight >= document.documentElement.scrollHeight - 5; });
  await p.waitForTimeout(100);
  if (fin) break;
}
await p.waitForTimeout(600);
const html = await p.content();
const m = await p.evaluate(src => {
  const COMPRA = new RegExp(src, 'i');
  const y = e => Math.round(e.getBoundingClientRect().top + scrollY);
  const enFijo = e => { for (let n = e; n && n !== document.body; n = n.parentElement) { if (getComputedStyle(n).position === 'fixed') return true; } return false; };
  const anim = e => getComputedStyle(e).animationName !== 'none' || getComputedStyle(e, '::after').animationName !== 'none' || getComputedStyle(e, '::before').animationName !== 'none';
  const links = [...document.querySelectorAll('a[href]')];
  const oferta = document.getElementById('oferta');
  const h1 = document.querySelector('h1');
  const h1y = h1 ? y(h1) : 0;
  const imgs = [...document.images].filter(i => i.offsetWidth > 0);
  const arriba = imgs.filter(i => y(i) >= h1y && y(i) < innerHeight * 1.5).sort((a, b) => b.offsetWidth - a.offsetWidth)[0];
  const top = [...document.querySelectorAll('section')].filter(s => !s.parentElement.closest('section') && s.offsetHeight > 40);
  return {
    alto: document.documentElement.scrollHeight,
    ancho: document.documentElement.scrollWidth,
    palabras: document.body.innerText.split(/\s+/).filter(Boolean).length,
    secciones: top.length,
    ofertaY: oferta ? y(oferta) : null,
    h1: h1 ? h1.innerText.trim() : '',
    compras: links.filter(a => COMPRA.test(a.href)).map(a => ({ y: y(a), alto: a.offsetHeight, fijo: enFijo(a), animado: anim(a), texto: a.innerText.trim().replace(/\s+/g, ' ').slice(0, 50) })),
    deslizan: links.filter(a => a.getAttribute('href') === '#oferta').map(a => ({ y: y(a), fijo: enFijo(a) })),
    mockup: arriba ? { ancho: arriba.offsetWidth, natural: arriba.naturalWidth } : null,
    bajas: imgs.filter(i => i.offsetWidth >= 200 && i.naturalWidth > 0 && i.naturalWidth < 700).map(i => (i.currentSrc || i.src).split('/').pop().slice(0, 50) + ' (' + i.naturalWidth + ' px)'),
    dataUsd: document.querySelectorAll('[data-usd]').length,
    texto: document.body.innerText,
  };
}, COMPRA.source);
await navegador.close();

const pantallas = +(m.alto / VIEW.height).toFixed(1);
const fallas = [], avisos = [];
if (pantallas > TOPE_PANTALLAS) fallas.push(`Larga: ${pantallas} pantallas (tope ${TOPE_PANTALLAS}).`);
else if (pantallas > META_PANTALLAS) avisos.push(`${pantallas} pantallas (meta ${META_PANTALLAS}).`);
if (m.secciones > TOPE_SECCIONES) fallas.push(`${m.secciones} secciones (tope ${TOPE_SECCIONES}).`);
if (m.palabras > AVISO_PALABRAS) avisos.push(`${m.palabras} palabras (meta ${META_PALABRAS}).`);
if (m.ofertaY === null) fallas.push('Falta la oferta con id="oferta".');
if (m.compras.length < 2 || m.compras.length > 3) fallas.push(`${m.compras.length} botones al checkout (tienen que ser 2 o 3).`);
for (const c of m.compras) {
  if (c.fijo) fallas.push(`Botón de compra en una barra fija: «${c.texto}».`);
  else if (m.ofertaY !== null && c.y < m.ofertaY) fallas.push(`Botón de compra antes de la oferta (y=${c.y}): «${c.texto}».`);
  if (!c.fijo && c.alto < 64) fallas.push(`Botón de compra bajo (${c.alto} px): «${c.texto}».`);
  if (!c.animado) fallas.push(`Botón de compra sin animación: «${c.texto}».`);
}
if (!m.deslizan.some(d => !d.fijo && d.y < VIEW.height * 2)) fallas.push('Falta el botón que desliza a #oferta antes de la pantalla 2.');
if (!/\d/.test(m.h1)) fallas.push('El título no tiene números.');
if (!m.mockup || m.mockup.ancho < 300) fallas.push('Falta el mockup grande arriba (300 px o más de ancho).');
if (m.ancho > VIEW.width + 1) fallas.push(`Corrimiento lateral: ${m.ancho} px de ancho.`);
if (m.bajas.length) avisos.push('Imágenes en baja: ' + m.bajas.join(', '));
if (!m.dataUsd) fallas.push('Ningún precio tiene data-usd.');
if (/\b(aceptar|accept)\b.{0,30}cookies|cookies.{0,60}\b(aceptar|accept)\b/is.test(m.texto)) fallas.push('Parece tener aviso de cookies.');
if (/\b15\s*(d[ií]as|days|jours|tage|giorni)\b.{0,40}garant|garant.{0,40}\b15\s*(d[ií]as|days|jours|tage|giorni)\b/is.test(m.texto)) fallas.push('La garantía dice 15 días.');
if (!/fbq\(/.test(html)) avisos.push('No encontré el píxel de Meta.');
if (!/clarity/i.test(html)) avisos.push('No encontré Microsoft Clarity.');
if (!/prefers-reduced-motion/.test(html)) avisos.push('No encontré prefers-reduced-motion en la página (puede estar en un CSS aparte).');

const { texto, ...datos } = m;
console.log(JSON.stringify({ ok: fallas.length === 0, pantallas, fallas, avisos, datos }, null, 1));
process.exit(fallas.length ? 1 : 0);
