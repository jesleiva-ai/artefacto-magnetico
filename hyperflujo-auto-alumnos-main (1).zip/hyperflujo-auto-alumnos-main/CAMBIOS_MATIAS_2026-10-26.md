# Cambios de Matías — 2026-10-26

Actualización del repo de alumnos para que trabaje como trabaja Matías hoy: **todo se lanza como el Método del Consultor y de forma automática, sin pedir confirmación.** Se hizo en dos tandas el mismo día (PR #1 y PR #2).

## Fuentes que se leyeron

- **Segundo cerebro** (`D:\segundo-cerebro`): `05_PROCESOS/` (lecciones, estrategia de anuncios, modelado, elegir ofertas, control antes de publicar, Utmify, calco por idioma, tipos de anuncios y placas, robot Nexus Profit, Netlify y GitHub, respuestas a clientes), `08_REFERENCIAS/` (notas de estilo y desarmes de landings), `06_PROYECTOS/` (el Consultor en 11 idiomas y el análisis de mercado multi-idioma) y `07_REVISIONES/` (reportes diarios de Meta y registro de cambios).
- **Memoria de Claude Code de Matías** (28 reglas con fecha y cita).
- **Repo `matias-proceso-lanzamiento`** y su copia local más nueva: el handoff del Método del Consultor y los briefs del 25 y 26/10 a los agentes de cada idioma.
- **Skills** instaladas y el paquete para alumnos que Matías armó el 24/10.
- **Sesiones de Claude de su PC**: la sesión directora, las de cada idioma del Consultor (cómo quedaron las webs y las opiniones), la de búsqueda de producto y los reportes diarios.
- **Matías en el chat (26/10):** escalera, requisitos de producto, opiniones reales, modo automático, borrar lo viejo, idiomas para escalar.
- No se copiaron datos de ventas por comprador, IDs de cuentas, claves ni material de las clases de Ramiro.

## Qué cambió, por carpeta

### Raíz
- `CLAUDE.md`: **Regla 0 de Matías** arriba de todo (modelo = Método del Consultor; automático; lo importante se guarda y lo viejo se reemplaza; gana Matías). Regla 2 (opiniones reales con fuente) y regla 11 (ventana de campaña de Matías) actualizadas.
- `ARRANQUE.md` y `README.md`: apuntan a la receta madre y al modo automático.
- `LEEME_ALUMNOS.md`: por dónde empezar, cómo se arranca y qué hace el código con el método.

### `recetas/`
- **Nueva `recetas/metodo-consultor/RECETA.md`**, la receta madre: modo automático; qué funcionó y qué no, por producto; buscar el producto; investigar países e idiomas; producto y escalera; web (modelado y calco); anuncios; Hotmart; píxel por producto y por país; campaña, cuándo reemplazar (con qué nivel y ángulo) y cómo escalar; control final.
- Cada receta (`anuncios`, `campana`, `cazar`, `hotmart`, `landing`, `operacion`, `producto`) dice qué paso de la receta madre es. Las referencias a la vieja `recetas/metodo-matias` ahora apuntan a la nueva.
- `anuncios` v1.2 y `hotmart` v1.2: los 9 ganadores, escenas nuevas, videos de 4 s, todas las pasarelas, el cupón y la escalera.

### `skills/` (motor)
- Las 12 skills apuntan a su sección de la receta madre y trabajan sin pedir confirmación.
- `producir-escalera` reescrita: por lo general 3 bumps, 1 upsell y 5 downsells, según la ficha.
- `landing`: calco en otro idioma, opiniones reales y la piel por marca; se sacó lo superado de D104.
- `modelar-oferta`: modelar la página tal cual.
- `meta-campana-cashtrap`: USD 75, regiones, botón, píxel por país y una sola campaña.
- `diagnostico-y-baja`: reemplazo por costo por venta y la ventana de Matías como corte por defecto.
- `cazar-oferta`: los requisitos nuevos.

### `herramientas/` y `datos/` (código)
- `meta_operacion.py` + `datos/reglas_operacion.json`: **corte de Matías por defecto** (48 h sin ventas → baja; con ventas no se corta antes del día 7). D92 queda como alternativa con `HYPERFLUJO_CORTE=d92`.
- `meta_operacion.diagnosticar`: también es perdedor el anuncio con **costo por venta mayor al precio**.
- `meta_campana.py`: botón **SEE_DETAILS en C3** y LEARN_MORE en C1/C2, al crear y al releer.
- `pixel.py` (+ `kit/sitio.py`, `compuerta_sitio.py`, `netlify_deploy.py`): **píxel por producto y por mercado** (`meta.pixeles`) y aviso si se reusa.
- `guardia_landing.py`: **opiniones reales** con fuente permitidas (marcadores `OPINIONES-REALES`); lo inventado sigue frenado.
- `calco_idioma.py` (nuevo): verifica que la web en otro idioma sea un calco.
- `datos/cazar.json`: 30 o más anuncios activos (40 ideal) y 10 días como mínimo.
- `ensayo_seco.py`: el guion ficticio de 8 días corre con el corte D92 para el que fue escrito.

### `pruebas/`
- Nuevas: `test_calco_idioma.py` (7) y `test_opiniones_reales.py` (4), más 2 en `test_pixel.py` y 3 en `test_reglas_036.py` (no baja antes de 48 h, modo d92, costo por venta).
- Actualizadas por el cambio de método: `test_reglas_036.py` (la baja sin ventas pasa de 24 h a 48 h), `test_campana_pausa.py` (C3 con SEE_DETAILS) y `test_cazar.py` (10 días).

### `conocimiento/matias/`
- Nuevos: `IDIOMAS_PARA_ESCALAR.md` (25 idiomas con su estado y sus riesgos), `13_receta_orquestador_metodo_consultor.md`, `notas/2026-10-26_novedades_del_metodo.md` y `memoria/`.
- En `cerebro/`: lecciones, estrategia de anuncios, control, Utmify, calco, tipos de anuncios y placas, storytime, notas de estilo, robot Nexus Profit, Netlify y GitHub, respuestas a clientes y `desarmes/`.
- **Lo viejo se reemplazó**: `MODELADO_PASO_A_PASO.md` y `ELEGIR_Y_MODELAR_OFERTAS.md` son la versión vigente (ya no hay copia vieja al lado). Se sacaron la escalera de 4 downsells, el arranque de 50/75 y el modo semi-automático. Las reglas repetidas de «no tocar la web» se unieron en una. La receta del orquestador ya no trae los pendientes ni las preguntas del 22/10.
- `skills/`: 29 skills nuevas (35 en total; `FUENTES.md`), con `meta-ads-mentor-method` sumada al final. En las copias de `operador-meta-ads`, `cash-trap-cbo-oro`, `embudo-hotmart-netlify`, `lanzar-en-hotmart`, `alertas-campanas`, `escalera-de-valor`, `guardar-sesion`, `jardin`, `importar-de-otras-ias`, `transcribir-y-minar`, `revisar-landing` y `revision-semanal` se cambió «pedir OK» por «avisar y seguir» (Matías, 2026-10-26).

### `docs/`
- `REGLAS_META_ADS.md`: precedencia Matías > Manual; USD 75; la ventana de Matías en el motor; el reemplazo por costo por venta; y la §11 con todo lo nuevo.
- `CAMBIOS_METODO.md`: 14 entradas del 2026-10-26 (qué decía, qué dice, por qué y con qué prueba).
- `MATIAS_ACCIONES.md`, `ARQUITECTURA.md`, `DECISIONES_HEREDADAS.md` y `OPERACION_DIARIA.md`: citas y referencias al día.

## Netlify o Cloudflare (Matías, 2026-10-26)
- El onboarding le pregunta al alumno **una sola vez**, primero de todo, si publica con Netlify o con Cloudflare, y lo guarda en `datos/config.local.json → hosting`. Ver `recetas/metodo-consultor/RECETA.md` §0 y §5 C, `skills/onboarding`, `/onboarding`, `skills/netlify`, `.env.ejemplo` y `herramientas/claves.py` (`CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`).
- Con Cloudflare, el agente publica con `wrangler pages deploy` y hace las mismas verificaciones; la publicación automática del motor sigue siendo solo para Netlify.
- La receta (§7) explica también cómo se entrega el producto: mail de Hotmart con PDF de acceso → página de gracias → portal con candados.

## Lo que queda para el motor de Ramiro

Al mezclar el «Sync desde hyperflujo-auto», estos archivos van a chocar porque los dos lados los tocaron: `CLAUDE.md`, `ARRANQUE.md`, `README.md`, `datos/reglas_operacion.json`, `datos/cazar.json`, `herramientas/{meta_operacion,meta_campana,pixel,guardia_landing,compuerta_sitio,netlify_deploy,ensayo_seco}.py`, `herramientas/kit/sitio.py`, las skills y recetas del motor y los `docs/`. **En la copia de alumnos gana el método de Matías:** al resolver, conservar sus reglas.

## Para correr las pruebas en Windows

Si el repo está en D: y las carpetas temporales en C:, una prueba de `test_netlify_rodeo` falla por la unidad (no por el método). Se corre con las temporales en la misma unidad:

```bash
TMP='D:\tmp' TEMP='D:\tmp' python -m unittest discover -s pruebas -t .
```
