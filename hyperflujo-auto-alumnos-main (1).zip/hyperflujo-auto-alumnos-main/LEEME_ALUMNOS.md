# hyperflujo-auto — copia para alumnos

Sistema para cazar, producir, publicar y operar productos digitales con Claude Code (Hotmart + Netlify + Meta Ads), con el método de Matías Parodi adentro. Trabaja **solo, sin pedir confirmación**, y lanza todo como el **Método del Consultor**, el producto de Matías que más vende.

## Por dónde empezar (en este orden)

1. **`recetas/metodo-consultor/RECETA.md`**: la receta madre, de punta a punta. Cómo se busca el producto (30 o más anuncios activos, mejor 40; más de 10 a 15 días; sin marca personal; 100 % digital), cómo se investiga en qué países e idiomas lanzarlo, cómo se arma la escalera, cómo se modela bien la web (y el calco en otro idioma), cómo se crean los 9 anuncios por nivel de conciencia, el píxel por producto y por país, Hotmart, la campaña y cuándo y con qué reemplazar cada anuncio.
2. **`conocimiento/matias/IDIOMAS_PARA_ESCALAR.md`**: los más de 25 idiomas en los que se puede vender un producto que ya funciona.
3. **`CLAUDE.md`, Regla 0**: cómo trabaja el sistema (automático, lo importante se guarda, lo viejo se reemplaza).
4. **`conocimiento/matias/`**: de dónde sale cada regla.
   - `notas/2026-10-26_novedades_del_metodo.md`: lo último, con fuente por punto.
   - `13_receta_orquestador_metodo_consultor.md`: la receta del director con subagentes.
   - `cerebro/`: sus notas (modelado, elegir ofertas, lecciones, estrategia de anuncios, tipos de anuncios y placas, estilo, Utmify, calco por idioma, desarmes de landings).
   - `memoria/`: las reglas de trabajo que le dejó a Claude, con fecha y cita.
   - `skills/`: sus 35 skills (lista y origen en `skills/FUENTES.md`).

## Kit del kit de skills (nuevo, 11/11/2026)

Matías sumó para la comunidad todo el kit de la mentoría **el kit de skills**: 39 skills, 10 comandos, sus herramientas y su conocimiento (fábrica de creativos, landings y ofertas). Está en **`kit-skills/`** y **se instala solo** cuando tu Hyperflujo se actualiza (al abrir Claude Code o con `/actualizar`): deja las skills en `~/.claude/skills`, los comandos en `~/.claude/commands`, las herramientas en `~/herramientas` y el cerebro del kit en `~/cerebro`. No borra nada tuyo: si algo ya existía distinto, queda una copia `.respaldo` al lado. Para instalarlo a mano: `python kit-skills/instalar.py` (en Mac, `python3`).

- **Videos con IA:** `metodo-6c` (persona de IA que habla a cámara), `anunciante-supremo` y sus estilos `anuncio-ugc-a-camara`, `anuncio-claymation`, `anuncio-3d-explicador`, `anuncio-musical`, `anuncio-viral-macro`; `creativos`, `de-link-a-creativos`, `carga-creativos`, `jurado`, `programar-reels-organicos`.
- **Oferta y web:** `investigar-mercado`, `oferta-completa`, `pricing`, `postcompra`, `maqueta-landing`, `evaluar-landing`, `desarme-completo`, `lanzar-idioma`, `webs-que-se-entregan-solas`, `cobro-por-mercado`, `compliance-checker`.
- **Espionaje:** `espia-ofertas`, `cloaker-xray` (solo detecta, no hace cloaking), `quien-cobra-kit`, `voz-cliente`, `radar-sesiones`.
- **Clientes y tiendas:** `app-cliente`, `corregir-cliente`, `montar-landing-shopify`, `montar-impultienda`, `comprar-dominio`, `bot-de-escala`, `meta-ads`, `higgsfield-product-photoshoot`, `notebooklm-research`, `whisper-flow`, `skill-finder`.
- Comandos: `/aprende`, `/buscar`, `/capturar`, `/jardin`, `/landing-xray`, `/llamadas`, `/minar`, `/orden`, `/radar`, `/transcribir`.
- Las skills de video usan la llave de **APIMART** (en `~/herramientas/.env`, nunca en el chat).
- Es material privado de la comunidad: no se comparte fuera de ella.

## Cómo se arranca

1. Hacé un fork o clonalo, abrí Claude Code en la carpeta en modo «omitir permisos» y pegá el mensaje de `ARRANQUE.md`.
   - **En Mac:** el comando es `python3`, no `python`. Si la terminal dice `command not found: python3`, instalá Python desde python.org (3.10 o más nuevo). Tu Claude ya lo sabe y usa `python3` solo.
2. En el onboarding firmás **una sola vez** las autorizaciones para todas las ofertas; desde ahí el sistema no te pregunta más.
3. Para usar las skills de Matías también fuera del motor, copiá `conocimiento/matias/skills/*` a `~/.claude/skills/` (o subí cada carpeta como `.zip` en Claude → Configuración → Capacidades → Skills).
4. **Usalo a tu manera.** Decile a tu Claude cómo querés trabajar: automático o semiautomático, solo ciertas partes, tu presupuesto, WhatsApp o ManyChat, skills que querés sumar o no usar. Lo guarda solo y te queda para siempre, en cada chat nuevo y en cualquier carpeta de tu computadora. Para verlas o cambiarlas: `/preferencias`.
5. **El panel de tu hyperflujo.** Al abrir Claude en esta carpeta se abre al costado del chat: cada producto con su estado, lo gastado en Meta contra lo vendido en Hotmart (neto) y el ROAS, el freno, el plan del día y la actualización. Arriba del lugar donde escribís queda una línea con lo de hoy, y cada venta nueva te avisa. Si lo cerraste: `/panel`. Necesita la app de escritorio o Claude Code 2.1.286 o más nuevo; la primera vez, aceptá la confianza de la carpeta.
6. **Un asesor para decisiones difíciles.** Escribí `/advisor opus` y tu Claude le consulta a un modelo más fuerte antes de elegir un camino, cuando un error se repite y antes de dar algo por terminado. Los workers del director ya lo usan al producir y al revisar (`datos/config.local.json → advisor`). Cuenta para el uso de tu plan.
7. Para lanzar un producto que ya vende en otro idioma: calco de la web y `python herramientas/calco_idioma.py original.html nuevo.html --idioma <xx>`.

## Mapa de mercados (en qué idiomas y países lanzar)

Abrí **`conocimiento/matias/mapa-de-mercados.html`** con doble clic: se ve en tu navegador. Tiene los idiomas y países donde Matías ya vendió, con su retorno real (ROAS), cómo segmentar cada uno en Meta, qué excluir, las reglas para lanzar en cada idioma y un prompt listo para copiar en tu Hyperflujo. La versión en texto, para tu Claude: `conocimiento/matias/MAPA_DE_MERCADOS.md`.

## Qué hace el código con el método

- **Corte de campaña de Matías por defecto** (`datos/reglas_operacion.json → corte.modo = "matias"`): 48 h sin ventas → se apaga; con ventas, 5 días sin tocar; +30 % cada 48 h con ROAS ≥ 2.
- **Reemplazo de anuncios**: el que tiene costo por venta mayor al precio o gastó el precio sin vender, por una reserva del mismo nivel.
- **Píxel por producto y por país** (`datos/cuentas.local.json → meta.pixeles`), verificado en cada deploy. **Lo crea el agente solo** (`herramientas/pixel_nuevo.py`): por la API si hay token de Meta en `.env`, si no por el navegador. No tenés que crearlo vos.
- **El Profesor** (`.claude/agents/profesor-web.md`): un subagente muy exigente que corrige cada web contra las páginas modelo de Matías antes de mostrarla y publicarla. Pone nota y deja un boletín con las correcciones; sin su aprobado (9 o más) la web no se publica. Lo llama solo tu Claude: no tenés que hacer nada.
- **El Director de Videos** (`.claude/agents/director-videos.md`): igual de exigente, pero con los anuncios en video, placa y carrusel. Mira cuadro por cuadro y escucha la transcripción: que la voz no cambie ni se corte, que la boca coincida, que tenga música hasta el final, que no esté pixelado, que no falten dedos, que no haya imágenes que se traslucen, que el idioma y el mensaje estén bien y que se parezca al anuncio ganador que modela. Sin su aprobado (9 o más) el anuncio no se carga. Lo llama solo tu Claude. Para la transcripción usa `faster-whisper` (`pip install faster-whisper`; el modelo se baja solo la primera vez).
- **Botón** «Más información» en C1/C2 y «Ver detalles» en C3.
- **Opiniones**: solo reales, con la fuente de cada captura (marcadores `OPINIONES-REALES`); lo inventado frena el deploy.
- **Caza**: 30 o más anuncios activos y más de 10 días.

El kit de skills está completo en `kit-skills/`.
Las claves van siempre a tu `.env`, nunca al chat. Cada alumno usa sus propias cuentas (Meta, Hotmart, Netlify, Claude).

**¿Vas a usar Overmart?** Si en el onboarding elegís Overmart, no usás Netlify, ni Cloudflare, ni Hotmart: Overmart hace la landing, el checkout, el embudo y la entrega. Seguí la guía aparte **`docs/OVERMART.md`**.
Lista de lo que cambió en esta versión: `CAMBIOS_MATIAS_2026-10-26.md`.
