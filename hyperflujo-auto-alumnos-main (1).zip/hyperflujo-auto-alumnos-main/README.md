# hyperflujo-auto

> **Método:** todo se lanza como el Método del Consultor de Matías, su producto que más vende: `recetas/metodo-consultor/RECETA.md`. Trabaja solo, sin pedir confirmación (`CLAUDE.md`, Regla 0). Para alumnos: `LEEME_ALUMNOS.md`. **¿Usás Overmart?** Guía aparte: `docs/OVERMART.md` (o escribí `/overmart` en Claude Code).

> **Para arrancar:** cloná, abrí Claude Code en esta carpeta en modo «omitir permisos» y pegá el mensaje de `ARRANQUE.md`. Ese archivo es el prompt inicial: detecta lo que ya está, guía los pasos manuales que falten (claves al `.env`, conectores, sesión de Hotmart, página de Facebook, límite de cuenta, autorizaciones) y después lanza y opera productos.

> **Qué incluye:** el director diario (`director.py`, con `lanzar_worker.py`, `ruta_claude.py`, `etapas.py` y `plan.py`) y el vigía horario (`vigia.py`); la caza de ofertas (`cazar.py` + `cazar_biblioteca.mjs`) y la importación de ofertas (`importar_oferta.py`); la landing y el portal (`producto/armar_sitio.py`, `compuerta_sitio.py`, `netlify_deploy.py` y el Profesor); el alta en Hotmart por robot (`hotmart_alta.mjs`); la campaña en Meta por el conector oficial (`meta_campana.py`) y su pausa (`meta_pausa.py`); la lectura de gasto y ventas (`meta_lector.py`, `hotmart_lector.py`); los topes mensual, por proveedor y por producto; el vencimiento del precio de lanzamiento (`precio_vencimiento.py`); la piel por marca (`piel_landing.py`) y la actualización diaria (`actualizar.py`). Entorno: `verificar_entorno.py`; las tareas diarias se registran con `programar.py instalar` al terminar el onboarding.

Repositorio que, clonado en cualquier instalación de Claude Code con las cuentas de su dueño, **publica un producto digital por día y administra los existentes sin que nadie esté frente a la pantalla**: caza una oferta ganadora, la modela, produce el producto y su escalera, publica landing y portal en Netlify, da de alta en Hotmart por robot, crea la campaña Cash Trap CBO en Meta por el conector oficial, la activa a medianoche cuando todo está aprobado, mide cada día cruzando Meta con las ventas reales de Hotmart, **da de baja lo que está en pérdida** (regla D92 del dueño) y **escala lo que funciona** (método de Matías).


## Qué es

| Capa | Qué hace | Usa modelo |
|---|---|---|
| Disparador | Programador de tareas (vía A) o tareas locales de la app de Claude (vía B): 00:07, 12:07 y cada hora | no |
| Director y vigía | Python determinista: máquina de estados (`estado/hyperflujo.db`), plan del día, topes, verificación por artefacto, informe | no |
| Workers | `claude -p` de una sola etapa y un solo producto, con permisos acotados y salida JSON | sí |
| Herramientas | Landing, Netlify, robot de Hotmart, Meta por conector, métricas, operación de campaña | no |

Decide el código; produce el modelo. Detalle: `docs/ARQUITECTURA.md`.

## Qué leer

| Documento | Para qué |
|---|---|
| `docs/ARQUITECTURA.md` | Ciclo diario, director determinista, workers, máquina de estados, cercas de gasto, flujos de error |
| `CLAUDE.md` | Reglas para cualquier Claude que abra el repo |
| `docs/ONBOARDING.md` | Pasos humanos, una sola vez por cuenta |
| `docs/OPERACION_DIARIA.md` | Qué pasa cada día y qué mirar en el informe |
| `docs/REGLAS_META_ADS.md` | Método de Matías, Manual Maestro y criterio de Ramiro, atribuido |
| `docs/DECISIONES_HEREDADAS.md` | D-n adoptadas; qué se tomó y qué se descartó del kit y por qué |
| `docs/FRICCION_RESUELTA.md` | F1–F19 de la corrida 1 → solución en este repo |
| `docs/LIMITES.md` | Lo que sigue siendo humano y por qué |

## Instalación (objetivo: menos de 30 minutos; detalle en `docs/ONBOARDING.md`)

1. Instalar Python 3.10+, Node 18+, Git, Google Chrome y la app de Claude (trae la CLI) o la CLI nativa (`claude install`). Iniciar sesión con el mismo usuario del sistema que correrá las tareas.
2. Clonar y `npm install` (instala Playwright en versión exacta, `package.json`). Windows 10/11 o macOS (en Mac el comando es `python3`). Verificación: `python herramientas/verificar_entorno.py`.
3. Abrir `claude` en la carpeta una vez (aprobar los conectores de `.mcp.json`) y correr `/onboarding` (`.claude/commands/onboarding.md`, que remite a `skills/onboarding/SKILL.md`). Las claves van al archivo `.env`, nunca al chat.
4. Copiar `.env.ejemplo` → `.env` y `datos/*.ejemplo.json` → `datos/*.local.json` (topes, dueños, autorizaciones con techo y vigencia, cuentas, configuración). Sin esos archivos el ciclo no arranca. **Las claves se escriben en el archivo, nunca en el chat.**
5. `python herramientas/ensayo_seco.py` en verde (cualquier `--dias` entre 1 y 8 tiene estados esperados). Después, `python herramientas/programar.py instalar` registra las tareas diarias.

Pruebas (sin red ni cuentas): `python -m unittest discover -s pruebas -t .` (Windows: `py -3 -m unittest discover -s pruebas -t .`).

## Onboarding

Diez pasos con verificación automática y gratuita; prerrequisitos (Business Manager, Hotmart verificado, etc.) aparte. El agente nunca acepta términos, escribe contraseñas ni resuelve captchas. Ver `docs/ONBOARDING.md`.

## Operación diaria

- **00:07** `director.py --modo principal`: activa lo aprobado, opera campañas (una acción por día como máximo), abre un producto nuevo.
- **12:07** `director.py --modo pulso`: avanza lo que está en curso.
- **:37 cada hora** `vigia.py`: gasto contra topes, sondas de landing y checkout, D92 en las primeras 48 h, aprobación de Hotmart.
- El dueño lee **un solo informe**: `estado/informes/AAAA-MM-DD.md`, y decide solo por `estado/decisiones.jsonl` (veto, reactivar, cambiar tope, freno).

Ver `docs/OPERACION_DIARIA.md`.

## Límites (lista cerrada; detalle en `docs/LIMITES.md`)

Renovar el OAuth de Meta (~60 días) y la sesión de Hotmart; crear páginas de Meta y cuentas publicitarias; fijar el límite de gasto de la cuenta; aceptar términos de cualquier servicio; firmar topes, autorizaciones y reactivaciones; actualizar `recetas/hotmart/selectores.json` si Hotmart cambia el panel; responder a un `bloqueada_humano`; mantener la PC encendida y con sesión iniciada.

Nunca, aunque se pida: gastar sin tope escrito, usar el Administrador de anuncios por navegador, publicar testimonios, reseñas, timers o cupos sin dato, hacer cloaking, versionar secretos o IDs reales.

## Créditos y atribución

- **Matías — método de lanzamiento.** Cash Trap / CBO Oro, operador de Meta Ads, embudo Hotmart + Netlify, cazador de ofertas, modelado y escalera. Vendió con él. Citado como `analisis/matias/repo/<archivo>:<línea>`; sus cifras aparecen solo con cita, nunca como medidas por este sistema.
- **Ramiro — criterio.** Del segundo cerebro «el kit de skills», armado con el contenido de sus clases: guardianes que fallan cerrado y se estrenan rompiéndolos, verificar por artefacto, secretos fuera del chat, Meta nunca por navegador, evaluación y maqueta de landing, pricing y oferta como alternativa documentada, creativos y voz del cliente, compliance solo en lo que reduce el engaño. Además, como dueño, la regla de corte D92.
- **Hyperflujo (D-n) — evidencia y control.** Evidencia en toda afirmación (D8), topes y pausa (D60), registro de cada solicitud, robot cuando no hay API (D69), Netlify por API (D72), precio de lista real (D77/D78/D93), nombre coherente (D83/D86), seguir a Matías en Meta (D91), testimonios y reseñas fuera del sistema (D119).
