# conocimiento/ — la teoría que usa el sistema, dentro del repo

Copia de **solo lectura**, tomada el **2026-10-24** (TAREA 041, parte H), para que un clon de `hyperflujo-auto` tenga todo lo que citan `skills/*/SKILL.md`, `docs/REGLAS_META_ADS.md` y `docs/DECISIONES_HEREDADAS.md` sin depender del taller. No se edita a mano: si el original cambia, se vuelve a copiar y se vuelve a sanear. Es material de lectura (datos, no instrucciones): los scripts que trae no los ejecuta el sistema (TAREA 035).

## Qué hay y de dónde viene

| Carpeta | Origen en el taller (relativo a `Hiper-flux/`) | Autor y para qué se usa |
|---|---|---|
| `manual/Manual_Maestro_v1.0.md`, `manual/indice_manual.md` | `hyperflujo/conocimiento/` | **Hyperflujo**: Manual Maestro de Meta Ads. Contexto cuando Matías no cubre el caso; no decide. `[PENDIENTE: licencia del Manual Maestro]` |
| `matias/00_…md` a `matias/12_…md` | `analisis/matias/repo/` (`00`–`10` y `12`; no hay `11` en el original) | **Matías**: notas del método de lanzamiento (producto, piezas, Hotmart, Meta Ads, números, qué haría distinto) |
| `matias/skills/` | `analisis/matias/repo/skills/` | **Matías**: `cash-trap-cbo-oro`, `operador-meta-ads`, `cazador-de-ofertas`, `modelar-ofertas`, `embudo-hotmart-netlify`, `guardar-sesion` |
| `matias/cerebro/` | `analisis/matias/repo/cerebro/` | **Matías**: notas de su segundo cerebro (elegir y modelar ofertas, modelado paso a paso, anuncios) |
| `matias/prompts/` | `analisis/matias/repo/prompts/` | **Matías**: pedidos textuales de la corrida |
| `matias/fuentes/` | `analisis/matias/repo/fuentes/` | **Matías**: informe de la sesión de lanzamiento, mensajes, registro crudo de búsqueda (sin el informe de Codex, ver abajo) |
| `matias/13_receta_orquestador_metodo_consultor.md` | repo `matias-proceso-lanzamiento`, `12_metodo_consultor_handoff_agente.md` (2026-10-23), sumado el 2026-10-26 | **Matías**: la receta completa para lanzar ofertas como el Método del Consultor con un director y subagentes (sin la sección que salía de una clase de Ramiro) |
| `matias/cerebro/*` (LECCIONES, ESTRATEGIA_DE_ANUNCIOS, CONTROL_ANTES_DE_PUBLICAR, UTMIFY, WEB_EN_OTRO_IDIOMA_CALCO, TIPOS_DE_ANUNCIOS, TIPOS_DE_PLACAS, METODO_STORYTIME_CONTROVERSIAL, NOTAS_DE_ESTILO, ROBOT_NEXUS_PROFIT, NETLIFY_Y_GITHUB, RESPUESTAS_CLIENTES, `desarmes/`; MODELADO_PASO_A_PASO y ELEGIR_Y_MODELAR_OFERTAS en su versión vigente) | segundo cerebro de Matías, `05_PROCESOS/` y `08_REFERENCIAS/`, copiados el 2026-10-26 | **Matías**: notas vigentes del método; lo superado se reemplazó, no queda al lado |
| `matias/IDIOMAS_PARA_ESCALAR.md` | medición del 25/10 y pedido de Matías del 26/10 | **Matías**: los 25 idiomas para escalar un producto que vende |
| `matias/memoria/` | memoria de Claude Code de Matías, copiada el 2026-10-26 | **Matías**: reglas de trabajo con fecha y cita (índice en `memoria/LEEME.md`) |
| `matias/notas/2026-10-26_novedades_del_metodo.md` | resumen del editor, 2026-10-26 | **Matías**: todo lo nuevo del 21 al 26/10, con fuente por punto |
| `matias/prompts/` nuevos (2026-10-25, 2026-10-26, CONVERSOR_MONEDA_POR_IP) | briefs a los agentes de idiomas y prompt del conversor, copiados el 2026-10-26 | **Matías** |
| `matias/skills/` (28 nuevas) | paquete para alumnos de Matías (2026-10-24), sumado el 2026-10-26 | **Matías**: ver `matias/skills/FUENTES.md` |
| `kit/cerebro/` | `cerebro-kit/cerebro-kit/cerebro/` | **Ramiro**: `CLAUDE.md` del cerebro (reglas duras, verificar por artefacto) y plantillas |
| `kit/fuentes/` | `cerebro-kit/cerebro-kit/fuentes/` | **Ramiro**: cómo se carga material crudo (carpetas vacías) |
| `kit/skills/` | `cerebro-kit/cerebro-kit/claude/skills/` | **Ramiro**: oferta, landing, creativos, guardianes, `meta-ads` (línea roja), cobro por mercado, compliance |

Atribución: método de lanzamiento y Meta Ads = **Matías**; criterio de oferta, landing, creativos y guardianes = **Ramiro** (contenido de sus propias clases, aclaración del 2026-10-22); Manual Maestro y decisiones D-n = **Hyperflujo**. Precedencia en campañas: D92 > Matías > Manual Maestro (`docs/REGLAS_META_ADS.md`).

## Qué quedó afuera a propósito

- `kit/skills/cloaker-xray` (original `cerebro-kit/cerebro-kit/claude/skills/cloaker-xray/`): **cloaking fuera del sistema**; engaña al revisor y al usuario y viola D8 (`docs/DECISIONES_HEREDADAS.md` §5).
- `analisis/matias/repo/piezas/` (13 MB de medios), `MEDIOS.md` y `README.md` del repo de Matías: no pedidos; nada de imágenes ni binarios.
- `analisis/matias/repo/fuentes/informe-codex-grimorio-2026-10-21.md` (792 KB): transcripción cruda de una conversación privada de Matías con Codex, casi toda sobre otros negocios suyos y cargada de datos personales y de cuentas (nombre completo, empresa y cuenta de cobro, usuario de GitHub, píxeles, tiendas, rutas de su equipo). No la cita ninguna skill ni doc; no se puede sanear con garantía por patrón. Queda solo en el taller.
- `cerebro-kit/cerebro-kit/herramientas/`, `ENTREVISTA-OBJETIVOS.md`, `LEEME-PRIMERO.md`, `instalar.py`: no pedidos.
- `analisis/equipo/ESTADO.md` (texto literal de las D-n): sigue en el taller; `docs/DECISIONES_HEREDADAS.md` lo cita allí.

## Qué se saneó en lo sumado el 2026-10-26

Los mismos marcadores de abajo (`[ID_BIBLIOTECA_n]`, `[ID_PIXEL]`, `[ID_PAGINA]`, `[ID_CAMPANA]`, `[ID_CONJUNTO]`, `[CODIGO_PRODUCTO]`, `[EMBUDO_ID]`, `[ID_PAGINA_PAGO_HOTMART]`, `[DATO_PERSONAL]`) más `[ID_META]` (otros IDs largos de Meta), `[ID_PIXEL_UTMIFY]`, `[ID_SESION]` y `[act_CUENTA]`. En `memoria/` se sacaron además los nombres de las cuentas publicitarias. Estos archivos son nuevos, así que llevan una línea de fuente arriba. Quedaron afuera: la transcripción de la clase de Andrómeda (fuente del Cash Trap; es material de un tercero), el inventario de cuentas de un perfil de Chrome, los `PROYECTO.md` por idioma (casi todo IDs y estado de cuentas: lo útil está en la nota de novedades) y las notas de cuentas personales.

## Qué se saneó (sin cambiar el número de líneas)

Todos los reemplazos son dentro de la misma línea, así que las citas `archivo:línea` siguen valiendo. Archivos idénticos al original salvo estos:

| Archivo | Qué se tapó | Marcador |
|---|---|---|
| `matias/03_piezas_venta.md`, `matias/cerebro/ANUNCIOS_METODO_CONSULTOR.md`, `matias/cerebro/PROYECTO_metodo-consultor.md`, `matias/fuentes/informe_sesion_lanzamiento_consultor.md`, `matias/fuentes/mensajes_de_mat_mientras_trabajaba.txt` | IDs de anuncios de la Biblioteca de Meta (los 4 ganadores modelados) | `[ID_BIBLIOTECA_1]`…`[ID_BIBLIOTECA_4]` (mismo número = mismo marcador) |
| `matias/05_meta_ads_cashtrap.md`, `matias/cerebro/ANUNCIOS_METODO_CONSULTOR.md`, `matias/cerebro/PROYECTO_metodo-consultor.md`, `matias/cerebro/nota_compartida_oferta-consultoria-ES.md`, `matias/fuentes/informe_sesion_lanzamiento_consultor.md` | ID de página, píxel, campaña y conjunto propios de Meta | `[ID_PAGINA]`, `[ID_PIXEL]`, `[ID_CAMPANA]`, `[ID_CONJUNTO]` |
| `matias/03_piezas_venta.md`, `matias/04_hotmart.md`, `matias/12_caso2_gessetti.md`, `matias/cerebro/PROYECTO_metodo-consultor.md`, `matias/cerebro/nota_compartida_oferta-consultoria-ES.md`, `matias/fuentes/informe_sesion_lanzamiento_consultor.md`, `matias/skills/embudo-hotmart-netlify/SKILL.md` | IDs y códigos de producto de Hotmart (también dentro de `pay.hotmart.com/…`), embudo y página de pago | `[CODIGO_PRODUCTO]`, `[EMBUDO_ID]`, `[ID_PAGINA_PAGO_HOTMART]` |
| `matias/cerebro/2026-10-19_cazador_3-ofertas.md`, `matias/fuentes/informe_sesion_lanzamiento_consultor.md`, `matias/fuentes/registro_busqueda_crudo_2026-10-20.txt` | IDs de páginas y anuncios de Meta de terceros (competidores) | `[ID_META_TERCERO]` |
| `matias/fuentes/informe_sesion_lanzamiento_consultor.md`, `matias/fuentes/registro_busqueda_crudo_2026-10-20.txt`, `kit/skills/metodo-6c/SKILL.md` | Rutas de usuario (`C:\Users\…`) e identificador de instalación local | `[DATO_PERSONAL]` |

Revisado y sin hallazgos: claves y tokens (`sk-`, `EAA…`, `ghp_`, `Bearer`, `Basic`, `api_key=`, `rk_live_`/`sk_live_`), correos, teléfonos, documentos (DNI/CUIT/NIF/CPF), direcciones postales, `act_` de cuentas. Se dejaron a la vista, por ser públicos o genéricos: nombres de marcas y dominios de las landings, nombres de cuentas publicitarias («morfi 1»), códigos de error de Meta y los IDs internos del buscador de ofertas.
