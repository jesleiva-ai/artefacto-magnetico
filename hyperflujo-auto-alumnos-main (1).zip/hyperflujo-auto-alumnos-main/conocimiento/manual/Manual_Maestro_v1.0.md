**MANUAL MAESTRO**  
**DE META ADS**

**\*En la actualidad el método cash trap es el que prolifera\***

Sistema operativo del mentor

Testing · Escalado · Estructuras CBO · Cost Cap · Bid Cap · Recuperación · Audiencias · Cash Trap · Mercados · Métricas · Diagnóstico

VERSIÓN 1.0  |  Fuente de trabajo: 16 transcripciones completas

# **Cómo usar este manual**

Este documento no es un resumen cronológico clase por clase. Está reorganizado como un sistema de decisión para que pueda usarse como referencia operativa al analizar campañas reales. Su objetivo es responder preguntas del tipo: qué estructura corresponde, cuánto tiempo esperar, qué métrica revisar, cuándo escalar, cuándo bajar presupuesto, cuándo reemplazar un anuncio y cuándo el curso no da una regla suficiente.

| \[FUENTE DE VERDAD\] La fuente primaria son las 16 transcripciones completas extraídas del curso. Este manual sintetiza, ordena y conecta esas enseñanzas, pero no reemplaza el backup literal. Cuando una frase del subtítulo es ambigua o contradictoria, se marca expresamente en lugar de inventar una corrección. |
| :---- |

| \[MENTOR DICE\] Regla, recomendación, ejemplo o procedimiento que aparece de forma explícita en las clases. No significa que sea una regla oficial de Meta: significa que forma parte del método enseñado en el curso. |
| :---- |

| \[INTERPRETACIÓN OPERATIVA\] Traducción de varias enseñanzas del curso a una regla práctica o flujo de decisión. Sirve para operar, pero se diferencia de una frase textual del mentor. |
| :---- |

| \[NO DEFINIDO / AMBIGUO\] El curso no da un umbral exacto, la transcripción es ambigua o hay instrucciones que dependen del contexto. En esos casos este manual no inventa una cifra. |
| :---- |

## **Instrucción recomendada para usarlo en otro chat**

Subí este archivo y escribí algo como: “Usá este Manual Maestro como fuente principal para analizar mi campaña. Separá lo que el mentor indica de tus propias inferencias. Si el manual no define una decisión, decímelo expresamente y no inventes una regla del mentor.”

## **Mapa de las 16 clases**

| Clase | Tema | Rol dentro del sistema |
| :---- | :---- | :---- |
| 1 | ABO normal | Configuración base, testeo individual, 48–72 h, diversidad creativa, regla 70/30. |
| 2 | Microtesting | Muchos creativos, micropresupuesto, 24 h, ganadores y CPC como señal secundaria. |
| 3 | Superposición \+ CBO 1-1-1 | No repetir el mismo anuncio en varias campañas; primera estructura de escala. |
| 4 | Pocket | Reducida, común y ampliada; lectura a nivel campaña. |
| 5 | CBO Mix / Power | Varios ganadores por conjunto, más presupuesto, concentración de ganadores. |
| 6 | CBO Gold | Un conjunto con varios ganadores; simplicidad y paciencia 48–72 h. |
| 7 | Cost Cap | Puja manual por objetivo de costo; testeo de bids; surfing. |
| 8 | Bid Cap | Límite máximo de puja; anuncios ganadores; estabilidad de costos. |
| 9 | Metodología de escala | Escala gradual, agresiva, surfing y tirón de oreja. |
| 10 | Historial de ventas | Días, horarios y países para decidir cuándo escalar/testear. |
| 11 | Campañas agresivas | Paso a estructuras más masivas cuando los ángulos ya están validados. |
| 12 | Salvar una campaña | Reemplazo correcto de anuncios sin perder historial. |
| 13 | Públicos y audiencias | Exclusiones, lookalike de compradores y audiencia guardada. |
| 14 | Cash Trap | Una sola campaña evergreen, creatividad diversa, mantenimiento periódico. |
| 15 | Mercados internacionales | Múltiples idiomas/mercados, separación de activos y pricing. |
| 16 | Métricas y diagnóstico | ROAS, AOV, hook, CTR, CPC, calidad de clic, conversión y fórmulas. |

# **1\. Mapa general del sistema**

El curso propone un recorrido que puede leerse como una progresión: primero se valida creatividad y ángulo; luego se concentra presupuesto en estructuras de escala; después se estabiliza o se escala con mayor agresividad; y, cuando una campaña o un anuncio se desgasta, se aplican procedimientos de recuperación antes de descartarlos.

| \[INTERPRETACIÓN OPERATIVA\] No todas las estructuras deben ejecutarse a la vez. El propio curso repite que distintas cuentas responden mejor a estructuras distintas. La función del sistema es identificar qué etapa estás atravesando y elegir una estructura coherente con esa etapa. |
| :---- |

## **1.1 Flujo maestro**

1. TESTEAR: validar ángulos y creativos con ABO normal o Microtesting.  
2. IDENTIFICAR GANADORES: anuncios que venden; en microtesting, si no hay ventas, conservar temporalmente 2–4 anuncios con CPC más bajo.  
3. ESCALAR: pasar ganadores a CBO 1-1-1, Pocket, Mix, Power o Gold según el nivel y la cantidad de ganadores.  
4. ESTABILIZAR / EMPUJAR: aplicar escala gradual, agresiva o surfing cuando la campaña ya vende.  
5. CONTROLAR RENTABILIDAD: seguir ROAS, CPA/costo por resultado, AOV y conversión.  
6. RECUPERAR: si una campaña con historial se deteriora, intentar reemplazar anuncios antes de apagar la campaña.  
7. AMPLIAR PÚBLICO: exclusión de interactuadores, lookalike de compradores o audiencias guardadas cuando corresponda.  
8. CONSOLIDAR: usar Cash Trap como metodología evergreen de una sola campaña si ese enfoque se adapta al negocio.  
9. EXPANDIR MERCADOS: traducir y separar infraestructura por idioma/mercado.  
10. DIAGNOSTICAR SIEMPRE: usar el árbol de métricas para distinguir problema de creativo, tráfico, página, checkout o rentabilidad.

**Fuente del curso:** Clase 1, Clase 2, Clase 3, Clase 4, Clase 5, Clase 6, Clase 9, Clase 12, Clase 13, Clase 14, Clase 15, Clase 16

## **1.2 Arquitectura de cuentas publicitarias que enseña el mentor**

En las clases de escala el mentor recomienda no acumular demasiadas campañas en una misma cuenta publicitaria. Repite como referencia 1–3 campañas, y propone separar testing, escala y campañas manuales en cuentas distintas cuando sea posible. En Cash Trap es todavía más estricto: una sola campaña por cuenta publicitaria.

| Función | Organización sugerida por el mentor | Fuente |
| :---- | :---- | :---- |
| Testing | Cuenta publicitaria dedicada a ABO/microtesting. | Clases 3 y 5 |
| Escala automática | Otra cuenta para Pocket, Mix, Power, Gold, 1-1-1. | Clases 3–5 |
| Campañas manuales | Otra cuenta para Cost Cap / Bid Cap / ROAS Cap. | Clases 3, 7, 8 |
| Cash Trap | Una sola campaña en esa cuenta; no sumar otras campañas. | Clase 14 |
| Idiomas | Cada idioma con su propia cuenta publicitaria y pixel. | Clase 15 |

| \[NO DEFINIDO / AMBIGUO\] La separación por cuentas se presenta como metodología del mentor. El curso no desarrolla límites técnicos oficiales de Meta ni compara formalmente esta arquitectura con alternativas. |
| :---- |

# **2\. Testing: validar antes de escalar**

## **2.1 ABO normal**

La estructura base de la Clase 1 es una campaña ABO donde cada conjunto contiene un solo anuncio. El objetivo es que cada creativo reciba presupuesto propio y pueda evaluarse de manera individual antes de pasar a una estructura de escala.

| Elemento | Regla del curso |
| :---- | :---- |
| Estructura | 1 conjunto \= 1 anuncio. |
| Presupuesto | Mínimo aproximado de USD 10/día por conjunto para productos de USD 10–25 en el ejemplo. |
| Duración | 48–72 horas. |
| Día 3 | Solo se justifica si ya hubo 1–2 ventas o señales que ameriten darle un día adicional. |
| Evento | Compra. |
| Audiencia | Abierta/Advantage en la explicación del curso. |
| Ubicaciones | El mentor expresa preferencia por móvil y Facebook \+ Instagram. |
| Análisis | CTR, CPM, conversión de la web y ventas. |
| Frecuencia de nuevos testeos | No todos los días; el mentor habla de cada 3–6 días aproximadamente para no consumir la ganancia. |

| \[MENTOR DICE\] La campaña de testeo se deja correr dos días; si empieza a vender puede llegar a tres. Lo que vende se conserva. Lo que no vende se descarta. |
| :---- |

**Fuente del curso:** Clase 1

## **2.2 Microtesting**

Microtesting mantiene la lógica ABO de un anuncio por conjunto, pero reduce el presupuesto y aumenta mucho el volumen de creativos. La decisión se toma con mayor velocidad: 24 horas.

| Precio del producto (ejemplos del curso) | Presupuesto por conjunto/día |
| :---- | :---- |
| USD 10–15 | USD 3.50 |
| USD 20–25 | USD 5–6 |
| USD 50–60 | USD 10 |

* Duración inicial: 24 horas.  
* Apagar lo que no vendió y conservar lo que sí vendió.  
* Duplicar conjuntos y reemplazar el creativo para seguir alimentando la misma campaña.  
* El mentor menciona la posibilidad de testear 20, 30, 40 o 50 creativos por día con micropresupuesto.  
* Si ningún anuncio vende, conservar temporalmente solo 2–4 con CPC más barato y reemplazar el resto.

**Fuente del curso:** Clase 2

## **2.3 Regla 70/30 y explotación de ángulos**

Una vez identificado un ángulo ganador, el curso propone concentrar la mayor parte del esfuerzo creativo en ese ángulo y reservar una parte menor para explorar nuevos dolores o enfoques.

| Distribución | Uso |
| :---- | :---- |
| 70% | Variaciones de lo que ya funciona. |
| 30% | Ángulos nuevos para descubrir nuevos dolores o segmentos. |

Tres variaciones concretas sugeridas en Microtesting:

* Mismo audio ganador \+ video nuevo.  
* Mismo video ganador \+ audio nuevo.  
* Mismo cuerpo de video \+ nuevo gancho en los primeros \~5 segundos.

**Fuente del curso:** Clase 1, Clase 2

## **2.4 Qué significa 'ganador' dentro del curso**

El término se usa de forma contextual. En ABO/Pocket se mencionan anuncios con ventas —por ejemplo 3–4 ventas antes de enviarlos a Pocket—. En Microtesting, una venta con micropresupuesto es una señal fuerte; si no hay ventas, el CPC bajo sirve como criterio secundario para decidir qué creativos merecen seguir.

| \[NO DEFINIDO / AMBIGUO\] El curso no fija un único número universal de ventas, gasto o ROAS que convierta automáticamente un anuncio en ganador para todos los productos. Por eso, este manual no debe convertir 'ganador' en un umbral rígido fuera de los ejemplos que sí aparecen. |
| :---- |

# **3\. Superposición en subasta y reutilización de anuncios**

La Clase 3 introduce una regla central del método: no repetir exactamente el mismo anuncio en múltiples campañas de escala. El mentor sostiene que Meta priorizará la campaña con más presupuesto para evitar que el mismo anuncio compita consigo mismo.

| \[MENTOR DICE\] Si un anuncio se pasa a una Pocket, dejarlo allí. Si se arma otra estructura —por ejemplo Cost Cap o Bid Cap— usar otras variaciones creativas del ganador en lugar del mismo anuncio exacto. |
| :---- |

## **3.1 Regla operativa**

* Un anuncio exacto \-\> una campaña de escala.  
* Para abrir otra estructura \-\> usar una variación creativa, no el mismo anuncio idéntico.  
* El Post ID se usa para trasladar el ganador a CBO 1-1-1 en el ejemplo del curso.  
* Separar cuenta de testing, cuenta de escala y cuenta de campañas manuales es la arquitectura preferida del mentor.

**Fuente del curso:** Clase 3, Clase 11

| \[ACLARACIÓN DE FUENTE\] La explicación sobre cómo Meta resuelve la superposición es una afirmación del mentor. Este manual la preserva como parte del método y no la presenta como documentación oficial verificada de Meta. |
| :---- |

# **4\. Estructuras de escala automáticas**

## **4.1 CBO 1-1-1**

| Variable | Configuración enseñada |
| :---- | :---- |
| Campaña | CBO. |
| Conjuntos | 1\. |
| Anuncios | 1 ganador. |
| Presupuesto inicial de ejemplo | USD 35 para productos de \~USD 15–30. |
| Tiempo mínimo | 2 días sin tocar. |
| Entrada | Anuncio ganador, usando Post ID en la demostración. |

Es la transición más simple desde testing hacia escala. Su valor dentro del curso es aislar un ganador en una campaña con presupuesto de campaña y darle tiempo para traccionar.

**Fuente del curso:** Clase 3

## **4.2 Pocket**

| Variante | Cantidad de conjuntos | Contenido de cada conjunto |
| :---- | :---- | :---- |
| Pocket reducida | 3 | El mismo anuncio ganador. |
| Pocket común | 5 | El mismo anuncio ganador. |
| Pocket ampliada | 7–8 | El mismo anuncio ganador. |

La Pocket se analiza a nivel campaña. El mentor advierte contra apagar conjuntos solo porque gastan poco o no venden: en CBO el presupuesto no se distribuye de forma uniforme.

* Inicio sugerido: USD 35; USD 50 si se quiere ser más agresivo.  
* Esperar 48 horas; si hay buenas señales, puede extenderse a 72 horas.  
* Solo considerar apagar un conjunto si consume mucho presupuesto sin vender mientras otros sí venden.  
* Usar el mejor anuncio; la clase menciona como referencia un ganador con 3–4 ventas.  
* Máximo orientativo del mentor: 2–3 campañas por cuenta publicitaria.

**Fuente del curso:** Clase 4

## **4.3 CBO Mix / Deep Pocket y CBO Power**

Estas estructuras evolucionan la lógica Pocket: en vez de un solo creativo ganador repetido, cada conjunto contiene varias creatividades ganadoras diferentes y el conjunto se duplica varias veces.

| Variable | Regla del curso |
| :---- | :---- |
| Ganadores por conjunto | 3–5 creativos diferentes. |
| Duplicación | Duplicar el conjunto unas 4–5 veces. |
| Presupuesto | La clase menciona USD 50–75 y luego recomienda USD 75–135; USD 100 aparece como buen número. |
| Espera | 48–72 horas. |
| Lectura | A nivel campaña. |
| Uso | Escala cuando ya existen varias creatividades ganadoras. |

| \[NO DEFINIDO / AMBIGUO\] La transcripción no deja una diferencia formal y perfectamente delimitada entre Mix y Power más allá de la cantidad de anuncios/volumen. No conviene inventar una configuración exacta adicional si la clase no la especifica. |
| :---- |

**Fuente del curso:** Clase 5

## **4.4 CBO Gold**

CBO Gold concentra varios anuncios ganadores en un solo conjunto. Es una de las estructuras que el mentor más recomienda por simplicidad y diversidad creativa.

| Variable | Regla del curso |
| :---- | :---- |
| Conjuntos | 1\. |
| Anuncios | Mínimo 3; ejemplos con 5, 7 o más. |
| Presupuesto | Relacionarlo con cantidad de anuncios y precio del producto. |
| Ejemplo | Producto USD 10 \+ 5 anuncios \-\> alrededor de USD 50\. |
| Espera | 48–72 horas antes de juzgar. |
| Comportamiento | Puede empezar a traccionar con más fuerza en días 3–5. |

**Fuente del curso:** Clase 6

## **4.5 Matriz de elección entre estructuras**

| Situación | Estructura que aparece en el curso | Lectura operativa |
| :---- | :---- | :---- |
| Un ganador recién validado | CBO 1-1-1 | Entrada simple a escala. |
| Un ganador fuerte \+ microsegmentaciones | Pocket | Duplicar conjuntos manteniendo el mismo ganador. |
| Varios ganadores | Mix / Power | Concentrar varias creatividades por conjunto y duplicar. |
| Varios ganadores \+ simplicidad | CBO Gold | Un conjunto con todos los ganadores. |
| Ángulos ya muy conocidos / etapa avanzada | Gold, Mix, Power, Pocket o CBO común | El mentor propone dejar atrás el 1-1-1 como forma predominante de testing y salir con más presupuesto. |

| \[INTERPRETACIÓN OPERATIVA\] El curso no define una 'mejor' estructura universal. Repite que hay cuentas en las que una estructura funciona mejor que otra. La elección debe tratarse como una prueba del propio ad account, no como una jerarquía fija. |
| :---- |

**Fuente del curso:** Clase 3, Clase 4, Clase 5, Clase 6, Clase 11

# **5\. Campañas manuales: Cost Cap y Bid Cap**

Las Clases 7 y 8 presentan campañas manuales como herramientas para controlar el costo, más que como el primer mecanismo de testing. El requisito repetido es trabajar con anuncios que ya demostraron capacidad de vender.

## **5.1 Cost Cap**

El mentor parte del costo promedio de compra de la cuenta y prueba varios objetivos de costo por resultado en ABO para descubrir un bid/objetivo que Meta pueda ejecutar con rentabilidad.

11. Tomar como referencia el CPA/costo por compra que ya existe en la cuenta.  
12. Crear una campaña ABO con el mismo anuncio ganador en distintos conjuntos.  
13. Asignar a cada conjunto un objetivo de costo diferente (ejemplo de la clase: USD 9, 10, 11, 12).  
14. Observar qué objetivo consigue ventas y profit.  
15. Usar ese objetivo en una estructura CBO Cost Cap con varios anuncios ganadores.  
16. Cuando una venta entra a buen costo y el ROAS es \>=2 en el ejemplo, el mentor duplica presupuesto durante el surfing.

| Elemento | Referencia del curso |
| :---- | :---- |
| Presupuesto ABO de prueba | Puede ser USD 100–150; Meta no necesariamente lo gasta completo. |
| CBO Cost Cap / Gold Cost Cap | Ejemplos de arranque USD 250–500; también se mencionan 300, 500, 1000\. |
| Creativos | Mínimo aproximado 4–10 ganadores en estructuras de escala manual. |
| Fin del día | Bajar presupuesto después del surfing. |
| Cuando 'muere' | Duplicar y, en el método mostrado, quitar los anuncios que ya vendieron para forzar gasto en ganadores que no consumieron. |

**Fuente del curso:** Clase 7

## **5.2 Bid Cap**

Bid Cap fija un límite máximo de puja en subasta. El mentor contrasta esto con Cost Cap, donde el costo real puede moverse alrededor del objetivo.

* Usar anuncios probados; no es la estructura que el mentor propone para testear creativos nuevos.  
* Mínimo de referencia: 4–10 anuncios ganadores.  
* Comenzar el límite de puja cerca del precio del producto.  
* Ejemplo: producto de USD 20 \-\> Bid Cap de USD 20; luego se puede probar USD 15 o USD 10 si la cuenta ya es estable.  
* Presupuesto puede escalarse agresivamente durante el día cuando aparecen ventas a buen costo.  
* Al final del día, bajar el presupuesto.  
* Cuando la campaña deja de funcionar, el mentor duplica y deja activos anuncios ganadores que no habían gastado/vendido para forzar distribución.

**Fuente del curso:** Clase 8

## **5.3 Diferencia funcional dentro del método**

| Cost Cap | Bid Cap |
| :---- | :---- |
| Define un objetivo de costo por resultado. | Define el máximo que se quiere pujar en la subasta. |
| El costo real puede quedar por encima o por debajo del objetivo. | Según la explicación del mentor, no se puja por encima del límite configurado. |
| Primero se testean distintos objetivos de costo. | El mentor sugiere empezar con el precio del producto como límite. |
| Busca estabilidad alrededor de un costo promedio. | Busca controlar el techo de puja. |

# **6\. Metodología de escalado**

## **6.1 Escala gradual**

* En ABO: después de más de 3 ventas, subir aproximadamente 20–30%.  
* Esperar 48–72 horas entre incrementos cuando se escala de forma tranquila.  
* Referencia de rentabilidad usada en la clase: ROAS alrededor de 1.8–2 para incrementos moderados.  
* Una sola venta puede ser casualidad; el mentor espera más confirmación antes de tocar presupuesto.

**Fuente del curso:** Clase 9

## **6.2 Escala agresiva en CBO**

Después de dejar una CBO automática al menos 48 horas, el mentor permite incrementos mucho más fuertes si el ROAS es alto. En la clase aparecen ejemplos de duplicar o triplicar presupuesto con ROAS 2–3.

| Señal | Acción enseñada |
| :---- | :---- |
| ROAS 2–3 después del período inicial | Probar duplicar o triplicar presupuesto. |
| ROAS \~1.7–1.9 | Subir aproximadamente 30% y reevaluar. |
| CPA llegando al precio/break-even | Bajar presupuesto 20–30%: 'tirón de oreja'. |
| Después del tirón | Esperar \~2 días; si no se recupera, apagar. |

**Fuente del curso:** Clase 9

## **6.3 Surfing**

Surfing es la versión más agresiva: aumentar presupuesto varias veces durante un día fuerte a medida que siguen entrando ventas rentables.

Ejemplo explícito de progresión mencionado en la clase: USD 35 \-\> 70 \-\> 150 \-\> 300 \-\> 1000 \-\> 2000 \-\> 4000\. No es una tabla universal; es un ejemplo del mentor para ilustrar la lógica.

| \[MENTOR DICE\] Al final del día se baja el presupuesto, pero no necesariamente al punto de partida. Ejemplo: si comenzó en 50 y terminó en 4000, podría bajarse a 200 para el siguiente ciclo. |
| :---- |

**Fuente del curso:** Clase 9

## **6.4 'Pixel optimizado' según la terminología del curso**

El mentor insiste en lograr al menos 50 ventas por semana y preferentemente 100 o más para mantener el pixel 'optimizado' y sostener escalas/surfing. Esta cifra se usa repetidamente como marco de su metodología.

| \[ACLARACIÓN DE FUENTE\] Este manual conserva la expresión y el umbral tal como se enseñan en el curso. No los presenta como una especificación técnica oficial de Meta. |
| :---- |

**Fuente del curso:** Clase 9, Clase 10, Clase 14

## **6.5 Historial de ventas: cuándo escalar y cuándo no tocar**

Después de aproximadamente dos semanas de ventas, la Clase 10 propone descargar el historial del ecommerce y analizar patrones de día, hora y país.

| Patrón | Uso operativo según la clase |
| :---- | :---- |
| Días débiles | No testear, no escalar, no tomar decisiones innecesarias. |
| Días buenos | Lanzar testeos y escalar. |
| Días más fuertes | Aplicar surfing. |
| Horas pico | Concentrar los incrementos de presupuesto en ese bloque. |
| Países con más ventas | Crear campañas de escala enfocadas en esos países. |

En el ejemplo de la clase, jueves aparece como el peor día y lunes/martes/viernes/domingo como días más fuertes; el bloque horario de mayor actividad se sitúa aproximadamente entre 13:00 y 20:00/21:00. Estos son datos de la cuenta de ejemplo, no reglas universales.

| \[INTERPRETACIÓN OPERATIVA\] La regla transferible no es 'escalar los martes'. La regla es: usar TU historial para identificar tus propios días y horas fuertes antes de definir la ventana de testeo o surfing. |
| :---- |

**Fuente del curso:** Clase 10

# **7\. Etapa avanzada: campañas agresivas**

La Clase 11 describe el cambio de enfoque cuando ya se conocen los ángulos y variaciones que venden. En esa etapa, el mentor deja de priorizar el testeo 1-1-1 y propone salir directamente con estructuras más grandes y mayor concentración de presupuesto.

* ABO Gold: varios anuncios dentro de cada conjunto, con presupuestos mayores y 2–3 días de testeo.  
* Pocket, Mix, Power, Gold o CBO común pueden utilizarse directamente con ángulos ya validados.  
* Ejemplos de arranque: USD 75–135 para algunas estructuras; USD 50–100 para otras.  
* Concentrar presupuesto en un conjunto con diversidad creativa se presenta como alineado con la lógica de Andromeda descrita por el mentor.  
* No repetir el mismo anuncio exacto en varias campañas; usar variaciones.

| \[MENTOR DICE\] Cuando ya sabés qué ángulos venden, la recomendación es usar la estructura que mejor responde en tu cuenta: Pocket, Mix, Power, Gold, CBO común, etc. |
| :---- |

**Fuente del curso:** Clase 11

# **8\. Recuperar una campaña que dejó de vender**

La Clase 12 es una pieza clave del sistema. El mentor parte de la idea de que una campaña con historial puede seguir siendo valiosa aunque los anuncios se hayan agotado. Por eso, antes de apagar una campaña que vendió bien durante tiempo, intenta reemplazar creativos manteniendo la estructura.

## **8.1 Cuándo aplica**

* La campaña tiene historial y vendió bien durante un período.  
* Comenzó a deteriorarse.  
* Ya recibió un 'tirón de oreja' o ajustes y no recuperó.  
* El problema parece estar en los anuncios, no en que la campaña jamás haya validado.

## **8.2 Procedimiento exacto**

17. NO apagar la campaña completa.  
18. Identificar los anuncios que se van a reemplazar.  
19. Duplicar el anuncio viejo.  
20. En el duplicado, reemplazar el creativo por un nuevo anuncio ganador.  
21. Publicar el duplicado nuevo.  
22. Recién después, apagar el anuncio viejo.  
23. Mantener la misma cantidad de anuncios/conjuntos que tenía la estructura.  
24. Si se reemplazan varios, el mentor sugiere reemplazarlos en la misma intervención.  
25. Esperar 48–72 horas para evaluar recuperación.

| \[MENTOR DICE\] No editar el creativo del anuncio viejo directamente. Duplicarlo, reemplazar en el duplicado, publicar y luego apagar el viejo. |
| :---- |

**Fuente del curso:** Clase 12

## **8.3 Aplicación por estructura**

| Estructura | Cómo conservarla |
| :---- | :---- |
| Pocket | Si tiene 3/5/7–8 conjuntos, reemplazar los anuncios correspondientes sin alterar la arquitectura. |
| Power | Si tiene 5 anuncios, reemplazar 5 por 5 nuevos. |
| Mix | Mantener la misma cantidad de anuncios que tenía la campaña. |
| Gold | Duplicar/reemplazar los anuncios deteriorados sin destruir el historial de campaña. |

# **9\. Públicos y audiencias**

## **9.1 Revivir un anuncio mostrándolo a gente nueva**

El primer enfoque de la Clase 13 crea una audiencia personalizada de personas que interactuaron con publicaciones o anuncios en Facebook/Instagram y luego la EXCLUYE de una campaña nueva.

26. Crear audiencia personalizada de interacción con publicaciones/anuncios.  
27. Crear nueva campaña con el anuncio ganador que se agotó.  
28. Excluir esa audiencia personalizada.  
29. Dejar que Meta busque personas que todavía no interactuaron con la marca.

**Fuente del curso:** Clase 13

## **9.2 Lookalike de compradores**

* Crear audiencia personalizada de compradores.  
* Crear audiencia similar/lookalike.  
* El mentor recomienda comenzar con 1%.  
* Usarla como sugerencia, NO como exclusión.  
* La clase señala que puede ser algo más cara pero busca una audiencia más calificada.

| \[ACLARACIÓN DE FUENTE\] La afirmación de que porcentajes mayores son 'menos exquisitos' o más caros pertenece a la explicación del mentor. Se conserva como enseñanza del curso. |
| :---- |

**Fuente del curso:** Clase 13

## **9.3 Guardar audiencia de una campaña rentable**

Si una campaña o conjunto acumula ventas a buen costo, el mentor propone guardar esa audiencia y usarla como sugerencia en nuevas campañas de escala. La campaña sigue siendo Advantage/abierta, pero no arranca completamente desde cero según la lógica del curso.

**Fuente del curso:** Clase 13

# **10\. Método Cash Trap**

Cash Trap se presenta como una metodología diferente: menos intervención, una sola campaña evergreen y diversidad creativa. El mentor la relaciona con un negocio 'lifestyle boutique' que no requiere estar todo el día en Ads Manager.

## **10.1 Estructura**

| Variable | Configuración |
| :---- | :---- |
| Campañas por cuenta | 1 sola. |
| Tipo | CBO Gold / Cash Trap. |
| Conjuntos | 1\. |
| Audiencia | Advantage / abierta. |
| Anuncios iniciales | Mínimo 5, máximo 7\. |
| Creatividad | Diversidad de formatos: carrusel, estático/placa, 1:1, horizontal 16:9, Reel 9:16, etc. |
| Objetivo | Ventas evergreen con menos intervención y sin surfing continuo. |

**Fuente del curso:** Clase 14

## **10.2 Tiempo y decisiones**

30. Dejar correr 48 horas sin tomar decisiones.  
31. Revisar en el día 3\.  
32. Si está vendiendo, dejarla llegar aproximadamente al día 5 antes de intervenir.  
33. Alrededor del día 5–6, si continúa vendiendo, comenzar a escalar.  
34. Si ROAS \>2, el mentor habla de subidas de 30–40% e incluso 50%; de lo contrario, aproximadamente 20% cada 2–3 días.  
35. El mentor indica subir presupuesto a medianoche.  
36. No subir presupuesto y reemplazar anuncios en la misma intervención.  
37. Después de reemplazar creativos, esperar 2–3 días.  
38. Si la campaña se rompe, aplicar tirón de oreja y dejar estabilizar 2–3 días.

**Fuente del curso:** Clase 14

## **10.3 Gestión de anuncios dentro de Cash Trap**

* Reemplazar anuncios que gastan y no venden, o venden demasiado caro.  
* No apagar por ansiedad un anuncio que acaba de conseguir su primera venta cara: darle aproximadamente 3 días en el ejemplo.  
* Anuncios que no gastan pueden dejarse; el mentor dice que algunos comienzan a gastar después de 2–3 semanas.  
* Si pasa aproximadamente un mes sin gasto, considerar reemplazo.  
* Cuando la campaña alcanza presupuestos altos (\~USD 300–400 en el ejemplo) y está estable, se pueden agregar 2 anuncios nuevos.  
* Después de sumar anuncios, dejar 5–7 días sin tocar para que se estabilice.

**Fuente del curso:** Clase 14

## **10.4 Presupuesto inicial: punto ambiguo de la transcripción**

| \[NO DEFINIDO / AMBIGUO\] La frase exacta del presupuesto inicial de Cash Trap quedó dañada en el subtítulo: aparece algo como '350... por lo menos ya 100 dólares'. Por fidelidad, este manual NO fija una cifra inicial única. Sí quedan claros los demás parámetros: 5–7 anuncios, 48 h sin tocar y escalado posterior si vende. |
| :---- |

# **11\. Mercados internacionales y múltiples idiomas**

La Clase 15 recomienda expandir un producto probado a múltiples mercados e idiomas, en lugar de depender exclusivamente de lanzar muchos productos diferentes.

## **11.1 Principio de expansión**

* Producto encontrado/validado en Argentina o Brasil \-\> probar mercados en inglés, francés o alemán.  
* Producto encontrado en inglés/francés/alemán \-\> probar mercado hispanohablante.  
* Brasil \-\> puede probar Latinoamérica, aunque el mentor también sugiere buscar mercados menos competidos.  
* Para inglés, menciona Estados Unidos, Canadá, Reino Unido, Israel y destaca Sudáfrica para low-ticket.  
* Para francés/alemán, sugiere Europa o país específico.

**Fuente del curso:** Clase 15

## **11.2 Separación de infraestructura por idioma**

| Activo | Regla del curso |
| :---- | :---- |
| Pixel | Uno distinto por idioma. |
| Landing / web | Versión separada y traducida. |
| Instagram | Cuenta separada por idioma. |
| Cuenta publicitaria | Separada por idioma. |
| Anuncios | Traducidos/adaptados al idioma correspondiente. |

| \[MENTOR DICE\] No mezclar idiomas, pixels y públicos en la misma cuenta publicitaria; el mentor lo justifica diciendo que las cuentas acumulan 'memoria/historial'. |
| :---- |

**Fuente del curso:** Clase 15

## **11.3 Precio entre mercados**

Como punto de partida, el mentor recomienda mantener el mismo ticket cuando audiencias de distintos idiomas pueden cruzarse. Cuenta un caso donde el producto estaba a USD 21 en español y USD 60 en inglés y algunos usuarios vieron ambos precios. Si se cambia el ticket, recomienda evitar solapamiento geográfico/audiencias.

**Fuente del curso:** Clase 15

# **12\. Métricas y diagnóstico**

La Clase 16 concentra el marco de diagnóstico. El curso distingue métricas de resultado, tráfico, página y video, y enseña a crear métricas personalizadas para tasa de gancho y calidad de clic.

| Métrica | Qué representa | Referencia del curso |
| :---- | :---- | :---- |
| Resultados | Compras o conversaciones, según el canal. | No fija benchmark universal. |
| Costo por resultado | Costo por compra o conversación. | Comparar con ticket, AOV y rentabilidad. |
| Presupuesto | Presupuesto diario de campaña o conjunto. | Depende de ABO/CBO. |
| Importe gastado | Gasto acumulado/del período. | Base para ROAS y control. |
| Alcance | Personas únicas alcanzadas. | Descriptiva. |
| Impresiones | Veces que se mostró el anuncio. | Puede superar alcance. |
| Frecuencia | Veces promedio que una persona ve el anuncio. | El mentor solo se preocupa si sube y la campaña entra en pérdida/break-even. |
| Conversión web | Compras / visitas a la web. | Ideal del mentor: \~2% o más. |
| Compras | Cantidad de purchases. | Resultado final. |
| ROAS | Valor de conversión / gasto. | Ejemplos: 1, 2, 3\. |
| AOV / ticket promedio | Valor promedio por compra, incluyendo bumps/backend. | Puede superar precio base. |
| Add to cart | Personas/acciones de agregado al carrito. | Diagnóstico de intención. |
| Pagos iniciados | Cantidad de checkouts iniciados. | Diagnóstico del checkout. |
| Checkout \-\> compra | Compras / pagos iniciados. | Ideal del mentor: \~50%. |
| Hook rate | Reproducciones 3 s / impresiones. | Ideal declarado: \>50%. |
| CTR enlace | Clicks enlace / impresiones. | \<1.5% se considera bajo en la clase. |
| CPC enlace | Gasto / clicks enlace. | Bajar mejorando hook/CTR según el modelo del mentor. |
| Calidad de clic | Landing page views / link clicks. | Benchmark principal mostrado: \>65%. |
| Costo visita destino | Gasto / landing page views. | Diagnóstico de tráfico real. |
| Retención | Porcentaje que mira el video completo. | Sin umbral único explícito. |
| CPM | Costo por 1000 impresiones. | Varía por nicho/demanda/calidad según el mentor. |

**Fuente del curso:** Clase 16

## **12.1 Fórmulas personalizadas**

| Métrica | Fórmula enseñada | Formato |
| :---- | :---- | :---- |
| Calidad de clic | Visitas a la página de destino / Clics en el enlace | Porcentaje |
| Tasa de gancho | Reproducciones de video de 3 segundos / Impresiones | Porcentaje |

**Fuente del curso:** Clase 16

## **12.2 Benchmarks que sí aparecen**

| Indicador | Referencia |
| :---- | :---- |
| Conversión web | \~2% o más. |
| Checkout \-\> compra | \~50%. |
| Hook rate | Ideal \>50%. |
| CTR enlace | Por debajo de 1.5% se considera bajo. |
| Calidad de clic | Benchmark principal: \>65%. |

| \[NO DEFINIDO / AMBIGUO\] En la explicación oral de calidad de clic aparece una mención a 75%, mientras que la referencia/formulación principal usa 65%. Por consistencia con la tabla y la fórmula del curso, este manual conserva 65% como benchmark principal y registra la ambigüedad. |
| :---- |

**Fuente del curso:** Clase 16

## **12.3 Cadena causal que enseña el mentor**

El razonamiento de la clase es: mejor gancho \-\> más personas siguen viendo \-\> más clicks \-\> CTR más alto \-\> CPC más bajo \-\> más tráfico con el mismo presupuesto. Después, la calidad de clic y la conversión web determinan cuánto de ese tráfico llega realmente a la página y cuánto termina comprando.

**Fuente del curso:** Clase 16

# **13\. Árboles de decisión operativos**

| \[INTERPRETACIÓN OPERATIVA\] Los siguientes árboles conectan reglas dispersas de las clases. No agregan umbrales nuevos: cuando el curso no da una cifra, el flujo lo marca como 'evaluar' o 'no definido'. |
| :---- |

## **13.1 Tengo una campaña nueva que todavía no vende**

39. ¿Está dentro de su ventana mínima? ABO normal: 48 h; Microtesting: 24 h; CBO de escala: al menos 48 h. Si sí, evitar decisiones prematuras.  
40. Revisar hook rate. Si es bajo, trabajar el gancho/primeros segundos.  
41. Revisar CTR. Si está por debajo de \~1.5%, el curso lo considera bajo.  
42. Revisar CPC. Si hook y CTR mejoran, el mentor espera que CPC baje.  
43. Revisar calidad de clic. Si está claramente por debajo de \~65%, investigar carga/velocidad de página.  
44. Revisar conversión web. Referencia del curso: \~2% o más.  
45. Revisar checkout \-\> compra. Referencia del curso: \~50%.  
46. Si las métricas previas son buenas y la página parece correcta pero no hay ventas, la Clase 1 contempla que el producto/oferta pueda ser el problema.

## **13.2 Tengo un anuncio ganador de testing**

47. Evitar usar el anuncio exacto en varias campañas de escala al mismo tiempo.  
48. Elegir una estructura de escala: 1-1-1 si querés aislarlo; Pocket si querés duplicar microsegmentaciones; Gold/Mix/Power si ya tenés varios ganadores.  
49. Dar a la nueva CBO al menos 48 h antes de decidir.  
50. Si vende con buen ROAS, aplicar escala gradual o agresiva según etapa.  
51. Crear variaciones del ganador para alimentar otras estructuras sin repetir exactamente el mismo anuncio.

## **13.3 La campaña vendía bien y dejó de vender**

52. Confirmar que es una campaña con historial; este procedimiento no es para una campaña que nunca validó.  
53. Si corresponde, aplicar primero tirón de oreja (bajar 20–30% en el marco de Clase 9\) y esperar \~2 días.  
54. Si no recupera y los anuncios parecen agotados, NO apagar la campaña completa.  
55. Duplicar anuncio viejo \-\> reemplazar creativo en duplicado \-\> publicar \-\> apagar viejo.  
56. Mantener la misma cantidad de anuncios/conjuntos.  
57. Esperar 48–72 h.  
58. Si el anuncio ganador parece saturado frente a la audiencia, considerar campaña nueva excluyendo interactuadores (Clase 13).

## **13.4 La campaña vende pero el costo se acerca al break-even**

59. Comparar CPA/costo por resultado con precio y AOV real.  
60. Si el costo llega al break-even en el escenario de Clase 9, bajar presupuesto 20–30%.  
61. Esperar aproximadamente 2 días para ver si se estabiliza.  
62. Si no se recupera, apagar según la metodología de esa clase.  
63. Si es una campaña con historial, antes de descartarla revisar si corresponde el procedimiento de reemplazo de anuncios de Clase 12\.

## **13.5 Quiero escalar una campaña que ya vende**

64. Confirmar que superó el período mínimo de aprendizaje/observación que enseña la estructura.  
65. En ABO con \>3 ventas: 20–30% cada 48–72 h como escala tranquila.  
66. En CBO automática con ROAS 2–3: el mentor permite duplicar/triplicar; con \~1.7–1.9 habla de \+30%.  
67. Si se aplica surfing, hacerlo en días/horas fuertes basados en TU historial, no en días genéricos.  
68. Por la noche, reducir presupuesto según la lógica de surfing.  
69. Si el CPA se deteriora hacia break-even, aplicar tirón de oreja.

## **13.6 Tengo muchos pagos iniciados pero pocas compras**

70. Calcular checkout \-\> compra.  
71. Comparar con la referencia del curso (\~50%).  
72. Si está muy por debajo, el cuello de botella está después de iniciar checkout y no debe diagnosticarse solo como problema del anuncio.  
73. El curso no desarrolla un protocolo detallado de optimización de checkout; requiere análisis adicional fuera del método.

| \[NO DEFINIDO / AMBIGUO\] El curso de estas 16 clases no da una lista exhaustiva de causas del abandono de checkout (medios de pago, errores técnicos, confianza, impuestos, etc.). Esas causas deben investigarse aparte. |
| :---- |

# **14\. Tabla maestra de reglas numéricas**

| Área | Variable | Regla / ejemplo | Fuente |
| :---- | :---- | :---- | :---- |
| ABO normal | Presupuesto | \~USD 10/día por conjunto para productos USD 10–25 del ejemplo | Clase 1 |
| ABO normal | Ventana | 48–72 h | Clase 1 |
| Microtesting | Presupuesto | USD 3.50 (producto 10–15); 5–6 (20–25); 10 (50–60) | Clase 2 |
| Microtesting | Ventana | 24 h | Clase 2 |
| Creatividad | Distribución | 70% ganador / 30% ángulos nuevos | Clases 1–2 |
| CBO 1-1-1 | Inicio | \~USD 35 | Clase 3 |
| CBO 1-1-1 | Espera | 2 días mínimo | Clase 3 |
| Pocket | Conjuntos | 3 / 5 / 7–8 | Clase 4 |
| Pocket | Inicio | USD 35; USD 50 más agresivo | Clase 4 |
| Pocket | Espera | 48 h; hasta 72 h con señales | Clase 4 |
| Mix/Power | Creativos | 3–5 por conjunto; duplicar 4–5 veces | Clase 5 |
| Mix/Power | Inicio | 50–75; recomendación posterior 75–135; 100 buen número | Clase 5 |
| Gold | Creativos | 3, 5, 7+ | Clase 6 |
| Gold | Espera | 48–72 h | Clase 6 |
| Cost Cap prueba | Presupuesto | 100–150 posible; no necesariamente se gasta | Clase 7 |
| Cost Cap CBO | Inicio | 250–500; ejemplos también 300/500/1000 | Clase 7 |
| Bid/Cost manual | Creativos | \~4–10 ganadores | Clases 7–8 |
| Escala ABO | Incremento | 20–30% cada 48–72 h con \>3 ventas | Clase 9 |
| Escala CBO | ROAS alto | ROAS 2–3: duplicar/triplicar en ejemplo | Clase 9 |
| Escala CBO | ROAS medio | \~1.7–1.9: \+30% | Clase 9 |
| Tirón de oreja | Reducción | 20–30% | Clase 9 |
| Ventas semanales | Referencia mentor | 50 mínimo; idealiza 100+ | Clases 9–10 |
| Cash Trap | Anuncios iniciales | 5–7 | Clase 14 |
| Cash Trap | Espera inicial | 48 h; revisar día 3; si vende, dejar \~5 días | Clase 14 |
| Cash Trap | Escala | ROAS \>2: \+30–40%, incluso 50%; si no, \~20% cada 2–3 días | Clase 14 |
| Conversión web | Benchmark | \~2%+ | Clase 16 |
| Checkout \-\> compra | Benchmark | \~50% | Clase 16 |
| Hook rate | Benchmark | Ideal \>50% | Clase 16 |
| CTR enlace | Benchmark | \<1.5% \= bajo | Clase 16 |
| Calidad de clic | Benchmark principal | \>65% | Clase 16 |

# **15\. Plantilla estándar para diagnosticar una campaña**

Para que un análisis futuro no dependa de impresiones parciales, conviene pasar siempre el mismo bloque de datos. Esta plantilla está diseñada para cruzarse con las reglas del manual.

| Dato | Completar |
| :---- | :---- |
| Estructura | ABO / CBO 1-1-1 / Pocket / Mix / Power / Gold / Cost Cap / Bid Cap / Cash Trap |
| Edad de campaña | Horas/días desde lanzamiento o último cambio importante |
| Presupuesto actual | USD/día |
| Gasto del período | USD |
| Ventas | Cantidad |
| Ingresos | USD |
| CPA / costo por compra | USD |
| ROAS | Valor |
| AOV / ticket promedio | USD |
| CPM | USD |
| Hook rate | % |
| CTR enlace | % |
| CPC enlace | USD |
| Clicks enlace | Cantidad |
| Landing page views | Cantidad |
| Calidad de clic | % |
| Conversión web | % |
| Add to cart | Cantidad / % |
| Checkouts iniciados | Cantidad |
| Checkout \-\> compra | % |
| Frecuencia | Valor |
| Cambios recientes | Presupuesto, anuncios, audiencia, landing, checkout |
| Historial | ¿Vendió bien antes? ¿Cuántas ventas? |
| Objetivo | Testear / escalar / estabilizar / recuperar |

## **15.1 Orden de lectura recomendado**

74. Primero: etapa y estructura (¿estamos testeando, escalando o recuperando?).  
75. Segundo: tiempo transcurrido desde lanzamiento/cambio.  
76. Tercero: resultado económico (ventas, CPA, ROAS, AOV).  
77. Cuarto: creativo (hook, CTR, CPC, CPM).  
78. Quinto: tráfico real (landing page views, calidad de clic).  
79. Sexto: sitio y checkout (conversión, add to cart, inicio de pago, checkout \-\> compra).  
80. Séptimo: historial de la campaña y cambios recientes.  
81. Octavo: recién entonces decidir mantener, escalar, bajar, reemplazar o apagar.

# **16\. Qué está definido por el curso y qué no**

## **16.1 El curso sí define**

* Ventanas de observación aproximadas para ABO, Microtesting y varias CBO.  
* Presupuestos de ejemplo por estructura y ticket.  
* Regla 70/30 para creatividad.  
* Estructuras Pocket 3/5/7–8.  
* Cantidad orientativa de anuncios en Gold, Mix/Power y campañas manuales.  
* Escala gradual 20–30% y ejemplos de escala agresiva.  
* Tirón de oreja y recuperación de campañas con historial.  
* Audiencias de interacción, lookalike de compradores y audiencia guardada.  
* Cash Trap con una campaña, un conjunto y 5–7 anuncios iniciales.  
* Separación por idioma de pixel, landing, Instagram y cuenta publicitaria.  
* Benchmarks de conversión, hook, CTR, calidad de clic y checkout \-\> compra.

## **16.2 El curso NO define de forma suficiente**

* Un CPA universal 'bueno' para cualquier producto.  
* Un ROAS mínimo universal para apagar cualquier campaña en cualquier momento.  
* Una cantidad exacta de gasto sin venta que obligue a apagar en todos los casos.  
* Una definición única de 'anuncio ganador' válida para todos los tickets.  
* Una fórmula completa de break-even incorporando fees, refunds, impuestos y costos de entrega.  
* Un protocolo exhaustivo para errores técnicos de checkout o Shopify.  
* Un presupuesto inicial inequívoco de Cash Trap debido a la transcripción dañada.  
* Una diferencia formal exacta entre todas las variantes Mix vs. Power en la transcripción disponible.  
* Una estrategia específica para cada país aplicable universalmente: los países/días/horarios mostrados son ejemplos de cuentas concretas.

## **16.3 Regla de seguridad para futuras respuestas**

| \[REGLA DEL MANUAL\] Si una decisión no puede justificarse con una regla del curso o con datos suficientes de la campaña, la respuesta debe decir 'el manual no define un umbral exacto para esto' y separar cualquier recomendación adicional como análisis externo, no como enseñanza del mentor. |
| :---- |

# **17\. Ambigüedades y puntos a conservar con cautela**

| Tema | Qué ocurre en la fuente | Cómo tratarlo |
| :---- | :---- | :---- |
| CBO en Clase 3 | El ASR contiene una frase que parece ubicar presupuesto a nivel conjunto, mientras el resto del curso describe CBO a nivel campaña. | Usar la estructura coherente con el resto del curso y registrar la contradicción. |
| Cash Trap presupuesto | La cifra inicial está dañada en el subtítulo. | No fijar un número único. |
| Calidad de clic | Se menciona 65% como referencia principal y aparece 75% una vez en el habla. | Usar 65% como benchmark principal y anotar la discrepancia. |
| Hook | Se habla de 5 o 3 segundos; la fórmula mostrada usa reproducciones de 3 segundos. | Para cálculo, usar 3 s / impresiones. |
| ROAS | La definición verbal contiene una frase ASR incorrecta, pero los ejemplos 10/10=1, 20/10=2, 30/10=3 son claros. | Interpretar por los ejemplos: valor de conversión / gasto. |
| Términos Cost/Bid/ROAS Cap | El ASR de nombres aparece deformado ('cosca', 'vidcap', 'roscap'). | Normalizar nombres en el manual, manteniendo la fuente de clase. |

# **18\. Glosario operativo**

| Término | Definición dentro del manual |
| :---- | :---- |
| ABO | Presupuesto a nivel conjunto de anuncios; se usa para testear de forma individual en el curso. |
| CBO | Presupuesto a nivel campaña; Meta distribuye entre conjuntos. |
| CBO 1-1-1 | Una campaña, un conjunto y un anuncio ganador. |
| Pocket | CBO con varios conjuntos que contienen el mismo anuncio ganador. |
| Pocket reducida / común / ampliada | 3 / 5 / 7–8 conjuntos respectivamente. |
| CBO Gold | Una CBO, un conjunto y varios anuncios ganadores. |
| CBO Mix / Power | Estructuras con múltiples ganadores por conjunto y mayor concentración de presupuesto. |
| Cost Cap | Estrategia manual con objetivo de costo por resultado. |
| Bid Cap | Estrategia manual con límite máximo de puja. |
| Surfing | Escalado intradía agresivo subiendo presupuesto a medida que entran ventas rentables. |
| Tirón de oreja | Bajar presupuesto para intentar que una campaña vuelva a costos aceptables. |
| Hook rate | Reproducciones de 3 segundos / impresiones, según la fórmula enseñada. |
| Calidad de clic | Landing page views / link clicks. |
| AOV | Ticket promedio por pedido, incluyendo order bumps/backend. |
| Cash Trap | Metodología evergreen de una sola CBO, un conjunto y diversidad creativa. |
| Ángulo ganador | Enfoque de venta/dolor/deseo que ya demostró respuesta en testing. |
| Variación creativa | Nueva ejecución del mismo ángulo: nuevo video, audio, gancho, formato, etc. |

# **19\. Índice de trazabilidad por clase**

Este índice permite volver rápidamente a la transcripción literal si una regla necesita ser auditada. El respaldo original debe conservarse separado de este manual.

| Clase | Contenido trazable |
| :---- | :---- |
| 1 | ABO normal; audiencia/ubicaciones; 48–72 h; 70/30; diagnóstico inicial. |
| 2 | Microtesting; presupuestos; 24 h; variaciones creativas; CPC si no hay ventas. |
| 3 | Superposición; no duplicar mismo anuncio; CBO 1-1-1; separación de cuentas. |
| 4 | Pocket reducida/común/ampliada; análisis a nivel campaña. |
| 5 | Mix/Power; 3–5 ganadores; duplicación de conjuntos; presupuestos mayores. |
| 6 | Gold; 3/5/7+ anuncios; presupuestos por cantidad; paciencia 48–72 h. |
| 7 | Cost Cap; test de objetivos; presupuestos altos; CBO Cost Cap; surfing. |
| 8 | Bid Cap; límite de puja; precio del producto como inicio; surfing; relanzamiento. |
| 9 | Escala gradual/agresiva; ROAS; tirón de oreja; 50–100 ventas/semana. |
| 10 | Historial; días/horas/países; cuándo testear, escalar o surfear. |
| 11 | Etapa avanzada; ABO Gold; salida directa en Gold/Mix/Power/Pocket/CBO. |
| 12 | Salvar campañas; duplicar-reemplazar-apagar; 48–72 h. |
| 13 | Excluir interactuadores; lookalike 1%; guardar audiencia rentable. |
| 14 | Cash Trap; 1 campaña; 1 conjunto; 5–7 anuncios; mantenimiento y escala. |
| 15 | Mercados; idiomas; separación de pixel/landing/Instagram/cuenta; pricing. |
| 16 | Métricas; fórmulas; benchmarks; diagnóstico creativo-tráfico-web. |

# **20\. Protocolo de consulta rápida**

Cuando uses este manual para una campaña real, la respuesta ideal debe tener este formato:

82. Estado actual: resumir estructura, edad, presupuesto, ventas, CPA, ROAS y AOV.  
83. Diagnóstico: identificar el cuello de botella con las métricas disponibles.  
84. Qué dice el mentor: citar la regla y la clase relevante.  
85. Qué haría ahora según el método: una sola intervención prioritaria, evitando tocar varias variables a la vez.  
86. Qué NO tocar todavía: proteger el período mínimo de observación/aprendizaje.  
87. Cuándo volver a mirar: 24 h / 48 h / 72 h / 2–3 días, según la estructura y la regla aplicable.  
88. Qué dato falta: si el manual no permite decidir, pedir la métrica que falta.  
89. Separar cualquier recomendación externa del método del mentor.

| \[OBJETIVO FINAL\] Este documento está diseñado para poder subirse solo a un chat nuevo y funcionar como referencia operativa del sistema de las 16 clases. El backup literal de transcripciones sigue siendo la evidencia primaria para auditorías o dudas de redacción. |
| :---- |

**FIN DEL MANUAL MAESTRO · Versión 1.0**