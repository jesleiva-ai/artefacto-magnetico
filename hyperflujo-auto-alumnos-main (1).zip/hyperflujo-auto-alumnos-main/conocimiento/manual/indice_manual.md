# Índice del Manual Maestro de Meta Ads v1.0

Archivo: `conocimiento/Manual_Maestro_v1.0.md` (copia intacta de `analisis/contexto_propuesta/fuentes/Manual_Maestro_Meta_Ads.md`, 838 líneas, SHA-256 `08e176c6…80132ba`). No editar el manual; si cambia, se crea otra versión y se regenera este índice.

Cómo leerlo: **Líneas** es el rango de la sección en el manual (incluye sus subsecciones en las filas de nivel 1). **Clases** son las clases del curso citadas dentro de ese rango. Para leer solo una parte: `sed -n 'INICIO,FINp' conocimiento/Manual_Maestro_v1.0.md` o la herramienta de lectura con offset/limit.

Etiquetas del manual: [MENTOR DICE] regla explícita del curso · [INTERPRETACIÓN OPERATIVA] traducción práctica · [NO DEFINIDO / AMBIGUO] el curso no da la cifra: no inventarla.

| Sección | Líneas | Clases citadas |
| :-- | --: | :-- |
| **Cómo usar este manual** | 12–52 | — |
| &nbsp;&nbsp;Instrucción recomendada para usarlo en otro chat | 28–31 | — |
| &nbsp;&nbsp;Mapa de las 16 clases | 32–52 | — |
| **1. Mapa general del sistema** | 53–89 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13, 14, 15, 16 |
| &nbsp;&nbsp;1.1 Flujo maestro | 60–74 | 1, 2, 3, 4, 5, 6, 9, 12, 13, 14, 15, 16 |
| &nbsp;&nbsp;1.2 Arquitectura de cuentas publicitarias que enseña el mentor | 75–89 | 3, 4, 5, 7, 8, 14, 15 |
| **2. Testing: validar antes de escalar** | 90–154 | 1, 2 |
| &nbsp;&nbsp;2.1 ABO normal | 92–112 | 1 |
| &nbsp;&nbsp;2.2 Microtesting | 113–130 | 2 |
| &nbsp;&nbsp;2.3 Regla 70/30 y explotación de ángulos | 131–147 | 1, 2 |
| &nbsp;&nbsp;2.4 Qué significa 'ganador' dentro del curso | 148–154 | — |
| **3. Superposición en subasta y reutilización de anuncios** | 155–173 | 3, 11 |
| &nbsp;&nbsp;3.1 Regla operativa | 162–173 | 3, 11 |
| **4. Estructuras de escala automáticas** | 174–256 | 3, 4, 5, 6, 11 |
| &nbsp;&nbsp;4.1 CBO 1-1-1 | 176–190 | 3 |
| &nbsp;&nbsp;4.2 Pocket | 191–208 | 4 |
| &nbsp;&nbsp;4.3 CBO Mix / Deep Pocket y CBO Power | 209–226 | 5 |
| &nbsp;&nbsp;4.4 CBO Gold | 227–241 | 6 |
| &nbsp;&nbsp;4.5 Matriz de elección entre estructuras | 242–256 | 3, 4, 5, 6, 11 |
| **5. Campañas manuales: Cost Cap y Bid Cap** | 257–304 | 7, 8 |
| &nbsp;&nbsp;5.1 Cost Cap | 261–281 | 7 |
| &nbsp;&nbsp;5.2 Bid Cap | 282–295 | 8 |
| &nbsp;&nbsp;5.3 Diferencia funcional dentro del método | 296–304 | — |
| **6. Metodología de escalado** | 305–367 | 9, 10, 14 |
| &nbsp;&nbsp;6.1 Escala gradual | 307–315 | 9 |
| &nbsp;&nbsp;6.2 Escala agresiva en CBO | 316–328 | 9 |
| &nbsp;&nbsp;6.3 Surfing | 329–339 | 9 |
| &nbsp;&nbsp;6.4 'Pixel optimizado' según la terminología del curso | 340–348 | 9, 10, 14 |
| &nbsp;&nbsp;6.5 Historial de ventas: cuándo escalar y cuándo no tocar | 349–367 | 10 |
| **7. Etapa avanzada: campañas agresivas** | 368–382 | 11 |
| **8. Recuperar una campaña que dejó de vender** | 383–419 | 12 |
| &nbsp;&nbsp;8.1 Cuándo aplica | 387–393 | — |
| &nbsp;&nbsp;8.2 Procedimiento exacto | 394–410 | 12 |
| &nbsp;&nbsp;8.3 Aplicación por estructura | 411–419 | — |
| **9. Públicos y audiencias** | 420–451 | 13 |
| &nbsp;&nbsp;9.1 Revivir un anuncio mostrándolo a gente nueva | 422–432 | 13 |
| &nbsp;&nbsp;9.2 Lookalike de compradores | 433–445 | 13 |
| &nbsp;&nbsp;9.3 Guardar audiencia de una campaña rentable | 446–451 | 13 |
| **10. Método Cash Trap** | 452–499 | 14 |
| &nbsp;&nbsp;10.1 Estructura | 456–469 | 14 |
| &nbsp;&nbsp;10.2 Tiempo y decisiones | 470–483 | 14 |
| &nbsp;&nbsp;10.3 Gestión de anuncios dentro de Cash Trap | 484–494 | 14 |
| &nbsp;&nbsp;10.4 Presupuesto inicial: punto ambiguo de la transcripción | 495–499 | — |
| **11. Mercados internacionales y múltiples idiomas** | 500–534 | 15 |
| &nbsp;&nbsp;11.1 Principio de expansión | 504–513 | 15 |
| &nbsp;&nbsp;11.2 Separación de infraestructura por idioma | 514–528 | 15 |
| &nbsp;&nbsp;11.3 Precio entre mercados | 529–534 | 15 |
| **12. Métricas y diagnóstico** | 535–594 | 16 |
| &nbsp;&nbsp;12.1 Fórmulas personalizadas | 565–573 | 16 |
| &nbsp;&nbsp;12.2 Benchmarks que sí aparecen | 574–588 | 16 |
| &nbsp;&nbsp;12.3 Cadena causal que enseña el mentor | 589–594 | 16 |
| **13. Árboles de decisión operativos** | 595–655 | 1, 9, 12, 13 |
| &nbsp;&nbsp;13.1 Tengo una campaña nueva que todavía no vende | 600–610 | 1 |
| &nbsp;&nbsp;13.2 Tengo un anuncio ganador de testing | 611–618 | — |
| &nbsp;&nbsp;13.3 La campaña vendía bien y dejó de vender | 619–628 | 9, 13 |
| &nbsp;&nbsp;13.4 La campaña vende pero el costo se acerca al break-even | 629–636 | 9, 12 |
| &nbsp;&nbsp;13.5 Quiero escalar una campaña que ya vende | 637–645 | — |
| &nbsp;&nbsp;13.6 Tengo muchos pagos iniciados pero pocas compras | 646–655 | — |
| **14. Tabla maestra de reglas numéricas** | 656–690 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 14, 16 |
| **15. Plantilla estándar para diagnosticar una campaña** | 691–732 | — |
| &nbsp;&nbsp;15.1 Orden de lectura recomendado | 722–732 | — |
| **16. Qué está definido por el curso y qué no** | 733–765 | — |
| &nbsp;&nbsp;16.1 El curso sí define | 735–748 | — |
| &nbsp;&nbsp;16.2 El curso NO define de forma suficiente | 749–760 | — |
| &nbsp;&nbsp;16.3 Regla de seguridad para futuras respuestas | 761–765 | — |
| **17. Ambigüedades y puntos a conservar con cautela** | 766–776 | 3 |
| **18. Glosario operativo** | 777–798 | — |
| **19. Índice de trazabilidad por clase** | 799–821 | — |
| **20. Protocolo de consulta rápida** | 822–838 | — |

## Clase → sección principal

| Clase | Tema | Secciones del manual (§N = sección sin subsecciones) |
| --: | :-- | :-- |
| 1 | ABO normal | 1.1, 2.1, 2.3, 13.1, §14 |
| 2 | Microtesting | 1.1, 2.2, 2.3, §14 |
| 3 | Superposición + CBO 1-1-1 | 1.1, 1.2, 3.1, 4.1, 4.5, §14, §17 |
| 4 | Pocket | 1.1, 1.2, 4.2, 4.5, §14 |
| 5 | CBO Mix / Power | 1.1, 1.2, 4.3, 4.5, §14 |
| 6 | CBO Gold | 1.1, 4.4, 4.5, §14 |
| 7 | Cost Cap | 1.2, 5.1, §14 |
| 8 | Bid Cap | 1.2, 5.2, §14 |
| 9 | Metodología de escala | 1.1, 6.1, 6.2, 6.3, 6.4, 13.3, 13.4, §14 |
| 10 | Historial de ventas | 6.4, 6.5, §14 |
| 11 | Campañas agresivas | 3.1, 4.5, §7 |
| 12 | Salvar una campaña | 1.1, 8.2, 13.4 |
| 13 | Públicos y audiencias | 1.1, 9.1, 9.2, 9.3, 13.3 |
| 14 | Cash Trap | 1.1, 1.2, 6.4, 10.1, 10.2, 10.3, §14 |
| 15 | Mercados internacionales | 1.1, 1.2, 11.1, 11.2, 11.3 |
| 16 | Métricas y diagnóstico | 1.1, 12.1, 12.2, 12.3, §14 |

Generado por script a partir de los encabezados `#`/`##` y de las menciones "Clase N" del manual; verificar contra el texto antes de citar una regla.
