# 00 · Línea de tiempo: Método del Consultor (español)

> **Estado: BORRADOR para que Matías corrija.** Todas las horas son de Buenos Aires (UTC−3). Salen de los registros de las sesiones de Claude Code:
> - «Segundo cerebro con IA»: la sesión principal, de donde salió el pedido.
> - «Cazar oferta validada y lanzarla en español»: la sesión que hizo el lanzamiento.
>
> Donde no hay registro dice **[FALTA: preguntar a Matías]**.

## Resumen

| Hito | Fecha y hora | Desde el pedido |
|---|---|---|
| Pedido de Matías: "cazá una oferta validada y lanzala" | 20/10 19:34 | 0 |
| Lanzamiento armado, sin campaña (web, portal, Hotmart, embudo, fanpage, píxel, 9 anuncios) | 20/10 21:11 | 1 h 37 min |
| Campaña creada en pausa (puntuación de Meta 100) | 20/10 23:23 | 3 h 49 min |
| Campaña publicada y activa (Meta aprobó los anuncios) | 20/10 23:30–23:34 | ~4 h |
| Embudo final (Kit → Prompts → Reuniones) y garantía de 7 días | 21/10 00:23–00:25 | ~4 h 50 min |
| Página de ventas restaurada por Codex a pedido de Matías | 21/10 00:39 | ~5 h |
| Primera venta | [FALTA: sale de la exportación de Hotmart] | [FALTA] |
| Matías: "se está vendiendo muy bien" | 21/10 11:58 | ~16 h 30 min |

## Paso a paso

| # | Hora (BA) | Qué pasó | Quién | Dónde quedó registrado |
|---|---|---|---|---|
| 1 | 20/10 19:34 | Matías pide activar la skill `cazador-de-ofertas`, buscar una oferta validada (más de 30 anuncios activos, más de 10 días, sin marca personal, infoproducto, otro mercado, en español) y hacer todo el lanzamiento sin pedir confirmación. Texto literal en `prompts/2026-10-20_1934_pedido-cazar-oferta-y-lanzar.md`. | Matías | sesión «Segundo cerebro con IA» |
| 2 | 20/10 19:35 | Se abre la sesión de lanzamiento y busca ofertas en el conector Nexus Profit (`descubrir_ofertas` con mínimo 30, después 10 y después 5 copias, 10 días). | Claude | sesión «Cazar oferta…» |
| 3a | 20/10 19:35–19:37 | Consulta Nexus Profit (`descubrir_ofertas`, `tendencias`, `buscar_anuncios`) y descarta candidatas. | Claude | `fuentes/informe_sesion_lanzamiento_consultor.md` |
| 3b | 20/10 19:36–19:41 | Busca en la Biblioteca de anuncios con el analizador de la skill, cuenta ~140 anuncios activos del original, mide la competencia en MX y ES y **elige la oferta** *Consulting Management EXPLAINED* (Business Explained, EE. UU.). | Claude | ídem |
| 3c | 20/10 19:41–19:57 | Escribe el producto: guía en 7 partes con 48 herramientas, 4 bonos, 3 bumps y el Kit. | Claude | ídem |
| 3d | 20/10 19:57–20:02 | Arma y publica el portal, la web v1, los mockups y los PDFs de acceso. | Claude | ídem |
| 3e | 20/10 20:02–20:20 | En el Chrome de Matías: crea la fanpage Estrategia Clara y el píxel. Matías acepta términos de Meta y autoriza que Claude los acepte en adelante. | Claude + Matías | ídem |
| 3f | 20/10 20:20–21:07 | Carga los 7 productos en Hotmart, en USD y con Estados Unidos como país principal (pedido de Matías), y los order bumps en Apariencia de la Página de Pago. | Claude, guiado por Matías | ídem |
| 3g | 20/10 20:55–21:10 | Arma el embudo de un clic (upsell, 2 downsells y gracias) con sus páginas y el widget, y lo activa. | Claude | ídem |
| 4 | 20/10 21:11 | Claude informa que el lanzamiento está armado y que falta la campaña. | Claude | — |
| 5 | 20/10 21:12–21:15 | Matías compara la web con la del original y pide modelarla tal cual: mockup con persona, ejemplos del producto, colores, animaciones, imagen por bono y botón fijo con descuento y contador. | Matías | — |
| 6 | 20/10 21:28 | Web rehecha con la estructura del original, publicada. | Claude | — |
| 7 | 20/10 22:25–22:28 | Matías revisa en el celular: imágenes estiradas. Se corrigen y se publican. | Matías + Claude | — |
| 8 | 20/10 22:28–22:35 | Matías pregunta en qué país hay competencia, quiere sumar México, pide ver los 9 anuncios y compararlos con los del original. Pega el link de la Biblioteca de anuncios del original. | Matías + Claude | — |
| 8b | 20/10 22:50–22:59 | En **Codex**, en paralelo, Matías pide un carrusel de opiniones en la página del Consultor. Codex toma 6 capturas de opiniones de la página en inglés de Business Explained, las traduce conservando nombres y fechas, las publica antes de la oferta final y enlaza las capturas originales. | Matías + Codex | `fuentes/codex_informe_conversacion_20261021.txt` |
| 9 | 20/10 22:58–22:59 | Anuncios v2 listos (5 videos con subtítulos y música, más placas). Matías: "vamos a correr anuncio". | Claude + Matías | carpeta `anuncios_v2` |
| 10 | 20/10 23:00–23:04 | Matías decide el precio de USD 19,99 ("17,90 está muy barato"). Se cambia en la web y en Hotmart. | Matías decide, Claude ejecuta | — |
| 11 | 20/10 23:06–23:08 | Matías define la segmentación: América del Norte, Central, del Sur, Caribe y España, sin Argentina, Nicaragua ni Venezuela, en los 3 idiomas de español, USD 75 por día, cuenta morfi 1. | Matías | — |
| 12 | 20/10 23:11–23:23 | Claude crea la campaña "Metodo Consultor ES - Cash Trap", el conjunto "Hispanos - Advantage+ - ES" y los 9 anuncios, en pausa. Puntuación de Meta: 100. | Claude | — |
| 13 | 20/10 23:30 | Matías: "Publícala". Claude activa la campaña, el conjunto y los 9 anuncios (23:30–23:32). Meta los aprueba (23:34). | Matías + Claude | — |
| 14 | 20/10 23:35–23:44 | Utmify: Matías ya tenía Hotmart conectado a Utmify y cargó él los parámetros UTM en los anuncios. El script de la página lo publicó la sesión principal (23:44). Matías publica a mano los "cambios sin publicar" de la campaña. | Matías + Claude | — |
| 15 | 20/10 23:44–21/10 00:23 | Backend: Matías pide que, diga sí o no, siempre se le ofrezca el producto siguiente, y que no se achique el Kit. Queda el embudo final Kit (USD 34,90) → Prompts (USD 17) → Reuniones [FALTA: precio exacto en el registro]. | Matías decide, Claude ejecuta | — |
| 16 | 21/10 00:24–00:25 | Regla nueva: garantía de 7 días en todos los productos. Se cambia en Hotmart y en la web (8 lugares). | Matías decide, Claude ejecuta | — |
| 17 | 21/10 ~00:26 | Incidente: un deploy de Claude pisó las imágenes de la página de ventas. | Claude | — |
| 18 | 21/10 00:36–00:39 | Matías le avisa a **Codex** que la página cambió. Codex encuentra el deploy de las 00:26 (la página bajó de unos 54.000 a 23.000 caracteres) y restaura solo el Método del Consultor, con el precio y la garantía vigentes (deploy 6ad8341b). Esa es la versión que vende. | Matías + Codex | `fuentes/codex_informe_conversacion_20261021.txt` |
| 19 | 21/10 00:31–00:51 | Matías pide el reporte de campañas a las 12:30 y que se guarde todo en el segundo cerebro. | Matías | — |
| 20 | 21/10 11:58 | Matías: "se está vendiendo muy bien". Pide guardar la estrategia de modelado y la web en el cerebro. | Matías | — |
| 21 | [FALTA] | Primera venta. | — | exportación de Hotmart |

## Tiempo por etapa (Matías completa la columna "Tiempo de Matías")

La columna "Tiempo de los chats" sale de los registros: va desde que arranca la etapa hasta el último mensaje de esa etapa. La de Matías es lo que estuvo él mirando, probando o decidiendo, incluido lo que hizo fuera del chat.

| Etapa | Cuándo (según registro) | Tiempo de los chats | Tiempo de Matías | Notas |
|---|---|---|---|---|
| Buscar producto | 20/10 19:35–19:41 | ~6 min | [FALTA: Matías] | Claude solo, sin mensajes de Matías en ese tramo |
| Hacer el producto | 20/10 19:41–20:02 | ~21 min | [FALTA: Matías] | Contenido, portal, PDFs y mockups |
| Revisar producto | 20/10 21:12–22:35 | ~1 h 20 min | [FALTA: Matías] | Correcciones de la web y comparación con el original |
| Hotmart | 20/10 20:20–21:10, más el precio 23:00–23:04 y el embudo 23:44–00:25 | ~50 min + 4 min + ~40 min | [FALTA: Matías] | Matías dio 6 indicaciones mientras se cargaba (USD, país, dónde van los bumps, link del checkout) |
| Página | 19:35–21:11 (primera versión), 21:12–22:28 (modelada), 00:40 (arreglo con ChatGPT) | [FALTA: sub-tiempos] | [FALTA: Matías] | — |
| Anuncios | dentro de 19:35–21:11 (v1) y hasta 22:58 (v2) | [FALTA: sub-tiempos] | [FALTA: Matías] | — |
| Campaña | 20/10 23:06–23:44 | ~40 min | [FALTA: Matías] | Segmentación decidida por Matías, carga por Claude con el conector de Meta Ads |
| Seguimiento diario | desde 21/10 (reporte automático 12:00–12:30) | [FALTA] | [FALTA: Matías] | Sesiones «Reporte diario 12:00 — Meta Ads» |
