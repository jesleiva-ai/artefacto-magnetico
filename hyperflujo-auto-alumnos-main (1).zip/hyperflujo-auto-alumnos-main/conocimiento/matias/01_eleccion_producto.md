# 01 · Elección del producto: Método del Consultor

> Estado: **borrador**. Fuente principal: `fuentes/informe_sesion_lanzamiento_consultor.md`, el informe que armó la sesión «Cazar oferta validada y lanzarla en español» leyendo su propio registro. Los detalles y los 23 candidatos completos están ahí.

## Cómo arrancó

- **Pedido de Matías:** 20/10/2026 19:34, en la sesión «Segundo cerebro con IA». El texto literal está en `prompts/2026-10-20_1934_pedido-cazar-oferta-y-lanzar.md`.
- **Tarea que recibió la sesión de lanzamiento:** el informe la cita textual en §1. Dice: «Activá la skill `cazador-de-ofertas` (conector nexus-profit + Biblioteca de anuncios de Meta) y buscá una oferta validada de infoproducto para modelar y vender EN ESPAÑOL, en un mercado distinto al que vende hoy».

## Criterios

1. Más de **30 anuncios activos**, en el perfil o con la frase exacta del producto.
2. Más de **10 días** al aire.
3. **No es marca personal.**
4. **Infoproducto:** ebook, guía o curso digital.
5. **Español libre o poco saturado:** se mira en qué países pauta y si alguien ya lo vende en español.

**Reglas que estaban escritas en otro lado:**
- La skill `cazador-de-ofertas` agrega 20 o más activos reales en el perfil, que no haya anuncios con «pocas impresiones» y señales de que es una marca.
- El cerebro (`cerebro/ELEGIR_Y_MODELAR_OFERTAS.md`) pide 20 a 30 o más anuncios y **más de 15 días**.

En este lanzamiento valieron los números del pedido: 30 anuncios y 10 días.

## Fuentes usadas

| Fuente | Cómo |
|---|---|
| Conector **Nexus Profit** (skill `cazador-de-ofertas`) | `descubrir_ofertas` con 30/10, 10/10 y por velocidad (5/10). También `tendencias` y `buscar_anuncios` por país: FR, PL y US. |
| **Biblioteca de anuncios de Meta** | En el navegador, sin iniciar sesión, con el analizador `skills/cazador-de-ofertas/scripts/meta_scan.min.js`. Búsqueda por la frase exacta del producto y por país. |
| Landing del original | business-explained.com (página «the-problem-solving-system…»). |
| Hotmart | No se usó para buscar. **[FALTA: preguntar a Matías si usa Hotmart para buscar ofertas]** |

## Cuántos candidatos miró y qué pasó con cada uno

- **23 candidatos documentados**, en `fuentes/informe_sesion_lanzamiento_consultor.md` §5.
- **1 elegido**, **2 en espera** y el resto **descartados**. Los motivos de descarte fueron: marca personal, ya se vende en español, menos de 30 anuncios, no es infoproducto o es un producto físico.
- **Elegido: Consulting Management EXPLAINED (Business Explained, EE. UU.).** Lo eligió Claude en ~6 minutos (19:35 a 19:41):
  - Unos 140 anuncios activos con la frase exacta, unos 120 de ellos en EE. UU.
  - Primer anuncio visto el 20/06/2026.
  - Es una tienda-marca con 69 ebooks, no una persona.
  - Ebook PDF de 109 páginas, que se vende a US$ 49.
  - En español solo tenía 6 anuncios de prueba en México y nadie más lo vendía.
- **Medición por país** (informe §5b): México, España, Colombia, Argentina, Chile, Perú, Ecuador y Guatemala.

## Decisiones de Matías en esta etapa

| Hora | Decisión (literal) |
|---|---|
| 20/10 22:30 | «Igualmente, si está vendiendo en inglés en México, yo puedo vender en español, ¿ok? No pasa nada.» |
| 20/10 22:32 | «Lo vamos a hacer en México también, si no hay nadie en México.» |
| 20/10 23:06 | «¿por qué no ponemos América del Norte, América Central, América del Sur, Caribe, y España? Y excluimos Argentina, Nicaragua, y Venezuela.» |

## Lo que falta

- **[FALTA: preguntar a Matías]** El aviso a Matías de «qué oferta elegí y por qué» no quedó como mensaje aparte (informe §6).
- **[FALTA: preguntar a Matías]** No hay registro de que se haya citado el «Manual Maestro» en esta búsqueda.
- **[FALTA: preguntar a Matías]** Qué otras búsquedas hizo Matías por su cuenta antes del 20/10, por ejemplo la nota del 19/10 en `cerebro/2026-10-19_cazador_3-ofertas.md`.
- **Lo que no es parte de este lanzamiento:** la sesión «Búsqueda de producto para vender» arrancó el 21/10 a las 11:53, después de que el Consultor ya vendía. Es la búsqueda de los productos siguientes (Kit Musical, For Knitters, Acordes en Claro, Aprendia).
