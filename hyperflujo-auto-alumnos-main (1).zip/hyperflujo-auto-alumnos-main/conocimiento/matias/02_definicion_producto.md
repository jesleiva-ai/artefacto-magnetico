# 02 · Definición del producto

> Estado: **borrador**. Fuentes: `cerebro/PROYECTO_metodo-consultor.md` y `fuentes/informe_sesion_lanzamiento_consultor.md`.

## Qué es

- **Nombre:** El Método del Consultor (en español, trato de «tú»).
- **Formato:** guía digital en 7 partes con **48 herramientas**, más 4 bonos. Son unas 16.000 palabras y se leen en un **portal web con candados**: https://laformulaebooks.site/portal-metodo-consultor/
- **Qué recibe el comprador:** Hotmart le entrega un PDF corto de acceso que lo lleva al portal.
- **Modelado de:** *Consulting Management EXPLAINED*, de Business Explained. Es un ebook de 109 páginas con más de 40 marcos (SCQA, MECE, Porter, ICE, BCG, KPI, Agile). El temario es el mismo, más completo.
- **Índice (Parte 1):** qué hace un consultor; la mentalidad del consultor; el proceso de 6 pasos; MECE; SCQA… Está completo en el texto del anuncio C3 y en `fuentes/`. **[FALTA: subir el índice completo de las 7 partes desde `D:\creativos\metodo-consultor-es\contenido\`]**

## Precio y garantía

- **USD 19,99.** Se muestra como 50% off de USD 39,98 hasta el 3/11/2026 23:59 (hora de Buenos Aires).
- **Por qué ese precio:** Claude había puesto 17,90. Matías lo cambió el 20/10 a las 23:00: «Vamos a ponerlo en 19.99 entonces. Está muy barato, si no. $19.99 es buen precio, ¿sí?».
- **Break-even por venta:** USD 19,99.
- **Garantía:** 7 días en todos los productos. Regla de Matías del 21/10: «7 días, nunca 15».
- **Moneda:** todo en USD y con Estados Unidos como país principal, a pedido de Matías. La web convierte a la moneda local según la IP del visitante.

## Escalera (backend)

| Paso | Producto | Precio (USD) |
|---|---|---|
| Principal | El Método del Consultor | 19,99 |
| Bump 1 | Plantillas del Consultor | 9,99 |
| Bump 2 | Presentaciones que Convencen | 9,99 |
| Bump 3 | Números para Decidir (6 calculadoras) | 9,99 |
| Upsell | Kit del Consultor Independiente (3 módulos) | 34,90 |
| Oferta 2 | Prompts de IA para Consultores | 17,00 |
| Oferta 3 | Reuniones que Deciden | 12,00 |

## Con qué se hizo y cuánto costó

| Herramienta | Para qué | Costo |
|---|---|---|
| Claude Code (sesión de lanzamiento) | Escribir el contenido en `contenido\*.md`, armar el portal y los PDFs | **[FALTA: costo del plan de Claude de Matías]** |
| Higgsfield (`gpt_image_2_5`, ~0,25 créditos por imagen; `kling3_0`, ~6,25 créditos por video de 5 s) | Mockups, imágenes y videos | ~110 créditos en total, entre producto, web y anuncios (informe §3). **[FALTA: valor en USD del crédito de Higgsfield]** |
| ElevenLabs | Voz y música de los videos | 1.606 caracteres. **[FALTA: costo en USD]** |

- **Prompts para escribir el producto:** los escribió Claude solo, a partir de la tarea. No hubo un prompt aparte de Matías.
- **Tiempo:** el contenido llevó unos 16 minutos (19:41 a 19:57) y el portal y los PDFs unos 5 (19:57 a 20:02).
