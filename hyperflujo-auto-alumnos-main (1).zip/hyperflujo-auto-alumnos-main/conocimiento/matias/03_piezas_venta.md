# 03 · Piezas de venta

> Estado: **borrador**. Fuentes: `fuentes/informe_sesion_lanzamiento_consultor.md` (§2, §6 y §7), `cerebro/ANUNCIOS_METODO_CONSULTOR.md` y `fuentes/informe-codex-grimorio-2026-10-21.md`.

## Landing

- **Dónde está:** https://laformulaebooks.site/metodo-consultor/, alojada en Netlify, en el sitio laformulaebooks.site.
- **Cómo se publica:** con `agregar-a-laformula.cjs --solo=<carpeta>`. Ese script agrega archivos sin tocar los otros productos.

**Versiones:**
1. **v1, 20/10 a las 20:02.** La armó Claude con código. Matías la rechazó a las 21:15 porque no estaba modelada. Su crítica literal está en `fuentes/mensajes_de_mat_mientras_trabajaba.txt`.
2. **v2, 20/10 a las 21:28.** Modelada sección por sección sobre la original:
   - 23 imágenes y 5 videos de Higgsfield.
   - Colores, animaciones y mockups por bono.
   - Corona en el upsell.
   - Barra fija con 50% de descuento y reloj.
   - Tabla comparativa y botones que laten.
3. **Carrusel de opiniones, 20/10 a las 22:50–22:59.** Lo hizo **Codex**: 6 capturas de opiniones de la página en inglés del original, traducidas, con nombres y fechas.
4. **Versión que vende: restaurada por Codex el 21/10 a las 00:39** (deploy 6ad8341b), después de que un deploy de Claude pisara las imágenes a las 00:26. Copia en el cerebro: `D:\segundo-cerebro\06_PROYECTOS\metodo-consultor-ES\web_ganadora\`. **[FALTA: subirla a `piezas/landing/`]**

**Desde el 21/10 la landing además tiene:**
- El píxel de Utmify y el script de UTMs de Utmify.
- Ya no tiene el píxel de Meta propio, porque Utmify dispara ese mismo píxel.

**Prompt para pedir que la web se modele de verdad:** `prompts/` (prompt B del informe §7).

## Anuncios (9, Cash Trap)

- **Versión 1:** inventada, no modelada del original. Matías la rechazó a las 22:35: «¿Vos querés que yo pierda plata?».
- **Versión 2:** modelada de 4 anuncios ganadores que pasó Matías desde la Biblioteca de Meta. Se armó entre las 22:38 y las 22:58.

| Nivel | Anuncio | Formato | Modelado de |
|---|---|---|---|
| C1 | ¿Por qué pensar como consultor? | Video dibujito | [ID_BIBLIOTECA_1] |
| C1 | La ventaja no es la inteligencia | Video 3D con cartel | [ID_BIBLIOTECA_2] |
| C1 | El manual perfecto… no existe… ¿o sí? | Placa | [ID_BIBLIOTECA_3] |
| C2 | ¿Presentaste una idea y nadie te la aprobó? (SCQA) | Video | [ID_BIBLIOTECA_1] |
| C2 | Los 3 marcos | Video 3D | [ID_BIBLIOTECA_2] |
| C2 | Herramientas | Carrusel de 6 placas | Páginas del libro |
| C3 | Qué hay dentro | Placa | Índice |
| C3 | Lo que recibes | Video | [ID_BIBLIOTECA_1] |
| C3 | Guía más 4 bonos (oferta) | Placa | [ID_BIBLIOTECA_3] |

- **Textos finales:** en `cerebro/ANUNCIOS_METODO_CONSULTOR.md`. Pedido de Matías a las 23:09: «ponele buenos copys en la descripcion fijate que usa la competencia». El resultado fue una frase de entrada más el índice completo.
- **Herramientas:**
  - Higgsfield para las imágenes y los clips de video.
  - ElevenLabs para la voz y la música.
  - ffmpeg y Pillow para el montaje.
  - Scripts en `D:\creativos\metodo-consultor-es\scripts\`: `guiones.py`, `audio.py`, `armar_videos.py` y `armar_placas_v2.py`.
- **Prompt de Matías para modelar los anuncios:** `prompts/` (prompt C del informe §7, literal).
- **Archivos:** `D:\creativos\metodo-consultor-es\anuncios_v2\`. Son pesados y quedan solo como ruta en `MEDIOS.md`.
- **Pendiente conocido:** los anuncios publicados todavía dicen «garantía de 15 días», incluida la voz del video C3.

## Checkout de Hotmart

- **Página de pago «En blanco»** ([ID_PAGINA_PAGO_HOTMART]) definida como estándar, con los 3 order bumps.
- **El link de la web lleva `?checkoutMode=10`:** sin eso no aparecen los bumps. Lo descubrió Matías.
- Detalle en `04_hotmart.md`.
