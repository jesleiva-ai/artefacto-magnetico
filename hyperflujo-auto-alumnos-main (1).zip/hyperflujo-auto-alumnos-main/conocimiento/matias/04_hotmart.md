# 04 · Hotmart

> Estado: **borrador**. Fuentes: `skills/embudo-hotmart-netlify/SKILL.md`, `cerebro/PROYECTO_metodo-consultor.md` e informe §2 y §8.

## Cómo se hizo

- **Herramienta:** **Claude en Chrome**, la extensión, con la sesión de Hotmart que Matías ya tenía abierta. **No se usó un MCP de Hotmart.** **[FALTA: preguntar a Matías si tiene un MCP de Hotmart y para qué lo usa]**
- **A mano lo hizo Matías:**
  - Abrir Chrome y aceptar los términos la primera vez.
  - Verificar que los bumps se ven.
  - Descubrir que hace falta `?checkoutMode=10`.
  - Conectar Hotmart con Utmify (webhooks).
- **Procedimiento paso a paso:** `skills/embudo-hotmart-netlify/SKILL.md`. Es la skill que se fue corrigiendo con lo que pasó en este lanzamiento.

## Productos (9)

- **Los 7 que se venden:** principal, 3 bumps, Kit, Prompts y Reuniones (ver `02_definicion_producto.md`).
- **Hay 2 en desuso:** Diagnóstico y Propuestas, que son módulos del Kit.
- **Campos de cada producto:**
  - Tipo eBook.
  - Descripción de más de 200 caracteres.
  - Idioma.
  - **País principal: Estados Unidos.** Matías: «cambialo a estados unidos yo siempre lo pongo asi».
  - Precio en **USD**, pago al contado. Matías: «Ponelo todo en dólares… con el convertidor de moneda se cambia solo».
  - **Garantía de 7 días.**
  - Imagen de 600×600.
  - Como contenido, un PDF de acceso al portal.
- **Precio en cada moneda:** Hotmart convierte solo. Además está prendida la conversión automática de moneda.

## Checkout y order bumps

- Herramientas → Apariencia de la Página de Pago → plantilla «En blanco» → Order Bump → un producto por vez → Guardar → Publicar → **Definir como estándar**.
- Link de la web: `https://pay.hotmart.com/[CODIGO_PRODUCTO]?checkoutMode=10` (ID público del checkout).

## Embudo de un clic

- **Embudo [EMBUDO_ID], activo:** Inicio → Kit → (Sí y No) → Prompts → (Sí y No) → Reuniones → (Sí y No) → Gracias.
- **Regla de Matías (20/10 23:54):** «si te compran o no te compran, le seguís ofreciendo productos en el backend». Ningún producto del embudo está incluido en otro.
- **Widget:** un solo código de Hotmart pegado en cada página de oferta.

## Afiliados, píxel y correos

- **Afiliados:** **[FALTA: preguntar a Matías]**. No se configuraron en estos chats.
- **Píxel en el producto de Hotmart:** quedó pendiente según `cerebro/PROYECTO_metodo-consultor.md`. **[FALTA: confirmar con Matías si lo cargó]**
- **Correos:** los de Hotmart por defecto, con un mail de acceso por producto comprado. **[FALTA: preguntar a Matías si personalizó algo]**
- **Utmify:** conectado por webhook. Lo hizo Matías.

## Problemas que hubo

- «Error interno del sistema» al guardar el precio: el producto queda como borrador y hay que buscarlo en la lista.
- Los bumps solo aceptan productos aprobados.
- El editor del embudo no deja mover una flecha. Hay que borrar la etapa y volver a crearla.
- Los bumps no se ven sin `?checkoutMode=10`, y en las pruebas desde Argentina o Brasil tampoco aparecen.
- Claves: ninguna. Todo se hizo con la sesión del navegador. Si en el futuro se usa la API, hay que conseguir `HOTMART_CLIENT_ID` y `HOTMART_CLIENT_SECRET` en Hotmart → Herramientas → Credenciales.
