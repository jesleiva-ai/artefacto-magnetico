# 05 · Meta Ads y Cash Trap

> Estado: **borrador**. Fuentes: `skills/cash-trap-cbo-oro/SKILL.md` (el método completo), `cerebro/PROYECTO_metodo-consultor.md` e informe §2 y §3.

## Cuenta y página

- **Portafolio:** The Daily Skillet.
- **Cuenta publicitaria:** morfi 1. El ID está tachado en el repo.
- **Página:** Estrategia Clara ([ID_PAGINA]). La creó Claude en el Chrome de Matías el 20/10, entre las 20:02 y las 20:20.
- **Píxel:** Metodo Consultor ES ([ID_PIXEL]). Matías lo compartió en las 3 cuentas publicitarias.

## Cómo se cargó

- **Con el conector de Meta Ads (MCP) desde Claude Code.** El orden fue:
  1. `ads_create_campaign`
  2. `ads_create_ad_set`
  3. `ads_create_creative` y `ads_create_ad`
  4. `ads_activate_entity`
- **Videos:** se subieron a Meta desde Higgsfield.
- **Imágenes:** se publicaron un rato en la web para que Meta las bajara, porque esa cuenta no permite subir archivos desde la PC.
- **Parámetros UTM de Utmify en los anuncios:** los cargó **Matías a mano** el 20/10 entre las 23:36 y las 23:44, y después publicó los «cambios sin publicar».

## Estructura exacta

| Nivel | Configuración |
|---|---|
| Campaña | «Metodo Consultor ES - Cash Trap», hoy renombrada por Matías a **«CONSULT 21/10»**. Objetivo ventas (OUTCOME_SALES), presupuesto en la campaña (CBO) de **USD 75 por día**. Arranque: 20/10 23:13 (creada) y 23:30 (prendida). |
| Conjunto | «Hispanos - Advantage+ - ES». Uno solo, público abierto Advantage+. **Países:** América del Norte, Central, del Sur, Caribe y España, **sin Argentina, Nicaragua ni Venezuela**. **Idiomas:** Español, Español (España) y Español (todos). Ubicaciones Advantage+. Optimiza compras con el píxel. |
| Anuncios | 9: 3 C1, 3 C2 y 3 C3 (ver `03_piezas_venta.md`). IA declarada. |
| Puntuación de Meta | 100 |

## Qué parte del método Cash Trap se aplicó

- **1 campaña, 1 conjunto y 9 anuncios (3 por nivel de conciencia):** sí.
- **USD 75 por día de arranque:** sí. Es la regla de Matías de arrancar con 50 o 75 según el producto.
- **País más idioma:** sí, con los 3 idiomas de español.
- **Ubicaciones Advantage+ sin sacar ninguna, puntuación de 90 o más:** sí (100).
- **Una sola campaña por cuenta:** sí, morfi 1 estaba vacía.
- **Largar a medianoche:** **no**. Se prendió a las 23:30 del 20/10, 30 minutos antes.
- **No tocar por 48 horas:** sí, hasta el 22/10 ~23:45. Según la regla, recién el día 3 se decide.

## Qué se miró cada día y qué se cambió

| Día | Qué se miró | Qué se cambió | Resultado |
|---|---|---|---|
| 20/10 (noche) | Que los 9 anuncios quedaran aprobados | Matías publicó los cambios de parámetros UTM | Activos 23:34 |
| 21/10 | Reporte automático de las 12:00 (sesión «Reporte diario 12:00 — Meta Ads») | Nada en la campaña. Solo el nombre, cambiado por Matías. **[FALTA: confirmar]** | Meta: 16 compras, ver `06_numeros.md` |
| 22/10 en adelante | **[FALTA]** | **[FALTA]** | **[FALTA]** |

- **[FALTA: preguntar a Matías]** Qué mira él en el Administrador de anuncios cada día y a qué hora.
