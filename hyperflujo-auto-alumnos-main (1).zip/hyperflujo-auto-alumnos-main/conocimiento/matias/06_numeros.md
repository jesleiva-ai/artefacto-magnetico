# 06 · Números

> Estado: **borrador**. Los números de Meta los leí con el conector de Meta Ads el 21/10/2026 por la tarde. Son lo que **Meta atribuye por el píxel**, no las ventas reales de Hotmart. Las ventas reales salen de la exportación de Hotmart. **[FALTA: Matías exporta y se guarda en `datos/`]**

## Meta Ads: campaña «CONSULT 21/10» (antes «Metodo Consultor ES - Cash Trap»)

| Día | Gasto (USD) | Compras (píxel) | Valor de compras (USD) | Costo por compra (USD) | ROAS |
|---|---|---|---|---|---|
| 20/10 | 0,09 | 0 | 0 | — | — |
| 21/10 (parcial, hasta la consulta) | 91,18 | 16 | 296,87 | 5,70 | 3,26 |
| **Total** | **91,27** | **16** | **296,87** | **5,70** | **3,25** |

- El valor por compra da USD 18,55 en promedio. **[FALTA: ver en Hotmart si incluye bumps y upsells]**
- **CSV crudo por anuncio y día:** **[FALTA: Matías exporta desde el Administrador de anuncios → Anuncios → Desglose por día → Exportar CSV, y se guarda tal cual en `datos/`]**

## Hotmart

- **Ventas por día, ingresos, reembolsos y primera venta:** **[FALTA: exportación de Hotmart → `datos/`]**. La exportación trae nombres y mails de compradores. En el repo va **solo con esas columnas tachadas**.

## Inversión por rubro

| Rubro | Monto | Fuente |
|---|---|---|
| Anuncios (Meta) | USD 91,27 hasta el 21/10 | conector Meta Ads |
| Higgsfield | ~110 créditos | informe §3. **[FALTA: valor en USD]** |
| ElevenLabs | 1.606 caracteres | **[FALTA: costo]** |
| Claude (plan) | **[FALTA]** | — |
| Netlify | **[FALTA: ¿plan gratis?]** | — |
| Hotmart (comisiones) | **[FALTA: sale de la exportación]** | — |
| Utmify | **[FALTA: plan]** | — |
