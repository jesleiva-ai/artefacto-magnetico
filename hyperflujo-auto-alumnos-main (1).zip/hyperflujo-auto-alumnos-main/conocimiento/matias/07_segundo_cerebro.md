# 07 · Segundo cerebro, skills y conectores

> Estado: **borrador**.

## Cómo está armado

- **Carpeta:** `D:\segundo-cerebro\`, con notas en Markdown y enlaces `[[...]]`.
- **Carpetas principales:**
  - `00_ENTRADA`: bandeja de entrada.
  - `04_CONTENIDOS`: anuncios.
  - `05_PROCESOS`: recetas, lecciones y skills.
  - `06_PROYECTOS`: un `PROYECTO.md` por producto.
- **Notas de este lanzamiento:** copiadas en `cerebro/`. Son:
  - `PROYECTO_metodo-consultor.md`
  - `ANUNCIOS_METODO_CONSULTOR.md`
  - `MODELADO_PASO_A_PASO.md` (la receta para repetirlo)
  - `ELEGIR_Y_MODELAR_OFERTAS.md`
  - `2026-10-19_cazador_3-ofertas.md`
  - `nota_compartida_oferta-consultoria-ES.md`
- **Instrucciones permanentes:**
  - Se cargan en cada chat de Claude Code desde la memoria del proyecto: hablar en español, garantía de 7 días, modelar como el Método del Consultor, no pedir confirmación salvo para plata o claves, y aceptar los términos de Meta y Hotmart avisando.
  - Además están `CLAUDE.md` del proyecto y `INSTRUCCIONES_IA.md` en el cerebro. **[FALTA: subir `INSTRUCCIONES_IA.md`, `LECCIONES.md` e `INICIO.md` del cerebro]**

## Skills (archivos completos en `skills/`)

| Skill | Para qué | Dónde vive en la PC |
|---|---|---|
| `cazador-de-ofertas` | Buscar y validar ofertas con Nexus Profit y la Biblioteca de Meta | Plugin de skills de la app de Claude |
| `modelar-ofertas` | Modelar una landing o un embudo que ya vende en otro idioma | Plugin de skills |
| `embudo-hotmart-netlify` | Bumps, upsell, downsells, widget y portal con candados | `~\.claude\skills\` (copia en el cerebro) |
| `cash-trap-cbo-oro` | El método de campaña | `~\.claude\skills\` |
| `operador-meta-ads` | Operar las cuentas con las reglas de Matías | `~\.claude\skills\` |
| `guardar-sesion` | Guardar lo aprendido en el cerebro | `~\.claude\skills\` |

**[FALTA: subir el resto de las skills que usa Matías]** La lista completa está en la app: alertas-campanas, anuncio-storytime-controversial, creativos-placas, escalera-de-valor, oferta-completa, revisar-landing, tablero-ventas y otras.

## Conectores (MCP) y herramientas

| Conector | Para qué | Cómo se instala |
|---|---|---|
| Nexus Profit | Buscar ofertas que venden | **[FALTA: preguntar a Matías]** |
| Meta Ads | Crear y leer campañas | Conector oficial de Meta en la app de Claude |
| Higgsfield | Imágenes y videos | Conector en la app de Claude |
| Claude en Chrome | Operar Hotmart y Meta con la sesión de Matías | Extensión de Chrome |
| Netlify | Publicar | Script con el token de la CLI de Netlify. `NETLIFY_AUTH_TOKEN` se saca con `netlify login` y queda en `%APPDATA%\netlify\Config\config.json` |
| ElevenLabs | Voz y música | API. `ELEVENLABS_API_KEY` se saca en elevenlabs.io → perfil → API Keys y va en `.env` |
| Codex (ChatGPT) | Arreglos de páginas en paralelo | App de Codex. **[FALTA: cómo lo usa Matías]** |

## Prompts que Matías repite

En `prompts/` y en `fuentes/informe_sesion_lanzamiento_consultor.md` §7:
- A: buscar oferta.
- B: modelar la web.
- C: modelar los 9 anuncios.
- D: armar la campaña.
- E: regla del embudo.
- F: medir países.
