# 08 · Problemas de automatización

> Estado: **borrador**. Salen de lo que pasó en los chats (informe §8 y esta sesión). Lo que Matías quiere que sea automático: **[FALTA: que lo complete Matías]**

## Lo que se hizo a mano o se trabó

1. **Carteles de permiso de la app:** uno por cada acción en Meta. Hubo 11 solo para prender la campaña. Matías se quejó varias veces: «Deja de pedirme permisos».
2. **Chrome desconectado:** errores de «grupo de pestañas». Hubo que reconectar el navegador y elegir el correcto varias veces.
3. **Términos de Meta y Hotmart:** la primera vez los tuvo que aceptar Matías.
4. **Bumps de Hotmart:** el truco de `?checkoutMode=10` lo descubrió Matías.
5. **Utmify:** la app bloqueó publicar el código cifrado. Matías cargó a mano los UTM en los anuncios. El script de UTMs en la página se instaló recién el 21/10, cuando soporte de Utmify avisó que las ventas llegaban sin UTMs.
6. **Dos chats publicando el mismo sitio:** un deploy de una sesión pisó la página de otra. La página que vende tuvo que restaurarla Codex.
7. **Copiar y pegar entre chats:** Matías hizo de puente entre la sesión principal, la de lanzamiento y Codex, por ejemplo cuando la sesión de Gessetti le habló en italiano.
8. **El conector de Meta Ads:**
   - No puede editar el texto de un anuncio publicado: hay que crear uno nuevo.
   - Arma creativos con campos que Meta ya no acepta («título y descripción del enlace obsoletos»). Hubo que completarlos en el Administrador de anuncios. Esto pasó en Gessetti.
9. **Subidas a Meta:**
   - Esa cuenta no permite subir archivos desde la PC.
   - Meta no baja imágenes desde Higgsfield.
   - Netlify falla con nombres en mayúsculas.
10. **Esperas:** que Hotmart apruebe los productos, que Meta revise los anuncios y las 48 horas sin tocar la campaña.
11. **Números:** las ventas reales están en Hotmart y el gasto en Meta. No hay un tablero que los cruce solo. **[FALTA: confirmar con Matías]**

## Lo que Matías querría que un sistema haga solo

**[FALTA: preguntar a Matías]**
