# 09 · Lo que haría distinto

> Estado: **borrador**. Lo de abajo son lecciones que **Matías ya dijo en los chats** y quedaron como reglas. Lo que él haría distinto: **[FALTA: que lo escriba Matías]**

**Lecciones que ya son reglas:**
- **Modelar, no inventar:** la web y los anuncios se copian en estructura del original desde el primer intento. Matías: «tenemos que modelar una oferta. ¿Vos querés que yo pierda plata?».
- **Garantía de 7 días desde el principio.**
- **Precio de 19,99** en vez de 17,90.
- **El embudo ofrece siempre el producto siguiente,** diga que sí o que no, y ningún producto del embudo está incluido en otro.
- **Utmify completo antes de prender:**
  - Script de UTMs y píxel en todas las páginas antes del checkout.
  - UTMs con `xcod` en cada anuncio.
  - Un solo píxel de Meta, el que dispara Utmify.
- **Una sola sesión publica cada carpeta del sitio,** y nunca se publica la página que vende desde una copia vieja del disco.
- **Prender a medianoche** (Cash Trap). El Consultor se prendió a las 23:30.

**Lo que haría distinto Matías:** **[FALTA: Matías]**
