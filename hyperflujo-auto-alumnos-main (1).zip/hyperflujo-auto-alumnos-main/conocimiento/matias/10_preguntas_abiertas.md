# 10 · Preguntas abiertas (todo lo marcado [FALTA])

## Para Matías

1. **Tiempos:** cuánto tiempo puso él en cada etapa (tabla en `00_linea_de_tiempo.md`).
2. **Exportaciones:**
   - El CSV de Meta Ads (anuncio y día).
   - La exportación de ventas de Hotmart, para tener la primera venta, las ventas por día, los ingresos y los reembolsos.
3. **Costos:**
   - Plan de Claude.
   - Valor del crédito de Higgsfield.
   - ElevenLabs.
   - Netlify.
   - Utmify.
   - Comisiones de Hotmart.
4. **Búsqueda de ofertas:**
   - ¿Usa Hotmart para buscar?
   - ¿Qué es el «Manual Maestro» y qué reglas trae?
   - ¿Buscó algo por su cuenta antes del 20/10?
5. **Hotmart:**
   - ¿Tiene un MCP de Hotmart?
   - ¿Configuró afiliados?
   - ¿Cargó el píxel en el producto?
   - ¿Personalizó los correos?
6. **Meta:**
   - ¿Qué mira cada día?
   - ¿Cambió algo además del nombre de la campaña?
7. **Codex:** ¿cómo lo usa y para qué, además de las páginas?
8. **Automatización:** ¿qué quiere que sea automático? (`08`)
9. **Lo que haría distinto** (`09`).

## Para completar desde archivos (no hace falta preguntar)

- El índice completo de las 7 partes del producto, desde `D:\creativos\metodo-consultor-es\contenido\`.
- La landing que vende (`web_ganadora\`), que va a `piezas/landing/`.
- Notas del cerebro que faltan subir: `INSTRUCCIONES_IA.md`, `LECCIONES.md` e `INICIO.md`.
- El resto de las skills.

## Lo que no está en ningún registro

Viene de `fuentes/informe_sesion_lanzamiento_consultor.md`:
- El aviso «qué oferta elegí y por qué» no quedó como mensaje aparte.
- Qué se hizo con el pedido «proba en flow» (20/10 21:21).
- La respuesta sobre países no hispanos (20/10 22:30).
- Los candidatos 18 a 23 de Nexus: la respuesta quedó cortada en el registro.
