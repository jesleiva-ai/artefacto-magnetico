# Caso 2 · Gessetti Profumati (el mismo proceso, repetido en italiano)

> Estado: **borrador corto**. Fuente: sesión «Segundo cerebro con IA» del 19 al 21/10. Sirve para ver qué se repite y qué cambió.

## Qué se repitió

- **Oferta modelada de la competencia** (SCENT & STONE, «The Aroma Stone Method»), vendida en otro idioma: **italiano, solo Italia**.
- **Precio de USD 19,99** y **garantía de 7 días**.
- **Producto:** guía de 38 páginas con 18 capítulos, 6 bonos y portal con candados.
- **Web** en laformulaebooks.site/gessetti-profumati/ con conversor de moneda.
- **Hotmart:** 3 bumps (solo se ven con `?checkoutMode=10` y comprando desde Italia o la UE), upsell de 39,99, upsell 2 de 14,99 y downsells. Embudo [EMBUDO_ID].
- **Cash Trap en la cuenta morfi 2,** USD 75 por día: 1 campaña, 1 conjunto (Italia, idioma italiano) y 9 anuncios (3 C1, 3 C2 y 3 C3), con un carrusel. Publicada el 21/10. **[FALTA: hora exacta]**
- **Utmify:**
  - Script de UTMs y píxel en las 8 páginas (21/10).
  - UTMs con `xcod` en los anuncios.
  - El píxel de Meta propio sigue en la página. **[FALTA: decidir si se saca como en el Consultor]**

## Qué cambió o falló

- **Los anuncios salieron «vacíos» en el Administrador:** los creativos personalizados por ubicación no se ven. Hubo que rehacerlos como imagen o video simple.
- **Error de «título y descripción del enlace obsoletos»** en los creativos creados por el conector. Se completaron título y descripción en el Administrador de anuncios.
- **La guía primero salió corta** (unas 7 páginas). Matías pidió de 35 a 40.
- **Hubo que hablarle a Matías en español:** una sesión le habló en italiano.

## Números

**[FALTA: Gessetti todavía no había vendido al 21/10]**
