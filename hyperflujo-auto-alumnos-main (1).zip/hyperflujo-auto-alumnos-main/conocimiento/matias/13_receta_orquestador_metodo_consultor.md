> Copia saneada de `12_metodo_consultor_handoff_agente.md` (repo matias-proceso-lanzamiento, versión del 2026-10-23), tomada el 2026-10-26. Sin la sección que sale de una clase de Ramiro (ver nota en su lugar). Lo que cambió después del 23/10 está en `notas/2026-10-26_novedades_del_metodo.md`.

# 12 · Handoff: el Método del Consultor como receta para lanzar ofertas con subagentes

**Para quién es:** el chat nuevo de Matías (el agente "orquestador") y el equipo de Hyperflujo. Con esto, el agente reparte el trabajo entre subagentes y lanza ofertas nuevas **igual** que El Método del Consultor, que es la que mejor vende.
**Cómo se usa:** pegá en el chat nuevo el bloque de la sección 1 ("Prompt para el orquestador"). El resto del archivo es la receta que va a leer el agente.
**Fuentes:** lo que se hizo en el chat del lanzamiento (20 y 21/10/2026), el cerebro (`D:\segundo-cerebro\`) y las reglas que fue dejando Matías hasta el 22/10. Lo que no está confirmado se marca **[FALTA]**.
**Anexos:** carpeta `D:\creativos\matias-proceso-lanzamiento\metodo_consultor\` (lista al final).

---

## 0. Por qué esta receta

- **Oferta original:** *Consulting Management EXPLAINED* (Business Explained, EE. UU., en inglés). Tenía ~140 anuncios activos y llevaba desde junio al aire; en español casi no había nadie.
- **Lo que se hizo:** se modeló en español como "El Método del Consultor", con producto propio, web modelada sección por sección, embudo de 6 productos y 9 anuncios copiados de los ganadores del original.
- **Resultado:** "se está vendiendo muy bien" (Matías, 21/10). **[FALTA: números de ventas, gasto y ROAS. Salen del reporte del 22/10 a las 12:30.]**
- **La regla de Matías:** "vamos a hacer así con todos los productos". **Nada se inventa: todo se modela.**

---

## 1. Prompt para el orquestador (copiar y pegar en el chat nuevo)

```
Sos el orquestador de lanzamientos de Matías. Tu trabajo es lanzar ofertas nuevas con la receta de "El Método del Consultor", repartiendo el trabajo entre subagentes.

Antes de nada, leé completos:
1. D:\creativos\matias-proceso-lanzamiento\12_metodo_consultor_handoff_agente.md (este archivo: receta, subagentes, controles y errores)
2. D:\segundo-cerebro\05_PROCESOS\MODELADO_PASO_A_PASO.md
3. D:\segundo-cerebro\05_PROCESOS\ELEGIR_Y_MODELAR_OFERTAS.md
4. D:\segundo-cerebro\05_PROCESOS\LECCIONES.md
5. D:\segundo-cerebro\06_PROYECTOS\metodo-consultor-ES\PROYECTO.md (el ejemplo terminado)

Reglas fijas:
- Hablame siempre en español rioplatense, simple.
- No me preguntes: decidí con la receta, avisá en una línea y seguí.
- Lo único que frena: contraseñas o códigos, mover plata y publicar o regenerar una página que ya está publicada.
- Podés prender las campañas vos. Cada oferta se prueba con USD 75 por día.
- Modelá todo; no inventes nada. LO QUE MÁS ME IMPORTA es cómo modelás las páginas web y los anuncios: seguí la sección 1 bis al pie de la letra. Yo tuve que meter mano y corregir las páginas y los anuncios; eso no puede volver a pasar.

Tarea: lanzá de 1 a 5 ofertas a la vez, cada una de punta a punta, con las fases y los subagentes de la sección 3. Cada oferta tiene su carpeta y su proyecto en el cerebro. Las tareas con cuentas (Hotmart, Facebook, publicar en Netlify) van de a una por vez, nunca en paralelo. Antes de gastar créditos en anuncios, mandame la hoja con los 9 ganadores elegidos y el plan de cada anuncio. Campañas: 48 horas sin tocar; si no vendió, se apaga; si vendió, 5 días sin tocar; después, +30% de presupuesto cada 48 horas. Al final de cada oferta, pasame un resumen corto: links, IDs, qué falta y cuánto se gastó.
```

---

## 1 bis. LO MÁS IMPORTANTE: cómo se modelan las páginas web y los anuncios

> Matías, 22/10: "Eso es lo más importante, lo que a mí más me interesa: cómo modela las páginas web y cómo modela los anuncios. Viste que yo las tuve que cambiar y meter mano y ayudarte."
> Las primeras versiones del Consultor (web y anuncios) se hicieron "a criterio" y hubo que tirarlas. Después Matías corrigió a mano las páginas de cinco productos. **Nada de esto puede volver a pasar.** Si una pieza no se parece a su original puesta al lado, está mal, aunque "quede linda".

### A. Modelar la página web (sin excepciones)

**La idea:** se copia la estructura, el orden, el tipo de imágenes y los gatillos de la página original y de las páginas que Matías dejó terminadas. Lo único propio son los textos, la marca y las imágenes nuevas. **No se agrega ni se saca una sección por gusto.**

**Paso a paso:**
1. **Desarmar la original** (skill `desarme-landing`): cada sección en orden, qué hace, qué imagen o video lleva, colores, botones, reloj y barra fija. Guardar `desarme_landing.md` **antes** de escribir una línea.
2. **Abrir la página terminada por Matías más parecida** (`D:\creativos\_referencia-paginas-mat\2026-10-21\`: `metodo-consultor.html`, `planos-listos.html`, `sueter-que-crece.html`, `music-adventure-kit.html`, `happy-little-eaters.html` o `mapa-del-mastil.html`) y copiar su estructura y sus estilos. La del Consultor que vende está en `D:\segundo-cerebro\06_PROYECTOS\metodo-consultor-ES\web_ganadora\`.
3. **Armarla con la skill `landing-modelada`** y el kit `kit-animaciones.css`. La skill tiene la receta completa; lo que más corrige Matías es esto:
   - **Cómo tiene que quedar:** la skill `web-como-metodo-consultor`: promesa con números, mockup grande, botón que desliza a la oferta, dolores, beneficios, lo que trae, bonus de regalo, oferta, compra, preguntas frecuentes, compra.
   - **Imágenes que venden:** foto hiperrealista de una persona usando el producto (en el Consultor, el empresario con el esquema del método al lado), mockup del pack, un mockup propio por cada bono y por cada oferta (el upsell con corona), vistas previas de páginas reales del producto en carrusel, y 5 o más videos cortos de uso (Higgsfield). Todo **sin texto adentro**: el texto se pone con código.
   - **Que se mueva:** promesa que cambia de color y flota, dolores que aparecen de a uno al bajar, botones grandes que laten, cambian de color y brillan, y barra fija que desliza a la oferta, con 50% OFF y cuenta regresiva.
   - **Opiniones:** la sección va armada y vacía, con `<!-- OPINIONES: las pone Mat -->`. Nunca se inventan.
4. **Comparar lado a lado antes de entregar:** captura de la original, de la página de Matías más parecida y de la nuestra, en celular y en compu. Si falta una sección, una animación o un tipo de imagen que la otra tiene, se agrega. Recién ahí se pasa el control de la sección 6 de `landing-modelada`.
5. **Una vez publicada, la página es de Matías.** No se rearma ni se republica sin su OK para ese cambio. Si él autoriza un cambio, se trabaja sobre la versión bajada de internet, nunca sobre los archivos viejos.

**Lo que Matías tuvo que corregir en el Consultor (que no vuelva a pasar).** Su crítica del 21/10, resumida:
- Imagen principal "hecha con Paint": en el original había una persona con IA mostrando el producto y un esquema al lado.
- No mostraba ejemplos del producto.
- Página "re apagada": sin colores ni animaciones.
- Sin mockups de bonos ni de ofertas (el original tiene la corona en la oferta especial).
- Sin videos de uso: el original tiene más de 5.
- Sin tabla comparativa.
- Botones chicos y quietos.
- Su frase: "vos no modelaste la página web, simplemente inventaste".

### B. Modelar los anuncios (sin excepciones)

**La idea:** **cada uno de nuestros 9 anuncios es la copia de un anuncio ganador del original**, uno a uno: mismo formato, misma escena, mismo encuadre y luz, mismo gancho y misma estructura de texto, con nuestra marca, nuestros números y nuestra oferta.

**Paso a paso:**
1. **Listar todos los anuncios activos del original** en la Biblioteca de Meta y ordenarlos por **días al aire** y **cantidad de copias** (cuantas más versiones del mismo, mejor funciona).
2. **Elegir los 9 mejores distintos** y clasificarlos: **3 C1** (no sabe que tiene el problema: historia, emoción, curiosidad), **3 C2** (conoce el problema: cómo funciona, qué trae, errores comunes) y **3 C3** (listo para comprar: oferta, lo que recibe, precio y garantía).
3. **Bajar la imagen o un fotograma de cada ganador** a `referencia_original\`.
4. **Plan de cada anuncio**, en una tabla con estas columnas: #, nivel, ID del ganador, días al aire, copias, formato, qué escena se copia, gancho y texto. **Se manda a Matías antes de gastar un crédito.**
5. **Producir copiando también la imagen:** si el ganador es un dibujito, el nuestro es un dibujito; si es una maqueta 3D con cartel, maqueta 3D con cartel; si es una foto hiperrealista, foto hiperrealista. **Nada de placas genéricas ni dibujos planos cuando el original usa fotos.** El texto del cartel o la placa se pone con código, con la letra y la posición del original.
6. **Texto del anuncio, igual que el original:** una frase de entrada según el nivel + "[Producto] te da un sistema probado para…" + **el índice completo** + bonos + "acceso inmediato · garantía de 7 días". Botón **Más información** o **Ver detalles**, nunca "Comprar" (Mat, 22/10). Contenido con IA declarado.
7. **Videos:**
   - Arrancan hablando en el segundo 0, sin silencios.
   - **Ninguna toma dura más de 4 s.**
   - Un solo subtítulo a la vez, de 2 o 3 palabras.
   - Música de fondo hasta el último cuadro.
   - Transiciones entre escenas y cierre de 2 s con el producto.
   - Voz con ElevenLabs.
8. **Hoja comparativa obligatoria:** los 9 ganadores arriba y los 9 nuestros abajo, en el mismo orden. Si uno de los nuestros no se parece a su ganador, se rehace antes de cargarlo.

**Lo que salió mal y no se repite:**
- **Consultor v1:** placas y videos inventados, sin modelar y sin música. Matías: "No entiendo por qué hiciste lo que vos quisiste, siendo y cuando que te estoy diciendo que tenemos que modelar una oferta. ¿Vos querés que yo pierda plata?". Se rehicieron.
- **Planos Listos:** textos modelados pero imágenes inventadas (dibujos beige contra las fotos de taller del original).
- **22/10:** se rehicieron los 9 anuncios de cinco productos por no elegir los ganadores desde el principio.
- **Videos con tomas de ~10 s**, en Planos Listos.

**Ejemplo bien hecho (Consultor v2):**

| Nivel | Anuncio | Modelado de |
|---|---|---|
| C1 | Video dibujito "¿Por qué pensar como consultor?" | [ID_BIBLIOTECA_1] (dibujito + escenas del libro) |
| C1 | Video 3D con cartel "La ventaja no es la inteligencia" | [ID_BIBLIOTECA_2] (maqueta 3D con cartel fijo) |
| C1 | Placa violeta "El manual perfecto… no existe… ¿o sí?" | [ID_BIBLIOTECA_3] (placa violeta con pila de productos) |
| C2 | Video "¿Presentaste una idea y nadie te la aprobó?" | [ID_BIBLIOTECA_1] |
| C2 | Video 3D "Los 3 marcos" | [ID_BIBLIOTECA_2] |
| C2 | Carrusel de 6 placas | Páginas del libro |
| C3 | Placa "Qué hay dentro" | Índice del texto |
| C3 | Video "Lo que recibes" | [ID_BIBLIOTECA_1] |
| C3 | Placa de la oferta | [ID_BIBLIOTECA_3] |

Detalle en `metodo_consultor\ANUNCIOS_METODO_CONSULTOR.md`.
**Lo que todavía no estaba en ese momento:** el elegir 9 ganadores distintos (allá fueron 4 ganadores para 9 anuncios) y la hoja comparativa. Desde el 22/10 son obligatorios.

---

## 2. Reglas que no se rompen (las dejó Matías)

| # | Regla | De dónde sale |
|---|---|---|
| 1 | **Modelar, no inventar.** Web, producto y anuncios copian la estructura, el formato y los ganchos del original. | Matías, 20/10 ("¿Vos querés que yo pierda plata?") |
| 2 | **Buscar ofertas:** 30 o más anuncios activos, mejor 40 o más (contados con la frase exacta del producto), más de 10 a 15 días al aire (mínimo 10), tienda-marca y no persona, ebook, guía o curso, y el idioma de destino libre. | Matías, 2026-10-26 |
| 3 | **Nada en portugués ni para Brasil.** Si el idioma está ocupado, se elige otro que no sea portugués. | Memoria `no-lanzar-en-portugues` (21/10) |
| 4 | **Idioma y países:** si el original vende en un solo país, se lanza en el mismo idioma en los otros países donde nadie lo vende. | Memoria `modelar-como-metodo-consultor` (Planos Listos) |
| 5 | **Todo en USD**, país principal **Estados Unidos** en Hotmart y conversor de moneda por IP en la web. | Matías, 20/10 |
| 6 | **Garantía 7 días en todos los productos, nunca 15.** Web, embudo y anuncios dicen lo mismo que Hotmart. | Matías, 21/10 |
| 7 | **Embudo:** diga que sí o que no, siempre se ofrece el producto siguiente. Ningún producto puede estar incluido en otro. | Matías, 21/10 |
| 8 | **Landing con la skill `landing-modelada`** y las páginas terminadas por Matías como modelo. | Memoria `landing-con-skill-de-mat` (21/10) |
| 9 | **No tocar webs publicadas:** no regenerar, no editar y no republicar sin el OK de Matías para ese cambio puntual. | Memorias `no-tocar-webs-de-mat` y `no-tocar-web` |
| 10 | **Anuncios: los 9 mejores ganadores del original, uno por cada anuncio nuestro.** Se modelan también las imágenes (escena, encuadre, luz y letra). | `MODELADO_PASO_A_PASO.md` §6 (22/10) |
| 11 | **Antes de gastar créditos en anuncios** se arma la hoja con los 9 ganadores y el plan de cada anuncio, se le manda al dueño como aviso y se sigue sin esperar. | `MODELADO_PASO_A_PASO.md` §6 (22/10) y Matías, 2026-10-26 (automático, sin pedir confirmación) |
| 12 | **Videos:** máximo 4 s por toma, un subtítulo a la vez, arrancan hablando en el segundo 0 y la música sigue hasta el final. | Memoria `videos-4-segundos-por-imagen` (22/10) |
| 13 | **Meta:** una sola campaña por cuenta publicitaria. Ubicaciones **por regiones** (nunca país por país), siempre sin Venezuela ni Nicaragua y sin los países donde ya vende el original. Idiomas en español: Español, Español (España) y Español (todos), **nunca inglés**. | `LECCIONES.md` (21 y 22/10) |
| 14 | **No se copian** testimonios inventados, contadores de compradores ni relojes falsos. El reloj va a una fecha real. | Tarea del 20/10 |
| 15 | **No preguntar ni cotizar:** gastar créditos de creativos y avisar después. Siguen frenando: contraseñas y mover plata. | Memorias `sin-cotizar-ni-preguntar` y `actuar-sin-preguntar` (21/10) |
| 15 bis | **El agente prende las campañas solo.** Cada oferta se prueba con **USD 75 por día**. | Matías, 22/10 |
| 15 ter | **Campañas:** 48 horas sin tocar. **Si no vendió en 48 h, se apaga.** Si vendió, se deja **5 días** sin tocar. Después, **+30% de presupuesto cada 48 horas**. | Matías, 22/10 |
| 15 quater | **De 1 a 5 ofertas a la vez.** | Matías, 22/10 |
| 16 | **Español neutro con "tú"** para todo el mercado hispano. | `LECCIONES.md` |


---

## 3. Cómo se reparte el trabajo (fases y subagentes)

```
FASE 1 Buscar ─► FASE 2 Desarmar + escribir (en paralelo) ─► FASE 3 Construir (en paralelo) ─► FASE 4 Cuentas (de a una) ─► FASE 5 Lanzar y cerrar
```

### Fase 1 · Buscar y validar (paralelo por idioma o nicho)

| Subagente | Hace | Entrega | Tiempo |
|---|---|---|---|
| **S1 Cazador** (uno por idioma o nicho) | Skill `cazador-de-ofertas`. Nexus: `descubrir_ofertas {min_copias:30, min_dias:10}`, después `{min_copias:10}` y `{orden:"velocidad"}`; `buscar_anuncios` por país en idiomas no hispanos; `tendencias`. Confirma cada candidata en la Biblioteca de Meta con el analizador de la skill. | Tabla de candidatos: nombre, nicho, links, activos, días, marca o persona, idioma libre y decisión | 30–40 min |
| **S2 Medidor de países** (solo para las elegidas) | Por país, tres búsquedas en la Biblioteca de Meta: el original en el idioma de destino, el original con su marca y la competencia genérica. | La tabla de países (como la §1b del `PROYECTO.md` del Consultor) y las regiones y exclusiones propuestas | 20 min |

**Control para pasar a la fase 2:** la oferta cumple la regla 2 con números de la Biblioteca de Meta y no cae en la 3. El orquestador avisa en una línea qué eligió y sigue.

### Fase 2 · Desarmar y escribir (paralelo)

| Subagente | Hace | Entrega | Tiempo |
|---|---|---|---|
| **S3 Desarmador** | Skill `desarme-landing` sobre la landing original. Lista **todos** los anuncios activos del original, los ordena por días al aire y cantidad de copias, elige los **9 mejores distintos** y los clasifica en 3 C1, 3 C2 y 3 C3. Baja la imagen o un fotograma de cada uno a `referencia_original\`. | `desarme_landing.md` (secciones en orden, colores, imágenes, videos, botones, reloj y barra fija) y `ganadores_9.md` (#, nivel, ID, días, copias, formato, gancho y texto) | 45 min |
| **S4 Escritor del producto** | Mismo temario y formato que el original, en versión **más completa**, en "tú". Referencia del Consultor: 48 herramientas en 7 partes, cada una con qué es, cuándo usarla, paso a paso, ejemplo y error común, más 4 bonos (~16.000 palabras). | `contenido\parte*.md` y `contenido\bono*.md` | 1–2 h |
| **S5 Escritor del backend** | 3 bumps, Kit (upsell), oferta 2 y oferta 3. **Ninguno incluido en otro** ni en el principal. | `contenido\extra_*.md` y `contenido\kit_*.md`, más `productos.py` con nombres, precios y descripciones | 1 h |

**Escalera (USD, garantía 7 días). Matías, 2026-10-26: «por lo general son un producto principal, tres order bump, un upsell y cinco downsells. Puede tener más o puede tener menos». La del Consultor:**

| Paso | Precio |
|---|---|
| Principal | 19,99 (se muestra como 50% off de 39,98, hasta una fecha real) |
| 3 order bumps | 9,99 cada uno |
| Upsell (Kit) | 34,90 |
| Oferta 2 | 17 |
| Oferta 3 | 12 |

**Control:** el temario cubre al del original; ningún extra repite contenido; las palabras alcanzan (más de 10.000 en el principal) **[FALTA: Matías no fijó un mínimo exacto; el Consultor tiene ~16.000]**.

### Fase 3 · Construir (paralelo, todo en disco: no publica)

| Subagente | Hace | Entrega | Tiempo |
|---|---|---|---|
| **S6 Landing** | Skill **`landing-modelada`**, con el kit `D:\creativos\_referencia-paginas-mat\kit-animaciones.css`. Abre la página de Matías más parecida (`D:\creativos\_referencia-paginas-mat\2026-10-21\`) y sigue el `desarme_landing.md` de S3. Imágenes y videos con Higgsfield, sin texto adentro. Conversor de moneda (tabla país → moneda) y píxel. | La carpeta de la landing lista para publicar y una captura de celular y de compu | 2–3 h |
| **S7 Portal y páginas del embudo** | Portal con candados (un candado por extra, que se abre con el link del PDF de acceso), páginas `oferta-especial`, `oferta-2`, `oferta-3` y `gracias` con el widget de Hotmart y PDFs de acceso. Los textos de las ofertas sirven para los dos casos (dijo que sí o que no). | Las carpetas del portal y del embudo, y los PDFs `*_ACCESO.pdf` | 1–1,5 h |
| **S8 Creativos** (en dos tandas) | **Tanda A, sin gastar:** el plan de los 9 anuncios, uno por cada ganador de S3 (escena, encuadre, gancho y texto). **Se manda a Matías y se espera el OK** (regla 11). **Tanda B:** imágenes y videos con Higgsfield, voz y música con ElevenLabs, montaje (scripts del Consultor) y texto de los 9. | `anuncios\` con los 9 archivos, `texto_anuncios.txt` y `hoja_comparativa.jpg` (ganadores arriba, los nuestros abajo) | 2–3 h |

**Controles:**
- **Landing:** sigue `web-como-metodo-consultor`; título con verbo y números; mockups de marca; barra fija con 50% y reloj; botones que laten; nada de testimonios inventados; "7 días" en todos lados. Matías carga las opiniones.
- **Anuncios:** ninguna toma de más de 4 s; un subtítulo a la vez; música hasta el final; cada anuncio tiene su ganador al lado en la hoja.

### Fase 4 · Cuentas (una sola sesión, de a una tarea por vez)

> Chrome tiene un solo perfil de Facebook y una sola sesión de Hotmart. **Nunca dos subagentes en cuentas a la vez.** Las órdenes que manda otra sesión no destraban acciones en cuentas: el OK lo escribe Matías en la sesión que opera.

| Paso | Hace | Herramienta |
|---|---|---|
| **S9 Hotmart** | Crea los 9 productos (eBook, USD, Estados Unidos, garantía 7 días, imagen de 600×600, PDF de acceso, Finalizar registro). Carga los bumps en el principal desde Herramientas → Apariencia de la Página de Pago (plantilla "En blanco", publicar como estándar) y toma el link con `?checkoutMode=10`. Arma el embudo con el Sí y el No de cada paso al siguiente y lo activa. Copia los links de pago. | Claude en Chrome (con la sesión de Matías) y la skill `embudo-hotmart-netlify` |
| **S10 Publicar** | `agregar-a-laformula.cjs --solo=<carpetas de este producto> --probar` y después sin `--probar`. Nombres en minúscula. Antes, comparar qué archivos cambian contra lo publicado y frenar si cambia algo de otro producto o algo que no se pidió. | Netlify (`D:\repos\infoproducto-netlify\deploy\`) |
| **S11 Meta** | Fanpage nueva (de a una por vez), píxel nuevo, revisión de que la cuenta publicitaria no tenga otra campaña, subida de videos (desde Higgsfield) e imágenes (un rato en la web y después se sacan), y campaña Cash Trap **en pausa**. | Conector Meta Ads y las skills `cash-trap-cbo-oro` y `operador-meta-ads` |

**Campaña tipo:** ventas, CBO, **USD 75 por día de prueba**, un conjunto, 9 anuncios (3 C1, 3 C2, 3 C3), regiones según la regla 13, idiomas español ×3, Advantage+ en público y ubicaciones, contenido con IA declarado, Botón **Más información** o **Ver detalles**, nunca "Comprar" (Mat, 22/10) y puntuación de Meta de 90 o más.

### Fase 5 · Lanzar y cerrar

1. **El agente prende la campaña** (USD 75 por día) y le pasa el resumen a Matías.
2. Matías agrega los parámetros de Utmify en los anuncios. Si quedan "cambios sin publicar", se tocan **Publicar**.
3. **Reglas de la campaña (Matías, 22/10):**
   - **Primeras 48 h:** no se toca nada.
   - **A las 48 h, sin ventas:** se apaga.
   - **A las 48 h, con ventas:** se deja **5 días** sin tocar.
   - **Después de esos 5 días:** **+30% de presupuesto cada 48 h**. La skill `cash-trap-cbo-oro` además pide ROAS 2 o más para subir; si el ROAS cae, no se sube y se cambia el anuncio que gastó sin vender por otro del mismo nivel.
   - Revisión con la skill `operador-meta-ads`.
4. Se guarda todo con `guardar-sesion`: el `PROYECTO.md` del producto, las lecciones y el registro en `07_REVISIONES\cambios-meta.md`.

---

### Cómo coordinar el equipo

> Esta sección del original resumía una clase de Ramiro («equipito-ia-infoproductos»). Por decisión de Ramiro, el material de sus clases no va en el repo de alumnos. Lo que sí es de Matías: «yo no quiero que me pidas permiso de nada… quiero tener subagentes, un director con sus empleados» (Matías, 2026-10-24), las tareas con cuentas de a una por vez y las reglas de la sección 2.

## 4. Estructura de carpetas por oferta

```
D:\creativos\<producto>-<idioma>\
  config.json            (marca, píxel, dominio, links de pago, IDs, widget)
  contenido\             (S4 y S5)
  referencia_original\   (S3: landing e imágenes de los 9 ganadores)
  ia\                    (imágenes y videos de Higgsfield)
  mockups\  pdf_acceso\  audio\  anuncios\
  scripts\               (copiados de D:\creativos\metodo-consultor-es\scripts\)
D:\repos\infoproducto-netlify\sitios\<producto>-landing\  y  portal-<producto>\
D:\segundo-cerebro\06_PROYECTOS\<producto>-<idioma>\PROYECTO.md
```

**Scripts del Consultor que se reusan** (copiar y cambiar textos): `productos.py`, `estilo.py` (con el conversor arreglado), `md.py`, `a_tu.py`, `armar_mockups.py`, `armar_portal.py`, `armar_web.py`, `guiones.py`, `audio.py`, `armar_videos.py` y `armar_placas_v2.py`.
⚠️ `armar_web.py` también arma una página de ventas vieja y **pisa la de la landing**. La landing nueva la arma S6 con `landing-modelada`. Una vez publicada, **ningún script vuelve a tocar esa carpeta**.

---

## 5. Errores que ya pasaron y no se repiten

| Error | Qué pasó | Cómo se evita |
|---|---|---|
| Web y anuncios inventados | Primera versión del Consultor hecha a criterio; hubo que tirarla | Fase 2 obligatoria antes de construir (S3) |
| Anuncios con imágenes inventadas | Planos Listos: texto modelado, imágenes en dibujo contra fotos de taller | Regla 10: copiar escena, encuadre y luz del ganador |
| Se rehicieron los 9 anuncios de cinco productos | No se modelaron los ganadores desde el principio | Regla 11: plan con OK antes de gastar |
| Kit con los downsells adentro | Se ofrecía lo mismo dos veces | Regla 7 y control de la fase 2 |
| Garantía de 15 días | Hubo que cambiar 9 productos, la web y quedaron anuncios mal | Regla 6 desde el principio |
| Imágenes de la web pisadas | Rearmar el backend pisó la página publicada (00:03 y 00:24 del 21/10) | Regla 9; S10 compara antes de publicar |
| Utmify borrado | Publicar desde una copia vieja borró el código que había puesto otra sesión | Bajar lo publicado antes de cualquier cambio autorizado |
| Otra sesión publicó carpetas ajenas | El script subía todo lo que tenía en `CARPETAS` | Siempre `--solo=` con las carpetas propias |
| Bumps que no se veían | Faltaba el link con `?checkoutMode=10` | Paso fijo de S9 |
| Productos en otra moneda o país | — | Regla 5 |
| Países sueltos o inglés en los idiomas | Una sesión cargó países uno por uno; en otra se coló inglés | Regla 13; revisar en pantalla antes de guardar |
| Fanpage equivocada | Varias sesiones publicaban en Facebook a la vez | Fase 4 de a una |
| Sesión que le hablaba a Matías en italiano | — | Al dueño siempre en español |
| Silencios y tomas largas en los videos | Planos Listos tenía tomas de ~10 s | Regla 12; medir cada escena |
| Nombres con mayúsculas en Netlify | El archivo no quedaba bien subido | Todo en minúscula |
| Imágenes para Meta desde Higgsfield | Meta no las baja desde ese servidor | Subirlas un rato a la web y sacarlas después |
| Código de seguimiento cifrado | La app no deja publicarlo | Lo pega Matías (Netlify → Snippet injection) |

---

## 6. Estado

El estado de cada lanzamiento va en su `PROYECTO.md` y en los reportes diarios. Lo vigente del método está en `recetas/metodo-consultor/RECETA.md`.

---

## 7. Datos del ejemplo terminado (para copiar el formato)

- **Web:** https://laformulaebooks.site/metodo-consultor/ · **Portal:** https://laformulaebooks.site/portal-metodo-consultor/
- **Hotmart:** principal [CODIGO_PRODUCTO] · bumps [CODIGO_PRODUCTO], [CODIGO_PRODUCTO] y [CODIGO_PRODUCTO] · Kit [CODIGO_PRODUCTO] · Prompts [CODIGO_PRODUCTO] · Reuniones [CODIGO_PRODUCTO] · embudo [EMBUDO_ID] · página de pago [ID_PAGINA_PAGO_HOTMART]
- **Meta:**
  - Portafolio [PORTAFOLIO] · cuenta [act_CUENTA]
  - Página Estrategia Clara [ID_PAGINA] · píxel [ID_PIXEL]
  - Campaña [ID_CAMPANA] · conjunto [ID_CONJUNTO]
- **Anuncios ganadores modelados:** [ID_BIBLIOTECA_1], [ID_BIBLIOTECA_3], [ID_BIBLIOTECA_2] y [ID_BIBLIOTECA_4]
- **Costos:** Higgsfield ~110 créditos y ElevenLabs ~1.600 caracteres por producto.
- **Claves:**
  - `ELEVENLABS_API_KEY` en `[DATO_PERSONAL]\Documents\reel-con-claude\.env`.
  - El token de Netlify sale de `netlify login` (queda en `%APPDATA%\netlify\Config\config.json`).
  - Hotmart y Facebook van con la sesión de Matías en Chrome. Nunca se escriben contraseñas.

---

## 8. Preguntas para Matías

Respondidas: USD 75 por día · el agente prende las campañas · de 1 a 5 ofertas a la vez · 48 h → apagar o 5 días → +30 % cada 48 h (22/10); días al aire, mínimo 10 y mejor 15 (26/10); escalera 1 + 3 + 1 + 5 por lo general (26/10).

---

### Anexos (`metodo_consultor\`)
- `PROYECTO_metodo-consultor.md`, `MODELADO_PASO_A_PASO.md`, `ELEGIR_Y_MODELAR_OFERTAS.md`, `LECCIONES.md` y `ANUNCIOS_METODO_CONSULTOR.md` (copias del cerebro)
- `skills\`: `landing-modelada`, `desarme-landing`, `escalera-de-valor`, `oferta-completa`, `embudo-hotmart-netlify`, `cash-trap-cbo-oro`, `operador-meta-ads` y `guardar-sesion` (las de búsqueda ya están en `busqueda\skills\`)
- `memoria_reglas_de_mat\`: las reglas de memoria que citan las secciones 2 y 5
- Handoff anterior (búsqueda y cronología del lanzamiento): `11_busqueda_productos_handoff.md`

Escrito el 22/10/2026.
