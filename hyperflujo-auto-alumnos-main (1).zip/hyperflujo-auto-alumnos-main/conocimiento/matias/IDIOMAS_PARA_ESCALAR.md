# Idiomas para escalar un producto que vende

**Fecha:** 2026-10-26. **Fuente:** Matías, 2026-10-26: «hay más de 25 idiomas en los que se puede vender los productos para poder escalar». Medición del Método del Consultor en la Biblioteca de Meta (25/10/2026, `06_PROYECTOS/ofertas/2026-10-25_mercado_metodo-consultor_mas-idiomas.md` del cerebro de Matías) y lanzamientos del 25 y 26/10.

**Cómo se usa:** un producto que ya vende en un idioma se escala lanzándolo en el siguiente idioma de esta lista, **nunca duplicando la campaña en otra cuenta del mismo mercado**. Cada idioma lleva su web calco (`recetas/metodo-consultor/RECETA.md` §5 B), su píxel, su cuenta publicitaria y su campaña de USD 75 por día. Antes de cada uno, la competencia se vuelve a medir en vivo: la Biblioteca cambia todos los días.

**Nunca:** portugués ni Brasil (Matías, 2026-10-21: «portugués es un mercado peligroso»).

| # | Idioma | Países | Estado con el Consultor (26/10) | Poder de compra para USD 20 | A tener en cuenta |
|---|---|---|---|---|---|
| 1 | Español | Latinoamérica (sin AR, NI, VE) + España | **Vende** (producto madre) | Medio | Español neutro con «tú» |
| 2 | Inglés | EE. UU., Reino Unido, Canadá, Australia | Idioma del original del Consultor: no se compite con él. Sí para otros productos (Happy Little Eaters, Music Adventure Kit) | Alto | Solo si el original no vende en inglés |
| 3 | Alemán | Alemania, Austria, Suiza | Lanzado 25/10 | Alto | Sin competencia local medida |
| 4 | Francés | Francia, Bélgica, Suiza, Luxemburgo, Canadá | Lanzado 25/10 | Alto | La IA traduce muy bien; «vous» |
| 5 | Italiano | Italia | Lanzado 25/10 | Medio-alto | 1 competidor que vende otra cosa |
| 6 | Neerlandés | Países Bajos, Bélgica | Lanzado 25/10 | Alto | Muchos compran directo en inglés |
| 7 | Polaco | Polonia | Lanzado 25/10 | Medio | Sin competencia; anuncios más baratos |
| 8 | Japonés | Japón | Lanzado 25/10 | Alto | Formalidad: segunda pasada de naturalidad; pagos con JCB a revisar |
| 9 | Rumano | Rumania, Moldavia | Lanzado 25–26/10 | Medio-bajo | Anuncios baratos |
| 10 | Árabe | Arabia Saudita, Emiratos, Kuwait, Catar, Baréin, Omán | Lanzado 25–26/10 | Alto (Golfo) | Derecha a izquierda (`dir="rtl"`, Noto Sans Arabic); árabe estándar; Egipto afuera al principio |
| 11 | Sueco | Suecia | Lanzado 25–26/10 | Muy alto | Leen inglés |
| 12 | Checo | Chequia | Lanzado 25–26/10 | Medio | Mercado chico |
| 13 | Hebreo | Israel | Lanzado 25–26/10 | Alto | Derecha a izquierda (Noto Sans Hebrew); comentarios sensibles |
| 14 | Coreano | Corea del Sur | En cola | Alto | Facebook se usa poco (Kakao/Naver); formalidad |
| 15 | Chino tradicional | Taiwán, Hong Kong | En cola | Alto | Pedir chino **tradicional**, no simplificado |
| 16 | Danés | Dinamarca | En cola | Muy alto | Idioma chico; leen inglés |
| 17 | Noruego | Noruega | En cola | Muy alto | Idioma chico; leen inglés |
| 18 | Finlandés | Finlandia | En cola | Alto | Difícil para la IA: revisión nativa |
| 19 | Griego | Grecia | En cola | Medio | Mercado chico |
| 20 | Húngaro | Hungría | En cola | Medio-bajo | Difícil para la IA: revisión nativa |
| 21 | Turco | Turquía | No por ahora | Bajo | Lira devaluada |
| 22 | Indonesio | Indonesia | No por ahora | Bajo | El original casi no invierte ahí |
| 23 | Vietnamita | Vietnam | No por ahora | Bajo | La Biblioteca trae mucho ruido |
| 24 | Tailandés | Tailandia | No por ahora | Medio-bajo | Ruido en la Biblioteca; la IA traduce peor |
| 25 | Ucraniano | Ucrania | No por ahora | Bajo | Guerra: pagos inciertos |

**Orden recomendado para el próximo producto** (de la medición del 25/10): francés, italiano, neerlandés, japonés, polaco, escandinavos, chino tradicional y árabe del Golfo; después coreano, rumano, checo y hebreo.

**Lo que no se pudo medir y se revisa antes de cada uno:** medios de pago de Hotmart en el país (en el checkout), costo real del anuncio (CPM) y si el original vende de verdad (la Biblioteca muestra adónde llega, no las ventas).
