# Mapa de mercados para lanzar en todo el mundo

**Fuente:** campañas reales de Workaholics (Meta Ads) y ventas netas de Hotmart, 21–29/10/2026, 3 a 8 días por idioma. ROAS = ingreso neto Hotmart / gasto Meta. Es una guía: cada nicho rinde distinto. Versión visual: `mapa-de-mercados.html` (misma carpeta).

**Cómo se usa:** con un producto ya validado, se lanza en el siguiente idioma de esta lista con web **calco** (receta `recetas/metodo-consultor/RECETA.md` §3 y §5 B), un píxel nuevo por producto e idioma, una cuenta publicitaria por idioma y campaña Cash Trap de USD 75/día. Automático, sin preguntar salvo contraseñas, códigos o tarjetas.

| Estado | Idioma | Países a segmentar en Meta | Idioma en Meta | ROAS (acumulado) | A tener en cuenta |
|---|---|---|---|---|---|
| Rinde | Italiano | Italia, Suiza, San Marino | Italiano | 2,81 | El mejor. Cobro en EUR; 60 % paga con PayPal. Primer idioma para escalar. |
| Rinde | Japonés | Japón | Japonés | 2,04 | 4 productos por comprador. Formal (です/ます), segunda pasada de naturalidad. |
| Vende | Español | Regiones: América del Norte, Central, del Sur, Caribe + España. Excluir AR, NI, VE (flojos: CL, DO, EC, SV) | Español ×3, nunca inglés | 1,0–1,45 | El de más volumen. Rinden Bolivia, Paraguay, Costa Rica. |
| Vende | Árabe del Golfo | Arabia Saudita, Kuwait, Catar, Baréin (sin Omán ni Emiratos) | Árabe | 1,35 | dir="rtl", Noto Sans Arabic. Kuwait 5,27. |
| Vende | Alemán | Alemania, Austria, Suiza, Liechtenstein, Luxemburgo | Alemán | 1,09 | Compra Alemania (1,90); AT/CH gastan sin vender. |
| Vende | Hebreo | Israel | Hebreo | 0,97 (subiendo) | dir="rtl", Noto Sans Hebrew. |
| Vende | Neerlandés | Países Bajos, Bélgica | Neerlandés | 0,95 | Bélgica sin ventas. |
| Vende | Rumano | Rumania, Moldavia | Rumano | 0,91 | Anuncios baratos. |
| Flojo | Polaco | Polonia | Polaco | 0,58 | Cobro en EUR vs zł; revisar BLIK. |
| Flojo | Sueco | Suecia | Sueco | 0,65 | CPM caro; Apple Pay falló; revisar Swish/Klarna. |
| Flojo | Checo | Chequia, Eslovaquia | Checo | 0,62 | Eslovaquia sin ventas. |
| Flojo | Francés | Francia, Bélgica, Suiza, Luxemburgo (+ Canadá francés) | Francés | 0 | Sin ventas en 67 h con nuestro producto; probar chico. |
| Sin probar | Inglés | EE. UU., Reino Unido, Canadá, Australia, Nueva Zelanda, Irlanda | Inglés (todos) | — | Solo si el original no vende en inglés. India: precio local + UPI. |
| Sin probar | Danés · Noruego · Finlandés · Griego · Húngaro · Coreano · Chino tradicional | Dinamarca · Noruega · Finlandia · Grecia/Chipre · Hungría · Corea del Sur · Taiwán/Hong Kong | El de cada país | — | Finlandés y húngaro: revisión nativa. Chino: tradicional. |

**Nunca:** portugués ni Brasil.

## Reglas
- **Calco, no versión nueva:** se traduce web, portal, embudo y anuncios tal cual; solo cambian texto, links de pago y píxel.
- **Un píxel por producto e idioma**, creado desde el selector «Conjunto de datos» del conjunto en la cuenta publicitaria (así nace con acceso; si no, «Account does not have access to pixel»).
- **Una campaña por cuenta publicitaria**; nunca duplicar la misma campaña en varias cuentas del mismo mercado.
- **Regiones de Meta, no país por país**; idioma de Meta siempre el del mercado.
- **Precio que coincida con el checkout:** en Europa Hotmart cobra en EUR; aclararlo en la web y revisar medios de pago locales.
- **Cash Trap:** 1 campaña, 1 conjunto, 9 anuncios (3 C1, 3 C2, 3 C3), USD 75/día; 48 h sin tocar; sin ventas a las 48 h se apaga; con ventas, 5 días sin tocar.
