# 3 ofertas para modelar — 2026-10-19

- **Fuente:** robot Nexus Profit (bóveda + biblioteca global), skill `cazador-de-ofertas`.
- **Reglas:** 20+ copias · 15+ días · sin "pocas impresiones" · 100% digital · sin marca personal.
- **Revisadas:** 9 que cumplen las reglas (3 de la bóveda, 6 de la global) → 3 elegidas, 3 descartadas, 2 en duda.
- **Panel:** https://nexusprofit.lat/informes-ia/58
- **Estado:** las 3 "falta confirmar": falta escanearlas en la Biblioteca de Meta.

| # | Oferta | Formato | Origen | Copias | Días | Precio | Puntaje | Seguridad |
|---|---|---|---|---|---|---|---|---|
| 1 | The Aroma Stone Method | Guía PDF | EE. UU. (inglés) | 32 en 15 creativos | 40 | US$ 19,99 (tachado 39,98) | 74 | 🟡 Media |
| 2 | WynalazLab, 120 proyectos de cartón para chicos | Pack PDF + videos | Polonia (+ checo) | 35 (+5 en checo) | 18 | US$ 19 | 74 | 🟡 Media |
| 3 | Helados artesanales para vender | Ebook de recetas | Global (español) | 54 | 84 | Aporte voluntario, por mensaje | 75 | 🟡 Media |

## 1. The Aroma Stone Method — 🟡 Media · 74/100 · falta confirmar
- **Qué vende:** guía para hacer difusores aromáticos de yeso (aroma stones, piezas decorativas, flores) para decorar, regalar o vender.
- **Señales de la landing:** Impultienda, píxel de Meta, garantía 15 días, bonos, "2.300+ descargas" (no verificado), escasez.
- **Cómo modelarlo:** ebook paso a paso en español/portugués + bonos (moldes, aromas, cómo venderlos). Cruza bien con velas, jabones y macramé.
- **Anunciante:** SCENT & STONE Studio, 100% en este producto, índice de inversión alto (62/100, no es dinero). [Perfil](https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&media_type=all&search_type=keyword_exact_phrase&q=SCENT%20%26%20STONE%20Studio) · [Landing](https://scent-stone-studio.impultienda.ar/)

## 2. WynalazLab — 🟡 Media · 74/100 · falta confirmar
- **Qué vende:** +120 proyectos para chicos de 5–12 años con cartón y cosas de la casa, con videos. Ángulo: menos pantalla.
- **Señales:** Impultienda, píxel de Meta, garantía 30 días, bonos, 1,9 copias por día. El mismo producto ya está en polaco y checo → escaló.
- **Cómo modelarlo:** pack imprimible + videos en español, portugués e inglés. Anuncios con manos y proyectos, **sin caras de chicos**.
- **Anunciante:** Crecer en casa, 88% en este producto. [Perfil](https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&media_type=all&search_type=keyword_exact_phrase&q=Crecer%20en%20casa) · [Landing](https://plinventalab.impultienda.ar/)

## 3. Helados artesanales — 🟡 Media · 75/100 · falta confirmar
- **Qué vende:** +30 recetas de helados artesanales para preparar y vender desde casa, con bonos.
- **Señales:** vende por mensaje con "aporte voluntario" (sin landing); 84 días al aire.
- **Cómo modelarlo:** ebook de recetas + costos y venta, con landing propia en Hotmart. Ángulo de ingreso extra desde casa, **sin prometer ganancias**.
- **Anunciante:** Gaia EduMarket. [Perfil](https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&media_type=all&search_type=page&view_all_page_id=[ID_META_TERCERO])

### Competencia de The Aroma Stone Method en México (2026-10-20) — 🟢 Entrada viable
- **Panel:** https://nexusprofit.lat/informes-ia/59
- **Base Nexus:** 0 competidores.
- **Meta (3/3 búsquedas completas):** "piedras aromáticas" 27 anuncios activos (97% leído) · "difusor de yeso" 5 (100%) · "piedras de aroma" frase exacta 1 (100%). La búsqueda sin comillas de "piedras de aroma" trajo ruido (apps de series, spas) y se reemplazó por la exacta.
- **Competidor directo (1):** Método Piedras de Aroma — guía digital en Impultienda, **1 anuncio en todo el mundo desde el 18/10**, US$ 16,90 + 8 bonos, garantía 15 días. Está probando, no escalando.
- **Mercado amplio (no directo):** Camila Navarro (guía de aromas para casa que incluye yeso, 3 anuncios), Crea, Encanta & Emprende (recuerdos para eventos), Resin Art y BioAlei (talleres presenciales).
- **Cómo entrar:** ebook en español con materiales para México, calculadora de precios y souvenirs como bonos; precio y bonos propios frente a los US$ 16,90 + 8 bonos del competidor.

### 2026-10-20 — Se modela en italiano
- El original (SCENT & STONE Studio) escaló: ~90 anuncios activos, 85 en EE. UU. En la base de Nexus ahora figura con el id **81093**.
- Se eligió **italiano** (español saturado, alemán libre como segundo mercado). Todo en [[PROYECTO]] (`06_PROYECTOS/gessetti-profumati-IT`).

## Descartadas
- Luiz eugenio fagundes (Método 555): marca personal con promesas de ganancia.
- DramaBox: app de series cortas, marca conocida.
- Dow Janes: marca conocida de educación financiera, vende con webinar.

## En duda
- Sofia Shan (200 almuerzos fitness, AR): posible marca personal; no se ve hace 14 días.
- _savio07 (Hotmart BR): anuncio sin texto; falta ver qué vende.

## Próximos pasos
1. Escanear las 3 en la Biblioteca de Meta (sube la seguridad).
2. Elegir país/idioma de venta y medir la competencia (etapa 2). **2026-10-19:** Mat vende en cualquier mercado; primero analiza las ofertas y después se elige el mercado. Etapa 2 en pausa.
3. `desarme-landing` → `oferta-completa` → `escalera-de-valor` → `modelar-ofertas` → `lanzar-en-hotmart`.

---
Relacionado: [[ROBOT_NEXUS_PROFIT]] · [[ELEGIR_Y_MODELAR_OFERTAS]]
Volver a [[INICIO]]
