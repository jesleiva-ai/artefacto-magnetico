# Anuncios: El Método del Consultor (español) — v2 modelada

**2026-10-20 · rehechos modelando los ganadores que pasó Mat** (la v1 de placas propias quedó descartada: no estaba modelada).
Campaña Cash Trap **prendida** en morfi 1 ([ID_CAMPANA]): USD 75/día, América del Norte + Central + Sur + Caribe + España sin AR/NI/VE, idiomas Español ×3. Puntuación Meta 100.
Página: **Estrategia Clara** ([ID_PAGINA]) · Píxel **Metodo Consultor ES** ([ID_PIXEL]) en **morfi 1** · Botón: **Comprar** · Link: https://laformulaebooks.site/metodo-consultor/
Archivos: `D:\creativos\metodo-consultor-es\anuncios_v2\` · scripts: `guiones.py`, `audio.py`, `armar_videos.py`, `armar_placas_v2.py`.

## Los anuncios de referencia (Business Explained, "Your Consulting Management Guide")

| ID | Formato | Qué hace |
|---|---|---|
| [ID_BIBLIOTECA_1] | Video 48 s, activo desde 20/06 | Dibujito surrealista de gancho ("¿Por qué es importante aprender a resolver problemas como un consultor?"), montaña de papeles, libro en mano, dedo sobre el póster de 6 pasos, libro abierto, cierre "Necesitas la estructura". Voz en off + subtítulos. |
| [ID_BIBLIOTECA_2] | Video 44 s | Maqueta 3D en miniatura + cartel fijo "THE MCKINSEY ADVANTAGE ISN'T IQ", voz en off + subtítulos. |
| [ID_BIBLIOTECA_3] / [ID_BIBLIOTECA_4] | Placa | Fondo violeta, titular "Perfect business bundle doesn't exist…", pila de productos. |

Los 80+ anuncios del original llevan **el mismo texto**: frase de entrada + índice completo. Se modeló igual.

## Los 9

| # | Nivel | Formato | Modelado de | Archivo |
|---|---|---|---|---|
| 1 | C1 | Video 39 s: dibujito + escenas reales | [ID_BIBLIOTECA_1] | `C1-por-que-pensar-como-consultor_9x16.mp4` |
| 2 | C1 | Video 27 s: maqueta 3D + muñeco con micrófono + cartel "La ventaja de las grandes consultoras no es la inteligencia" | [ID_BIBLIOTECA_2] | `C1-la-ventaja-no-es-la-inteligencia_9x16.mp4` |
| 3 | C1 | Placa violeta "El manual perfecto… no existe… ¿o sí?" + pila de productos | [ID_BIBLIOTECA_3] | `C1-manual-perfecto-no-existe_4x5/9x16.png` |
| 4 | C2 | Video 25 s: dibujito ("¿Presentaste una idea y nadie te la aprobó?") + SCQA | [ID_BIBLIOTECA_1] | `C2-ideas-que-no-se-aprueban_9x16.mp4` |
| 5 | C2 | Video 28 s: maqueta 3D + cartel "Los 3 marcos que usan los consultores" (SCQA, MECE, ICE) | [ID_BIBLIOTECA_2] | `C2-los-3-marcos_9x16.mp4` |
| 6 | C2 | Carrusel 6 placas: 4 herramientas + cierre | Páginas del libro del ganador | `C2-carrusel-5-herramientas_1..6_4x5.png` |
| 7 | C3 | Placa "Qué hay dentro" (la que aprobó Mat) con foto real del producto | Índice del texto | `C3-que-hay-dentro_4x5/9x16.png` |
| 8 | C3 | Video 28 s: libro, índice, páginas, bonos + precio de lanzamiento y garantía | [ID_BIBLIOTECA_1] | `C3-lo-que-recibes_9x16.mp4` |
| 9 | C3 | Placa violeta pila de productos + "50% OFF · precio de lanzamiento" + garantía | [ID_BIBLIOTECA_3] | `C3-guia-mas-4-bonos-oferta_4x5/9x16.png` |

- Videos: voz en off en español (ElevenLabs, voz Enrique Mondragón), subtítulos de 2-3 palabras en recuadro, **música de fondo** (ElevenLabs Music), cierre de 2 s con el producto. Audio nivelado a -15 LUFS.
- Imágenes y clips: Higgsfield (gpt_image_2_5 + Kling 3.0). Textos de venta compuestos con código, no dibujados por la IA (regla de `modelar-ofertas`).

## Texto para Meta (los 9)
Archivo: `anuncios_v2\texto_anuncios.txt`. Arranca: "El Método del Consultor te da un sistema probado para resolver cualquier problema de negocio." + índice completo de las 7 partes y 48 capítulos + bonos + "Guía digital en español · acceso inmediato · garantía de 7 días (los anuncios publicados todavía dicen 15)".
Título sugerido: **Instant PDF → "Guía digital · acceso inmediato"**.

## Lo que NO se modeló
- Las cifras de Trustpilot y "80.000+ profesionales" (no son nuestras).
- "Un consultor reacciona a este libro" (sería una opinión inventada).

## Costos (2026-10-20)
- Higgsfield: ~109 créditos en total entre la web y estos anuncios (saldo 1.020,41 → 911,41).
- ElevenLabs: 1.606 caracteres (5 voces + música), medido con el contador de la cuenta.

---
Relacionado: [[PROYECTO]] · [[ESTRATEGIA_DE_ANUNCIOS]] · [[METODO_STORYTIME_CONTROVERSIAL]]
Volver a [[INICIO]]
