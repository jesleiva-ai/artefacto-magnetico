> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/CONTROL_ANTES_DE_PUBLICAR.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-21. IDs reemplazados por marcadores.

# Control antes de publicar (receta del Método del Consultor)

Fuente: Mat, 2026-10-21. Planos Listos salió sin seguir la receta, y la sesión anotó como hecho lo que no estaba hecho. Esta lista se revisa **con los archivos a la vista**, no con lo que diga la sesión. Si falta un punto, no se publica ni se carga la campaña.

Receta completa: [[MODELADO_PASO_A_PASO]] · [[ELEGIR_Y_MODELAR_OFERTAS]].

> **Webs ya publicadas (Mat, 2026-10-21):** Mat las corrige a mano. Ninguna sesión vuelve a armar, editar ni publicar una página que ya está en internet sin su OK para ese cambio. Los scripts `armar_landing.py` y `armar_portal.py`, y la publicación con `agregar-a-laformula.cjs`, le pisan las correcciones.

## 1. Oferta
- [ ] El destino está libre. Puede ser el mismo idioma en otros países, si ahí nadie vende la oferta con volumen (medido país por país), o si no otro idioma. Ver la regla en [[ELEGIR_Y_MODELAR_OFERTAS]].
- [ ] Está anotada la tabla de la Biblioteca: anuncios activos, días al aire, tienda-marca y el idioma de destino libre.

## 2. Desarme
- [ ] Existe un archivo de desarme de la landing original (skill `desarme-landing`), con las secciones en orden.
- [ ] Están anotados los ID de 4 o 5 anuncios ganadores del original, cada uno con su formato, gancho y texto.

## 3. Landing (se arma con la skill `landing-modelada`)
- [ ] Sigue el orden de secciones del desarme, más lo de la web ganadora del Consultor.
- [ ] Tiene imagen hiperrealista en la primera pantalla, mockup del producto y un mockup por bono (carpeta `mockups/` o `ia/` con archivos).
- [ ] Respeta `web-como-metodo-consultor` (`medir_web.mjs` da ok): 2 o 3 botones de compra solo desde la oferta; la barra fija desliza. Cuenta regresiva hasta una fecha real, botones que laten y conversor de moneda (`data-usd`).
- [ ] El píxel está en la landing, en el portal y en la página de gracias.
- [ ] No hay testimonios inventados, contadores falsos ni promesas de resultado.

## 4. Anuncios (9 para la Cash Trap)
- [ ] Cada anuncio dice de qué ganador del original sale (su ID).
- [ ] Hay videos, no solo placas: dibujito con voz, maqueta 3D y "lo que recibes", como en el Consultor.
- [ ] El texto sigue el esquema: frase de entrada + índice completo + bonos + acceso inmediato + garantía de 7 días.

## 5. Hotmart y embudo
- [ ] Los 7 productos están aprobados y la garantía de todos es de 7 días.
- [ ] Están los 3 order bumps en el checkout "En blanco" con `?checkoutMode=10`.
- [ ] El embudo de un clic está activo y revisado flecha por flecha.

---
Volver a [[INICIO]]
