> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/ELEGIR_Y_MODELAR_OFERTAS.md`), versión vigente al 2026-10-26. IDs reemplazados por marcadores.

# Cómo elijo y modelo ofertas

Fuente: la persona, 2026-10-18.

## Requisitos para modelar una oferta que ya existe

Una oferta se puede modelar (relanzar en otro mercado) si cumple **todo** esto:

1. Tiene **30 anuncios activos o más, mejor 40 o más** (Mat, 2026-10-26).
2. Esos anuncios se vienen mostrando **hace más de 10 a 15 días** (mínimo 10, mejor 15 o más; Mat, 2026-10-26): señal de que vende.
3. **Nunca marca personal** (no depende de la cara, el nombre o la historia de una persona). Mat, 2026-10-26: «nosotros los vendemos sin aparecer en cámara»; vendemos productos digitales sin mostrarnos (Hotmart, Shopify, Impultienda, Netlify, Lovable).
   - Para buscar: la skill `cazador-de-ofertas` (Nexus Profit) sirve también para buscar productos directo en la Biblioteca de anuncios, con su analizador.
4. Se lanza en un **mercado o idioma distinto** al original.

Dónde buscar: primero el **robot Nexus Profit** (skill `cazador-de-ofertas`, guía en `ROBOT_NEXUS_PROFIT.md`, con `min_dias: 15`), y confirmar en la Biblioteca de anuncios de Meta. *(Mi lectura: se puede revisar con la conexión de Meta Ads, que tiene búsqueda en la biblioteca.)*

## Cómo se modela

- Skill `modelar-ofertas`: clona la landing, el quiz o el embudo, lo traduce y le pone estética propia.
- Precio en dólares, de USD 5 a 40, cobrando con Hotmart.
- La landing lleva el **conversor de moneda por IP** (precios en moneda local del visitante, base en USD): `prompts/CONVERSOR_MONEDA_POR_IP.md`.
- Se arma la escalera de valor: producto principal + order bump + upsell + downsell.
- Anuncios con el método Andrómeda / Cash Trap (9 anuncios: 3 C1, 3 C2, 3 C3), eligiendo de `TIPOS_DE_ANUNCIOS.md` y `TIPOS_DE_PLACAS.md`.

## Receta Método Consultor (la que hay que repetir tal cual)

Fuente: Mat, 2026-10-21: "modelalos tal cual, como hicimos el Método del Consultor, que se está vendiendo muy bien". Detalle completo en [[metodo-consultor-ES/PROYECTO]]. **El paso a paso con herramientas, secciones de la web y los 9 anuncios: [[MODELADO_PASO_A_PASO]].** Copia de la web que vende: `06_PROYECTOS\metodo-consultor-ES\web_ganadora\`.

1. **Encontrar la oferta en la Biblioteca de Meta** con la frase exacta del producto (no solo en el robot): 30 o más anuncios activos (el Consultor tenía ~140), primer anuncio de hace más de 10 a 15 días, una tienda-marca y no una persona (allá era "Business Explained", con 69 ebooks), y **el idioma de destino libre** (en español había 6 anuncios y nadie vendía esa guía).
   - **Regla de idioma y país (Mat, 2026-10-21):** si la oferta vende en un solo país (por ejemplo, Argentina) y en los otros países con el mismo idioma nadie la vende con volumen, **se puede lanzar en el mismo idioma en esos países**, como Planos Listos en Latinoamérica sin Argentina. Si esos países ya están ocupados, se lanza en otro idioma. En los dos casos, primero se mide país por país en la Biblioteca.
   - **Portugués no (Mat, 2026-10-21):** "portugués es un mercado peligroso, no lo quiero en portugués". No se lanza nada en portugués ni para Brasil.
2. **Producto:** el mismo formato y temario del original, ampliado en versión propia (allá: ebook de 40+ marcos → "48 herramientas + 4 bonos").
3. **Landing:** se modela **sección por sección sobre la original**, con la misma estructura (advertorial, videos por herramienta, tabla comparativa, barra fija con reloj, botones que laten). Textos, diseño e imágenes son propios. Lleva conversor de moneda por IP y píxel en todas las páginas.
4. **Anuncios:** se toman los anuncios ganadores del original (anotar sus ID de la Biblioteca) y se modelan para los 9 de la Cash Trap (3 C1, 3 C2, 3 C3).
5. **No se copia:** testimonios con cifras, "80.000+ eligieron" ni el reloj de 59 minutos.
6. **Escalera igual a la del Consultor (USD, garantía 7 días en todo):**

   | Paso | Precio |
   |---|---|
   | Principal | 19,99, mostrado como 50 % off de 39,98 hasta una fecha |
   | 3 order bumps | 9,99 cada uno |
   | Upsell | 34,90 |
   | Oferta 2 | 17 |
   | Oferta 3 | 12 |

   - **Escalera vigente (Mat, 2026-10-26, supera la de arriba):** "Tenés que seguir como tiene el método del consultor. Por lo general son un producto principal, tres order bump, un upsell y cinco downsells. Puede tener más o puede tener menos". Precios del Consultor como referencia: principal 19,99 · bumps 9,99 · upsell 34,90 · ofertas siguientes 17 y 12. — Fuente: Mat, en el chat.
   - Embudo de un clic: diga que sí o que no, se le ofrece el siguiente. Ninguna oferta repite contenido de otra.
   - Checkout de Hotmart "En blanco" con `?checkoutMode=10`.
7. **Publicación:**
   - Web en laformulaebooks.site (Netlify), con portal del comprador con candados y página de gracias.
   - Campaña Cash Trap CBO en toda América y España, sin Argentina, Nicaragua ni Venezuela, en idiomas español, con Advantage+.

## Ofertas propias

También se crean ofertas desde cero. [Pendiente: cómo elige la persona el nicho y el producto cuando la oferta es propia.]

## Límite

Modelar es tomar la estructura de una oferta que funciona y hacer una versión propia: textos, diseño e imágenes propios. No se copian textos, imágenes, marcas ni testimonios del original.

---
Relacionado: [[ROBOT_NEXUS_PROFIT]] · [[ESTRUCTURA_LANDING_GANADORA]] · [[PAGINAS_DE_VENTA]]
Volver a [[INICIO]]
