> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/ESTRATEGIA_DE_ANUNCIOS.md`), versión vigente al 2026-10-26. IDs reemplazados por marcadores.

# Mi estrategia de anuncios: método Andrómeda / Cash Trap

Cómo armo, pruebo y escalo anuncios en Meta. Claude sigue esto antes que cualquier criterio general. Si una skill dice otra cosa, se avisa la diferencia y decide la persona.

**Fuentes:**
- Clase grabada del 2026-10-18 → `00_ENTRADA/2026-10-18_clase-metodo-andromeda_transcripcion.txt` (fuente principal).
- Skill `cash-trap-cbo-oro` (complemento: presupuesto, tiempos y escala, que la clase no detalla).
- Ejemplos reales: `08_REFERENCIAS/NOTAS.md`.

---

## 1. La idea de fondo

- Desde 2024 Meta usa una IA (Andrómeda) que elige sola a quién mostrar cada anuncio. Ya no sirve segmentar a mano con intereses, edades o sugerencias.
- Andrómeda "escanea" cada anuncio (título, imagen, colores, ángulo de venta) y con eso decide a quién mostrarlo.
- Lo único que controlamos nosotros son los anuncios. **La comida de Andrómeda es la variedad creativa:** si los anuncios se parecen, Meta los manda al mismo público y no vende.
- Por eso el tiempo se invierte en una sola cosa: pensar anuncios distintos, creativos, que corten el scroll.
- Se pide paciencia: la campaña puede tardar 48 horas en responder.

## 2. Estructura de la campaña

- **1 sola campaña** de ventas con Advantage+ (campaña inteligente) activado.
- **1 solo conjunto**, público abierto, sin intereses ni sugerencias.
- **País + idioma, sí o sí.** En español se marcan las tres variantes: Español, Español (España) y Español (todos). Si no se marca el idioma y la campaña incluye un país como Estados Unidos, también llega a gente que habla inglés y se pierde presupuesto. (Dato: confirmado por la persona el 2026-10-18.)
- **9 anuncios**, 3 por cada nivel de conciencia (ver punto 3). Se nombran C1, C1, C1, C2, C2, C2, C3, C3, C3.
- **Presupuesto en la campaña (CBO).** Si en una cuenta puntual la CBO nunca funciona, se puede armar igual con el presupuesto en el conjunto (ABO): la estructura es la misma.
- **Seguir las recomendaciones de Meta:** la "puntuación de recomendación" de la campaña tiene que estar en 90% o más (la de referencia está en 97%).
- **Una campaña por cuenta publicitaria.** Dos campañas compiten entre sí. No se usa campaña de remarketing: Andrómeda lo hace sola (los anuncios C3 los ven quienes ya vieron C1 y C2).
- **No reutilizar los mismos anuncios (mismo post ID) en otra campaña o cuenta.**
- Si ya hay campañas que venden, no se apagan. La nueva se larga en una cuenta publicitaria nueva.

## 3. Los 3 niveles de conciencia y qué anuncio va para cada uno

Nivel bajo no quiere decir que el cliente sea tonto: quiere decir que todavía no se dio cuenta del problema.

### C1: no sabe que tiene el problema
Se le habla desde la **emoción**, nunca con tecnicismos. Formatos que funcionan:
- **Blooper:** mostrar algo que se hace mal, para que se sienta identificado.
- **Antes y después:** situación inicial contra resultado, con una promesa real, sin exagerar.
- **Problema cotidiano:** una frustración básica del día a día y cómo se ve resuelta.

### C2: sabe que tiene el problema, pero no sabe cómo resolverlo
Se le **enseña algo**, para subirle la conciencia. Formatos que funcionan:
- **Tutorial o contenido útil:** un paso a paso.
- **Demostración:** video corto de cómo funciona el producto, o un testimonio de alguien que certifica que funciona.
- **Carrusel educativo:** el paso a paso en imágenes.

### C3: sabe cómo resolverlo, y está eligiendo con quién
Se va al **cierre**. Formatos que funcionan:
- **Oferta directa:** precio, descuento, bonos de regalo.
- **Rompe objeciones:** placa con las objeciones comunes tachadas y su respuesta ("No tengo tiempo" → lo hacés a tu ritmo; "No tengo el dinero" → se paga con tarjeta en cuotas).
- **El producto por dentro:** mostrar qué hay adentro.

Ejemplo para entenderlo (el de la panchería): C1 come panchos y no conoce tu local. C2 quiere comer un pancho y no sabe a dónde ir. C3 conoce tu local, pero todavía va al de siempre por miedo.

## 4. Cómo leer los resultados y cuándo tocar

- **Se mira la campaña entera (ROAS de campaña), no anuncio por anuncio.** Los 9 trabajan en equipo: las compras suelen venir de los C3 y C2, pero los C1 son los defensores. Si se apagan, se rompe el embudo.
- **Si la campaña da buenos resultados, no se toca nada.**
- **Qué hacer a las 48 h, mirando el ROAS de la campaña (dato: la persona, 2026-10-19):**
  | A las 48 h | Qué se hace |
  |---|---|
  | **No vendió nada** | Se **apaga** la campaña (lo hace el agente solo y avisa; Mat, 2026-10-22) |
  | **Vendió** | Se deja **5 días** sin tocar (Mat, 2026-10-22) |
  | **ROAS 2 o más** | **Se escala +30%** |
  - Después, **cualquier día que la campaña esté en ROAS 2 o más se puede escalar +30%**, respetando 48 h entre aumentos.
- **Arranque y escala (dato: la persona, 2026-10-19):**
  - Toda campaña arranca con **USD 75 por día** y la prende el agente solo, a la medianoche (Mat, 2026-10-22).
  - Pasados esos 5 días, si tiene **ROAS 2 o más**, se sube **+30%**.
  - Después, **+30% cada 48 h mientras siga en ROAS 2 o más**. Si baja de 2, no se sube.
  - **Para escalar se sube la misma campaña; no se duplica en otras cuentas del mismo mercado** (Mat, 2026-10-26: las copias del Consultor en 5 cuentas se pisaron con la principal). Para crecer, otro idioma o país: [[IDIOMAS_PARA_ESCALAR]].
- **Break-even por compra = precio del producto principal.** Los order bumps, upsells y downsells van aparte, como ganancia extra. Un anuncio que gastó el precio del producto principal sin vender ya pasó su break-even. (Dato: la persona, 2026-10-19.)
- **Qué es "buenos resultados":** ROAS 2 = ganancia. Con USD 1.000 por día o más de inversión, se acepta ROAS 1,5. (Dato: la persona, 2026-10-18.)
- **Si la campaña no da resultados:** se busca el anuncio que no rinde, se apaga y se reemplaza por uno **del mismo nivel de conciencia**, para respetar el embudo. Si se apagó un C2, entra un C2. Puede ser:
  - una variación nueva (otro ángulo u otro formato), o
  - algo que ya funcionó antes, siempre que sea de ese mismo nivel.
- Siempre quedan 9: 3 C1, 3 C2, 3 C3. (Dato: confirmado por la persona el 2026-10-18.)
- **Cambio de anuncios: automático (Mat, 2026-10-22 y 24: «yo no quiero que me pidas permiso de nada»).** El agente detecta el anuncio que no rinde, lo cambia y avisa. Se cambian los que tienen **costo por venta mayor al precio**, los que gastaron el precio sin vender y los que no gastaron (Mat, 2026-10-25), con **escenas nuevas** (alcance, Mat 31/10: es dentro del mismo producto en el mismo idioma; para otro idioma se pueden traducir y reusar las escenas de otro idioma). Siempre por uno del **mismo nivel** (C1→C1, C2→C2, C3→C3). El reemplazo es:
  - **otra variación con un ángulo nuevo**, para probar, o
  - si el ángulo del anuncio apagado **funciona**, **el mismo ángulo en otro formato**.
  Sale del banco de reserva. Receta completa: `recetas/metodo-consultor/RECETA.md` del repo de alumnos, §9.
- **Cambios: cada 2 días como mucho.** Esperar a que la campaña responda (24 a 48 horas).
- Es normal que los C3 tengan la frecuencia más alta (2 o 3). No hay que cambiarlos por eso.

## 5. Complementos de la skill (la clase no lo detalla, a confirmar)

- **Tiempos:** largar a la medianoche y no tocar durante 48 horas completas. Si vendió algo, dejarla correr la semana. El día 3 suele ser el peor, y el día 5 suele arrancar.
- **Escala:** desde el día 5 a 7, con ROAS 2 o más, subir 30% del presupuesto y esperar 48 a 72 horas. Nunca subir presupuesto y cambiar anuncios el mismo día.
- **Sin "surfing"** (subir el presupuesto varias veces en el mismo día).
- **Backend:** tener upsells para sostener un costo por compra más alto que el precio.

## 6. Diferencias entre la clase y la skill (para decidir)

| Tema | Clase (2026-10-18) | Skill `cash-trap-cbo-oro` |
|---|---|---|
| Cantidad de anuncios | **RESUELTO: 9, 3 C1 + 3 C2 + 3 C3** (confirmado 2026-10-18) | 5 o más (desactualizado) |
| Cómo se varían | **RESUELTO: por nivel de conciencia**; la skill no tiene niveles (confirmado 2026-10-18) | por formato (reel, horizontal, cuadrado, placa, carrusel) |
| CBO o ABO | **RESUELTO: CBO; ABO solo si la CBO nunca anda en esa cuenta** (clase; skill ya corregida) | siempre CBO, ABO descartado (desactualizado) |
| Campañas por cuenta | **RESUELTO: una por cuenta publicitaria; si hay campañas vendiendo no se apagan, se usa otra cuenta** (clase; skill ya corregida) | una por producto (desactualizado) |
| Ubicaciones | **RESUELTO: ubicaciones Advantage+, sin sacar ninguna; puntuación al 100% o lo más cerca** (confirmado 2026-10-18; skill ya corregida) | sacar WhatsApp e Historias (desactualizado) |
| Reemplazo de un anuncio | **RESUELTO: siempre del mismo nivel de conciencia** (variación nueva o algo que ya funcionó) (confirmado 2026-10-18) | duplicar uno que funcione con creativo nuevo |

Según la persona, la diferencia de la skill es solo la falta de niveles de conciencia y la cantidad de anuncios. Todas las diferencias quedaron resueltas a favor de la clase, y la skill ya está corregida.

## 7. Reglas que no rompo

- Una campaña, un conjunto, nueve anuncios: 3 C1, 3 C2, 3 C3.
- Un anuncio apagado se reemplaza siempre por otro de su mismo nivel de conciencia.
- No tocar una campaña que da resultados.
- No apagar anuncios "caros" si la campaña rinde: trabajan en equipo.
- Los anuncios de C3 pueden usar descuentos, bonos, cupos y testimonios **solo si son reales**. *(Agregado por Claude, a confirmar.)*
- **Los 9 anuncios se modelan de los ganadores del competidor** (Biblioteca de Meta: mismos formatos, ganchos y estructura de texto), adaptados por nivel de conciencia. No se inventan formatos. Ejemplo hecho: [[ANUNCIOS_METODO_CONSULTOR]]. *(Mat, 2026-10-20.)*
- Videos: hablan desde el segundo 0, con subtítulos, música y transiciones. *(Mat, 2026-10-20.)*
- Segmentación en español: América del Norte + Central + Sur + Caribe + España, sin Argentina, Nicaragua ni Venezuela; idiomas Español ×3. *(Mat, 2026-10-21.)*

## Pendientes (la clase no lo dice)

- Presupuesto con el que arranca la persona en la práctica.
- Si los 9 anuncios tienen que ser de formatos distintos o pueden repetir formato.

## Última actualización

- Fecha: 2026-10-26 (automático, USD 75, una sola campaña, reemplazo por costo por venta)
- Fuente: clase del 2026-10-18 (transcripción) + skill `cash-trap-cbo-oro`

---
Relacionado: [[TIPOS_DE_ANUNCIOS]] · [[TIPOS_DE_PLACAS]] · [[METODO_STORYTIME_CONTROVERSIAL]] · [[cambios-meta]] · [[CONFIG_AUTOMATIZACIONES]] · [[PRODUCTOS]]
Volver a [[INICIO]]
