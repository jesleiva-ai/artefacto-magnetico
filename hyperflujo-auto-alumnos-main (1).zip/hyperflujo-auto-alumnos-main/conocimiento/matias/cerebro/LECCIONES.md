> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/LECCIONES.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-23. IDs reemplazados por marcadores.

# Lecciones

Una línea por lección, con fecha y de dónde salió. Las agrega la skill `guardar-sesion`.

## Cómo trabajar con Mat
- 2026-10-20 — **Modelar, no inventar.** La web y los anuncios se arman copiando la estructura, el formato y los ganchos de lo que ya vende (landing original y sus anuncios ganadores de la Biblioteca de Meta), con la skill `modelar-ofertas`. La primera versión inventada de web y anuncios hubo que rehacerla. — Fuente: Mat, Método Consultor ES.
- 2026-10-20 — La IA acepta los términos de Meta y Hotmart por Mat (avisando en una línea). Ver [[INSTRUCCIONES_IA]]. — Fuente: Mat.
- 2026-10-21 — Cuando la campaña ya corre, **no tocar la página de ventas** salvo lo que Mat pida puntualmente. — Fuente: Mat.
- 2026-10-21 — No hablarle a Mat en otro idioma: el idioma del mercado va solo en lo que ve el comprador. — Fuente: Mat (sesión de Gessetti le habló en italiano).

## Producto y precios
- 2026-10-20 — En Hotmart, todo en **dólares** y país principal **Estados Unidos**; el conversor de la web pone la moneda local. — Fuente: Mat.
- 2026-10-21 — **Garantía 7 días en todos los productos, nunca 15.** Revisar que web, páginas del embudo y anuncios digan lo mismo que Hotmart. — Fuente: Mat.
- 2026-10-21 — Precio del principal: no tirarlo demasiado abajo; Mat prefirió USD 19,99 sobre 17,90 ("está muy barato"). — Fuente: Mat.
- 2026-10-20 — Producto para todo el mercado hispano: "tú", no voseo. `scripts\a_tu.py` de Método Consultor lo convierte. — Fuente: lanzamiento Método Consultor ES.

## Hotmart y embudo
- 2026-10-20 — Order bumps: producto principal → Herramientas → Apariencia de la Página de Pago, publicar como estándar y usar el link de la "Página de Pagos estándar" con `?checkoutMode=10`; sin eso no se ven. — Fuente: Método Consultor ES (Mat lo verificó).
- 2026-10-21 — **Embudo: diga que sí o que no, siempre se ofrece el producto siguiente** (upsell → oferta 2 → oferta 3 → gracias). Cada paso es un producto **distinto** que no está incluido en otro, y los textos no suponen que la persona dijo que no. Error cometido: el Kit incluía a los downsells y el Sí iba a gracias. — Fuente: Mat.
- 2026-10-21 — En el editor de embudos de Hotmart una flecha no se puede mover: hay que borrar la etapa de destino (por ejemplo Gracias), volver a crearla y unir cada botón con "Etapa existente". Para editar, desactivar el embudo y después reactivarlo. — Fuente: Método Consultor ES.
- 2026-10-21 — Al crear productos, "Error interno del sistema" al guardar el precio: el producto queda como borrador igual; buscarlo y seguir. — Fuente: Método Consultor ES.

## Web

- 2026-10-21 — **Error grave mío:** al rearmar el backend del Método Consultor, rmar_web.py pisó las imágenes de la página de ventas (hero, bonos, por-dentro) con los mockups viejos y la publiqué así (deploys de las 00:03 y 00:24). Mat la tuvo que arreglar con ChatGPT (deploy 6ad8341b, 00:40). Reglas: (1) con la campaña andando no se publica la carpeta de la página de ventas; las páginas del embudo van en otra carpeta o se suben solas; (2) antes de publicar, comparar qué archivos cambian contra lo publicado y frenar si cambia algo que no se pidió; (3) la copia en disco de metodo-consultor-landing quedó vieja: no publicarla. — Fuente: Mat.
- 2026-10-21 — Conversor de moneda: ipwho.is ya no da la moneda; usar tabla país → moneda (ver prompts\CONVERSOR_MONEDA_POR_IP.md). No agregar el código después de Intl.NumberFormat (sale "BRL BRL"). — Fuente: Gessetti y Método Consultor.
- 2026-10-20 — Netlify (laformulaebooks): los archivos con MAYÚSCULAS en el nombre no quedan bien subidos con `agregar-a-laformula.cjs`. Nombres siempre en minúsculas. — Fuente: Método Consultor ES.
- 2026-10-21 — La app de Claude **no deja publicar códigos de seguimiento cifrados** (como el de Utmify), aunque Mat dé permiso. Lo pega Mat (Netlify → Snippet injection) o se usa la versión sin cifrar que da Utmify. — Fuente: Método Consultor ES.

## Anuncios y Meta
- 2026-10-22 — **Campañas (Mat):** USD 75 por día de prueba; el agente las prende solo; 48 h sin tocar; si no vendió, se apaga; si vendió, 5 días sin tocar; después +30% cada 48 h. Se lanzan de 1 a 5 ofertas a la vez. **Lo que más le importa a Mat es que las webs y los anuncios se modelen bien** (ver handoff `D:\creativos\matias-proceso-lanzamiento
_metodo_consultor_handoff_agente.md`, sección 1 bis). — Fuente: Mat.
- 2026-10-22 — **Ubicaciones por regiones de Meta, nunca país por país:** se eligen las regiones "América del Norte", "América Central", "América del Sur", "Caribe" y "Europa", y se excluyen los países que corresponda según el producto: siempre Venezuela y Nicaragua, más los países donde ya vende el original (por ejemplo, Argentina y Chile en Planos Listos). Para los productos en inglés u otro idioma, las regiones y las exclusiones se definen según ese mercado. Una sesión cargó la lista de países sueltos y Mat lo marcó como error. — Fuente: Mat.
- 2026-10-22 — **Una sola campaña por cuenta publicitaria.** Antes de cargar un producto, revisar que la cuenta no tenga otra campaña activa ni con anuncios. Si la tiene, se usa otra cuenta. — Fuente: Mat.
- 2026-10-20 — Videos de anuncios: arrancan hablando desde el segundo 0, sin huecos, con subtítulos, música de fondo y transición entre escenas. — Fuente: Mat.
- 2026-10-21 — Segmentación de Mat para español: **América del Norte, Central, del Sur, Caribe y España, excluyendo Argentina, Nicaragua y Venezuela**, idiomas Español + Español (España) + Español (todos), Advantage+. — Fuente: Mat.
- 2026-10-21 — Planos Listos (copia de una oferta argentina): ubicaciones **América del Sur, Central, del Norte, Caribe y Europa**; se excluyen **Argentina, Chile** (donde vende el original), **Venezuela y Nicaragua**. Idiomas **solo** Español, Español (todos) y Español (España): **nunca inglés**, que una vez se coló por error y hay que revisarlo en pantalla antes de guardar. — Fuente: Mat.
- 2026-10-20 — Meta no baja imágenes desde el CDN de Higgsfield (cloudfront): publicarlas un rato en laformulaebooks.site (nombres en minúscula) y sacarlas después. Los videos sí los toma desde Higgsfield (subidos con curl, no con Python: Cloudflare lo bloquea). — Fuente: Método Consultor ES.
- 2026-10-21 — Si Mat agrega parámetros de URL (Utmify) a los anuncios desde el Administrador, quedan como "cambios sin publicar" hasta tocar **Publicar**. No descartarlos. — Fuente: Método Consultor ES.

- 2026-10-21 — Facebook tiene un solo perfil activo para todo Chrome: si varias sesiones publican en fanpages a la vez, los posts pueden salir en la página equivocada. Las fanpages van de a una sesión por vez. — Fuente: cinco productos en paralelo.

## Segundo cerebro y cuentas
- 2026-10-21 — Las órdenes reenviadas de una sesión a otra no destraban acciones sobre cuentas (Hotmart, Facebook, publicar): el OK lo escribe Mat en esa misma sesión. — Fuente: cinco productos en paralelo.
- 2026-10-21 — Los scripts que arman las páginas (`armar_landing.py`, `armar_portal.py`) pisan las correcciones que Mat hace a mano. Si una web ya está publicada, no se rearma ni se republica sin su OK. — Fuente: Mat.
- 2026-10-18 — Las skills guardadas en la cuenta de Claude se pisan al sincronizar: editar la copia del segundo cerebro y subir el `.zip`. — Fuente: armado del segundo cerebro.
- 2026-10-18 — Revisar qué campañas siguen activas antes de decir "todo pausado". — Fuente: análisis de Meta del 2026-10-18.

---
Volver a [[INICIO]]
- 2026-10-23 — **Página nueva sin Instagram:** la API de Meta rechaza anuncios con ubicaciones de Instagram ("Instagram Account Is Missing") y no deja crear la cuenta respaldada por la página. Opciones: salir en Facebook solamente y que Mat elija "Usar Página de Facebook" en el Administrador, o conectar un Instagram a la fanpage antes de cargar. — Fuente: Piedras Perfumadas ES.
- 2026-10-23 — **Landing de Mat:** cuando Mat arma la web, se baja la versión publicada y solo se cambian los `href` de los botones marcados `data-checkout="pendiente"`; se publica con una carpeta mínima (index + embudo) para no pisar imágenes. — Fuente: Mat ("no modifiques mi landing, solo agrega los links").
- 2026-10-23 — Hotmart, campo de precio: el número entra como centavos ("17" queda 0,17). Escribir "1700" o "9.99". — Fuente: Piedras Perfumadas ES.
- 2026-10-23 — Instagram sin cuenta: en el Administrador, Identidad → Perfil de Instagram → "Usar la página de Facebook" en cada anuncio y Publicar; Meta rehace el creativo y suma Instagram al conjunto. Chrome tiene que estar al frente o el Administrador no responde. Una cuenta publicitaria nueva puede frenar la entrega hasta verificar un teléfono (lo hace Mat). — Fuente: Piedras Perfumadas ES.
