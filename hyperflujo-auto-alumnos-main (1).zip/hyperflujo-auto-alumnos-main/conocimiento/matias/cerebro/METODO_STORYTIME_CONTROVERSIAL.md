> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/METODO_STORYTIME_CONTROVERSIAL.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-19. IDs reemplazados por marcadores.

# Método: story time con gancho controversial

> **Ya es skill:** `05_PROCESOS/skills/anuncio-storytime-controversial/SKILL.md` (aprobada por la persona el 2026-10-18). Este archivo queda como análisis de fondo; si hay cambios, se hacen en la skill.

Estrategia propia de la persona para anuncios de cursos de oficios. No es el clásico "gancho → problema → solución → llamado a la acción": abre con una historia exagerada, polémica o irónica **propia del nicho**, y va directo a la venta.

**Fuentes:**
- Explicación de la persona (2026-10-18).
- Análisis de Claude de los anuncios 01 a 05 en `08_REFERENCIAS/anuncios` (detalle en `08_REFERENCIAS/NOTAS.md`).

Lo marcado *(mi lectura)* es interpretación de Claude, a confirmar.

---

## 1. La idea en una línea

Una situación **cotidiana del mundo de ese oficio**, exagerada hasta lo gracioso o lo polémico, contada en primera persona o directo al que mira. En 2 a 4 segundos frena el scroll, y con una sola frase se pasa a la venta del curso.

## 2. Qué lo hace funcionar (lo que se repite en los 5)

### a) El gancho sale del nicho, no es polémica al azar
Cada oficio tiene sus propias historias, chistes y estereotipos. El gancho toma uno y lo lleva al extremo.

| Anuncio | Lo que realmente pasa en ese mundo | Cómo se exagera |
|---|---|---|
| 01 Cámaras de seguridad | La gente pone cámaras por miedo: a que le roben o a lo que pasa en su casa cuando no está | "Si tenés miedo que tu mujer te engañe..." + video de cámara oculta; cierra con un ladrón atrapado en cámara |
| 02 Herrería | Un error de soldadura te puede arruinar un trabajo | "Siempre cometía algún pequeño error" + una casa entera prendida fuego |
| 03 Mecánica | El estereotipo del mecánico: la cerveza, las excusas | "Las mentiras a mi mujer, la cerveza a la noche y ser mecánico son cosas que no puedo cambiar" |
| 04 Plomería | Nadie sabe cómo se llaman las piezas en la ferretería | "No le pido el cosito que va en el coso que es más grande que el tubito" |
| 05 Steel framing | Separarse y quedarse sin casa | "Mi mujer me dejó, perdí la casa y el perro" → aprendió a construir casas |

### b) Es verosímil
Son cosas que pasan de verdad, o que la gente reconoce ("a mí me pasó", "conozco a uno así"). La exageración está en el tamaño, no en inventar algo imposible.

### c) La ironía conecta el gancho con el oficio *(mi lectura)*
El mejor caso es el 05: perdió la casa y terminó aprendiendo a hacer casas. En el 01 la cámara es la que "ve" la infidelidad y al ladrón. En el 02 el error es justo lo que el curso enseña a no cometer. El chiste no está pegado de afuera: es el oficio mismo visto con humor.

### d) La imagen ilustra la frase al pie de la letra, y más grande
Si dice "pequeño error", se ve una casa en llamas. Si dice "engaño", se ve una cámara oculta en el dormitorio. El contraste entre lo que se dice (chico) y lo que se ve (enorme) es parte del chiste.

### e) El narrador se ríe de sí mismo, no del que mira *(mi lectura)*
"Yo también era de los que...", "las mentiras a mi mujer", "me dejó". El que queda mal parado es el narrador o la situación, nunca el espectador ni un grupo de gente. Por eso hace gracia y no ofende.

### f) Pivote corto y directo a la venta
Una sola frase de puente, sin explicar el problema:
- "solucionalo con mi curso..."
- "por eso, 10 años después, te grabé un curso..."
- "pero sí puedo cambiar tu futuro, porque grabé un curso..."
- "y grabé un curso online de plomería..."
- "hoy, además de haberlo logrado, preparé un curso..."

### g) La venta siempre promete lo mismo
Aprender el oficio, con salida laboral o negocio propio. Precio fijo arriba en pantalla ($6.500). Cierre: "Hacé clic en el botón y te lo envío".

### h) Remate visual al final *(mi lectura)*
Mientras se dice el llamado a la acción, a veces se ve un clip con remate: el ladrón que sale corriendo y lo persiguen (01), el mismo clip del principio (03, 04).

## 3. Estructura del guion (17 a 25 segundos, 55 a 80 palabras)

| Parte | Tiempo | Qué pasa |
|---|---|---|
| 1. Gancho controversial | 0–4 s | Situación del nicho exagerada, con humor, ironía o polémica. Primera persona ("yo...") o directo ("si tenés..."). |
| 2. Pivote | 1 frase | "por eso / pero / y" → "grabé un curso de [oficio]". |
| 3. Promesa | 1 o 2 frases | Aprendés el oficio → salida laboral o tu propio negocio. Opcional: 2 o 3 cosas concretas que se aprenden, o bonos. |
| 4. Cierre | 1 frase | "Hacé clic en el botón y te lo envío." |

Visual: título fijo arriba con oficio y precio, subtítulos grandes palabra por palabra, clips del oficio, sin la cara del vendedor.

## 4. Tipos de gancho vistos

1. **Miedo íntimo** que el oficio "resuelve" (01).
2. **Confesión de error con consecuencia gigante** (02).
3. **Meme con giro** "X, Y y Z no los puedo cambiar, pero sí puedo cambiar tu futuro" (03).
4. **Chiste del oficio** con lenguaje de la calle (04).
5. **Caída y reinvención** irónica (05).

## 5. Límites: polémico sí, ofensivo no

- El chiste es sobre la situación o sobre el narrador, nunca contra el que mira ni contra un grupo (por origen, género, religión, cuerpo, etc.).
- La exageración tiene que ser reconocible como exageración, no una mentira sobre el producto.
- Nada de imágenes sexuales o de desnudos: Meta las rechaza aunque el chiste funcione. *(Ver el 01: el gancho funciona igual sin la imagen de la mujer en ropa interior.)*
- No usar material con logos de canales de TV ni textos de anuncios ajenos.
- Lo que se promete del curso tiene que ser real (salida laboral = aprender el oficio, no garantizar un trabajo).

## 6. Relación con el método Andrómeda *(mi lectura, a confirmar)*

Estos anuncios abren como C1 (emoción, la persona no estaba buscando nada) y cierran como C3 (precio y "te lo envío"). Falta definir si dentro de la campaña de 9 cuentan como C1, como C3, o si los de oficios siguen otra lógica.

## Pendientes

- Más ejemplos para afinar los tipos de gancho (la persona va a mandar más).
- ¿Este método también se usa para la línea del grimorio, o es solo para oficios?
- ¿Qué anuncios de los 5 funcionaron mejor?

---
Relacionado: [[ESTRATEGIA_DE_ANUNCIOS]] · [[TIPOS_DE_ANUNCIOS]] · [[ANUNCIOS]]
Volver a [[INICIO]]
