> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/MODELADO_PASO_A_PASO.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-22. IDs reemplazados por marcadores.

# Modelado paso a paso (cómo se hizo El Método del Consultor)

Fuente: lanzamiento del Método Consultor, 2026-10-20 y 21. Mat, 2026-10-21: "se está vendiendo muy bien… esa forma de modelar funciona, vamos a hacer así con todos los productos".
La receta corta (requisitos, precios, segmentación) está en [[ELEGIR_Y_MODELAR_OFERTAS]]. Acá está **el cómo**, con las herramientas y los errores que no hay que repetir.

**Copia de la web que vende:** `06_PROYECTOS\metodo-consultor-ES\web_ganadora\` (HTML, imágenes y videos tal como están publicados). Es la referencia para las próximas landings. No se publica desde esa carpeta.

## 1. Elegir la oferta (½ día)
1. Skill `cazador-de-ofertas` + Biblioteca de Meta con la **frase exacta** del producto.
2. Medir país por país: el original con su marca, el original en el idioma de destino y la competencia genérica. Anotar una tabla (ver la del [[metodo-consultor-ES/PROYECTO]]).
3. Guardar la **landing original** y los **ID de 4 o 5 anuncios ganadores** (los que llevan más días y más copias).

## 2. Desarmar el original antes de hacer nada
- Landing: skill `desarme-landing`. Lista de secciones en orden, qué hace cada una, colores, tipo de imágenes y videos, botones, reloj y barra fija.
- Anuncios: para cada ganador, anotar el formato (dibujito, maqueta 3D con cartel, placa, carrusel), el gancho, la duración y el texto. **El texto del anuncio del original suele ser siempre el mismo: una frase de entrada + el índice completo del producto.** Se copia ese esquema.
- **Error que no se repite:** la primera web y los primeros anuncios del Consultor se hicieron "a criterio" y hubo que tirarlos. Primero se desarma, después se modela.

## 3. Producto
- Mismo temario y formato que el original, en versión propia y más completa (Consultor: 48 herramientas en 7 partes, cada una con qué es, cuándo usarla, paso a paso, ejemplo y error común, más 4 bonos; ~16.000 palabras).
- Escrito en "tú" para todo el mercado hispano.
- Portal web con candados (en lugar de PDF): se lee desde el celular y cada extra se abre al comprarlo.

## 4. Landing modelada sección por sección
> **Obligatorio desde el 2026-10-21:** toda landing se arma con la skill **`landing-modelada`** (`05_PROCESOS\skills\landing-modelada\SKILL.md`) y el kit `D:\creativos\_referencia-paginas-mat\kit-animaciones.css`. Antes de empezar, se miran las páginas terminadas por Mat en `D:\creativos\_referencia-paginas-mat\2026-10-21\`. Mat: "no quiero que hagan lo que quieran… si no, gasto tokens y termino haciéndolo manual".

Secciones de la web que vende (en este orden):
1. Titular tipo artículo + imagen del "profesional con el sistema" (hiperrealista).
2. El problema que nadie nombra ("la brecha que frena carreras").
3. La escena que duele ("la reunión que todavía repasas").
4. El sistema por dentro (mockups, videos cortos de cada herramienta).
5. Las preguntas que no te animas a hacer.
6. Mini ejercicio: "5 problemas reales, ¿qué abrirías?".
7. Para quién es.
8. Por qué importa ahora.
9. Qué incluye: 48 herramientas / 7 partes.
10. 4 bonos con mockup propio cada uno.
11. Comparación ("no es otro libro de negocios").
12. Opiniones (ver la nota de abajo).
13. Preguntas frecuentes + garantía de 7 días.
- Siempre: estructura de `web-como-metodo-consultor`, barra fija que desliza a la oferta, cuenta regresiva hasta una fecha real, botones grandes que laten, animaciones al bajar, conversor de moneda por IP y píxel.
- Imágenes con Higgsfield `gpt_image_2_5` (~0,25 créditos c/u) y videos cortos con Kling 3.0 (~6 créditos c/u). Pedir **sin texto adentro**; el texto se pone con código.
- **Opiniones:** la web publicada muestra opiniones traducidas sobre la marca del original (las agregó Mat con ChatGPT). Para el producto propio, usar opiniones de compradores reales en cuanto existan.

## 5. Escalera y embudo
- Precios, bumps, upsell, ofertas 2 y 3: ver la receta en [[ELEGIR_Y_MODELAR_OFERTAS]].
- Skill `embudo-hotmart-netlify`. Diga que sí o que no, siempre se ofrece el producto siguiente, y **ningún producto puede estar incluido en otro**.
- Garantía de 7 días en todos.

## 6. Los 9 anuncios modelados (Cash Trap)
> **Cómo se eligen (Mat, 2026-10-22): los 9 mejores anuncios de la competencia, uno por cada anuncio nuestro.**
> 1. En la Biblioteca de Meta, listar todos los anuncios activos del original y ordenarlos por **días al aire** y **cantidad de copias** (cuantas más versiones del mismo, mejor funciona).
> 2. Elegir los **9 mejores distintos** y clasificar cada uno por nivel de conciencia: **3 C1** (no sabe que tiene el problema: historia, emoción, curiosidad), **3 C2** (conoce el problema y busca solución: cómo funciona, qué tiene adentro, errores comunes) y **3 C3** (listo para comprar: oferta, lo que recibe, precio y garantía).
> 3. **Cada anuncio nuestro modela uno de esos 9, uno a uno:** mismo formato (video, placa o carrusel), misma escena, encuadre y luz, mismo gancho y misma estructura de texto, con la marca, los números y la oferta nuestros.
> 4. Se anota en una tabla: #, nivel, ID del ganador, días al aire, copias, formato y archivo. Al final se arma la hoja con los 9 ganadores arriba y los 9 nuestros abajo, en el mismo orden.
> 4 bis. **Antes de gastar un solo crédito**, la sesión manda la lista de los 9 ganadores (ID, nivel, formato e imagen) y el plan de cada anuncio. Se manda como aviso y se sigue sin esperar (Mat, 2026-10-26: automático, sin pedir confirmación). Así no se tiran créditos en anuncios que después hay que rehacer (2026-10-22: se rehicieron los 9 de los cinco productos por no modelar a los ganadores desde el principio).
> 5. Videos: máximo 4 s por toma, un solo subtítulo a la vez, música hasta el final y cierre de 2 s con el producto. Texto: frase de entrada + "[Producto] te da…" + índice completo + bonos + acceso inmediato y garantía de 7 días.

> **Regla de Mat (2026-10-21): se modelan también las imágenes, no solo el texto.** Para cada ganador del original: bajar su imagen o su fotograma a `referencia_original\` y copiar **la escena, el encuadre, la luz, el estilo de letra y dónde va el logo y el botón**, con la marca propia y sin el texto ni el logo del otro. Si el original usa fotos hiperrealistas, los nuestros también: nada de dibujos planos ni placas genéricas. Al terminar, se arma una hoja con los ganadores al lado de los nuestros y se compara. Error que no se repite: Planos Listos tenía los textos modelados y las imágenes inventadas (dibujos en beige contra fotos de taller).

| Nivel | Formato modelado del original |
|---|---|
| C1 ×3 | Video dibujito con voz + escenas del producto · video maqueta 3D con cartel fijo · placa "el manual perfecto no existe… ¿o sí?" |
| C2 ×3 | Video dibujito con un problema puntual (SCQA) · video 3D "los 3 marcos" · carrusel con 4 herramientas |
| C3 ×3 | Placa "qué hay dentro" · video "lo que recibes" con precio y garantía · placa de la oferta (guía + bonos + % off) |
- Texto de los 9: una frase de entrada según el nivel + "[Producto] te da un sistema probado para…" + índice completo + bonos + "acceso inmediato · garantía de 7 días". Botón **Más información** o **Ver detalles**, nunca "Comprar" (Mat, 22/10). Declarar contenido con IA.
- **Regla de Mat: cada imagen o toma dura como máximo 4 segundos en pantalla.** Si una escena dura más, se corta o se cambia de imagen. También: un solo texto de subtítulo a la vez (nunca título y subtítulo diciendo lo mismo), y música hasta el último cuadro, sin silencio en la tapa final.
- Videos: voz ElevenLabs (cotizar antes), subtítulos de 2–3 palabras, música de fondo, arrancan hablando en el segundo 0. Scripts en `D:\creativos\metodo-consultor-es\scripts\` (`guiones.py`, `audio.py`, `armar_videos.py`, `armar_placas_v2.py`): copiar la carpeta y cambiar los textos.
- Campaña: skill `cash-trap-cbo-oro`, segmentación en [[ELEGIR_Y_MODELAR_OFERTAS]], USD 75/día en ese lanzamiento.

## 7. Publicar sin romper nada
- Cada producto en su carpeta de laformulaebooks.site, con `agregar-a-laformula.cjs --solo=<carpetas de ese producto>`, nombres de archivo en minúscula.
- **Con la campaña andando, no se publica la carpeta de la página de ventas.** Antes de cualquier publicación, mirar qué archivos cambian y frenar si cambia algo que no se pidió. (Error del Consultor: rearmar el backend pisó las imágenes de la página de ventas.)
- Imágenes para Meta: subirlas un rato a la web (en minúscula) y sacarlas después; los videos se suben desde Higgsfield.

## 8. Costos de referencia (Consultor)
- Higgsfield: ~110 créditos en total (web + anuncios).
- ElevenLabs: ~1.600 caracteres (5 voces + música).

---
Relacionado: [[ELEGIR_Y_MODELAR_OFERTAS]] · [[metodo-consultor-ES/PROYECTO]] · [[ANUNCIOS_METODO_CONSULTOR]] · [[LECCIONES]]
Volver a [[INICIO]]
