> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/NETLIFY_Y_GITHUB.md`), tomada el 2026-10-26 (nota del 2026-10-20). IDs reemplazados por marcadores.

# Montar páginas y portales en Netlify (con GitHub)

Fuente: repositorio de Ramiro Cerrato (academia) `ramiaguero/prompt-infoproducto-seguro-netlify`, guardado el 2026-10-20 a pedido de Mat.
Copia completa: `08_REFERENCIAS/repos/prompt-infoproducto-seguro-netlify/` (README, prompt maestro y guía de GitHub).

## Qué es

Un **prompt maestro** para que la IA construya en Netlify un infoproducto con:
- página pública (landing, quiz o calculadora);
- checkout (en el repo es **DEMO**, no cobra de verdad);
- ingreso con Google;
- **portal del comprador** que Netlify no entrega si la persona no compró.

La idea que no se negocia: *Google confirma quién sos; el servidor confirma si compraste; el rol `buyer` es el permiso; Netlify bloquea el archivo antes de entregarlo.*

## Cómo se conecta (sin pasar contraseñas a la IA)

GitHub guarda el proyecto → **GitHub Desktop** lo sincroniza con la compu → Claude trabaja sobre esa carpeta → Netlify publica desde GitHub o con su programa de consola.

1. Fork del repo en la cuenta de GitHub de Mat.
2. Clonarlo con GitHub Desktop (en el disco D).
3. Abrir esa carpeta con Claude y pegar el prompt maestro.
4. Responder la entrevista (7 preguntas comerciales).

## Lo que necesita la persona (Claude no lo puede hacer solo)

- Iniciar sesión en Netlify y en GitHub Desktop.
- Activar Identity y el ingreso con Google en Netlify.
- **Visitor access → producción pública** (si queda privada, se rompe el ingreso).
- Autorizar cada deploy (cuesta créditos de Netlify; referencia del repo: 15 créditos por deploy de producción, a verificar).
- Para cobro real: proveedor de pago con webhook verificable. **Con Hotmart:** Hotmart cobra y avisa por webhook; el portal da acceso solo si llega esa compra. Un "pago aprobado" en la URL nunca da acceso.

## Herramientas en la compu (2026-10-20)

- Git: viene con GitHub Desktop (`[DATO_PERSONAL]\AppData\Local\GitHubDesktop\app-3.6.6\resources\app\git\cmd\git.exe`).
- Node.js y Netlify CLI: **no instalados** (hacen falta para pruebas y deploy).

## Cómo entrega Mat (decisión del 2026-10-20)

- **Netlify:** la web de venta y el **portal** (app donde la compradora recorre la guía y los bonos).
- **Hotmart:** solo checkout, order bumps, upsell y downsell. El "producto" cargado en Hotmart es un **PDF "Felicidades por tu compra"** con un botón al portal.
- El portal se abre con el link (no pide login). Límite: quien tenga el link entra. Si algún día hace falta cerrarlo, se usa el sistema del repo (Google + rol `buyer` + webhook de Hotmart).
- Ejemplo de portal de Mat: https://portal-formula-del-vinculo.netlify.app (bienvenida, números, ruta por fases, biblioteca con tarjetas).

## Lo que ya está armado (2026-10-20)

- Node.js 24 en `D:\Programas\nodejs` · Netlify CLI 27 en `D:\Programas\npm-global` (npm guarda todo en D).
- Sesión de Netlify iniciada en la compu (cuenta Pro `parodiezequielmatias`).
- Copia de trabajo del repo: `D:\repos\infoproducto-netlify` (fork `parodiezequielmatias-maker/prompt-infoproducto-seguro-netlify`). Cada web va en `sitios\<nombre>\`.
- **Dominio:** `laformulaebooks.site`. El DNS está en **Hostinger** (no en Netlify). No hay subdominios automáticos: cada subdominio necesita un registro **CNAME** en Hostinger que apunte al sitio `.netlify.app`.
- **Visitor access:** Netlify crea los sitios privados. Hay que dejar **producción pública y vistas previas privadas** (`sso_login_context: non_production`, igual que laformulaebooks).

## Regla de Mat: todo en laformulaebooks.site, una carpeta por producto (2026-10-20)

- Web de venta: `laformulaebooks.site/<producto>/` · Portal: `laformulaebooks.site/portal-<producto>/` (ej. `/biblia-robienia-na-drutach/` y `/portal-robienia-na-drutach/`).
- Es **un solo sitio de Netlify** (`heartfelt-semifreddo-f77e65`, id `a0efd57a-f986-438e-9d3e-05b82606eb7e`) con ~340 archivos y la función **grimorio-forum** (foro del Grimorio).
- **Nunca** volver a subirlo con `netlify deploy` desde una carpeta parcial: borraría los otros productos y el foro.
- Para sumar un producto: `node D:\repos\infoproducto-netlify\deploy\agregar-a-laformula.cjs --probar` y después sin `--probar`. El script conserva todos los archivos y la función, sube solo lo nuevo, publica como borrador, verifica y recién ahí pasa a producción. Para otro producto, cambiar `CARPETAS` dentro del script.
- Lección: Netlify devuelve la lista de archivos de a 100. La primera versión del script leyó 100 de 339; la prueba lo frenó. El script ahora exige que las dos cuentas coincidan.

## Cómo publicar una web suelta (receta, si algún día hace falta un sitio aparte)

1. Carpeta en `D:\repos\infoproducto-netlify\sitios\<nombre>\` con su `index.html`.
2. `netlify sites:create --name <nombre> --account-slug parodiezequielmatias --disable-linking`
3. `netlify deploy --prod --dir <carpeta> --site <id>`
4. Producción pública (ver arriba) y comprobar que la dirección responda 200.
5. Subdominio: cargarlo en el sitio y agregar el CNAME en Hostinger.
6. Guardar en GitHub con GitHub Desktop (Commit + Push).

## Pendiente

- [ ] Push del primer commit con GitHub Desktop (la consola no tiene la sesión de GitHub).

---
Relacionado: [[PAGINAS_DE_VENTA]] · [[PROYECTO]]
Volver a [[INICIO]]
