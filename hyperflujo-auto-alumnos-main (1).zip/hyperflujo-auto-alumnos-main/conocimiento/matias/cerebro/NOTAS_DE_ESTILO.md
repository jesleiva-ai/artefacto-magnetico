> Copia saneada del segundo cerebro de Matías (`08_REFERENCIAS/NOTAS.md`), tomada el 2026-10-26 (nota del 2026-10-19). IDs reemplazados por marcadores. Son las notas de estilo de Matías sobre anuncios y piezas que funcionan.

# Notas de referencias

Una entrada por ejemplo. La completa Claude al revisar los archivos.

## Plantilla

### [nombre del archivo o link]

- Tipo: anuncio / imagen / página
- Producto:
- Qué se ve:
- Estilo: [colores, tipografía, tono, tipo de foto]
- Gancho o promesa principal:
- ¿Funcionó?: sí / no / no sé — [dato y fecha, si hay]
- Qué copiar de esto:
- Qué no repetir:

---

### anuncios/2026-10-18_anuncio-01.mp4

- Tipo: anuncio (reel vertical 9:16, 21 segundos, con audio)
- Producto: curso online de instalación y uso de cámaras de seguridad, "de cero a experto". Precio en pantalla: $6.500 pesos. (Dato: texto del anuncio.)
- Guion leído de los subtítulos (la voz no la escuché): "Si tenés miedo que tu mujer te engañe, o te preocupa la seguridad de tu hogar, solucionalo con mi curso online de cámaras de seguridad de cero a experto. Te enseño todo para que puedas instalarlas en tu hogar, o en algún local, o montes tu propio emprendimiento o tengas salida laboral. Es grabado online y está listo para que puedas empezar. Hacé clic en el botón y te lo envío."
- Qué se ve: abre con imagen de cámara oculta en un dormitorio; sigue con un video de cámara nocturna de un robo (con logo de un canal de TV), cámaras Hikvision y cámaras tipo lamparita, una mano instalando, la app en el celular, y cierra con un ladrón en la puerta de una casa.
- Estilo: clips de stock o de productos, sin cara del vendedor; subtítulos amarillos con borde negro que aparecen palabra por palabra; título fijo arriba con producto y precio desde el segundo 4. Del segundo 15 en adelante se ven textos en portugués de otro anuncio ("Conexão Wi-Fi", "Zoom de até 4x").
- Gancho: miedo personal y fuerte (infidelidad) en el primer segundo, después amplía a seguridad del hogar.
- Ángulo (mi lectura): miedo/protección + salida laboral. Escalera de tres usos: tu casa → un local → trabajo propio.
- Oferta: precio bajo y visible todo el tiempo; curso grabado, acceso inmediato. Sin bonos ni garantía a la vista.
- Llamado a la acción: "Hacé clic en el botón y te lo envío."
- ¿Funcionó?: no sé — falta el dato.
- Qué copiar de esto: precio fijo arriba durante casi todo el video; subtítulos grandes de alto contraste; mostrar el producto en uso (mano instalando, app en el celular); la escalera de beneficios hasta "salida laboral"; llamado a la acción corto.
- Qué no repetir (mi lectura, riesgos):
  - El gancho de la infidelidad con imagen de una mujer en ropa interior grabada a escondidas: Meta suele rechazar o limitar contenido sugerente, y sugiere espiar a la pareja, lo que puede traer bloqueos de la cuenta publicitaria.
  - El logo de un canal de TV y los textos en portugués de otro anuncio: son material ajeno, se notan a la vista y pueden traer reclamos o rechazos.

---

### anuncios/2026-10-18_anuncio-02_electro-shock.mp4

- Tipo: anuncio (reel vertical 9:16, 24 segundos, con audio, baja resolución 360x640)
- Producto: curso online de herrería. Precio en pantalla: $6.500 pesos. (Dato: texto del anuncio.)
- Guion leído de los subtítulos (la voz no la escuché): "Yo también era de los que soldaban y siempre cometía algún pequeño error. Por eso, 10 años después, te grabé un curso profesional de herrería [...] a que tengas tu propio emprendimiento o salida laboral como herrero profesional. Aprenderás técnicas y soldaduras, qué herramientas y materiales son adecuados, y además te voy a enseñar cómo armar planos. Hacé clic en el botón y te lo envío." (Entre "herrería" y "a que tengas" hay una parte que no quedó en los fotogramas.)
- Qué se ve: soldador con chispas, una casa en llamas (parece imagen hecha con IA), barras de hierro, una fragua, herreros trabajando en el yunque, un taller con dos personas y guantes sobre la mesa.
- Estilo: igual que el anuncio 01. Clips de stock sin la cara del vendedor, subtítulos amarillos con borde negro palabra por palabra, título fijo arriba con producto y precio desde el segundo 6.
- Gancho: historia personal en primera persona ("yo también era de los que...") más una consecuencia exagerada con imagen fuerte (el incendio).
- Ángulo (mi lectura): identificación con el error, autoridad por experiencia ("10 años después") y salida laboral.
- Oferta: precio bajo y fijo en pantalla; lista corta de lo que aprende (técnicas, herramientas y materiales, planos).
- Llamado a la acción: "Hacé clic en el botón y te lo envío." (el mismo que el 01)
- ¿Funcionó?: no sé — falta el dato.
- Qué copiar de esto: el gancho de historia personal; la lista de 3 cosas concretas que aprende; mismo molde visual que el 01.
- Qué no repetir (mi lectura): el video está en baja resolución y se ve pixelado; la casa en llamas exagera la consecuencia de un error de soldadura.

---

### anuncios/2026-10-18_anuncio-03.mp4

- Tipo: anuncio (reel vertical 9:16, 19 segundos, con audio)
- Producto: curso de mecánico de autos. Precio en pantalla: $6.500 pesos. (Dato: texto del anuncio.)
- Guion leído de los subtítulos (la voz no la escuché): "Las mentiras a mi mujer, la cerveza a la noche y ser mecánico de autos son cosas que no puedo cambiar, pero sí puedo cambiar tu futuro, porque grabé un curso online para enseñarte a que puedas ser mecánico de autos y que tengas salida laboral, o que puedas tener tu propio negocio, por un único pago de 6.500 pesos. Te lo envío ahora mismo haciendo clic en el botón."
- Qué se ve: abre y cierra con una mecánica trabajando en un motor (mismo clip, efecto de vuelta al principio); una cerveza; mecánicos arrodillados frente a un auto (gesto de broma); manos con guantes en motores.
- Estilo: clips de stock; subtítulos blancos con borde negro (no amarillos); título arriba en recuadro negro con letra blanca: "Curso de mecánico de autos por $6.500 pesos", desde el segundo 2.
- Gancho: formato de meme "X, Y y Z son cosas que no puedo cambiar", con humor de personaje del oficio.
- Ángulo (mi lectura): identidad y humor del oficio → giro "pero sí puedo cambiar tu futuro" → salida laboral o negocio propio.
- Oferta: "por un único pago de 6.500 pesos" dicho en voz, además de escrito.
- Llamado a la acción: "Te lo envío ahora mismo haciendo clic en el botón."
- ¿Funcionó?: no sé — falta el dato.
- Qué copiar de esto: el giro "no puedo cambiar X, pero sí puedo cambiar tu futuro"; repetir el precio en voz con "único pago"; cerrar con el mismo clip de la apertura.
- Qué no repetir: nada claro a la vista.

---

### anuncios/2026-10-18_anuncio-04.mp4

- Tipo: anuncio (reel vertical 9:16, 17 segundos, con audio)
- Producto: curso de plomería online. Precio en pantalla: $6.500 pesos. (Dato: texto del anuncio.)
- Guion leído de los subtítulos (la voz no la escuché): "Soy plomero y me sé los nombres de las griferías. Cuando voy a la ferretería no le pido el cosito que va en el coso que es más grande que el tubito: me lo sé de memoria. Y grabé un curso online de plomería para que aprendas un oficio y puedas tener tu trabajo o tu propio negocio. Si hacés clic en el botón te lo envío."
- Qué se ve: un plomero armando caños de PVC bajo una mesada, una grifería, el mostrador de una ferretería, manos con piezas de bronce y cinta de teflón. Abre y cierra con el mismo plomero.
- Estilo: clips caseros, de celular, que parecen reales y no de banco; subtítulos amarillos con borde negro; título fijo arriba "Curso plomería online — Solo $6.500 pesos" desde el segundo 3.
- Gancho: humor de identidad del oficio ("el cosito que va en el coso"), que hace reír a quien es del rubro o a quien le pasó en la ferretería.
- Ángulo (mi lectura): orgullo de saber el oficio → te lo enseño → trabajo o negocio propio.
- Oferta: precio fijo arriba; no lo dice en voz.
- Llamado a la acción: "Si hacés clic en el botón te lo envío."
- ¿Funcionó?: no sé — falta el dato.
- Qué copiar de esto: el chiste con lenguaje real de la calle; los clips caseros que se ven auténticos; el guion más corto de los cuatro (unas 55 palabras).
- Qué no repetir: nada claro a la vista.

---

### anuncios/2026-10-18_anuncio-05.mp4

- Tipo: anuncio (reel vertical 9:16, 25 segundos, con audio)
- Producto: curso online de steel framing (construcción en seco), con 2 bonos de regalo: electricista domiciliaria y epoxy para paredes y pisos. Precio en pantalla: $6.500 pesos arg. (Dato: texto del anuncio.)
- Guion leído de los subtítulos (la voz no la escuché): "Bueno, después de que mi mujer me dejó, perdí la casa y el perro. Tuve que reinventarme y comencé a estudiar construcc[ión...] que es el sistema más usado en América Latina para hacer casas, y se llama steel framing. Hoy, además de haberlo logrado, preparé un curso para poder enseñarte, y además te voy a dar como bonos de regalo el de electricista domiciliaria y el de epoxy para paredes y pisos. Pinchá en el botón que te lo envío." (Entre "construcc" y "que es" falta un pedazo.)
- Qué se ve: casa prefabricada terminada, interior con escalera y baño, estructuras de perfiles de acero, una cabaña en A terminada y en esqueleto, un plano en 3D en la computadora, obreros armando paneles.
- Estilo: clips de obra, de otros; subtítulos amarillos con borde negro; título fijo arriba "Curso online — solo $6.500 pesos arg" desde el segundo 12 (más tarde que en los otros). En los primeros 8 segundos quedan visibles textos del video original de otra cuenta ("Vivienda prefabricada de 6x3 metros a entrega inmediata", "La misma incluye baño y cocina completa").
- Gancho: historia de caída tragicómica ("mi mujer me dejó, perdí la casa y el perro").
- Ángulo (mi lectura): caída → reinvención → logro ("hoy, además de haberlo logrado") → te lo enseño. Es el arco de historia más completo de los cinco.
- Oferta: precio fijo + 2 bonos de regalo de otros oficios (la única vez que aparecen bonos).
- Llamado a la acción: "Pinchá en el botón que te lo envío."
- ¿Funcionó?: no sé — falta el dato.
- Qué copiar de esto: el arco de reinvención; nombrar el sistema o técnica con autoridad ("el más usado en América Latina"); los bonos de otros cursos para subir el valor sin bajar el precio.
- Qué no repetir (mi lectura): los textos del video original de otra cuenta se leen y confunden (parece que se vende una casa prefabricada); el título con el precio aparece recién a la mitad.

---

## Patrón común (mi lectura de los anuncios 01 a 05, a confirmar con la estrategia de la persona)

### Producto y oferta
- Siempre un curso online de un oficio práctico (cámaras de seguridad, herrería, mecánica, plomería, steel framing).
- Siempre el mismo precio: $6.500 pesos, curso grabado, entrega inmediata.
- A veces se suman otros cursos como bonos de regalo (05).

### Estructura del guion (4 partes, 17 a 25 segundos, 55 a 80 palabras)
1. **Gancho (0–4 s):** una frase en primera persona o directa al que mira, con emoción o humor. Tipos vistos:
   - Miedo: "Si tenés miedo que tu mujer te engañe..." (01)
   - Historia del error: "Yo también era de los que soldaban y siempre cometía algún pequeño error..." (02)
   - Meme con giro: "X, Y y Z son cosas que no puedo cambiar, pero sí puedo cambiar tu futuro" (03)
   - Humor del oficio: "Soy plomero y me sé los nombres de las griferías..." (04)
   - Caída y reinvención: "Después de que mi mujer me dejó, perdí la casa y el perro. Tuve que reinventarme..." (05)
2. **Presentación:** "grabé un curso online de [oficio] para que aprendas...". El vendedor habla como alguien del oficio.
3. **Beneficio final, siempre el mismo:** "salida laboral" o "tu propio negocio / emprendimiento". A veces suma una lista corta de lo que se aprende (02) o "es grabado y está listo para empezar" (01).
4. **Cierre, siempre el mismo:** "Hacé clic en el botón y te lo envío" (con variantes mínimas).

### Visual
- Título fijo arriba con oficio y precio desde los primeros 2 a 6 segundos, durante casi todo el video.
- Subtítulos grandes palabra por palabra, en el centro de la pantalla (amarillos con borde negro en 3 de 4; blancos en 03).
- Clips del oficio en acción (manos trabajando, herramientas, resultado), sin la cara del vendedor.
- Varias veces el último clip repite el primero.

---

# Nivel de conciencia de cada ejemplo

Según el método (ver `05_PROCESOS/ESTRATEGIA_DE_ANUNCIOS.md`). Los nombres C1 y C2 de los archivos 06 a 09 los puso la persona (dato); el resto es mi lectura.

| Ejemplo | Nivel | Formato del método | Fuente |
|---|---|---|---|
| 06 altar pequeño | C2 | tutorial | nombre del archivo (C2) |
| 07 "cuando empecé hice todo al revés" | C2 | contenido útil / error de principiante | nombre del archivo (C2) |
| 08 ritual de los domingos | C1 | problema cotidiano → calma | nombre del archivo (C1) |
| 09 taza de manzanilla, cinco minutos | C1 | problema cotidiano / emoción | nombre del archivo (C1) |
| imagen 01 ritual de baño | C2 | carrusel / paso a paso | mi lectura |
| imagen 02 pack de 7 libros | C3 | oferta directa (precio, pago único, garantía) | mi lectura |
| imagen 03 historieta del grimorio | C1 | antes y después ("estancada" → "conectada") | mi lectura |
| 01 a 05 oficios | C1 + C3 en el mismo video | gancho emocional (C1) y cierre con precio (C3) | mi lectura |

Observación: los anuncios de oficios mezclan dos niveles en un solo video. Con el método, cada oficio tendría 9 anuncios separados (3 C1, 3 C2, 3 C3). Falta saber si los de oficios se armaron antes del método o si son otra estrategia.

---

# Segunda línea: espiritualidad y bienestar femenino (anuncios 06 a 09 e imágenes 01 a 03)

### anuncios/2026-10-18_anuncio-06_C2-2.mp4

- Tipo: anuncio (reel vertical 9:16, 20 segundos, 1080x1920, con audio)
- Producto: El Gran Grimorio de las Brujas (se nombra como "mi grimorio"). Sin precio en pantalla.
- Guion (subtítulos, completo): "Así armas un altar pequeño: eliges un rincón tranquilo, limpias la superficie y pones un paño, colocas una vela en el centro, sumas un cristal y unas hierbas, y algo que sea tuyo. Enciendes la vela y piensas en tu intención. Hay más en mi grimorio. Link abajo."
- Qué se ve: una mujer pelirroja con cárdigan verde en una cabaña de madera con nieve afuera (parece generada con IA), que habla a cámara al principio y al final, y en el medio hace cada paso con las manos.
- Estilo: tipo UGC (persona hablando a cámara, en primera persona); subtítulos blancos con letra de libro (serif), de 2 o 3 palabras; sin título fijo ni precio; tonos cálidos y suaves.
- Gancho: "Así armas un altar pequeño". Promete un tutorial corto y útil.
- Ángulo (mi lectura): dar valor primero (un mini tutorial completo) y mostrar el producto como "hay más de esto".
- Llamado a la acción: "Hay más en mi grimorio. Link abajo." (señala con el dedo hacia abajo)
- ¿Funcionó?: no sé — falta el dato.

### anuncios/2026-10-18_anuncio-07_C2.mp4

- Tipo: anuncio (reel vertical 9:16, 20 segundos, 1080x1920, con audio)
- Producto: El Gran Grimorio de las Brujas ("mi grimorio"). Sin precio.
- Guion (subtítulos, completo): "Cuando empecé hice todo al revés: quería rituales complicados desde el primer día, sin entender nada de lo que hacía. Me abrumé y lo dejé guardado. Lo que me sirvió fue ir de a poco, con prácticas simples, una a la vez. Eso encontré en mi grimorio, por eso lo sigo usando. Si te da curiosidad, link abajo."
- Qué se ve: la misma mujer (IA) en una librería con lluvia afuera; mesa con libros, velas, cristales y frascos de hierbas; un cuaderno escrito a mano.
- Estilo: igual que el 06.
- Gancho: confesión del error del principiante ("hice todo al revés").
- Ángulo (mi lectura): identificación con el que se abruma, y el producto como la solución simple ("una práctica a la vez").
- Llamado a la acción: "Si te da curiosidad, link abajo."
- ¿Funcionó?: no sé — falta el dato.

### anuncios/2026-10-18_anuncio-08_C1-2.mp4

- Tipo: anuncio (video horizontal 16:9, 20 segundos, 1920x1080, con audio). Es el único horizontal.
- Producto: El Gran Grimorio de las Brujas ("mi grimorio"). Sin precio.
- Guion (subtítulos, completo): "Los domingos a la noche tengo un ritual que me encanta: apago las luces grandes, prendo una vela y abro mi grimorio. Elijo una sola práctica para la semana y escribo cómo me siento en el espacio que trae para eso. Es un rato tranquilo y arranco la semana con otra cabeza. Si te da curiosidad, link abajo."
- Qué se ve: la misma mujer (IA) en un departamento con ventanal a la ciudad de noche; prende una vela con un fósforo, abre el libro y escribe.
- Estilo: igual que el 06 y el 07, pero en horizontal.
- Gancho: rutina personal concreta ("los domingos a la noche tengo un ritual").
- Ángulo (mi lectura): mostrar cómo se usa el producto en la vida real; menciona una función concreta (el espacio para escribir).
- Llamado a la acción: "Si te da curiosidad, link abajo."
- ¿Funcionó?: no sé — falta el dato.
- Ojo: en horizontal ocupa poca pantalla en reels e historias; sirve más para el feed.

### anuncios/2026-10-18_anuncio-09_C1.mp4

- Tipo: anuncio (reel vertical 9:16, 33 segundos, 1080x1920, con audio). El más largo.
- Producto: El Gran Grimorio de las Brujas (nombrado completo). Sin precio.
- Guion (subtítulos, completo): "Prepara una taza de manzanilla, enciende una vela, siéntate cinco minutos en silencio, sin pantallas, sin prisa. Para muchas personas esa pausa es un ritual, y es mucho más que una costumbre: es un momento solo para ti. Las hierbas, las velas y los cristales nos recuerdan algo que olvidamos fácil: bajar el ritmo. El Gran Grimorio de las Brujas te propone pequeños rituales para incorporar a tu rutina. Empieza hoy, con cinco minutos."
- Qué se ve: otra mujer pelirroja (IA) con suéter blanco en una cabaña nevada; prepara té, prende una vela, se sienta junto a la ventana con una manta, lee un libro antiguo.
- Estilo: sin hablar a cámara, voz en off narrando; planos lentos; subtítulos blancos con letra de libro.
- Gancho: una instrucción simple y tranquila ("Prepara una taza de manzanilla...").
- Ángulo (mi lectura): calma y tiempo para una misma; el ritual como pausa, no como magia.
- Llamado a la acción: "Empieza hoy, con cinco minutos." (no dice "link abajo")
- ¿Funcionó?: no sé — falta el dato.

### imagenes/2026-10-18_imagen-01_ritual-bano-amor.webp

- Tipo: imagen (anuncio o publicación), cuadrada
- Producto: probablemente El Gran Grimorio (mi lectura: es un ritual de muestra; no nombra el producto).
- Qué se ve: título "Ritual de Baño Dulce para Atraer el Amor" con letra gótica; 4 fotos (IA) de una mujer echando pétalos y miel en un bol, en la bañera, velas, y ella sonriendo con un libro antiguo abierto. Marco tipo pergamino con rosas, lunas y estrellas.
- Estilo: estética de grimorio antiguo; colores cálidos, crema y bordó.
- Gancho: el nombre del ritual (amor), que da curiosidad por el paso a paso.
- Ojo (mi lectura): "atraer el amor" es una promesa de resultado; conviene que la ficha del producto diga qué incluye y que el anuncio no prometa que funciona.

### imagenes/2026-10-18_imagen-02_pack-7-libros.webp

- Tipo: imagen de anuncio con oferta, cuadrada
- Producto: pack de 7 libros de la marca "Habita tu vida": Abraza a la niña que fuiste, Hoy te dejo ir, Vuelvo a mí, Tú eres tu prioridad, Mereces mucho más, 50 cápsulas de amor propio, Si lo crees, lo creas. Precio: US$ 14,99, un solo pago, acceso al portal, 7 días de garantía. (Dato: texto de la imagen.)
- Qué se ve: las 7 tapas sobre una mesa con flores, una taza de café, una vela y una manta bordó; título grande "7 libros sobre los temas que más nos atraviesan a las mujeres".
- Estilo: rosa, crema y bordó; letra manuscrita mezclada con letra en mayúscula; botón "Quiero mis 7 libros →".
- Gancho: el número (7 libros) y la identificación ("a las mujeres").
- Oferta: la más completa de todos los ejemplos: precio, forma de pago, acceso y garantía en la misma imagen.
- Ojo: es otro producto y otra marca, con precio en dólares (no en pesos).

### imagenes/2026-10-18_imagen-03_grimorio-brujas.webp

- Tipo: imagen tipo historieta de 4 cuadros, vertical
- Producto: El Gran Grimorio de las Brujas + 5 bonus. (Dato: texto de la imagen.)
- Qué se ve: una mujer pelirroja (ilustración realista con IA) en una cocina antigua. Cuadro 1: "Siento que todo está estancado..."; 2: "¿Y si empiezo por algo simple?" (hojas de Hierbas Mágicas, Protección, Rituales Simples); 3: "Sal, albahaca, canela... y mi intención" (arma un frasco); 4: con una taza, "No era magia de película. Era volver a conectar conmigo." Abajo: "El Gran Grimorio de Las Brujas + 5 bonus · Link en la bio".
- Estilo: tonos sepia y cálidos, letra gótica para el nombre del producto, globos de diálogo.
- Gancho: el problema emocional ("todo está estancado").
- Ángulo (mi lectura): del estancamiento a la conexión con una misma; baja la expectativa de "magia" para ganar confianza.
- Llamado a la acción: "Link en la bio" (pensado para publicación orgánica, no para anuncio pago).

## Patrón de la segunda línea (mi lectura, a confirmar)

Es una estrategia distinta a la de los oficios:

| | Oficios (01–05) | Grimorio / bienestar (06–09, imágenes) |
|---|---|---|
| Público | hombres que buscan un oficio o salida laboral | mujeres interesadas en rituales, calma, amor propio |
| Quién habla | voz en off "del oficio", sin cara | una "creadora" a cámara (IA) o voz en off suave |
| Gancho | emoción fuerte o humor | tutorial corto, confesión o rutina personal |
| Contenido | promesa de trabajo | da valor primero (un ritual completo y gratis) |
| Precio | fijo arriba todo el video ($6.500) | no aparece en los videos; sí en la imagen del pack (US$ 14,99) |
| Cierre | "Hacé clic en el botón y te lo envío" | "Si te da curiosidad, link abajo" |
| Voseo | sí ("hacé", "tenés") | mezcla de tú ("eliges", "prepara") y voseo ("si te da") |
| Visual | clips de otros, subtítulos amarillos | todo generado con IA, subtítulos blancos con letra de libro, tonos cálidos |

---
Volver a [[INICIO]]
