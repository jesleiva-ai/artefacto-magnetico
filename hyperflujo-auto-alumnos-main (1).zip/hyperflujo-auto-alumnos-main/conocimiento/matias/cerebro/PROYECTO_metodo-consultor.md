# Proyecto: El Método del Consultor (español)

- **Qué es:** modelado de *Consulting Management EXPLAINED* (Business Explained, EE. UU., en inglés) para venderlo en **español**.
- **Estado (2026-10-21):** **todo andando.** Web, portal, 9 productos en Hotmart, order bumps, embudo de un clic activo y campaña Cash Trap **prendida** en morfi 1 (USD 75/día desde 2026-10-20 ~23:45).
- **Fuente:** pedido de Mat + investigación de Claude (Nexus Profit y Biblioteca de anuncios de Meta, 2026-10-20).

## 1. Por qué esta oferta

| Requisito | Dato (Biblioteca de Meta, 2026-10-20, solo activos) |
|---|---|
| Más de 30 anuncios activos | ~140 con la frase exacta "Consulting Management EXPLAINED" (~120 en EE. UU.) |
| Más de 10 días | primer anuncio visto: 2026-06-20 |
| No es marca personal | tienda-marca "Business Explained" (69 ebooks "X Explained") |
| Infoproducto | ebook PDF de 109 páginas, 40+ marcos (SCQA, MECE, Porter, ICE, BCG, KPI, Agile) |
| Español libre | el original pauta en inglés para todo el mundo; en español solo 6 anuncios en México. Nadie más vende esta guía en español. |

- Landing original (advertorial): https://business-explained.com/the-problem-solving-system-that-top-consultants-use-on-every-engagement/ · cobra US$ 49.
- Anuncios ganadores del original que se modelaron: [ID_BIBLIOTECA_1], [ID_BIBLIOTECA_3], [ID_BIBLIOTECA_2], [ID_BIBLIOTECA_4] (ver [[ANUNCIOS_METODO_CONSULTOR]]).
- **No se modeló:** testimonios con cifras, "80.000+ eligieron", reloj de 59 minutos.

## 2. La escalera (todo en USD, garantía 7 días en todos)

| Paso | Producto | ID Hotmart | Precio | Link de pago | Página |
|---|---|---|---|---|---|
| Principal | El Método del Consultor (48 herramientas + 4 bonos) | [CODIGO_PRODUCTO] | 19,99 | https://pay.hotmart.com/[CODIGO_PRODUCTO]?checkoutMode=10 | /metodo-consultor/ |
| Bump 1 | Plantillas del Consultor | [CODIGO_PRODUCTO] | 9,99 | https://pay.hotmart.com/[CODIGO_PRODUCTO] | — |
| Bump 2 | Presentaciones que Convencen | [CODIGO_PRODUCTO] | 9,99 | https://pay.hotmart.com/[CODIGO_PRODUCTO] | — |
| Bump 3 | Números para Decidir (6 calculadoras) | [CODIGO_PRODUCTO] | 9,99 | https://pay.hotmart.com/[CODIGO_PRODUCTO] | — |
| Upsell | Kit del Consultor Independiente (3 módulos) | [CODIGO_PRODUCTO] | 34,90 | https://pay.hotmart.com/[CODIGO_PRODUCTO] | /metodo-consultor/oferta-especial/ |
| Oferta 2 | Prompts de IA para Consultores | [CODIGO_PRODUCTO] | 17,00 | https://pay.hotmart.com/[CODIGO_PRODUCTO] | /metodo-consultor/oferta-prompts/ |
| Oferta 3 | Reuniones que Deciden | [CODIGO_PRODUCTO] | 12,00 | https://pay.hotmart.com/[CODIGO_PRODUCTO] | /metodo-consultor/oferta-reuniones/ |

- **Precio 19,99** (Mat, 2026-10-21: "17,90 está muy barato"). Break-even por venta = 19,99. Se muestra como 50% off de 39,98 **hasta el 3/11/2026 23:59 (Buenos Aires)**: el 4/11 subir el precio en Hotmart o mover `FIN_LANZAMIENTO` en `armar_landing_v2.py`.
- **Order bumps:** página de pago "En blanco" ([ID_PAGINA_PAGO_HOTMART]) como estándar; el link de la web lleva `?checkoutMode=10`.
- **Embudo [EMBUDO_ID] (activo):** Inicio → Kit → (Sí y No) → Prompts IA → (Sí y No) → Reuniones → (Sí y No) → Gracias. Regla de Mat: diga que sí o que no, se ofrece el siguiente. Ninguna oferta repite contenido de otra.
- Productos en desuso (no tocar ni ofrecer): Diagnóstico [CODIGO_PRODUCTO] y Propuestas [CODIGO_PRODUCTO] (son módulos del Kit).

## 3. Publicado

- **Resultado:** se está vendiendo muy bien (Mat, 2026-10-21). Copia de la web que vende en `web_ganadora\` (deploy 6ad8d367). Método para repetirlo: [[MODELADO_PASO_A_PASO]].

| Qué | Dirección |
|---|---|
| Web de venta | https://laformulaebooks.site/metodo-consultor/ |
| Portal del comprador | https://laformulaebooks.site/portal-metodo-consultor/ |
| Gracias | https://laformulaebooks.site/metodo-consultor/gracias/ |

- Web modelada sección por sección sobre la original (advertorial, videos por herramienta, tabla comparativa, barra fija con reloj, botones que laten). Conversor de moneda por IP (tabla país → moneda) y píxel en todas las páginas.
- Portal con candados por dispositivo; el Kit abre sus 3 módulos. Las ofertas 2 y 3 tienen su tarjeta con link de pago.
- **Utmify:** Hotmart está conectado y Mat puso los parámetros en los anuncios. El código de Utmify **no está** en la página de ventas: la app bloquea publicarlo porque viene cifrado. Si se quiere, Mat lo pega en Netlify → Snippet injection.

## 4. Meta

- Portafolio The Daily Skillet ([ID portafolio The Daily Skillet]) · cuenta **morfi 1** ([ID cuenta publicitaria morfi 1]) · página **Estrategia Clara** ([ID_PAGINA]) · píxel **Metodo Consultor ES** ([ID_PIXEL]).
- **Campaña "Metodo Consultor ES - Cash Trap"** ([ID_CAMPANA]), conjunto [ID_CONJUNTO]: ventas, CBO **USD 75/día**, América del Norte + Central + Sur + Caribe + España, **sin Argentina, Nicaragua ni Venezuela**, idiomas Español / Español (España) / Español (todos), Advantage+ público y ubicaciones, 9 anuncios (3 C1, 3 C2, 3 C3), IA declarada. Puntuación de Meta 100. Detalle en [[ANUNCIOS_METODO_CONSULTOR]].
- Los anuncios publicados dicen "garantía de 15 días" (el video C3 también lo dice en la voz). Al reemplazarlos, usar los archivos nuevos (ya dicen 7 días).

## 5. Pendiente

- [ ] 2026-10-22 12:30: reporte de campañas (tarea programada `reporte-campanas-22-oct`). No tocar la campaña antes de 48 h completas (2026-10-22 ~23:45).
- [ ] Compra de prueba (Mat): principal + bump → Kit → Prompts → Reuniones; mails de acceso; compra en el píxel.
- [ ] Subir logo y portada a la fanpage Estrategia Clara (`marca\`).
- [ ] Cargar el píxel en el producto de Hotmart (como en Gessetti).
- [ ] 4/11: fin del precio de lanzamiento.

## 6. Archivos (`D:\creativos\metodo-consultor-es\`)

- Contenido: `contenido\*.md` · links, píxel y widget: `config.json`.
- Scripts (`scripts\`): `armar_mockups.py` → `armar_web.py` → `armar_landing_v2.py` → `armar_portal.py`. **Ojo:** `armar_web.py` también pisa la página de ventas con la versión vieja; si solo se cambia el backend, guardar antes `index.html` y volver a ponerlo, o correr solo `embudo_imgs()` de `armar_landing_v2.py`.
- Anuncios: `anuncios_v2\` (scripts `guiones.py`, `audio.py`, `armar_videos.py`, `armar_placas_v2.py`).
- PDFs de acceso: `pdf_acceso\*_ACCESO.pdf`.
- **NO publicar la página de ventas desde disco:** la versión buena es la que arregló Mat con ChatGPT (deploy 6ad8341b, 2026-10-21 00:40); la copia local quedó vieja.
- Publicar (solo backend y con cuidado): `node D:\repos\infoproducto-netlify\deploy\agregar-a-laformula.cjs --solo=metodo-consultor,portal-metodo-consultor`.

---
Relacionado: [[ANUNCIOS_METODO_CONSULTOR]] · [[ELEGIR_Y_MODELAR_OFERTAS]]
Volver a [[INICIO]]
