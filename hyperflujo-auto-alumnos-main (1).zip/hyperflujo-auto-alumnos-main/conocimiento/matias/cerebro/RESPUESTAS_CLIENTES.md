> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/RESPUESTAS_CLIENTES.md`), tomada el 2026-10-26 (nota del 2026-10-19). IDs reemplazados por marcadores.

# Respuestas a clientes (plantillas)

Base para la skill `atencion-al-cliente`. Se adaptan al producto y se traducen al idioma del cliente. Los datos entre [corchetes] salen de la ficha del producto.

## No me llegó el acceso
¡Hola! Gracias por tu compra de [producto] 🙌 El acceso lo envía Hotmart al mail con el que compraste: revisá también la carpeta de spam o promociones, con el asunto de Hotmart. Si en unos minutos no lo encontrás, respondeme con el mail de la compra y te lo reenvío.
→ Acción para la persona: reenviar el acceso desde Hotmart.

## No puedo entrar / descargar
¡Hola! Para entrar: [cómo se accede: área de miembros de Hotmart / portal / link]. Si un archivo no abre, probá desde la compu o con otro navegador. Si sigue sin andar, contame qué archivo es y desde qué dispositivo, y lo resolvemos.

## Duda antes de comprar
¡Hola! [Respuesta concreta con lo que incluye el producto]. Tenés [X] días de garantía: si no te sirve, te devolvemos el dinero. Acá lo podés ver completo: [link].

## No es lo que esperaba
¡Hola! Gracias por avisarme, lamento que no sea lo que buscabas. ¿Me contás qué esperabas encontrar? Si querés, te muestro dónde está [lo que busca, si existe]. Y si preferís el reembolso, estás dentro de la garantía.

## Pedido de reembolso
¡Hola! Sin problema. Podés pedirlo desde tu compra en Hotmart, o si preferís lo gestiono yo. Gracias por haberlo probado.
→ Acción para la persona: aprobar el reembolso en Hotmart si está dentro de la garantía.

## Comentario de anuncio: pregunta
¡Hola! [Respuesta corta]. Toda la info está acá 👉 [link]

## Comentario de anuncio: crítica
Gracias por tu comentario. [Respuesta respetuosa y concreta, sin discutir.]

## Comentario de anuncio: insulto, spam o estafa
→ Ocultar el comentario. No responder.

---
Relacionado: [[PREGUNTAS_Y_LENGUAJE]] · [[PRODUCTOS]]
Volver a [[INICIO]]
