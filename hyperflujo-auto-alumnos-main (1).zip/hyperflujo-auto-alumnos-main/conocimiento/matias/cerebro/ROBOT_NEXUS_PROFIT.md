> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/ROBOT_NEXUS_PROFIT.md`), tomada el 2026-10-26 (nota del 2026-10-19). IDs reemplazados por marcadores.

# Robot de ofertas: Nexus Profit

Conectado el 2026-10-19. Es un conector (MCP) de Claude que tiene una base de anuncios de Meta (una biblioteca global + la **bóveda** propia de Mat) y herramientas para encontrar, validar y medir ofertas. Se usa junto con la skill **`cazador-de-ofertas`** (viene con el servicio; vive en la cuenta de Claude, no se copió acá porque es del servicio y solo funciona con su conector).

## Herramientas del robot (14)

| Herramienta | Qué hace | ¿Cambia algo? |
|---|---|---|
| `descubrir_ofertas` | Ofertas que cumplen las reglas (copias, días, digital, sin "pocas impresiones"), con puntaje, checklist y pendientes | Solo lee |
| `tendencias` | Qué categorías y países tienen más ofertas nuevas escaladas | Solo lee |
| `ver_anunciante` | Qué vende un anunciante y cuánto concentra en un producto | Solo lee |
| `ver_anuncio` | Detalle de un anuncio (titular, texto) | Solo lee |
| `analizar_landing` | Formato real, precio, checkout, píxeles, order bump/upsell, garantía, bonos, antigüedad del dominio, señales de cloaker | Solo lee |
| `buscar_anuncios` | Búsqueda en la base | Solo lee |
| `radar_competencia` / `mapa_paises` | Competencia de un tema en un país | Solo lee |
| `perfiles_por_descubrir` | Anuncios nuevos con pocas copias que pueden venir de perfiles grandes | Solo lee |
| `revisar_anuncios` | Vista previa de lo que se limpiaría de la bóveda | Solo lee |
| `validar_oferta` | Da el veredicto de una oferta; también **guarda** si es marca/no digital | Escribe en Nexus |
| `guardar_escaneo_meta` | **Guarda** un escaneo de la Biblioteca de Meta | Escribe en Nexus |
| `publicar_informe` | **Publica** un informe en el panel web de Nexus | Escribe en Nexus |
| `limpiar_anuncios` | **Borra** anuncios de la bóveda — **irreversible** | ⚠️ Solo con OK explícito de Mat |

## Cómo se usa con las reglas de Mat

Reglas de Mat (`ELEGIR_Y_MODELAR_OFERTAS.md`): **20–30+ anuncios activos, más de 15 días, sin marca personal, producto digital, para lanzar en otro mercado.** El robot trae por defecto 10 días: al usarlo, pasar `min_copias: 20` y `min_dias: 15`.

Flujo:
1. `descubrir_ofertas` (+ `tendencias` como contexto).
2. Revisar cada oferta a mano: que sea **100% digital** (el filtro automático deja pasar cosas; ej.: en la prueba apareció una app de series cortas, que no es modelable) y **sin marca personal**.
3. `analizar_landing` y `detector-cloaker` en las mejores.
4. Confirmar en la Biblioteca de Meta (el robot trae un analizador para contar anuncios en el navegador).
5. Etapa 2: competencia en el país donde Mat quiere vender (veredicto: océano azul / entrada viable / competido / saturado).
6. Seguir con `desarme-landing` → `oferta-completa` → `escalera-de-valor` → `modelar-ofertas` → `lanzar-en-hotmart`.

## Prueba del 2026-10-19 (solo lectura)

- Servidor: versión 2026.10.19-limpieza. **11 ofertas** cumplen las reglas por defecto.
- Las 3 más escaladas: una app de series cortas (GB, **no modelable**: es entretenimiento), un infoproducto de anuncios y embudos en Hotmart (BR, 76 copias, 60 días) y otro de Hotmart (BR, 55 copias, 143 días). Las tres "falta confirmar en Meta" y ninguna con creativos nuevos esta semana.
- Tendencias 14 días: 21 ofertas nuevas escaladas; Negocios y Dinero (5, todas Brasil), Gastronomía y Recetas (2).

## Reglas de uso

- Nada de `limpiar_anuncios` sin un sí explícito de Mat (borra para siempre).
- Publicar informes en el panel o guardar escaneos: preguntar antes, salvo que Mat lo pida.
- No inventar números: todo dato sale del robot o de Meta, con fecha.

---
Relacionado: [[ELEGIR_Y_MODELAR_OFERTAS]] · [[2026-10-19_cazador_3-ofertas]]
Volver a [[INICIO]]
