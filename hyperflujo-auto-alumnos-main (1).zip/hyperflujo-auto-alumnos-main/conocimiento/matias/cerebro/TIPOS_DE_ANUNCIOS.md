> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/TIPOS_DE_ANUNCIOS.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-19. IDs reemplazados por marcadores.

# Tipos de anuncios

Catálogo de todos los formatos de anuncio que usa la persona: qué es cada uno, para qué nivel de conciencia sirve (ver `ESTRATEGIA_DE_ANUNCIOS.md`), cómo se arma y un ejemplo real.

Lo marcado *(mi lectura)* es interpretación de Claude, a confirmar.

---

## Catálogo por nivel de conciencia

Cada tipo se puede hacer en reel, placa o carrusel. ✅ = tipo que la persona ya usa (dato, 2026-10-18). 🆕 = propuesto por Claude, a probar. El nivel de cada uno es la propuesta de Claude, a confirmar.

### C1: emoción, no sabe que tiene el problema

| Tipo | Qué es | Ejemplo (oficio plomería) |
|---|---|---|
| ✅ Story time con gancho controversial | Historia exagerada del nicho + pivote a la venta (skill `anuncio-storytime-controversial`) | "Soy plomero y me sé los nombres de las griferías..." |
| ✅ Antes y después | Situación inicial contra resultado, promesa real | Baño inundado → baño arreglado por uno mismo |
| ✅ Blooper | Alguien haciéndolo mal, para que se identifique | El que ajusta la canilla y le salta el chorro a la cara |
| ✅ Historieta cómica | 4 viñetas: problema → descubrimiento → acción → resultado | |
| ✅ Noticia de último momento | Formato de noticiero o placa "ÚLTIMO MOMENTO" con algo del nicho, en tono exagerado | "ÚLTIMO MOMENTO: hombre pidió 'el cosito que va en el coso' y el ferretero renunció" |
| ✅ Escenas | Una escena actuada del día a día del nicho | Suegra llamando un domingo: "¿me venís a ver la pérdida?" |
| 🆕 POV | "POV: sos [rol] y te pasa [situación]" | "POV: sos plomero y en el asado todos te cuentan su pérdida" |
| 🆕 Cosas que nadie te dice | Lista de verdades incómodas o graciosas del oficio | "3 cosas que nadie te dice de ser plomero" |
| 🆕 Opinión polémica | Una afirmación que divide y genera comentarios, del nicho | "Opinión impopular: llamar al plomero es pagar por algo que aprendés en una tarde" |
| 🆕 Un día en la vida | Un día del que ya vive del oficio por su cuenta | Mañana con 3 trabajos, tarde libre |
| 🆕 Meme del nicho | Placa meme con un chiste interno del rubro | Plantilla de meme conocida con el chiste del oficio |
| 🆕 "¿Te pasó?" | Placa o video que pregunta por una situación típica e invita a comentar | "¿A quién le pasó que la canilla gotea justo un domingo?" |

### C2: sabe que tiene el problema, no sabe cómo resolverlo

| Tipo | Qué es | Ejemplo |
|---|---|---|
| ✅ Tutorial | Paso a paso corto que se puede hacer de verdad | "Cómo cambiar el cuerito de una canilla en 3 pasos" |
| ✅ Testimonio | Alguien real cuenta su experiencia con el producto | Captura o video de un alumno real |
| ✅ Resultados | Lo que consiguieron alumnos o el producto, con prueba real | Fotos de trabajos hechos por alumnos |
| 🆕 3 errores | "3 errores que cometés cuando..." | "3 errores que hacen que tu canilla vuelva a gotear" |
| 🆕 Amateur vs profesional | Comparación lado a lado de cómo lo hace cada uno | Teflón mal puesto contra bien puesto |
| 🆕 Respondo comentarios | Responder una pregunta real de un comentario | "Me preguntaron si se puede aprender sin experiencia..." |
| 🆕 Mitos | Mito contra realidad del nicho | "Mito: hace falta matrícula para arreglar una pérdida" (solo si es cierto) |
| 🆕 Clase 1 gratis | Un pedacito real de la primera clase del curso | 30 segundos de la clase de herramientas |
| 🆕 Checklist / infografía | Placa o carrusel con una lista útil para guardar | "Las 10 herramientas básicas del plomero" |
| 🆕 Demostración en tiempo real | Hacer algo de principio a fin sin cortes | "Mirá cómo destapo esto en 60 segundos" |
| 🆕 Cuánto se cobra | Precios reales de mercado de trabajos del oficio, como dato educativo | "Cuánto se cobra hoy cambiar un flexible" (con fuente real, sin prometer ingresos) |

### C3: sabe cómo resolverlo, está eligiendo con quién

| Tipo | Qué es | Ejemplo |
|---|---|---|
| Oferta directa | Producto + precio + condiciones + botón (sale de la clase) | Placa del pack con precio y garantía |
| Rompe objeciones | Objeciones tachadas con su respuesta (sale de la clase) | "No tengo tiempo" → a tu ritmo |
| Producto por dentro | Mostrar la plataforma, los módulos, los materiales (sale de la clase) | Grabación de pantalla recorriendo el curso |
| 🆕 Apilado de valor | Curso + bonos uno por uno, con lo que incluye cada uno | "Curso + bono electricista + bono epoxy" |
| 🆕 Garantía al frente | La garantía como mensaje principal | "Probalo 7 días: si no te sirve, te devolvemos la plata" |
| 🆕 Comparación de precio | El precio frente a algo cotidiano | "Sale menos que llamar al plomero una vez" (si es verdad) |
| 🆕 Cómo comprar | Paso a paso de cómo se paga y cómo llega el acceso | Para el que duda del proceso |
| 🆕 Preguntas frecuentes | Las 4 o 5 dudas de compra respondidas | "¿Necesito herramientas? ¿Cuánto dura? ¿Tiene certificado?" |
| 🆕 Recordatorio | "¿Lo viste y no te decidiste?" para el que ya vio los C1 y C2 | Solo con condiciones reales: nada de cupos o precios falsos |

**Regla para todos:** testimonios, resultados, garantías, descuentos y cupos tienen que ser reales. Las escenas actuadas no pueden parecer un testimonio real.

---

## 1. Reel story time con gancho controversial ✅

- **Qué es:** video vertical de 17 a 25 s, con voz en off "del oficio", clips del oficio y subtítulos grandes. Gancho exagerado del nicho → pivote → venta.
- **Nivel:** abre como C1 y cierra como C3 *(mi lectura)*.
- **Cómo se arma:** skill `anuncio-storytime-controversial`. Para producirlo con clips reales y voz: skill `reel-clips`.
- **Ejemplos:** anuncios 01 a 05 (cámaras, herrería, mecánica, plomería, steel framing).

## 2. Reel UGC con creadora (IA) ✅

- **Qué es:** una "creadora" generada con IA que habla a cámara en primera persona, en un lugar cálido. Da valor (un ritual, una rutina, un error de principiante) y cierra con "si te da curiosidad, link abajo". Sin precio.
- **Nivel:** C1 (rutina, emoción) o C2 (tutorial, error de principiante), según el guion. (Dato: nombres de archivo de la persona.)
- **Cómo se arma:** skill `ugc-video-hiperrealista`.
- **Ejemplos:** anuncios 06 a 09 (grimorio).

## 3. Placa (imagen estática)

> Catálogo completo de placas por nivel de conciencia: `05_PROCESOS/TIPOS_DE_PLACAS.md` (2026-10-18).

- **Qué es:** [Pendiente: explicación de la persona]
- **Nivel:** [Pendiente]
- **Cómo se arma (texto, diseño, medidas):** [Pendiente]
- **Variantes:**
  - *Placa de oferta directa* (C3): producto + precio + condiciones + botón. Ejemplo: imagen 02, pack de 7 libros a US$ 14,99 *(mi lectura)*.
  - *Placa rompe objeciones* (C3): objeciones tachadas con su respuesta (sale de la clase; falta un ejemplo real).
  - *Placa del producto por dentro* (C3): sale de la clase; falta un ejemplo real.
  - [Pendiente: otras]
- **Ejemplos:** imagen 02.

## 4. Carrusel

- **Qué es:** [Pendiente: explicación de la persona]
- **Nivel:** C2 cuando es educativo / paso a paso (sale de la clase).
- **Cómo se arma (cantidad de imágenes, qué va en cada una, primera y última):** [Pendiente]
- **Ejemplos:** imagen 01, ritual de baño, podría ser la tapa de un carrusel *(mi lectura)*. [Pendiente: ejemplos reales]

## 5. Historieta / viñetas

- **Qué es:** imagen de 4 cuadros con un personaje (IA), globos de diálogo y un mini arco: problema → descubrimiento → acción → resultado emocional. Abajo, el nombre del producto y el llamado a la acción.
- **Nivel:** C1, del tipo antes y después *(mi lectura)*.
- **Ejemplo:** imagen 03, grimorio.
- [Pendiente: confirmar si es un formato que usa seguido]

## Otros formatos (pendientes)

- Video horizontal (estilo YouTube): anuncio 08.
- Video cuadrado (feed).
- Blooper (C1), antes y después (C1), demostración o testimonio (C2): salen de la clase; faltan ejemplos reales.
- [Pendiente: los que agregue la persona]

---
Relacionado: [[ESTRATEGIA_DE_ANUNCIOS]] · [[TIPOS_DE_PLACAS]] · [[METODO_STORYTIME_CONTROVERSIAL]] · [[ANUNCIOS]]
Volver a [[INICIO]]
