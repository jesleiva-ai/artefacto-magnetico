> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/TIPOS_DE_PLACAS.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-19. IDs reemplazados por marcadores.

# Tipos de placas (anuncios de imagen estática)

**48 formatos:** 17 C1 · 15 C2 · 16 C3. Los 20 marcados ✅ son de la persona; los 28 marcados 🆕 los propuso Claude y están para probar. (Actualizado 2026-10-18.)

**Uso:** cada vez que haya que armar anuncios de placa para un producto, elegir de acá (3 por nivel para una Cash Trap) y adaptar el ejemplo al nicho del producto.

Todos los tipos de anuncio llevados a formato placa, más tipos que solo existen como placa. Para cada uno: nivel de conciencia, cómo se arma y un ejemplo (con plomería, para que se vea la idea; se adapta a cualquier nicho).

✅ = tipo que la persona usa o pidió sumar (dato, 2026-10-18). 🆕 = propuesta de Claude, a probar. El nivel de cada placa es propuesta de Claude, a confirmar.

---

## Reglas generales de una placa

- **Se entiende en 1 segundo.** Título grande, de 12 palabras como máximo. Si hay que hacer zoom para leer, no sirve.
- **Una sola idea por placa.**
- **Medidas:** 1:1 (1080×1080) o 4:5 (1080×1350) para el feed; 9:16 (1080×1920) para historias. Con ubicaciones Advantage+, conviene subir 4:5 y 9:16.
- **Poco texto, letra gruesa y contraste fuerte.** Lo demás va en el texto del anuncio.
- **En C3, siempre visibles:** precio, lo que incluye y un botón dibujado ("Quiero el mío →").
- **Todo lo que se dice es real:** descuentos, garantías, testimonios, resultados, cupos. Si un 50% OFF no es real, no se usa.
- **Nada que parezca un testimonio o una noticia real si es inventado.** El humor tiene que verse como humor.

---

## C1: emoción (frenar el scroll)

| Placa | Cómo se arma | Ejemplo |
|---|---|---|
| ✅ Story time | Foto fuerte del nicho + título con la frase controversial + 1 línea de pivote abajo | Foto de ferretería: "No le pido 'el cosito que va en el coso'. Me lo sé de memoria." / abajo: "Aprendé plomería → link" |
| ✅ Antes y después | Placa partida en dos: ANTES / DESPUÉS con la misma escena | Baño inundado / baño arreglado. "De esto... a esto, en una tarde." |
| ✅ Blooper | Foto del error con un título irónico | Chorro de agua en la cara: "Cuando 'era solo ajustar la canilla'." |
| ✅ Historieta cómica | 4 viñetas con globos: problema → idea → acción → resultado; producto abajo | Como la del grimorio |
| ✅ Noticia de último momento | Diseño de portada de diario o placa roja "ÚLTIMO MOMENTO", **en tono de humor evidente** | "ÚLTIMO MOMENTO: hombre pidió 'el cosito del coso' y el ferretero pidió licencia" |
| ✅ Escena | Foto de la escena actuada con un globo o subtítulo | Suegra al teléfono: "¿Me venís a ver la pérdida? Es un segundito..." |
| ✅ Meme | Plantilla de meme conocida con el chiste interno del nicho | "Yo explicándole al ferretero lo que necesito" + foto del meme |
| ✅ Opinión polémica | Formato tweet o post (fondo blanco, foto de perfil, texto) | "Opinión impopular: pagar un plomero es pagar algo que aprendés en una tarde." |
| 🆕 POV | "POV:" + situación + foto en primera persona | "POV: sos plomero y en el asado todos te cuentan su pérdida" |
| 🆕 "¿Te pasó?" | Pregunta grande + foto típica; invita a comentar | "¿A quién le gotea la canilla justo un domingo?" |
| 🆕 Nota del celular | Captura estilo app de notas con una lista honesta y graciosa | "Cosas que aprendí en mi primer año de plomero: 1. Nunca digas 'es un minuto'..." |
| 🆕 Carta escrita a mano | Foto de una hoja escrita a mano con un mensaje corto | "Querido yo de hace 5 años: aprendé un oficio." |
| 🆕 Expectativa vs realidad | Placa partida: EXPECTATIVA / REALIDAD, con dos fotos del nicho | "Lo que pensé que era ser plomero / lo que es de verdad" |
| 🆕 Cartel de advertencia | Diseño de señal amarilla de peligro con un chiste del nicho | "⚠️ PELIGRO: suegra con canilla rota a la vista" |
| 🆕 Búsqueda de Google | Captura del buscador con el autocompletado de dudas típicas | "cómo arreglar una canilla que gotea a las 3 de la mañana..." |
| 🆕 Horóscopo del oficio | Los 12 signos (o algunos) como personajes del rubro; muy compartible | "Los signos del zodíaco como plomeros" |
| 🆕 Ranking / tier list | Tabla de categorías (de mejor a peor) con elementos del nicho | "Los clientes del plomero, del mejor al peor" |

## C2: enseñar (subir la conciencia)

| Placa | Cómo se arma | Ejemplo |
|---|---|---|
| ✅ Tutorial | 3 pasos numerados con mini foto cada uno (si son más de 3, mejor carrusel) | "Cambiá el cuerito en 3 pasos: 1. Cerrá la llave 2. ... 3. ..." |
| ✅ Testimonio | Captura **real** de un mensaje o comentario de un alumno (con permiso; tapar datos personales) | "Arreglé el baño de mi vieja con lo que aprendí 🙌" |
| ✅ Resultados | Collage de trabajos **reales** de alumnos | 4 fotos de instalaciones hechas por alumnos |
| ✅ Cosas que nadie te dice / secretos | Título "Lo que nadie te dice de..." + 3 puntos cortos | "3 secretos que los plomeros no te cuentan" |
| ✅ Mito vs realidad | Dos columnas: MITO ❌ / REALIDAD ✅ | "Mito: hace falta un taller. Realidad: arrancás con 10 herramientas." (solo si es cierto) |
| ✅ Amateur vs profesional | Placa partida con dos fotos: así lo hace el amateur / así el profesional | Teflón mal puesto / bien puesto |
| ✅ 3 errores que no sabías | Título + 3 errores numerados con ❌ | "3 errores que hacen que tu canilla vuelva a gotear" |
| 🆕 Checklist / infografía | Lista para guardar, con íconos | "Las 10 herramientas básicas del plomero" |
| 🆕 Esto o esto | Pregunta A/B con dos fotos; genera comentarios y enseña en la respuesta | "¿Cuál está bien instalado? ¿A o B?" |
| 🆕 Cuánto se cobra | Tabla de precios **reales de mercado** de trabajos del oficio, con fuente y fecha | "Cuánto se cobra hoy: cambiar flexible $X, destapar $Y" (sin prometer ingresos) |
| 🆕 Plan de 7 días | Calendario con qué se aprende cada día | "Semana 1 del curso: lunes herramientas, martes..." |
| 🆕 Glosario / traductor | Dos columnas: cómo lo dice la gente / cómo se llama de verdad | "'El cosito' = niple · 'la goma' = cuerito" |
| 🆕 Foto con círculo rojo | Foto de un trabajo real con el error marcado en rojo | "¿Ves el problema?" |
| 🆕 Antes de comprar, leé esto | Lista de lo que sí y lo que no conviene comprar al arrancar | "No compres herramientas hasta ver esto" |
| 🆕 Diagrama simple | Esquema claro de cómo funciona algo del nicho, en una sola imagen | "Así funciona el agua en tu casa" |

## C3: cierre (vender)

| Placa | Cómo se arma | Ejemplo |
|---|---|---|
| ✅ Venta directa | Mockup del producto + nombre + precio grande + qué incluye en 3 líneas + botón | Como la del pack de 7 libros (US$ 14,99, pago único, acceso, garantía) |
| ✅ 50% de descuento | Precio tachado + precio nuevo enorme + condición clara. **Solo si el descuento es real.** | "~~$13.000~~ $6.500 — 50% OFF" |
| ✅ Garantía | Sello de garantía grande como protagonista | "Probalo 7 días. Si no te sirve, te devolvemos la plata." |
| ✅ Derriba objeciones | 3 o 4 objeciones tachadas, cada una con su respuesta | ~~"No tengo tiempo"~~ → a tu ritmo · ~~"No tengo plata"~~ → cuotas |
| ✅ Producto por dentro | Mockup de la plataforma en celular o compu, con módulos visibles | Captura del aula con la lista de clases |
| 🆕 Apilado de valor | Curso + cada bono como "tarjetas" una debajo de otra, con lo que incluye cada uno | "Curso de steel framing + Bono electricista + Bono epoxy" |
| 🆕 Comparación de precio | Precio frente a un gasto cotidiano | "Sale menos que una visita del plomero." (si es verdad) |
| 🆕 Ticket / recibo | Diseño de ticket que suma lo que gastás en arreglos contra el precio del curso | "Plomero x3 = $$$ / Curso = $6.500" (con números reales) |
| 🆕 Preguntas frecuentes | 4 o 5 dudas de compra con respuesta corta | "¿Necesito experiencia? No. ¿Cuánto dura? ..." |
| 🆕 Cómo comprar | 3 pasos: tocás el botón → pagás → te llega el acceso al mail | Para el que duda del proceso |
| 🆕 "No lo compres si..." | Anti-venta honesta: para quién NO es | "No lo compres si no pensás practicar." Filtra y genera confianza |
| 🆕 Certificado | Foto del certificado, **solo si el curso lo entrega de verdad** | "Al terminar, te llevás tu certificado" |
| 🆕 Recordatorio | "¿Lo viste y no te decidiste?" + producto + precio | Para el que ya vio los C1 y C2. Sin cupos ni plazos falsos |
| 🆕 Precio por día | El precio dividido por día, con la cuenta real | "Menos de $X por día durante un mes" |
| 🆕 Regalo sorpresa | Caja de regalo abierta con los bonos saliendo | "Además, te llevás..." |
| 🆕 Lo que te llega al comprar | Mockup del mail o del acceso que recibe la persona | Responde "¿y después de pagar qué pasa?" |

---

## Cómo combinarlas en una Cash Trap de 9 anuncios

Ejemplo de reparto con placas y videos mezclados:
- **C1:** 1 reel story time + 1 placa meme + 1 placa antes y después.
- **C2:** 1 reel tutorial + 1 placa mito vs realidad + 1 carrusel de 3 errores.
- **C3:** 1 placa de venta directa + 1 placa que derriba objeciones + 1 placa de garantía o producto por dentro.

Así cada nivel tiene 3 anuncios distintos en ángulo y en formato.

---
Relacionado: [[ESTRATEGIA_DE_ANUNCIOS]] · [[TIPOS_DE_ANUNCIOS]] · [[ANUNCIOS]]
Volver a [[INICIO]]
