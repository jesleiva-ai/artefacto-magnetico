> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/UTMIFY.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-22. IDs reemplazados por marcadores.

# Utmify: cómo se conecta cada producto

Fuente: Mat y el soporte de Utmify, 2026-10-21/22.

## 1. Parámetros de URL en los anuncios (lo mismo en todos)
En Meta, en cada **anuncio** (no en la campaña ni en el conjunto), abajo de todo, en **"Parámetros de URL"**, se pega este texto tal cual, sin espacios:

```
utm_source=FB&utm_campaign={{campaign.name}}|{{campaign.id}}&utm_medium={{adset.name}}|{{adset.id}}&utm_content={{ad.name}}|{{ad.id}}&utm_term={{placement}}&xcod=FBhQwK21wXxR{{campaign.name}}|{{campaign.id}}hQwK21wXxR{{adset.name}}|{{adset.id}}hQwK21wXxR{{ad.name}}|{{ad.id}}hQwK21wXxR{{placement}}
```

Antes de guardar, revisar en pantalla que lo tengan todos los anuncios. Si Mat los agrega desde el Administrador, quedan como "cambios sin publicar" hasta que se toque **Publicar**.

## 2. Píxel en Utmify
En Utmify, en **Integrações → Pixel → Adicionar Pixel**: nombre del producto, tipo Meta, el ID del píxel de Meta y el **token de la API de conversiones**. El token lo pega Mat, porque es una clave y Claude no la escribe.

| Producto | Píxel de Meta | ID del píxel en Utmify |
|---|---|---|
| Planos Listos | [ID_PIXEL] | [ID_PIXEL_UTMIFY] |
| Método del Consultor | [ID_PIXEL] | [ID_PIXEL_UTMIFY] |
| Gessetti (IT) | [ID_PIXEL] | [ID_PIXEL_UTMIFY] |

## 3. Código en la página de venta (y en cualquier página antes del checkout)
Se reemplaza el píxel propio de Meta por esto, cambiando el número por el ID de Utmify del producto. Si quedan los dos, Meta cuenta doble:

```html
<!-- Utmify: píxel + script de UTMs -->
<script>window.pixelId="ID_DE_UTMIFY";</script>
<script async defer src="https://cdn.utmify.com.br/scripts/pixel/pixel.js"></script>
<script src="https://cdn.utmify.com.br/scripts/utms/latest.js" data-utmify-prevent-subids async defer></script>
```

Las páginas que van después del pago (ofertas del embudo y gracias) no lo llevan. Si una venta aparece con motivo "UTMs vacías", es que falta este código en la página.

---
Relacionado: [[ESTRATEGIA_DE_ANUNCIOS]] · [[LECCIONES]]
