> Copia saneada del segundo cerebro de Matías (`05_PROCESOS/WEB_EN_OTRO_IDIOMA_CALCO.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-26. IDs reemplazados por marcadores.

# Web de un producto en otro idioma = calco de la web en español

Fecha: 26/10/2026 · Fuente: Mat, en el chat, viendo las 11 webs del Método del Consultor.

> «es mi propia página, son mis productos, es mi propio testimonio, es todo lo mismo. Tiene que ser tal cual igual el calco… para todos los países donde se venda Método Consultor tiene que ser la misma web traducida. Nada más. No puede cambiar nada… hay mucha plata que se invierte acá».

## La regla
- La web de cada idioma es la web en español publicada, copiada tal cual y traducida. Esto incluye la landing, las ofertas del embudo (upsell y downsells), la página de gracias y el portal.
- Queda igual: el HTML, las secciones, el orden, las fotos, los colores, las fuentes, los botones, los testimonios (traducidos tal cual) y el conversor de moneda.
- Cambia solo:
  - el texto traducido;
  - los links del checkout y del portal del idioma;
  - el píxel del idioma;
  - las imágenes con texto en español visible, que se reemplazan por la misma imagen en el idioma, con el mismo encuadre;
  - la dirección RTL en árabe y en hebreo.
- Nada de fotos nuevas, secciones nuevas ni «mejoras».
- Antes de publicar, se comparan capturas en celular de la versión en español y de la del idioma, sección por sección.

## Por qué
El 25 y el 26/10 los agentes armaron cada web con imágenes y estructuras propias, y quedaron todas distintas. Mat: «no va a vender». La web en español es la que vende y la que se modela.

## Cómo se aplica
- Brief para los agentes: `D:\creativos\matias-proceso-lanzamiento\BRIEF_LANDING_IGUAL_ES.md`.
- Vale para cualquier producto que se lance en otro idioma, no solo para el Consultor.
