> Copia saneada del segundo cerebro de Matías (`08_REFERENCIAS/paginas/2026-10-21_desarme_bebe-comelon.md`), tomada el 2026-10-26 (nota del 2026-10-21). IDs reemplazados por marcadores. Ejemplo de la skill `desarme-landing` sobre una landing de la competencia.

# Desarme: Bebé Comelón (bebecomelon.com)

- Fecha: 2026-10-21 · Página de Meta [ID_META] · Cobra con Hotmart · Español (LatAm + España).
- Página real: la misma URL que usan los anuncios, sin señales de cloaker (los anuncios llevan directo a bebecomelon.com).
- Modelado propio: Happy Little Eaters (inglés), `D:\creativos\bebe-comelon-en\`.

## 1. Estructura (en orden)
| # | Sección | Qué hace | Elementos |
|---|---|---|---|
| 1 | Primera pantalla | Promesa: alimentar al bebé desde los 6 meses sin pensar cada día qué darle | Título serif grande, mockup del recetario, insignias (desde 6 meses, recetas, acceso inmediato), botón |
| 2 | "¿Te sentís identificada?" | 6 dolores de la mamá (no sabe qué darle, miedo, falta de tiempo, rechazo) | Tarjetas con ícono |
| 3 | Qué hay en el libro | Recetas por momento del día: desayunos, almuerzos, meriendas, cenas, postres, más papillas | Fotos de cada categoría |
| 4 | Mirá lo que incluye | Carrusel de páginas reales del recetario (unas 12) | Imágenes de páginas |
| 5 | Qué cambia para vos | 6 cambios (organización, tranquilidad, variedad) | Tarjetas con tilde |
| 6 | Temario | 8 partes en acordeón | Desplegables |
| 7 | Bonos | Bonos "valorados en USD 95" (snacks de fruta, dulces sin azúcar, +100 recetas, guía con imágenes, remedios naturales, estimulación temprana) | Mockup por bono |
| 8 | Elegí tu opción | Dos planes: Esencial 12,99 y Súper 17,99, con tabla comparativa | Dos cajas de precio, 2 botones |
| 9 | Para vos / no para vos | Filtra al comprador | Dos columnas |
| 10 | Historia de la fundadora | "Soy María José", mamá que creó el recetario | Foto |
| 11 | Testimonios | Opiniones de "mamás reales" | Capturas y fotos |
| 12 | Compra segura | Sello Hotmart, pagos | Íconos |
| 13 | Preguntas frecuentes | 11 preguntas (edad, ingredientes, acceso, pago, alergias) | Acordeón |
| 14 | Qué pasa después de comprar | 4 pasos | Pasos numerados |
| 15 | Llamado final | Repite oferta | Botón |

Botón de compra: en primera pantalla, en la caja de precios (2) y al final. Hay 4 videos insertados en la página.

## 2. Visual
- Paleta: bordó oscuro #431927 (texto y fondos), verde #31816D (botones), bordó #791537, coral #DD6C3C, mostaza #DA8E0B; fondo casi blanco #FBFAF9 con tintes amarillos suaves.
- Tipografías: títulos Cormorant Garamond / Playfair (serif elegante), texto Nunito y Quicksand (redondeadas).
- Imágenes: mockups del libro, fotos de comida, páginas reales del recetario. 89 imágenes en total.
- Celular: todo en una columna, carruseles deslizables.

## 3. Escritura (descrito, no copiado)
- Le habla a la mamá primeriza que arranca la alimentación complementaria. Tono cálido y de "te entiendo".
- Títulos en pregunta ("¿te sentís identificada…?") y de beneficio.
- Nivel C1–C2: reconoce el problema y muestra la solución.

## 4. Gatillos
- Garantía de 7 días (Hotmart). Bonos con valor tachado. Precio con 50% off.
- Prueba social: testimonios y autoridad ("avalado por pediatra"), contador de "personas comprando ahora" y reloj de 15 minutos. **No se modelan** (no son verificables / promesas de salud).

## 5. Oferta
- Esencial USD 12,99 / Súper USD 17,99. Hotmart. No se ven bumps sin entrar al checkout; upsells no visibles sin comprar.

## 6. Anuncios que la alimentan
33 activos (2026-10-21). Ganadores (más días al aire y copias del mismo texto):
| ID | Desde | Formato | Gancho | Texto |
|---|---|---|---|---|
| [ID_META] | 5-may-2026 | Video 28 s vertical: comida real (cuchara con papilla, platos), texto encima | "¿Tu bebé arranca la alimentación complementaria y no sabés qué cocinarle?" | Esquema fijo: pregunta de dolor + "sé lo que se siente" + qué es (+400 recetas desde 6 meses, guía BLW) + resultado emocional + lista de regalos + "50% off, clic en Comprar" |
| [ID_META] | 5-may-2026 | Video 27 s: tapa del recetario y páginas | mismo gancho | mismo texto |
| [ID_META] | 5-may-2026 | Carrusel de 5 placas: "Receta BLW fácil", "+400 recetas", tapas de los libros | mismo gancho | mismo texto |
| [ID_META] | 24-jul-2026 | Video 33 s: una receta paso a paso (puré de quinoa) con la página del libro | mismo gancho | mismo texto |
| [ID_META] | sep-2026 | Video, título "+400 recetas nutritivas" | mismo gancho | mismo texto |

El texto es siempre el mismo y los creativos cambian. Titulares del enlace: "Más de 400 recetas para tu bebé", "Recetario #1…". Desde octubre suma anuncios de "reservá tu cupo gratis" (otro embudo, no se modela).

## 7. Por qué vende
1. Dolor muy concreto y momento de vida claro (empieza a comer a los 6 meses).
2. Organización por momento del día: resuelve "qué le doy hoy".
3. Muestra páginas reales: se ve lo que se compra.
4. Precio bajo con muchos bonos.
5. Videos de comida real, simples de producir.

## Qué tomamos
Orden de secciones 1–9 y 12–15, páginas reales visibles, recetas por momento del día, bonos con mockup, preguntas frecuentes y 4 pasos. No tomamos: fundadora, testimonios, "avalado por pediatra", contador de compras, reloj de 15 minutos, bonos de salud. Precio: escalera del Consultor (19,99 con ancla 39,98).
