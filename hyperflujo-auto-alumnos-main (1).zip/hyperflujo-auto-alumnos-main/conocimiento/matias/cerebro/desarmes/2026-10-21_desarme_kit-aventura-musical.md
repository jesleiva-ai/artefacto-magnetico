> Copia saneada del segundo cerebro de Matías (`08_REFERENCIAS/paginas/2026-10-21_desarme_kit-aventura-musical.md`), tomada el 2026-10-26 (nota del 2026-10-21). IDs reemplazados por marcadores. Ejemplo de la skill `desarme-landing` sobre una landing de la competencia.

# Desarme · Kit Aventura Musical (original en español)

Fecha: 2026-10-21. Landing: https://kitaventuramusicall.lovable.app/ (Lovable, cobra con Hotmart `pay.hotmart.com/[CODIGO_PRODUCTO]`). Página de Meta "Laura Martínez" ([ID_META]), 37 anuncios activos, el primero del 14/09/2026. Leída con Edge sin ventana (página armada por JavaScript). Cloaker: el análisis de Nexus Profit no encontró señales; no se pasó `detector-cloaker` completo.

Se usa para modelar **Music Adventure Kit** (inglés), `D:\creativos\kit-musical-en\`.

## 1. Estructura (en orden)

| # | Sección | Qué hace | Elementos |
|---|---|---|---|
| 1 | Primera pantalla | Avisa a quién le habla (educadoras, terapeutas, madres) y promete +160 actividades listas aunque nunca hayas tocado un instrumento | Etiqueta de aviso, título con número, subtítulo, **botón con precio**, fila de 4 sellos (páginas, cantidad de educadoras, garantía, descarga) |
| 2 | "La cruda realidad" | Dolor del domingo a la noche: 4 frases con ✕ | Lista con cruces |
| 3 | "Imagínate esto" | El después: 4 frases con ✓ | Lista con tildes |
| 4 | "El sistema probado" | Cómo se recibe y se usa en 3 pasos (descarga, imprime, aplica) | 3 pasos numerados |
| 5 | "Por dentro del kit" | Números del contenido: páginas, dinámicas, 48 tarjetas, juegos | 4 contadores grandes |
| 6 | Vista previa | Muestra páginas del material | 4 imágenes del material |
| 7 | Testimonios | 3 testimonios con nombre y rol (uno habla de pacientes TEA) | Estrellas + **botón** |
| 8 | Bonos | 3 bonos con "valorado en" y "hoy gratis" (canciones, planificador anual, fichas de ritmo corporal) | Imagen por bono |
| 9 | Resumen de inversión | Suma de valores (57) contra el precio (7,90) | Tabla de valores, **botón con precio**, 3 sellos |
| 10 | Garantía | 7 días, "riesgo de nuestro lado" | Escudo |
| 11 | Preguntas frecuentes | Mensualidad, formato, pago seguro, otro país, acceso | Acordeón |
| 12 | Pie | Derechos | — |
| — | Flotante | Aviso "X de México acaba de comprar" | Notificación de ventas (probablemente falsa) |

Botón de compra: **3 veces** (primera pantalla, después de testimonios, resumen de inversión).

## 2. Visual
- Paleta: crema `#FCFBF8`, violeta `#575ECF`, rojo-naranja `#FE3F21`, naranja `#FE7B02`, rosa `#F858BC`, texto casi negro `#1B1B1B`.
- Tipografías: Fraunces (títulos) e Inter (texto).
- Imágenes: mockups del kit (6), vista previa de páginas (4), una por bono (3). Hecha para celular.

## 3. Escritura
- Promesa: muchas actividades musicales listas para imprimir, sin saber música y sin planificar.
- Títulos: beneficio con número y frases de dolor/alivio. Tono cercano y urgente. Apunta a C2 (sabe el problema, busca solución).

## 4. Gatillos
- Garantía 7 días · 3 bonos con valor tachado · precio ancla (57 → 7,90) · prueba social ("+5.000 educadores", 3 testimonios, notificación de compras) · urgencia "oferta por tiempo limitado" sin fecha · FAQ.
- **No copiamos:** "+5.000 educadores", testimonios, la notificación de compras ni la mención a TEA (promesa de salud).

## 5. Oferta
- USD 7,90 pago único, Hotmart. No se ven order bumps ni upsells en la página.

## 6. Anuncios
- 37 activos; tandas del 14/09, 01/10 y 15/10. El más viejo ([ID_META]) es imagen con texto largo: aviso a padres/musicoterapeutas/profes → dolor (quedarse en blanco, repetir actividades) → "no te falta capacidad, te falta material" → lista de lo que recibís → descargás, imprimís, aplicás.
- Ver `D:\creativos\kit-musical-en\anuncios\ganadores_original.md`.

## 7. Por qué vende
1. Habla a un rol concreto (educadora) y a un miedo concreto ("no tengo el don").
2. Muestra el material por dentro (vista previa y contadores).
3. Precio muy bajo contra un valor sumado alto.
4. Recibir → imprimir → aplicar: cero esfuerzo.

**Qué tomamos:** el orden de las secciones 1 a 11, los sellos en la primera pantalla, dolor/alivio con ✕/✓, los 3 pasos, los contadores, la vista previa, el resumen de inversión y la garantía. Sin testimonios ni contadores de compradores.
