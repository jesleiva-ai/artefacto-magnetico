> Copia saneada del segundo cerebro de Matías (`08_REFERENCIAS/paginas/2026-10-21_desarme_planoteca.md`), tomada el 2026-10-26 (nota del 2026-10-21). IDs reemplazados por marcadores. Ejemplo de la skill `desarme-landing` sobre una landing de la competencia.

# Desarme: Planoteca (planoteca.impultienda.ar)

Fecha: 2026-10-21 · Fuente: landing leída en vivo + Biblioteca de Meta (perfil [ID_META], ~57 anuncios, desde el 18/9, 12 nuevos en 7 días). Sin cloaker: la página es la misma desde el anuncio y desde afuera.

## 1. Estructura (en orden)

| # | Sección | Qué hace | Elementos |
|---|---|---|---|
| 1 | Barra superior | Urgencia | "🔥 OFERTA LIMITADA" + reloj de minutos que se reinicia (falso) |
| 2 | Primera pantalla | Promesa: pasar de mirar madera a terminar el primer proyecto en 48 h | Título + subtítulo (+800 planos, medidas, cortes, para armar o vender), nombre del producto, ★4.9 (500+ ventas), precio tachado US$ 89,90 → US$ 17,90, lista de 3 bonos con "US$ 14 GRATIS", ahorro "86 % OFF", "quedan 4 cupos", reloj, botón, sellos (entrega inmediata · pago seguro · garantía 7 días), "24 personas viendo" |
| 3 | Bonos | Valor percibido | 3 tarjetas con nombre, descripción, "Valor: US$ 14 GRATIS"; total US$ 42 |
| 4 | ¿Qué vas a encontrar adentro? | Beneficios | 4 bloques con ícono: sabés qué comprar y cortar · proyectos en menos de 48 h · elegí según tus herramientas (kits) · encontrá proyectos según herramientas |
| 5 | ¿Te sentís identificado? | Dolor | 4 tarjetas con ✕: planos que no sirven · comprás madera y te arrepentís · no sabés por dónde empezar · algo no encaja. Cierre: "tenemos la solución" |
| 6 | Testimonios | Prueba social | Captura simulada de WhatsApp (inventada) + 500+ clientes · 4.9 · 100 % satisfacción |
| 7 | Todo lo que incluye | Stack de oferta | Producto + 3 bonos + garantía, valor total US$ 131,90 → US$ 17,90, botón |
| 8 | 3 pasos | Cómo funciona | Elegís por nivel/herramienta → comprás y cortás → armás con paso a paso |
| 9 | Garantía | Riesgo cero | 7 días, sello |
| 10 | Preguntas frecuentes | Objeciones | Sin experiencia · herramientas · materiales y cortes · aprender o vender · actualizaciones |
| 11 | Cierre | Último llamado | Precio, bonos, botón |
| 12 | Barra fija inferior + carrito | Compra | Reloj, precio, "Descargar ahora", mini-carrito con Mercado Pago, aviso "María de Buenos Aires compró" (falso) |

Botón de compra: 5 veces (primera pantalla, stack, cierre, barra fija, carrito).

## 2. Visual
- Fondo claro, acentos naranja/fuego, tarjetas blancas con borde suave, íconos emoji. Tipografía sans moderna.
- Imágenes: mockup del ebook, fotos de muebles de madera terminados.
- Pensada para celular (todo en una columna).

## 3. Escritura
- Promesa: resultado rápido y concreto (primer mueble en 48 h), sin experiencia.
- Tono: cercano, voseo argentino, frases cortas. Nivel de conciencia: C2 (sabe que quiere hacer muebles, no sabe cómo).

## 4. Gatillos
- Garantía 7 días · 3 bonos con valor · ancla 89,90 → 17,90 · escasez falsa (cupos, reloj que se reinicia, personas viendo, compras simuladas) · prueba social inventada · FAQ.
- **Lo que se modela:** estructura, bonos con valor, ancla, 3 pasos, FAQ, garantía, barra fija.
- **Lo que no se copia:** cupos, reloj falso, personas viendo, compras simuladas, testimonios inventados, cifras de ventas.

## 5. Oferta
- US$ 17,90 en Impultienda + Mercado Pago. No se ven bumps ni upsells sin comprar.

## 6. Anuncios que la alimentan
- ~57 activos (34 reales leídos), ~50 % imagen y ~50 % video.
- Formatos ganadores: **collage/grilla de fichas de planos** ("+800 planos") · **placa con tabla de cortes** ("Una tabla en proyecto…") · **video de mueble terminado con texto**.
- Ganchos (texto): "En los videos de carpintería todo parece facilísimo…" · "¿Querés hacer algo con madera este fin de semana…?" · "Improvisar sale caro cuando la madera ya está cortada" · "No necesitás seguir buscando un plano distinto…" · "Si recién estás empezando…". Esquema: frase de entrada + "Con Planoteca tenés más de 800 planos…" + lista con íconos (📐 medidas, 🪵 materiales, 🛠️ paso a paso, ✅ niveles).
- Titulares: "+800 planos con medidas y listas de cortes." · "Acceso inmediato. Medidas, cortes y paso a paso." · "No necesitás ser experto".

### Ganadores anotados (Biblioteca, página [ID_META], leído 2026-10-21)
| ID | Formato | Al aire desde | Copias | Gancho (texto) | Qué muestra |
|---|---|---|---|---|---|
| [ID_META] | Video 30 s, 9:16 | 13 oct 2026 | 3 | "En los videos de carpintería todo parece facilísimo… hasta que te toca a vos" | Persona en el taller cargando una tabla, subtítulos grandes. Texto: dolor (no dan medidas ni orden) + lista con íconos 📐🪵🛠️✅ |
| [ID_META] | Video 35 s, 9:16 | 17 oct 2026 | 3 | "Si recién estás empezando, no necesitás saber todo antes del primer proyecto" | Grilla de fichas de proyectos ("+800 planos de carpintería") que va pasando. Cierra con "hacé la prueba rápida" según nivel y herramientas |
| [ID_META] | Imagen 9:16 | 18 sep 2026 | 2 | "No necesitás seguir buscando un plano distinto cada vez" | Mesa larga con planos impresos, título "+800 planos. Una sola descarga." |
| [ID_META] | Imagen 9:16 | 18 sep 2026 | 2 | "Improvisar sale caro cuando la madera ya está cortada" | Cartel de pizarra en la puerta del taller: "Dejá de improvisar. +800 planos listos para el taller" |
| [ID_META] | Imagen 1:1 | 18 sep 2026 | 2 | "Cuando encontrás un proyecto que funciona, no tenés que volver a calcular todo" | Tres mesas iguales en el taller: "Tres mesas, un solo plano, cero improvisación" |

Esquema del texto en los 5: frase de entrada (dolor o permiso) + "Con Planoteca tenés más de 800…" + qué trae cada plano + niveles + cierre de acción. No usan testimonios en el texto.

## 7. Por qué vende
1. Promesa concreta y rápida (48 h) para principiante.
2. Elegir por herramientas que ya tenés: baja la barrera.
3. Precio bajo con ancla alta y bonos con valor.
4. Muchos creativos nuevos por semana sobre los mismos 3 formatos.
