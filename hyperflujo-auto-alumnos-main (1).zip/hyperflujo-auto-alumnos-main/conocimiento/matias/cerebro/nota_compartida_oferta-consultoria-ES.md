# Método del Consultor ES — estado 2026-10-20

Todo el detalle en D:\segundo-cerebro\06_PROYECTOS\metodo-consultor-ES\PROYECTO.md

- Oferta modelada: Consulting Management EXPLAINED (Business Explained, ~140 anuncios activos desde 2026-06-20, sin competencia en español).
- Web: https://laformulaebooks.site/metodo-consultor/ · Portal: https://laformulaebooks.site/portal-metodo-consultor/
- Hotmart: principal [CODIGO_PRODUCTO] (US$ 17,90), bumps [CODIGO_PRODUCTO]/[CODIGO_PRODUCTO]/[CODIGO_PRODUCTO] (9,99), upsell [CODIGO_PRODUCTO] (34,90), DS [CODIGO_PRODUCTO] (17) y [CODIGO_PRODUCTO] (12). Embudo [EMBUDO_ID] activo.
- Lección clave: los bumps solo se ven con el link `?checkoutMode=10` (link de "Página de Pagos estándar"). Productos en USD y país Estados Unidos (Mat).
- Meta: página Estrategia Clara [ID_PAGINA], píxel [ID_PIXEL] en morfi 1. 9 anuncios en D:\creativos\metodo-consultor-es\anuncios (sin cargar).
- Pendiente: logo/portada en la fanpage, píxel en el producto de Hotmart, compra de prueba (Mat), correcciones de la landing que Mat va a pasar.
