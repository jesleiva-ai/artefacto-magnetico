# Criterio visual y de persuasión para landings y anuncios

**Fuente:** correcciones de Matías sobre una landing modelada de un producto de Office (2026-10-26) y dos rondas más de correcciones del dueño del producto (2026-10-26 y 2026-10-27), aplicadas por el director del motor. Esta es la vara con la que se revisa una landing o un anuncio **antes** de mostrarlo: si un punto no se cumple, se corrige antes de pedir revisión humana. Cada corrección humana nueva se suma acá, con su fecha.

Complementa `recetas/metodo-consultor/RECETA.md` §5 y §6 y la skill `conocimiento/matias/skills/revisar-landing`, que cubre lo funcional (precios, checkout, píxel, celular).

## Landing: bloque por bloque

| Bloque | Lo que tiene que pasar | Lo que se corrigió porque no pasaba |
|---|---|---|
| **Hero** | Promesa **cuantitativa**: qué logra y en cuánto tiempo («Aprendé X en 27 días»). Animada (titila o cambia de color), llamativa, con contraste. | Hero «re apagado»: lindos colores, pero no retiene. |
| **Plazo de la promesa** | Sale de la **estructura real del producto** (27 capítulos → 27 días, uno por día), nunca de un resultado inventado. | — |
| **Mockup principal** | Hiperrealista, «aesthetic», grande, **en movimiento** (hojas que pasan). El libro en 3D, como objeto real. Pantallas de notebook o tablet con la página real en su proporción, sin deformar. | Producto chico, quieto y de frente; computadora plana «deja mucho que desear». |
| **Mockups con IA** | Usar las portadas reales como referencia exacta. El texto que inventa la IA (lomos, pantallas) se borra o se reemplaza por el real. | — |
| **«Mirá lo que recibís»** | Carrusel automático que avanza solo, con imágenes grandes y letra legible. **Usar capturas reales de las páginas**: la IA desfigura el texto. | Letras chicas: «no se puede apreciar qué está comprando la gente». |
| **Dolores** | Fuertes, **dedo en la llaga** (quedar en evidencia, perder oportunidades, tardar el triple). Grandes, con los **logos originales** de lo que se enseña, animados en secuencia de arriba hacia abajo. Un puente después: «te falta un método». | Letra chica, «pasan re desapercibidos». |
| **Beneficios, «es para ti», «qué vas a aprender»** | El mismo tratamiento que los dolores: grandes, animados y que se lean. Copy corto y persuasivo con **emojis de venta bien elegidos** (✅ 🚀 💡 ⏱️ 🎁 🔥), sin estrellas de reseña. | Emojis genéricos «que no llaman la atención», bloques que no se leen. |
| **Cartel del método** | Bonito, estético y legible: es el puente entre dolor y solución. | Pasaba desapercibido. |
| **Video del producto por dentro** | **Uno solo**, de calidad, en cámara lenta, que muestre todo el producto. Mejor dentro de un dispositivo hiperrealista. | Varios deslizables sueltos. |
| **Oferta** | Mockup cuidado, **precio visible y grande**, tachado con el **precio de lista real** (el que se cobra al vencer el lanzamiento), garantía con los días reales, resumen de lo que trae. | Bloque «apagadísimo» y sin precio. |
| **Cuenta regresiva** | A una **fecha real**. Si falta mucho, mostrar los días grandes más un reloj hh:mm:ss en vivo, para que se vea correr. Negrita, color, brillo. | 26 días en letra chica no generan urgencia. |
| **Botones** | Grandes, rectangulares, altos, que titilan y cambian de color. El último CTA más llamativo que el resto. De compra, 2 o 3 y solo desde la oferta (`web-como-metodo-consultor`). | — |
| **Barra fija de arriba** | **Una sola línea en celular** (~36 px): urgencia sin comerse la pantalla. | Ocupaba ~90 px fijos. |
| **Contacto** | Nunca un correo personal en la página de venta: garantía y soporte por la plataforma de cobro, o un correo de la marca. | Aparecía un Gmail personal en la garantía. |
| **Preguntas frecuentes** | Si ya funcionan, no se tocan. | — |
| **Portada del producto (ebook o PDF)** | Modelada con la misma estética que la landing y los mockups. | La portada «chocaba con todo el otro diseño». |

## Reglas que no se negocian
- Precio tachado, garantía, cifras y plazos: solo lo que está en la ficha con evidencia. Si Matías o el dueño piden un tachado que no existe, se usa el precio de lista real y se avisa.
- La cuenta regresiva apunta a una fecha real; nunca se reinicia para simular urgencia.
- Microsoft Clarity y el píxel cargan al abrir la página: ninguna landing lleva aviso de cookies (Matías, 2026-11-03).
- Conversor de moneda por país para los mercados de la campaña.

## Anuncios
- Modelar los 9 ganadores del competidor (RECETA §6), con las mismas escenas y la misma estructura.
- **Una voz distinta por anuncio** (ElevenLabs, voz nativa del mercado), para no repetir la misma voz en todo el set.
- **Música libre de derechos** (por ejemplo, Pixabay) hasta el último cuadro.
- Los primeros días Meta suele darle más entrega a las imágenes que a los videos: no apagar un video por eso antes de la ventana de corte.

## Mercado: buscar océanos azules
Antes de abrir un país nuevo: contar cuántos anuncios activos hay del mismo tipo de producto en cada país de la región y si se están vendiendo (días al aire, copias). Pocos competidores con señales de venta = océano azul candidato. Ejemplo de la corrida de octubre: para Office en LATAM aparecieron EE. UU. hispano, República Dominicana, El Salvador, Panamá y Costa Rica por encima de los mercados obvios.

## Cómo se usa en el flujo
El revisor de criterio es el **Profesor** (subagente `profesor-web`, Matías 2026-10-27; vara en `skills/profesor-web/SKILL.md`): no edita, solo juzga. El revisor recorre esta tabla con capturas a 390 y 1440 px y devuelve una lista de correcciones ordenadas por impacto. Un corrector las aplica y el revisor vuelve a mirar; si después de tres vueltas no aprueba, se le muestra al dueño con el último boletín y se sigue corrigiendo. Sin aprobado no se publica (`netlify_deploy.py` lo exige).
