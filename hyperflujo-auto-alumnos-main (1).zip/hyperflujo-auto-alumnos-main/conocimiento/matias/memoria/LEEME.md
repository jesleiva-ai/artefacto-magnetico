# memoria/ — las reglas de trabajo que Matías le fue dejando a Claude

Copia saneada, tomada el **2026-10-26**, de la memoria de Claude Code de Matías (`~/.claude/projects/<proyecto de trabajo>/memory/`). Cada archivo es una regla con su fecha, su cita («Why») y cómo se aplica («How to apply»). Se sacaron los IDs de cuentas, los nombres de cuentas publicitarias y los identificadores internos de sesión; no se copiaron las notas de cuentas personales ni la de los repos de clase de Ramiro.

Son las reglas con las que Matías trabaja **hoy** (las repetidas se unieron y lo superado se sacó). Si chocan con una skill o receta más vieja, mandan estas. Todo junto, paso por paso: `recetas/metodo-consultor/RECETA.md`. Lo más reciente:

| Fecha | Regla | Archivo |
|---|---|---|
| 2026-10-26 | Web en otro idioma = calco exacto de la web en español | `landing-idioma-copia-exacta.md` |
| 2026-10-26 | Un producto que vende va en **una sola** campaña; no duplicarlo en otras cuentas para el mismo mercado | `consultor-una-sola-campana.md` |
| 2026-10-25 | Un píxel nuevo por idioma o país (Hotmart, Utmify y conjunto) | `pixel-nuevo-por-idioma.md` |
| 2026-10-25 | Todas las pasarelas prendidas también en los embudos de Hotmart | `todos-los-pagos-prendidos.md` |
| 2026-10-24 | Anuncios nuevos = escenas nuevas (Google Flow), nunca reusar clips entre cuentas | `anuncios-escenas-nuevas-flow.md` |
| 2026-10-24 | Director con subagentes como empleados | `director-con-empleados.md`, `delegar-tareas-largas.md`, `reusar-sesiones-paradas.md` |
| 2026-10-22 | USD 75/día, el agente prende, 48 h / 5 días / +30 % cada 48 h | `campanas-prueba-y-escala.md` |
| 2026-10-22 | Botón «Más información» o «Ver detalles», nunca «Comprar» | `boton-mas-informacion.md` |
| 2026-10-22 | Tomas de video de 4 s como máximo | `videos-4-segundos-por-imagen.md` |
