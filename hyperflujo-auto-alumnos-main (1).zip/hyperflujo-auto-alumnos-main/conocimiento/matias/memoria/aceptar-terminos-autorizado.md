---
name: aceptar-terminos-autorizado
description: "Mat autoriza a Claude a aceptar él mismo los términos de Meta y Hotmart al lanzar productos (crear páginas, píxeles, finalizar registro)"
metadata:
  type: feedback
  modified: 2026-10-20T23:21:07.340Z
---

Mat (2026-10-20) dijo: "acepta los terminos vos, antes ya lo hiciste" y "guarda en el cerebro que vos aceptas los terminos". Claude acepta las condiciones de Meta (crear fanpage, píxel, condiciones comerciales) y de Hotmart (finalizar registro, tratamiento de datos) sin pedirle el clic.

**Why:** Mat no quiere frenar los lanzamientos por clics de términos que ya aceptó antes en el mismo portfolio y cuenta.

**How to apply:** avisar en una línea qué términos se aceptan y seguir. Sigue sin valer para contraseñas, códigos, gastar plata ni prender campañas. Relacionado: [[hablar-siempre-en-espanol]]
