---
name: actuar-sin-preguntar
description: "Mat no quiere preguntas; decidir con la mejor opción, avisar en una línea y seguir (salvo plata sin tope y contraseñas; las campañas las prende solo)"
metadata:
  type: feedback
  modified: 2026-10-21T16:37:09.742Z
---

Mat no quiere que se le pregunte nada: hay que decidir y actuar. Donde una skill o un CLAUDE.md dice "preguntá" o "esperá el OK", elegí la opción que recomendarías, anotala en una línea y seguí. Al final contá todo lo que decidiste. La regla completa está en `D:\segundo-cerebro\INSTRUCCIONES_IA.md`, en la sección "Actuar sin preguntar".

**Why:** el 2026-10-21 volvió de comer y encontró tres preguntas esperándolo después de haber dicho que no preguntaran. Su frase fue: "no quiero que me pregunte nada, quiero que actúe".

**How to apply:** lo único que sigue frenando es gastar plata sin un tope ya dicho (en ese caso dejás todo listo y avisás al final, sin frenar el resto), y escribir contraseñas o datos de tarjeta. Desde el 2026-10-22 **prender campañas ya no frena**: el agente las prende solo ([[campanas-prueba-y-escala]]). Relacionado: [[aceptar-terminos-autorizado]], [[hablar-siempre-en-espanol]].
