---
name: anuncios-escenas-nuevas-flow
description: "anuncios nuevos = escenas nuevas; usar Flow (logueado en Chrome, plan PLUS, imágenes ilimitadas), nunca repetir el mismo banco de clips entre cuentas del mismo producto e idioma; en otro idioma se pueden traducir"
metadata:
  type: feedback
  modified: 2026-10-25T02:26:48.423Z
---

Cuando Mat pide anuncios nuevos o escalar a otras cuentas, cada anuncio lleva **escenas nuevas**, no los mismos clips con otro guion. Para eso está **Google Flow, logueado en el Chrome de Mat (plan PLUS, imágenes ilimitadas)**: flow.google.com en Chrome, nunca en el navegador de la app (ahí no tiene la sesión).

**Why:** el 24/10/2026 se produjeron 45 anuncios del Consultor para 5 cuentas reusando 12 clips viejos (la misma reunión 3D en ~19 lugares) porque Flow «no tenía sesión» en el navegador de la app y nadie lo probó en Chrome. Mat: «Teníamos que hacer anuncios nuevos. ¿Flow no lo usaste?… tenés imágenes infinitas». Se pausaron las 5 campañas antes de salir.

**How to apply:** antes de producir, abrir Flow en Chrome y generar escenas propias para cada cuenta (otro ángulo, otra persona, otro ambiente). Si una herramienta no anda, probar en Chrome y avisar en una línea; nunca seguir en silencio con material repetido. Ver [[videos-4-segundos-por-imagen]], [[director-con-empleados]].

**Alcance (Mat, 2026-10-31):** la regla es para el **mismo producto en el mismo idioma** (por ejemplo, las 5 cuentas del Consultor en español). Para llevar un anuncio a **otro idioma** (sueco, hebreo, etc.) se pueden **traducir y reusar las escenas** de los anuncios de otro idioma, siempre que no se vea texto del idioma original. Dentro del mismo idioma, no repetir escenas entre anuncios ni entre cuentas.
