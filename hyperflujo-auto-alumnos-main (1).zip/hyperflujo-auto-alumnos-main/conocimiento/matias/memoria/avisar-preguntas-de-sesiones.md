---
name: avisar-preguntas-de-sesiones
description: "Si una sesión que mandé a trabajar le pregunta algo a Mat o espera su OK, avisarle al toque en una línea, con el link a esa sesión"
metadata:
  type: feedback
  modified: 2026-10-24T21:07:39.677Z
---

Cuando otra sesión (los "empleados" de Mat: Planos, Kit, Acordes, etc.) le hace una pregunta a Mat o queda esperando su OK, avisarle apenas me entero, en una línea y con el link a esa sesión. No quedarme callado ni esperar a que termine otra cosa.

**Why:** Mat, 24/10/2026: "cuando el empleado tuyo tenga consultas, avisame, porque me estaba preguntando cosas pero no me dijiste nada, y estaba pausado". La sesión de Planos quedó frenada esperándolo y él no se enteró.

**How to apply:** ante cualquier aviso de que una sesión está "esperando al usuario" o pide un OK, escribir primero: "La sesión de X te está preguntando Y, entrá acá: [link]", aunque esté en medio de otra tarea. Relacionado: [[actuar-sin-preguntar]].
