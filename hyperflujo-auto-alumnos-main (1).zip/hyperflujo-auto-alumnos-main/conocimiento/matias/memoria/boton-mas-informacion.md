---
name: boton-mas-informacion
description: "botón de los anuncios de Meta siempre \"Más información\" o \"Ver detalles\", nunca \"Comprar\""
metadata:
  type: feedback
  modified: 2026-10-22T18:47:21.045Z
---

En todos los anuncios de Meta el botón es **"Más información" (LEARN_MORE)** o **"Ver detalles" (SEE_DETAILS)**. Nunca "Comprar" (SHOP_NOW ni BUY_NOW). Tampoco en el texto ("Tap Shop now"): se usa "Tap Learn more" o "Tap See details".

**Why:** Mat lo pidió en la noche del 2026-10-21 y lo repitió el 2026-10-22 ("no pongas nunca botón comprar, siempre más información o ver detalles"). El handoff del Consultor y el cerebro decían "Comprar"; ya se corrigieron.

**How to apply:** C1 y C2 van con "Más información"; C3 con "Ver detalles". Revisar también los textos de anuncio que traen las sesiones (por ejemplo, `texto_anuncios.txt`) antes de cargarlos. Relacionado: [[modelar-como-metodo-consultor]].
