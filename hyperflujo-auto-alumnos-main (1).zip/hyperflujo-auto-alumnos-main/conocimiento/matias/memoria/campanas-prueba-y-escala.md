---
name: campanas-prueba-y-escala
description: "Campañas de Mat — USD 75/día de prueba, el agente las prende solo, 48 h apagar o 5 días, +30% cada 48 h, 1 a 5 ofertas a la vez"
metadata:
  type: feedback
  modified: 2026-10-25T00:17:31.317Z
---

Reglas de campaña que dijo Mat el 2026-10-22:
- Cada oferta se prueba con **USD 75 por día**.
- **El agente puede prender las campañas solo** (ya no hace falta su OK para prender).
- **48 horas sin tocar.** Si a las 48 h no vendió, se apaga. Si vendió, se deja **5 días** sin tocar. Después, **+30% de presupuesto cada 48 horas**.
- Se lanzan **de 1 a 5 ofertas a la vez**.
- **Escala:** se sube la misma campaña +30 % cada 48 h si gana; **no se duplica** en otras cuentas del mismo mercado (26/10/2026, ver [[consultor-una-sola-campana]]). Para crecer, otro idioma o país con su píxel.

**Why:** quiere que los lanzamientos corran solos con un agente que reparte trabajo entre subagentes, sin esperar sus confirmaciones.

**How to apply:** al terminar de cargar una Cash Trap, prenderla y avisar. Revisar a las 48 h y aplicar la regla. La skill `cash-trap-cbo-oro` además pide ROAS 2 o más para subir presupuesto. El handoff completo está en `D:\creativos\matias-proceso-lanzamiento\12_metodo_consultor_handoff_agente.md`. Relacionado: [[actuar-sin-preguntar]] · [[modelar-como-metodo-consultor]].

