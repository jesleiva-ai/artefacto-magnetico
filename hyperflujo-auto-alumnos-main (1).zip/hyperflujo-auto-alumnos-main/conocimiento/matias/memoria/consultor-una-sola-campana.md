---
name: consultor-una-sola-campana
description: "El Consultor corre en UNA sola campaña (la cuenta principal); S1–S5 quedan en pausa y sus anuncios son el banco de reserva"
metadata:
  type: project
  modified: 2026-10-26T17:06:50.849Z
---

Desde el 26/10/2026, el Método del Consultor se vende con una sola campaña: "CONSULT 21/10" ([ID_CAMPANA]), en su cuenta principal ([act_CUENTA]).
- Las copias S1 a S5, en otras 5 cuentas, quedaron en pausa. No se borran.
- Sus anuncios forman el banco de reserva, para reemplazar los anuncios de la principal cuando se saturen.

**Why:** al abrir 6 cuentas el 25/10 con el mismo píxel y el mismo público, se pisaron entre ellas: Meta contó 47 compras cuando Hotmart tenía 30. El gasto se multiplicó por 9 y las ventas solo por 2 o 3, y pasó a perder unos USD 60–100 por día. Cuando estaba sola (21–24/10) ganaba: unos USD 297 de gasto contra USD 981 netos con backend, un ROAS de alrededor de 3,3. Mat: "vamos a usar solo una campaña… la principal, que es la mejor de todas".

**How to apply:**
- No volver a duplicar el Consultor en otras cuentas para el mismo mercado.
- Para escalar, subir la principal un 30% cada 48 h si gana.
- Las otras cuentas se usan para otros productos o idiomas.
- Medir siempre contra Hotmart.

Relacionado: [[no-tocar-consultor]], [[campanas-prueba-y-escala]].
