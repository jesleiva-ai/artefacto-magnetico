---
name: delegar-tareas-largas
description: "Mat quiere que las tareas largas (Clarity, Hotmart, revisiones con navegador) las hagan \"empleados\" en segundo plano, para seguir charlando conmigo"
metadata:
  type: feedback
  modified: 2026-10-25T20:43:57.800Z
---

Cuando haya que hacer algo largo, como revisar Clarity, cambiar cosas en Hotmart, publicar páginas o recorrer varias pantallas, mandarlo a un empleado: un subagente en segundo plano, o la sesión del producto si ya existe. Yo sigo charlando con Mat mientras tanto y le aviso cuando el empleado termina.

**Why:** Mat, 25/10/2026: "No tenés que hacer esta tarea. La tiene que hacer los otros empleados tuyos. Así yo puedo seguir hablando con vos." Le molesta quedarse esperando mientras yo uso el navegador.

**How to apply:** las consultas rápidas (una o dos llamadas a Meta o Hotmart) las hago yo directo. Lo que lleve varios pasos de navegador o más de un par de minutos va a un empleado, con un encargo completo. Ojo: si Mat solo está preguntando, no mandar a nadie a cambiar nada; confirmar primero si es una orden o una pregunta. Relacionado: [[director-con-empleados]], [[avisar-preguntas-de-sesiones]].
