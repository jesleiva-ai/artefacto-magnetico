---
name: director-con-empleados
description: "Mat quiere trabajar con un director y subagentes como empleados, todo automático y sin pedirle permisos"
metadata:
  type: feedback
  modified: 2026-10-24T22:43:32.975Z
---

Mat quiere que el trabajo grande se haga con un **director** (la sesión principal) que reparte tareas a **subagentes como empleados**, una etapa y un producto cada uno, y que todo corra automático, sin pedirle permiso de nada (24/10/2026).

**Why:** dijo «yo no quiero que me pidas permiso de nada… quiero tener subagentes, un director con sus empleados». Es el modelo de director y etapas de `hyperflujo-auto`.

**How to apply:** en lanzamientos y tareas largas, usar subagentes por etapa sin preguntar si hace falta. No tocar su `~/.claude/settings.json`, que ya tiene casi todo en permitir. Lo único que sigue frenando: gastar sin tope dicho y escribir contraseñas o tarjetas. Ver [[actuar-sin-preguntar]], [[repos-de-rami]].
