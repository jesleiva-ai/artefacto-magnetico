---
name: garantia-7-dias
description: "Regla de Mat: todos los productos (principal, bumps, upsells, downsells) llevan garantía de 7 días, nunca 15"
metadata:
  type: feedback
  modified: 2026-10-21T03:06:21.033Z
---

Todos los productos de Mat en Hotmart llevan **garantía de 7 días**. Nunca 15. Vale para el principal, los order bumps, los upsells y los downsells, y para todo texto que la mencione (web, páginas del embudo, anuncios, PDFs, portal).

**Why:** Mat lo pidió explícitamente el 2026-10-21 ("nunca 15, ¿ok?"), después de que Gessetti y el Método Consultor salieran con 15 días.

**How to apply:** al crear un producto en Hotmart, elegir 7 días en el plazo de reembolso; al escribir copy, decir "garantía de 7 días" / "garanzia 7 giorni". Relacionado: [[hablar-siempre-en-espanol]].
