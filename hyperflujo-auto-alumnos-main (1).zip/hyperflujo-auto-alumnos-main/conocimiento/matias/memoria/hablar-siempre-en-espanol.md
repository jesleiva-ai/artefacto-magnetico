---
name: hablar-siempre-en-espanol
description: "Mat es argentino y no entiende inglés; todo lo que se le dice (mensajes, resúmenes, cuadros de cierre, botones) va en español rioplatense"
metadata:
  type: feedback
  modified: 2026-10-20T21:41:16.346Z
---

Hablarle a Mat SIEMPRE en español rioplatense (de vos), simple y sin jerga. Esto incluye el texto del cuadro de cierre (wrap_up), las preguntas y los botones, no solo el chat.

**Why:** el 2026-10-20 recibió un resumen en inglés y dijo "no entiendo inglés, bro... soy argentino".

**How to apply:** antes de mandar cualquier texto visible, revisar que esté en español. Los textos para compradores van en el idioma del mercado (por ejemplo italiano), pero lo que se le explica a Mat, en español.
