---
name: landing-con-skill-de-mat
description: "Toda página de venta se arma con la skill landing-modelada y las páginas terminadas por Mat como modelo; nada \"a criterio\""
metadata:
  type: feedback
  modified: 2026-10-22T01:47:48.871Z
---

Toda landing nueva se arma con la skill **`landing-modelada`** (`D:\segundo-cerebro\05_PROCESOS\skills\landing-modelada\SKILL.md`), usando el kit `D:\creativos\_referencia-paginas-mat\kit-animaciones.css`. Antes de empezar, se abre la página terminada por Mat más parecida, de `D:\creativos\_referencia-paginas-mat\2026-10-21\`.

**Why:** Mat terminaba rehaciendo a mano cada página que armaban los agentes, gastando plata en tokens. Lo dijo así (2026-10-21): "quiero que modelen las webs… súper estética, animada, bien modelada respetando la línea de una marca, no hecha a lo criollo".

**How to apply:** fijate en lo que más corrige: la primera pantalla con todo lo de la venta, el título con verbo y números, las animaciones (promesa que se mueve, dolores que aparecen de a uno, botones que laten y brillan), los mockups de marca, los carruseles y la barra fija. Las opiniones las pone él. Una página ya publicada no se toca sin su OK: [[no-tocar-webs-de-mat]]. Relacionado: [[modelar-como-metodo-consultor]].
