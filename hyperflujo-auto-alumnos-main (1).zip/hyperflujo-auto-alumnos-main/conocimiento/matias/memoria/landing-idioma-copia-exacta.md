---
name: landing-idioma-copia-exacta
description: "la landing de un producto en otro idioma es una copia exacta de la publicada en español (mismo HTML, mismas imágenes); solo cambia el texto traducido, links y píxel"
metadata:
  type: feedback
  modified: 2026-10-26T17:40:28.992Z
---

Cuando un producto se lanza en otro idioma, la landing se arma copiando tal cual el HTML publicado en español: mismas secciones, el mismo orden, las mismas imágenes, colores y fuentes. Solo cambian el texto (traducido línea por línea), los links del checkout y del portal, el píxel del idioma y las imágenes que tienen texto en español visible (estas van con la misma imagen en la versión del idioma). No se generan fotos nuevas ni se rediseña nada.

**Why:** Mat, 26/10/2026, viendo las 11 landings del Método del Consultor: «no modelaron la página. Las páginas son todas diferentes. Tiene que ser exactamente igual… Porque no va a vender». Los agentes habían rehecho cada landing con imágenes y estructuras propias.

**How to apply:** antes de publicar, comparar la captura en celular de la ES y la del idioma sección por sección. Brief modelo: D:\creativos\matias-proceso-lanzamiento\BRIEF_LANDING_IGUAL_ES.md. Ver [[landing-con-skill-de-mat]] y [[modelar-como-metodo-consultor]].
