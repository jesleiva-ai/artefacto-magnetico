---
name: modelar-como-metodo-consultor
description: "Toda oferta nueva se modela \"tal cual\" con la receta de El Método del Consultor (su oferta que mejor vende), no inventando"
metadata:
  type: feedback
  modified: 2026-10-21T19:07:48.097Z
---

Mat quiere que cada oferta nueva se modele **tal cual** se modeló "El Método del Consultor" (modelo de *Consulting Management EXPLAINED*, de EE. UU. y en inglés, pasado al español), que se vende muy bien. Una vez Claude "hizo lo que quiso" y hubo que rehacerlo todo.

**Why:** lo que se inventa no vende. Lo que vende es copiar la estructura de algo que ya funciona en otro idioma o mercado.

**How to apply:** seguí la receta guardada en `D:\segundo-cerebro\05_PROCESOS\ELEGIR_Y_MODELAR_OFERTAS.md` (sección "Receta Método Consultor") y en el proyecto `D:\segundo-cerebro\06_PROYECTOS\metodo-consultor-ES\PROYECTO.md`. En resumen:
- **Buscar:** frase exacta en la Biblioteca de Meta, con 30 o más anuncios activos, más de 15 días al aire, una tienda-marca y no una persona, y el idioma de destino libre.
- **Landing:** se modela sección por sección sobre la original. Se copian los anuncios ganadores del original.
- **Escalera:** se arma igual que la del Consultor.
- **Meta:** se lanza con la Cash Trap.
- **Lo que nunca se copia:** testimonios con cifras, contadores de compradores y relojes falsos.

**Errores de Planos Listos (2026-10-21), que no se repiten:**
- **Idioma y país (corrección de Mat):** si el original vende en un solo país y en los otros países con el mismo idioma nadie lo vende, se lanza en ese mismo idioma en esos países. Planos Listos en español para Latinoamérica sin Argentina **estaba bien**. Solo si esos países ya están ocupados se pasa a otro idioma.
- La landing se hizo genérica, sin desarmar la original. Primero va `desarme-landing` y después se arma sección por sección.
- Quedó sin mockups, sin imagen hiperrealista y sin videos. **No son opcionales:** van siempre, con créditos de creativos.

Relacionado: [[garantia-7-dias]]
