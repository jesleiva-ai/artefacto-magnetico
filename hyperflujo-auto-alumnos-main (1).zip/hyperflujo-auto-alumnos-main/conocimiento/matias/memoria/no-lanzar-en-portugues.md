---
name: no-lanzar-en-portugues
description: "Mat no quiere lanzar productos en portugués (Brasil): lo considera un mercado peligroso"
metadata:
  type: feedback
  modified: 2026-10-21T19:15:41.284Z
---

Mat, 2026-10-21: "portugués es un mercado peligroso… no lo quiero en portugués". No se modela ni se lanza nada en portugués ni para Brasil. Al elegir el idioma de destino, el portugués no cuenta como opción. Que el original esté en portugués sí está bien: por ejemplo, Bebé Comelón se llevó al inglés.

**Why:** él lo ve como un mercado riesgoso. Todavía no dijo el motivo exacto.

**How to apply:** si el mismo idioma está ocupado en los otros países, buscá otro idioma que no sea portugués (inglés, francés, italiano, alemán). Relacionado: [[modelar-como-metodo-consultor]].
