---
name: no-tocar-consultor
description: "El Método del Consultor es el que vende: no cambiar nada (Hotmart, embudo, página ni campaña) sin orden de Mat"
metadata:
  type: feedback
  modified: 2026-10-24T19:28:38.040Z
---

En el Método del Consultor no se toca nada: ni precios, ni order bumps, ni upsells, ni la página, ni la campaña. Solo se puede mirar.

**Why:** Mat, 24/10/2026: "en el consultor no toques nada". Es el producto que mejor vende (ROAS real ~3,4, 29 ventas y upsells saliendo).

**How to apply:** cuando se ajuste otro embudo (por ejemplo Planos), se puede usar el Consultor solo como comparación, de solo lectura. Cualquier cambio en el Consultor, preguntarlo antes, aunque parezca una mejora. Relacionado: [[no-tocar-webs-de-mat]].
