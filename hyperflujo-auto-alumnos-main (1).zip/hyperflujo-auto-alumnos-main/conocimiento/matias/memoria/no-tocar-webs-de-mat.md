---
name: no-tocar-webs-de-mat
description: "Mat corrige las páginas a mano; ninguna sesión regenera, edita ni republica una web sin su OK"
metadata:
  type: feedback
  modified: 2026-10-22T00:21:38.638Z
---

Mat corrige él mismo las páginas web publicadas. Varias veces una sesión volvió a correr `armar_landing.py`/`armar_portal.py` o a publicar con `agregar-a-laformula.cjs` desde sus archivos viejos y le **pisó sus correcciones**. El 2026-10-21 lo dijo así: "dejen de meter mano en la web porque las cambié ya varias veces y me vuelven a meter mano".

**Why:** los scripts arman la página desde la versión de la sesión, no desde la que corrigió Mat, así que cada vez que se publica se borra su trabajo.

**How to apply:** no regeneres, no edites HTML y no publiques ninguna página ya publicada sin su OK explícito para ese cambio. Si hace falta poner un link de pago o un píxel, anotalo y avisale. Antes de cualquier publicación que él autorice, primero bajá la versión que está en internet y compará, para no pisar sus cambios. Relacionado: [[modelar-como-metodo-consultor]].

También: no correr scripts que regeneren landing, embudo o portal sobre una web publicada (`armar_web.py`, `armar_landing.py`, `armar_portal.py`); el widget de Hotmart, links o píxel se cambian sobre la versión bajada de internet. Pasó el 2026-10-21 con El Mapa del Mástil: se rearmó la web y volvió el nombre viejo. (Une las reglas `no-tocar-web` y `no-tocar-paginas-web`, que decían lo mismo.)
