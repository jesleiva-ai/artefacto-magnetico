---
name: pixel-nuevo-por-idioma
description: cada idioma o país nuevo de un producto lleva su propio píxel de Meta; no se reusa el píxel de otro idioma
metadata:
  type: feedback
  modified: 2026-10-25T21:46:12.218Z
---

Cuando un producto se lanza en otro idioma o país, se crea **un píxel nuevo** para ese lanzamiento: por ejemplo «Berater-Methode DE» para el Método del Consultor en alemán. No se reusa el píxel del idioma original («Metodo Consultor ES»).

**Why:** Mat, 25/10/2026: «para Alemania hay que crear un píxel nuevo. No podemos usar el mismo píxel… Es un píxel nuevo para cada país o para cada idioma».

**How to apply:** crear el píxel en el portafolio dueño de la cuenta publicitaria nueva y cargarlo en tres lugares:
- en los productos de Hotmart de ese idioma;
- en Utmify, para la landing de ese idioma;
- en el conjunto de anuncios, como evento Compra.

Ver [[modelar-como-metodo-consultor]] y [[campanas-prueba-y-escala]].
