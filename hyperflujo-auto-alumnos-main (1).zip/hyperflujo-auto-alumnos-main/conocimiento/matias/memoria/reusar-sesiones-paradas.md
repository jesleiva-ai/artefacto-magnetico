---
name: reusar-sesiones-paradas
description: "antes de abrir sesiones nuevas, darle el trabajo a las sesiones o agentes que están parados; yo dirijo y no hago el trabajo"
metadata:
  type: feedback
  modified: 2026-10-25T22:09:53.143Z
---

Cuando hay trabajo nuevo, primero se reparte entre las sesiones que ya existen y están paradas, con SendMessage a su id. Solo se abre una sesión nueva si no queda ninguna libre que sirva. El director (yo) reparte y controla, no hace el trabajo.

**Why:** Mat, 25/10/2026: «Acordate de mandar a laburar a todos los otros, no hagas las cosas vos… tenés sesiones paradas, no hace falta que abras tantas sesiones nuevas… tenés como 10 agentes».

**How to apply:** antes de abrir una sesión nueva, mirar la lista de sesiones vinculadas y darle la tarea a una que esté parada, con un brief completo. Ver [[director-con-empleados]] y [[delegar-tareas-largas]].
