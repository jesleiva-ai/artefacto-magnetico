---
name: sin-cotizar-ni-preguntar
description: "Mat no quiere cotizaciones ni preguntas — gastar créditos de creativos y armar todo sin pedir OK, avisando después"
metadata:
  type: feedback
  modified: 2026-10-21T16:38:03.188Z
---

Mat (2026-10-21, más tarde que [[actuar-sin-preguntar]]): "no me pidas cotización de nada, sé todo libre… no quiero que me pidas más cotización de nada ni que me preguntes más nada". Amplía esa regla: tampoco se frena por cotizar gastos de herramientas de creativos. (El intento de sumarlo a `INSTRUCCIONES_IA.md` fue bloqueado por el sistema de seguridad; ahí sigue la versión de "actuar sin preguntar".)

**Why:** las preguntas y cotizaciones frenan los lanzamientos; Mat prefiere que se avance y se le informe.

**How to apply:** generar imágenes/videos/voces (Higgsfield, ElevenLabs), cargar en Hotmart y armar/publicar páginas sin pedir cotización ni OK; decidir lo abierto con el criterio de la receta ([[modelar-como-metodo-consultor]]) y avisar después qué se hizo y cuánto se gastó. Sigue sin valer para contraseñas/códigos/tarjetas y mover plata sin tope. Desde el 22/10 las campañas las prende y opera el agente solo ([[campanas-prueba-y-escala]]). La carpeta reel-con-claude conserva su propia regla de tope. Relacionado: [[aceptar-terminos-autorizado]] · [[hablar-siempre-en-espanol]]
