---
name: todos-los-pagos-prendidos
description: "en Hotmart, todos los métodos de pago prendidos en el checkout de cada producto (Google Pay incluido) y en cada embudo de venta"
metadata:
  type: feedback
  modified: 2026-10-23T20:17:57.816Z
---

En la configuración del pago de cada producto principal de Hotmart (Herramientas → Configuraciones de la página de pago → Opciones de pago) van **todos los métodos de pago prendidos**: Google Pay, Apple Pay, PayPal, Pago Híbrido, Cuenta Hotmart, Klarna, Mercado Pago, OXXO, Yape, etc.

**Why:** Mat, 23/10/2026: "quiero que estén todos los métodos de pago disponibles". En Planos, Google Pay estaba apagado y fuera de México llegaban al pago 20 personas y no pagaba ninguna; los productos nuevos traían Google Pay, Pago Híbrido, Cuenta Hotmart y Klarna Pay Now apagados por defecto.

**How to apply:** al lanzar un producto nuevo en Hotmart, prender todos los métodos de pago antes de largar la campaña. Y el campo de cupón va **apagado** en todos ("Mostrar opción de Insertar Cupón"): Mat, 23/10: "qué cupón ni cupón". Se sacó en los 8 productos. **También en los embudos** (Herramientas → Embudo de Ventas → ••• → Editar → Métodos de Pago): Tarjeta, Boleto, PayPal, Pix y Apple Pay prendidos. Los embudos nuevos vienen solo con tarjeta, y así quien paga con PayPal o Mercado Pago nunca ve el upsell. Mat, 25/10/2026: "activa todas las pasarelas de pago… en todos los embudos" (se arreglaron 10 de 19).

Relacionado: [[actuar-sin-preguntar]].
