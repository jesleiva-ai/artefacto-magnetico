---
name: videos-4-segundos-por-imagen
description: En los videos de anuncios cada imagen o toma dura como máximo 4 segundos; un solo subtítulo a la vez y música hasta el final
metadata:
  type: feedback
  modified: 2026-10-22T03:09:36.034Z
---

En los videos de anuncios, **cada imagen o toma dura como máximo 4 segundos** en pantalla. Además, va un solo subtítulo a la vez (nunca un título arriba y un subtítulo abajo que dicen lo mismo) y la música sigue hasta el último cuadro, sin silencio en la tapa final.

**Why:** Mat (2026-10-22) preguntó por qué no se había respetado "la regla de 4 segundos por imagen". No estaba escrita en el cerebro, así que se perdió. Los videos de Planos Listos tenían tomas de unos 10 segundos.

**How to apply:** al armar o revisar cualquier video de anuncio, medí cuánto dura cada escena. Si alguna pasa los 4 segundos, cortala o cambiá la imagen. Está anotado en `D:\segundo-cerebro\05_PROCESOS\MODELADO_PASO_A_PASO.md`, sección 6. Relacionado: [[modelar-como-metodo-consultor]].
