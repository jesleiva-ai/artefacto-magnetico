# Novedades del método de Matías (2026-10-21 al 2026-10-26)

**Fecha:** 2026-10-26 · **Armó:** el editor del repo de alumnos, por pedido de Matías.
**Fuentes leídas:** el segundo cerebro de Matías (`05_PROCESOS/`, `06_PROYECTOS/`, `07_REVISIONES/`), su memoria de Claude Code (copiada en `../memoria/`), el handoff del Método del Consultor (`../13_receta_orquestador_metodo_consultor.md`), los briefs que mandó a los agentes de cada idioma (`../prompts/2026-10-25_*`, `../prompts/2026-10-26_*`), sus skills (`../skills/`) y las sesiones de Claude de su PC (el lanzamiento del Consultor en 11 idiomas y los reportes diarios de Meta). Sin datos de ventas por comprador ni IDs de cuentas.

Cada punto dice **qué**, **cita** y **de dónde sale**. Lo que es deducción del editor va marcado *(a confirmar)*.

## 1. El patrón: un producto que vende se lanza en muchos idiomas

- El Método del Consultor (modelado de una oferta en inglés) fue el que mejor vendió: «ROAS real ~3,4, 29 ventas y upsells saliendo» (memoria `no-tocar-consultor`, 2026-10-24). Cuando estaba solo, del 21 al 24/10, gastó unos USD 297 contra USD 981 netos con backend (memoria `consultor-una-sola-campana`, 2026-10-26).
- El 25/10 Matías pidió llevarlo a otros idiomas: «¿en qué otro idioma lo podemos lanzar?… hay muchos mercados y hay muchos idiomas». Se lanzó en alemán, francés, italiano, neerlandés, polaco, japonés y una segunda tanda (rumano, árabe del Golfo, sueco, checo y hebreo). Fuente: `06_PROYECTOS/ofertas/2026-10-25_mercado_metodo-consultor_mas-idiomas.md` y `../prompts/2026-10-25_brief-idiomas-tanda2.md`.
- **Cómo se elige el idioma** (de esa nota del cerebro):
  1. Si el anuncio original llega al país (anuncios activos del original, país por país, en la Biblioteca de Meta).
  2. Competencia local: 2 o 3 búsquedas con palabras del idioma; se cuenta solo a quien vende algo parecido y barato.
  3. Poder de compra para el precio (USD 20) y riesgos: escritura de derecha a izquierda (árabe, hebreo), formalidad (japonés, coreano), uso de Facebook en el país, medios de pago de Hotmart en el país (se revisan en el checkout antes de lanzar).
  4. Ojo: en vietnamita y tailandés la Biblioteca trae mucho ruido; ese conteo es poco confiable.
- **Nunca portugués ni Brasil** (memoria `no-lanzar-en-portugues`, 2026-10-21).
- **Tres fases por idioma** (brief del 25/10): (1) producto, backend, landing, Hotmart y 9 anuncios traducidos y con sonido nativo; (2) píxel nuevo del idioma; (3) campaña en pausa copiando la estructura de la campaña que vende, USD 75/día.

## 2. La web en otro idioma es un calco de la web que vende

- Matías, 2026-10-26: «es mi propia página, son mis productos, es mi propio testimonio, es todo lo mismo. Tiene que ser tal cual igual el calco… para todos los países donde se venda Método Consultor tiene que ser la misma web traducida. Nada más. No puede cambiar nada». Fuente: `../cerebro/WEB_EN_OTRO_IDIOMA_CALCO.md`, memoria `landing-idioma-copia-exacta`.
- Vale para la landing, las páginas del embudo, la de gracias y el portal, y para cualquier producto, no solo el Consultor.
- Cambian solo: el texto (traducido en el mismo orden), los links del checkout y del portal, el píxel del idioma, las imágenes con texto visible (la misma foto editada, con el mismo encuadre y las mismas personas) y `dir="rtl"` en árabe y hebreo.
- Antes de publicar: captura de celular (390 px) de las dos versiones, comparada sección por sección. Herramienta para el chequeo automático de la estructura: `herramientas/calco_idioma.py`. Las opiniones de la página original van traducidas tal cual, con su aviso y el link a cada captura.
- Por qué: el 25 y el 26/10 los agentes rehicieron cada web con imágenes y estructuras propias; Matías: «no va a vender».
- Esto es distinto del **modelado** de una oferta ajena (que copia estructura, formato y gatillos y pone textos e imágenes propios): el calco es para traducir una web **propia** que ya vende.

## 3. Escala: una sola campaña por producto y mercado

- 24/10: Matías probó escalar el Consultor con «una CBO Oro de USD 100 por día en cada cuenta publicitaria», con 9 anuncios nuevos por cuenta y el píxel compartido (memoria `campanas-prueba-y-escala`).
- 26/10, resultado: «se pisaron entre ellas: Meta contó 47 compras cuando Hotmart tenía 30. El gasto se multiplicó por 9 y las ventas solo por 2 o 3». Matías: «vamos a usar solo una campaña… la principal, que es la mejor de todas». Las copias quedaron en pausa y sus anuncios pasaron a ser el **banco de reserva** (memoria `consultor-una-sola-campana`).
- Regla vigente: para escalar se sube la campaña principal +30 % cada 48 h si gana; las otras cuentas se usan para **otros productos o idiomas**; se mide siempre contra Hotmart.

## 4. Meta Ads: lo que se sumó

| Regla | Cita / fuente |
|---|---|
| Arranque de cada oferta: **USD 75 por día** (antes 50 o 75) | Matías, 2026-10-22 (memoria `campanas-prueba-y-escala`) |
| El agente **prende la campaña solo**; 48 h sin tocar; sin ventas se apaga; con ventas 5 días sin tocar; después +30 % cada 48 h | Matías, 2026-10-22 |
| De 1 a 5 ofertas a la vez | Matías, 2026-10-22 |
| Ubicaciones **por regiones de Meta**, nunca país por país; siempre sin Venezuela ni Nicaragua y sin los países donde ya vende el original | `../cerebro/LECCIONES.md`, 2026-10-22 |
| Idiomas en español: Español, Español (España), Español (todos); **nunca inglés** (revisar en pantalla antes de guardar) | `LECCIONES.md`, 2026-10-21 |
| Botón **«Más información»** (C1, C2) o **«Ver detalles»** (C3), nunca «Comprar», tampoco en el texto | Matías, 2026-10-21 y 22 (memoria `boton-mas-informacion`) |
| **Un píxel nuevo por idioma o país**, cargado en Hotmart, en Utmify y en el conjunto como Compra | Matías, 2026-10-25: «Es un píxel nuevo para cada país o para cada idioma» (memoria `pixel-nuevo-por-idioma`) |
| El píxel se crea en el mismo portafolio que la cuenta publicitaria (si no, el conjunto falla por permisos) | lección del lanzamiento en francés y alemán, 2026-10-25/26 |
| **Reemplazo de anuncios:** se cambian los que tienen **costo por venta mayor al precio** del principal y los que **no gastaron o gastaron sin vender**, siempre por uno del mismo nivel | Matías, 2026-10-25 (registro de cambios de Meta, Planos Listos: «cambia los anuncios… hacelo con flow») |
| Anuncios nuevos = **escenas nuevas** (Google Flow), nunca reusar los mismos clips entre cuentas | Matías, 2026-10-24 (memoria `anuncios-escenas-nuevas-flow`) |
| Cada anuncio nuestro modela uno de los **9 mejores ganadores** del original (ordenados por días al aire y cantidad de copias), también en la imagen; antes de gastar créditos se arma la hoja de los 9 ganadores con el plan | `../cerebro/MODELADO_PASO_A_PASO.md` |
| Videos: tomas de 4 s como máximo, un subtítulo a la vez, hablando desde el segundo 0, música hasta el final | Matías, 2026-10-22 (memoria `videos-4-segundos-por-imagen`) |
| Con tope de costo (cost cap) la campaña casi no gastó y la prueba no fue justa *(observación de un reporte, a confirmar como regla)* | reporte de Meta del 2026-10-25 |

## 5. Hotmart y embudo

- **Escalera (Matías, 2026-10-26, en el chat con el editor):** «Tenés que seguir como tiene el método del consultor. Por lo general son un producto principal, tres order bump, un upsell y cinco downsells. Puede tener más o puede tener menos». Precios del Consultor: principal 19,99 (50 % off de 39,98 hasta una fecha real), bumps 9,99, upsell 34,90, ofertas siguientes 17 y 12 (`../13_receta_orquestador_metodo_consultor.md` §3). 
- Diga que sí o que no, siempre se ofrece el producto siguiente; ningún producto incluido en otro (21/10).
- **Todas las pasarelas prendidas** en el checkout de cada producto (Google Pay, Apple Pay, PayPal, Pago Híbrido, Cuenta Hotmart, Klarna, Mercado Pago, OXXO, Yape…) **y en cada embudo** (los embudos nuevos vienen solo con tarjeta y quien paga con PayPal o Mercado Pago no ve el upsell). Cupón apagado: «qué cupón ni cupón». Matías, 23 y 25/10 (memoria `todos-los-pagos-prendidos`).
- Campo de precio de Hotmart: el número entra como centavos («17» queda 0,17); escribir «1700» o «9.99» (`LECCIONES.md`, 23/10).
- Garantía de 7 días en todo, nunca 15; todo en USD con país principal Estados Unidos (20 y 21/10).

## 6. Forma de trabajo con Claude

- **Director con empleados:** «yo no quiero que me pidas permiso de nada… quiero tener subagentes, un director con sus empleados» (24/10). Las tareas largas (navegador, Hotmart, Clarity) van a un empleado en segundo plano y el director sigue charlando (25/10). Primero se reusan las sesiones paradas (25/10). Si un empleado pregunta algo, avisar al toque con el link (24/10).
- **No preguntar:** decidir con la receta, avisar en una línea y seguir. Frenan solo las contraseñas o códigos, mover plata sin tope y tocar webs ya publicadas (21 y 22/10).
- **Webs publicadas:** no se rearman ni se republican sin el OK de Matías para ese cambio; si hay que tocar, se baja lo publicado y se cambia solo lo pedido (21 y 23/10).
- **Chrome y las cuentas:** un solo perfil de Facebook para todas las sesiones; las tareas con cuentas van de a una (21/10).

## 7. Herramientas que usa hoy (sin claves)

- **Google Flow** (flow.google.com, plan PLUS con imágenes ilimitadas) para las escenas de los anuncios; los pedidos de a uno.
- **Higgsfield** por conector para los videos: Kling 3.0 modo `std`, sin sonido, 9:16, 5 s, unos 6 créditos por clip, tope de 12 clips por idioma («Usa uno bueno. Pero que no sea el más caro», 25/10).
- **ElevenLabs** para la voz nativa (variable `ELEVENLABS_API_KEY` en el `.env`).
- **Utmify** para atribuir ventas: parámetros de URL en cada anuncio y su script en las páginas antes del checkout (`../cerebro/UTMIFY.md`). El token de la API de conversiones lo pega el dueño.
- **Microsoft Clarity** en las landings; ojo: si Netlify ya inyecta un bloque de Clarity, el que viene en el HTML se saca para no duplicarlo (lección del francés, 26/10).

## 8. Resuelto el 2026-10-26 (Matías, en el chat)

- **Días al aire:** «que se estén vendiendo hace más de 10, 15 días»: mínimo 10, mejor 15 o más. **Anuncios activos:** «más de 40 anuncios activos o 30»: mínimo 30, mejor 40.
- **Escalera:** por lo general 1 principal, 3 bumps, 1 upsell y 5 downsells; puede haber más o menos.
- **Opiniones:** van las reales de la web original, traducidas tal cual: «Incluso no les ponían los testimonios, que ahora sí se los ponen».
- **Automático:** «Lo de no pedir confirmación… es una de las reglas más importantes porque esto tiene que trabajar de manera automática».
- **Lo viejo se borra o se quita:** en el repo se reemplazaron las versiones superadas en lugar de dejarlas al lado.
- **Todo se modela como el Método del Consultor:** la receta completa quedó en `recetas/metodo-consultor/RECETA.md`, y los idiomas para escalar en `../IDIOMAS_PARA_ESCALAR.md`.
