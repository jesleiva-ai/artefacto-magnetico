# Prompt C: Modelar los 9 anuncios.

- **Chat de origen:** «Cazar oferta validada y lanzarla en español» (sesión de Claude Code)
- **Fecha:** 2026-10-20 2237 (hora de Buenos Aires)
- **Fuente:** `fuentes/informe_sesion_lanzamiento_consultor.md` §7. Ahí se aclara cuándo es literal de Matías y cuándo es un resumen.

**Modelar los 9 anuncios. Usarlo después de tener 3 a 5 anuncios ganadores del original. Literal de Matías, 21/10 22:37–22:39:
```
[links de la Biblioteca de Meta de los anuncios ganadores]
Acá te pasé lo que tenés que hacer. Y ahora agarrá y hace nueve anuncios. C1, C2 y C3. Tres de cada uno. Y por favor, modelá esos anuncios, ¿ok?
Voy a hacer variaciones con el ángulo del nivel de conciencia de cada uno para venderle, pero no inventes cosas raras, por favor.
Podés hacer alguna variación, algún carrusel si querés […] los videos con música.
Acordate que si hay espacios en vacío donde no habla nadie […] cortale, cosa que el video empiece hablando, le pones alguna transición […] Ponele subtítulo, le puedes poner una musiquita.
ponele buenos copys en la descripcion fijate que usa la competencia
```
