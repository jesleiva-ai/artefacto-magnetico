# Prompt A: Buscar una oferta para modelar en español.

- **Chat de origen:** «Cazar oferta validada y lanzarla en español» (sesión de Claude Code)
- **Fecha:** 2026-10-20 (hora de Buenos Aires)
- **Fuente:** `fuentes/informe_sesion_lanzamiento_consultor.md` §7. Ahí se aclara cuándo es literal de Matías y cuándo es un resumen.

**Buscar una oferta para modelar en español. Usarlo para arrancar un producto nuevo. Es el de la tarea, adaptable:
```
Activá la skill `cazador-de-ofertas` (conector nexus-profit + Biblioteca de anuncios de Meta) y buscá una oferta validada de infoproducto para modelar y vender EN [IDIOMA], en un mercado distinto al que vende hoy.
Requisitos (todos obligatorios): más de 30 anuncios activos; más de 10 días corriendo; que NO sea marca personal; que sea un infoproducto (ebook/guía/curso digital); que hoy NO venda en [IDIOMA] (o con poca competencia): fijate en qué países pauta y confirmá que el mercado está libre.
Cuando la encuentres, avisame en una o dos líneas qué oferta es, dónde vende y por qué cumple, y seguí con el lanzamiento con la receta de D:\segundo-cerebro\05_PROCESOS\MODELADO_PASO_A_PASO.md.
```
