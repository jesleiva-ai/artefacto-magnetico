> Brief de la segunda tanda de idiomas del Método del Consultor (`D:\creativos\matias-proceso-lanzamiento\BRIEF_IDIOMAS_TANDA2.md`, 2026-10-25). Copia saneada.

# Brief: El Método del Consultor, segunda tanda de idiomas (25/10/2026)

Mat lo pidió así: «lo saquemos en árabe… en Rumanía… en noruego, danés o sueco… en checo y… en hebreo. En hebreo me gusta. Porque ahí lo podemos vender en Israel». No le pidas confirmación de nada: decidí con la receta, avisá en una línea y seguí.

## Quién hace cada idioma
| Idioma | Países | Carpeta | Sesión directora |
|---|---|---|---|
| Rumano | Rumania y Moldavia | `D:\creativos\metodo-consultor-ro\` | consultor-carga |
| Árabe | Arabia Saudita, Emiratos, Kuwait, Catar, Baréin y Omán | `D:\creativos\metodo-consultor-ar\` | cazar-oferta-validada (directora) |
| Sueco | Suecia (y Finlandia sueca) | `D:\creativos\metodo-consultor-se\` | consultor-medicion |
| Checo | Chequia | `D:\creativos\metodo-consultor-cz\` | consultor-cargador |
| Hebreo | Israel | `D:\creativos\metodo-consultor-he\` | consultor-escala-cargar |

## Antes de empezar, leé
1. `D:\creativos\matias-proceso-lanzamiento\12_metodo_consultor_handoff_agente.md`, sobre todo la sección 1 bis.
2. Los lanzamientos de hoy, que son tu modelo directo. Tienen el resumen y los pasos de cada uno:
   - `D:\creativos\metodo-consultor-nl\RESUMEN_PARA_MAT.md`: el más prolijo.
   - `D:\creativos\metodo-consultor-it\`, `-fr\`, `-de\`, `-pl\` y `-jp\`.
3. `D:\segundo-cerebro\06_PROYECTOS\ofertas\2026-10-25_mercado_metodo-consultor_mas-idiomas.md`.

## Las 3 fases (orden de Mat)
1. **Producto:** traducido y adaptado al idioma, con sonido nativo. Incluye:
   - la guía, los 4 bonos y todo el backend;
   - la landing (la misma que la del Consultor publicado, https://laformulaebooks.site/metodo-consultor/, traducida sección por sección con `landing-modelada`);
   - los **testimonios reales de Mat traducidos tal cual**;
   - Hotmart completo: 7 productos, checkout con 3 bumps y todos los pagos, upsell, downsells, garantía de 7 días y precios en USD;
   - los 9 anuncios (los mismos tipos que venden), pasados por el revisor.
2. **Píxel:** uno nuevo para el idioma, cargado **directo en Hotmart** y en la landing. **No va en Utmify.** La landing lleva solo el script de UTMs.
3. **Campaña:** se arma en pausa, copiando la estructura de CONSULT 21/10. USD 75 por día. Va en una cuenta libre que se asigna después: [cuenta libre del alumno]. Se prende cuando Mat cargue la tarjeta.

## Reglas para estos idiomas
- **Árabe y hebreo se leen de derecha a izquierda.** La landing, el portal, las placas y los subtítulos van con `dir="rtl"` y con fuentes que muestren bien el alfabeto (Noto Sans Arabic / Noto Sans Hebrew). Hacé una segunda pasada de naturalidad con otro subagente, igual que en japonés.
- **Árabe:** estándar moderno, con tono cercano y profesional. Ejemplos con nombres y ciudades del Golfo. No incluyas Egipto en esta etapa.
- **Hebreo:** ejemplos con nombres y ciudades de Israel.
- **Videos (actualizado):** se hacen con el **conector de Higgsfield** (`mcp__b3618371-d73b-453f-a7bd-20f7b6ee8ed2__generate_video`), sin usar Chrome. Modelo: **Kling 3.0** (`kling3_0`), modo `std`, `sound: off`, 9:16 y 5 s, a partir de la imagen nueva de cada escena. Es bueno y está en el medio de precio, a unos 6 créditos por clip. Tope: **12 clips por idioma**; un clip que salió mal se repite una sola vez. Mat cargó créditos para esto. Lo que pidió: «Usa uno bueno. Pero que no sea el más caro… Fíjate que se optimice mi dinero».
- **Escenas:** las imágenes salen de Flow (flow.google.com, cuenta PLUS, gratis), propias de cada idioma y sin repetir con ninguno de los otros. A la cuenta PRO de Flow le quedan muy pocos créditos de video. Si no alcanzan, las escenas van como **imagen nueva con movimiento de cámara** (el zoom del armado) y se anota en el resumen. No se compran créditos.
- Voz nativa con ElevenLabs, tomas de 4 s como máximo, un subtítulo por vez y música hasta el final.
- **Chrome es uno solo y lo comparten muchas sesiones.** Trabajá siempre en tu propia pestaña. Las tareas con cuentas se hacen de a una y cortas.
- **Si un paso solo lo puede hacer Mat** (su OK escrito en tu sesión para publicar o crear en sus cuentas, conectar el píxel, una clave), avisá a la sesión madre `[ID_SESION]` en una línea y seguí con lo demás.

**Terminado** = las 3 fases, salvo la tarjeta. Avisá a la sesión madre en una línea: «[Idioma] listo para pagar».
