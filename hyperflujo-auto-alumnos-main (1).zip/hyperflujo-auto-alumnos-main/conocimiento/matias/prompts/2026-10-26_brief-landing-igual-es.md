> Brief que Matías mandó a los agentes de cada idioma (`D:\creativos\matias-proceso-lanzamiento\BRIEF_LANDING_IGUAL_ES.md`, 2026-10-26). Copia saneada.

# Brief: la landing de cada idioma tiene que ser IGUAL a la de español (26/10/2026)

Mat, textual: «no modelaron la página. Las páginas son todas diferentes. Tiene que ser exactamente igual. Tiene que ser la misma página. Porque no va a vender».

## Regla de Mat (no se negocia)
«es mi propia página, son mis productos, es mi propio testimonio… Tiene que ser tal cual igual el calco… para todos los países donde se venda Método Consultor tiene que ser la misma web traducida. Nada más. No puede cambiar nada.»
Es un CALCO. No se rediseña, no se «mejora», no se agregan ni se sacan secciones, fotos, testimonios ni frases. Si dudás, copiá lo de español.
Esto vale para TODA la web del idioma, no solo para la landing: la landing, las páginas del embudo (las ofertas del upsell y los downsells), la de gracias y el portal. Cada una es el calco de su par en español (/metodo-consultor/…), traducido.

## Qué hay que hacer
1. Partí del HTML publicado de español: https://laformulaebooks.site/metodo-consultor/
   (bajalo tal cual, con curl). Ese es el molde y no se cambia.
2. Copialo a la carpeta de tu idioma y cambiá SOLO:
   - los textos, traducidos uno por uno en el mismo orden, con la misma cantidad de secciones, títulos, viñetas, preguntas frecuentes y testimonios (los de Mat traducidos tal cual);
   - los links del checkout y del portal de tu idioma;
   - el píxel de tu idioma (sacá el de español) y el script de UTMs;
   - el precio, la moneda y la garantía, que es de 7 días;
   - en árabe y hebreo, además, `dir="rtl"` y la fuente Noto.
3. Imágenes: las MISMAS de español. Ojo: en las fotos con texto (tapa, pantallas, mockups) va la MISMA foto española, con las mismas personas, colores y encuadre, y solo se reemplaza el texto por el del idioma, editando la imagen española como base. No uses fotos con otras personas ni tapas de otro color. Así lo corrigió la sesión madre el 26/10 en NL y JP.
   Además:, en el mismo lugar y del mismo tamaño. Solo cambiá las que tienen texto en español visible (tapa del libro, mockups, placas): usá la versión de tu idioma que ya tenés, mismo encuadre. No agregues ni saques imágenes.
4. Los colores, las fuentes, el orden, los botones, los espacios y el conversor de moneda quedan idénticos.
5. Antes de publicar, sacá una captura de la página entera de ES y de la tuya en celular (390 px) y compará sección por sección. Tienen que verse iguales, cambiando solo el idioma.
6. Publicá sobre la carpeta de tu idioma (Mat lo autorizó en este pedido) y comprobá en vivo que responde 200, que los botones van al checkout correcto y que el píxel dispara.
7. No toques la página de español ni la de otro idioma.

Al terminar, mandá a la sesión madre: «[Idioma]: landing igual a ES, publicada» y la ruta de las 2 capturas.
