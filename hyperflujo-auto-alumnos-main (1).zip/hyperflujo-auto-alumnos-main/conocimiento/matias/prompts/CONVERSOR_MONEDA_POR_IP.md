> Copia saneada del segundo cerebro de Matías (`prompts/CONVERSOR_MONEDA_POR_IP.md`), tomada el 2026-10-26. Fecha de la nota original: 2026-10-20. IDs reemplazados por marcadores.

# Prompt: conversor de moneda por IP para landings (multidivisa)

Fuente: PDF de la persona "CONVERSOR DE MONEDA INTERNO IP" (2026-10-18). Original guardado al lado: `CONVERSOR_MONEDA_POR_IP_original.pdf`.

**Para qué sirve:** que cualquier landing muestre los precios en la moneda local del visitante, detectada por su IP, sin selector visible. Los precios base siempre están en USD (se cobra en dólares con Hotmart).

**Cómo se usa:** pasarle este prompt a la IA (o a un alumno) junto con el HTML completo de la landing.

> **Arreglo 2026-10-21 (nota de Claude):** ipwho.is **ya no devuelve la moneda**, solo el país (`country_code`), y ipapi.co falla desde el navegador. Con el código tal cual, el conversor **nunca convierte** y todo queda en US$. Solución (ya aplicada abajo): sacar la moneda de una tabla país → moneda (`MON`). Probado en Gessetti Profumati: desde Brasil muestra BRL.
>
> **Ojo (nota de Claude):** el precio convertido que se muestra es aproximado (cotización del día y redondeado sin decimales). En el checkout, Hotmart aplica su propia conversión, así que el monto final puede diferir un poco del que se vio en la página.

---

## El prompt (copiar y pegar)

Actuá como desarrollador front-end experto en landings de venta directa. Te voy a pasar el HTML completo de una landing. Tu tarea es agregarle un conversor de moneda automático por IP (multidivisa), sin selector visible, que convierta todos los precios a la moneda local del visitante.

**Cómo tiene que funcionar:**
- Detecta el país/moneda del visitante por su IP (usá https://ipwho.is/ y, si falla, https://ipapi.co/json/ como respaldo).
- Trae la cotización en vivo con https://open.er-api.com/v6/latest/USD.
- Convierte automáticamente todos los precios y los muestra en la moneda local con `Intl.NumberFormat`.
- Si la moneda es USD o falla la detección, deja los precios en dólares sin romper nada.

**Reglas obligatorias:**
- Marcá CADA precio de la página con el atributo `data-usd="VALOR_EN_DOLARES"` (ej: `<span data-usd="14.99">US$14.99</span>`). Los valores base SIEMPRE se guardan en USD.
- El conversor debe recorrer todos los `[data-usd]` y reemplazar su texto por el precio convertido.
- No debe convertir contenedores que tengan hijos: solo los elementos hoja con el precio.
- El conversor NUNCA puede romper el carrito ni el checkout: envolvelo en try/catch y que corra al final.
- No agregues ningún selector de moneda visible: es 100% automático por IP.

Pegá este bloque de JavaScript en la landing y adaptalo a mi HTML:

```html
<script>
(function(){
  var FX=null;
  function money(u){
    if(FX){
      try{ return new Intl.NumberFormat(undefined,{style:'currency',
        currency:FX.cur,maximumFractionDigits:0}).format(u*FX.rate); }catch(e){}
    }
    return 'US$'+u.toFixed(2);
  }
  function applyFx(){
    document.querySelectorAll('[data-usd]').forEach(function(e){
      if(e.children.length) return;               // solo elementos hoja
      var u=parseFloat(e.getAttribute('data-usd'));
      if(!isNaN(u)) e.textContent=money(u);
    });
  }
  applyFx(); // primer render en USD
  (async function(){
    try{
      var c=null;
      // ipwho.is ya no devuelve la moneda (solo el país): la moneda sale de esta tabla
      var MON={AR:'ARS',BO:'BOB',BR:'BRL',CL:'CLP',CO:'COP',CR:'CRC',DO:'DOP',GT:'GTQ',HN:'HNL',MX:'MXN',NI:'NIO',PE:'PEN',PY:'PYG',UY:'UYU',
        AT:'EUR',BE:'EUR',CY:'EUR',DE:'EUR',EE:'EUR',ES:'EUR',FI:'EUR',FR:'EUR',GR:'EUR',HR:'EUR',IE:'EUR',IT:'EUR',LT:'EUR',LU:'EUR',LV:'EUR',MT:'EUR',NL:'EUR',PT:'EUR',SI:'EUR',SK:'EUR',SM:'EUR',VA:'EUR',MC:'EUR',
        CH:'CHF',GB:'GBP',PL:'PLN',CZ:'CZK',HU:'HUF',RO:'RON',SE:'SEK',NO:'NOK',DK:'DKK',CA:'CAD',AU:'AUD',NZ:'NZD',JP:'JPY',IN:'INR',ZA:'ZAR',TR:'TRY'};
      try{ var geo=await fetch('https://ipwho.is/').then(function(r){return r.json();});
        c=(geo&&geo.currency&&geo.currency.code)||(geo&&MON[geo.country_code])||null; }catch(e){}

      if(!c){ try{ var g2=await fetch('https://ipapi.co/json/').then(function(r){return r.json();});
        c=g2&&g2.currency; }catch(e){} }
      if(!c||c==='USD') return;
      var f=await fetch('https://open.er-api.com/v6/latest/USD').then(function(r){return r.json();});
      var r=f&&f.rates&&f.rates[c];
      if(!r) return;
      FX={cur:c,rate:r};
      applyFx();
    }catch(e){ /* si algo falla, queda en USD */ }
  })();
})();
</script>
```

Antes de terminar, revisá que TODOS los precios visibles tengan su `data-usd` (precio principal, precio tachado, ahorro, bonos, order bumps y total del carrito). Devolveme el HTML completo funcionando.

**Tip:** si la landing tiene carrito con order bumps, que el conversor también llame a la función que arma el total (ej. `renderCart()`) después de `applyFx()`, para que el total del carrito se muestre convertido.

---
Volver a [[INICIO]]
