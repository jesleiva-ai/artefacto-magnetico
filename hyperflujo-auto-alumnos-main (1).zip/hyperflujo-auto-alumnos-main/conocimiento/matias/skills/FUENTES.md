# skills/ de Matías — de dónde sale cada una

Copias de **solo lectura** de las skills propias de Matías. Para usarlas en Claude Code se copian a `~/.claude/skills/` (o se suben como `.zip` en Claude → Configuración → Capacidades → Skills). Las rutas `D:\segundo-cerebro\…` son las de Matías: cada alumno le dice a Claude dónde está su cerebro.

- **Las 6 primeras** (`cash-trap-cbo-oro`, `operador-meta-ads`, `cazador-de-ofertas`, `modelar-ofertas`, `embudo-hotmart-netlify`, `guardar-sesion`) vienen del repo `matias-proceso-lanzamiento` (copia del 2026-10-24). Siguen iguales a las que usa Matías al 2026-10-26.
- **Las 28 siguientes** se sumaron el **2026-10-26** desde el paquete para alumnos que armó Matías el 2026-10-24 (`D:\segundo-cerebro\05_PROCESOS\skills\_paquete_alumnos\skills-para-alumnos\carpetas\`), que ya trae tapados el sitio, el checkout y las cuentas («Mat» pasa a «el usuario»). Se compararon con las que tiene instaladas hoy: la única diferencia es ese reemplazo.
- **Sumada el 2026-10-26** (Matías: «añadirle todas las skills»): `meta-ads-mentor-method`, el método del mentor de Meta Ads de Matías (misma fuente que el Manual Maestro de `conocimiento/manual/`).
- **No se incluyó:** `reel-clips`, porque sale de una clase de Ramiro (su material de clases no va en el repo de alumnos). Las `hf-*` no se repiten acá: son las skills del motor, en `skills/`.

| Skill | Para qué (resumen) | Fecha de la versión |
|---|---|---|
| `meta-ads-mentor-method` | Método del mentor de Meta Ads: diagnóstico, estructura, escala y recuperación de campañas… | 2026-10-24 |
| `alertas-campanas` | Chequeo rápido de las cuentas de Meta Ads del usuario para detectar problemas que hacen perder plata o ventas: conjuntos o anuncios que dej… | 2026-10-19 |
| `anuncio-storytime-controversial` | Escribe guiones de anuncios cortos (reels de 17–25 s) con el método propio de Mat: story time con gancho controversial, irónico o exager… | 2026-10-18 |
| `atencion-al-cliente` | Prepara respuestas para los compradores y seguidores del usuario (mails, mensajes, comentarios de anuncios, reclamos de postventa de Hotmart… | 2026-10-19 |
| `capturar-idea` | Guarda al toque una idea, nota, gancho, audio transcripto o link suelto en la bandeja de entrada del segundo cerebro del usuario (D:\\segund… | 2026-10-19 |
| `cash-trap-cbo-oro` | Usar siempre que se arme, analice, escale o diagnostique una campaña de Meta Ads con la estrategia Cash Trap / CBO Oro / método Andrómeda… | 2026-10-21 |
| `cazador-de-anuncios-ropa` | Encuentra en la Biblioteca de Anuncios de Meta los anuncios de ropa y productos físicos que más están funcionando hoy (los que llevan má… | 2026-10-24 |
| `cazador-de-ofertas` | Encuentra y valida las ofertas de productos digitales (ebooks y apps) con más potencial hoy usando el conector nexus-profit de Nexus Profit… | 2026-10-24 |
| `chequeo-politicas-meta` | Revisa anuncios (guiones, placas, carruseles, textos) y páginas de destino de productos digitales antes de subirlos a Meta, buscando lo que… | 2026-10-19 |
| `creativos-placas` | Crea las placas (anuncios de imagen estática) de un producto digital del usuario: elige los formatos por nivel de conciencia (C1/C2/C3) de … | 2026-10-19 |
| `desarme-landing` | Desarma una landing que vende (propia o de la competencia) para entender por qué funciona: estructura sección por sección, colores y tipo… | 2026-10-19 |
| `detector-cloaker` | Revisa si la landing de una oferta de la competencia usa cloaker: si le muestra una página 'segura' a quien la revisa (Meta, espías) y otr… | 2026-10-19 |
| `ebook-canva` | Genera ebooks infoproducto profesionales en formato Word (.docx) con TODO el copy y diseño editorial ya escrito, pero SIN generar imágenes… | 2026-10-24 |
| `ebook-editorial-docx` | Genera ebooks/infoproductos completos escribiendo TODO el copy editorial en un .docx con diseño profesional (docx-js) e insertando fotos fo… | 2026-10-24 |
| `ebook-higgsfield` | Genera ebooks infoproducto profesionales de nivel editorial usando Higgsfield (Nano Banana Pro 2K) para crear cada página como imagen de al… | 2026-10-24 |
| `embudo-hotmart-netlify` | Arma el embudo completo de un producto digital en Hotmart con las páginas en Netlify: order bumps en el checkout, upsell y downsells de un … | 2026-10-21 |
| `escalera-de-valor` | Arma o revisa la escalera de valor de un producto digital low-ticket del usuario: producto principal, order bumps, upsells y downsell, con p… | 2026-10-19 |
| `espia-de-ofertas` | Busca en la Biblioteca de anuncios de Meta ofertas de productos digitales low-ticket que ya están vendiendo en otro mercado/idioma y que cu… | 2026-10-19 |
| `guardar-sesion` | Cierra una sesión de trabajo guardando en el segundo cerebro de Mat (D:\\segundo-cerebro) lo que se decidió, lo que quedó pendiente y lo … | 2026-10-19 |
| `importar-de-otras-ias` | Trae al segundo cerebro del usuario (D:\\segundo-cerebro) lo que otras IAs ya saben de él y de su negocio (la app de Claude, ChatGPT, Gemin… | 2026-10-19 |
| `investigar-mercado` | Evalúa si un nicho o producto digital low-ticket tiene potencial en un mercado/idioma antes de lanzarlo o modelarlo: demanda, competencia e… | 2026-10-19 |
| `jardin` | Ordena el segundo cerebro del usuario (D:\\segundo-cerebro) sin borrar nada: procesa lo acumulado en 00_ENTRADA, detecta notas repetidas, co… | 2026-10-19 |
| `landing-modelada` | Arma la página de venta de un producto digital del usuario modelándola sobre la original y con el formato que el usuario deja en sus pági… | 2026-10-22 |
| `lanzar-en-hotmart` | Arma en Hotmart la escalera de valor completa de un producto digital del usuario: producto principal, checkout personalizado, order bumps, u… | 2026-10-19 |
| `modelar-ofertas` | Usar esta skill cada vez que el alumno (o Mat) quiera clonar, modelar o adaptar una oferta que ya funciona — una landing page, un quiz/fun… | 2026-10-24 |
| `oferta-completa` | Arma la oferta completa de un producto digital low-ticket del usuario: nombre, promesa principal, mecanismo (por qué funciona), qué incluy… | 2026-10-19 |
| `operador-meta-ads` | Opera las cuentas de Meta Ads de Mat con su método Cash Trap / Andrómeda: lee campañas y anuncios, diagnostica con sus reglas (48 h, ROAS… | 2026-10-19 |
| `quien-cobra` | Averigua con qué plataforma cobra y entrega una oferta de la competencia (Hotmart, Kiwify, Eduzz, Monetizze, Perfect Pay, Shopify, Stripe, … | 2026-10-19 |
| `respaldar-cerebro` | Hace una copia de respaldo comprimida del segundo cerebro del usuario (D:\\segundo-cerebro) en D:\\respaldos-segundo-cerebro, con fecha y ho… | 2026-10-19 |
| `revisar-landing` | Revisa una landing o página de venta de producto digital low-ticket antes de lanzarla (o una que no convierte) con el checklist del usuario… | 2026-10-19 |
| `revision-semanal` | Hace la revisión semanal del negocio del usuario con su segundo cerebro (D:\\segundo-cerebro): qué avanzó, decisiones, pendientes, númer… | 2026-10-19 |
| `tablero-ventas` | Arma el tablero de ventas y ganancia del negocio del usuario cruzando el gasto de Meta Ads (leído de sus cuentas) con las ventas reales de … | 2026-10-19 |
| `transcribir-y-minar` | Convierte material crudo (transcripciones de clases, audios, videos, PDFs, artículos, capturas, notas largas) en notas útiles del segundo … | 2026-10-19 |
| `ugc-video-hiperrealista` | Usar cuando el alumno (o el usuario) quiera crear un video publicitario UGC hiperrealista con una creadora o creador generado por IA demostr… | 2026-10-24 |
| `voz-del-cliente` | Junta y ordena las palabras reales de los clientes de un nicho (comentarios de anuncios, mensajes, preguntas de compradores, reseñas de pro… | 2026-10-19 |
