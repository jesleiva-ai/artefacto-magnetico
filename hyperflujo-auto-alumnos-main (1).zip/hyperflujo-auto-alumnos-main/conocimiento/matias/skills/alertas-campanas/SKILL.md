---
name: "alertas-campanas"
description: "Chequeo rápido de las cuentas de Meta Ads del usuario para detectar problemas que hacen perder plata o ventas: conjuntos o anuncios que dejaron de entregar, anuncios rechazados, campañas activas con el conjunto pausado, gasto sin ventas por encima del break-even, presupuesto que no se gasta, frecuencia muy alta y caídas bruscas. Solo lectura; avisa y propone, no cambia nada. Usar cuando se pida 'chequeá si algo anda mal', 'alertas', '¿se cortó algo?', '¿están entregando?', o como tarea programada cuando la persona lo active."
model: sonnet
effort: low
---

# Alertas de campañas

Solo lectura. Para actuar: `operador-meta-ads`, que aplica los cambios solo y avisa (Mat, 2026-10-26: automático, sin pedir confirmación).

## Qué buscar (en todas las cuentas con campañas activas)

| Alerta | Cómo se detecta | Gravedad |
|---|---|---|
| **No entrega** | Campaña activa con gasto 0 o casi 0 en las últimas 24 h; conjunto con estado "con problemas" | 🔴 |
| **Anuncio rechazado** | Estado rechazado / en revisión hace mucho | 🔴 |
| **Conjunto pausado dentro de campaña activa** | Campaña activa, anuncios con estado "conjunto pausado" | 🟠 (avisar: puede ser a propósito) |
| **Pago o cuenta** | Cuenta sin medio de pago, cuenta restringida, entrega pausada por facturación | 🔴 |
| **Gasto sin ventas** | Anuncio o campaña que gastó ≥ break-even (precio del producto principal) sin compras, fuera de las primeras 48 h | 🟠 |
| **Presupuesto que no se gasta** | Gasta menos del 50% del presupuesto diario | 🟠 |
| **Frecuencia alta** | Frecuencia > 3 en anuncios C1/C2 (en C3 es normal 2–3) | 🟡 |
| **Caída brusca** | Costo por compra 2× el de los 7 días anteriores, o CTR −30% | 🟡 |

## Entrega

Lista corta por gravedad: cuenta · campaña · alerta · dato · qué propone el método. Si no hay nada: "Todo entregando normal" en una línea.

Guardar solo las alertas 🔴 y 🟠 en `D:\segundo-cerebro\07_REVISIONES\alertas.md` con fecha.

## Programación

Hoy se usa **a mano** (decisión de la persona, 2026-10-19). Cuando la persona lo pida, se puede programar (por ejemplo, cada mañana) para que avise solo si hay 🔴 o 🟠.
