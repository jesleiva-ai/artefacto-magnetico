---
name: "anuncio-storytime-controversial"
description: "Escribe guiones de anuncios cortos (reels de 17–25 s) con el método propio de Mat: story time con gancho controversial, irónico o exagerado ADAPTADO AL NICHO, y pivote directo a la venta. Usar cuando se pida un guion, un gancho, un hook, ideas de anuncios o un reel para vender un curso o producto digital (oficios, belleza, dieta, etc.), o cuando se pida 'un gancho polémico', 'story time', 'algo que no sea el típico gancho-problema-solución'."
---

# Anuncio story time con gancho controversial

Método propio de Mat para anuncios de venta directa. **No** es el clásico "gancho → problema → solución → llamado a la acción". Abre con una situación **cotidiana del nicho**, exagerada hasta lo gracioso, irónico o polémico, contada por alguien que se ríe de sí mismo; en una sola frase pivotea a la venta y cierra.

El objetivo del gancho no es ofender: es que la persona **frene el scroll y vea el anuncio entero**.

## 1. Los 8 principios (lo que hace que funcione)

1. **El gancho sale del nicho, nunca es polémica al azar.** Cada nicho tiene sus historias, chistes, estereotipos y desastres típicos. Se toma uno y se lleva al extremo.
2. **Verosímil.** Son cosas que pasan de verdad o que la gente reconoce ("a mí me pasó", "conozco a uno así"). Se exagera el tamaño, no se inventa algo imposible.
3. **La ironía conecta el gancho con lo que se vende.** El chiste es el oficio visto con humor: perdió la casa → aprendió a construir casas; el "pequeño error" de soldadura → incendio, justo lo que el curso enseña a evitar.
4. **El que queda mal parado es el narrador (o la situación), nunca el que mira** ni un grupo de personas.
5. **La imagen ilustra la frase al pie de la letra, pero más grande.** Dice "pequeño error" → se ve una casa en llamas. El contraste entre lo que se dice y lo que se ve es parte del chiste.
6. **Pivote de una sola frase** a la venta. Sin explicar el problema.
7. **La promesa es simple y siempre la misma para el nicho:** aprender el oficio/habilidad → salida laboral, trabajar desde casa o negocio propio (o el resultado verificable que tenga el producto).
8. **Remate visual** opcional al final, mientras se dice el llamado a la acción (el ladrón que sale corriendo, el mismo clip del principio).

## 2. Estructura del guion (17–25 s, 55–80 palabras)

| Parte | Tiempo | Qué pasa |
|---|---|---|
| 1. Gancho controversial | 0–4 s | Situación del nicho exagerada. Primera persona ("yo...", "mi suegra...") o directo ("si tenés miedo que..."). |
| 2. Pivote | 1 frase | "Por eso..." / "Pero sí puedo..." / "Y grabé un curso..." / "Hoy, además de haberlo logrado..." |
| 3. Promesa | 1–2 frases | Qué aprende y para qué le sirve (salida laboral / negocio propio). Opcional: 2–3 cosas concretas que aprende, o bonos. |
| 4. Cierre | 1 frase | "Hacé clic en el botón y te lo envío." (o la variante que use el producto) |

**Visual fijo del formato:** título arriba con producto y precio desde los segundos 2–6 y durante casi todo el video ("Curso de [oficio] — $[precio]"); subtítulos grandes palabra por palabra en el centro; clips del oficio en acción; sin la cara del vendedor (voz en off "de alguien del oficio").

## 3. Tipos de gancho

1. **Miedo íntimo que el producto resuelve.** "Si tenés miedo que tu mujer te engañe, o te preocupa la seguridad de tu hogar..." (cámaras de seguridad)
2. **Confesión de error con consecuencia gigante.** "Yo también era de los que soldaban y siempre cometía algún pequeño error" + casa en llamas. (herrería)
3. **Meme con giro.** "Las mentiras a mi mujer, la cerveza a la noche y ser mecánico son cosas que no puedo cambiar, pero sí puedo cambiar tu futuro." (mecánica)
4. **Chiste del oficio con lenguaje de la calle.** "No le pido el cosito que va en el coso que es más grande que el tubito: me lo sé de memoria." (plomería)
5. **Caída y reinvención irónica.** "Después de que mi mujer me dejó, perdí la casa y el perro. Tuve que reinventarme..." → aprendió a construir casas. (steel framing)
6. **Ironía del día a día del oficio.** "Mis clientas me cuentan del ex, de la suegra y del jefe. Soy manicura, pero debería cobrar como psicóloga."

## 4. Cómo trabajar un pedido

1. **Datos mínimos** (si faltan, preguntar una sola vez, proponiendo una respuesta):
   - Producto y qué incluye de verdad (si hay ficha en el segundo cerebro, usarla: `03_PRODUCTOS/PRODUCTOS.md`).
   - Precio y moneda.
   - Público (quién compra, país, voseo o tú).
   - Promesa real (salida laboral, trabajar desde casa, etc.).
2. **Lista de situaciones del nicho:** escribir 8–10 situaciones cotidianas, desastres típicos, estereotipos o chistes internos de ese mundo. Pensar como alguien que trabaja de eso hace 10 años: ¿qué le pasa siempre?, ¿de qué se ríen entre colegas?, ¿qué error comete todo principiante?, ¿qué le dicen los clientes?, ¿qué piensa la familia de su trabajo?
3. **5 ganchos de tipos distintos** (sección 3), cada uno con:
   - la frase del gancho,
   - la imagen exagerada que lo acompaña,
   - el pivote,
   - en una línea, por qué funciona.
4. **Recomendar uno** y escribir el guion completo con la estructura de la sección 2.
5. **Plan visual por frase:** qué clip va debajo de cada frase (literal y exagerado), texto del título fijo, remate final.
6. **Pasar el checklist de la sección 6** antes de entregar.

## 5. Formato de entrega

```
GANCHO ELEGIDO: [tipo] — [por qué]

GUION ([n] palabras, ~[n] s)
[frase 1]  →  CLIP: [qué se ve]
[frase 2]  →  CLIP: [qué se ve]
...

TÍTULO FIJO: "[texto]" (desde el segundo [n])
SUBTÍTULOS: grandes, palabra por palabra, centro de pantalla
REMATE VISUAL: [clip final]

OTROS 4 GANCHOS PARA PROBAR:
1. [gancho] — imagen: [..]
...
```

Si se piden varios anuncios para una campaña Cash Trap (skill `cash-trap-cbo-oro`), indicar el nivel de conciencia de cada uno: este formato abre como C1 (emoción) y cierra como C3 (precio). Para los C2 hacen falta anuncios que enseñen algo (tutorial, demostración, carrusel).

Para producir el video con clips reales, voz y subtítulos, usar la skill del reel (`reel-clips`) con este guion.

## 6. Límites: polémico sí, ofensivo no (checklist)

- [ ] El chiste es sobre el narrador o la situación, **no contra el que mira** ni contra un grupo (origen, género, religión, cuerpo, orientación, etc.).
- [ ] **No sugiere atributos personales del que mira** (salud, cuerpo, peso, finanzas, etc.): "¿Te da vergüenza tu cuerpo?" está prohibido por Meta. En dieta o salud, el que fracasa es el narrador ("Empecé la dieta 47 veces...").
- [ ] **Sin imágenes sexuales, desnudos ni ropa interior**: Meta las rechaza aunque el chiste funcione. La idea se puede sugerir sin mostrarlo.
- [ ] La exageración se nota que es exageración; **lo que se dice del producto es real** (qué incluye, precio, promesa). Nada de testimonios inventados, cupos falsos ni resultados garantizados.
- [ ] Sin logos de canales de TV, marcas ajenas ni textos de otros anuncios en los clips.
- [ ] La promesa es aprender el oficio con salida laboral o negocio propio, no "vas a ganar X".

## 7. Ejemplos aprobados por Mat (2026-10-18)

**Dieta (curso de viandas saludables)**
- Gancho: "Empecé la dieta 47 veces. Todas un lunes. Todas terminaron el lunes a la noche, abrazado a media pizza fría."
- Imagen: un calendario con todos los lunes tachados; la heladera abierta a medianoche.
- Pivote: "Lo que me faltaba no era voluntad, era saber cocinar rico y sano. Por eso grabé un curso de viandas..."

**Electricista**
- Gancho: "Mi suegra todavía cree que el apagón de la Navidad pasada fue culpa de la compañía de luz. Fui yo, con una zapatilla y mucha confianza."
- Imagen: mesa navideña a oscuras, un chispazo, la suegra iluminada por una vela.
- Pivote: "Hoy vivo de arreglar lo que antes rompía, y grabé un curso para que aprendas el oficio y trabajes de esto."

**Maquilladora**
- Gancho: "Me maquillé sola para el casamiento de mi prima. En todas las fotos con flash parezco un fantasma con cachetes de payaso."
- Imagen: la foto grupal con flash; todos normales, ella con la cara blanca.
- Pivote: "Ese día aprendí que la base con protector solar y el flash no se llevan. Hoy maquillo novias, y grabé un curso para que aprendas y cobres por hacerlo."

**Manicura**
- Gancho: "Mis clientas me cuentan del ex, de la suegra y del jefe. Soy manicura, pero debería cobrar como psicóloga."
- Imagen: una clienta llorando mientras le pintan las uñas; la manicura asiente seria.
- Pivote: "Lo bueno es que este oficio te deja trabajar desde tu casa. Grabé un curso para que armes tu propio gabinete."

**Barbería**
- Gancho: "Le dije a mi cuñado 'tranquilo, un degradado lo hace cualquiera'. Fue a su propio casamiento con gorra."
- Imagen: la foto de la boda; el novio de traje y gorra, el cuñado mirando a cámara.
- Pivote: "Por eso aprendí en serio, y grabé un curso de barbería para que vivas de esto."

### Guiones reales completos (anuncios que corrió Mat)

- **Plomería:** "Soy plomero y me sé los nombres de las griferías. Cuando voy a la ferretería no le pido el cosito que va en el coso que es más grande que el tubito: me lo sé de memoria. Y grabé un curso online de plomería para que aprendas un oficio y puedas tener tu trabajo o tu propio negocio. Si hacés clic en el botón te lo envío."
- **Mecánica:** "Las mentiras a mi mujer, la cerveza a la noche y ser mecánico de autos son cosas que no puedo cambiar, pero sí puedo cambiar tu futuro, porque grabé un curso online para enseñarte a que puedas ser mecánico de autos y que tengas salida laboral, o que puedas tener tu propio negocio, por un único pago de 6.500 pesos. Te lo envío ahora mismo haciendo clic en el botón."
- **Steel framing:** "Bueno, después de que mi mujer me dejó, perdí la casa y el perro. Tuve que reinventarme y comencé a estudiar construcc[...] (falta un pedazo en la transcripción), que es el sistema más usado en América Latina para hacer casas, y se llama steel framing. Hoy, además de haberlo logrado, preparé un curso para poder enseñarte, y además te voy a dar como bonos de regalo el de electricista domiciliaria y el de epoxy para paredes y pisos. Pinchá en el botón que te lo envío."
- **Herrería:** "Yo también era de los que soldaban y siempre cometía algún pequeño error. Por eso, 10 años después, te grabé un curso profesional de herrería, para que tengas tu propio emprendimiento o salida laboral como herrero profesional. Aprenderás técnicas y soldaduras, qué herramientas y materiales son adecuados, y además te voy a enseñar cómo armar planos. Hacé clic en el botón y te lo envío."
- **Cámaras de seguridad:** "Si tenés miedo que tu mujer te engañe, o te preocupa la seguridad de tu hogar, solucionalo con mi curso online de cámaras de seguridad de cero a experto. Te enseño todo para que puedas instalarlas en tu hogar, o en algún local, o montes tu propio emprendimiento o tengas salida laboral. Es grabado online y está listo para que puedas empezar. Hacé clic en el botón y te lo envío." *(Al producirlo: no usar imagen sexual para el gancho de infidelidad.)*

## 8. Lo que NO hacer

- Gancho genérico que serviría para cualquier nicho ("¿Querés ganar plata desde tu casa?").
- Polémica sin relación con el oficio (un escándalo cualquiera para llamar la atención).
- Explicar el problema durante 10 segundos antes de vender: el pivote es una frase.
- Burlarse del que mira: "¿Seguís siendo un fracasado?", "¿Te da vergüenza ir a la playa con ese cuerpo?".
