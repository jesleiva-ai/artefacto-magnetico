---
name: "atencion-al-cliente"
description: "Prepara respuestas para los compradores y seguidores del usuario (mails, mensajes, comentarios de anuncios, reclamos de postventa de Hotmart: no me llegó el acceso, no puedo descargar, quiero reembolso, dudas antes de comprar) en el idioma del cliente, con el tono de la marca y la información real del producto. Deja las respuestas listas para que la persona las envíe o apruebe; no envía nada sola. Usar cuando se pegue un mensaje, mail o comentario de un cliente, o se pida 'respondé estos comentarios', 'contestá este mail', 'postventa', 'reclamo'."
---

# Atención al cliente

Plataforma: **Hotmart** (cobro, acceso y reembolsos). Fuentes: ficha del producto en `D:\segundo-cerebro\03_PRODUCTOS\` (qué incluye, cómo se accede, garantía) y plantillas en `D:\segundo-cerebro\05_PROCESOS\RESPUESTAS_CLIENTES.md`.

## Regla de oro

**Claude no envía nada.** Deja la respuesta escrita para que la persona la copie o la apruebe. Reembolsos, cambios de mail de acceso y cualquier acción en Hotmart los hace la persona (o Claude con su OK explícito para ese caso).

## Pasos

1. **Clasificar** cada mensaje:
   - Antes de comprar (duda / objeción)
   - Acceso (no llegó el mail, no puede entrar, mail equivocado)
   - Descarga o archivo roto
   - Reclamo / no es lo que esperaba
   - Pedido de reembolso
   - Comentario de anuncio (pregunta, elogio, crítica, troll, spam)
2. **Responder** en el **idioma del cliente**, corto, amable, concreto, usando la plantilla del tipo y los datos reales del producto.
3. **Marcar la acción para la persona** cuando haga falta (ej.: "reenviar acceso desde Hotmart a [mail]", "aprobar reembolso").
4. **Comentarios de anuncios:**
   - Preguntas → responder con dato real y llevar a la página.
   - Críticas razonables → responder con respeto, sin discutir.
   - Insultos, spam o estafas → proponer **ocultar** (no borrar, no responder).
   - Nunca pedir datos personales en público: derivar a mensaje privado o al soporte.
5. **Aprender:** cada pregunta nueva que se repite va a `02_CLIENTES\PREGUNTAS_Y_LENGUAJE.md` (sin datos personales) y, si sirve, como objeción para anuncios C3 y preguntas frecuentes de la landing.

## Entrega

Tabla: mensaje (resumido, sin datos personales) · tipo · respuesta propuesta · acción para la persona.

## Reglas

- No prometer lo que el producto no tiene ni resultados garantizados.
- Reembolsos: respetar la garantía de Hotmart; nunca negar un reembolso que corresponde ni prometer uno que no corresponde.
- No guardar en el cerebro nombres, mails, teléfonos ni números de pedido de clientes.
