---
name: "capturar-idea"
description: "Guarda al toque una idea, nota, gancho, audio transcripto o link suelto en la bandeja de entrada del segundo cerebro del usuario (D:\\segundo-cerebro\\00_ENTRADA), sin procesarlo todavía. Usar cuando se diga 'guardá esta idea', 'anotá esto', 'capturá', 'se me ocurrió...', o se pegue algo suelto para no perderlo."
model: sonnet
effort: low
---

# Capturar idea

Rápido y sin vueltas: la idea se guarda tal cual, con fecha, y se procesa después.

## Pasos

1. Crear `D:\segundo-cerebro\00_ENTRADA\AAAA-MM-DD_HHMM_[tema-en-3-palabras].md` con:

```
# [Tema en pocas palabras]

- Fecha: AAAA-MM-DD HH:MM
- Tipo: idea de producto / gancho / anuncio / oferta para modelar / tarea / aprendizaje / link / otro
- Relacionado con: [producto o proyecto, si se nombró]
- Estado: sin procesar

## Texto original
[lo que dijo la persona, sin corregir ni resumir]

## Nota de Claude (opcional, 1–2 líneas)
[a qué archivo del cerebro podría ir cuando se procese]
```

2. Responder en una línea: "Guardado en 00_ENTRADA: [nombre]".

## Reglas

- No editar ni "mejorar" el texto original.
- No mover nada a otras carpetas: eso se hace al procesar (prompt `prompts/PROCESAR_ENTRADA.md`) o en la revisión semanal.
- Si es un link, guardar el link y, si se puede leer, un resumen de 2 líneas marcado como resumen de Claude.
- Nada de contraseñas, claves ni datos personales de terceros.
