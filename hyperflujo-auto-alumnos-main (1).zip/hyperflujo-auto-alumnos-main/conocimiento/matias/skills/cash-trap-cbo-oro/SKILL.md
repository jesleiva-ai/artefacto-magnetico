---
name: "cash-trap-cbo-oro"
description: "Usar siempre que se arme, analice, escale o diagnostique una campaña de Meta Ads con la estrategia Cash Trap / CBO Oro / método Andrómeda (1 campaña CBO, 1 conjunto, 9 anuncios: 3 por cada nivel de conciencia C1, C2 y C3)."
---

# Cash Trap / CBO Oro — Manual de campaña para Meta Ads

Esta skill aplica la estrategia **Cash Trap** (también conocida en la jerga como **"CBO Oro"**) para armar, analizar o escalar una campaña de Meta Ads. Es una sola campaña desde el día uno, que reemplaza por completo el combo clásico de "campaña de testeo (ABO) → campaña de escala (CBO)": sin fase de testeo separada y sin pasar anuncios ganadores entre campañas.

Cuando se analice o arme una campaña real, seguir el protocolo de la sección 10 y separar: Estado actual → Diagnóstico → Qué dice el método → Qué haría ahora → Qué NO tocar todavía → Cuándo volver a mirar.

## 1. Por qué existe

Meta (a través de su IA de optimización, Andrómeda) premia la concentración de presupuesto y el aprendizaje acumulado de una sola campaña, y castiga mover anuncios ganadores entre campañas (reinicia el aprendizaje y suele "romper" la campaña al escalarla). Cash Trap evita ese problema de raíz: todo el aprendizaje queda guardado en una única campaña que nunca se reemplaza, solo se alimenta.

## 2. Estructura obligatoria

Siempre: **1 campaña → 1 conjunto de anuncios → 9 anuncios (3 C1 + 3 C2 + 3 C3).** Nunca varios conjuntos, nunca un conjunto por anuncio.

- **Objetivo de campaña:** Ventas (o Interacción si se vende por WhatsApp).
- **Presupuesto:** a nivel campaña (CBO). Excepción: si en una cuenta publicitaria puntual la CBO nunca funciona, se puede armar con el presupuesto en el conjunto (ABO) y probar. La estructura es la misma: 1 campaña, 1 conjunto, 9 anuncios.
- **Un solo conjunto de anuncios.**
- **9 anuncios** dentro de ese conjunto: **3 para cada nivel de conciencia** (C1, C2, C3 — ver sección 4). Nombrarlos con su nivel (C1, C1, C1, C2, C2, C2, C3, C3, C3) para saber siempre qué nivel es cada uno.
- **Segmentación para productos en español (cómo la arma Mat, 2026-10-21):** regiones **América del Norte, América Central, América del Sur, Caribe** + **España**, excluyendo **Argentina, Nicaragua y Venezuela**; idiomas Español, Español (España) y Español (todos); Advantage+ en público y ubicaciones.
- **Segmentación:** audiencia abierta, sin intereses, edades ni "sugerencias" de Meta. **País + idioma, siempre (sí o sí):**
  - Elegir los países donde se vende.
  - Marcar el idioma del anuncio. Si se vende en español, marcar **las tres variantes: Español, Español (España) y Español (todos)**.
  - Por qué: si se apunta a varios países y uno de ellos es, por ejemplo, Estados Unidos, sin el idioma el anuncio también le llega a gente que habla inglés y se pierde presupuesto.
- **Ubicaciones:** **ubicaciones Advantage+** (las automáticas que recomienda Meta). **No sacar ninguna ubicación** (ni WhatsApp, ni Stories, ni otras): quitar ubicaciones baja la puntuación de la campaña.
- **Puntuación de recomendación de Meta (Andrómeda):** tiene que quedar en el **100% o lo más cerca posible (90% o más)**. Campaña de ventas con Advantage+ activado y seguir las sugerencias que Meta va mostrando al armarla: quien elige el público es Meta, no nosotros. Lo único que controlamos son los anuncios.
- **Píxel:** el de siempre, en la página de ventas.

## 3. Reglas de presupuesto (regla dura, no opcional)

**Regla vigente de Mat (2026-10-22): la campaña arranca con USD 75 por día** y la prende el agente solo, a la medianoche, sin preguntar. La regla de abajo (precio × cantidad de anuncios) queda solo como referencia de la versión anterior; manda el arranque de USD 75.

Referencia anterior — la regla de oro: **el presupuesto por anuncio tiene que acercarse al precio del producto.** El dinero es "la comida" de los anuncios — si un anuncio no puede gastar al menos lo que vale el producto, Meta no le da suficiente alcance como para generar una venta.

Fórmula: **precio del producto × cantidad de anuncios = presupuesto diario mínimo de campaña.**

Con los 9 anuncios de la estructura, el mínimo es **precio del producto × 9**. Ejemplos:
- Producto a $5 × 9 anuncios = $45/día mínimo.
- Producto a $10 × 9 anuncios = $90/día mínimo.
- Producto de WhatsApp a $2 × 9 anuncios = $18/día; nunca bajar de ese piso.
- Si más adelante se suman anuncios por encima de 9, el mínimo sube con la misma cuenta (más anuncios = más "bocas" que alimentar).

Esta regla aplica para cualquier idioma, país o canal (página web, WhatsApp, quiz, VSL). **Esta campaña no se puede arrancar con $5–15 por día** — directamente no funciona.

## 4. Diversidad creativa por niveles de conciencia ("el equipo de fútbol")

Como ya no se puede segmentar por intereses, la única herramienta para que Meta (Andrómeda) encuentre clientes distintos son los anuncios mismos: Andrómeda "escanea" cada anuncio (título, imagen, colores, ángulo) y con eso decide a quién mostrarlo. La variedad creativa es su comida. Un conjunto con un solo anuncio es mandar a la guerra a un solo jugador; un conjunto con 9 anuncios distintos, repartidos por nivel de conciencia, es mandar un equipo completo.

### Los 3 niveles de conciencia

Nivel bajo no significa que el cliente sea tonto: significa que todavía no se dio cuenta del problema.

**C1 — No sabe que tiene el problema.** Se le habla desde la **emoción**, nunca con tecnicismos. Formatos:
1. **Blooper:** mostrar algo que se hace mal, para que se sienta identificado.
2. **Antes y después:** situación inicial contra resultado, con una promesa real, sin exagerar.
3. **Problema cotidiano:** una frustración básica del día a día y cómo se ve resuelta.

**C2 — Sabe que tiene el problema, pero no sabe cómo resolverlo.** Se le **enseña algo** para subirle la conciencia. Formatos:
1. **Tutorial o contenido útil:** un paso a paso.
2. **Demostración:** video corto de cómo funciona el producto, o testimonio real de alguien que certifica que funciona.
3. **Carrusel educativo:** el paso a paso en imágenes.

**C3 — Sabe cómo resolverlo y está eligiendo con quién.** Se va al **cierre**. Formatos:
1. **Oferta directa:** precio, descuento, bonos de regalo.
2. **Rompe objeciones:** placa con las objeciones comunes tachadas y su respuesta ("No tengo tiempo" → lo hacés a tu ritmo; "No tengo el dinero" → cuotas con tarjeta).
3. **El producto por dentro:** mostrar qué hay adentro.

Ejemplo (panchería nueva): C1 come panchos y no conoce el local; C2 quiere comer un pancho y no sabe a dónde ir; C3 conoce el local pero sigue yendo al de siempre por miedo a lo nuevo.

### Reglas de la variedad

- **3 anuncios por nivel, y los 3 de un mismo nivel distintos entre sí** (otro ángulo, otro formato). Ayuda variar también el formato visual dentro de cada nivel: reel vertical, horizontal, cuadrado, placa, carrusel.
- **Nunca repetir el mismo anuncio:** si se parecen, Meta no lo interpreta como variedad, los manda al mismo público y termina mostrando solo uno.
- **El conjunto vende en equipo:** las compras suelen venir de los C3 y los C2, pero los C1 son los defensores del equipo. Sacarlos rompe el embudo y los que venden dejan de vender.
- **No hace falta campaña de remarketing:** los C3 los ven sobre todo quienes ya vieron los C1 y los C2. Es normal que los C3 tengan la frecuencia más alta (2 o 3).
- Lo que más vende es la creatividad: anuncios que corten el scroll. Las ideas más disruptivas suelen ser las que mejor funcionan; se les busca el nivel de conciencia y entran al equipo.

## 5. Requisitos de la cuenta publicitaria

- **Una sola campaña por cuenta publicitaria.** Ni dos campañas, ni campaña de remarketing aparte: con más de una, la cuenta compite contra sí misma (un día tracciona una y al otro día la otra). El remarketing lo hace Andrómeda sola dentro de la misma campaña.
- Que a alguien le funcione duplicar campañas (pasa en nichos muy grandes, como salud) no significa que esté bien hecho: "lo peor es que te salga bien lo que estás haciendo mal".
- Los anuncios de esta campaña **no pueden reutilizarse en ninguna otra campaña ni cuenta** (nunca el mismo Post ID en dos lugares).
- No hay capital mínimo de cuenta, pero sí capital para sostener el presupuesto diario.
- **Si ya hay campañas vendiendo en una cuenta, no se apagan** (sería un error apagar algo que vende). La Cash Trap nueva se larga en **otra cuenta publicitaria** (se puede compartir el mismo píxel), con anuncios distintos.

## 6. Timing: los primeros días (donde más se falla)

Meta necesita un periodo de **aprendizaje** para entender quién es el público, y cualquier cambio (presupuesto, pixel, pausar/agregar un anuncio) **resetea ese aprendizaje**. La ansiedad de tocar la campaña es lo que más la rompe.

**Regla central:** largar la campaña a la medianoche y no tocarla durante las primeras **48 horas completas** (el día 2 tiene que terminar entero). Recién al mediodía del día 3 se mira si vendió algo en esas 48 horas.

- **Si vendió algo en 48 horas** (no hace falta estar en ganancia, con que haya vendido alcanza): se deja correr sin tocar nada los 5 días restantes de la semana.
- **Si no vendió nada en 48 horas:** ahí sí se puede pausar o repensar el producto.
- El **día 3 suele ser el peor día** de la campaña — no pasa nada, parece que se va a morir. Es normal, no es señal de apagarla.
- El **día 5 suele empezar a arrancar** en serio.
- A partir del **día 5–7** recién se toman decisiones de optimización (subir presupuesto o cambiar anuncios, nunca ambas cosas el mismo día).
- La campaña se analiza **por semana, no por día** — igual que un negocio no se juzga por un solo día flojo si su pico está en otro día de la semana.
- Nunca mirarla obsesivamente todos los días — eso genera ansiedad y lleva a tocarla de más, que es lo que la rompe.

## 7. Cómo escalar presupuesto

- Se analiza y decide **a nivel campaña** (ROAS de la campaña entera), nunca anuncio por anuncio para decidir subir presupuesto.
- **Arranque: USD 50 por día** (regla de Mat, 2026-10-19).
- A las **48 horas**, mirando el ROAS de la campaña: **sin ventas → se apaga**; **vende pero con ROAS menor a 2** (break-even, 1,5) **→ no se escala, se deja correr** hasta 5 días; **ROAS 2 o más → se sube 30%**.
- Después, cualquier día que la campaña esté en ROAS 2 o más se puede subir 30% (48 h entre aumentos).
- Después de subir, se esperan **48 horas** antes de volver a tocar algo (subir de nuevo, bajar, cambiar anuncios).
- Si el ROAS se mantiene en 2+, se vuelve a subir 30% (cada 48 h). Si no, no se toca hasta que vuelva a ROAS 2+.
- **Nunca dos cambios el mismo día.** O se sube presupuesto, o se cambian anuncios — nunca ambas cosas juntas. Después de cualquiera de las dos, esperar **3 días** antes de la próxima decisión.
- Cuando la campaña ya acumuló bastante presupuesto (ej. pasó de $50 a $120/día) y viene funcionando bien, en vez de solo subir presupuesto se agregan anuncios nuevos **de a uno por nivel de conciencia** (pasa de 9 a 12: un C1, un C2 y un C3 más), para no desbalancear el embudo. Cada vez que se agregan anuncios nuevos, se repite la espera de aprendizaje (~5 días) antes de la próxima decisión.
- Sobre el CPA: es normal que suba por encima del precio del producto principal al escalar — se sostiene con un **backend/upsell fuerte** (ej. ticket promedio de $30–50 contra un CPA de $15). Un backend sólido también protege si clonan la oferta: se gana la puja por CPA aunque el que clonó tenga más volumen.

## 8. Cómo reemplazar anuncios que no funcionan

**Regla clave:** si la campaña entera está en ganancia (ROAS 2+), **no se toca ningún anuncio individual**, aunque uno tenga un costo por compra carísimo. Ese anuncio caro puede estar actuando como "arquero" que atrae al público difícil para que los otros 8 vendan barato — apagarlo rompe el equipo entero.

**Cuándo sí intervenir:** solo cuando el ROAS de la campaña empieza a bajar (de 2 a 1.5, a 1.3, cerca del punto de equilibrio). En ese caso:

1. Identificar el/los anuncio(s) que gastaron igual o más que el precio del producto sin generar venta.
2. Ver de qué **nivel de conciencia** es (C1, C2 o C3) y apagarlo.
3. Reemplazarlo **siempre por un anuncio del mismo nivel de conciencia**, para respetar el embudo: si se apagó un C2, entra un C2; si se apagó un C3, entra un C3. El reemplazo puede ser:
   - una variación nueva de ese nivel (otro ángulo u otro formato), o
   - algo que ya funcionó antes, siempre que sea de ese mismo nivel.
4. La campaña **nunca puede quedar con menos anuncios** que los que tenía, ni desbalanceada: siempre 3 C1, 3 C2 y 3 C3. Si se apagó 1, se suma 1 del mismo nivel.
5. Esperar **3 días** antes de la próxima decisión (la campaña tambalea mientras reacomoda el aprendizaje con el anuncio nuevo).

## 9. Por qué NO usar "surfing" de presupuesto

"Surfear" es subir el presupuesto progresivamente a lo largo del mismo día (ej. arrancar con $300 y terminar la noche con $10.000, duplicando cada vez que vende). Es una técnica muy usada, pero trae problemas serios en esta estrategia:

- Convierte en **esclavo del negocio**: hay que estar todo el día pegado a la pantalla mirando métricas.
- Genera **ansiedad constante**.
- Factura mucho pero **se gana poco en proporción** (ej. facturar $3.000 para ganar $300–500 — mucha facturación, poca ganancia real).
- Rompe el aprendizaje constantemente, así que **se satura y se cae al día siguiente** (vende bien 1–2 días y después se desploma).
- Obliga a sacar decenas de creativos nuevos todo el tiempo para sostenerlo.

La alternativa: dejar que la campaña trabaje sola y en automático (subidas de 30% cada 48–72h, sin tocarla a diario), y usar el tiempo/energía libre en **sacar más productos/ofertas** en paralelo en vez de sobre-optimizar una sola campaña. Es mejor tener varios productos vendiendo solos todos los días que un solo producto surfeado a mano.

## 10. Protocolo de análisis (formato de respuesta para diagnósticos reales)

Cuando se analice una campaña Cash Trap real, estructurar la respuesta así:

1. **Estado actual**: días de vida, presupuesto, cantidad de anuncios por nivel de conciencia (C1/C2/C3) y sus formatos, ventas, CPA, ROAS.
2. **Diagnóstico**: ¿está dentro de su ventana mínima de aprendizaje (48h recién largada / 48–72h tras el último cambio)? ¿el ROAS de campaña viene subiendo, estable o cayendo?
3. **Qué dice el método**: citar la regla concreta aplicable (sección correspondiente de este manual).
4. **Qué hacer ahora**: UNA sola intervención prioritaria — nunca tocar presupuesto y anuncios el mismo día.
5. **Qué NO tocar todavía**: proteger la ventana de aprendizaje vigente.
6. **Cuándo volver a mirar**: 48h / 3 días / 5–7 días, según la regla aplicable.

## 11. Checklist de arranque

- [ ] 1 campaña, objetivo Ventas (o Interacción si es WhatsApp), CBO a nivel campaña (ABO solo si la CBO nunca anda en esa cuenta)
- [ ] 1 solo conjunto de anuncios, audiencia abierta, sin intereses; país + idioma sí o sí (en español: Español, Español (España) y Español (todos))
- [ ] Ubicaciones Advantage+, sin sacar ninguna; puntuación de recomendación de Meta al 100% o lo más cerca (90%+)
- [ ] 9 anuncios: 3 C1 (emoción: blooper, antes/después, problema cotidiano), 3 C2 (enseñar: tutorial, demostración, carrusel), 3 C3 (cierre: oferta, objeciones, producto por dentro)
- [ ] Los 3 de cada nivel distintos entre sí; nombrados con su nivel
- [ ] Presupuesto de arranque: USD 75 por día (Mat, 2026-10-22)
- [ ] Es la única campaña de la cuenta publicitaria (sin remarketing aparte); anuncios nunca reutilizados en otra campaña. Si la cuenta ya tiene campañas vendiendo, no se apagan: usar otra cuenta
- [ ] Largarla a medianoche y no tocarla por 48 horas completas
- [ ] Si vendió algo en 48h → dejarla correr 5 días más sin tocar nada
- [ ] Analizarla por semana, no por día (día 3 suele ser el peor, es normal)
- [ ] Arrancar con USD 50/día; pasadas 48 h, con ROAS 2+, subir 30% cada 48 h
- [ ] Nunca dos cambios el mismo día (o presupuesto o anuncios, nunca ambos); esperar 3 días entre decisiones
- [ ] No tocar anuncios individuales mientras la campaña esté en ganancia, aunque uno sea caro
- [ ] Si el ROAS de campaña cae, apagar el anuncio flojo y reemplazarlo por otro del mismo nivel de conciencia — siempre 3 C1, 3 C2, 3 C3
- [ ] Al escalar fuerte, sumar anuncios de a uno por nivel (9 → 12) en vez de solo subir presupuesto
- [ ] Nada de "surfear" el presupuesto en el mismo día
- [ ] Backend/upsell fuerte para sostener un CPA más alto que el precio del producto principal

## Glosario rápido

**ABO** = presupuesto a nivel conjunto. **CBO** = presupuesto a nivel campaña (Meta reparte entre conjuntos/anuncios). **Cash Trap / CBO Oro** = 1 campaña CBO, 1 conjunto, 9 anuncios (3 por nivel de conciencia), presupuesto = precio del producto × cantidad de anuncios, cero intervención en las primeras 48h, análisis por semana. **ROAS** = retorno sobre inversión publicitaria (ingresos / gasto en ads). **CPA** = costo por adquisición (costo por compra). **Backend** = productos/ofertas que se venden después de la compra principal (order bumps, upsells, downsells) para sostener un ticket promedio más alto. **C1 / C2 / C3** = niveles de conciencia del cliente: no sabe que tiene el problema / lo sabe pero no sabe cómo resolverlo / sabe cómo y está eligiendo con quién.
