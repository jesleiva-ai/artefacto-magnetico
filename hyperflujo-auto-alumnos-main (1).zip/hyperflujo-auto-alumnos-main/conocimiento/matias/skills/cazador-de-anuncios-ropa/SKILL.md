---
name: cazador-de-anuncios-ropa
description: Encuentra en la Biblioteca de Anuncios de Meta los anuncios de ropa y productos físicos que más están funcionando hoy (los que llevan más días al aire y más copias), analiza a la competencia del local en su país o ciudad y entrega los ganadores para modelar, con su formato, gancho, oferta y un plan de 9 anuncios. Úsala cuando el usuario pida "qué anuncios de ropa funcionan", "espiá a la competencia", "anuncios ganadores para mi local", "qué hace la competencia en Instagram/Facebook", "ideas de anuncios para mi tienda", "cazar anuncios" o quiera modelar anuncios para vender ropa, calzado o accesorios, aunque no nombre la skill.
---

# Cazador de anuncios (ropa y productos físicos)

Tu trabajo: encontrar los anuncios que **ya le están funcionando a otras tiendas** para que el usuario los modele en su local o tienda online. No inventás ideas: buscás evidencia.

Un anuncio que una tienda mantiene prendido muchos días, y del que hace varias copias, **le está dando plata**. Nadie sostiene semanas un anuncio que pierde.

**Idioma:** escribí siempre en el idioma del usuario, de principio a fin, aunque Meta o las tiendas estén en otro idioma. Los términos de búsqueda sí van en el idioma del país donde buscás.

**Archivos de esta skill:**
- `scripts/meta_scan.min.js`: el analizador de la Biblioteca de Meta. **Es el que pegás en el navegador.**
- `scripts/meta_scan.js`: el mismo, legible. No hace falta leerlo.

Necesitás un navegador que puedas manejar (por ejemplo, Claude en Chrome). Si no hay, entregá los links de búsqueda y explicá qué tiene que mirar el usuario.

---

## 1. Antes de empezar: preguntar con opciones (un solo mensaje)

Preguntá solo lo que falte. Proponé opciones para que conteste corto, por ejemplo «2, mujer, Córdoba»:

1. **¿Qué vende?** Ropa de mujer · hombre · niños · talles grandes · urbana/streetwear · deportiva · lencería · calzado · accesorios · otro.
2. **¿Dónde vende?** País y ciudad. ¿Solo en el local, con envíos o tienda online?
3. **¿Qué buscamos?** A) Los anuncios ganadores del rubro en el país (para modelar). B) Su competencia directa (tiendas parecidas en su zona). C) Las dos.
4. **¿Tiene tiendas que ya conoce y quiere espiar?** Nombres o links de Instagram/Facebook (opcional).
5. **Ticket promedio** de lo que vende (opcional; sirve para comparar ofertas).

Si el pedido ya trae todo, no preguntes y arrancá.

---

## 2. Términos de búsqueda

Armá de 3 a 5 términos de 2 o 3 palabras, **como los buscaría una compradora del país**. Por ejemplo, para ropa de mujer en Argentina: «ropa de mujer», «conjuntos mujer», «jeans mujer», «talles reales», «outfit otoño».

- **Por ciudad:** la Biblioteca de Meta filtra por país, no por ciudad. Para la competencia local, sumá términos con el nombre de la ciudad o del barrio («ropa mujer córdoba», «tienda ropa nueva córdoba») y mirá dónde dice cada tienda que está, en su perfil o en el texto del anuncio («envíos a todo el país», «local en…»).
- **Por temporada:** si se acerca una fecha (Día de la Madre, Black Friday, Hot Sale, fiestas, vuelta al cole, cambio de temporada), sumá un término con la fecha: «día de la madre ropa», «hot sale ropa».
- **Términos distintos entre sí:** cada término encuentra tiendas que el otro no ve.

---

## 3. Escanear la Biblioteca de Meta con el analizador

URL de búsqueda: `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=XX&q=TÉRMINO&search_type=keyword_unordered&media_type=all`. `XX` es el código del país: AR, MX, CO, CL, PE, UY, ES, US…

Perfil de una tienda: abrí la tienda en la Biblioteca y usá el link con `view_all_page_id=`.

1. Abrí la búsqueda, con **solo activos** y el país, y esperá a que carguen los primeros anuncios.
2. **Cargá el analizador** con tu herramienta para correr JavaScript en esa pestaña:
   - **Primera página:** leé `scripts/meta_scan.min.js` y ejecutá su contenido completo, tal cual. Define `window.nexusScan` y deja una copia guardada en el navegador.
   - **Páginas siguientes** (cada página nueva borra el analizador): ejecutá este cargador, que recupera la copia guardada:
     ```js
     await new Promise(ok => { const s = localStorage.getItem('__nexusScanSrc'); if (!s) return ok('sin-copia'); const el = document.createElement('script'); el.onload = () => ok(window.nexusScan ? 'listo ' + window.nexusScan.version : 'fallo'); el.onerror = () => ok('fallo'); el.src = URL.createObjectURL(new Blob([s], { type: 'text/javascript' })); document.head.appendChild(el); })
     ```
     Si devuelve `sin-copia` o `fallo`, pegá el archivo completo otra vez.
   - No uses `eval` ni `new Function`: Meta los bloquea. No escribas tu propia versión del analizador.
3. Ejecutá `await nexusScan.step(15000)` varias veces hasta que devuelva `done: true`. De cada vuelta mirá solo `done`, `cards` y `cobertura_porcentaje`.
   - **No saques capturas** mientras escaneás: gastan mucho y el analizador ya lee los anuncios.
   - **No hagas clic** en «Ver más» ni en los botones de las tarjetas: abren la tienda y sacan la pestaña de Meta.
   - **Si la cobertura queda por debajo del 80%:** bajá la página con el scroll real del navegador (unas 10 ruedas), esperá 2 segundos y ejecutá `nexusScan.collect()`. Repetí hasta llegar a 80% o hasta que `sin_cambios_seguidas` llegue a 3.
   - **Si Claude queda detrás de otra ventana,** Meta deja de cargar: pedile al usuario que la deje visible.
4. Ejecutá `nexusScan.result()`. Te da los anuncios activos, las copias, los nuevos de los últimos 7 días, los destinos (a qué página manda cada anuncio) y los anunciantes (quién vende y cuánto). Ya saca los inactivos y los de «pocas impresiones».
5. **Escaneo parcial** (`llego_al_final: false`): los números son un mínimo. Decilo con la cobertura, por ejemplo «se leyó ~40% de los ~300».
6. **Nunca** inicies sesión en Facebook ni uses la cuenta del usuario: el escaneo es anónimo. Si Meta pide login o captcha, frená y avisá.
7. **Al terminar,** cerrá las pestañas que abriste. No toques las que el usuario ya tenía.

Para las 3 a 5 tiendas más fuertes, **escaneá también su perfil**: así sabés si están escalando (muchos anuncios nuevos esta semana) o probando.

---

## 4. Qué cuenta como anuncio ganador (reglas para productos físicos)

| Regla | Valor | Por qué |
|---|---|---|
| **Tienda que invierte** | 10 o más anuncios activos reales en su perfil (sin contar «pocas impresiones») | Muestra que la tienda pone plata en serio en Meta. |
| **Días al aire** | 14 o más | Si sigue prendido después de dos semanas, vende. Con 30 días o más, es un ganador fuerte. |
| **Copias** | 2 o más del mismo anuncio | Duplicar un anuncio es señal de que lo están escalando. |
| **Pocas impresiones** | Se excluyen | Casi no se muestran: no prueban nada. |
| **Tamaño parecido** | Preferí tiendas chicas o medianas, como el usuario | Las marcas grandes (Zara, Nike, Shein…) venden por su nombre: su anuncio no se puede copiar en un local. Nombralas aparte como «referencia de estilo», no como ganadores. |
| **Mismo rubro** | Ropa del mismo público que el usuario | Un anuncio de zapatillas de running no sirve para una tienda de vestidos de fiesta. |

Si el usuario da otros valores («7 días», «solo mi ciudad»), usá los suyos.

**Ojo con las fechas:** en temporada alta (Día de la Madre, Black Friday, Navidad) muchos anuncios son de pocos días. Ahí mirá más las copias y los anuncios nuevos de los últimos 7 días que los días al aire.

---

## 5. Analizar cada ganador

De cada anuncio ganador (máximo 10) anotá:

- **Tienda**, con el link a su perfil en la Biblioteca y al anuncio.
- **Días al aire y copias.**
- **Formato:** video vertical (reel), video cuadrado, foto sola, carrusel de prendas, catálogo, colección.
- **Qué se ve:** modelo real o maniquí, probador o «prueba de ropa» (try-on), «armado de outfit», antes y después, unboxing del paquete, la dueña hablando a cámara, recorrida por el local, detalle de la tela, perchero con precios, foto de producto sobre fondo blanco.
- **Gancho** de los primeros 3 segundos o primera línea del texto (textual, entre comillas).
- **Oferta:** % de descuento, 2x1 o 3x2, envío gratis desde $X, cuotas sin interés, descuento por transferencia o efectivo, regalo con la compra, «últimos talles», «nueva colección», precio en el anuncio o no.
- **Llamada a la acción** y destino: WhatsApp, Instagram, tienda online o mensaje.
- **Por qué funciona**, en una línea.

Después buscá **los patrones**: qué formato se repite más entre los ganadores, qué oferta usan casi todos y a qué destino mandan (en ropa local suele ganar el WhatsApp).

---

## 6. La competencia del local (si pidió la opción B o C)

1. Con los términos por ciudad, listá las tiendas que anuncian en su zona o que envían a su zona.
2. Para cada una: cuántos anuncios activos tiene, desde cuándo, qué ofrece y a qué precio (si lo muestra), si manda a WhatsApp o a la tienda, y si está escalando (anuncios nuevos esta semana).
3. **Qué hueco deja la competencia:** algo que nadie hace (nadie muestra talles reales, nadie hace video en el local, nadie ofrece cuotas, nadie envía en el día) y que el usuario puede ocupar.

---

## 7. Lo que entregás

1. **Resumen en 3 líneas:** cuántas búsquedas y perfiles escaneaste, cuántos ganadores encontraste y la conclusión principal.
2. **Tabla de los ganadores** (hasta 10), de mayor a menor fuerza, con las columnas del paso 5 y los links.
3. **Patrones que se repiten:** formato, oferta, gancho y destino.
4. **La competencia del local** (si la pidió), con el hueco que deja.
5. **Plan de 9 anuncios para modelar**, cada uno copiando la estructura de un ganador. Son 3 por nivel:
   - **3 para quien no conoce la tienda:** gancho fuerte y prueba de ropa, outfit o detrás de escena.
   - **3 para quien está comparando:** cómo calza, talles, tela, envío y cuotas.
   - **3 para quien está por comprar:** oferta, últimas unidades, regalo o descuento por transferencia, con el botón a WhatsApp o a la tienda.

   Para cada anuncio: qué ganador modela, formato, qué se filma o fotografía en el local, gancho y texto sugerido.
6. **Links** de todas las búsquedas y perfiles usados, para que el usuario los revise.

---

## Reglas que no se rompen

- **Modelar no es copiar:** se copia la estructura, el formato, el tipo de escena y la oferta. **Nunca** las fotos, videos, marcas ni textos literales de otra tienda. Las fotos y videos los hace el usuario con sus prendas.
- **Nada inventado:** cada dato sale de la Biblioteca de Meta y tiene su link. Si algo no se pudo ver, decí «sin dato».
- **No prometas resultados.** Un ganador de otra tienda es una pista fuerte, no una garantía.
- **Sin datos personales** de clientas ni de dueñas de otras tiendas en el informe.
- **No cargues ni prendas anuncios** desde esta skill: solo investiga y propone.
