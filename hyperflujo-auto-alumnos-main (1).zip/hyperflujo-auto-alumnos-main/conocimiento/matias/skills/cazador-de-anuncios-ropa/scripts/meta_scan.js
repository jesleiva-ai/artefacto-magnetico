/*
 * Analizador de la Biblioteca de Anuncios de Meta (perfil de anunciante o búsqueda).
 *
 * Uso desde el navegador de Claude (ejecutar JavaScript en la pestaña de Meta):
 *   1. Primera página: pegar este archivo completo.     -> define window.nexusScan y guarda una copia en la pestaña
 *      Páginas siguientes: el cargador corto de la skill  -> recupera esa copia sin volver a pegar el archivo
 *   2. await nexusScan.step(15000)  (repetir)           -> baja y carga anuncios; devuelve {done, cards}
 *      Si Meta se frena (cobertura baja): bajar con el scroll REAL del navegador y luego nexusScan.collect() (repetir)
 *   3. nexusScan.result()                               -> resumen JSON para el informe y para guardar_escaneo_meta
 *   Si step() devuelve cards: 0 después de cargar la página, usar nexusScan.debug() y contar a mano.
 */
(function nexusInstall() {
  const VERSION = '2026.10.20b';

  const MONTHS = {
    ene: 0, jan: 0, janv: 0, enero: 0, janeiro: 0, january: 0,
    feb: 1, fev: 1, febrero: 1, fevereiro: 1, february: 1,
    mar: 2, marzo: 2, marco: 2, março: 2, march: 2,
    abr: 3, apr: 3, abril: 3, april: 3,
    may: 4, mai: 4, mayo: 4, maio: 4,
    jun: 5, junio: 5, junho: 5, june: 5,
    jul: 6, julio: 6, julho: 6, july: 6,
    ago: 7, aug: 7, agosto: 7, august: 7,
    sep: 8, sept: 8, set: 8, septiembre: 8, setiembre: 8, setembro: 8, september: 8,
    oct: 9, out: 9, octubre: 9, outubro: 9, october: 9,
    nov: 10, noviembre: 10, novembro: 10, november: 10,
    dic: 11, dez: 11, dec: 11, diciembre: 11, dezembro: 11, december: 11,
  };

  const ID_RE = /(?:identificador de la biblioteca|identificador da biblioteca|id da biblioteca|library id|id de anuncio|ad id)\D{0,10}(\d{10,20})/i;
  const ID_DIGITS_RE = /^\s*(\d{12,20})\s*$/;
  const COPIES_RE = /(\d{1,5})\s*(?:anuncios?\s+usan|ads?\s+use|an[uú]ncios?\s+usam)/i;
  /**
   * La etiqueta "pocas impresiones" de Meta en cada idioma de la Biblioteca (la página sale en el idioma del navegador de
   * quien la abre). En inglés es "Low impression count": antes no se reconocía y daba 0 aunque las hubiera.
   */
  const LOW_IMPRESSIONS_RE = new RegExp([
    'n[uú]mero de impresiones bajo', 'pocas impresiones', 'impresiones bajas',
    'low impression count', 'low number of impressions', 'low impressions',
    'n[uú]mero de impress[õo]es baixo', 'baixo n[uú]mero de impress[õo]es', 'poucas impress[õo]es',
    'nombre d.impressions faible', 'faible nombre d.impressions', 'impressions faibles',
    'numero di impressioni basso', 'numero basso di impressioni', 'poche impressioni',
    'geringe anzahl (?:an |von )?impressionen', 'wenige impressionen', 'niedrige anzahl (?:an |von )?impressionen',
    'laag aantal (?:vertoningen|weergaven|impressies)', 'weinig (?:vertoningen|weergaven|impressies)',
    'niska liczba wy[sś]wietle[nń]', 'ma[lł]a liczba wy[sś]wietle[nń]',
    'd[uü][sş][uü]k g[oö]sterim', 'az g[oö]sterim',
    'num[aă]r (?:redus|sc[aă]zut) de afi[sș][aă]ri',
  ].join('|'), 'i');
  /** Idiomas en los que se conoce con seguridad el texto de la etiqueta: en los demás, 0 encontradas no prueba que no haya. */
  const LOW_IMPRESSIONS_SURE_LANGS = ['es', 'pt', 'en', 'fr', 'it'];
  const INACTIVE_RE = /\binactiv[oa]\b|\binativ[oa]\b|\binactive\b|\binactif\b|\binattiv[oa]\b|\binaktiv\b|\binactief\b|\bnieaktywn[ya]\b|\bpasif\b/i;
  const TOTAL_RE = /~?\s*([\d.,]{1,9})\s*(?:resultados|results|resultados encontrados|r[ée]sultats|risultati|ergebnisse|resultaten|wynik[oó]w|sonu[cç])/i;
  const LOGIN_WALL_RE = /inicia sesi[oó]n para (continuar|ver)|log in to (continue|see)|fa[cç]a login para continuar|entre para continuar/i;
  const SKIP_TAGS = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1 };
  const MARK = 'data-nx-card';

  function norm(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  /** "Circulando desde el 7 oct 2026", "Started running on Oct 7, 2026", "Veiculação iniciada em 7 de out de 2026". */
  function parseStartDate(text) {
    const t = norm(text);
    const anchor = t.search(/circulacion desde|circulando desde|en circulacion desde|started running on|veiculacao iniciada em|veiculando desde|comenzo a circular/);
    const slice = anchor >= 0 ? t.slice(anchor, anchor + 80) : t;
    let m = slice.match(/(\d{1,2})\s*(?:de\s+)?([a-z]{3,10})\.?\s*(?:de\s+)?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]] !== undefined) return new Date(Number(m[3]), MONTHS[m[2]], Number(m[1]));
    m = slice.match(/([a-z]{3,10})\.?\s+(\d{1,2}),?\s*(\d{4})/);
    if (m && MONTHS[m[1]] !== undefined) return new Date(Number(m[3]), MONTHS[m[1]], Number(m[2]));
    return null;
  }

  function parseCopies(text) {
    const m = String(text || '').match(COPIES_RE);
    return m ? Math.max(1, parseInt(m[1], 10)) : 1;
  }

  const SHARED_HOST_RE = /^(?:.+\.)?(hotmart\.com|hotmart\.club|kiwify\.com\.br|kiwify\.app|eduzz\.com|sun\.eduzz\.com|monetizze\.com\.br|braip\.com|kirvano\.com|ticto\.com\.br|ticto\.app|greenn\.com\.br|perfectpay\.com\.br|lastlink\.com|pepper\.com\.br|herospark\.com|yampi\.com\.br|adoorei\.com|vega\.checkout|cakto\.com\.br|impultienda\.com|clickbank\.net|hop\.clickbank\.net|digistore24\.com|jvzoo\.com|warriorplus\.com|buygoods\.com|maxweb\.com|clickfunnels\.com|myclickfunnels\.com|systeme\.io|kajabi\.com|mykajabi\.com|teachable\.com|thinkific\.com|podia\.com|gumroad\.com|stan\.store|beacons\.ai|linktree\.com|linktr\.ee|payhip\.com|lemonsqueezy\.com|whop\.com|skool\.com|patreon\.com|ko-fi\.com|buymeacoffee\.com|thrivecart\.com|samcart\.com|cartpanda\.com|myshopify\.com|shopify\.com|tiendanube\.com|nuvemshop\.com\.br|mitiendanube\.com|mercadoshops\.com|woocommerce\.com|wordpress\.com|wixsite\.com|squarespace\.com|webflow\.io|carrd\.co|notion\.site|canva\.site|play\.google\.com|apps\.apple\.com|itunes\.apple\.com|testflight\.apple\.com|chromewebstore\.google\.com|microsoft\.com|store\.steampowered\.com|itch\.io|checkout\.stripe\.com|buy\.stripe\.com|paypal\.com|paypal\.me|mercadopago\.com|mpago\.la|pagseguro\.uol\.com\.br|asaas\.com|docs\.google\.com|forms\.gle|drive\.google\.com|sites\.google\.com|typeform\.com|tally\.so|jotform\.com|bit\.ly|tinyurl\.com|cutt\.ly|rebrand\.ly|shorturl\.at)$/i;
  const OWN_SUBDOMAIN_RE = /^(?:checkout|pay|pago|pagos|compra|comprar|tienda|shop|store|loja|go|lp|oferta|ofertas|promo|curso|cursos|aula|aulas|clase|clases|app|membresia|miembros|members|acceso|login|blog|web|page|pages)\.(?=[a-z0-9-]+\.[a-z]{2,}$)/i;

  function destinationKey(href) {
    if (!href) return 'sin-destino';
    let url = href;
    try {
      const u = new URL(href);
      if (/(^|\.)l\.facebook\.com$|(^|\.)lm\.facebook\.com$/.test(u.hostname) && u.searchParams.get('u')) {
        url = u.searchParams.get('u');
      }
      const d = new URL(url);
      const host = d.hostname.replace(/^(www\.|m\.)/, '').toLowerCase();
      if (/^(wa\.me|api\.whatsapp\.com|whatsapp\.com|wa\.link|m\.me|messenger\.com|t\.me)$/.test(host)) return 'mensaje';
      if (/(^|\.)(facebook\.com|instagram\.com|fb\.me)$/.test(host)) return 'perfil-social';
      if (!SHARED_HOST_RE.test(host)) return host.replace(OWN_SUBDOMAIN_RE, '');
      return (host + d.pathname.replace(/\/+$/, '')).toLowerCase();
    } catch (e) {
      return 'sin-destino';
    }
  }

  function dayKey(d) {
    return d ? d.toISOString().slice(0, 10) : null;
  }

  /** links: lista de URLs o de {href, text}. El anunciante sale del link a su página de Facebook o del view_all_page_id. */
  function parseCardText(text, links) {
    const items = (links || []).map(l => (typeof l === 'string' ? { href: l, text: '' } : l));
    const hrefs = items.map(l => l.href);
    const id = (String(text).match(ID_RE) || [])[1] || null;
    const start = parseStartDate(text);
    const pageLink = items.find(l => /view_all_page_id=\d+/.test(l.href));
    const pageId = pageLink ? (pageLink.href.match(/view_all_page_id=(\d+)/) || [])[1] : null;
    const nameLink = items.find(l => l.text && l.text.trim().length > 1 && l.text.trim().length < 80 && /facebook\.com\/(?!ads\/library|l\.php)/.test(l.href));
    const outbound = hrefs.find(h => /l\.facebook\.com\/l\.php|^https?:\/\/(?!([a-z]+\.)?facebook\.com)/i.test(h) && !/facebook\.com\/ads\/library/i.test(h)) || null;
    const copies = parseCopies(text);
    const destination = destinationKey(outbound);
    return {
      id,
      copies,
      start: dayKey(start),
      lowImpressions: LOW_IMPRESSIONS_RE.test(text),
      inactive: INACTIVE_RE.test(String(text).slice(0, 300)),
      destination,
      advertiser: nameLink ? nameLink.text.trim() : null,
      pageId: pageId || null,
      snippet: String(text).replace(/\s+/g, ' ').slice(0, 160),
      group: groupKey(text, copies, destination),
    };
  }

  /**
   * Meta muestra el mismo grupo ("54 anuncios usan este creativo y este texto") en varias tarjetas: cada una con otro
   * identificador y otra fecha, pero el mismo texto y el mismo N. La clave quita identificadores, fechas y números largos.
   */
  function groupKey(text, n, destination) {
    const body = norm(text)
      .replace(new RegExp(ID_RE.source, 'gi'), ' ')
      .replace(/(circulacion desde|circulando desde|en circulacion desde|started running on|veiculacao iniciada em|veiculando desde)[^\n]{0,40}/g, ' ')
      .replace(/\d{5,}/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 400);
    return n + '|' + destination + '|' + body;
  }

  /** Un número suelto es identificador solo si la etiqueta de al lado lo nombra a él (un teléfono suelto no cuenta). */
  function labelled(el, digits) {
    const m = el ? (el.textContent || '').match(ID_RE) : null;
    return !!m && m[1] === digits;
  }

  /**
   * Identificadores de anuncio en la página: el texto "Identificador de la biblioteca: N", o un nodo solo con N si la
   * etiqueta está al lado. Recorre nodos de texto sueltos: sin innerText, que obliga al navegador a calcular el diseño.
   */
  function idAnchors(doc) {
    const anchors = [];
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      const text = node.nodeValue || '';
      if (!parent || SKIP_TAGS[parent.tagName] || text.length > 400) continue;
      let m = text.match(ID_RE);
      if (!m && (m = text.match(ID_DIGITS_RE))) {
        const up = parent.parentElement;
        if (!labelled(parent, m[1]) && !labelled(up, m[1]) && !labelled(up && up.parentElement, m[1])) m = null;
      }
      if (m) anchors.push({ el: parent, id: m[1] });
    }
    return anchors;
  }

  /**
   * Tarjetas nuevas de la página. La tarjeta de cada identificador es su ancestro más alto (hasta 14 niveles) que no
   * contiene otro identificador: se calcula con un mapa de ancestros en lugar de leer el texto de cada contenedor.
   * Las ya leídas quedan marcadas y no se vuelven a procesar (fresh: true las relee, para debug()).
   */
  function findCards(doc, opts) {
    const fresh = !!(opts && opts.fresh);
    const anchors = idAnchors(doc);
    const owner = new Map();
    for (const a of anchors) {
      for (let el = a.el, i = 0; el && i < 14; i++, el = el.parentElement) {
        const current = owner.get(el);
        if (current === undefined) owner.set(el, a.id);
        else if (current !== a.id) owner.set(el, '*');
      }
    }

    const pending = [];
    const seen = new Set();
    for (const a of anchors) {
      if (seen.has(a.id)) continue;
      let card = null;
      for (let el = a.el, i = 0; el && i < 14 && owner.get(el) === a.id; i++, el = el.parentElement) card = el;
      if (!card) continue;
      seen.add(a.id);
      if (!fresh && card.getAttribute(MARK) === state.token) continue;
      pending.push(card);
    }

    // Primero todas las lecturas y después las marcas: escribir entre lecturas obliga a recalcular el diseño en cada una.
    const cards = new Map();
    const els = [];
    for (const card of pending) {
      const parsed = parseCardText(card.innerText || '', Array.from(card.querySelectorAll('a[href]')).map(a => ({ href: a.href, text: a.textContent || '' })));
      if (parsed.id && !cards.has(parsed.id)) {
        cards.set(parsed.id, parsed);
        els.push(card);
      }
    }
    if (!fresh) els.forEach(el => el.setAttribute(MARK, state.token));
    return { cards, els };
  }

  /** "~280 resultados": está arriba de todo, así que el recorrido termina enseguida. Admite el número y la palabra en nodos separados. */
  function declaredTotal(doc) {
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    let node, prev = '';
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      const text = node.nodeValue || '';
      if (!parent || SKIP_TAGS[parent.tagName] || !text.trim()) continue;
      if (text.length > 200) { prev = ''; continue; }
      const m = (prev + ' ' + text).match(TOTAL_RE);
      if (m) return parseInt(m[1].replace(/[.,]/g, ''), 10);
      prev = text;
    }
    return null;
  }

  /** Muro de "inicia sesión": primero en los diálogos y, si no, en la página. Solo se busca cuando dejó de cargar. */
  function loginWall(doc) {
    for (const d of doc.querySelectorAll('[role="dialog"], [aria-modal="true"]')) {
      if (LOGIN_WALL_RE.test(d.textContent || '')) return true;
    }
    return LOGIN_WALL_RE.test(doc.body.innerText || '');
  }

  /** Copias que aporta cada tarjeta: un grupo repetido en varias tarjetas cuenta su N una sola vez (como en la base). */
  function countedCopies(list) {
    const seen = new Set();
    return list.map(c => {
      if (c.copies > 1 && c.group) {
        if (seen.has(c.group)) return 0;
        seen.add(c.group);
      }
      return c.copies;
    });
  }

  /** Idioma de la página de Meta ("es", "en"...), para saber si el conteo de "pocas impresiones" es confiable. */
  function pageLang() {
    try {
      return String((document.documentElement && document.documentElement.lang) || '').slice(0, 2).toLowerCase() || null;
    } catch (e) {
      return null;
    }
  }

  function summarize(cards, opts) {
    const today = opts && opts.today ? new Date(opts.today) : new Date();
    const since7 = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 7);
    const list = Array.from(cards.values());
    const valid = list.filter(c => !c.inactive && !c.lowImpressions);
    const counted = countedCopies(valid);
    const byDay = {};
    const byDest = {};
    const byAdv = {};
    let newAds = 0, newCopies = 0, first = null, last = null;
    valid.forEach((c, i) => {
      const n = counted[i];
      if (c.start) {
        byDay[c.start] = (byDay[c.start] || 0) + 1;
        if (!first || c.start < first) first = c.start;
        if (!last || c.start > last) last = c.start;
        if (new Date(c.start) >= since7) { newAds++; newCopies += n; }
      }
      const d = byDest[c.destination] || (byDest[c.destination] = { destino: c.destination, anuncios: 0, copias: 0, primer_anuncio: null });
      d.anuncios++; d.copias += n;
      if (c.start && (!d.primer_anuncio || c.start < d.primer_anuncio)) d.primer_anuncio = c.start;
      const advKey = c.pageId || c.advertiser || 'desconocido';
      const a = byAdv[advKey] || (byAdv[advKey] = { anunciante: c.advertiser || null, pagina_id: c.pageId || null, anuncios: 0, copias: 0, primer_anuncio: null, nuevos_7d: 0 });
      a.anuncios++; a.copias += n;
      if (c.start && (!a.primer_anuncio || c.start < a.primer_anuncio)) a.primer_anuncio = c.start;
      if (c.start && new Date(c.start) >= since7) a.nuevos_7d++;
    });
    const destinos = Object.values(byDest).sort((a, b) => b.copias - a.copias);
    const totalCopies = counted.reduce((s, n) => s + n, 0);
    const knownDestinos = destinos.filter(d => d.destino !== 'sin-destino' && d.destino !== 'mensaje' && d.destino !== 'perfil-social');
    const knownCopies = knownDestinos.reduce((s, d) => s + d.copias, 0);
    const low = list.filter(c => c.lowImpressions).length;
    const lang = opts && opts.lang ? opts.lang : null;
    // En un idioma sin la etiqueta conocida, 0 no es un dato: se informa sin dato para que nadie lo lea como "ninguna".
    const lowKnown = low > 0 || !lang || LOW_IMPRESSIONS_SURE_LANGS.indexOf(lang) >= 0;
    return {
      anuncios_leidos: list.length,
      anuncios_activos: valid.length,
      pocas_impresiones: lowKnown ? low : null,
      idioma_pagina: lang,
      inactivos: list.filter(c => c.inactive).length,
      copias_totales: totalCopies,
      nuevos_7d: newAds,
      copias_nuevas_7d: newCopies,
      primer_anuncio: first,
      ultimo_anuncio: last,
      por_dia: Object.keys(byDay).sort().map(k => ({ dia: k, anuncios: byDay[k] })),
      destinos: destinos.slice(0, 8),
      anunciantes: Object.values(byAdv).sort((x, y) => y.copias - x.copias).slice(0, 25),
      producto_principal: knownDestinos[0] ? knownDestinos[0].destino : null,
      concentracion_porcentaje: knownDestinos[0] && knownCopies ? Math.round(knownDestinos[0].copias * 100 / knownCopies) : null,
    };
  }

  /**
   * Lo que ya cubrimos de lo que Meta dice tener. El total de Meta cuenta anuncios, y según la página un grupo
   * ("29 anuncios usan…") aparece como una tarjeta o repetido en varias: se toma lo mayor entre tarjetas leídas y copias.
   * Si las copias superan el total, incluyen anuncios inactivos del grupo y no sirven para medir: solo cuentan las tarjetas.
   */
  function coverage(cards, total) {
    if (!total) return null;
    const list = Array.from(cards.values());
    const copies = countedCopies(list).reduce((s, n) => s + n, 0);
    const read = copies > total ? list.length : Math.max(list.length, copies);
    return Math.min(100, Math.round(read * 100 / total));
  }

  async function nudgeScroll(doc) {
    const scroller = doc.scrollingElement || doc.documentElement || doc.body;
    const els = Array.from(state.lastCardEls || []);
    const lastEl = els[els.length - 1];
    if (lastEl && lastEl.isConnected) lastEl.scrollIntoView({ block: 'end' });
    window.scrollTo(0, scroller.scrollHeight);
    await new Promise(r => setTimeout(r, 400));
    window.scrollBy(0, -600);
    await new Promise(r => setTimeout(r, 300));
    window.scrollTo(0, scroller.scrollHeight);
    window.dispatchEvent(new Event('scroll'));
  }

  const here = typeof location !== 'undefined' ? location.href : null;
  const previous = typeof window !== 'undefined' && window.__nexusScanState;
  // Solo se retoma un escaneo de esta misma página de hace menos de 10 minutos: uno más viejo (la pestaña quedó abierta)
  // traería tarjetas que Meta ya no muestra y daría números de otro momento.
  const fresh = previous && previous.url === here && Date.now() - (previous.createdAt || 0) < 600000;
  const state = fresh ? previous
    : { url: here, createdAt: Date.now(), cards: new Map(), stableRounds: 0, done: false, startedAt: null, lastCardEls: [], blocked: null };
  state.token = state.token || 'nx' + Math.random().toString(36).slice(2, 10);
  if (typeof window !== 'undefined') window.__nexusScanState = state;

  function absorb(doc) {
    const before = state.cards.size;
    const found = findCards(doc);
    for (const [k, v] of found.cards) if (!state.cards.has(k)) state.cards.set(k, v);
    if (found.els.length) state.lastCardEls = found.els.slice(-3);
    const added = state.cards.size - before;
    if (added === 0 && loginWall(doc)) state.blocked = 'login';
    state.stableRounds = added === 0 ? state.stableRounds + 1 : 0;
    return added;
  }

  function collect() {
    const added = absorb(document);
    const total = declaredTotal(document);
    return { nuevas: added, cards: state.cards.size, total_meta: total, cobertura_porcentaje: coverage(state.cards, total), sin_cambios_seguidas: state.stableRounds, bloqueo: state.blocked };
  }

  async function step(budgetMs) {
    const deadline = Date.now() + Math.min(budgetMs || 15000, 20000);
    state.startedAt = state.startedAt || Date.now();
    const initialTotal = declaredTotal(document);
    const initialCov = coverage(state.cards, initialTotal);
    if (state.done && !state.blocked && initialCov !== null && initialCov < 80 && state.cards.size < 400) {
      state.done = false;
      state.stableRounds = 0;
    }
    while (Date.now() < deadline && !state.done) {
      await nudgeScroll(document);
      await new Promise(r => setTimeout(r, 2500));
      absorb(document);
      const curTotal = declaredTotal(document);
      const curCov = coverage(state.cards, curTotal);
      const maxStable = curCov !== null && curCov < 80 ? 4 : 3;
      if (state.stableRounds >= maxStable || (curCov !== null && curCov >= 95) || state.cards.size >= 400 || Date.now() - state.startedAt > 300000) state.done = true;
    }
    const total = declaredTotal(document);
    return { done: state.done, cards: state.cards.size, total_meta: total, cobertura_porcentaje: coverage(state.cards, total), bloqueo: state.blocked };
  }

  /** Completo si leyó al menos el 80% de lo que Meta declara; si Meta no declara total, si dejó de cargar varias veces seguidas. */
  function result() {
    const total = declaredTotal(document);
    const cov = coverage(state.cards, total);
    const reachedEnd = !state.blocked && (cov !== null ? cov >= 80 : state.stableRounds >= 3);
    return Object.assign({
      version: VERSION,
      // Cuándo se leyó de verdad la página: el servidor rechaza un resultado viejo reenviado como si fuera nuevo.
      leido_en: new Date().toISOString(),
      url: location.href,
      total_meta: total,
      cobertura_porcentaje: cov,
      llego_al_final: reachedEnd,
      bloqueo: state.blocked,
      parcial_motivo: reachedEnd ? null : (state.blocked === 'login' ? 'Meta pidió iniciar sesión' : (cov !== null && cov < 80 ? `Meta dejó de cargar: se leyó ~${cov}% de lo que declara` : 'no se terminó de bajar')),
    }, summarize(state.cards, { lang: pageLang() }));
  }

  function debug() {
    const found = findCards(document, { fresh: true });
    return { version: VERSION, idioma_pagina: pageLang(), encontradas: found.cards.size, leidas: state.cards.size, muestra: Array.from(found.cards.values()).slice(0, 3), texto_pagina: (document.body.innerText || '').slice(0, 1500) };
  }

  const api = { version: VERSION, step, collect, result, debug, _helpers: { parseStartDate, parseCopies, destinationKey, parseCardText, summarize, coverage, groupKey, findCards, declaredTotal } };
  if (typeof window !== 'undefined') window.nexusScan = api;
  if (typeof module !== 'undefined') module.exports = api;

  // Copia en la pestaña: en las páginas siguientes el cargador de la skill la vuelve a cargar como <script src="blob:...">
  // (Meta no permite eval), sin pegar de nuevo el archivo entero.
  try {
    if (typeof localStorage !== 'undefined') localStorage.setItem('__nexusScanSrc', '(' + nexusInstall.toString() + ')();');
  } catch (e) {
    // Sin almacenamiento: se pega el archivo en cada página, como antes.
  }
})();
