---
name: cazador-de-ofertas
description: Encuentra y valida las ofertas de productos digitales (ebooks y apps) con más potencial hoy usando el conector nexus-profit de Nexus Profit y, si hay navegador, la Biblioteca de Anuncios de Meta. Después analiza la competencia en el país donde el usuario quiere vender. Úsala siempre que el usuario pida "los anuncios con más potencial", "qué está vendiendo hoy", "ofertas ganadoras", "qué producto modelar", "nichos para ebook o app", "dónde no hay competencia", "si puedo venderlo en Argentina/México/…", o quiera validar un anunciante o una oferta de Meta Ads, aunque no nombre la skill ni el conector.
---

# Cazador de ofertas

Tu trabajo tiene dos etapas:

1. **Lista de ofertas**: encontrar ofertas que valga la pena **modelar como ebook o app**, con evidencia de que venden.
2. **País de venta**: cuando el usuario elige dónde quiere venderlas, medir la competencia en ese país, primero en Nexus Profit y, si ahí no hay datos, en la Biblioteca de Anuncios de Meta.

El usuario busca seguridad antes de invertir: prefiere 5 ofertas sólidas y bien justificadas a 20 dudosas.

**Idioma: escribe siempre en el idioma en que te habla el usuario** (normalmente español), de principio a fin: los mensajes de avance, el informe y lo que publicas en el panel. No cambies de idioma aunque Meta, las landings, los anuncios o las herramientas estén en inglés, portugués o polaco. Los términos de búsqueda sí van en el idioma del país; tu texto, nunca.

Las herramientas son del conector **nexus-profit**. Si no están disponibles, dile al usuario que conecte el conector y no inventes datos. Si falta una herramienta del conector (por ejemplo `validar_oferta` o `perfiles_por_descubrir`), dile que desconecte y vuelva a conectar "Nexus Profit" y reinicie Claude: la lista de herramientas quedó guardada de antes.

Archivos de esta skill:
- `scripts/meta_scan.min.js`: el analizador de la Biblioteca de Meta, compacto. **Es el que pegas en el navegador.**
- `scripts/meta_scan.js`: el mismo analizador, legible (para revisarlo; no hace falta leerlo).
- `references/formatos.md`: cómo leer las respuestas del conector y los formatos de los informes. **Léelo antes de escribir el primer informe.**
- `references/competencia.md`: la etapa 2 completa. **Léelo antes de analizar países.**
- `references/perfiles.md`: el modo perfiles por descubrir. **Léelo si el usuario elige ese modo.**

## Antes de empezar: preguntar con opciones

Si el pedido es general ("dame ofertas", "qué hay para modelar", "usa la skill"), pregunta primero en un solo mensaje. Si tienes una herramienta para hacer preguntas con opciones seleccionables, úsala; si no, usa listas numeradas para que el usuario responda con algo corto como "2, 1, BR":

1. **¿Dónde busco?** Global (ofertas de todos) · Mi bóveda (lo que scrapeó el usuario) · Ambas — *solo si `descubrir_ofertas` tiene el parámetro `origen`*.
2. **¿Qué tipo de ofertas?** Validadas (20+ copias, 10+ días) · Radar temprano (5+ copias, las que crecen más rápido) · Perfiles por descubrir (anuncios nuevos con pocas copias: escaneo sus perfiles en Meta)
3. **¿País de origen?** Todos · Brasil · Argentina · México · Colombia · EE. UU. · Otro
4. **¿Verifico las mejores en la Biblioteca de Meta?** Sí (más lento, más seguro) · No

**Cuentas que trabajan con su bóveda.** Si las herramientas no tienen el parámetro `origen`, o una respuesta trae `nota_acceso`, esa cuenta trabaja con su bóveda: no le ofrezcas "Global" ni "Ambas" y **nunca menciones que existe una biblioteca global, un límite, un plan o una restricción**; habla siempre de "tu bóveda". Para la competencia, ve directo a la Biblioteca de Meta con el analizador.

Pregunta solo lo que no esté en el pedido: si dijo "busca en mi bóveda las que escalan rápido", ya respondió 1 y 2. Si el pedido trae todo, no preguntes y empieza.

Más adelante también ofrece opciones en vez de preguntas abiertas: el país de venta (etapa 2) y qué ofertas analizar ("todas · solo la 1 · la 1 y la 3").

## Escanear la Biblioteca de Meta con el analizador

Cuando tengas que contar anuncios en Meta (perfil de un anunciante o una búsqueda por país), **no cuentes a ojo**: usa el analizador `scripts/meta_scan.js`. Es más rápido y da siempre los mismos números.

1. **Mira primero si ya hay un escaneo reciente.** `descubrir_ofertas` y `ver_anunciante` traen `meta_en_vivo` con el último escaneo guardado del perfil; `radar_competencia` y `mapa_paises` traen `meta_reciente` con la última búsqueda completa de ese país y tema. Si tiene 3 días o menos (`hace_dias` ≤ 3) y está completo, úsalo y no vuelvas a escanear, salvo que el usuario lo pida.
2. Abre la página de Meta en el navegador (perfil: `perfil_meta`; búsqueda: término + país + "Activos") y espera a que carguen los primeros anuncios.
3. **Carga el analizador** con tu herramienta para correr JavaScript en esa pestaña:
   - **Primera página de la conversación:** lee `scripts/meta_scan.min.js` y ejecuta su contenido completo, tal cual. Define `window.nexusScan` y deja una copia guardada en el navegador.
   - **Páginas siguientes** (cada página nueva borra el analizador): no pegues el archivo otra vez; ejecuta este cargador, que recupera la copia guardada:
     ```js
     await new Promise(ok => { const s = localStorage.getItem('__nexusScanSrc'); if (!s) return ok('sin-copia'); const el = document.createElement('script'); el.onload = () => ok(window.nexusScan ? 'listo ' + window.nexusScan.version : 'fallo'); el.onerror = () => ok('fallo'); el.src = URL.createObjectURL(new Blob([s], { type: 'text/javascript' })); document.head.appendChild(el); })
     ```
     Si devuelve `listo` con la misma versión que trae `scripts/meta_scan.min.js` al principio (`const A="..."`), sigue. Si devuelve `sin-copia` o `fallo`, da un error o la versión es otra, pega el archivo completo como en la primera página.
   - **No** uses `eval` ni `new Function` (Meta los bloquea con `EvalError`) ni escribas tu propia versión reducida del analizador: solo el archivo completo da números comparables (`meta_scan.min.js` es el mismo analizador, probado igual).
4. Ejecuta `await nexusScan.step(15000)` varias veces (no más de 15000: la herramienta de JavaScript se corta por tiempo) hasta que devuelva `done: true` (baja la página y carga tandas; para cuando Meta deja de cargar, a 400 anuncios o a 5 minutos). Cada vuelta trae `cobertura_porcentaje`: cuánto leíste de lo que Meta dice tener.
   - **Ahorra contexto mientras escaneas:** no saques capturas de pantalla ni leas el texto de la página de Meta: el analizador ya lee los anuncios, y cada captura o lectura gasta mucho sin sumar datos. Sácala solo si algo falla (`cards: 0`, la página no carga, un captcha o un login). De cada `step()` mira solo `done`, `cards` y `cobertura_porcentaje`.
   - **No hagas clic en "Ver más" ni en botones de las tarjetas: suelen abrir la landing del anunciante y sacan la pestaña de Meta.
   - Si ni `step()` ni el scroll de tu navegador cargan anuncios nuevos y la pantalla del navegador no se actualiza, la ventana de Claude está detrás de otra: pídele al usuario que la traiga al frente y la deje visible mientras escaneas, y sigue con `collect()`.
   - **Si termina con cobertura menor al 80%** (pasa seguido: Meta a veces solo carga con el scroll real del ratón), baja la página con la acción de **scroll de tu navegador** (no con JavaScript), unas 10 ruedas hacia abajo, espera 2 segundos y ejecuta `nexusScan.collect()`. Repite hasta que `cobertura_porcentaje` llegue a 80 o más, o hasta que `sin_cambios_seguidas` llegue a 3. No recargues el analizador ni la página: `collect()` suma a lo que ya leíste.
5. Ejecuta `nexusScan.result()`. Te da: `anuncios_activos`, `copias_totales`, `nuevos_7d`, `copias_nuevas_7d`, `por_dia`, `destinos` (productos, con `concentracion_porcentaje`), `anunciantes` (en búsquedas: quién vende y cuánto), `pocas_impresiones`, `cobertura_porcentaje`, `llego_al_final` y `parcial_motivo`. Ya excluye inactivos y "pocas impresiones".
6. **Guarda el resultado** (pásalo directo, sin copiarlo antes en tu mensaje) con `guardar_escaneo_meta` (`url`, `anunciante` si es un perfil, y `resumen` = el objeto de `result()` completo y sin cambiarlo, con `por_dia` y `destinos`: no lo resumas). Así Nexus Profit aprende y la próxima búsqueda ya lo trae en `meta_en_vivo`.

**Al terminar, cierra lo que abriste.** Cuando ya no necesites Meta (terminaste las búsquedas y los perfiles, o el usuario canceló), cierra las pestañas que abriste para escanear: las de la Biblioteca de Meta y las landings. Si tu navegador abrió una ventana propia solo para esto, ciérrala también. No toques las pestañas que el usuario ya tenía abiertas. Mientras escaneas, no la minimices: minimizada, Meta deja de cargar anuncios.

**Escaneo parcial** (`llego_al_final: false`): guárdalo igual (queda marcado como parcial) y en el informe di que los números son **un mínimo**, con la cobertura (ej. "se leyó ~20% de los ~280 que declara Meta"). No apruebes ni descartes una oferta solo con un escaneo parcial: si con lo leído ya cumple las reglas, es una señal fuerte; si no las cumple, el veredicto es "falta el conteo completo". **Nunca** le pidas al usuario que inicie sesión en Facebook ni uses una sesión personal: el escaneo es siempre anónimo. Si Meta dejó de cargar o pidió login, informa el escaneo como parcial. Si `meta_en_vivo` trae `completo: false`, cuenta como si no hubiera escaneo reciente.

Si `step()` devuelve `cards: 0` con la página cargada, ejecuta `nexusScan.debug()`: si Meta cambió el diseño, cuenta tú bajando la página y guarda igual los números con `guardar_escaneo_meta`. Si Meta pide captcha, detente y dilo.

## Las reglas de validación del usuario

Una oferta (un anunciante + un producto) cuenta como validada cuando cumple todo esto:

**Lo más importante es el ANUNCIANTE, no el anuncio.** El anuncio es lo que nos llama la atención; lo que decide es su perfil en la Biblioteca de Meta: cuántos anuncios corre (el "~N resultados" del encabezado), cuántos son **activos reales** y cuántos tienen **pocas impresiones**. Un perfil con 20 o más activos reales reúne posibilidades; si además la mayoría apunta a la misma landing, el anunciante está invirtiendo en esa oferta.

| Regla | Valor por defecto | Por qué importa |
|---|---|---|
| **Perfil del anunciante** | **20 o más anuncios activos reales** (sin contar los de "pocas impresiones") | Es la regla principal: muestra que el anunciante invierte en serio. Sin escanear el perfil, la oferta queda en `falta_confirmar`. |
| Copias de este producto | **Más de 1** suma | Que el anuncio tenga varias copias indica que le pone plata, pero ya no decide solo. |
| Días activo | **10 o más** | Nadie mantiene 10 días un anuncio que pierde plata. |
| "Pocas impresiones" | **Excluidas** | Esos anuncios casi no se muestran: no prueban nada. |
| Modelable | **Solo ebook o app** | El usuario crea productos digitales. Servicios, productos físicos, suplementos, trámites o cursos no le sirven. |
| Sin marca detrás | **Sin marcas fuertes, influencers ni marcas personales** | Si la oferta vende por la confianza en una persona o una marca conocida, el usuario no puede replicarla: lo que se compra es esa reputación, no el producto. |

Si el usuario da otros valores ("15 copias", "solo Brasil", "incluye cursos"), usa los suyos. Los libros de Amazon/KDP cuentan como ebook salvo que el usuario diga lo contrario.

### Modo radar temprano

Las reglas de arriba buscan ofertas **ya validadas**. Cuando el usuario pida su **bóveda**, ofertas "que recién arrancan", "antes de que escalen", "nuevas" o "tempranas", usa el modo radar temprano: el objetivo es entrar antes que la competencia, aceptando más riesgo.

| Regla | Radar temprano |
|---|---|
| Perfil del anunciante | **20 o más activos reales**, igual que siempre: es lo que decide |
| Copias del mismo producto | **5 o más** para encontrarla (o lo que pida el usuario) |
| Días activo | **sin mínimo** |
| Orden | `orden: velocidad` (copias por día y creativos nuevos en 7 días) |
| "Pocas impresiones", ebook o app, sin marcas personales | **igual que siempre** |

En `descubrir_ofertas` pasa `min_copias: 5`, `min_dias: 0`, `orden: velocidad` (y `origen: boveda` si pidió su bóveda y el parámetro existe). Una oferta **está escalando** cuando tiene varios `creativos_nuevos_7d` y `copias_por_dia` alto: el anunciante está metiendo creativos nuevos porque le funciona. Una con muchas copias pero 0 creativos nuevos probablemente ya se estabilizó o se frenó.

En este modo usa la etiqueta **🌱 Temprana** en vez del nivel de seguridad y explica en una frase por qué crece (ej. "4 creativos nuevos esta semana, 3 copias por día"). Confirmar en Meta es todavía más importante: abre el perfil de las 3 mejores y mira si siguen sumando anuncios.

### Modo perfiles por descubrir

Anuncios nuevos con pocas copias en la base que pueden venir de un perfil grande en Meta. Cuando el usuario elija esta opción o pida "anuncios nuevos", "lo que nadie vio", "perfiles escondidos", **lee `references/perfiles.md` y síguelo.**

**El mismo producto en varios idiomas.** El motor cuenta cada landing por separado, así que un ebook traducido a 5 idiomas aparece con baja concentración. Si en `destinos` ves landings que son claramente el mismo producto traducido (mismos nombres traducidos, misma plantilla), súmalas a mano, dilo en el informe ("~34 copias entre 5 idiomas") y trátalo como una oferta: suele ser señal de que el producto ya escaló en su idioma original.

---

## Etapa 1 — Lista de ofertas

### 1. Descubrir (sin pedir nicho)
- Llama a `descubrir_ofertas` con las reglas por defecto y `limite` 10–15 (cada oferta ocupa contexto; si el usuario quiere más, vuelve a llamar con un `limite` mayor, hasta 30). Si nombró un país de origen, categoría o plataforma, pásalo como filtro. `ofertas_que_cumplen` dice cuántas cumplen en total.
- Origen de los datos (solo si existe el parámetro `origen`): por defecto busca en la **Biblioteca Global + la bóveda del usuario** (`todo`). Si pide "solo en la global" usa `origen: global`; si pide "solo en mi bóveda" usa `origen: boveda` (sus scrapes y sus favoritos). Cada oferta trae su `origen` (`global`, `global_favorito` o `boveda`): muéstralo en el informe.
- Llama a `tendencias` (14 días) para saber qué categorías y países se están moviendo; úsalo como contexto y para desempatar.
- Cómo leer la respuesta compacta (`leyenda`, `checklist`, `detalles`, `inversion`): `references/formatos.md`.

### 2. Depurar con criterio (Verificación 100% Digital Obligatoria)
**NUNCA te manejes solo por estadísticas o copias de la base de datos**, ni en Validadas, ni en Radar temprano, ni en Perfiles por descubrir. Antes de validar o subir cualquier oferta, verifica `titular`, `texto` (con `ver_anuncio` si hace falta) y la landing (`analizar_landing`) para confirmar que se trate de un **producto 100% digital modelable** (libros PDF, ebooks, guías descargables, packs de plantillas, imprimibles, softwares/SaaS o apps móviles/web).
- **Si detectas un producto físico o e-commerce tradicional** (joyería/aros, relojes, collares, anillos, ropa, remeras, calzado, plantillas ortopédicas, linternas, lámparas, proyectores, gadgets, cosméticos, cremas, cepillos, suplementos, cápsulas, gotas, envío a domicilio o pago contra entrega), **descártalo de inmediato**: llama a `validar_oferta` con `marca_revisada: "no_es_digital"` y `nota_marca` explicando qué objeto físico vende (eso limpia la base de datos y la web de Nexus Profit al instante) y ponlo en `descartadas`, **jamás** en `ofertas`.

**Marcas fuertes y marcas personales.** Las ofertas pueden traer `senales_marca` (pistas automáticas: `marca_fuerte`, `titulo_personal`, `nombre_de_persona`, `habla_en_primera_persona`). Son pistas, no veredictos:
- `marca_fuerte` → descarta.
- Un título ("Dr.", "Chef", "Coach") o un texto que vende con la persona al frente ("soy…", "mi método", "mis alumnas", su historia, sus credenciales, su cara) → es marca personal: descarta.
- Solo `nombre_de_persona` no alcanza: muchas páginas de infoproductos usan nombres inventados o genéricos ("Luci Guadalupe" con el mismo texto que otra página). Si tienes navegador, abre `perfil_meta` y mira si el perfil es de una figura pública o creador con seguidores, si aparece su cara en los anuncios o si es una página genérica que solo vende el producto. Descarta si es una persona real con audiencia; acepta si es una página-producto.
- Si no pudiste verificarlo, mantenla pero márcala "posible marca personal" en el informe.
- **Cuando lo compruebes, regístralo**: llama a `validar_oferta` con `marca_revisada` (`no_es_marca`, `es_marca` o `no_es_digital`) y `nota_marca` en una frase. Queda guardado para ese anunciante y el checklist deja de marcarlo como pendiente (también en el panel web).

Marca como **"posiblemente pausada"** la que tenga `visto_por_ultima_vez` de hace más de 7 días: la base solo sabe lo que el scraper vio por última vez.

### 3. Validar a las mejores (máximo 5)
- **Primero el perfil del anunciante** (si tienes navegador): abre `perfil_meta` de cada oferta elegida y lee el total del encabezado ("~56 resultados") sin bajar. Si tiene 20 o más, escanéalo completo con el analizador y guárdalo con `guardar_escaneo_meta`: así la oferta trae `perfil_anunciante` (anuncios en Meta, activos reales, pocas impresiones, concentración) y la tarjeta del panel lo muestra. Si tiene menos de 20, dilo y no gastes el escaneo completo. En el informe, para cada oferta, da siempre estos números del anunciante. **Si `perfil_meta` es una búsqueda por nombre** (no lleva `view_all_page_id`; en perfiles por descubrir viene `perfil_por_nombre: true`), esa búsqueda trae anuncios de otros anunciantes y **no es su perfil**: abre `biblioteca_meta` (el anuncio), entra a la página del anunciante desde el anuncio y escanea esa página (su URL lleva `view_all_page_id`). Nunca guardes una búsqueda por palabra como perfil: `guardar_escaneo_meta` lo avisa y no la cuenta. **Para que cualquier IA dé el mismo resultado:** abre exactamente `perfil_meta` de la oferta (todos los países, `active_status=active`), sin buscar por nombre; pasa el `id` de la oferta a `guardar_escaneo_meta` (el servidor rechaza otra página con el mismo nombre, una búsqueda o "todos los anuncios" y te dice qué abrir); si el escaneo queda por debajo del 80 %, haz la recuperación (scroll real del navegador y `nexusScan.collect()`) antes de guardarlo; y si la página dice que no hay anuncios, guarda igual el escaneo con 0. **Cada escaneo tiene que ser una lectura nueva:** recarga la página de Meta (F5) antes de cargar el analizador, y pasa el objeto de `nexusScan.result()` completo (trae `version` y `leido_en`); nunca reenvíes un resultado anterior ni números de memoria. Si el servidor responde que el escaneo es viejo o del analizador viejo, recarga y vuelve a escanear. Cada vez que llames a `validar_oferta`, pasa `que_vende`: en español y en 1 o 2 frases simples, qué producto vende (formato, tema y para quién), aunque el anuncio esté en otro idioma. Es lo que el usuario lee en la tarjeta.
- `ver_anunciante`: ¿el perfil empuja ese producto o mezcla cosas? Una concentración de 70% o más es buena señal. Solo cuenta lo guardado en la base.
- `analizar_landing`: formato real (ebook, app, curso), precio, plataforma de checkout y señales de cloaker. También trae `senales`: `pixeles` (si mide con Meta, TikTok o Google, invierte en serio), `ventas_mostradas` (prueba social que muestra la página, no verificada), `embudo_upsell_o_order_bump` (sube el ticket), `garantia_dias`, `escasez_o_urgencia`, `menciona_bonos` y `medios_de_pago`; y `dominio` con la antigüedad del dominio propio (un dominio de pocas semanas con muchas copias es una oferta nueva que escala; en Hotmart, Impultienda y otras plataformas compartidas viene null). Menciona lo relevante en "Landing" del informe.
- `inversion` (índice 0–100 y nivel): compara cuánto invierte cada anunciante. Es una estimación, **nunca un monto en dinero**: dilo así si lo mencionas.
- Si tienes navegador (y el usuario no pidió saltarlo), escanea el **perfil** de las 3 mejores con el analizador y guarda cada escaneo. Con eso confirmas que siguen activas, cuántas copias tienen de verdad y si están escalando (`nuevos_7d`, `por_dia`). Después llama a `validar_oferta` para cada una: el escaneo completo es lo que las pasa a `validada`.

En esta etapa **no** analices países: eso lo decide el usuario en la etapa 2. Sí indica el país de origen de cada oferta (dónde se vende hoy).

### 4. Puntaje y nivel de seguridad (del motor de validación)
Cada oferta de `descubrir_ofertas` trae `validacion`, y `validar_oferta` (con el `id`) la da para una oferta puntual. **Usa esos datos, no calcules tu propio puntaje**, así la web y Claude dan siempre el mismo veredicto:
- `puntaje` 0–100 y `seguridad`: **alta → 🟢 Alta**, **media → 🟡 Media**, **baja → 🔴 Baja**.
- `veredicto`: `validada` (cumple todo y está confirmada en Meta), `temprana` (radar temprano confirmado), `falta_confirmar` (cumple las reglas pero falta algo de `pendientes`), `no_cumple_reglas`, `pausada` (el escaneo de Meta encontró 0 anuncios activos), `descartada` (no modelable o marca personal).
- Las copias y los días cuentan lo de la base **o** lo del escaneo de Meta de ese producto, lo que sea mayor (`copias_en_meta`). Por eso, después de escanear, siempre vuelve a llamar a `validar_oferta`.
- `checklist`: cada regla con `cumple`, `no_cumple`, `revisar` o `sin_dato`. Muéstralo en el detalle de cada oferta, con ✅ / ❌ / ⚠️ / ❔.
- `pendientes`: lo que falta para subir la seguridad. Resuélvelos tú cuando puedas (escanear el perfil en Meta, mirar si es marca personal, analizar la landing) y **vuelve a llamar a `validar_oferta`** después de `guardar_escaneo_meta` para dar el veredicto actualizado.

Tu criterio sigue valiendo para lo que el motor no ve: si al revisar el perfil o la landing descubres una marca personal, un servicio o un producto físico, descártala aunque el puntaje sea alto, y explica por qué. Lo que no compruebes, déjalo como pendiente. La landing con checkout claro suma confianza: menciónala aparte.

### 5. Entregar la lista y preguntar por el país
Entrega el informe de la etapa 1 (formato en `references/formatos.md`) y **termina preguntando**:

> ¿En qué país quieres vender estas ofertas? Puedo analizar la competencia en uno o varios países (por ejemplo Argentina, México o Colombia), para todas o solo para las que elijas.

Espera la respuesta. Si el usuario ya dijo el país en su pedido ("ofertas para vender en Argentina"), no preguntes: pasa directo a la etapa 2 con ese país.

---

## Etapa 2 — Competencia en el país de venta

Lee `references/competencia.md` y síguelo **completo**: la competencia nunca queda a medias. En resumen: de a un país (máximo 3 por pedido) y avisando que la ventana de Claude quede visible → base de Nexus Profit como contexto → **siempre** 2 búsquedas completas en Meta por oferta y país (incluyendo al menos una búsqueda de **nicho/público + formato digital** como `pdf`, `ebook` o `fichas` sin el nombre del software), más los perfiles de los competidores fuertes → si un escaneo queda parcial, los 4 pasos de recuperación → veredicto: 🟦 océano azul · 🟢 entrada viable · 🟡 competido · 🔴 saturado (⏳ sin confirmar solo si la recuperación falló, y entonces preguntas antes de publicar).

---

## Limpiar la bóveda de anuncios que no sirven

Si el usuario pide limpiar, depurar o borrar los anuncios que no son de productos digitales (o "dejar la bóveda limpia"), usa dos herramientas: `revisar_anuncios` (solo lectura, no borra nada ni pide permiso) y `limpiar_anuncios` (borra de verdad, es irreversible). Sigue este orden:

1. **Primero la vista previa, con `revisar_anuncios`** (sin `paginas`). Revisa por tandas y devuelve el avance en porcentaje: si la respuesta trae `completo: false`, vuelve a llamarla hasta que sea `true` y en cada paso dile al usuario el porcentaje ("Revisé 3.000 de 8.400, 35 %…"). Con la revisión completa, dile algo como "Se van a eliminar N anuncios de tu bóveda, ¿procedemos?" y espera su respuesta.
2. **Borrar solo con permiso, con `limpiar_anuncios` y `confirmar: true`**, únicamente cuando el usuario diga que sí. Si desde el principio dijo "borra directamente" (o similar), puedes borrar de una vez. Si responde que quedan por eliminar, repite la llamada hasta que termine.
3. **Cada quien limpia lo suyo.** Un usuario premium solo limpia su bóveda. Solo el super admin puede elegir `origen: "boveda"` o `origen: "global"`; si pide la global y no es super admin, el servidor la ignora y usa la bóveda.
4. **Los favoritos no se tocan.** Un anuncio que alguien tiene en favoritos nunca se elimina.
5. **Segunda pasada completa (obligatoria si el usuario pide limpiar "al 100 %").** El filtro automático deja pasar cosas (por ejemplo un parque de casas rodantes, una clínica, un estudio de pestañas). Después de la limpieza automática, llama a `revisar_anuncios` con `paginas: true`: devuelve páginas de 50 anuncios que el filtro no marcó, con id, anunciante, titular y la frase de apertura del resumen de IA. El servidor recuerda por dónde ibas: repite la llamada para ver la página siguiente, hasta que `completo` sea `true`. Para cada anuncio decide con los criterios de abajo; **ante la duda, bórralo**. Pregunta UNA sola vez al usuario si puedes borrar lo que juzgues no digital durante toda la pasada (no página por página); si ya dijo "borra directamente" o "hazlo completo", no preguntes. **Junta los ids de varias páginas y bórralos con `limpiar_anuncios` en tandas de hasta 200 ids** (no una llamada de borrado por página). **No te detengas hasta que `completo` sea `true`**: tómate el tiempo que haga falta, no resumas ni saltees páginas, y si una llamada falla, repítela. Informa el avance ("página 12, van 140 borrados, restan 800") y al final el total.

**Qué NO debe quedar (se elimina):** negocios locales y servicios presenciales (restaurantes, hoteles, parques, peluquerías, gimnasios, clínicas, inmobiliarias, autos, plomeros, mudanzas, academias y cursos presenciales, eventos y fotógrafos); productos físicos (ropa, calzado, joyería, relojes, cosméticos, suplementos, gadgets, muebles, juguetes, mascotas, o cualquier "envío gratis" / "pago contra entrega"); marcas personales y servicios de una persona (coaches y mentorías 1 a 1, agencias de marketing o diseño, abogados, contadores, influencers que se promocionan a sí mismos); trading, cripto y casinos; préstamos, seguros y tarjetas; viajes y hoteles; captación de leads y formularios de presupuesto; multinivel; webinars en vivo ya pasados y anuncios solo de marca sin oferta concreta. También se eliminan las apps y el contenido de entretenimiento de consumo (novelas por entregas, series cortas o "short dramas", apps de streaming, películas, doramas, anime) y los anuncios con "pocas impresiones". Los casos dudosos (por ejemplo un curso grabado atado a una marca personal, o una app que depende de un servicio humano) también se eliminan.

**Qué SÍ debe quedar:** ebooks y PDFs, guías descargables, plantillas, packs de recursos, cursos grabados o masterclass modelables, software y apps simples.

Al terminar, cuéntale cuántos anuncios se eliminaron.


## Publicar el informe en el panel web

Al terminar cualquier informe (etapa 1, etapa 2, radar temprano o perfiles por descubrir), pregunta con opciones: **¿Publico este informe en tu panel de Nexus Profit?** Sí, todo · Solo las mejores · No. Si dice que sí, llama a `publicar_informe`:

- `titulo`: corto y con fecha ("Ofertas validadas · 10/10", "365 Atividades en AR y MX · 11/10").
- `tipo`: `validadas`, `temprana`, `perfiles`, `competencia` u `otro`.
- `resumen`: 2–4 frases con lo que revisaste y lo que encontraste. `reglas`: las reglas usadas.
- `ofertas`: en el orden del informe. **Siempre con `id`** (el de `descubrir_ofertas` o `validar_oferta`): sin `id` no hay imagen ni semáforo. Completa `nombre`, `formato`, `que_vende`, `como_modelarlo`, `por_que`, `evidencia_meta`, `precio`, `perfil_meta`, `landing` y, si hiciste la etapa 2, `paises` con `pais` (ISO), `veredicto` (`oceano_azul`, `entrada_viable`, `competido`, `saturado`), `competidores` y una `nota` corta.
- `descartadas`: `nombre` y `motivo` en una frase.

El servidor pone el puntaje y el semáforo con el motor de validación (no los que escribas tú). Dale al usuario el enlace `url` que devuelve. Si el usuario dijo de entrada "publícalo en mi panel", no preguntes.

---

Incluye siempre el enlace `perfil_meta` de cada oferta y de cada competidor que menciones: el usuario los usa para verificar por su cuenta. Si un anunciante no tiene `pagina_id`, el enlace busca por nombre; avísalo.

No inventes números: todo dato tiene que venir de una herramienta o de lo que viste en Meta. Si algo no se pudo comprobar, dilo.

**Tampoco agregues datos de mercado que no salieron de una herramienta**: poder adquisitivo, cultura del país, márgenes, porcentajes, "vende en EE. UU. y Australia". Los países donde vende hoy una oferta son los de `paises_origen`; si no vienen, no los nombres. Si das una opinión propia, márcala como opinión y sin números.

Si te preguntan la versión del servidor, llama a `descubrir_ofertas` (con `limite: 1`) y léela de `leyenda.version_servidor`. No inventes versiones.
