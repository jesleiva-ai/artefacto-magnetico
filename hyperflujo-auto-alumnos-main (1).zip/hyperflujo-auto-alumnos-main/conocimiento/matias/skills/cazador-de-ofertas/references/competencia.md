# Etapa 2 — Competencia en el país de venta

Escribe todo en el idioma del usuario; solo los términos de búsqueda van en el idioma del país.

**Regla del usuario: la competencia nunca queda a medias.** Un país está terminado solo cuando cumple el checklist del paso 5 para cada oferta. Si algo no se pudo completar, no lo tapes con "es un mínimo": sigue los pasos de recuperación (paso 4) y, si aun así no se pudo, pregunta antes de publicar.

## 0. Antes de empezar

- **De a un país, máximo 3 por pedido.** Termina un país completo (todas las ofertas elegidas) antes de pasar al siguiente. Si el usuario pide más de 3 países, haz los 3 más prometedores (idioma local, poder adquisitivo, competencia conocida) y pregunta si sigue con el resto.
- **Avisa en un mensaje corto** cuántas búsquedas vas a hacer (2 por oferta y país, más los perfiles de los competidores fuertes) y pide al usuario que **deje visible la ventana de Claude** mientras escaneas: si queda detrás de otra, Meta deja de cargar anuncios.

## 1. Elegir los términos de búsqueda

Para cada oferta define 2–3 términos de 2–3 palabras **en el idioma del país destino**, como los buscaría un comprador (para un pack de ebooks de herbolaria en Colombia: "remedios naturales pdf", "herbolaria ebook", "plantas medicinales libro"). Que sean distintos entre sí: cada término encuentra anunciantes que el otro no ve. No dejes que la herramienta adivine el tema: el automático puede salir genérico ("recetas") y traer ruido.

**Los 2 primeros términos describen el producto exacto (tema + formato), no la categoría.** Para un pack de planos de trailers: "planos de trailers", "planos remolque pdf"; no "proyectos de herrería" ni "oficios". Un término de categoría solo puede ser el tercero, y lo que traiga va como mercado amplio, no como competencia directa (paso 3).

**Al menos una búsqueda obligatoria de nicho + formato digital (sin el nombre de la app o plataforma):** si la oferta nombra un software o plantilla específica (ej. "Notion para estudiantes de gastronomía", "Trello para arquitectos"), no busques solo con la marca de la herramienta ("notion gastronomia"): al menos uno de los términos debe buscar **el público/nicho + formato digital** en el idioma del país (ej. "studenti gastronomia pdf", "schede tecniche cucina pdf", "ricettario professionale ebook"). Así detectas quién le vende hoy ebooks, guías PDF o fichas descargables a ese mismo público aunque no use esa marca de software.

## 2. Mirar la base de Nexus Profit (contexto, no veredicto)

Llama a `radar_competencia` con el `id` de la oferta, `pais_destino` y `consulta` = tu mejor término. Da competidores, copias, días y `meta_search_url`. Si trae ruido, repite con otro término. Para varios países a la vez sirve `mapa_paises` (hasta 6 por llamada; los que faltan vuelven en `pendientes`).

La base solo tiene lo que guardó el scraper: **úsala como punto de partida, nunca como veredicto final** (tampoco uses `buscar_anuncios` como sustituto). Tenga 0 o 9 competidores, el paso 3 se hace igual. Si la respuesta trae `nota_acceso`, la base viene solo como conteo: los nombres salen de Meta (sin mencionarlo como un límite).

## 3. Buscar en la Biblioteca de Meta (siempre)

Para cada oferta, en el país:

0. **Si `radar_competencia` o `mapa_paises` trae `meta_reciente`** para ese país, ya hay una búsqueda completa en Meta de ese tema guardada hace 3 días o menos: úsala (anunciantes, copias y `destinos`) y no vuelvas a escanear ese término. Cuenta como búsqueda de Meta para el informe. Haz igual las búsquedas que falten con los otros términos.
1. Abre la búsqueda de Meta con tu navegador (tu primer término, el país y "Activos") y escanéala **completa** con el analizador (`llego_al_final: true`, cobertura de 80% o más). No dependes de ninguna extensión: la búsqueda la haces tú.
2. Repite con el **segundo término** (y un tercero si los dos primeros traen resultados muy distintos). Une los anunciantes de todas las búsquedas sin contarlos dos veces.
3. Quédate con los **competidores directos**: anunciantes con anuncios **activos hoy en Meta** que venden **el mismo tema en el mismo formato** (otro pack de planos de trailers, otro ebook del mismo tema). Mira los textos y el destino de cada anuncio si hace falta.
   - **No son competencia directa** los megapacks generales de la categoría (ej. "+5.000 planos de herrería"), los cursos, los servicios, los productos físicos ni los alquileres. Si son muchos, nómbralos aparte en la nota como "mercado amplio", pero no los cuentes en `competidores`.
   - **Los datos de cada competidor salen de Meta, hoy**: si sigue activo, cuántos anuncios tiene, desde cuándo y el precio que muestra. La base de Nexus Profit sirve para saber a quién buscar, pero un anunciante de la base que hoy no aparece activo en Meta **no cuenta**, y sus días o precio guardados no se publican.
   - El total "~N resultados" de una búsqueda es contexto: no es la cantidad de competidores.
4. Para los 2–3 competidores más fuertes, escanea **su perfil**: así sabes si está escalando (muchos anuncios nuevos) o probando. Si no hay competidores del mismo producto, no hace falta.
5. Guarda cada escaneo con `guardar_escaneo_meta` (búsquedas sin `anunciante`; perfiles con `anunciante` y `pagina_id`).

Si Meta pide login o captcha, detente y dilo. Si no tienes navegador, entrega los enlaces de búsqueda y explica qué debe contar el usuario: en ese caso el país queda "sin confirmar".

## 4. Si un escaneo queda parcial: recuperarlo, no aceptarlo

Cuando una búsqueda termina con `llego_al_final: false`, haz esto en orden y vuelve a mirar la cobertura después de cada paso:

1. **Ventana visible**: dile al usuario "Deja la ventana de Claude al frente y avísame con un 'listo'". Espera su respuesta y sigue con `nexusScan.collect()` (suma a lo ya leído).
2. **Scroll real**: baja con la acción de scroll del navegador (unas 10 ruedas), espera 2 segundos y `nexusScan.collect()`. Repite hasta que `sin_cambios_seguidas` llegue a 3.
3. **Recargar la página**: recarga la búsqueda, vuelve a cargar el analizador y repite `step()`. (Al recargar se empieza de cero: compara con lo leído antes y quédate con la lectura más completa.)
4. **Dividir la búsqueda**: si son muchos resultados, busca con un término más preciso o con comillas para que Meta devuelva menos anuncios, y escanea esas búsquedas completas.

Si después de los 4 pasos sigue parcial, esa búsqueda queda **"sin confirmar"**: guárdala igual (queda marcada como parcial) y anota cuánto se leyó.

## 5. Checklist para dar un país por terminado (por oferta)

- [ ] Base de Nexus Profit revisada (`radar_competencia`).
- [ ] 2 búsquedas en Meta con términos distintos, **completas**.
- [ ] Perfiles de los 2–3 competidores más fuertes escaneados (si los hay).
- [ ] Escaneos guardados con `guardar_escaneo_meta`.
- [ ] Veredicto del paso 6.

Muéstralo en el informe por oferta (ej. "Meta: 2/2 búsquedas completas · 2 perfiles revisados").

## 6. Dar un veredicto por país

Cuenta solo **competidores directos** (paso 3), con lo visto hoy en Meta:

- **🟦 Océano azul**: 0 competidores directos en las búsquedas completas. Oportunidad, pero sin demanda probada localmente.
- **🟢 Entrada viable**: 1–3 competidores directos, ninguno con 20 o más copias. Hay demanda y poca competencia.
- **🟡 Competido**: 4–7 competidores directos, o alguno con 20+ copias o con más de 30 días activo. Demanda probada; hay que diferenciarse en ángulo o precio.
- **🔴 Saturado**: 8 o más competidores directos, o 3 o más con 20+ copias. Solo con una propuesta claramente mejor.
- **⏳ Sin confirmar**: alguna búsqueda quedó parcial después del paso 4. No inventes el veredicto: di qué se vio y qué falta.

`competidores` es **exactamente** la cantidad de competidores directos que nombras en la nota, ni más ni menos. La nota sigue este orden: "Meta: 2/2 búsquedas completas · 'término 1' (~N resultados) · 'término 2' (~N) · Directos: Nombre (X anuncios, desde dd/mm), … · Mercado amplio: … · Descartados: Nombre (sin anuncios activos)".

## 7. Publicar

Antes de publicar, cierra las pestañas de Meta y de las landings que abriste para el análisis (y la ventana del navegador si la abriste solo para esto), sin tocar las del usuario.

**No publiques con países a medias.** Haz las búsquedas de cada país con tu navegador y guárdalas con `guardar_escaneo_meta` antes de publicar. Si después de los 4 pasos de recuperación alguno quedó "sin confirmar", pregunta con opciones: Reintentar ahora (con la ventana visible) · Publicar marcándolo como sin confirmar · No publicar todavía.

Al publicar (`publicar_informe`), cada país va en `paises` con `pais` (ISO), `veredicto` (`oceano_azul`, `entrada_viable`, `competido`, `saturado`, o `sin_confirmar` solo si falló la recuperación), `competidores` y una `nota` corta que diga cuántas búsquedas de Meta se completaron. El formato del informe está en `references/formatos.md`.
