# Respuestas del conector y formatos de informe

## Cómo leer las respuestas

`descubrir_ofertas` viene compacta para no gastar contexto:

- **`leyenda`** (una vez por respuesta): `checklist` con el texto de cada regla por su clave (`copias`, `dias`, `pocas_impresiones`, `modelable`, `sin_marca`, `concentracion`, `escalando`, `activa`, `confirmada_meta`), los `estados` posibles y qué es `inversion`.
- **`validacion`** de cada oferta: `puntaje`, `veredicto`, `seguridad`, `checklist` como `{regla: estado}` (`cumple`, `no_cumple`, `revisar` o `sin_dato`), `detalles` con la explicación de las reglas que no cumplen o que usan un dato de Meta, y `pendientes`.
- **`inversion`**: `"nivel índice/100"` (por ejemplo `"alto 59/100"`). Compara cuánto invierte cada anunciante con copias, creativos, ritmo, días y países: **nunca es un monto en dinero**.
- **`meta_en_vivo`**: resumen del último escaneo guardado (`hace_dias`, `completo`, `cobertura_porcentaje`, `anuncios_activos`, `copias_totales`, `nuevos_7d`, `concentracion_porcentaje`).
- Los campos vacíos no vienen: si falta `senales_marca`, no hay señales de marca; si falta `copias_en_meta`, no hay escaneo de ese producto; si falta `meta_en_vivo`, no hay escaneo del anunciante.
- `texto` viene recortado a 160 caracteres. Para el texto completo, `ver_anuncio`.

`validar_oferta` devuelve la versión completa de una oferta: `checklist` como lista (`clave`, `regla`, `estado`, `detalle`) e `inversion_estimada` con `indice` y `nivel`.

`mapa_paises` revisa hasta 6 países por llamada; si el tiempo no alcanza, los que faltan vuelven en `pendientes`.

## Formato del informe — Etapa 1

En el idioma del usuario:

```
# Ofertas con más potencial — [fecha]
Reglas: 20+ copias · 10+ días · sin pocas impresiones · ebook o app · sin marcas ni marcas personales
Revisadas: N ofertas → M validadas

| # | Oferta | Formato | País de origen | Copias | Días | Origen | Puntaje | Seguridad |
|---|---|---|---|---|---|---|---|---|

## 1. [Nombre corto de la oferta] — 🟢 Alta · 92/100 · validada
- **Checklist:** ✅ 20+ copias (60) · ✅ 10+ días (25) · ✅ ebook o app · ✅ sin marca personal · ✅ concentración 85% · ✅ escalando · ✅ confirmada en Meta
- **Pendiente:** lo que diga `pendientes` (o "nada").
- **Qué vende:** una frase concreta (tema + ángulo + promesa).
- **Cómo modelarlo:** ebook / app, y el ángulo a copiar o mejorar.
- **Anunciante:** nombre · concentración X% en este producto
- **Ver en Meta:** [perfil del anunciante](perfil_meta) · [anuncio](biblioteca_meta)
- **Evidencia:** N copias en M creativos · D días activo · visto por última vez [fecha] · origen: global / tu favorito / tu bóveda · confirmado en Meta: sí / no / pendiente
- **Landing:** plataforma · precio · [enlace]
- **Por qué tiene potencial:** 1–2 frases.

## Descartadas
- [anunciante]: motivo en una frase.

## Ten en cuenta
Datos de la base de Nexus Profit al [fecha]; qué se verificó en Meta y qué quedó pendiente.

¿En qué país quieres vender estas ofertas? …
```

Checklist con ✅ cumple · ❌ no_cumple · ⚠️ revisar · ❔ sin_dato. En cuentas que trabajan con su bóveda, la columna "Origen" dice siempre "tu bóveda" (o quítala).

En modo radar temprano usa **🌱 Temprana** en vez del nivel de seguridad y agrega las columnas **Copias/día** y **Creativos nuevos (7 d)**.

## Formato del informe — Etapa 2

```
# Competencia en [país] — [fecha]

| # | Oferta | Término buscado | Anunciantes | Copias | Fuente | Veredicto |
|---|---|---|---|---|---|---|

## 1. [Oferta] en 🇦🇷 Argentina — 🟢 Entrada viable
- **Origen:** vende en 🇧🇷 Brasil con N copias.
- **Base de Nexus Profit:** "[término]" → X competidores (contexto).
- **Meta:** "[término 1]" ~N resultados (completa) · "[término 2]" ~N resultados (completa) → Y anunciantes venden lo mismo · perfiles revisados: Z.
- **Checklist:** ✅ base · ✅ 2/2 búsquedas completas en Meta · ✅ perfiles de los competidores fuertes (o ⏳ qué faltó y por qué).
- **Competidores principales:** [nombre](perfil_meta) · A anuncios activos de este producto en su perfil · copias · activo desde [fecha] · escalando / probando, …
- **Recomendación:** cómo entrar (ángulo, precio, formato) en 1–2 frases.
```
