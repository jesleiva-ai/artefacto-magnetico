# Modo perfiles por descubrir

El scraper guarda el anuncio que encontró, no el perfil entero: un anuncio con 1–2 copias en la base puede venir de un perfil con 200 anuncios. Nadie más lo ve en una galería, así que es donde está la ventaja.

1. Llama a `perfiles_por_descubrir` (por defecto: detectados en 7 días, hasta 4 copias, modelables, sin escaneo en 14 días; uno por anunciante).
2. **Lo que importa es el anunciante.** Abre el `perfil_meta` de cada uno y lee primero el total del encabezado ("~N resultados"), sin bajar. Si tiene menos de 20, anótalo y pasa al siguiente. Si tiene 20 o más, escanéalo completo: cada perfil trae `perfil_anunciante` con sus anuncios en Meta, activos reales y pocas impresiones (si ya se escaneó antes, ahí está el dato). **Si `perfil_meta` es una búsqueda por nombre** (no lleva `view_all_page_id`; en perfiles por descubrir viene `perfil_por_nombre: true`), esa búsqueda trae anuncios de otros anunciantes y **no es su perfil**: abre `biblioteca_meta` (el anuncio), entra a la página del anunciante desde el anuncio y escanea esa página (su URL lleva `view_all_page_id`). Nunca guardes una búsqueda por palabra como perfil: `guardar_escaneo_meta` lo avisa y no la cuenta.
3. Escanea en tanda el `perfil_meta` de los que pasaron con el analizador (sección "Escanear la Biblioteca de Meta" de SKILL.md; máximo 10 perfiles por sesión, salvo que el usuario pida más) y guarda cada escaneo con `guardar_escaneo_meta`, con `anunciante` y `pagina_id` si lo ves. Si `perfil_por_nombre` es true, confirma que la página sea la misma.
4. Llama a `validar_oferta` para cada uno: el escaneo cuenta para las copias y los días (`copias_en_meta`), así que los perfiles grandes pasan a `validada` o `temprana` y aparecen solos en `descubrir_ofertas`.
5. Informa en una tabla: anunciante · anuncios en Meta · activos reales · pocas impresiones · copias en la base → copias en Meta · anuncios nuevos en 7 días · veredicto. Destaca los que eran "chicos" en la base y resultaron grandes.

Al publicar el informe usa `tipo: perfiles`.
