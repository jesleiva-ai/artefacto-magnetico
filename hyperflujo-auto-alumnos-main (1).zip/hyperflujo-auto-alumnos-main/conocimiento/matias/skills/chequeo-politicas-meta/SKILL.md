---
name: "chequeo-politicas-meta"
description: "Revisa anuncios (guiones, placas, carruseles, textos) y páginas de destino de productos digitales antes de subirlos a Meta, buscando lo que suele causar rechazos, restricciones o bloqueos de cuenta, y propone cómo arreglarlo sin perder el gancho. Usar cuando se pida 'revisá si Meta lo aprueba', 'chequeo de políticas', 'me rechazaron un anuncio', o antes de largar una Cash Trap."
model: sonnet
effort: medium
---

# Chequeo de políticas de Meta

Es un control preventivo según las políticas publicitarias de Meta tal como se conocen; **no garantiza la aprobación** (la decide Meta y sus reglas cambian). Si hay dudas sobre una regla puntual, sugerir revisar la política oficial vigente.

## Qué revisar (riesgo ALTO / MEDIO / BAJO + arreglo)

**Atributos personales del que mira** — ALTO
- Afirmar o insinuar algo sobre la persona que ve el anuncio: salud física o mental, peso, cuerpo, situación financiera, religión, orientación, edad, antecedentes.
- ❌ "¿Te da vergüenza tu cuerpo?" / "¿Estás endeudado?" → ✅ hablar del narrador o de una situación general ("Empecé la dieta 47 veces...").

**Contenido sexual o sugerente** — ALTO
- Desnudos, ropa interior, poses sugerentes, foco en partes del cuerpo. Aunque sea para un chiste (ej.: el gancho de infidelidad del anuncio de cámaras).

**Promesas de resultados** — ALTO
- Ganancias garantizadas, "ganá $X por mes", resultados de salud o peso garantizados, curas.
- Espiritualidad/esoterismo: se puede vender el producto, no prometer que el ritual "funciona" (amor, dinero, salud garantizados).
- Antes y después de cuerpos en productos de peso o salud.

**Engaño** — ALTO
- Noticias falsas que parecen reales, logos de medios, celebridades sin permiso, testimonios inventados, escasez falsa ("últimos cupos" que no es real), botones o notificaciones falsas que simulan la interfaz (play falso, "tenés 1 mensaje").
- Una "noticia de último momento" en tono de humor tiene que verse claramente como humor.

**Contenido impactante o violento** — MEDIO
- Imágenes de violencia, accidentes o sangre muy explícitos. Una casa en llamas o un ladrón escapando suele pasar; heridas o sangre, no.

**Derechos de terceros** — MEDIO
- Logos de canales de TV, marcas, música con derechos, clips con marcas de agua o textos de otros anuncios.

**Coherencia con la página** — MEDIO
- El anuncio y la landing tienen que hablar del mismo producto y precio. Página que no carga, rota o distinta a lo anunciado.

**Lenguaje** — BAJO
- Insultos fuertes, mayúsculas y signos de exclamación excesivos, "clic acá" engañoso.

**Categorías especiales** — revisar
- Salud, finanzas/inversiones, apuestas, empleo: pueden requerir declaraciones o estar restringidas.

## Entrega

Tabla: elemento (frase/imagen) · riesgo · por qué · arreglo propuesto que mantiene el gancho. Al final: veredicto "subir / subir con cambios / no subir".

## Reglas

- Proponer siempre un arreglo que conserve el humor o la polémica del gancho; no matar el anuncio.
- No decir "está aprobado": decir "riesgo bajo".
