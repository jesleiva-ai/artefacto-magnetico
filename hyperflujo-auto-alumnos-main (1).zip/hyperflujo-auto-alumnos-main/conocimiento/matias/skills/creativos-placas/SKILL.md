---
name: "creativos-placas"
description: "Crea las placas (anuncios de imagen estática) de un producto digital del usuario: elige los formatos por nivel de conciencia (C1/C2/C3) de su catálogo de 48 placas, escribe el texto de cada una, genera las imágenes que hagan falta (mockup del producto, hero, caja de bonos, escena) con Higgsfield cotizando antes de gastar, y compone la placa final con el texto bien escrito. Usar cuando se pida 'haceme placas', 'creativos de imagen', 'mockup', 'foto del producto', 'caja de bonus', 'los 9 anuncios en placa' o anuncios estáticos para una campaña."
---

# Creativos: placas

Fuentes (leer antes de crear):
- Producto: `D:\segundo-cerebro\03_PRODUCTOS\` (ficha del producto: qué incluye, precio, bonos, garantía, escalera).
- Formatos: `D:\segundo-cerebro\05_PROCESOS\TIPOS_DE_PLACAS.md` (48 formatos por nivel, reglas generales de placa).
- Estrategia: `D:\segundo-cerebro\05_PROCESOS\ESTRATEGIA_DE_ANUNCIOS.md` (9 anuncios: 3 C1, 3 C2, 3 C3).
- Estilo propio: `D:\segundo-cerebro\08_REFERENCIAS\NOTAS.md`.
- Si se piden también videos: `anuncio-storytime-controversial`, `ugc-video-hiperrealista`, `reel-clips`.

## Pasos

1. **Datos mínimos:** producto, idioma/mercado, cuántas placas (por defecto 9: 3 C1, 3 C2, 3 C3) y si hay fotos o mockups reales del producto (usarlos antes que generar).
2. **Elegir formatos:** 3 distintos por nivel desde `TIPOS_DE_PLACAS.md`, sin repetir ángulo. Mostrar la lista "C1: meme / antes-después / opinión polémica..." con el texto propuesto de cada placa (título ≤ 12 palabras, subtítulo, precio/botón si es C3) y **esperar el OK**.
3. **Imágenes necesarias:** decidir cuáles se generan y cuáles salen de material real:
   - **Mockup del producto** (libro, PDF en tablet/celular, pack, caja de bonos), **hero** (la persona del avatar usando el producto), **escena** del nicho, **fondo** para texto.
   - Generar **sin texto** dentro de la imagen (el texto lo pone el paso 5, para que no salga con errores de ortografía).
4. **Cotizar antes de gastar (Higgsfield):**
   - Pedir el costo con `generate_image` y `get_cost: true` (modelo `marketing_studio_image` para producto/anuncio; `gpt_image_2_5` para lo general) y mirar el saldo (`balance`).
   - Decir: "Son N imágenes, aprox. X créditos. ¿Confirmás?" y **no generar sin el sí**. No usar generaciones gratuitas/ilimitadas salvo que la persona lo pida.
   - Formatos: 4:5 para feed y 9:16 para historias (con ubicaciones Advantage+ conviene hacer las dos).
5. **Componer la placa** con texto real usando el script de esta skill:
   ```
   python -I "<carpeta de la skill>\scripts\componer_placa.py" --salida C1-meme-01_4x5.png --fondo imagen.png --tamano 1080x1350 --titulo "..." --subtitulo "..." [--tachado "..." --precio "..." --boton "..."]
   ```
   - Para 9:16 repetir con `--tamano 1080x1920`.
   - Formatos especiales (meme, tweet, nota del celular, ticket, mito vs realidad, antes/después partido) se pueden armar con Pillow o generar como imagen completa y revisar la ortografía letra por letra.
6. **Revisar cada placa:** mirarla (abrir la imagen), comprobar ortografía, precio = ficha, que se lea en 1 segundo, y pasar la skill `chequeo-politicas-meta`.
7. **Guardar:**
   - Las imágenes van **fuera del segundo cerebro** (pesan): `D:\creativos\[producto]\AAAA-MM-DD\`, con nombres `C1-meme-01_4x5.png`, `C3-oferta-01_9x16.png`.
   - En el cerebro, anotar cada placa en `04_CONTENIDOS\ANUNCIOS.md` (formato, nivel, gancho, ruta).
8. **Cargar en Meta:** solo si la persona lo pide, **siempre en pausa**, nombradas C1/C2/C3, y nunca prender ni tocar presupuesto sin su orden.

## Reglas

- Todo lo que dice la placa es real: precio, descuento, garantía, bonos, testimonios, resultados. Si un "50% OFF" no es real, no va.
- Personas generadas con IA: no presentarlas como clientes reales ni poner testimonios en su boca.
- Sin caras de chicos reconocibles, sin logos o marcas ajenas, sin imágenes sexuales.
- Nada que cueste créditos o plata sin cotizar y sin el sí de la persona.
