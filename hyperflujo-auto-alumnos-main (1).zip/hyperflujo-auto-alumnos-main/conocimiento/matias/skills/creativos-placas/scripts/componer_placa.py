"""Compone una placa de anuncio: imagen de fondo (o color) + textos con borde + precio + botón.

Uso:
  python -I componer_placa.py --salida placa.png [--fondo imagen.png | --color "#1b1b1b"]
      [--tamano 1080x1350] [--titulo "..."] [--subtitulo "..."] [--precio "..."]
      [--tachado "..."] [--boton "..."] [--color_texto "#ffffff"] [--color_acento "#ffd400"]
      [--fuente C:\\Windows\\Fonts\\impact.ttf] [--fuente_texto C:\\Windows\\Fonts\\arialbd.ttf]

El título va arriba, el subtítulo debajo, el precio y el botón abajo. Todo centrado.
"""
import argparse
import textwrap

from PIL import Image, ImageDraw, ImageFont, ImageOps


def cargar_fondo(args, w, h):
    if args.fondo:
        img = Image.open(args.fondo).convert("RGB")
        return ImageOps.fit(img, (w, h), Image.LANCZOS)
    return Image.new("RGB", (w, h), args.color)


def texto_centrado(draw, lineas, fuente, y, w, color, borde, ancho_borde):
    for linea in lineas:
        caja = draw.textbbox((0, 0), linea, font=fuente, stroke_width=ancho_borde)
        tw, th = caja[2] - caja[0], caja[3] - caja[1]
        draw.text(((w - tw) / 2, y), linea, font=fuente, fill=color,
                  stroke_width=ancho_borde, stroke_fill=borde)
        y += th + int(fuente.size * 0.25)
    return y


def ajustar(texto, fuente, ancho_max, draw):
    for chars in range(40, 8, -1):
        lineas = textwrap.wrap(texto, chars)
        if all(draw.textlength(l, font=fuente) <= ancho_max for l in lineas):
            return lineas
    return textwrap.wrap(texto, 8)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--salida", required=True)
    p.add_argument("--fondo")
    p.add_argument("--color", default="#1b1b1b")
    p.add_argument("--tamano", default="1080x1350")
    p.add_argument("--titulo", default="")
    p.add_argument("--subtitulo", default="")
    p.add_argument("--precio", default="")
    p.add_argument("--tachado", default="")
    p.add_argument("--boton", default="")
    p.add_argument("--color_texto", default="#ffffff")
    p.add_argument("--color_acento", default="#ffd400")
    p.add_argument("--fuente", default=r"C:\Windows\Fonts\impact.ttf")
    p.add_argument("--fuente_texto", default=r"C:\Windows\Fonts\arialbd.ttf")
    a = p.parse_args()

    w, h = (int(x) for x in a.tamano.lower().split("x"))
    img = cargar_fondo(a, w, h)
    d = ImageDraw.Draw(img)
    margen = int(w * 0.07)
    ancho = w - 2 * margen

    y = int(h * 0.06)
    if a.titulo:
        f = ImageFont.truetype(a.fuente, int(w * 0.095))
        y = texto_centrado(d, ajustar(a.titulo.upper(), f, ancho, d), f, y, w,
                           a.color_texto, "#000000", max(3, int(w * 0.006)))
    if a.subtitulo:
        f = ImageFont.truetype(a.fuente_texto, int(w * 0.045))
        texto_centrado(d, ajustar(a.subtitulo, f, ancho, d), f, y + int(h * 0.015), w,
                       a.color_acento, "#000000", max(2, int(w * 0.004)))

    yb = h - int(h * 0.06)
    if a.boton:
        f = ImageFont.truetype(a.fuente_texto, int(w * 0.05))
        tw = d.textlength(a.boton, font=f)
        bh = int(f.size * 1.9)
        bw = int(tw + f.size * 2)
        x0, y0 = (w - bw) // 2, yb - bh
        d.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], radius=bh // 2, fill=a.color_acento)
        d.text((w / 2, y0 + bh / 2), a.boton, font=f, fill="#000000", anchor="mm")
        yb = y0 - int(h * 0.025)
    if a.precio:
        f = ImageFont.truetype(a.fuente, int(w * 0.13))
        caja = d.textbbox((0, 0), a.precio, font=f)
        ph = caja[3] - caja[1]
        d.text((w / 2, yb - ph / 2), a.precio, font=f, fill=a.color_acento, anchor="mm",
               stroke_width=max(3, int(w * 0.006)), stroke_fill="#000000")
        yb -= ph + int(h * 0.02)
    if a.tachado:
        f = ImageFont.truetype(a.fuente_texto, int(w * 0.05))
        tw = d.textlength(a.tachado, font=f)
        d.text((w / 2, yb), a.tachado, font=f, fill=a.color_texto, anchor="mm",
               stroke_width=2, stroke_fill="#000000")
        d.line([(w / 2 - tw / 2, yb), (w / 2 + tw / 2, yb)], fill="#ff3b30", width=max(3, int(w * 0.005)))

    img.save(a.salida)
    print("ok", a.salida, img.size)


if __name__ == "__main__":
    main()
