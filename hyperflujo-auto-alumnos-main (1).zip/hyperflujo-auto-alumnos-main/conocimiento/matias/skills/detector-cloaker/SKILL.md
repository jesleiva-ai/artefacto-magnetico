---
name: "detector-cloaker"
description: "Revisa si la landing de una oferta de la competencia usa cloaker: si le muestra una página 'segura' a quien la revisa (Meta, espías) y otra distinta al comprador que llega desde el anuncio. Sirve para saber cuál es la oferta real antes de modelarla. Solo lectura; no usa ni arma cloaking. Usar cuando se pida 'tiene cloaker?', 'revisá si esta página es la real', 'detector de cloaker', o al estudiar una oferta con la Biblioteca de anuncios."
model: sonnet
effort: medium
---

# Detector de cloaker

**Para qué:** al modelar, la página que se ve desde la Biblioteca de anuncios puede ser una "página segura" y no la oferta real. Esta skill lo detecta.

**Límite:** es solo para **detectar** en ofertas ajenas. el usuario **no usa cloaking** (Meta lo castiga con bloqueo de cuentas). Nunca armar, configurar ni recomendar un cloaker.

## Pasos

1. Tomar el **link del anuncio** (desde la Biblioteca de anuncios: botón del anuncio / URL de destino, con sus parámetros).
2. Pedir la página de varias formas y anotar, para cada una: **URL final** después de redirecciones, **título**, **tamaño** del HTML, **hay o no hay precio/checkout**, primeras líneas de texto:
   - a) Navegador normal (pestaña del navegador integrado).
   - b) Pedido simple sin navegador (PowerShell `Invoke-WebRequest` o `curl`) con agente de usuario de navegador de celular.
   - c) Mismo pedido con agente de usuario del revisor de Meta (`facebookexternalhit/1.1`).
   - d) La URL **sin** los parámetros del anuncio (`fbclid`, `utm_*`, etc.) y **con** ellos.
3. **Señales de cloaker:**
   - Las versiones muestran **páginas distintas** (otro título, otro producto, una página sin precio ni botón de compra, un blog genérico, "página en construcción").
   - **Redirecciones** a otro dominio solo en algunas versiones, o por JavaScript al cargar.
   - Dominios intermedios conocidos de cloakers o de rastreo antes de la página final.
   - Una versión liviana sin checkout vs. otra con oferta completa.
4. **Veredicto:** "sin señales de cloaker" / "posible cloaker" / "cloaker probable", con la evidencia de cada versión.
5. Si hay cloaker, la **página real** es la que ve el comprador (la del navegador normal con los parámetros del anuncio). Esa es la que se usa para `desarme-landing` y `quien-cobra`.

## Entrega

Tabla: versión · URL final · título · ¿precio/checkout? · diferencias. Veredicto y qué página usar para modelar. Guardar junto a la oferta en `D:\segundo-cerebro\06_PROYECTOS\ofertas\`.

## Reglas

- Solo lectura: no completar formularios ni checkouts, no cargar datos.
- No probar desde VPN ni técnicas para engañar al sitio; solo los pedidos de arriba.
- Un resultado negativo no garantiza que no haya cloaker (algunos filtran por país o IP): decirlo.
