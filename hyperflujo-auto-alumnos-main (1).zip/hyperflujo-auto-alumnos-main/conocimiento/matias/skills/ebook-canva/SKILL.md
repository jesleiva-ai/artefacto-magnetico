---
name: ebook-canva
description: Genera ebooks infoproducto profesionales en formato Word (.docx) con TODO el copy y diseño editorial ya escrito, pero SIN generar imágenes por IA — deja un espacio en blanco marcado cada dos páginas para que el usuario agregue sus propias imágenes en Canva. Usar cuando el usuario pida crear un ebook, infoproducto digital, manual o guía y aclare que NO quiere usar Higgsfield / IA para las imágenes, que las va a poner él mismo en Canva, o que quiere el ebook "solo con el texto", "para editar en Canva", "sin imágenes generadas", o cualquier variante. También usar si el usuario pide "el mismo flujo del otro ebook pero sin Higgsfield". Es la versión gemela de la skill ebook-higgsfield, pensada para cuando el usuario prefiere diseñar visualmente él mismo.
---

# Skill: Generador de Ebooks para Canva (sin IA de imágenes)

## Qué hace esta skill

Genera ebooks infoproducto completos de calidad editorial, igual que `ebook-higgsfield`, pero en lugar de generar imágenes con IA, Claude escribe TODO el copy y arma el documento en Word (.docx) con diseño de texto (títulos, columnas, bullets, badges de texto) y deja un **recuadro placeholder marcado** cada dos páginas para que el usuario complete con sus propias imágenes directamente en Canva (o pegando el recuadro dentro de un template de Canva).

**Resultado:** un .docx listo para abrir, revisar el copy, y llevar a Canva a maquetar con imágenes propias.

---

## Cuándo usar esta skill vs. ebook-higgsfield

- Usar **ebook-canva** (esta skill) cuando el usuario diga que no quiere depender de Higgsfield, que va a poner las imágenes él mismo, o que quiere diseñar en Canva.
- Usar **ebook-higgsfield** cuando el usuario quiera el ebook 100% automatizado con imágenes generadas por IA.
- Si hay duda, preguntar directamente: "¿Querés que genere las imágenes con IA (Higgsfield) o preferís dejar el espacio para que las agregues vos en Canva?"

---

## FLUJO COMPLETO

```
PASO 1 → Claude hace las 7 preguntas de relevamiento
PASO 2 → Claude define la estructura del ebook
PASO 3 → Claude escribe TODO el copy de cada página
PASO 4 → Claude arma el .docx con diseño editorial de texto
         + recuadro placeholder de imagen cada 2 páginas
PASO 5 → Claude entrega el .docx con present_files ✅
```

**Nota:** No hay paso manual de descarga/subida de imágenes — todo el documento se genera de una. El único trabajo del usuario después es abrir el .docx (o pasarlo a Canva) y completar los recuadros marcados con sus propias fotos/gráficos.

---

## PASO 1 — Relevamiento del nicho (SIEMPRE PRIMERO)

Obtener estas 7 variables. Si ya están en la conversación (por ejemplo porque el usuario ya las dio para otro ebook), extraerlas sin volver a preguntar:

1. **NICHO** — ¿De qué trata el ebook?
2. **AVATAR** — ¿A quién le vendés?
3. **PROMESA** — ¿Qué resultado concreto obtiene quien compra?
4. **PRODUCTO** — ¿Cuántos capítulos/recetas/técnicas tiene?
5. **PRECIO** — ¿Cuánto va a valer?
6. **PALETA** — ¿Colores de la marca? (si no tiene, sugerir según nicho, ver tabla abajo)
7. **NOMBRE** — ¿Cómo se llama el ebook y la marca?

Si el usuario sube un PDF o ebook de referencia, analizar su estructura de contenido (no el diseño visual, ya que acá no generamos imágenes) y replicarla.

---

## PASO 2 — Definir estructura del ebook

Arquitectura base (adaptar según nicho). A diferencia de ebook-higgsfield, acá cada "página" es un bloque de texto en el Word, y cada 2 páginas se inserta un placeholder de imagen:

```
PÁGINA 1   → Portada (título, subtítulo, promesa) + placeholder de imagen hero
PÁGINA 2   → Bienvenida / presentación emocional
PÁGINA 3   → Contenido 1 (con ingredientes/pasos/desarrollo) + placeholder de imagen
PÁGINA 4   → Contenido 2
PÁGINA 5   → Contenido 3 + placeholder de imagen
PÁGINA 6   → Tips esenciales (lista numerada)
PÁGINA 7   → Cierre + CTA + placeholder de imagen final
```

Mínimo 7 páginas, máximo 20. La regla de oro: **un placeholder de imagen cada 2 páginas** (páginas impares, o donde el contenido lo pida más — por ejemplo la portada siempre lleva uno).

---

## PASO 3 — Escribir el copy de cada página

Escribir el texto completo y pulido de cada página, con el mismo nivel de detalle y persuasión que llevaría una página diseñada:

- **Portada:** título grande + subtítulo con la promesa + 2-3 badges de beneficio en texto (ej. "✓ Sin TACC · ✓ Fácil · ✓ Listo en 1 día")
- **Bienvenida:** copy emocional corto (80-120 palabras) conectando con el dolor/deseo del avatar
- **Páginas de contenido:** título del capítulo/receta + cuerpo desarrollado (ingredientes en lista + pasos numerados, o desarrollo del tema según nicho)
- **Tips:** lista numerada de 5-8 tips con título bold + 1 línea de descripción cada uno
- **Cierre:** CTA claro, redes, precio si aplica, copyright

Todo en español, tono acorde al nicho (cálido para cocina/bienestar, directo para finanzas/negocios, etc.)

---

## PASO 4 — Armar el .docx

Usar la skill `docx` (docx-js / npm `docx`) para generar el Word. Estructura de cada página del ebook:

1. Un `PageBreak` antes de cada página nueva (excepto la primera)
2. Los elementos de texto de esa página (títulos con `HeadingLevel`, párrafos, listas con `numbering`)
3. Si esa página lleva placeholder de imagen: un recuadro visual usando una **tabla de 1 celda con borde punteado** (no usar tabla como línea, pero sí como marco — es el uso correcto acá) que contenga:
   - Texto centrado en gris: `📷 ESPACIO PARA IMAGEN`
   - Debajo, en itálica y más chico: una sugerencia concreta de qué imagen buscar/tomar/diseñar en Canva (ej. "Sugerencia: foto del plato terminado, luz natural, fondo claro")
   - Alto sugerido de la celda: suficiente para simular el espacio real de una imagen (~3000-4000 DXA de alto aprox., ajustar según layout de la página)

**Paleta de texto:** aunque no hay imágenes, usar el color de acento de la marca en los títulos (`color` en `TextRun`) para que el documento ya se sienta on-brand y sea más fácil de trasladar a Canva.

**Gotchas del docx-js a respetar** (ver skill `docx` completa si hace falta):
- `PageBreak` debe ir dentro de un `Paragraph`
- Nunca usar `\n`, párrafos separados
- Listas con `numbering` config, no bullets literales
- Shading de tablas con `ShadingType.CLEAR`, nunca `SOLID`
- Después de generar, renderizar a PDF/imagen con `soffice.py` y mirar el resultado antes de entregar

Nombre de archivo sugerido: `[nombre_ebook]_para_canva.docx`

---

## PASO 5 — Entregar

Copiar el .docx a `/mnt/user-data/outputs/` y entregar con `present_files`. Decirle al usuario:

> "✅ Tu ebook está listo con todo el copy armado. Dejé un espacio marcado (📷 ESPACIO PARA IMAGEN) cada dos páginas con una sugerencia de qué imagen poner ahí — lo podés abrir directo en Canva o en Word para completar con tus fotos."

No hay paso de espera ni de subida de imágenes por parte del usuario en el chat — el documento ya sale completo y lo único que falta es que el usuario le agregue las imágenes por su cuenta.

---

## Paletas sugeridas por nicho

| Nicho | Fondo (referencia) | Acento (para títulos en el Word) | Texto |
|---|---|---|---|
| Cocina/Recetas | #FFF8F0 cálido | #C0533A terracota | #3D1F0D marrón |
| Fitness/Salud | #FFFFFF blanco | #7CB518 verde lima | #1A1A2E gris |
| Crochet/Manualidades | #FDF6EC crema | #E8A598 rosa palo | #5C3D2E marrón |
| Finanzas/Negocios | #0A1628 azul | #C9A84C dorado | #FFFFFF blanco |
| Edición de Video | #0D0D0D negro | #00D4FF cian | #FFFFFF blanco |
| Bienestar/Holístico | #E8F0E9 salvia | #C8A951 dorado | #2D4A22 verde |
| Belleza/Estética | #FDF0F0 rosa | #D4AF7A dorado | #2C2C2C gris |

(El fondo no se usa directamente en el Word ya que no hay diseño de página con color completo, pero sirve de referencia para que el usuario mantenga la paleta al maquetar en Canva.)

---

## Notas importantes

- Copy siempre en español, tono acorde al nicho
- El foco de esta skill es el TEXTO — no generar ni buscar imágenes de ningún tipo
- El placeholder de imagen SIEMPRE debe incluir una sugerencia concreta de qué imagen usar ahí, no dejarlo vacío
- Respetar la cadencia de un placeholder cada 2 páginas como regla general, pero la portada y el cierre casi siempre llevan uno también
- Verificar el .docx renderizándolo a PDF antes de entregar (ver PASO 4)
- Entregar siempre con `present_files`
- Si el usuario después pide migrar este mismo ebook a Higgsfield, usar la skill `ebook-higgsfield` reutilizando las 7 variables ya relevadas
