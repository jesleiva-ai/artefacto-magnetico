---
name: "ebook-editorial-docx"
description: "Genera ebooks/infoproductos completos escribiendo TODO el copy editorial en un .docx con diseño profesional (docx-js) e insertando fotos fotorrealistas generadas con Higgsfield (una por receta/ítem + portada), en vez de crear cada página como una imagen completa. Usar como método PREFERIDO en vez de ebook-higgsfield para cualquier ebook/infoproducto con imágenes IA — es más rápido, más barato en créditos, evita errores de tipografía de la IA, y el copy queda 100% editable."
---

# Skill: Ebook Editorial (.docx + fotos Higgsfield)

## Qué hace esta skill

Genera ebooks infoproducto completos de calidad editorial, igual que `ebook-higgsfield`, pero con un flujo mucho más eficaz: en vez de generarle a la IA CADA PÁGINA como una imagen completa (con el texto ya "horneado" dentro de la imagen), Claude **escribe todo el copy directamente en Word** (títulos, ingredientes, pasos, tips, tablas, bullets — con `docx-js`) y usa Higgsfield **solo para las fotos** (una foto realista por receta/ítem + la portada), que se insertan como imágenes dentro del documento.

**Resultado:** un .docx (convertible a PDF) de nivel editorial, con fotos de calidad y texto 100% nítido y editable — sin los typos ni errores tipográficos que la IA comete cuando tiene que dibujar texto dentro de una imagen.

**Por qué este método reemplaza a `ebook-higgsfield`:** generar cada página completa como imagen (texto + diseño + foto todo junto) es lento, gasta muchos más créditos, y el texto generado por la IA casi siempre tiene errores de ortografía/tipografía difíciles de corregir sin regenerar toda la página. Escribiendo el copy en Word y generando solo las fotos se resuelven los tres problemas: es más rápido, más barato, y el texto siempre es perfecto porque lo escribe Claude, no un modelo de imágenes.

**Cuándo usar `ebook-canva` en cambio:** si el usuario aclara que no quiere ninguna imagen generada por IA (va a poner sus propias fotos en Canva), usar `ebook-canva` en vez de esta skill.

---

## FLUJO COMPLETO

```
PASO 1 → Claude hace las 7 preguntas de relevamiento
PASO 2 → Claude define la estructura del ebook (capítulos/secciones + items)
PASO 3 → Claude escribe TODO el copy de cada item en un archivo de contenido (.js)
PASO 4 → Claude genera las fotos en Higgsfield (batch): 1 portada + 1 foto por item
PASO 5 → Descarga + optimiza las imágenes (sharp)
PASO 6 → Arma el .docx con docx-js: diseño editorial completo + fotos insertadas
PASO 7 → Renderiza a PDF y revisa visualmente antes de entregar
PASO 8 → Entrega el .docx (y/o PDF) con SendUserFile ✅
```

Todo pasa en el workspace de Claude — no hay paso manual de descarga/subida de imágenes por parte del usuario, a diferencia de `ebook-higgsfield` clásico.

---

## PASO 1 — Relevamiento del nicho (SIEMPRE PRIMERO)

Obtener estas 7 variables. Si ya están en la conversación (por ejemplo porque el usuario ya las dio para otro ebook o hay un avatar/marca ya definida), extraerlas sin volver a preguntar:

1. **NICHO** — ¿De qué trata el ebook?
2. **AVATAR** — ¿A quién le vendés? ¿Hay un avatar/personaje de marca ya creado (ej. un chef) que deba aparecer en la portada?
3. **PROMESA** — ¿Qué resultado concreto obtiene quien compra?
4. **PRODUCTO** — ¿Cuántos capítulos/recetas/ítems tiene? ¿Se divide en varios libros/tomos?
5. **PRECIO** — ¿Cuánto va a valer?
6. **PALETA** — ¿Colores de marca? (si no tiene, sugerir según nicho, ver tabla abajo)
7. **NOMBRE** — ¿Cómo se llama el ebook y la marca?

Si el usuario sube un PDF o ebook de referencia, analizar su estructura de contenido y replicarla.

---

## PASO 2 — Definir estructura

Arquitectura base (adaptar según nicho — esto es el patrón usado en CrispCraft, 500 recetas air fryer divididas en 5 libros de ~80-125 recetas cada uno, más 3 guías bonus):

```
Portada (título + imagen hero de marca)
Página de bienvenida (copy emocional del avatar/autor)
Por cada capítulo:
  → Página de intro del capítulo (título + bajada)
  → Por cada item (receta/técnica/lección):
      - Título + blurb corto
      - FOTO del item (una por item)
      - Tabla de datos rápidos (prep/cook/servings o equivalente del nicho)
      - Lista de ingredientes/materiales (bullets)
      - Instrucciones/pasos (lista numerada)
      - Tip destacado (callout con fondo de color)
Página de cierre (agradecimiento + CTA + copyright)
```

Si el producto es grande, dividirlo en varios documentos/libros (como CrispCraft: 5 libros principales + bonus guides), cada uno con su propia portada e imagen de portada.

---

## PASO 3 — Escribir el copy completo (archivo de contenido)

Crear un archivo `<nombre>_content.js` que exporte la estructura de datos completa, SIN placeholders — todo el copy ya definitivo:

```js
// Ejemplo real usado en CrispCraft (ebook1_recipes.js)
const chapters = [
  {
    title: "Egg-Based Breakfasts",
    intro: "Protein-packed and ready before your coffee finishes brewing...",
    recipes: [
      {
        title: "Spinach & Feta Egg Muffins",
        blurb: "Fluffy egg cups loaded with wilted spinach and salty feta.",
        prep: "10 min", cook: "12 min", servings: "4",
        ingredients: ["6 large eggs", "1 cup fresh spinach, chopped", "..."],
        steps: ["Whisk eggs...", "Stir in spinach...", "..."],
        tip: "Swap spinach for kale or arugula — any leafy green works.",
        imgPrompt: "overhead photo of fluffy baked egg muffins with spinach and feta, on a white plate, rustic wooden table, natural light, appetizing food photography"
      },
      // ...
    ]
  }
];
module.exports = { chapters };
```

Cada item lleva su propio `imgPrompt` en inglés (los prompts de Higgsfield siempre van en inglés, el copy visible va en el idioma del producto). El `imgPrompt` describe SOLO la foto (comida/producto/escena realista), nunca texto ni diseño — el texto va aparte, escrito por Claude en el Word.

Si el negocio tiene un avatar de marca (ej. un chef, un personaje), usar ese mismo `media_id` de referencia ya confirmado en Higgsfield para la foto de portada, para mantener consistencia visual con el resto de los assets de marketing.

---

## PASO 4 — Generar las fotos en Higgsfield

**Modelo recomendado:** `nano_banana_pro` (o el modelo fotorrealista por defecto de la cuenta). Para la portada, si hay avatar de marca, usar `medias: [{ value: <media_id del avatar>, role: "image_references" }]`.

**Para las fotos de items (recetas/productos):** generación simple por prompt, SIN texto ni UI superpuesta — son fotos de producto/comida realistas, tipo editorial de revista de cocina, no páginas de diseño.

Lanzar en batch (`generate_image_batch`) todas las fotos de un libro juntas, esperar con `jobs_wait` en grupos de hasta 12, y descargar todas con un script Node (`https.get` → `fs.createWriteStream`) a una carpeta `images_<libro>/`.

**Aspect ratio recomendado:** 4:3 para fotos de recetas/items (se ve bien en una columna de página tamaño carta), libre para la portada según el diseño.

---

## PASO 5 — Optimizar imágenes

Usar `sharp` para convertir a JPG y bajar el peso antes de insertarlas en el Word (si no, el .docx queda pesadísimo):

```js
const sharp = require('sharp');
await sharp(`${SRC}/${f}`)
  .resize({ width: isCover ? 1600 : 920 })
  .jpeg({ quality: isCover ? 88 : 82 })
  .toFile(`${DEST}/${outName}`);
```

---

## PASO 6 — Armar el .docx con docx-js

Usar la skill `docx` (ver sus gotchas de docx-js: `PageBreak` dentro de `Paragraph`, nunca `\n`, tablas con `columnWidths` + `width` por celda en DXA, `ShadingType.CLEAR` nunca `SOLID`, `ImageRun` con `type` explícito, etc.)

Estructura de cada item (recipeBlock/itemBlock):

1. Título numerado + blurb en itálica
2. `ImageRun` con la foto optimizada, centrada, ~460x345 (fotos de item) o ~560x420 (portada)
3. Tabla de datos rápidos (prep/cook/servings o equivalente) con shading claro
4. Lista de ingredientes/materiales con bullets (`numbering` config, nunca `•` literal)
5. Lista de instrucciones numerada
6. Callout de tip con `shading` de color de acento
7. `PageBreak`

Usar la paleta de marca en títulos, headers y acentos (`TextRun.color`). Página tamaño Letter (`12240x15840` DXA) salvo que el usuario pida A4. Footer con nombre de colección + número de página (`PageNumber.CURRENT`).

Si el producto se divide en varios libros, generar un script `build_<libro>.js` por cada uno, cada uno importando su propio `_content.js` y su propia carpeta de imágenes.

---

## PASO 7 — Verificar antes de entregar

```bash
python scripts/office/soffice.py --headless --convert-to pdf output.docx
pdftoppm -jpeg -r 100 output.pdf page
```

Mirar (`Read`) al menos la portada, una página de item completa y el cierre, antes de entregar — confirmar que las fotos insertaron bien, que no hay texto cortado, y que el diseño se ve prolijo.

---

## PASO 8 — Entregar

Copiar el/los .docx (y PDF si corresponde) a `/mnt/user-data/outputs/` y entregar con `SendUserFile`. Si el ebook tiene varios libros/tomos, entregarlos todos juntos en una sola tanda para que el usuario tenga la colección completa de una vez.

---

## Paletas sugeridas por nicho

| Nicho | Fondo (referencia) | Acento principal | Acento secundario | Texto |
|---|---|---|---|---|
| Cocina/Recetas | #FBF3E4 cálido | #E2572B naranja | #1F3D2B verde | #2B2118 marrón |
| Fitness/Salud | #FFFFFF blanco | #7CB518 verde lima | #1A1A2E gris | #1A1A2E gris |
| Crochet/Manualidades | #FDF6EC crema | #E8A598 rosa palo | #5C3D2E marrón | #5C3D2E marrón |
| Finanzas/Negocios | #0A1628 azul | #C9A84C dorado | #FFFFFF blanco | #FFFFFF blanco |
| Edición de Video | #0D0D0D negro | #00D4FF cian | #FFFFFF blanco | #FFFFFF blanco |
| Bienestar/Holístico | #E8F0E9 salvia | #C8A951 dorado | #2D4A22 verde | #2D4A22 verde |
| Belleza/Estética | #FDF0F0 rosa | #D4AF7A dorado | #2C2C2C gris | #2C2C2C gris |

---

## Notas importantes

- Copy siempre en el idioma del producto (español o inglés según el mercado que el usuario esté targeteando); prompts de Higgsfield SIEMPRE en inglés.
- Una foto por item es el estándar — no hace falta más, y mantiene el .docx liviano. La portada puede llevar la foto más grande/cuidada del documento.
- Si hay un avatar de marca ya generado (chef, personaje), reutilizar siempre su `media_id` confirmado en Higgsfield para la portada y cualquier foto que lo incluya, en vez de generar una cara nueva cada vez.
- Nunca generar el copy como parte de la imagen — el texto SIEMPRE se escribe en Word. Esto es lo que distingue a esta skill de `ebook-higgsfield` y lo que evita los errores de tipografía de la IA.
- Verificar el .docx renderizándolo a PDF antes de entregar (PASO 7) — no entregar sin mirarlo.
- Entregar siempre con `SendUserFile`.
- Si el usuario pide después migrar este ebook al formato "página completa como imagen", usar `ebook-higgsfield`. Si pide sacar la IA de las imágenes por completo, usar `ebook-canva`.