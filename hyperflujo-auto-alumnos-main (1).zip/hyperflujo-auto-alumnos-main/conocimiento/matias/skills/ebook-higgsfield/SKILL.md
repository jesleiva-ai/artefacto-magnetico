---
name: ebook-higgsfield
description: Genera ebooks infoproducto profesionales de nivel editorial usando Higgsfield (Nano Banana Pro 2K) para crear cada página como imagen de alta calidad. Usar SIEMPRE que el usuario pida crear un ebook, infoproducto digital, manual, guía, o cualquier producto digital con páginas visuales. También usar cuando el usuario mencione "prompts para ebook", "páginas para Higgsfield", "generar infoproducto digitalmente", "crear PDF para vender", "hacer un ebook", o cualquier variante. Claude genera las imágenes DIRECTAMENTE en Higgsfield sin que el usuario tenga que hacer nada — flujo 100% automatizado. Produce el PDF final completo ensamblando todas las páginas. Activar con comando slash o automáticamente cuando el usuario quiera crear cualquier tipo de ebook o infoproducto digital.
---

# Skill: Generador de Ebooks con Higgsfield

## Qué hace esta skill

Genera ebooks infoproducto completos de calidad editorial. Cada página del ebook es una imagen generada con Higgsfield Nano Banana Pro 2K que contiene TODO integrado: diseño visual, fotos del producto, copy completo, ingredientes/pasos, tipografía editorial.

**Resultado:** PDF listo para vender con páginas de nivel revista.

---

## FLUJO COMPLETO

```
PASO 1 → Claude hace las 7 preguntas
PASO 2 → Claude define la estructura del ebook
PASO 3 → Claude genera TODAS las páginas en Higgsfield
         (cada imagen = una página completa con TODO adentro)
PASO 4 → Usuario descarga las imágenes de los widgets
         y las sube al chat
PASO 5 → Claude ensambla el PDF y lo entrega listo ✅
```

**Nota:** El PASO 4 es el único paso manual — descargar y subir las imágenes. Son 2 minutos. No requiere Claude Code ni ninguna otra herramienta.

---

## PASO 1 — Relevamiento del nicho (SIEMPRE PRIMERO)

Obtener estas 7 variables. Si ya están en la conversación, extraerlas sin preguntar:

1. **NICHO** — ¿De qué trata el ebook?
2. **AVATAR** — ¿A quién le vendés?
3. **PROMESA** — ¿Qué resultado concreto obtiene quien compra?
4. **PRODUCTO** — ¿Cuántos capítulos/recetas/técnicas tiene?
5. **PRECIO** — ¿Cuánto va a valer?
6. **PALETA** — ¿Colores de la marca? (si no tiene, sugerir según nicho)
7. **NOMBRE** — ¿Cómo se llama el ebook y la marca?

Si el usuario sube un PDF de referencia, analizar su diseño y replicarlo en los prompts.

---

## PASO 2 — Definir estructura del ebook

Arquitectura base (adaptar según nicho):

```
PÁGINA 1   → Portada (título, subtítulo, imagen hero, marca, badges)
PÁGINA 2   → Bienvenida / presentación emocional
PÁGINA 3   → Receta/contenido 1 (con foto, ingredientes, pasos)
PÁGINA 4   → Recetas/contenido 2 y 3 (dos en una página)
PÁGINA 5   → Recetas/contenido 4 y bonus
PÁGINA 6   → Tips esenciales (grid de cards)
PÁGINA 7   → Cierre + CTA (redes, precio, copyright)
```

Mínimo 7 páginas, máximo 20.

---

## PASO 3 — Generación de páginas en Higgsfield

**CLAVE:** Cada prompt debe describir una PÁGINA COMPLETA del ebook con TODO el contenido integrado en la imagen — diseño, texto, fotos de comida/producto, layout. NO son fotos sueltas.

**Parámetros obligatorios:**
```
model: "nano_banana_2"
aspect_ratio: "2:3"
count: 1
```

Lanzar TODAS las páginas en paralelo.

**Estructura del prompt para cada página:**

```
Create a complete, full-page ebook layout image for a [NICHO] infoproduct.
This is PAGE [N] of the ebook "[NOMBRE]".

PAGE CONTENT: [describir exactamente qué va en esa página]

VISUAL STYLE:
- Background color: [COLOR FONDO de la paleta]
- Accent color: [COLOR ACENTO]
- Text color: [COLOR TEXTO]
- Magazine editorial style, premium Brazilian infoproduct aesthetic
- Clean typography, bold headlines, readable body text

LAYOUT ELEMENTS:
[describir el layout específico: header, columnas, fotos, badges, etc.]

FOOD/PRODUCT PHOTOS: Include realistic, appetizing photos of [producto específico]
integrated naturally into the layout.

TEXT ON IMAGE (in Spanish):
- Headline: "[TÍTULO DE LA PÁGINA]"
- [resto del copy específico de esa página]

Brand name "[NOMBRE MARCA]" in footer. Page number [N].
Ultra-high quality, print-ready, 2K resolution. No watermarks.
```

---

## PASO 4 — Instrucciones para el usuario

Cuando las imágenes terminen de generarse en los widgets, decirle al usuario:

> "✅ Tus [N] páginas están listas en los widgets de arriba.
> Para obtener el PDF:
> 1. Descargá cada imagen haciendo clic en el botón de descarga de cada widget
> 2. Subílas todas juntas acá en un solo mensaje
> 3. Yo armo el PDF en segundos 🔥"

---

## PASO 5 — Ensamblar PDF

Cuando el usuario suba las imágenes:

```python
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import os

W, H = A4
c = canvas.Canvas("/mnt/user-data/outputs/[nombre_ebook].pdf", pagesize=A4)

# Por cada imagen subida (en orden de página):
img = Image.open(path).convert("RGB")
temp = f"/tmp/pag_{i}.jpg"
img.save(temp, "JPEG", quality=95)

# Full-page, cubriendo toda la página A4
scale = max(W / img.width, H / img.height)
new_w = img.width * scale
new_h = img.height * scale
x = (W - new_w) / 2
y = (H - new_h) / 2

c.drawImage(temp, x, y, new_w, new_h)
c.showPage()

c.save()
```

Entregar con `present_files`.

---

## Paletas sugeridas por nicho

| Nicho | Fondo | Acento | Texto |
|---|---|---|---|
| Cocina/Recetas | #FFF8F0 cálido | #C0533A terracota | #3D1F0D marrón |
| Fitness/Salud | #FFFFFF blanco | #7CB518 verde lima | #1A1A2E gris |
| Crochet/Manualidades | #FDF6EC crema | #E8A598 rosa palo | #5C3D2E marrón |
| Finanzas/Negocios | #0A1628 azul | #C9A84C dorado | #FFFFFF blanco |
| Edición de Video | #0D0D0D negro | #00D4FF cian | #FFFFFF blanco |
| Bienestar/Holístico | #E8F0E9 salvia | #C8A951 dorado | #2D4A22 verde |
| Belleza/Estética | #FDF0F0 rosa | #D4AF7A dorado | #2C2C2C gris |

---

## Reglas de calidad

**Portada:**
- Foto hero grande y apetitosa del producto
- Título grande bold en color acento
- Subtítulo con la promesa
- Badges de beneficios (✓ Sin TACC / ✓ Fácil / ✓ Listo en 1 día)
- Nombre de marca en footer

**Páginas de receta:**
- Header con número y nombre de receta
- Foto del plato terminado integrada en el layout
- Columna INGREDIENTES + columna PREPARACIÓN
- Badges de tiempo/porciones/dificultad
- TIP destacado al pie
- Número de página en footer

**Página de tips:**
- Header grande de color con título
- Grid de 6 cards numeradas
- Foto de ambiente al fondo
- Cada card: número en círculo + título bold + descripción

**Cierre:**
- Fondo del color acento (invertir paleta)
- Foto de persona feliz con el producto
- Card blanca con CTA claro
- Instagram, web, precio destacado
- Copyright

---

## Notas importantes

- Prompts de Higgsfield SIEMPRE en inglés
- Copy visible en las páginas en el idioma del producto (español)
- Usar `nano_banana_2` — NO otros modelos
- El texto generado por Higgsfield puede tener errores de tipografía — es normal en IA
- Si el usuario sube PDF de referencia, analizar y replicar su estilo exacto
- Entregar siempre el PDF con `present_files`
