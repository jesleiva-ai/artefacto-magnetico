---
name: "embudo-hotmart-netlify"
description: "Arma el embudo completo de un producto digital en Hotmart con las páginas en Netlify: order bumps en el checkout, upsell y downsells de un clic con el widget de botones Sí/No de Hotmart pegado en páginas HTML propias, página de gracias, y portal con candados que se abren solo si la persona compró. Opera Hotmart desde el navegador con la sesión de la persona. Usar cuando se pida 'armá los order bumps', 'poné el upsell y los downsells', 'el widget de sí y no', 'embudo de Hotmart con Netlify', 'portal con candado' o al lanzar la escalera de un producto."
---

# Embudo Hotmart + Netlify (bumps, upsell, downsells y candados)

Hotmart cobra (checkout, bumps, upsell y downsells de un clic). Netlify muestra todo lo demás: la web, las páginas de cada oferta y el portal donde está el producto. Cada producto de Hotmart es un PDF corto que dice "Gracias por tu compra" con un botón al portal.

## Antes de empezar (preguntar solo lo que falte)

- La escalera ya decidida (si no, usar `escalera-de-valor`): producto principal, hasta 3 order bumps, 1 upsell y los downsells, con precio en USD.
- Que la persona haya iniciado sesión en Hotmart en su navegador. **Nunca escribir contraseñas ni códigos de verificación.**
- **¿Netlify o Cloudflare?** Si no está guardado en la configuración, preguntarlo una vez (Matías, 2026-10-26: «algunos usan una y otros usan otra»). Con Cloudflare, las páginas se publican con Cloudflare Pages y todo lo demás de esta skill vale igual.
- Dónde se publica la web (sitio de Netlify o proyecto de Cloudflare, y carpeta). Si el sitio tiene otros productos, publicar **solo agregando archivos**, nunca reemplazando el sitio entero.
- Idioma del mercado: todos los textos que ve el comprador van en ese idioma.

Mat autoriza a aceptar los términos de Hotmart, finalizar el registro y activar el embudo: avisar en una línea y seguir.

**Escalera del backend:** cada oferta del embudo es un producto distinto que no está incluido en otro (si el upsell es un pack, los siguientes no pueden ser partes de ese pack), porque a todos se les ofrece el siguiente, digan que sí o que no.

## Paso 1. Un producto de Hotmart por cada cosa que se cobra

Cada bump, el upsell y cada downsell es su propio producto (eBook) con su precio, garantía y como contenido el PDF de acceso a su página del portal.

1. Crear producto (`app.hotmart.com/products/add`) → eBook → nombre, descripción (Hotmart pide **al menos 200 caracteres**), idioma, **país principal de ventas: Estados Unidos** (así lo pone siempre Mat, aunque se venda en otro idioma), imagen (mockup cuadrado de 600×600).
2. Precio **en dólares (USD)** siempre, pago al contado, **garantía de 7 días en todos los productos, nunca 15** (regla de Mat, 2026-10-21; la web y los anuncios tienen que decir lo mismo). El conversor de la web muestra la moneda local. Si al guardar sale "Error interno del sistema", el producto queda como borrador igual: buscarlo en la lista y seguir.
3. Si aparece el paso de "Área de Miembros", saltearlo y subir el PDF en **Contenido del producto**.
4. **Finalizar registro** (avisar en una línea y seguir (Mat, 2026-10-26: automático, sin pedir confirmación)). Hotmart lo revisa; en general aprueba en minutos.
5. **Los bumps y los pasos del embudo solo aceptan productos aprobados.** Mientras esperás, armá las páginas (paso 3).
6. Con el producto aprobado, copiar su link de pago en **Links de divulgación** (`/products/manage/<ID>/hotlink-setup`, link `pay.hotmart.com/...`).

## Paso 2. Order bumps en el checkout del producto principal

1. En el producto principal: **Herramientas → Apariencia de la Página de Pago** (abre `custom-checkout.hotmart.com/<ID>`). Elegir plantilla "En blanco".
2. Barra izquierda → **Order Bump** → **Elegir producto** → buscar por nombre → desplegar → marcar la oferta → **Seleccionar**.
3. Se elige **un producto por vez**: escribir la descripción (una línea, en el idioma del mercado, que empiece con "Sí, agregá…") → **Insertar**. Repetir por cada bump.
4. Cuidado: la barra izquierda tiene otros componentes (Evaluaciones = testimonios, Cuenta regresiva). **No insertar testimonios ni contadores falsos.**
5. **Guardar** → **Publicar página** → en "Gestionar publicación" elegir **Definir como estándar** → confirmar.
6. Si después se cambia algo, **Guardar cambios → Guardar y actualizar** (Hotmart dice que tarda hasta 5 minutos).
7. **El link de compra que va en la web es el de la "Página de Pagos estándar"**, que trae `?checkoutMode=10` (ej. `pay.hotmart.com/[CODIGO_PRODUCTO]?checkoutMode=10`). Copiarlo desde `custom-checkout.hotmart.com/<ID>` y usar ese en todos los botones. **Sin `?checkoutMode=10` los bumps no aparecen** (lección de Gessetti y de Método Consultor, 2026-10-20).
8. Verificar en ese mismo link (no en otro) que aparezcan los bumps. Si se prueba desde la PC de Mat, el checkout puede abrir en Brasil (R$); cambiar el país con "Alterar país" para ver cómo lo ve el comprador. Mat lo confirmó a mano el 2026-10-20.

## Paso 3. Las páginas de cada oferta en Netlify

Una página por paso, cada una en su carpeta (`/oferta-especial/`, `/oferta-1/`, …, `/gracias/`). Plantilla en `plantilla_pagina_oferta.html`. Cada página lleva:

- Barra arriba: "Tu pedido está confirmado. No cierres esta página."
- Título que hable a quien **ya compró** el principal, mockup, qué incluye (solo lo que el producto tiene de verdad), precio con `data-usd` y el conversor de moneda por IP.
- El lugar del widget: el comentario `<!-- HOTMART-WIDGET -->` donde después se pega el código de Hotmart. Los botones Sí/No los dibuja el widget; **no inventar botones propios**.
- `noindex` (no hace falta que Google las encuentre) y el píxel de Meta si lo hay.
- Prohibido: urgencia falsa, relojes, "últimos cupos", testimonios inventados.

La página de gracias explica que llega un mail de Hotmart por cada producto comprado y tiene un botón al portal.

## Paso 4. El embudo de un clic en Hotmart

Herramientas → Mostrar todas → **Embudo de Ventas** (`/tools/sales/funnel`) → **Nuevo Embudo**:

1. Nombre, producto principal, su oferta, medio de pago (tarjeta) → **Crear Embudo**.
2. En la lista, **••• → Editar etapas**. Se abre un diagrama con el bloque "Inicio".
3. Tocar el botón de un bloque abre **Nueva Etapa**:
   - Tipo **Oferta** → nombre de la etapa, producto, oferta y **URL de la página** (sin `https://`, por ejemplo `misitio.com/producto/oferta-especial/`).
   - Siguiente → texto del botón Sí → Siguiente → texto del botón No → Siguiente → vista previa → **Guardar**.
4. **Regla de Mat (2026-10-21): diga que sí o que no, siempre se le ofrece el producto siguiente**, para subir el ticket promedio. Cadena: Inicio → Upsell → (Sí y No) → Oferta 2 → (Sí y No) → Oferta 3 → … → Gracias. Nunca mandar a Gracias a quien dijo que sí si quedan ofertas.
   - Por eso **cada paso tiene que ser un producto distinto, que no esté incluido en otro paso**. Si el upsell es un pack que contiene a los downsells, a quien lo compró se le vendería lo mismo dos veces. Armar la escalera con productos que no se pisen.
   - Los textos de cada página no pueden suponer que la persona dijo que no a la anterior ("Entendido, el kit no es para ahora…"): tienen que servir para los dos casos.
5. Última etapa: tipo **Página de Agradecimiento** con la URL de `/gracias/`.
6. Unir los **Sí** con **Etapa Existente** al mismo paso que su No (el producto siguiente). El Sí y el No del último van a Gracias.
7. Revisar recargando: cada etapa de oferta tiene que tener sus dos flechas.
8. Botón **Widget Code**: Hotmart da **un solo código para todas las páginas** y la lista de URLs donde pegarlo. Copiarlo tal cual:

```html
<!-- HOTMART - Sales Funnel Widget -->
<div id="hotmart-sales-funnel"></div>
<script src="https://checkout.hotmart.com/lib/hotmart-checkout-elements.js"></script>
<script>
checkoutElements.init('salesFunnel').mount('#hotmart-sales-funnel')
</script>
<!-- HOTMART - Sales Funnel Widget -->
```

9. Pegarlo en cada página de oferta en lugar de `<!-- HOTMART-WIDGET -->`, publicar en Netlify y verificar que cada URL responda y tenga el widget.
10. **Activar embudo** (avisar en una línea y seguir (Mat, 2026-10-26: automático, sin pedir confirmación)). Para editar etapas después hay que desactivarlo.

## Paso 5. Portal con candados

Todo vive en un solo portal. Lo que no se compró aparece con candado:

- Sección "Contenido extra" con una tarjeta por bump y por colección. Si está bloqueada, el botón lleva al **link de pago** de ese producto. Si está abierta, lleva a su página.
- Cada página de producto del portal guarda en el navegador que se desbloqueó (`localStorage`). El upsell desbloquea también todo lo que incluye.
- El PDF de acceso de cada producto lleva a su página del portal: al entrar, queda desbloqueado.
- Explicarle a la persona el límite: el desbloqueo es **por dispositivo** y la seguridad es la misma que la de un portal con link. Si cambia de celular, vuelve a abrir el link del PDF.

## Paso 6. Prueba y entrega

- Verificar que cada página publicada responda y que el checkout del principal muestre los bumps.
- **La compra de prueba la hace la persona**, nunca Claude. Revisar con ella: bumps cobrados, upsell que aparece, que el No lleve al downsell, que el Sí cobre con un clic, que llegue el mail de cada producto y que el píxel registre la compra.
- Anotar en el cerebro: IDs de producto, links de pago, URLs de cada página, ID del embudo y del checkout.

## Errores conocidos

- "Todavía no has registrado productos" al elegir un bump: el producto no está aprobado todavía.
- "Error interno del sistema" al guardar el precio: el producto igual se crea como borrador. Buscarlo en la lista y seguir.
- Los bumps no aparecen enseguida en el checkout: esperar unos segundos y recargar.
- La URL de la página quedó con `https://` repetido: borrar el campo y escribir la dirección sin `https://`.
