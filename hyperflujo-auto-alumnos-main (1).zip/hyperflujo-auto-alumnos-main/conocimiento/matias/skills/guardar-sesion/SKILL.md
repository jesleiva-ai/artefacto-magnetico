---
name: "guardar-sesion"
description: "Cierra una sesión de trabajo guardando en el segundo cerebro de Mat (D:\\segundo-cerebro) lo que se decidió, lo que quedó pendiente y lo aprendido, y propone actualizar las notas principales. Usar cuando se diga 'guardá la sesión', 'cerramos', 'anotá lo que hicimos', 'orden', 'guardá todo', o al terminar una tarea larga de negocio."
model: sonnet
effort: low
---

# Guardar sesión

Si una decisión no queda escrita, la próxima sesión no la conoce. Esta skill la escribe.

Reglas de la casa: `D:\segundo-cerebro\INSTRUCCIONES_IA.md` y `D:\segundo-cerebro\CLAUDE.md`.

## Pasos

1. **Repasar la conversación** y separar:
   - **Decisiones** (lo que la persona decidió o confirmó, con sus palabras).
   - **Datos nuevos** (números, precios, resultados, links) con su fuente.
   - **Tareas pendientes** (qué, para quién, para cuándo si se dijo).
   - **Lecciones** (algo que salió mal o bien y conviene recordar).
   - **Ideas sueltas** que no se trabajaron.
   - Lo que es **deducción de Claude** va marcado como *(a confirmar)*.
2. **Escribir la nota de la sesión** en `D:\segundo-cerebro\07_REVISIONES\sesiones\AAAA-MM-DD_[tema-corto].md`:

```
# Sesión AAAA-MM-DD — [tema]

## Decisiones
- [decisión] — Fuente: la persona

## Datos nuevos
- [dato] — Fuente: [de dónde]

## Pendientes
- [ ] [tarea] — [para cuándo, si se dijo]

## Lecciones
- [lección]

## Ideas sueltas
- [idea]

## Archivos que se cambiaron en esta sesión
- [ruta] — [qué cambió]
```

3. **Lecciones:** si hay alguna, agregarla también a `D:\segundo-cerebro\05_PROCESOS\LECCIONES.md` con fecha (una línea por lección; no duplicar las que ya están).
4. **Ideas sueltas:** cada una va a `00_ENTRADA` con la skill `capturar-idea`.
5. **Proponer actualizaciones** a las notas principales (estrategia, producto, contexto del negocio, etc.): mostrar la lista "archivo → qué agregaría" y aplicarlo, avisando qué cambió; lo viejo se reemplaza (Mat, 2026-10-26: automático, sin pedir confirmación).
6. **Cerrar** con 3 líneas: qué se guardó, qué quedó pendiente, próximo paso.

## Reglas

- No inventar decisiones: si algo no quedó claro, va en pendientes como pregunta.
- No guardar contraseñas, claves, tokens ni datos de compradores.
- Si ya existe una nota de sesión del mismo día y tema, agregar al final en vez de crear otra.
