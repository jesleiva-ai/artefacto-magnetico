---
name: "importar-de-otras-ias"
description: "Trae al segundo cerebro del usuario (D:\\segundo-cerebro) lo que otras IAs ya saben de él y de su negocio (la app de Claude, ChatGPT, Gemini, Codex u otra): da el pedido para pegar en esa IA, guarda la respuesta cruda y la destila en notas con fecha y fuente, marcando lo deducido como no confirmado. Usar cuando se pida 'traé lo que sabe ChatGPT', 'importá lo de la app de Claude', 'pasá mi memoria de otra IA', o al armar el cerebro de un alumno."
model: sonnet
effort: medium
---

# Importar lo que saben otras IAs

## 1. Pedido para pegar en la otra IA

Darle a la persona este texto para pegar en la app de Claude, ChatGPT, Gemini u otra:

```
Estoy pasando mi trabajo a un sistema nuevo y necesito llevarme todo lo que sabés de mí y de mi negocio.
Haceme un resumen ordenado, sin inventar nada, de todo lo que sabés por lo que venimos hablando:
1. Quién soy: país, moneda, cómo trabajo, cuánto tiempo le dedico.
2. Mis productos: qué vendo, a quién, a qué precio, en qué plataforma y en qué idiomas.
3. Lo que probé: ofertas, páginas, anuncios y campañas; qué funcionó y qué no, con números si los tenés.
4. Lo que decidí: precios, nombres, reglas y criterios que me puse.
5. Mis métodos: cómo armo campañas, anuncios, ofertas.
6. Mis objetivos y lo que hoy me frena.
7. Cómo me gusta trabajar y que me hablen.
Si de algo no sabés nada, poné "sin datos". Al lado de cada cosa, aclará si te lo dije yo o si lo estás deduciendo.
```

## 2. Guardar crudo

La respuesta que pegue la persona va tal cual a `D:\segundo-cerebro\00_ENTRADA\AAAA-MM-DD_memoria-[nombre-de-la-IA].md` con fuente y fecha.

## 3. Destilar

- Separar por destino: contexto del negocio, productos, estrategia/métodos, clientes, lecciones, objetivos.
- Lo que la otra IA marcó como **deducido** se guarda como *(no confirmado — fuente: [IA])*.
- **Comparar con lo que ya está en el cerebro:** si coincide, no duplicar; si contradice, mostrar las dos versiones y que decida la persona.
- Mostrar el plan "archivo → qué agregaría" y aplicarlo, avisando qué cambió; lo viejo se reemplaza, no se deja al lado (Mat, 2026-10-26: automático, sin pedir confirmación).

## Reglas

- No guardar contraseñas, claves, datos de tarjetas ni datos personales de terceros (clientes, compradores) aunque la otra IA los mencione.
- El cerebro es la fuente de verdad: lo importado no pisa lo confirmado por la persona.
