---
name: "investigar-mercado"
description: "Evalúa si un nicho o producto digital low-ticket tiene potencial en un mercado/idioma antes de lanzarlo o modelarlo: demanda, competencia en la Biblioteca de anuncios, precios, ángulos que se usan, avatar y creencias, y da un veredicto (lanzar / probar chico / descartar). Usar cuando se pida 'investigá el mercado', '¿este nicho da?', '¿lo lanzo en [idioma]?', 'avatar', o antes de modelar una oferta en un mercado nuevo."
---

# Investigar mercado

Contexto: `D:\segundo-cerebro\01_NEGOCIO\CONTEXTO_DEL_NEGOCIO.md` y `05_PROCESOS\ELEGIR_Y_MODELAR_OFERTAS.md`. Mercados del usuario: todos los idiomas donde se pueda vender.

## Señales que se miran *(criterios propuestos por Claude, a confirmar por la persona)*

| Señal | Cómo se mide | Bueno | Malo |
|---|---|---|---|
| **Ofertas que escalan** | Anunciantes del nicho con 20–30+ anuncios activos y +15 días (skill `espia-de-ofertas`) | 2 o más | ninguno |
| **Competencia en el mercado destino** | Anunciantes del mismo producto en el idioma destino | pocos o ninguno con volumen | muchos con 30+ anuncios |
| **Precio** | Precios de entrada vistos | entra en USD 5–40 | solo high-ticket |
| **Ángulos** | Qué prometen los anuncios que más corren | hay ángulos sin usar | todos dicen lo mismo y está saturado |
| **Demanda de búsqueda** | Búsquedas, tendencias, grupos y videos del tema en ese idioma | tema vivo y con preguntas | nadie habla del tema |
| **Políticas** | Riesgo en Meta (skill `chequeo-politicas-meta`) | bajo | salud/finanzas/promesas imposibles |
| **Escalera posible** | ¿Hay bumps y upsells naturales? (skill `escalera-de-valor`) | 3+ complementos | producto que se agota en uno |

## Pasos

1. Definir nicho, producto y mercado/idioma destino (y de origen si es modelado).
2. Medir cada señal; anotar el dato, la fecha y la fuente. Lo que no se pudo medir: `desconocido`.
3. **Avatar:** quién compra, qué le pasa, qué quiere, qué cree que es verdad sobre el tema (creencias que hay que romper o usar), en qué palabras lo dice (skill `voz-del-cliente` si hace falta profundidad).
4. **Ángulos posibles** por nivel de conciencia (C1/C2/C3) y 5 ganchos story time del nicho (skill `anuncio-storytime-controversial`).
5. **Veredicto:** lanzar / probar chico / descartar, con el porqué en 3 líneas.

## Entrega

Guardar en `D:\segundo-cerebro\06_PROYECTOS\ofertas\AAAA-MM-DD_mercado_[nicho]_[idioma].md` con: tabla de señales, avatar, ángulos, ganchos, veredicto y próximos pasos (`oferta-completa` → `escalera-de-valor` → `modelar-ofertas` → anuncios).

## Reglas

- Los datos con fecha y fuente; nada inventado.
- Un mercado se evalúa en su idioma (buscar en polaco para Polonia, etc.).
