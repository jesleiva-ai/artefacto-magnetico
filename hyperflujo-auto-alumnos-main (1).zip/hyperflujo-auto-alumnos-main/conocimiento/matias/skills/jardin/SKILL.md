---
name: "jardin"
description: "Ordena el segundo cerebro del usuario (D:\\segundo-cerebro) sin borrar nada: procesa lo acumulado en 00_ENTRADA, detecta notas repetidas, contradictorias o viejas, pendientes sin cerrar y datos sin fecha, y propone dónde va cada cosa. Usar cuando se pida 'ordená el cerebro', 'jardín', 'limpiá las notas', 'qué hay sin procesar', o una vez por mes."
model: sonnet
effort: low
---

# Jardín: ordenar el cerebro

Reglas de la casa: `D:\segundo-cerebro\INSTRUCCIONES_IA.md`. **Lo viejo o superado se borra o se reemplaza** por la versión vigente, avisando qué se sacó (Mat, 2026-10-26: «lo que quede viejo se tiene que borrar o quitar»).

## Pasos

1. **Entrada:** listar todo lo de `00_ENTRADA` con estado "sin procesar". Para cada uno proponer destino (producto, estrategia, cliente, proyecto, idea de anuncio, descartar a archivo) siguiendo `prompts/PROCESAR_ENTRADA.md`.
2. **Repetidos:** buscar notas que dicen lo mismo en dos lugares; proponer cuál queda como fuente principal y en la otra dejar solo un enlace.
3. **Contradicciones:** precios, reglas o datos que no coinciden entre archivos (ej.: precio en ficha vs. en página de venta). Listarlas con las dos fuentes; no elegir solo.
4. **Viejo:** notas con "Última actualización" de hace más de 60 días, proyectos sin movimiento, campañas del análisis que ya no existen. Proponer actualizar o archivar.
5. **Pendientes:** juntar los `[Pendiente]` y `[ ]` abiertos de todo el cerebro en una lista por prioridad.
6. **Sin fuente o sin fecha:** marcar datos importantes que no dicen de dónde salen.
7. **Mostrar el plan** (tabla: archivo → qué propongo → por qué) y aplicarlo, avisando qué cambió (Mat, 2026-10-26: automático, sin pedir confirmación).
8. Guardar el resumen en `D:\segundo-cerebro\07_REVISIONES\AAAA-MM-DD_jardin.md`.

## Reglas

- No cambiar el sentido de lo que escribió la persona; solo ordenar, enlazar y marcar.
- Al archivar, anotar fecha, motivo y cuál es la fuente vigente (ver `99_ARCHIVO/README.md`).
