---
name: landing-modelada
description: Arma la página de venta de un producto digital del usuario modelándola sobre la original y con el formato que el usuario deja en sus páginas terminadas (Método del Consultor, Planos Listos, Pequeños Abrigos, Music Adventure Kit, Happy Little Eaters, Más Allá de los Acordes). Usar siempre que se pida 'armá la landing', 'la página de venta', 'modelá la web', 'hacé la página', o al modelar una oferta. No inventa estructura: sigue esta receta paso por paso.
---

# Landing modelada (como las deja el usuario)

el usuario terminaba corrigiendo a mano cada página que armaban los agentes. Esta skill sale de comparar, el 2026-10-21, las 5 páginas antes y después de sus correcciones, más la del Método del Consultor. **Seguila tal cual. Si algo no está acá, no lo inventes: preguntalo en una línea o dejalo marcado para el usuario.**

Páginas de referencia (las versiones terminadas por el usuario):
- En internet: `tusitio.com/` + `metodo-consultor/`, `planos-listos/`, `sueter-que-crece/`, `music-adventure-kit/`, `happy-little-eaters/` y `mapa-del-mastil/`.
- Copia: `[carpeta de páginas de referencia]\2026-10-21\` (un `.html` por página). **Antes de armar, abrí la más parecida y copiá su estructura y sus estilos.**

**REGLA QUE MANDA EN TODA WEB (2026-11-09).** Pasa por encima de cualquier otra indicación de este archivo:
- **Orden exacto:** promesa cuantitativa arriba de todo (qué logra, con números y plazo real) → imagen del producto (mockup GRANDE; la persona usándolo, chiquita o nada) → botón que DESLIZA a la presentación de la oferta → dolores → beneficios → lo que trae el producto → bonus de regalo → presentación de la oferta → botón de compra → preguntas frecuentes → botón de compra.
- **Botones de compra:** dos o tres en total, y solo desde la presentación de la oferta para abajo. Antes de la oferta NINGÚN botón va al checkout, tampoco en el encabezado ni en la barra fija, que también deslizan. Un botón de compra antes de la oferta genera pagos iniciados falsos.
- **El botón de compra:** bien grande y animado: titila, late agrandándose y achicándose, llama la atención.
- **Presentación de la oferta:** con su nombre y un mockup marketinero y estético con el producto y todos los bonus en una sola imagen animada (o video). Sin esa imagen la oferta no está presentada.

**Cómo tiene que quedar: skill `web-como-metodo-consultor`** (estructura, largo, mockups y botones, con números y una medición automática). Esta skill dice cómo se trabaja; si chocan, gana aquella. Un calco a otro idioma de una web que ya vende no se compacta.

## 0. Antes de escribir una línea
1. **Desarme de la original** con la skill `desarme-landing`: secciones en orden, colores y tipo de imágenes. Guardalo.
2. **Nombre y marca:** el nombre del producto es el mismo en la web, en Hotmart y en los anuncios. La marca de la página es la de la fanpage (Punto Claro, Tiny Tempo, Armonía a la Vista…).
3. **Imágenes primero:** el pack del producto (mockup con el principal y los bonos), una imagen por bono, vistas previas de páginas reales del producto y una imagen de uso. Hacelas con Higgsfield, **sin texto adentro**. El texto se pone con código.

## 1. La primera pantalla (es lo que más corrige el usuario)
En este orden:
1. **Barra de arriba, en una línea:** emoji del tema + "Precio de lanzamiento: 50% OFF · hasta el [fecha real] · Descarga inmediata".
2. **Encabezado:** nombre de la marca a la izquierda y botón "Ver oferta" a la derecha, que desliza a la oferta.
3. **Etiqueta chica:** "[Producto] · [formato] en [idioma]" (ej.: "Pequeños Abrigos · Patrón digital en español").
4. **Título = qué logra + números concretos.** Empieza con un verbo y dice el resultado, la cantidad y para quién.
   - ✅ "Teje suéteres sin costuras de 6 meses a 12 años con un solo patrón en 8 tallas"
   - ✅ "Bring music time to life with 36 ready-to-use activities for ages 2–8"
   - ✅ "200 recipes. More variety. Less mealtime guesswork."
   - ❌ "El Suéter que Crece · Patrón de suéter infantil de arriba hacia abajo" (nombre + descripción: el usuario lo cambia siempre)
5. **Subtítulo:** "[principal] + [N] bonos…", en una línea.
6. **Mockup grande del producto** con animación suave de flotar (sube y baja).
7. **Botón que desliza a la oferta.** Precio, reloj y compra no van acá: van en la oferta.

## 2. El resto de la página
Los bloques y el orden son los de `web-como-metodo-consultor`, sin agregar secciones. Además:
- **Dolor en forma de pregunta y sin golpes:** "¿Te pasó al seguir un patrón?", "La teoría se entiende mejor cuando la ves en tu guitarra". Nada de "te la explicaron mal" ni promesas de resultado.
- **Lo que trae:** un carrusel con páginas reales del producto, con flechas, y que se amplíe al tocarla.
- **La oferta:** nombre, imagen animada con el producto y todos los bonos, "Lo que recibes" (el principal y cada bono con "Incluido", sin precios de extras), qué es (digital) y qué **no** incluye, ancla tachada real → precio, "AHORRAS 50% · HASTA EL [fecha]", cuenta regresiva a fecha real y garantía de 7 días. **Los order bumps NO van en la web:** se ofrecen solo en el checkout de Hotmart.
- **Opiniones:** solo reales, en una tira corta entre la oferta y las preguntas, con su fuente. **Las capturas y los textos los pone el usuario.** Si no hay, el bloque no va. **Nunca escribas opiniones, nombres ni números de compradores.**
- **Preguntas frecuentes** desplegables, de 4 a 6.

## 3. Que se vea lindo y se mueva (el usuario: "súper estética, animada, no hecha a lo criollo")
**Usá el kit de animaciones** `[carpeta de páginas de referencia]\kit-animaciones.css`: copialo, cambiá el prefijo `pm` por uno del producto y poné los colores de la marca. Trae todo esto:
- **La promesa se mueve:** el título y los subtítulos cambian de color despacio (8 s) y flotan unos píxeles.
- **Los dolores, los cambios y los pasos aparecen de a uno, de arriba hacia abajo,** a medida que la persona baja (clase `.rev` con demoras `.d1`…`.d4`).
- **Los botones de compra están vivos:** el fondo se mueve entre dos colores, laten y les pasa un brillo cada pocos segundos. El botón de la barra fija también late.
- **Las imágenes flotan:** el pack, la oferta, los pasos y los bonos. Los bonos pares van desfasados, para que no se muevan todos juntos.
- **Un puntito que titila** en la etiqueta de "lanzamiento".
- Quien pide menos movimiento en el celular ve la página quieta.

**Imágenes llamativas y de marca:**
- **Arriba, el mockup grande del producto** en tablet, celular o impreso. La persona usándolo, chiquita o nada.
- **Mockups prolijos de cada bono**, con la misma tapa y los mismos colores que el principal: parecen una colección.
- **Una fila de emojis o íconos del tema** arriba del título, y tarjetas con ✕ (dolores) y ✓ (cambios).
- **Carrusel** con flechas y para ampliar al tocar: vista previa del producto.
- **Botón grande con el texto "QUIERO [verbo + producto]"** y una línea chica abajo ("Patrón digital + 4 bonos · garantía de 7 días").
- **Barra fija abajo** con "50% OFF · LANZAMIENTO" y la cuenta regresiva a fecha real. Desliza a la oferta, no compra.

**Línea de marca:** una sola paleta y dos fuentes (una con personalidad para los títulos y una simple para el texto), las mismas en la web, en las tapas, en los mockups y en la fanpage. Las imágenes en `.webp`, con nombres en minúscula.

## 3 bis. Tapas de Hotmart (el usuario, 2026-10-22: "son horribles")
Las tapas del principal, los bumps, el upsell y los downsells forman **una colección**: foto hiperrealista de Higgsfield del producto (libro, carpeta, tablet o celular) en una escena real del nicho con luz cálida, con el nombre bien legible, un color propio por producto y la misma letra y el mismo logo en todas. Nunca una franja de color con un dibujito plano. **La tapa del principal es la imagen del pack que el usuario puso en su web, tal cual** (por ejemplo `img/pequenos-abrigos-pack.webp`). Las demás se hacen en ese mismo estilo.

## 4. Lo técnico, siempre
- **Conversor de moneda por IP** con los precios en `data-usd` (`prompts/CONVERSOR_MONEDA_POR_IP.md`).
- **Píxel de Meta** en la landing, las páginas del embudo, la de gracias y el portal. Revisalo al final: en una corrección se perdió.
- **Botón al checkout** "En blanco" con `?checkoutMode=10`.
- **Páginas del embudo** con el widget Sí/No de Hotmart.
- **Cantidades reales:** el número de la página tiene que ser el que trae el producto. Si la página dice 300, el producto tiene que tener 300.

## 5. Lo que nunca se hace
- No se inventan opiniones, contadores de compradores, "X personas viendo" ni relojes que se reinician.
- No se promete resultado (plata, salud, tiempo garantizado).
- **Una vez publicada, la página es del usuario:** no se vuelve a armar, editar ni publicar sin su OK para ese cambio. Si hace falta un link o un píxel, se anota y se le avisa. Si él autoriza un cambio, primero se baja la versión de internet y se trabaja sobre esa, nunca sobre los archivos viejos de la sesión.

## 6. Control antes de entregar
**Primero, el Profesor** (Matías, 2026-10-27): quien arma no se corrige a sí mismo. Llamá al subagente `profesor-web` con la carpeta del sitio y la ficha, corregí todo su boletín y volvé a presentarla hasta el aprobado. La vara y las webs modelo: `skills/profesor-web/SKILL.md` y `conocimiento/matias/webs_modelo/`.

Pasá `D:\segundo-cerebro\05_PROCESOS\CONTROL_ANTES_DE_PUBLICAR.md` y además revisá:
- [ ] Respeta `web-como-metodo-consultor`: `medir_web.mjs` da ok, mockup grande arriba, primer botón desliza, 2 o 3 botones de compra solo desde la oferta, botón grande que titila y late, imagen de la oferta con todos los bonus.
- [ ] El título empieza con un verbo y tiene números.
- [ ] Está "Lo que recibes" con el principal y los bonos incluidos, y NO hay order bumps en la web.
- [ ] Las opiniones son reales y con fuente, o no está el bloque.
- [ ] Hay vista previa en carrusel, que se amplía.
- [ ] Las animaciones funcionan (flotar, latir, título).
- [ ] El píxel, `data-usd` y el checkout están bien.
- [ ] La comparé lado a lado con la página de referencia más parecida.

---
Relacionado: [[MODELADO_PASO_A_PASO]] · [[ELEGIR_Y_MODELAR_OFERTAS]] · [[CONTROL_ANTES_DE_PUBLICAR]]
