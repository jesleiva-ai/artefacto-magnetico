---
name: "lanzar-en-hotmart"
description: "Arma en Hotmart la escalera de valor completa de un producto digital del usuario: producto principal, checkout personalizado, order bumps, upsells de un clic, downsells y página de gracias, con precios en USD, textos de cada oferta, páginas de upsell/downsell (con conversor de moneda) y prueba final. Lo opera desde el navegador con la sesión de la persona, sin pedir OK: avisa en una línea cada paso que guarda o publica (Mat, 2026-10-26: automático, sin pedir confirmación). Usar cuando se pida 'armá el checkout', 'cargá los order bumps', 'configurá el upsell/downsell', 'armá el embudo en Hotmart', 'subí el producto a Hotmart' o 'lanzar producto'."
---

# Lanzar en Hotmart: escalera de valor completa

el usuario cobra y entrega todo con **Hotmart**, en **USD** (cada comprador paga en su moneda). La escalera se diseña antes con `escalera-de-valor` (break-even = precio del producto principal) y la oferta con `oferta-completa`. Modelo real: Grimorio (principal USD 14,99 + 3 bumps + 8 upsells + 7 bonos).

## Quién hace qué

- **Claude:** diseña cada pieza (textos, precios, páginas), y opera Hotmart desde el navegador con la sesión abierta de la persona, **mostrando lo que va a guardar y esperando el OK antes de cada guardado o publicación**.
- **Siempre la persona:** iniciar sesión, contraseñas, datos bancarios/fiscales, aceptar términos, compras reales.
- **Nombres de menús:** Hotmart cambia su panel seguido. Los pasos describen *qué* configurar; si un menú no coincide, describir lo que se ve en pantalla y ubicarlo con la persona. No inventar opciones que no aparecen.

## 0. Plan de la escalera (antes de tocar Hotmart)

Tabla de `escalera-de-valor`, una fila por pieza:

| Paso | Producto | Precio USD | Dónde aparece | Si dice SÍ → | Si dice NO → |
|---|---|---|---|---|---|
| Principal | ... | 14,99 | landing → checkout | bumps en el checkout | — |
| Bump 1–3 | ... | 4–9 | casilla en el checkout | se suma al pago | — |
| Upsell 1 | ... | ... | página después de pagar | Upsell 2 | Downsell 1 |
| Downsell 1 | versión rebajada real del Upsell 1 | ... | página si rechazó Upsell 1 | Upsell 2 | Upsell 2 |
| Upsell 2... | ... | ... | ... | ... | ... |
| Final | — | — | página de gracias | — | — |

Reglas: precios USD 5–40; bumps más baratos que el principal y ligados a la misma promesa; downsell solo si existe una versión rebajada real; nada se ofrece dos veces en el mismo recorrido. Mostrar el plan y **esperar el OK**.

## 1. Productos en Hotmart

**Cada pieza que se cobra (principal, cada bump, cada upsell, cada downsell) tiene que existir como producto en Hotmart** con su propia oferta y precio en USD.

Para cada uno: nombre, descripción corta, imagen, categoría, idioma, precio en USD (oferta principal del producto), garantía (por defecto 7 días, a confirmar), entrega (área de miembros de Hotmart preferible, o archivos), y, si aplica, página de venta. Anotar el **ID / código de oferta** de cada uno en la ficha del producto.

## 2. Checkout del producto principal

- Personalizar el checkout: idioma del mercado, logo/imagen del producto, colores acordes a la landing, título y lista corta de lo que incluye, sello de garantía, preguntas mínimas (solo los datos que Hotmart exige).
- Cuotas si corresponde. Moneda: USD como base.
- Píxel de Meta conectado al producto/checkout para registrar compras (y el evento de inicio de pago si Hotmart lo permite).

## 3. Order bumps (en el checkout)

Por cada bump (1 a 3):
- Producto de Hotmart del bump + su oferta/precio.
- **Título** corto con beneficio (máx. ~60 caracteres) — ej.: "Sumá la Biblioteca de Magia Verde por solo US$8".
- **Descripción** de 1–2 líneas: qué es y por qué complementa al principal.
- Imagen chica del bump.
- Orden: el más barato / más obvio primero.
Textos en el idioma del mercado. Mostrar los textos y esperar OK antes de guardarlos.

## 4. Upsells y downsells de un clic (después del pago)

Hotmart permite ofrecer productos después de la compra con **compra de un clic** (sin volver a cargar la tarjeta) usando su configuración de embudo de ventas / upsell y un **fragmento de código o widget que se pega en la página del upsell** (botón "Sí, lo quiero" y enlace "No, gracias"). En el panel:
1. Crear el **embudo** del producto principal con los pasos del plan (paso 0).
2. Para cada upsell/downsell: elegir el producto y la oferta de Hotmart, y la **URL de su página**.
3. Configurar a dónde va cada respuesta: SÍ → siguiente paso; NO → downsell (si existe) o siguiente paso; al final → página de gracias.
4. Copiar el código/widget que da Hotmart para cada paso y pegarlo en su página.

**Páginas de upsell/downsell** (las arma Claude, en HTML, en el idioma del mercado):
- Título: "¡Espera! Tu compra está confirmada — antes de entrar, mirá esto".
- Qué es el upsell, para qué le sirve **a quien ya compró el principal**, qué incluye, precio (con `data-usd` y el conversor de moneda por IP de `prompts/CONVERSOR_MONEDA_POR_IP.md`).
- Botón grande de SÍ (el widget de Hotmart) y enlace chico de NO.
- Sin contadores falsos ni "solo por hoy" si no es real.
- Downsell: "Entiendo, ¿y si te lo dejo en versión [más chica] por US$X?".
Subirlas donde el usuario aloja sus landings y anotar las URLs.

## 5. Página de gracias

Confirmación de compra, cómo acceder (mail de Hotmart / área de miembros), qué hacer si no llega el mail (revisar spam), contacto de soporte. Opcional: invitación a la comunidad.

## 6. Prueba completa

- Recorrer el checkout **sin pagar**: idioma, precio, moneda, bumps visibles y con texto correcto.
- **Compra de prueba: la hace la persona** (o con el modo/herramienta de prueba que ofrezca Hotmart). Verificar: cobro del principal + bumps marcados, aparición de cada upsell, que el NO lleve al downsell, que el SÍ cobre con un clic, que llegue el acceso de cada producto comprado, que el píxel registre la compra en Meta, y la página de gracias.
- Si algo falla, corregir y repetir.

## 7. Registro

- Ficha del producto (`03_PRODUCTOS\`): escalera con IDs/códigos de Hotmart, precios y URLs de cada página; estado "activo".
- `04_CONTENIDOS\PAGINAS_DE_VENTA.md`: landing, páginas de upsell/downsell y gracias.
- Checklist con ✅ en `D:\segundo-cerebro\06_PROYECTOS\[producto]_lanzamiento.md`.
- Siguiente: `revisar-landing` → anuncios (`creativos-placas`, `anuncio-storytime-controversial`) → `operador-meta-ads`.

## Reglas

- Nada se publica ni se guarda en Hotmart sin el OK de la persona para ese paso.
- Precios y promesas = ficha del producto. Sin descuentos, escasez ni testimonios que no sean reales.
- Nunca escribir contraseñas, datos de tarjeta o bancarios.
