---
name: "meta-ads-mentor-method"
description: "Use whenever diagnosing, building, scaling, or recovering a Meta Ads campaign for el usuario — apply this method before giving targeting, budget, structure, or scaling advice."
---

# Manual Maestro de Meta Ads (método del mentor de Mat)

Fuente: síntesis de 16 clases de un curso de Meta Ads que el usuario compró. Esto es EL MÉTODO DEL MENTOR, no una verdad universal de Meta ni mi propia opinión. Cuando una recomendación viene de acá, decilo como "según el método del mentor" o similar; cuando agregue una inferencia mía que el curso no cubre, decilo aparte y explícitamente ("esto no está definido por el curso, es mi lectura").

Siempre que analice o arme una campaña real del usuario, sigo el protocolo de la sección 10 y separo: Estado actual → Diagnóstico → Qué dice el mentor → Qué haría ahora → Qué NO tocar todavía → Cuándo volver a mirar → Qué dato falta.

## 1. Flujo maestro (las 9 etapas)

TESTEAR (validar ángulos/creativos, ABO o Microtesting) → IDENTIFICAR GANADORES → ESCALAR (CBO 1-1-1, Pocket, Mix, Power, Gold) → ESTABILIZAR/EMPUJAR (escala gradual, agresiva o surfing) → CONTROLAR RENTABILIDAD (ROAS, CPA, AOV, conversión) → RECUPERAR (reemplazar anuncios antes que apagar, si hay historial) → AMPLIAR PÚBLICO (exclusión de interactuadores, lookalike de compradores, audiencia guardada) → CONSOLIDAR (Cash Trap si aplica al negocio) → EXPANDIR MERCADOS (separar por idioma/país).

Arquitectura de cuenta: el mentor recomienda no acumular campañas en una misma cuenta — referencia 1–3 campañas por cuenta, separando testing / escala / manuales en cuentas distintas cuando sea posible. En Cash Trap: una sola campaña por cuenta.

## 2. Testing: validar antes de escalar

**ABO normal** (Clase 1): 1 conjunto = 1 anuncio. Presupuesto ~USD 10/día por conjunto para productos de USD 10–25. Ventana: 48–72 h (día 3 solo si ya hubo 1–2 ventas/señales). Evento optimizado: Compra. Audiencia abierta/Advantage. Preferencia del mentor por móvil + Facebook/Instagram. Nuevos testeos cada 3–6 días aprox., no todos los días.

**Microtesting** (Clase 2): mismo 1 anuncio por conjunto pero micropresupuesto y mucho volumen de creativos (20–50/día posible). Decisión en 24 h: apagar lo que no vendió, conservar lo que vendió, duplicar y rotar creativo. Si nada vendió, conservar temporalmente 2–4 con CPC más bajo. Presupuesto de ejemplo: USD 3.50 (producto 10–15), USD 5–6 (20–25), USD 10 (50–60).

**Regla 70/30**: 70% del esfuerzo creativo en variaciones del ángulo ganador (mismo audio+video nuevo / mismo video+audio nuevo / mismo cuerpo+gancho nuevo en primeros ~5s), 30% en ángulos nuevos.

**"Ganador"** es contextual, no un umbral universal: en ABO/Pocket se habla de anuncios con ventas (ej. 3–4 antes de pasar a Pocket); en Microtesting, una venta con micropresupuesto ya es señal fuerte, y si no hay ventas, el CPC bajo es criterio secundario. El curso NO fija un número universal de ventas/gasto/ROAS que defina "ganador" para todo producto — no inventar ese umbral.

## 3. No repetir el mismo anuncio en varias campañas de escala

Regla operativa (Clase 3): un anuncio exacto → una sola campaña de escala. Para abrir otra estructura, usar una variación creativa, no el mismo anuncio idéntico (Meta prioriza la campaña con más presupuesto y el anuncio compite contra sí mismo). Post ID se usa para trasladar el ganador a CBO 1-1-1. Arquitectura preferida: cuenta de testing / cuenta de escala / cuenta de campañas manuales, separadas.

## 4. Estructuras de escala automáticas

| Estructura | Conjuntos | Contenido | Presupuesto inicio | Espera |
|---|---|---|---|---|
| CBO 1-1-1 | 1 | 1 anuncio ganador | ~USD 35 (productos ~15–30) | mínimo 2 días |
| Pocket reducida | 3 | mismo ganador repetido | USD 35; USD 50 si agresivo | 48h, hasta 72h con señales |
| Pocket común | 5 | mismo ganador repetido | ídem | ídem |
| Pocket ampliada | 7–8 | mismo ganador repetido | ídem | ídem |
| Mix / Power | varios conjuntos | 3–5 ganadores distintos por conjunto, duplicar conjunto 4–5 veces | 50–75 inicial, luego 75–135 recomendado, 100 buen número | 48–72h |
| Gold | 1 | mínimo 3 ganadores, ejemplos con 5, 7+ | relacionar con cantidad de anuncios y precio (ej. producto USD10 + 5 anuncios ≈ USD50) | 48–72h, puede traccionar más fuerte días 3–5 |

En Pocket: NO apagar conjuntos solo porque gastan poco o no venden (en CBO el presupuesto no se reparte uniforme); solo apagar un conjunto si consume mucho presupuesto sin vender mientras otros sí venden. Máximo orientativo: 2–3 campañas Pocket por cuenta.

Matriz de elección: 1 ganador recién validado → CBO 1-1-1. 1 ganador fuerte + microsegmentaciones → Pocket. Varios ganadores → Mix/Power. Varios ganadores + querer simplicidad → Gold. El curso NO define una estructura "mejor" universal — depende de cada cuenta, tratarlo como prueba propia.

Etapa avanzada (Clase 11, ángulos ya validados): saltar el 1-1-1 como testing predominante y salir directo con Gold/Mix/Power/Pocket/CBO común con más presupuesto (ejemplos: USD 75–135 o USD 50–100 según estructura). No repetir el mismo anuncio exacto en varias campañas.

## 5. Campañas manuales: Cost Cap y Bid Cap

Requisito común: usar anuncios que YA demostraron que venden, no para testear creativos nuevos.

**Cost Cap**: partir del CPA/costo por compra ya existente en la cuenta. Crear ABO con el mismo anuncio ganador en varios conjuntos, cada uno con un objetivo de costo distinto (ej. USD 9, 10, 11, 12). Ver cuál logra ventas/profit y usar ese objetivo en una CBO Cost Cap con varios ganadores. Con ROAS ≥2 y venta a buen costo, duplicar presupuesto durante el surfing. Presupuesto de prueba ABO: 100–150 (Meta no necesariamente lo gasta todo); CBO Cost Cap de arranque: 250–500 (también aparecen 300/500/1000).

**Bid Cap**: fija el límite máximo de puja (el costo real de Cost Cap puede moverse alrededor del objetivo; Bid Cap no puja por encima del límite). Mínimo 4–10 anuncios ganadores. Empezar el bid cerca del precio del producto (ej. producto USD20 → Bid Cap USD20, después probar 15 o 10 si la cuenta ya es estable). Escalar agresivo durante el día con ventas a buen costo, bajar presupuesto al final del día (no necesariamente al punto de partida: ej. si arrancó en 50 y llegó a 4000, bajar a 200 para el ciclo siguiente). Si la campaña "muere": duplicar y dejar activos los anuncios ganadores que no habían gastado/vendido, para forzar distribución hacia ellos.

## 6. Metodología de escalado

- **Escala gradual** (ABO): con >3 ventas, subir ~20–30%, esperar 48–72h entre incrementos. Referencia de rentabilidad: ROAS ~1.8–2. Una sola venta puede ser casualidad — esperar más confirmación antes de tocar presupuesto.
- **Escala agresiva** (CBO): después de mínimo 48h, con ROAS 2–3 se puede duplicar o triplicar presupuesto.
- **Surfing**: la más agresiva — subir presupuesto varias veces en un día fuerte mientras siguen entrando ventas rentables. Ejemplo ilustrativo (no tabla universal): 35→70→150→300→1000→2000→4000. Concentrar los incrementos en las horas pico del propio historial. Por la noche, bajar presupuesto.
- **Tirón de oreja**: si el CPA se acerca al break-even, bajar presupuesto 20–30% y esperar ~2 días; si no se recupera, apagar (o evaluar reemplazo de anuncios si la campaña tiene historial — ver sección 8).
- **Pixel "optimizado"**: el mentor insiste en al menos 50 ventas/semana, idealmente 100+, para sostener escalas agresivas y surfing.
- **Historial de ventas**: después de ~2 semanas vendiendo, descargar historial y mirar patrones propios de día/hora/país — NO aplicar los patrones de ejemplo de la clase (jueves peor día, lunes/martes/viernes/domingo mejores, pico 13–21h) como regla universal; son de una cuenta de ejemplo. La regla transferible es: usar TU historial, no días genéricos.

## 7. Recuperar una campaña que dejó de vender (Clase 12)

Aplica cuando: la campaña tiene historial y vendió bien un tiempo, empezó a deteriorarse, ya recibió tirón de oreja/ajustes y no recuperó, y el problema parece estar en los anuncios (no en que la campaña nunca haya validado).

Procedimiento exacto — NO apagar la campaña completa:
1. Identificar los anuncios a reemplazar.
2. Duplicar el anuncio viejo.
3. En el duplicado, reemplazar el creativo por uno nuevo.
4. Publicar el duplicado.
5. Recién después, apagar el anuncio viejo.
6. Mantener la misma cantidad de anuncios/conjuntos que tenía la estructura (Pocket: reemplazar conjunto por conjunto sin alterar la arquitectura; Power: 5 por 5; Mix: igual cantidad; Gold: duplicar/reemplazar sin destruir el historial de campaña).
7. Si se reemplazan varios, hacerlo en la misma intervención.
8. Esperar 48–72h para evaluar recuperación.

## 8. Públicos y audiencias (Clase 13)

- **Revivir anuncio agotado**: crear audiencia personalizada de interacción con publicaciones/anuncios → crear campaña nueva con el anuncio ganador agotado → EXCLUIR esa audiencia → dejar que Meta busque gente que todavía no interactuó.
- **Lookalike de compradores**: audiencia personalizada de compradores → lookalike (empezar con 1%) → usar como SUGERENCIA, no como exclusión. Puede salir algo más cara pero busca audiencia más calificada.
- **Audiencia guardada**: si una campaña/conjunto acumula ventas a buen costo, guardar esa audiencia y usarla como sugerencia en campañas de escala nuevas (la campaña sigue Advantage/abierta, no arranca 100% de cero).

## 9. Método Cash Trap (Clase 14)

Una sola campaña evergreen, mínima intervención, diversidad creativa. Pensado para negocio "lifestyle boutique" sin estar todo el día en Ads Manager.

Estructura: 1 cuenta = 1 campaña (CBO Gold/Cash Trap), 1 conjunto, audiencia Advantage/abierta, 5–7 anuncios iniciales con formatos diversos (carrusel, estático 1:1, horizontal 16:9, Reel 9:16). Presupuesto inicial: el curso NO lo define con precisión (parte de transcripción dañada) — no inventar una cifra única.

Tiempos: dejar correr 48h sin decisiones → revisar día 3 → si vende, dejarla llegar a ~día 5 antes de intervenir → día 5–6 si sigue vendiendo, empezar a escalar. Con ROAS >2: subidas de 30–40% e incluso 50%; si no, ~20% cada 2–3 días. Subir presupuesto a medianoche. No subir presupuesto y reemplazar anuncios en la misma intervención. Después de reemplazar creativos, esperar 2–3 días. Si se rompe, tirón de oreja y estabilizar 2–3 días.

Gestión de anuncios: reemplazar los que gastan y no venden o venden muy caro. No apagar por ansiedad un anuncio que recién tuvo su primera venta cara — darle ~3 días. Anuncios que no gastan: dejarlos, a veces arrancan a las 2–3 semanas; si pasa ~1 mes sin gasto, considerar reemplazo. Con presupuestos altos y estables (~USD 300–400 ejemplo), se pueden sumar 2 anuncios nuevos, y después dejar 5–7 días sin tocar.

## 10. Mercados internacionales y multi-idioma (Clase 15)

Principio: expandir un producto YA validado a otros mercados/idiomas, en vez de depender solo de lanzar productos nuevos. Producto validado en Argentina/Brasil → probar inglés, francés o alemán. Producto validado en inglés/francés/alemán → probar mercado hispanohablante. Desde Brasil, también se puede probar LatAm o mercados menos competidos.

Para inglés, el mentor menciona Estados Unidos, Canadá, Reino Unido, Israel, y destaca Sudáfrica especialmente para low-ticket. Para francés/alemán: Europa o país específico. (Esto explica por qué CA/UK/ZA/US es una combinación que sigue la lógica del curso, no un invento nuestro.)

Separación de infraestructura por idioma: pixel propio, landing/web propia y traducida, cuenta de Instagram separada, cuenta publicitaria separada — el mentor lo justifica porque las cuentas acumulan "memoria/historial" y no quiere mezclar idiomas/pixels/públicos.

Precio entre mercados: como punto de partida, mantener el mismo ticket si las audiencias de distintos idiomas pueden cruzarse (ejemplo del curso: mismo producto a USD21 en español y USD60 en inglés generó fricción cuando usuarios vieron ambos precios). Si se cambia el ticket, evitar solapamiento geográfico/de audiencias.

## 11. Métricas y diagnóstico (Clase 16)

Cadena causal que enseña el mentor: mejor gancho → más gente sigue viendo → más clicks → CTR más alto → CPC más bajo → más tráfico con el mismo presupuesto → después, calidad de clic y conversión web determinan cuánto de ese tráfico llega a la página y compra.

Fórmulas:
- Hook rate = reproducciones de video de 3s / impresiones.
- Calidad de clic = landing page views / clicks en el enlace.

Benchmarks que sí da el curso:
| Métrica | Referencia |
|---|---|
| Conversión web (compras/visitas) | ~2% o más |
| Checkout → compra | ~50% |
| Hook rate | ideal >50% |
| CTR enlace | <1.5% se considera bajo |
| Calidad de clic | benchmark principal >65% (hay una mención suelta a 75% en el audio, pero el manual usa 65% por consistencia con la fórmula) |

Otras métricas sin benchmark fijo del curso: CPM (varía por nicho/demanda/calidad), frecuencia (preocupa solo si sube y la campaña entra en pérdida/break-even), retención de video (sin umbral único).

## 12. Árboles de decisión rápidos

**Campaña nueva que todavía no vende**: ¿está dentro de su ventana mínima? (ABO 48h / Microtesting 24h / CBO escala 48h mínimo) → si sí, no decidir todavía. Si ya pasó la ventana: revisar hook rate (bajo → trabajar gancho) → CTR (<1.5% bajo) → CPC (debería bajar si hook/CTR mejoran) → calidad de clic (<65% → investigar carga/velocidad de página) → conversión web (referencia ~2%+) → checkout→compra (referencia ~50%). Si todo esto está bien y aun así no hay ventas, el curso contempla que el problema sea el producto/oferta en sí.

**Anuncio ganador de testing**: no usar el mismo anuncio exacto en varias campañas de escala a la vez. Elegir estructura (1-1-1 para aislar / Pocket para duplicar microsegmentaciones / Gold-Mix-Power si ya hay varios ganadores). Dar a la CBO nueva mínimo 48h. Si vende con buen ROAS, aplicar escala gradual o agresiva según etapa. Crear variaciones del ganador para alimentar otras estructuras.

**Campaña que vendía bien y dejó de vender**: confirmar que tiene historial real (si nunca validó, esto no aplica). Si corresponde, tirón de oreja (−20–30%) y esperar ~2 días. Si no recupera y los anuncios parecen agotados: NO apagar completa — aplicar el procedimiento de duplicar/reemplazar/apagar de la sección 7, manteniendo la misma cantidad de anuncios/conjuntos, esperar 48–72h. Si el ganador parece saturado frente a la audiencia, considerar campaña nueva excluyendo interactuadores (sección 8).

**Campaña vende pero el costo roza el break-even**: comparar CPA/costo por resultado con precio y AOV real. Si llega al break-even, bajar presupuesto 20–30%, esperar ~2 días. Si no se estabiliza, apagar según esa lógica — pero si la campaña tiene historial, antes de descartarla evaluar el procedimiento de reemplazo de anuncios de la sección 7.

**Quiero escalar una campaña que ya vende**: confirmar que superó la ventana mínima de observación de su estructura. ABO con >3 ventas: 20–30% cada 48–72h. CBO automática con ROAS 2–3: duplicar/triplicar; con ~1.7–1.9: +30%. Surfing solo en días/horas fuertes del PROPIO historial. Bajar presupuesto de noche. Si el CPA se deteriora hacia break-even, tirón de oreja.

**Muchos checkouts iniciados, pocas compras**: calcular checkout→compra y comparar con ~50%. Si está muy por debajo, el cuello de botella está después del checkout iniciado — no diagnosticar solo como problema de anuncio. El curso no da protocolo detallado de optimización de checkout técnico; eso requiere análisis fuera del método (ej. medios de pago, errores técnicos, confianza, impuestos).

## 13. Protocolo de consulta rápida (formato de respuesta obligatorio para diagnósticos reales)

Cuando analice una campaña real del usuario, estructurar la respuesta así:
1. **Estado actual**: estructura, edad, presupuesto, ventas, CPA, ROAS, AOV.
2. **Diagnóstico**: cuello de botella según las métricas disponibles.
3. **Qué dice el mentor**: citar la regla y la clase/sección relevante de este manual.
4. **Qué haría ahora según el método**: UNA sola intervención prioritaria — evitar tocar varias variables a la vez.
5. **Qué NO tocar todavía**: proteger la ventana mínima de observación/aprendizaje de la estructura en juego.
6. **Cuándo volver a mirar**: 24h / 48h / 72h / 2–3 días, según la estructura y regla aplicable.
7. **Qué dato falta**: si el manual no permite decidir con lo que hay, pedir la métrica puntual que falta — no inventarla.

Separar siempre cualquier recomendación mía que NO sea del método del mentor (ej. sugerencias de checkout, copy, landing) marcándola como análisis externo al curso.

## 14. Plantilla de datos a pedir para diagnosticar

Estructura (ABO/CBO 1-1-1/Pocket/Mix/Power/Gold/Cost Cap/Bid Cap/Cash Trap) · edad de campaña · presupuesto actual · gasto del período · ventas · ingresos · CPA · ROAS · AOV · CPM · hook rate · CTR enlace · CPC enlace · clicks enlace · landing page views · calidad de clic · conversión web · add to cart · checkouts iniciados · checkout→compra · frecuencia · cambios recientes (presupuesto/anuncios/audiencia/landing/checkout) · historial (¿vendió bien antes? ¿cuántas ventas?) · objetivo (testear/escalar/estabilizar/recuperar).

Orden de lectura recomendado: 1) etapa y estructura → 2) tiempo transcurrido desde lanzamiento/cambio → 3) resultado económico (ventas, CPA, ROAS, AOV) → 4) creativo (hook, CTR, CPC, CPM) → 5) tráfico real (landing page views, calidad de clic) → 6) sitio y checkout → 7) historial y cambios recientes → 8) recién ahí decidir: mantener, escalar, bajar, reemplazar o apagar.

## 15. Lo que el curso NO define (no inventar umbrales acá)

- CPA "bueno" universal para cualquier producto.
- ROAS mínimo universal para apagar cualquier campaña en cualquier momento.
- Cantidad exacta de gasto sin venta que obligue a apagar siempre.
- Definición única de "anuncio ganador" válida para todos los tickets.
- Fórmula completa de break-even con fees, refunds, impuestos, envío.
- Protocolo exhaustivo de errores técnicos de checkout/Shopify.
- Presupuesto inicial inequívoco de Cash Trap.
- Diferencia formal exacta entre todas las variantes Mix vs Power.
- Una estrategia de país/día/horario universal — los ejemplos de Clase 10 son de una cuenta puntual, no una regla general.

Si una decisión no se puede justificar con una regla de este manual ni con datos suficientes de la campaña, decirlo explícitamente ("el manual no define un umbral exacto para esto") en vez de inventar una cifra, y separar cualquier recomendación adicional como análisis externo al método.

## 16. Glosario rápido

ABO = presupuesto a nivel conjunto (testeo individual). CBO = presupuesto a nivel campaña (Meta reparte entre conjuntos). CBO 1-1-1 = 1 campaña/1 conjunto/1 ganador. Pocket = CBO con varios conjuntos, todos con el mismo ganador (reducida 3 / común 5 / ampliada 7–8). Gold = 1 conjunto con varios ganadores. Mix/Power = múltiples ganadores por conjunto + mayor concentración de presupuesto, duplicando conjuntos. Cost Cap = estrategia manual con objetivo de costo por resultado. Bid Cap = estrategia manual con límite máximo de puja. Surfing = escalado intradía agresivo mientras entran ventas rentables. Tirón de oreja = bajar presupuesto para recuperar costos. Cash Trap = 1 campaña evergreen, 1 conjunto, diversidad creativa, mínima intervención. Ángulo ganador = enfoque de venta que ya demostró respuesta en testing. Variación creativa = nueva ejecución del mismo ángulo (video/audio/gancho/formato distinto, nunca el anuncio idéntico).