---
name: "modelar-ofertas"
description: "Usar esta skill cada vez que el alumno (o Mat) quiera clonar, modelar o adaptar una oferta que ya funciona — una landing page, un quiz/funnel de preguntas, una sales page, un VSL o cualquier embudo de ventas — a un nuevo idioma, con su propia estética, paleta de colores, avatar de marca e imágenes generadas con el motor de IA que tenga conectado. Activar también si pega el HTML, capturas de pantalla o un link de una oferta ganadora (propia o de otro nicho/idioma) y pide \"modelar esto\", \"clonar este funnel\", \"traducir y rediseñar esta landing\", \"adaptar este quiz a mi marca\", \"hacer mi propia versión de esto\", incluso si no menciona la palabra \"skill\" o \"modelar\" explícitamente."
---

# Modelar Ofertas

## Qué hace esta skill

Toma una oferta que ya está funcionando — landing page, quiz, sales page, VSL o cualquier embudo — y produce una versión nueva: mismo mecanismo de venta y misma estructura psicológica, pero en otro idioma, con la estética y colores del alumno, y con imágenes propias generadas por el motor de IA que el alumno tenga conectado (Higgsfield, generación de imágenes nativa, o cualquier otro — nunca asumas uno fijo, revisá qué hay disponible en la sesión antes de arrancar).

La idea de fondo: lo que hace ganadora a una oferta es su estructura — cómo está armado el quiz, qué gatillos psicológicos usa el copy, en qué orden aparecen las cosas. Eso se conserva intacto. Lo que cambia es el idioma, la piel visual y las imágenes, para que el alumno pueda salir a vender con una oferta que es genuinamente suya, no una copia literal.

## Paso 0 — Reunir lo que falta antes de empezar

No arranques a construir sin tener claro:

1. **El material fuente**: el HTML, las capturas, o el link de la oferta a modelar. Si falta, pedilo — no se puede modelar lo que no se ve.
2. **Idioma de destino**: a qué idioma/mercado va (ej. español neutro para vender en toda Latinoamérica, portugués, inglés, etc.).
3. **Estética nueva**: paleta de colores, tono visual (si no la define, proponé 2-3 opciones coherentes con el nicho en vez de adivinar una sola).
4. **Avatar o marca**: si la oferta original tiene un personaje/autor ficticio, preguntá si quiere mantener ese arquetipo con otra cara/nombre adaptado al nuevo mercado, o si tiene su propio avatar de marca para reusar.
5. **Motor de imágenes disponible**: revisá qué herramientas de generación de imágenes están conectadas en la sesión (MCP de Higgsfield, generación nativa, etc.) antes de generar nada. Si hay más de una, preguntá cuál prefiere usar.

Si el alumno ya dio todo esto en su mensaje, no hace falta volver a preguntar — seguí directo al Paso 1.

## Paso 1 — Analizar la oferta original

Antes de traducir o rediseñar nada, entendé la estructura completa:

- Si es un **quiz/funnel**: qué preguntas hace, en qué orden, qué lógica de branching tiene, qué resultado muestra al final.
- Si es una **landing/sales page**: qué secciones tiene (hero, dolor, promesa, prueba social, oferta, CTA, garantía, FAQ) y en qué orden aparecen.
- Qué imágenes hay y qué rol cumple cada una (gancho emocional, prueba social, producto, autor/avatar).
- Qué bloques de copy son el verdadero motor de venta (suelen ser el texto largo tipo "story time" o el guión del VSL, no solo los títulos) — identificalos porque van a necesitar la traducción más cuidadosa de todas.

Un error común es traducir y recolorear sin primero mapear esto: termina perdiéndose piezas o cambiando el orden sin querer.

## Paso 2 — Traducir todo el copy

- Traducí el sentido y la intención psicológica, no palabra por palabra. Un gatillo emocional que funciona en un idioma puede sonar forzado traducido literal — adaptalo para que suene natural en el idioma de destino.
- Si el idioma de destino es español y el público es "todo el mercado hispanohablante" (no un solo país), usá español neutro (tú/usted según corresponda) y evitá modismos regionales marcados (voseo argentino, por ejemplo), salvo que el alumno pida explícitamente un dialecto.
- Revisá el resultado buscando mezclas de idioma accidentales o modismos que se filtraron del idioma original.
- Los bloques largos de "story time" / guión emocional son los que más venden — dedicales el cuidado extra en vez de tratarlos como texto de relleno.

## Paso 3 — Recolorear y adaptar la estética

- Si es HTML, definí la paleta nueva como variables CSS (custom properties) en un solo lugar, nunca coloreando elemento por elemento — así un cambio de paleta no rompe nada y es fácil ajustar después.
- Mantené el layout y la experiencia de usuario intactos. Lo que cambia es la piel visual (colores, tipografía si corresponde), no la estructura que ya está probada y funciona.
- Si el alumno no tiene paleta definida, proponé 2-3 paletas coherentes con el nicho antes de elegir una.

## Paso 4 — Regenerar las imágenes con el motor que tenga conectado

- Nunca reutilices las imágenes originales tal cual — son de otra oferta, en otro idioma/mercado, y probablemente con otra estética.
- Escribí los prompts de generación en inglés (es lo que mejor entienden la mayoría de los motores de imagen), describiendo solo la escena/sujeto. Nunca le pidas al motor de imágenes que dibuje el texto de venta dentro de la imagen — los motores de IA cometen errores tipográficos difíciles de corregir. Si una imagen necesita texto superpuesto (un gancho, un titular), generá el fondo limpio sin texto y compaginá el texto por separado con código (HTML/CSS si es para web, o una composición con una librería de imágenes si es un archivo final), usando una tipografía del sistema.
- Si la oferta original tiene un avatar/personaje de autor, creá uno nuevo coherente con el mercado de destino (mismo arquetipo narrativo — ej. "especialista que vivió el problema en carne propia" — pero con otra apariencia/nombre), salvo que el alumno ya tenga su propio avatar de marca para reusar.
- Cuando el alumno tenga más de un motor de imágenes conectado, generá una muestra con cada uno si no especificó cuál prefiere, para que elija.

## Paso 5 — Armar el entregable final

- Si el original era una landing/quiz en HTML, entregá un único archivo HTML autocontenido (CSS y JS inline, sin dependencias externas) listo para pegar en Netlify, Systeme.io o la plataforma que use el alumno — igual que el formato en que vino el original, salvo que pida otra cosa.
- Cuando algo necesite un dato que solo el alumno tiene (link de checkout, link de la plataforma de pago, su propio pixel), dejá un placeholder bien visible en mayúsculas (ej. `PEGA-AQUI-TU-LINK-DE-CHECKOUT`) en vez de inventar un valor — nunca generes ni completes datos de pago o cuentas reales.

## Paso 6 — Verificar antes de entregar

Antes de dar por terminado, revisá (renderizando el HTML o mirando el archivo final):

- Que no haya texto mezclado en dos idiomas.
- Que el layout no se haya roto al cambiar colores o imágenes.
- Que todas las imágenes nuevas carguen y encajen en el espacio que ocupaban las originales.
- Que los placeholders que dejaste estén claramente marcados.

## Entrega

Entregá el archivo final y un resumen breve de qué cambiaste (idioma, paleta, imágenes, avatar) y qué placeholders dejaste pendientes de completar por el alumno. No hace falta un informe largo — el alumno ya conoce su oferta, lo que necesita es el archivo y saber qué le falta tocar.