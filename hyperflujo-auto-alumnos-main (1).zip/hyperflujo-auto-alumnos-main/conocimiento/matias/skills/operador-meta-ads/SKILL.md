---
name: "operador-meta-ads"
description: "Opera las cuentas de Meta Ads de Mat con su método Cash Trap / Andrómeda: lee campañas y anuncios, diagnostica con sus reglas (48 h, ROAS 2 / 1,5, break-even = precio del producto principal), propone qué anuncio cambiar por otro del mismo nivel de conciencia (C1/C2/C3) usando un banco de reserva (ángulo nuevo, o el mismo ángulo en otro formato si funciona), arma estructuras y carga anuncios siempre en pausa. Modo automático (Mat, 2026-10-22 y 24): aplica las reglas solo, sin pedir el 'dale', y avisa en una línea qué cambió y por qué. Usar cuando se pida 'revisá mis campañas', 'cambiá el anuncio que no vende', 'armá la Cash Trap en la cuenta', 'cargá los anuncios', o en la revisión diaria."
---

# Operador de Meta Ads (automático)

El método manda: `D:\segundo-cerebro\05_PROCESOS\ESTRATEGIA_DE_ANUNCIOS.md` y la skill `cash-trap-cbo-oro`. Esta skill solo **ejecuta** ese método en la cuenta.

## Regla de oro

**Modo automático (Mat, 2026-10-22: «el agente puede prender las campañas solo»; 2026-10-24: «yo no quiero que me pidas permiso de nada»):** se lee, se decide con el método y **se aplica** el cambio (pausar, prender, crear, subir presupuesto, cambiar un anuncio), avisando en una línea qué se hizo y por qué regla. Todo lo nuevo se crea en pausa y se prende a la medianoche. Frena solo un presupuesto por encima del tope escrito.

## Datos que usa

- **Break-even por compra = precio del producto principal** (ficha en `03_PRODUCTOS\`). Bumps/upsells/downsells no cuentan.
- **ROAS bueno:** 2 o más; con USD 1.000/día o más, 1,5.
- **Tiempos:** nada en las primeras 48 h completas; un solo cambio por vez (presupuesto **o** anuncios, nunca los dos el mismo día); 3 días de espera entre decisiones.
- **Estructura:** 1 campaña por cuenta, 1 conjunto, 9 anuncios (3 C1, 3 C2, 3 C3) nombrados con su nivel; país + idioma (en español: Español, Español (España), Español (todos)); ubicaciones Advantage+; puntuación de Meta ≥ 90%.

## Revisión (diaria o cuando se pida)

1. Leer las campañas activas de las cuentas (gasto, compras, costo por compra, ROAS, frecuencia, CTR) y la fecha de inicio / último cambio.
2. Para cada campaña decidir con el método:
   - **En ventana de aprendizaje** (menos de 48 h desde el inicio o menos de 3 días del último cambio) → no tocar; decir cuándo se mira.
   - **ROAS de campaña ≥ 2** → no tocar ningún anuncio, aunque alguno sea caro. Si pasaron 48 h del arranque (USD 50/día) o del último aumento, proponer **+30% de presupuesto** (con el monto nuevo). Regla de escala: +30% cada 48 h mientras siga en ROAS 2+, hasta el tope diario definido por la persona.
   - **ROAS de campaña bajando o por debajo del objetivo** → buscar el anuncio que **gastó ≥ break-even sin ninguna compra** (o el peor costo por compra) y proponer:
     - pausar ese anuncio, y
     - prender **uno del banco de reserva del mismo nivel** (C1→C1, C2→C2, C3→C3).
   - **A las 48 h, según el ROAS de la campaña** (regla de la persona, 2026-10-19):
     - **sin ventas** → proponer **apagar la campaña** y repensar el producto/oferta;
     - **vende pero ROAS < 2** (break-even, 1,5) → **no escalar, dejar correr** sin tocar nada, hasta 5 días seguidos;
     - **ROAS ≥ 2** → proponer **+30%**.
   - Después: **cualquier día que la campaña esté en ROAS ≥ 2**, proponer +30% (mínimo 48 h entre aumentos).
3. Entregar el reporte con el formato de la sección 10 de `cash-trap-cbo-oro`: Estado → Diagnóstico → Qué dice el método → Qué hacer (UNA acción) → Qué no tocar → Cuándo volver a mirar.

## Banco de reserva

- Por cada campaña, tener **2 anuncios de reserva por nivel** (6 en total), aprobados por la persona y **cargados en pausa**, con nombre `RES-C1-[ángulo]-[formato]`, `RES-C2-...`, `RES-C3-...` (ej.: `RES-C1-suegra-placa`, `RES-C2-3errores-carrusel`). El ángulo y el formato en el nombre permiten elegir bien el reemplazo.
- Si no hay reserva del nivel que hace falta, avisar y proponer crearla (skills `creativos-placas`, `anuncio-storytime-controversial`, `ugc-video-hiperrealista`).
- Al usar uno, quitarle el "RES-" del nombre para que quede como C1/C2/C3 activo.

## Armar una Cash Trap en la cuenta

Con los 9 creativos aprobados: crear campaña de ventas (CBO, Advantage+), 1 conjunto con país + idioma y ubicaciones Advantage+, y los 9 anuncios **en pausa**. Mostrar la puntuación de recomendación de Meta y el presupuesto propuesto (precio del producto × 9 como mínimo). Prender solo con el "dale" y, por método, a la medianoche.

## Registro

Cada cambio aplicado se anota en `D:\segundo-cerebro\07_REVISIONES\cambios-meta.md`:
`AAAA-MM-DD HH:MM — cuenta — campaña — qué se cambió — por qué (regla) — aprobado por la persona`.

## Reglas

- Nunca crear cuentas, cambiar medios de pago, permisos, píxeles ni configuraciones de la cuenta.
- Nunca cloaking ni nada que esconda la página real a Meta.
- Si una herramienta devuelve un error o un dato raro, decirlo; no reintentar cambios a ciegas.
- Modo automático desde el 2026-10-22 (antes, semi-automático): la persona ya no aprueba cada cambio; se le informa.
- Cómo elegir el reemplazo: se cambian los anuncios con costo por venta mayor al precio, los que gastaron el precio sin vender y los que no gastaron (Mat, 2026-10-25); si el ángulo del anuncio apagado funciona, el mismo ángulo en otro formato; si no, un ángulo nuevo del mismo nivel, siempre con escenas nuevas (alcance, Mat 31/10: es dentro del mismo producto en el mismo idioma; para otro idioma se pueden traducir y reusar las escenas de otro idioma).
