---
name: "quien-cobra"
description: "Averigua con qué plataforma cobra y entrega una oferta de la competencia (Hotmart, Kiwify, Eduzz, Monetizze, Perfect Pay, Shopify, Stripe, Gumroad, Systeme, etc.) y qué se puede ver de su embudo antes de pagar, mirando la landing y el link del checkout. Usar cuando se pida 'con qué cobra', 'qué plataforma usa', 'quién cobra esta oferta', o al estudiar una oferta para modelar."
model: sonnet
effort: low
---

# Quién cobra

## Pasos

1. Abrir la landing (navegador) y **no comprar ni cargar datos**.
2. Mirar el **link de los botones de compra** (sin hacer el pago) y el dominio del checkout:
   - `pay.hotmart.com` / `hotmart.com` → Hotmart
   - `pay.kiwify.com.br` / `kiwify` → Kiwify
   - `eduzz.com` / `sun.eduzz` → Eduzz
   - `monetizze` → Monetizze · `perfectpay` → Perfect Pay · `braip` → Braip
   - `checkout.stripe.com` → Stripe · `gumroad.com` → Gumroad · `/cart`, `myshopify.com` → Shopify
   - `systeme.io`, `clickfunnels`, `payhip`, `lemonsqueezy`, `mercadopago` → la que corresponda
   - Si el link pasa por un acortador o un dominio propio, abrir el checkout y mirar el dominio final y el pie de página.
3. Mirar en la página: logos de pago, textos tipo "compra segura con...", términos y condiciones, nombre del productor, píxeles visibles.
4. En el checkout (sin pagar): moneda, precio, **order bumps visibles**, garantía, cuotas.

## Entrega

| Oferta | Plataforma de cobro | Cómo se supo | Moneda / precio | Order bumps visibles | Garantía | Notas |

Upsells y downsells: se ven solo después de pagar → marcar "no visible sin comprar".

Guardar junto al análisis de la oferta (`D:\segundo-cerebro\06_PROYECTOS\ofertas\`).

## Reglas

- Nunca completar el pago ni cargar datos personales o de tarjeta.
- Si no se pudo saber, decir "desconocido", no adivinar.
