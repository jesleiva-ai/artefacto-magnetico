---
name: "respaldar-cerebro"
description: "Hace una copia de respaldo comprimida del segundo cerebro del usuario (D:\\segundo-cerebro) en D:\\respaldos-segundo-cerebro, con fecha y hora, sin instalar nada y sin tocar el disco C, y permite restaurar una versión anterior. Usar cuando se pida 'hacé un respaldo', 'backup del cerebro', 'guardá una copia', 'volvé a la versión de...', antes de cambios grandes en el cerebro, o una vez por semana."
model: sonnet
effort: low
---

# Respaldar el cerebro

## Hacer un respaldo

```
powershell -ExecutionPolicy Bypass -File "<carpeta de la skill>\scripts\respaldar.ps1"
```

Crea `D:\respaldos-segundo-cerebro\segundo-cerebro_AAAA-MM-DD_HHMM.zip` (sin carpetas temporales). Responder con el nombre y el tamaño.

**Cuándo:** antes de cambios grandes (jardín, importaciones de Codex, edición de muchas notas), y una vez por semana (se puede sumar a la revisión semanal).

## Restaurar

1. Listar los respaldos con fecha y tamaño.
2. La persona elige uno.
3. **Primero hacer un respaldo del estado actual** (por las dudas).
4. Descomprimir el elegido en `D:\segundo-cerebro_restaurado_AAAA-MM-DD` (carpeta nueva, **no encima** del cerebro actual) y mostrar qué archivos cambian.
5. Reemplazar solo lo que la persona apruebe.

## Reglas

- Nunca borrar respaldos solo: si hay más de 12, avisar y que decida la persona.
- Nada en el disco C salvo el archivo temporal que se borra al terminar.
