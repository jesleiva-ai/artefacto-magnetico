# Copia comprimida del segundo cerebro en D:\respaldos-segundo-cerebro
# Uso: powershell -ExecutionPolicy Bypass -File respaldar.ps1
$origen  = "D:\segundo-cerebro"
$destino = "D:\respaldos-segundo-cerebro"
New-Item -ItemType Directory -Force $destino | Out-Null

$fecha = Get-Date -Format "yyyy-MM-dd_HHmm"
$zip   = Join-Path $destino "segundo-cerebro_$fecha.zip"
$tmp   = Join-Path $env:TEMP "respaldo-cerebro-$fecha"

# Copia sin carpetas temporales, después comprime
robocopy $origen $tmp /E /XD "_tmp" "_tmp_pdf" /NFL /NDL /NJH /NJS /NP | Out-Null
Compress-Archive -Path "$tmp\*" -DestinationPath $zip -Force
Remove-Item $tmp -Recurse -Force

$mb = "{0:N1}" -f ((Get-Item $zip).Length / 1MB)
$total = (Get-ChildItem $destino -Filter "segundo-cerebro_*.zip").Count
Write-Output "Respaldo creado: $zip ($mb MB). Respaldos guardados: $total."
if ($total -gt 12) { Write-Output "Hay más de 12 respaldos: conviene revisar si se borran los más viejos (no se borran solos)." }
