---
name: "revisar-landing"
description: "Revisa una landing o página de venta de producto digital low-ticket antes de lanzarla (o una que no convierte) con el checklist del usuario: precios y escalera de valor, conversor de moneda por IP, checkout de Hotmart, garantía, celular, velocidad y que la página diga solo lo que el producto tiene. Usar cuando se pida 'revisá la landing', 'chequeá la página', 'por qué no convierte', o antes de largar una campaña."
model: sonnet
effort: medium
---

# Revisar landing

Se puede revisar desde un link (navegador) o desde el HTML. Fuentes de verdad:
- Ficha del producto: `D:\segundo-cerebro\03_PRODUCTOS\` (precio, qué incluye, bonos, garantía).
- Conversor: `D:\segundo-cerebro\prompts\CONVERSOR_MONEDA_POR_IP.md`.
- Registro de páginas: `D:\segundo-cerebro\04_CONTENIDOS\PAGINAS_DE_VENTA.md`.

## Checklist (cada punto: ✅ / ⚠️ / ❌ + qué se vio)

**1. Primera pantalla (sin scrollear, en celular)**
- Título con una promesa clara y verificable.
- Imagen o mockup del producto.
- Precio o botón visible pronto.

**2. Precios**
- Precio principal = el de la ficha del producto.
- Precio tachado / descuento: solo si es real y coincide con la ficha.
- Cada precio marcado con `data-usd` y el conversor por IP instalado (probar que muestre moneda local y que si falla quede en USD).
- Order bumps, upsell y downsell con los precios de la ficha.

**3. Checkout**
- Todos los botones llevan al checkout correcto de Hotmart (producto correcto).
- No hay botones rotos ni links a páginas viejas.
- Order bumps aparecen donde corresponde.
- No completar ni enviar el pago: solo comprobar que el link abre el checkout correcto.

**3b. Entrega y post-compra (Hotmart)**
- Página de gracias: explica cómo acceder y dónde llega el mail.
- Cada link de entrega (área de miembros, portal, archivos) abre y descarga; ningún archivo del producto queda en un link público abierto si se puede evitar.
- Los upsells/downsells muestran el precio y el producto correctos.
- Por país: el conversor muestra la moneda local esperada. Si no se puede probar desde otro país, marcar "no comprobado por país" y revisar al menos la lógica del conversor.

**4. Confianza**
- Garantía visible, con los días reales.
- Qué incluye, explicado (módulos, páginas, archivos, formato de entrega).
- Cómo se recibe el acceso (mail, portal).
- Testimonios solo si son reales. Sin contadores falsos, "últimos cupos" inventados ni notificaciones de compra falsas.
- Contacto / soporte, términos y privacidad.

**5. Coherencia con los anuncios**
- Lo que promete el anuncio aparece en la página (mismo producto, mismo precio, misma promesa).
- Idioma correcto en toda la página (sin restos del idioma original si es modelada).

**6. Técnica**
- Se ve bien en celular (sin cosas cortadas, letra legible).
- Carga rápido (sin imágenes enormes; si se puede medir, anotar el tiempo).
- Píxel de Meta instalado (si se puede ver desde el navegador).

**7. Políticas**
- Pasar la skill `chequeo-politicas-meta` sobre los textos principales.

## Entrega

1. Puntaje: X de 7 bloques sin ❌.
2. Lista de ❌ ordenada por impacto en ventas, con el arreglo concreto.
3. Lista de ⚠️ (mejoras opcionales).
4. Actualizar la entrada de la página en `PAGINAS_DE_VENTA.md` (fecha de revisión y pendientes) y avisar (Mat, 2026-10-26: automático, sin pedir confirmación).

## Reglas

- Lo que no se pudo comprobar se marca "no comprobado", no ✅.
- No hacer compras reales ni cargar datos de pago.
