---
name: "revision-semanal"
description: "Hace la revisión semanal del negocio del usuario con su segundo cerebro (D:\\segundo-cerebro): qué avanzó, decisiones, pendientes, números de Meta Ads de la semana, los 3 cuellos de botella del negocio con la nota de donde sale cada uno, y 3 prioridades para la semana siguiente. Usar cuando se pida 'revisión semanal', 'cómo vino la semana', 'cuellos de botella', 'qué priorizo', o los viernes."
---

# Revisión semanal

Base: `D:\segundo-cerebro\prompts\REVISION_SEMANAL.md` y la plantilla `07_REVISIONES\PLANTILLA_REVISION_SEMANAL.md`. Reglas: `INSTRUCCIONES_IA.md`.

## Pasos

1. **Leer lo de los últimos 7 días:**
   - `00_ENTRADA` (ideas y notas sin procesar).
   - `07_REVISIONES\sesiones\` (decisiones y pendientes de cada sesión).
   - `06_PROYECTOS\` (proyectos activos y ofertas espiadas).
   - `05_PROCESOS\LECCIONES.md`.
   - La revisión de la semana anterior, si existe.
2. **Números de Meta (si está la conexión de Meta Ads):** por cada campaña activa, gasto, compras, costo por compra y ROAS de los últimos 7 días, contra la regla de Mat (ROAS 2; 1,5 con USD 1.000/día o más) y su método (`ESTRATEGIA_DE_ANUNCIOS.md`). Solo lectura: **no cambiar nada en las campañas.** Si no hay conexión, pedir los números o dejarlos como "sin datos".
3. **Detectar los 3 cuellos de botella:** lo que más frena el objetivo del negocio (USD 100.000/mes de ganancia, en `CONTEXTO_DEL_NEGOCIO.md`). Cada uno con:
   - qué es,
   - **la nota o el dato de donde sale** (ruta del archivo o campaña),
   - qué lo destrabaría.
4. **3 prioridades** para la semana siguiente, ligadas a esos cuellos de botella. Explicar por qué, sin inventar urgencias.
5. **Marcar** contradicciones entre notas, información sin fecha y tareas sin responsable.
6. **Guardarlo** (y mostrarlo) (Mat, 2026-10-26: automático, sin pedir confirmación), en `D:\segundo-cerebro\07_REVISIONES\AAAA-MM-DD_revision-semanal.md`.

## Formato

```
# Revisión semanal — AAAA-MM-DD

## Números de la semana (Meta)
| Campaña | Gasto | Compras | Costo/compra | ROAS | Qué dice el método |

## Qué avanzó
## Decisiones tomadas
## Pendientes abiertos
## Los 3 cuellos de botella
1. [cuello] — Fuente: [nota/dato] — Qué lo destraba: [...]
## 3 prioridades para la semana que viene
## Contradicciones o datos viejos
## Fuentes revisadas
```

## Reglas

- No publicar, enviar, pausar ni cambiar nada: solo leer y proponer.
- Cada afirmación importante con su fuente.
- Si se corre automática (tarea programada), avisar solo cuando el borrador esté listo o haya algo urgente.
