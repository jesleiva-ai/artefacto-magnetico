---
name: "tablero-ventas"
description: "Arma el tablero de ventas y ganancia del negocio del usuario cruzando el gasto de Meta Ads (leído de sus cuentas) con las ventas reales de Hotmart (exportadas por la persona), por día, producto y cuenta: gasto, ventas, ingresos, ROAS real, ganancia y avance contra el objetivo de USD 100.000/mes. Usar cuando se pida 'tablero', 'cuánto gané', 'ganancia del mes', 'cómo vengo con el objetivo', 'números del negocio'."
model: sonnet
effort: medium
---

# Tablero de ventas y ganancia

Objetivo del negocio: **USD 100.000 de ganancia por mes** (`01_NEGOCIO\CONTEXTO_DEL_NEGOCIO.md`).

## Fuentes

1. **Gasto en anuncios:** Meta Ads, leído de las cuentas (gasto por cuenta y campaña, por día). Solo lectura.
2. **Ventas reales:** **Hotmart**. No hay conexión directa: la persona exporta el reporte de ventas de Hotmart (CSV/Excel del período) y lo deja en `D:\segundo-cerebro\00_ENTRADA\hotmart\`. Usar las columnas de fecha, producto, estado (aprobada/reembolsada), precio y comisión/neto. Si el archivo no está, el tablero se arma con lo que registra Meta y se marca "ventas Hotmart: faltan".
3. **Cuenta ↔ producto:** de las fichas de producto (`03_PRODUCTOS\`).

## Cálculos

- **Ingresos netos** = ventas aprobadas − reembolsos − comisión de Hotmart (si viene en el reporte).
- **Ganancia** = ingresos netos − gasto en Meta.
- **ROAS real** = ingresos netos ÷ gasto (incluye bumps, upsells y downsells, que Meta no siempre ve).
- **Ticket promedio** = ingresos netos ÷ compras del producto principal.
- **Avance del objetivo** = ganancia del mes ÷ 100.000; y ganancia diaria promedio vs. USD 3.300/día.
- Todo número calculado se marca como calculado; si falta una columna, decir cuál.

## Entrega

1. **Resumen:** período, gasto total, ingresos netos, ganancia, ROAS real, avance del objetivo.
2. **Por producto/cuenta:** gasto · ventas · ingresos netos · ganancia · ROAS real · ROAS que ve Meta · estado de la campaña.
3. **Por día** (últimos 7 o 30 días).
4. **3 lecturas:** qué producto deja más ganancia, cuál pierde plata, y qué dice el método (`operador-meta-ads`) para cada uno.

Guardar en `D:\segundo-cerebro\07_REVISIONES\tablero_AAAA-MM-DD.md`. Si la persona lo pide, publicarlo además como página visual (artifact privado) con los mismos números.

## Reglas

- No guardar datos de compradores (nombres, mails, países individuales); solo totales.
- Moneda: todo en USD.
- Solo lectura en Meta: el tablero no cambia nada.
