---
name: ugc-video-hiperrealista
description: Usar cuando el alumno (o el usuario) quiera crear un video publicitario UGC hiperrealista con una creadora o creador generado por IA demostrando o usando un producto, para Meta Ads/Reels/TikTok. Activar con pedidos como "hazme un UGC", "un video de alguien usando el producto", "un anuncio con una persona hablando a cámara", "video de venta directa con un creador".
---

# UGC Video Hiperrealista

## Qué hace esta skill

Produce un video publicitario estilo UGC (contenido generado por un creador) con una persona de IA hiperrealista hablando a cámara y demostrando un producto o servicio, con audio nativo (voz + música opcional), listo para subir como anuncio. Usa el motor de Higgsfield por debajo (MCP de Higgsfield conectado en la sesión), pero con un flujo guiado pensado para infoproductos y ventas directas en español.

El resultado final es UN solo archivo de video (no clips sueltos), en el formato y duración que pida el alumno.

## Paso 0 — Reunir lo que falta antes de empezar

Preguntá (o extraé del mensaje si ya lo dio) en una sola tanda:

1. **Duración**: 15s, 30s, 45s u otra (párate en múltiplos que acepten clips de 4-15s).
2. **Formato/orientación**: horizontal (16:9, para feed/YouTube), vertical (9:16, Reels/Stories/TikTok) o cuadrado. El motor por defecto genera vertical — si el alumno pide horizontal o cuadrado, hay que pasarlo explícitamente en cada llamada de generación de video (ver Paso 5).
3. **Producto**: foto o descripción del producto (opcional — si es un infoproducto digital sin foto física, se puede hacer sin producto en pantalla, con la persona demostrando la actividad/oficio relacionado, como en el ejemplo de macramé).
4. **Creador**: si el alumno tiene su propio avatar/rostro autorizado para usar, reusarlo. Si no, se genera uno nuevo (ver Paso 2) — pedí rasgos generales si le importan (género, edad, estética) o dejalo a tu criterio coherente con la marca.
5. **Idioma y tono**: por defecto el motor habla en inglés — para alumnos hispanohablantes, hay que pedir explícitamente español neutro (o el dialecto que corresponda) en el prompt de audio de cada clip.
6. **Claims/datos reales**: pedí los datos verdaderos del producto/oferta que se pueden mencionar (nunca inventar resultados, testimonios, compras o reviews — ver Paso 3).

## Paso 1 — Cargar el workflow base de Higgsfield

Llamar `get_workflow_instructions` con `workflow: "ugc-video"` del MCP de Higgsfield. Elegir el formato según lo que pida el alumno (por defecto `review`: una persona demuestra el producto o cuenta algo mientras lo usa). Leer `references/formats/<formato>.md`, `references/duration.md`, `references/ugc-character.md`, `references/monologue-craft.md`, `references/ugc-board.md`, `references/boards.md` y `references/ugc-clip.md` del mismo workflow antes de generar nada — ahí están las reglas obligatorias de seguridad, estructura de prompts y los parámetros exactos de cada modelo.

**Gate de seguridad y verdad (obligatorio, nunca saltarlo):**
- Solo personas generadas adultas (21+) o personas reales con consentimiento explícito del alumno para usar su imagen — nunca clonar la cara o voz de alguien sin permiso, nunca figuras públicas.
- Nunca inventar compras, resultados, antes/después, reseñas o testimonios — el creador de IA es un demostrador/presentador, no un "cliente real".
- Los claims del producto tienen que ser datos reales que dio el alumno; sin eso, describir solo lo observable (materiales, pasos, mecánica visible).
- Encuadrar el video como demo/creativo de marca, no como review orgánico espontáneo — avisarle esto al alumno al entregar.

## Paso 2 — Planificar duración y generar la identidad del creador

1. Vía `sandbox_exec`, correr `plan_duration.py` del workflow con la duración pedida para obtener `clip_count` y `clip_durations` (los clips Seedance van de 4 a 15s cada uno).
2. Si no hay foto de creador propia, generar una con `generate_image_batch` (`model: "soul_2"`, `aspect_ratio: "3:4"`, `quality: "2k"`), siguiendo las reglas de `ugc-character.md`: SOLO la persona (sin producto en la imagen, eso se agrega después en el video), con las 4 frases ancla obligatorias ("high model facial features", "symmetrical features", "well-proportioned figure", "natural skin texture"), coherente con la estética de marca del alumno (paleta, ambiente). Guardar `job_id` como `character_media_id` — se reusa igual en todos los boards y clips, nunca se regenera a mitad de camino.

## Paso 3 — Escribir el guion (monólogo)

Seguir `monologue-craft.md`: densidad de palabras según duración de cada clip (~28-35 palabras por clip de 13-15s), un solo arco narrativo con un "pero entonces" a mitad de camino, tono NATURAL por defecto (cálido, genuino, nunca gritado). Primera palabra nunca puede ser un arranque de "calentamiento" ("Okay", "Bueno", "Eh", etc.). Nunca inventar reclamos no aprobados por el alumno. Escribir el guion completo en español neutro (u el idioma pedido) ANTES de generar ningún board, y dividirlo en segmentos, uno por clip.

## Paso 4 — Generar los boards (storyboards de 8 escenas)

Por cada clip, generar un board de 8 paneles verticales en una sola tira horizontal (`model: "gpt_image_2"`, `aspect_ratio: "21:9"`, `resolution: "2k"`, `quality: "high"`), usando `character_media_id` (y el board anterior limpio como referencia si no es el primero). Describir las 8 escenas (encuadre, acción, expresión) siguiendo el arco del guion — nunca hornear texto de venta dentro de la imagen.

**Limpieza obligatoria de cada board** (nunca te la saltees): importar el `result_url` del board crudo con `media_import_url`, y correr `generate_image_batch` con `model: "seedream_v5_pro"` y el prompt de limpieza fijo de `boards.md` (mantiene encuadre/identidad exactos, solo mejora micro-realismo de piel/luz/grano). Descargar y mirar el resultado (Bash + Read) antes de seguir — si algo falla (identidad, cantidad de paneles, texto no deseado), corregir antes de avanzar.

## Paso 5 — Escribir y generar los clips de video

Por cada board, escribir UN prompt de Seedance siguiendo la estructura obligatoria de `ugc-clip.md`: Style & Mood, Narrative Summary, 8 Cuts (uno por panel del board, con encuadre, acción, manos, micro-gestos), Static Description (ambiente), y Audio (texto exacto a decir, en el idioma pedido).

Llamar `generate_video_batch` con:
```
model: "seedance_2_5"
duration: <segundos de este clip>
aspect_ratio: "16:9" (horizontal) | "9:16" (vertical) | "1:1" (cuadrado) — SIEMPRE pasarlo explícito según lo pedido en el Paso 0
resolution: "1080p"
mode: "omni_reference"
generate_audio: true
medias: [ {board limpio, role: image}, {character_media_id, role: image} ]
```
Si el alumno pidió música, agregar una línea "Music: ..." al final del prompt de audio del clip donde corresponda (nunca inventar música si no la pidió). Si Higgsfield devuelve `submission_failed` por un preset recomendado, reintentar pasando `declined_preset_id` con el id que devolvió el error.

Esperar los jobs con `jobs_wait` (agrupados de a 12 como máximo, timeout 15s, repetir hasta `all_terminal: true`).

## Paso 6 — Unir los clips en un solo video final

Los clips quedan como archivos separados — hay que entregar UN solo video. Descargar cada clip (`curl`) y concatenarlos con `ffmpeg`:

```bash
ffmpeg -y -i clip1.mp4 -i clip2.mp4 \
  -filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]" \
  -map "[v]" -map "[a]" -c:v libx264 -crf 18 -preset medium -c:a aac -b:a 192k \
  final_video.mp4
```
(Agregar más pares `[N:v][N:a]` y subir `n=` si hay más de 2 clips.)

Hacer un control de calidad visual rápido: extraer 4-5 frames espaciados con ffmpeg, armar una sola imagen de contacto con PIL y mirarla con Read antes de entregar — confirmar identidad consistente, ropa/escenario sin saltos raros, y que la pieza/producto final se vea bien.

## Paso 7 — Entregar

Copiar el video final a `/mnt/user-data/outputs/` y entregarlo con `SendUserFile`. En el mensaje final, siempre incluir:

- El guion hablado completo (para que el alumno pueda editarlo o traducirlo).
- Aviso honesto: es una persona generada por IA, no una clienta real — para plataformas de ads conviene encuadrarlo como creativo de marca/demo, no como testimonio orgánico.
- Confirmación de que los datos/claims mencionados son los reales que dio el alumno, sin resultados inventados.
- Ofrecer variantes: otra duración, otro formato/orientación, subtítulos quemados, o recortar a una versión más corta para Stories/Reels.

## Notas para cuando el alumno lo use directamente

- Cuanto más específico el pedido inicial (nicho, tono, si quiere música, orientación), menos preguntas hacen falta.
- El modelo de creador (`soul_2`) y el de limpieza (`seedream_v5_pro`) son obligatorios — no se puede saltar la limpieza de los boards, es lo que le da el nivel hiperrealista en vez de verse "plástico" de IA.
- Nunca reemplazar `seedance_2_5` por otro modelo de video aunque falle — si un modelo queda bloqueado, avisar y parar esa fase en vez de improvisar con otro.
- Todo esto consume créditos de Higgsfield — si el alumno no tiene el MCP de Higgsfield conectado, avisarle que esta skill lo necesita.
