# Webs modelo (la vara del Profesor)

Las páginas de venta que Matías da por buenas, bajadas el 2026-10-27 tal como estaban publicadas. Son la vara con la que el subagente `profesor-web` corrige toda web nueva (`skills/profesor-web/SKILL.md`).

Matías, 2026-10-27: «Acá te voy a dejar unas páginas web para que vos sepas cómo son los modelos de página web que yo quiero… fijate que son bonitas».

| Archivo | Nicho | En vivo |
|---|---|---|
| `metodo-consultor-es.html` | Negocios (el producto que más vende) | https://laformulaebooks.site/metodo-consultor/ |
| `universo-macrame.html` | Hobby, manualidades | https://laformulaebooks.site/universo-macrame/ |
| `piedras-perfumadas.html` | Artesanía, aromas | https://laformulaebooks.site/piedras-perfumadas/ |
| `sueter-que-crece.html` | Tejido infantil | https://laformulaebooks.site/sueter-que-crece/ |
| `la-boveda-del-editor.html` | Pack digital para editores de video | https://www.workaholicsagency.com/labovedadeleditor |

## Cómo usarlas
- Para el diseño, la estructura, los componentes y las animaciones: abrir el HTML (los estilos están adentro) y, para ver las imágenes, la versión en vivo.
- Para comparar lado a lado: `node herramientas/capturar_referencia.mjs --url <link en vivo> --salida <producto>/entradas/profesor/modelo` y mirar `captura_390.png`.
- **Los textos, precios, bonos y fechas son de esos productos:** no se copian. Lo de cada producto sale de su ficha.
- En estas copias, los links de compra, píxeles, IDs de Utmify y Clarity, correos y códigos de afiliado se reemplazaron por marcadores (`[CHECKOUT_URL]`, `[ID_PIXEL]`, …). No se publican tal cual.
- La Bóveda trae cupos, «personas viendo», contadores de clientes y avatares que en este repo están prohibidos (regla 2 de `CLAUDE.md`): de ahí se toma solo el diseño.
