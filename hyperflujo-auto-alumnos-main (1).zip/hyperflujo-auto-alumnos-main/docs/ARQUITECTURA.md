# Arquitectura de hyperflujo-auto (v1.0 — TAREA 035, 2026-10-22)

Este documento es la síntesis final del Arquitecto principal. Parte de tres propuestas («autonomía primero», «seguridad del gasto primero», «replicabilidad primero») y de dos veredictos de jueces. **Gana «autonomía primero»**: sumó 165,0 puntos, contra 163,6 de «replicabilidad» y 152,6 de «seguridad». Sobre esa base se aplican los injertos que pidieron los dos jueces; cada uno queda marcado **[I-n]** en el texto, y la lista completa está en §16.

Atribución: **Matías** = método de lanzamiento (citado `analisis/matias/repo/<archivo>:<línea>`); **Ramiro** = criterio de Ramiro (decisiones D-n que él dictó y paquete `cerebro-kit`); **Hyperflujo (D-n / F-n)** = lo que el equipo decidió (`analisis/equipo/ESTADO.md`) o sufrió (`analisis/equipo/FRICCION_AUTOMATIZACION.md`) en la corrida 1. Las cifras de terceros van siempre con cita. Lo que falta se marca `[PENDIENTE: …]`. El repo no contiene IDs reales, solo marcadores: `[act_CUENTA]`, `[ID_PIXEL]`, `[ID_PAGINA]`, `[CODIGO_PRODUCTO]`, `[CODIGO_OFERTA]`, `[CHECKOUT_URL]`, `[EMBUDO_ID]`, `[DOMINIO]`.

---

## 1. Qué hace el sistema

Clonado en una PC con Claude Code y las cuentas de su dueño, el sistema hace cuatro cosas:

1. **Abre un producto nuevo por día.** El límite es `max_nuevos_por_dia`: 1 por defecto, hasta 3 según D82. Por cada producto, caza la oferta en la Biblioteca de anuncios, la modela, produce el ebook o portal con su escalera (3 bumps + upsell + 2 downsells) y lo sube al repo de productos (D119: solo el producto). Después publica el portal y la landing en Netlify, da el producto de alta en Hotmart con el robot, crea la campaña Cash Trap CBO en Meta en pausa y la activa a medianoche cuando todo está aprobado.
2. **Administra los activos todos los días.** Mide el gasto de Meta contra las ventas netas de Hotmart y aplica la regla de corte del dueño (D92). Para lo que sobrevive, sigue las reglas de operación de Matías: escalar +30 % o reponer anuncios del mismo nivel.
3. **No espera a nadie.** Cada corrida termina. Toda espera es un estado que la próxima corrida vuelve a evaluar: aprobación de Hotmart, 48 h sin tocar.
4. **No gasta sin tope escrito.** Toda solicitud paga y toda escritura externa queda en un registro auditable.

Lo que sigue siendo humano es una lista cerrada (§13 y `docs/LIMITES.md`).

---

## 2. Principios

1. **La ficha manda** (D1/D8). `ofertas/OF-NNN/oferta.json` es la autoridad sobre producto, precio, promesa, evidencia, marca y escalera.
2. **Decide el código, produce el modelo.** `director.py` y `vigia.py` son Python determinista y deciden estado, plata, tiempos y transiciones. Un worker `claude -p` solo produce piezas o ejecuta acciones que ya figuran en el plan del día; nunca decide si se gasta.
3. **La seguridad no depende del modelo.** Vigilancia, pausa automática y D92 corren sin LLM cuando `.env` tiene las credenciales de lectura (§8.4).
4. **Verificar por artefacto, nunca por el texto del worker** (Ramiro, `cerebro/CLAUDE.md` regla 9). Vale un archivo con su sha256, un deploy leído por API, un producto listado en Hotmart, una campaña releída con su `spend_cap`.
5. **Dato faltante nunca mata ni aprueba** [I-0e]. Una lectura de ventas que falla vale `null`, nunca 0, y no dispara D92.
6. **Los OK escritos de la corrida 1 se reemplazan por autorizaciones escritas una sola vez** (D82, D88). Cada una lleva texto literal, firmante exacto, alcance, **techo y vigencia obligatorios** [I-1c]. Si falta la entrada, la etapa hace PARAR y lo dice en el informe.
7. **Guardianes en código, estrenados rompiéndolos** (Ramiro: «un guardián que nunca falló está sin estrenar»).
8. **Tres capas que no se mezclan** [I-2a]:
   - *repo*: versionado, igual para todos;
   - *instalación*: `.env`, `estado/`, `operacion/sesiones/` y logs, fuera de git;
   - *cuenta*: `datos/*.local.json` y `ofertas/*/externo.local.json`, fuera de git.
9. **Matías en el flujo; Ramiro como alternativa documentada** donde se contradicen. Las decisiones del dueño (D77/D78, D90, D92, D93, D98, D100, D101) son valores por defecto configurables, y cada desvío respecto de Matías queda anotado en el informe.
10. **Nada inventado en ninguna plantilla** (D8, F38, D119): ni testimonios, ni reseñas, ni relojes, ni cupos, ni «% off», ni «antes USD X».

---

## 3. Vista general

```
┌──────────────────────── NIVEL 0 · DISPARADOR SIN MODELO ────────────────────────────┐
│ Vía A (objetivo): Programador de tareas / cron / launchd ← herramientas/programar.py │
│ Vía B (puente operativo hoy): tareas programadas LOCALES de la app de Claude          │
│   00:07  director.py --modo principal   12:07  director.py --modo pulso               │
│   :37 de cada hora  vigia.py            (horas en datos/config.local.json)            │
└───────────────┬───────────────────────────────┬───────────────────────────────┬──────┘
                ▼                               ▼                               ▼
┌──────────── NIVEL 1 · DIRECTOR Y VIGÍA (Python stdlib, sin LLM) ─────────────────────┐
│ estado/hyperflujo.db (máquina de estados) · estado/planes/<fecha>.json (lo permitido) │
│ puerta.py → registro.py (gasto) · autorizaciones.py · topes.py · freno_meta           │
│ etapas.py: por etapa → herramienta determinista | worker · verificador por artefacto  │
│ informe.py → estado/informes/AAAA-MM-DD.md (único canal, F12) · avisos.py             │
└───────┬──────────────────────────────────┬───────────────────────────────────────────┘
        │ lanzar_worker.py (claude -p)     │ herramientas directas (Python / Node+Playwright)
        ▼                                  ▼
┌─ NIVEL 2 · WORKERS (una etapa, un producto, terminan) ─┐ ┌─ HERRAMIENTAS ─────────────────────┐
│ --permission-mode dontAsk · --allowedTools por etapa    │ │ validar_ficha · armar_landing      │
│ --disallowedTools · --strict-mcp-config --mcp-config    │ │ netlify_deploy · hotmart_alta.mjs  │
│ --json-schema worker_salida.json · timeout del proceso  │ │ meta_ads · operar_campana · vigia  │
│ hooks: guardian_plan (gasto), guardian_secreto          │ │ piel_landing · repo_productos …    │
└──────────────┬──────────────────────────────────────────┘ └───────────────┬────────────────────┘
               ▼ MCP solo dentro de la sesión (meta-ads, hotmart, higgsfield)  ▼ REST / robot con la sesión del dueño
┌──────────────────────────────────── PROVEEDORES ─────────────────────────────────────┐
│ Meta (conector oficial por OAuth; Graph API opcional con usuario del sistema EMPLEADO) │
│ Hotmart (robot Playwright sobre Chrome real del dueño; MCP/REST con Basic, lectura)   │
│ Netlify (API) · Higgsfield / ElevenLabs (con tope) · GitHub (repo privado de productos)│
└───────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Orquestación

### 4.1 Nivel 0 — disparador

- **Vía A (objetivo).** `herramientas/programar.py instalar|quitar|estado` registra tres tareas en el programador del sistema operativo [I-2g]:
  - Windows: schtasks, con «ejecutar solo cuando el usuario haya iniciado sesión», porque el robot de Hotmart necesita escritorio;
  - Linux: cron;
  - macOS: launchd.

  Antes de registrar, muestra el comando exacto. Las tres tareas son `director.py --modo principal`, `director.py --modo pulso` y `vigia.py`.
- **Vía B (puente operativo hoy) [I-B1].** Son las tareas programadas **locales** de la app de escritorio de Claude, la misma vía que usó la corrida 1 (`~/.claude/scheduled-tasks/of001-vigilancia-d92` y `of005-vigilancia-d92`).
  - Corren en esta PC, con acceso al `.env` y al Chrome del robot, mientras la app esté abierta. Si la app estaba cerrada, corren al abrirla.
  - El prompt es autocontenido: «en `<repo>` corré `python herramientas/director.py --modo …` y nada más».
  - Corrección a la propuesta «replicabilidad»: decía que el scheduler de la app no llega al `.env` ni al Chrome. Eso vale solo para las rutinas **en la nube**.
- `director.py` es el mismo en A y en B. `verificar_entorno.py --orquestacion` dice cuál vía está disponible.
- **CLI de Claude, verificada en esta PC el 2026-10-22:**
  - `claude.exe` 2.1.304 viene empaquetado en `%LOCALAPPDATA%\Claude-Data\<id>\claude-code\<versión>\…` y **no está en PATH**. `herramientas/ruta_claude.py` lo resuelve en este orden: PATH, después `HYPERFLUJO_CLAUDE_EXE`, después la carpeta de la app.
  - `--help` confirma los flags `-p`, `--permission-mode`, `--allowedTools`, `--disallowedTools`, `--json-schema`, `--mcp-config`, `--strict-mcp-config`, `--settings`, `--setting-sources`, `--model`, `--effort`, `--max-budget-usd`, `--add-dir` y `--output-format`.
  - **`--max-turns` no existe en esta versión.** El corte duro es el `timeout` de `subprocess.run`.
  - El onboarding ofrece además instalar la CLI en PATH (`claude install`) [I-B1].

### 4.2 Nivel 1 — director y vigía

| Proceso | Cuándo | Qué hace | Usa modelo |
|---|---|---|---|
| `director.py --modo principal` | 00:07 (zona de la cuenta) | 0) pre-vuelo; 1) **activar** lo que esté en `lista_para_activar` (Matías larga a medianoche, `skills/cash-trap-cbo-oro/SKILL.md:92-94`) y aplicar las subidas de presupuesto ya decididas; 2) **operar** los activos, una acción por campaña; 3) subir al repo de productos lo listo (D119); 4) **avanzar** los productos en curso; 5) **abrir** un producto nuevo si hay cupo; 6) informe | workers por etapa |
| `director.py --modo pulso` | 12:07 | Avanzar productos en curso sin abrir nuevos, releer aprobaciones y reescribir el informe. Matías mira al mediodía del día 3 (`cash-trap-cbo-oro/SKILL.md:94`) | workers por etapa |
| `director.py --modo avance --of OF-NNN` | lo dispara el vigía | Solo las etapas **deterministas** de un producto, sin worker, cuando Hotmart aprobó: checkouts, bumps estándar, embudo y publicar landing [I-2i] | no |
| `vigia.py` | cada hora, minuto :37 | Gasto de hoy contra el diario autorizado; sonda HTTP de landing y checkout (dos lecturas separadas 5 min); D92 cada hora en las primeras 48 h; aprobación de Hotmart; solicitudes «enviando» con más de 30 min pasan a `envio_incierto` y se concilian por ID [I-2i]; vencimientos D78; freno de Meta. **Solo pausa: nunca activa ni sube gasto** | no |

Reglas del nivel 1:

- **Cerrojo único** (`estado/director.lock` con PID, hora y latido). Un cerrojo de más de 3 h se considera huérfano: se toma y se anota. El vigía usa su propio cerrojo y escribe en la base dentro de transacciones SQLite.
- **Verificación por artefacto** al volver de cada etapa. Si falta algo, `intentos += 1`. Al segundo fallo del día, el producto pasa a `bloqueada_humano` (si hace falta una persona) o a `fallida`, con lo que se probó. Base: D40, «2 intentos y pendiente».
- **Workers secuenciales** (`workers.paralelo_max = 1`), para que no se repitan dos sesiones publicando el mismo sitio (F35; Matías, `09_que_haria_distinto.md:14`).
- Nunca `sleep` largos ni polling dentro del proceso.

### 4.3 Nivel 2 — workers `claude -p`

`herramientas/lanzar_worker.py` arma la llamada a partir de `etapas.py`:

```
<claude.exe> -p "<prompt generado de plantillas/prompts/<etapa>.md>"
  --append-system-prompt "<contenido de skills/<etapa>/SKILL.md>"
  --permission-mode dontAsk                       # lo no permitido se rechaza sin preguntar ni clasificar
  --allowedTools "<lista de la etapa>"            # preaprueba exactamente lo que la etapa usa
  --disallowedTools "<lista de la etapa>"         # recorte duro adicional
  --mcp-config .mcp.json --strict-mcp-config      # el worker ve SOLO meta-ads, hotmart, higgsfield [I-0a]
  --json-schema plantillas/esquemas/worker_salida.json --output-format json
  --model <config.modelos[rol de la etapa]> [--max-budget-usd N si factura API]
  (timeout duro de subprocess.run por etapa)
```

- **Ninguna etapa usa `bypassPermissions` ni `--dangerously-skip-permissions`.** `dontAsk` con allowlist por etapa resuelve los bloqueos del clasificador en escrituras gratuitas del robot y en tarjetas de medios (F6, F19bis, F22) sin dar permisos de más. Eso cierra el riesgo de «todo en allow» (D99).
- **`--strict-mcp-config`** impide que el worker vea los conectores del usuario: correo, navegador, control del escritorio. La vía B no tiene strict; ahí la barrera dura es el `deny` explícito de esos conectores en `.claude/settings.json`, que vale en cualquier modo [I-1e].
- El worker devuelve **solo** el JSON de `worker_salida.json`. Del JSON de salida de la CLI, el director lee `total_cost_usd`, `num_turns`, `duration_ms` y `session_id` y los registra en la EJ (`registrar_tiempo` y tabla `trabajos`) [I-0g]. Si se factura por API, además los registra como consumo del proveedor `anthropic`.
- El prompt siempre dice «no preguntes; si falta un dato, `[PENDIENTE]` y terminá» (Ramiro, `ofertas-prompt.md`: un loop sin humano jamás pregunta).
- Modelo por rol (D40): Opus produce, Sonnet revisa y ejecuta planes, Haiku hace lo mecánico (`datos/config.local.json → modelos`).

---

## 5. Ciclo de un producto: máquina de estados

Las etapas viven en `estado/hyperflujo.db`, tabla `productos` (SQLite de la biblioteca estándar: transacciones y cerrojo sin dependencias). Solo `director.py` y `vigia.py` cambian la etapa. Cada transición escribe un evento con hora, regla, herramienta y artefacto verificado.

Ejecutores: «W» = worker; «H» = herramienta determinista; «R» = robot Playwright.

| # | Etapa | Ejecuta | Salida verificable | Siguiente |
|---|---|---|---|---|
| 0 | `candidata` | W `cazar-oferta` + H `cazar.py` | `referencia/candidatos.json` y `paises.json` con los umbrales de Matías medidos (perfil ≥ 20 activos reales, oferta ≥ 30, más de 10–15 días, sin marca personal; `skills/cazador-de-ofertas/SKILL.md:73-82`) y la cobertura anotada; nunca `estimated_total_count` | `cazada` |
| 1 | `cazada` | H `nueva_oferta.py` + `capturar_referencia.mjs`, W `modelar-oferta` | `mapa_secciones.md` y `anuncios_ganadores[]` (IDs públicos como `[ID_BIBLIOTECA_n]`) | `nombrada` |
| 2 | `nombrada` | W `nombre-coherente` + H `nombre_coherente.py` | `nombre.json` con 5 opciones, medición y elegido; si no se pudo medir, español sin anglicismo y `medicion: no_disponible` | `ficha_valida` |
| 3 | `ficha_valida` | W `modelar-oferta` + H `precio.py`, `validar_ficha.py` | `oferta.json` con precio D78, escalera de Matías (por lo general 3+1+5, 2026-10-26) «ninguno incluido en otro» (`analisis/matias/repo/cerebro/ELEGIR_Y_MODELAR_OFERTAS.md:33-44`), `campana` y `prohibidas[]`; `validar_ficha` = 0 | `producida` |
| 4 | `producida` | H motor + W `producir-producto`, `producir-escalera` | 7 PDF + portal y `validacion_producto.json` con sha256; cero «Imagen pendiente» (F33) | `portal_publicado` |
| 5 | `portal_publicado` | H `netlify_deploy.py` | `/portal/` en producción con GET anónimo 200 (F21, F36/D94) | `en_panel` |
| 6 | `en_panel` | H `repo_productos.py publicar` | commit en el repo privado de productos con la entrega y el `LEEME.md` (D119: sin reviews ni perfiles) | `landing_borrador` |
| 7 | `landing_borrador` | H `producto/armar_sitio.py` + `compuerta_sitio.py` | landing y páginas `oferta-*`, `gracias` y `privacidad`; validación en verde; deploy borrador | `hotmart_borrador` |
| 8 | `hotmart_borrador` | R `hotmart_alta.mjs` (seca → real) | 7 productos en borrador con precio base = lista y oferta de lanzamiento aparte (F25), PDF, soporte y píxel | `hotmart_enviado` |
| 9 | `hotmart_enviado` | R `finalizar_registro` con autorización `finalizar_registro` vigente | estado «en revisión», leído | espera (la revisa el vigía) |
| 10 | `hotmart_aprobado` | H lectura por API/MCP | los 7 productos aprobados | `embudo_listo` |
| 11 | `embudo_listo` | R `leer_oferta`, `bumps_estandar`, `embudo_un_clic` | checkout `?off=` de lanzamiento capturado, con precio igual a la ficha; bumps en checkout estándar `?checkoutMode=10`; embudo Upsell → DS1 → DS2 → Gracias (`skills/embudo-hotmart-netlify/SKILL.md:32-83`) | `landing_publicada` |
| 12 | `landing_publicada` | H `producto/armar_sitio.py` + `netlify_deploy.py publicar` (autorización `publicar`) | GET 200; `compuerta_sitio.py` sobre la URL pública (CTA al `off=` correcto, píxel, UTM → `src`/`sck`) | `medios_listos` |
| 13 | `medios_listos` | W `anuncios-333` + H `componer_anuncios.py`, `validar_anuncios.py`, medios con tope | 9 piezas 3/3/3 + 6 RES-, hoja de contacto y sitio `<marca>-medios` con GET 200 por medio | `campana_en_pausa` |
| 14 | `campana_en_pausa` | W `meta-campana-cashtrap` (conector) + H `plan_campana.py` | campaña CBO, conjunto Advantage+ y 9 + 6 anuncios PAUSED con CTA `LEARN_MORE` (D100); releídos: locales, `daily_budget` y `spend_cap` = diario × días (F37, D98) | `lista_para_activar` |
| 15 | `lista_para_activar` | H compuerta | Hotmart aprobado, embudo activo, landing 200, cupo global disponible (sin espera de testimonios, D119) | `activa` (a las 00:07) |
| 16 | `activa` | H/W activar con autorización `activar_campana` | ACTIVE releído; `activada_en` | `operando` |
| 17 | `operando` / `escalando` | H `operar_campana.py` | veredicto y como mucho una acción por día (§9) | `retirada` o sigue |
| — | `retirada` | H pausa | campaña PAUSED releída; todo se conserva | terminal (solo la saca un `reactivar` escrito) |
| — | `pausada_tecnica` | H vigía | sonda caída, tope del día superado o lectura de ventas ausente | sigue pausada salvo `reanudacion_automatica` firmada [I-0x] |
| — | `bloqueada_humano` / `fallida` | H | motivo y acción humana exacta | vuelve a la etapa anterior cuando se resuelve |

Línea de tiempo típica:

1. Día D a las 00:07: se abre el producto y avanza hasta `hotmart_enviado`. Tarda ≈ 3–5 h de agente `[PENDIENTE: medir; OF-005 llevó ≈ 10 h con relevos, hyperflujo/recetas/metodo-consultor/RECETA.md «Tiempos»]`.
2. Ese día o el siguiente, el vigía ve la aprobación de Hotmart y dispara `--modo avance`, que deja la campaña en `lista_para_activar`.
3. La activación ocurre a las 00:07 siguientes, y D92 corre cada hora durante las primeras 48 h.

---

## 6. Estado y datos

### 6.1 Estado (instalación, fuera de git)

- `estado/hyperflujo.db` (SQLite) con cinco tablas:
  - `productos`: etapa, intentos, bloqueo, hitos y próxima revisión;
  - `eventos`: transiciones;
  - `trabajos`: cada lanzamiento de worker, con su costo y resultado;
  - `mediciones`: gasto, ventas netas y ROAS por día y por anuncio;
  - `veredictos`.
- `estado/planes/AAAA-MM-DD[-sufijo].json`: las **únicas** escrituras externas permitidas ese día. Esquema en `plantillas/esquemas/plan_dia.json`. Cumple el papel del «ticket» [I-2t].
- `estado/libro_gasto.jsonl`: libro append-only que escribe solo `puerta.py` [I-1b].
- Otros archivos de estado:
  - `estado/freno.json`: freno del dueño (solo se permite pausar);
  - `estado/freno_meta.json`: enfriamiento por los límites de Meta [I-1d];
  - `estado/decisiones.jsonl`: veto, reactivar, cambiar tope o freno, firmado por un nombre de `datos/dueno.local.json`;
  - `estado/friccion.jsonl` y `estado/onboarding.json`;
  - `estado/informes/AAAA-MM-DD.md`: los informes sí van a git, sanitizados.

### 6.2 Datos del dueño (cuenta, fuera de git; en el repo solo `datos/*.ejemplo.json`)

| Archivo | Contenido |
|---|---|
| `config.local.json` | zona, horarios, modelos, workers, avisos |
| `topes.local.json` | tope diario global, por proveedor y por producto |
| `autorizaciones.local.json` | reglas escritas, con techo y vigencia |
| `dueno.local.json` | firmantes exactos |
| `cuentas.local.json` | cuentas descubiertas por `/onboarding` con el conector (D84) |
| `reglas_operacion.local.json` | valores que sobrescriben `datos/reglas_operacion.json` |

### 6.3 Producto (`ofertas/OF-NNN/`)

- `oferta.json`: la ficha, solo con marcadores.
- `oferta.md`: vista generada.
- `externo.local.json`: IDs reales de Hotmart, Meta y Netlify; fuera de git.
- `referencia/`, `producto/`, `escalera/`, `landing/`, `anuncios/`, `campana/`, `canales/hotmart/`.
- `ejecuciones/EJ-NNN/registro.json`, más `entradas/` con la copia de la ficha y del brief usados.
- `entradas/` y `medios/`: fuera de git.

---

## 7. Gasto: puerta única, cuatro topes, plan del día

1. **Puerta única: `herramientas/puerta.py`, sobre `registro.py`** [I-1b]. Toda solicitud paga o escritura externa pasa por `puerta.solicitar(...)`: Meta, Hotmart en modo real, Netlify, GitHub, Higgsfield, ElevenLabs y Claude por API. La puerta comprueba en este orden y **falla cerrada** ante el primer fallo:
   - el libro se puede leer;
   - no hay `envio_incierto` para ese producto y proveedor;
   - no hay freno del dueño (salvo para pausar) ni freno de Meta;
   - hay una autorización vigente que cubre la acción, con techo y vigencia;
   - se cumplen los **cuatro topes acumulativos**: (1) tope del producto en la ficha; (2) tope diario global de `datos/topes.local.json`, calculado desde el libro; (3) `spend_cap` y `daily_budget` releídos de la plataforma antes de activar; (4) techo de la autorización;
   - el `estimado` es mayor que 0, finito y en la unidad del proveedor (`datos/tarifas.json`).

   Si todo pasa: `agregar_solicitud(clave)` → `marcar_enviando` → una sola llamada → `guardar_id_externo` → fila en el libro. Una operación gratuita se registra con `gratuita=True` y `motivo_gratuita`.
2. **El plan del día hace de ticket** [I-2t].
   - El director escribe en `estado/planes/<fecha>.json` cada escritura permitida, con `clave`, la `herramienta` MCP o el prefijo del `comando`, `estimado`, `tope_ref`, `autorizacion_ref` y `max_llamadas`.
   - El worker abre la solicitud con `puerta.py ticket --accion A-…`, que la deja en `enviando`.
   - El hook `herramientas/hooks/guardian_plan.py` (PreToolUse) cubre `mcp__higgsfield__generate_*`, `mcp__meta-ads__ads_create_*`, `ads_activate_entity`, `ads_update_entity`, `ads_creative_upload_media` y `hotmart_alta.mjs --modo real`. Los deja pasar **solo** si existe una acción del plan para esa herramienta con la solicitud en `enviando`, no venció (10 min) y no superó `max_llamadas`. Si no puede leer el plan o el registro, niega.
   - El worker cierra con `puerta.py id-externo`. Existe modo lote (F29).
3. **Los medios se piden por script cuando existe uno** [I-1h]. Higgsfield y ElevenLabs van por `herramientas/higgsfield.py` y `herramientas/elevenlabs.py`, que tienen la credencial y pasan por la puerta. El ticket MCP queda solo como alternativa.
4. **Freno de Meta compartido** [I-1d]. Los códigos 4, 17, 32, 613 y 80000–80014 escriben un enfriamiento en `estado/freno_meta.json`. Hay un techo propio de 25 escrituras por hora. Si el archivo no se puede leer, el freno cuenta como activo. Nunca se reintenta ni se regenera el token (Ramiro, `CONTRATO-FRENO.md`).
5. **Meta.** `daily_budget` = diario de la ficha; `spend_cap` de campaña = diario × días. Ambos se releen antes de activar.
   - Una Cash Trap por cuenta (Matías, `cash-trap-cbo-oro/SKILL.md:84-88`). Tener varias campañas por cuenta (D90) requiere la autorización `campanas_compartidas` y el desvío se anota.
   - El conector no lee ni escribe el límite de gasto de la cuenta (D101). Ese límite se fija a mano en el onboarding; si hay token del usuario del sistema, el vigía lo lee y avisa al llegar al 70 % `[PENDIENTE]`.
6. **Pausa automática sin OK** (D60) cuando el gasto de hoy supera el diario autorizado, cuando la landing o el checkout no devuelven 200 en dos sondas, y por D92. Nada se reenciende solo. La reanudación automática solo existe si `datos/config.local.json → reanudacion_automatica: true` **y** hay una entrada firmada en `estado/decisiones.jsonl` [I-0x].
7. **Consumo real desconocido = `null`.** Higgsfield se concilia por `id_externo` (`transactions`), nunca por diferencia de saldo (D42). El gasto de Meta se concilia por insights una vez por día.
8. **Modelo.** El `total_cost_usd` de cada worker va al registro. Si se factura por API, además se usan `--max-budget-usd` y el tope `anthropic` de topes (D55/D56; USD 10 por mes no alcanza para 1–3 productos por día `[PENDIENTE: dueño]`).

---

## 8. Seguridad del entorno (acotado por código)

| Capa | Mecanismo | Qué evita |
|---|---|---|
| `deny` en `.claude/settings.json` (vale en cualquier modo) | Bloquea: lectura de `.env*`, sesiones y `datos/*.local.json`; `git push`, `rm -rf`, `curl` y `wget`; escrituras de Hotmart (reembolsos, cupones, suscripciones); audiencias y boost; **conectores del usuario** `mcp__claude-in-chrome__*`, `mcp__computer-use__*`, `mcp__Claude_Browser__*`, y `mcp__terminal__*` [I-1e]. Los conectores con nombre propio de cada usuario (por ejemplo, el correo con un identificador único) no admiten un patrón genérico: en la vía A los deja fuera `--strict-mcp-config` y en la vía B el `disallowed` de cada etapa (anotado en `docs/LIMITES.md`) | Secretos, destrucción y conectores que la etapa no usa. Es la barrera dura de la vía B |
| `--strict-mcp-config` + `.mcp.json` | El worker ve solo meta-ads, hotmart (HTTP con `Authorization: Basic ${HOTMART_BASIC}`, F9 [I-0c]) e higgsfield | Correo, navegador y escritorio del usuario |
| `dontAsk` + allowlist por etapa | `etapas.py` define `allowed` y `disallowed` para cada etapa | Gasto o activación fuera de etapa |
| `guardian_plan.py` (PreToolUse) | Tickets del plan del día | «Todo en allow» sin red (D99) |
| `guardian_secreto.py` (UserPromptSubmit) | Secretos pegados en el chat: aviso para rotarlos (Ramiro, `hook-secreto-en-el-chat.py`) | Secretos en el chat |
| `guardian_codigo.py` (AST) [I-0d] | Cada cliente de red tiene una sola puerta `_pedir` que pasa por `puerta.py` | Llamadas pagas por fuera de la puerta |
| `probar_guardianes.py` | Rompe cada guardián a propósito (sin ticket, sin tope, plan ilegible, `.env` ilegible) y bloquea `programar.py instalar` mientras no pase [I-0d] | Guardianes sin estrenar |

### 8.4 Vigilancia sin modelo

- Con `META_SYSTEM_USER_TOKEN`, el vigía lee insights y pausa por Graph API (`meta_ads.Cliente`). El token es de un usuario del sistema con rol **EMPLEADO**, nunca ADMIN (Ramiro, `claude/skills/meta-ads/SKILL.md`, «La línea roja»: la API sí, el Administrador por navegador nunca).
- Con `HOTMART_BASIC`, `hotmart_api.py` lee ventas y aprobación sin columnas del comprador `[PENDIENTE: endpoints exactos]`.
- Sin esos tokens, el vigía encola un trabajo `vigilar` para un worker y el informe lo marca como «vigilancia dependiente del modelo» `[PENDIENTE: decisión del dueño; en la corrida 1 eligió el conector OAuth, D84/D99]`.

---

## 9. Reglas de operación: baja y escalado

Orden de precedencia: **Hyperflujo (D92) > Matías > Manual Maestro.** Cada decisión cita la regla que aplicó. Las reglas viven en `datos/reglas_operacion.json`; el dueño las sobrescribe en `reglas_operacion.local.json`.

### 9.1 Baja (D92 por defecto, parametrizable)

- **(a)** A las 24 h o más desde `activada_en`, con 0 ventas (compra aprobada en Hotmart, o `Purchase` del píxel como señal): PAUSAR la campaña y pasar el producto a `retirada`.
- **(b)** A las 48 h o más, si los ingresos netos de Hotmart (brutos − reembolsos − comisión) son menores que el gasto acumulado de Meta: lo mismo.
- `gasto_min_factor_precio` = 0, que es D92 literal. El preset del brief §1.3 (48 h de entrega y gasto ≥ 2 × precio) se elige con `corte.modo = "brief_035"`; por defecto no se mezcla [I-1x].
- **Dato faltante.** (a) y (b) exigen una lectura de ventas exitosa en ese tick.
  - Dos lecturas fallidas seguidas: aviso.
  - Más de `pausa_preventiva_sin_datos_horas` (6) sin lectura y con gasto corriendo: `pausada_tecnica`.
  - La ventana D92 se extiende por el tiempo pausado [I-1k].
- **Qué es la baja.** `ads_update_entity` → PAUSED, con motivo y relectura. Se conserva todo: landing, portal y productos de Hotmart siguen disponibles para quienes compraron `[PENDIENTE: dueño: ¿desactivar también la oferta de lanzamiento y despublicar la landing?]`.
- **Reactivación.** Solo con la autorización `reactivar`, que nombra la oferta (nunca «todas»).
- El informe acumula cuántos productos retira D92(a). Con USD 30 por día, la primera venta puede tardar más de 24 h; Matías arranca con 50–75 por día (`cash-trap-cbo-oro/SKILL.md:35`).

### 9.2 Operación según Matías (`cash-trap-cbo-oro/SKILL.md:92-151`, `operador-meta-ads/SKILL.md:12-58`; D91)

1. 48 h sin tocar después de activar o de cualquier cambio. La decisión se toma a nivel campaña con ROAS = ingresos netos de Hotmart / gasto de Meta, nunca con el píxel solo.
2. Si el ROAS es ≥ 2: `daily_budget` +30 %, aplicado a las 00:07 y **solo si** cabe en los cuatro topes; si no cabe, el informe pide un tope nuevo. Si es < 2, la campaña corre hasta el día 5, subordinada a D92.
3. Las subidas siguientes se hacen cada 48 h como mínimo, con ROAS ≥ 2. Nunca se «surfea» dentro del día.
4. Con ROAS ≥ 2 no se toca ningún anuncio. Si el ROAS baja:
   - el anuncio perdedor es el que gastó ≥ precio de lanzamiento sin compra atribuida por `utm_content`/`sck`;
   - se pausa y se repone con una RES- del mismo nivel;
   - nunca quedan menos de 9 activos ni se desbalancea el 3/3/3, y los C1 no se sacan;
   - sin reserva del nivel, no se apaga nada y se encola la producción de una reserva.
5. Un solo tipo de cambio por día (presupuesto **o** anuncios), y 3 días de espera después de cambiar anuncios.
6. Con mucho presupuesto acumulado, en vez de subir se agregan anuncios de a uno por nivel, de 9 a 12 [I-0f].
7. El fin de la oferta de lanzamiento (D78) cuenta como el «cambio de anuncios» de ese día [I-0f].
8. El diagnóstico usa el formato de 6 puntos de Matías (`cash-trap-cbo-oro/SKILL.md:144-151`). La lectura de Ramiro («sin ~50 resultados no concluir», ROAS marginal) se muestra como nota y no decide.

---

## 10. Precio (D77/D78/D93)

- El cazador modela el **precio de lanzamiento**. `precio.py` calcula `lista = lanzamiento / (1 − d)`, con `d ∈ [0,60; 0,70]`, y `fin_lanzamiento` = aprobación de Hotmart + 30 días o más.
- En Hotmart, el precio base es la lista y la oferta de lanzamiento lleva código propio desde el alta (F25). La landing y los anuncios apuntan solo a ese `off=`.
- **Revisión 035 (h. 12): suspendido.** La landing y los anuncios muestran solo el precio que se cobra. No se muestra precio regular tachado ni fecha de fin: un precio que nunca se cobró es una referencia ficticia y una fecha que nadie hace vencer es urgencia falsa (D8). Nunca «antes USD Y», porcentajes ni cuenta regresiva.
- [PENDIENTE: vencimiento D78 sin implementar; hasta que exista y esté probado no se publica ningún par de precios.] El vigía avisaría 3 días antes del fin. Al vencer, con la autorización `desactivar_oferta_al_vencer`: el robot desactiva la oferta, la landing se regenera con «precio regular» y los C3 que muestran el par de precios se reponen con RES- sin precio.
- Los secundarios van a precio literal de Matías (`analisis/matias/repo/02_definicion_producto.md:23-31`) `[PENDIENTE: D85 literal contra D73 proporcional cuando el principal no vale 17,90]`.

---

## 11. Nombre coherente (F18, D83/D86)

1. El worker genera 5 opciones en el idioma y la región del mercado.
2. `nombre_coherente.py` mide cada opción en la Biblioteca con frase exacta por país, contando solo anuncios devueltos, y busca choques con anunciantes o páginas. Trends no tiene API oficial: va como columna «no medido» `[PENDIENTE]`.
3. Un anglicismo entra solo si se midió y supera a sus equivalentes en español.
4. El worker elige y el dueño ve el resultado en el informe.
5. `validar_nombre.py` exige la misma cadena en la ficha, los 7 productos de Hotmart, el `<title>` de la landing, la campaña y los anuncios (`utm_campaign`), el sitio de Netlify y el PDF de acceso.

---

## 12. Repo de productos, sin testimonios (D119)

1. En la etapa `en_panel`, `repo_productos.py publicar` sube `productos/<id>/` (la entrega y `LEEME.md`) al repo privado `REPO_PRODUCTOS_URL`. Es lo único que el sistema hace con ese repo.
2. Testimonios, reseñas y perfiles de probadores quedan fuera del sistema (D119, Ramiro, 2026-10-23: «testimonios fuera del sistema: quitá el código»; supera D89, D96 y D117). No hay código que los pida, recoja, valide, espere ni inserte; ninguna plantilla de landing tiene ese bloque; el director no espera testimonios ni feedback para publicar ni activar, y no hay freno de calidad por puntaje.
3. Opiniones: solo reales y con fuente, entre los marcadores `OPINIONES-REALES` (Matías, 2026-10-26).

---

## 13. Onboarding humano único

El detalle va en `docs/ONBOARDING.md`, que escribe C2. Los **prerrequisitos** pueden tardar días y quedan fuera de los 30 min [I-2j]: Business Manager y cuenta publicitaria en USD con medio de pago, Hotmart verificado con cobro habilitado, Netlify, GitHub, Higgsfield, ElevenLabs y Claude con el login del plan.

| # | Paso humano (una vez) | Verificación automática | Min |
|---|---|---|---|
| 1 | Instalar Python ≥ 3.10, Node ≥ 18, Git y Chrome; clonar; `npm install` | `verificar_entorno.py` | 10 |
| 2 | CLI `claude` en PATH o app instalada | `verificar_entorno.py --orquestacion` (`ruta_claude.py`) | 2 |
| 3 | Crear `.env` desde `.env.ejemplo` (nunca pegar valores en el chat) | `claves.py`: definida / no definida | 4 |
| 4 | Meta: límite de gasto de la cuenta, a mano (D101); píxel vinculado; una página por marca (F7); OAuth de meta-ads eligiendo una cuenta y una página | `/onboarding` descubre cuenta, píxel y página (D84) y escribe `cuentas.local.json` | 5 |
| 5 | Hotmart: credenciales de API en `.env`; login del robot una vez en Chrome real con perfil persistente (F4) | `hotmart_sesion.mjs verificar` (F13) | 3 |
| 6 | Netlify: token; Visitor access público (F36) | sitio de prueba con GET anónimo 200 | 2 |
| 7 | Repo privado de productos + token (D119: solo se sube el producto) | commit de prueba y revert | 2 |
| 8 | Firmar `topes`, `dueno`, `autorizaciones` (con techo y vigencia) y `config` | `autorizaciones.py verificar` | 4 |
| 9 | Correr `probar_guardianes.py` y `ensayo_seco.py --dias 3` hasta verde | `estado/onboarding.json` completo | 3 |
| 10 | Vía A: `programar.py instalar`. Vía B: crear las tareas locales de la app y tocar «Run now» una vez | `programar.py estado` | 2 |

Después del onboarding sigue siendo humano:

- renovar el OAuth de Meta (~60 días, F2) y la sesión de Hotmart;
- crear páginas y cuentas;
- fijar el límite de gasto de la cuenta publicitaria;
- actualizar `selectores.json` si Hotmart cambia el panel;
- firmar topes, autorizaciones y reactivaciones;
- conseguir consentimientos nuevos;
- mantener la PC encendida y con sesión iniciada.

---

## 14. Flujos de error

| Situación | Detección | Respuesta automática | Estado | Humano |
|---|---|---|---|---|
| Worker sin artefactos o pasado de tiempo | verificación / timeout | un reintento como EJ nueva con `deriva_de`; después, bloqueo | `fallida` | leer el informe |
| `TopeInsuficiente`, sin autorización o costo desconocido | puerta | no se envía; se anota | etapa en espera | firmar tope o autorización |
| `envio_incierto` | vigía (> 30 min en «enviando») | conciliación por ID; si falla, se bloquea ese proveedor para el producto | `bloqueada_humano` | conciliar en el panel |
| Sesión de Hotmart vencida | `hotmart_sesion verificar` en el pre-vuelo | ninguna escritura | `bloqueada_humano` | loguear el robot |
| Selectores de Hotmart rotos | código de salida del robot | volcado de `hotmart_explorar` y aborto | `bloqueada_humano` | actualizar `selectores.json` |
| «Error interno» de Hotmart | robot | busca el borrador por nombre y continúa | — | — |
| Precio del checkout ≠ ficha | captura | no se publica | `bloqueada_humano` | — |
| Netlify devuelve 401 | GET anónimo | ajusta la visibilidad si `netlify_visibilidad` está autorizado; si no, bloqueo | — | Visitor access |
| Locales distintos de las claves de español (F37) | relectura del conjunto | corrige y relee; si persiste, no se activa | `campana_en_pausa` | — |
| Freno de Meta | código de error | enfriamiento en disco, cero reintentos | — | — |
| Landing o checkout caídos | sonda ×2 | PAUSED | `pausada_tecnica` | según `reanudacion_automatica` |
| Gasto de hoy > diario | vigía | PAUSED | `pausada_tecnica` | revisar |
| Falla la lectura de ventas | `null` | no se decide D92; 2 fallos → aviso; más de 6 h con gasto corriendo → pausa | `pausada_tecnica` | revisar credenciales |
| OAuth de meta-ads vencido | error del conector | escrituras en espera; vigilancia por API si hay token | `bloqueada_humano` | `/mcp` → Authenticate |
| Ningún candidato cumple | `cazar.py` | «sin producto hoy» en el informe | — | — |
| Cerrojo huérfano | latido > 3 h | se toma y se anota | — | — |

Regla general: ningún error reintenta a ciegas más de una vez, ningún error reenciende una campaña, y todo error aparece en el informe con la acción humana exacta o con «ninguna».

---

## 15. Pruebas y ensayo en seco

- Suite única, sin red ni cuentas: `python -m unittest discover -s pruebas -t .`. `pruebas/sin_red.py` hace fallar cualquier conexión real.
- Dobles por proveedor en `pruebas/fakes/`: Meta, API de Hotmart, panel falso de Hotmart, Netlify, Higgsfield, ElevenLabs, GitHub y `claude`.
- `ensayo_seco.py --dias 3` recorre corrida principal, pulsos, vigías y medianoches con relojes falsos. Un producto nuevo llega hasta `lista_para_activar` y se activa. Después se prueban estos casos: muere a las 24 h; muere a las 48 h en negativo; escala con ROAS ≥ 2; se repone un anuncio perdedor; se cae la lectura de ventas; vence la oferta D78. Produce los informes con el socket bloqueado [I-2h].
- Pruebas de regla dura: sin IDs reales; plantillas sin testimonios ni reseñas (D119), timers ni cupos; guardianes rotos a propósito; compuerta multiplataforma (Ramiro); `--help` de cada script (F41); transiciones completas.

---

## 16. Injertos aplicados

| Id | Origen | Qué entra |
|---|---|---|
| I-0a | propuesta 0, a pedido del juez 2 | `--strict-mcp-config` en todo worker |
| I-B1 | propuesta 0 | vía B local como puente; `ruta_claude.py`; instalación de la CLI en el onboarding |
| I-0c | propuesta 0 | hotmart en `.mcp.json` como servidor HTTP con Basic tomado de `.env` |
| I-0d | propuesta 0 | `guardian_codigo.py` (AST) y `probar_guardianes.py`, que bloquea `programar.py instalar` |
| I-0e | propuesta 0 | dato faltante nunca mata ni aprueba |
| I-0f | propuesta 0 | reglas finas de Matías: de 9 a 12 anuncios; fin de lanzamiento como cambio del día; republicar la landing 1 vez por día y no en las primeras 48 h |
| I-0g | propuesta 0 | `total_cost_usd`, `num_turns` y `duration_ms` por worker |
| I-0x | juez 1 | sin reanudación automática salvo firma del dueño |
| I-1b | propuesta 1 | `puerta.py` + `libro_gasto.jsonl` append-only, falla cerrada |
| I-1c | propuesta 1 | autorizaciones con techo y vigencia obligatorios |
| I-1d | propuestas 1 y 2 | freno de Meta compartido en disco |
| I-1e | juez 1 | `deny` de los conectores del usuario (barrera de la vía B) |
| I-1h | propuesta 1 | medios por script con puerta; ticket MCP solo como alternativa |
| I-1k | propuesta 1 | la pausa técnica extiende la ventana D92 |
| I-1x | juez 2 | D92 literal; el 2 × precio queda solo en el preset `brief_035` |
| I-1v | propuesta 1 | `validar_anuncios.py` y `compuerta_sitio.py` con casos que deben fallar |
| I-2a | propuesta 2 | tres capas: repo, instalación, cuenta |
| I-2g | propuesta 2 | `programar.py` multiplataforma |
| I-2h | propuesta 2 | `test_sin_ids_reales` y ensayo con el socket bloqueado |
| I-2i | propuesta 2 | `envio_incierto` a los 30 min; encadenar etapas deterministas cuando Hotmart aprueba |
| I-2j | propuesta 2 | prerrequisitos fuera de los 30 min |
| I-2t | propuesta 2 | tickets, implementados como acciones del plan del día |

---

## 17. Pendientes de diseño

- `[PENDIENTE: dueño]` token de usuario del sistema de Meta en `.env` para vigilar sin modelo; límite de la cuenta por API.
- `[PENDIENTE: dueño]` facturación del modelo (plan o API) y tope mensual; cifras de `topes.local.json`.
- `[PENDIENTE: dueño]` qué pasa con Hotmart y la landing al retirar un producto; reanudación automática.
- `[PENDIENTE]` endpoints REST de ventas de Hotmart para `hotmart_api.py`; confirmar que el OAuth de meta-ads persiste entre llamadas `claude -p` (F2).
- `[PENDIENTE]` flujos `bumps_estandar`, `embudo_un_clic` y `desactivar_oferta` en `selectores.json`; confirmar contra `hyperflujo/ofertas/OF-005/ejecuciones/EJ-008` y `EJ-011` (solo lectura).
- `[PENDIENTE]` claves numéricas de idioma de Meta, confirmadas por relectura (F37).
- `[PENDIENTE]` licencia del Manual Maestro antes de copiarlo a `conocimiento/`.
- `[PENDIENTE]` tiempos reales por etapa del ciclo autónomo.
