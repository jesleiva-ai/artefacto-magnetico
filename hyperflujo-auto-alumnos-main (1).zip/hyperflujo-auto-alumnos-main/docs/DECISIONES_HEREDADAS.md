# Decisiones heredadas

Qué se tomó de cada fuente y por qué. Tres orígenes, siempre atribuidos:

- **Matías** — método de lanzamiento (vendió con él): `conocimiento/matias/` (skills `cash-trap-cbo-oro`, `operador-meta-ads`, cazador, modelado; notas `02_definicion_producto.md`, `09_que_haria_distinto.md`).
- **Ramiro** — su criterio, empaquetado por la academia donde enseña IA: `conocimiento/kit/` (`cerebro/CLAUDE.md`, `skills/`). Aclaración de Ramiro (2026-10-22, TAREA 035): es contenido de sus propias clases.
- **Hyperflujo (D-n)** — decisiones del equipo y del dueño en la corrida 1 (`analisis/equipo/ESTADO.md`, del taller: no se copió a `conocimiento/`).

Regla de conflicto (TAREA 035): si el kit y Matías se contradicen en una etapa, en el flujo se aplica **Matías** y la regla de Ramiro queda como alternativa documentada para que él decida. Por encima de ambos, las reglas de corte y gasto del dueño (D60, D92).

## 1. Decisiones D-n adoptadas

| D-n | Qué dice (resumen) | Cómo se aplica en este repo |
|---|---|---|
| D8 | Toda afirmación de landing o anuncio con evidencia; sin testimonios, timers ni cupos; tachado solo con evidencia del precio de lista | Regla dura 2 de `CLAUDE.md`; `compuerta_sitio.py`, `validar_anuncios.py` |
| D40 | Uso del plan: sesión nueva por tarea, sin bucles, «2 intentos y pendiente» | Workers `claude -p` de una etapa; `bloqueada_humano` al segundo fallo |
| D60 | Meta por API con tope; spend_cap por campaña; límite de cuenta fijado a mano | Puerta única y cuatro topes (`puerta.py`, `topes.py`, `freno_meta.py`) |
| D69 | Nada a mano: si no hay API, robot Playwright con la sesión del dueño | `hotmart_alta.mjs` y familia (C5) |
| D72 | Hosting en Netlify, publicación por API | `netlify_deploy.py` |
| D73 | Escalera de productos (bumps, upsell, downsells) | `escalera.py`, receta `metodo-consultor`; `[PENDIENTE: D85 literal contra D73 proporcional]` |
| D77 / D78 / D93 | Precio de lanzamiento siempre, ≥ 30 días, 60–70 % bajo la lista; lista real en Hotmart; «precio regular» solo con dato | `precio.py`; landing con par de precios condicionado |
| D83 / D86 | Nombre coherente con el mercado; anglicismo solo medido | `nombre_coherente.py`, `validar_nombre.py` (F18) |
| D84 | Píxel, cuenta y página se descubren por el conector | `/onboarding` escribe `datos/cuentas.local.json` |
| D85 | Secundarios a precio literal de Matías | `conocimiento/matias/02_definicion_producto.md:23-31` |
| D88 | «Finalizar registro» lo aprieta el robot con autorización escrita | autorización `finalizar_registro` en `datos/autorizaciones.local.json` |
| D91 | En Meta Ads, seguir a Matías al pie de la letra | `docs/REGLAS_META_ADS.md`, `operar_campana.py` |
| D92 | Regla de corte del dueño: 24 h sin venta → baja; 48 h con neto < gasto → baja | `datos/reglas_operacion.json`, máxima precedencia |
| D94 / F36 | Sitios públicos sin login de visitante | paso 6 del onboarding |
| D96 | Testimonios solo con consentimiento firmado | Superada por D119: no hay testimonios en el sistema |
| D99 | Nada de «todo en allow»; permisos acotados por etapa | `dontAsk` + `--allowedTools` por etapa; hooks |
| D100 | CTA «Más información» (`LEARN_MORE`) | `plan_campana.py` |
| D101 | Presupuesto de campaña firmado por el dueño con spend_cap | ficha + autorizaciones; desvío anotado si no coincide con el arranque de Matías |
| D119 | Ramiro, 2026-10-23: «testimonios fuera del sistema: quitá el código». Testimonios, reseñas y perfiles de probadores quedan fuera del sistema; al repo de productos solo se sube el producto (supera D89, D96 y D117) | Sin `testimonios.py`, skill ni receta de testimonios; ninguna plantilla de landing tiene ese bloque; el director no espera testimonios ni feedback del panel para publicar ni activar (`pruebas/test_panel.py`) |

`[PENDIENTE: transcribir fecha y texto literal de cada D-n desde analisis/equipo/ESTADO.md; aquí solo el resumen operativo]`

## 2. Matías: tomado

- Estructura Cash Trap / CBO Oro completa, segmentación, creativos 3/3/3, tiempos, escalado +30 %, reemplazo del mismo nivel, diagnóstico de 6 puntos (`docs/REGLAS_META_ADS.md`, con citas).
- Lanzar a medianoche y mirar al mediodía del día 3 (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:92-94`) → horas del director.
- Workers secuenciales para no publicar dos veces el mismo sitio (`conocimiento/matias/09_que_haria_distinto.md:14`).
- Umbrales del cazador y modelado de oferta (C3; citas en `skills/cazar-oferta/` y `recetas/metodo-consultor/`).

## 3. Matías: no tomado o subordinado

| Qué | Por qué |
|---|---|
| Ventana de 48 h / 5 días antes de apagar | Subordinada a D92 (decisión del dueño); el desvío se anota en cada informe |
| Arranque USD 50–75 por día (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:35`) | Manda el tope firmado (D60/D101) |
| Testimonio en C2 «demostración» | Testimonios fuera del sistema (D119): C2 va con tutorial, demostración o carrusel |
| Datos de sus campañas (F11) | No están en el repo; ninguna cifra suya se presenta como medición propia |

## 4. Ramiro: tomado

| Skill / regla | Qué entra | Dónde |
|---|---|---|
| `conocimiento/kit/cerebro/CLAUDE.md` (regla 9) | Verificar por artefacto, nunca por el texto del worker | Regla dura 7 de `CLAUDE.md`; verificador del director |
| `conocimiento/kit/cerebro/CLAUDE.md` | Guardianes que fallan cerrado y se estrenan rompiéndolos; secretos fuera del chat | `probar_guardianes.py`, `guardian_secreto.py`, `claves.py` |
| `meta-ads` | Línea roja: nunca el Administrador de anuncios por navegador; «sin ~50 resultados no concluir» como nota | `docs/REGLAS_META_ADS.md` §1 y §8 |
| `evaluar-landing`, `maqueta-landing` | Criterio de evaluación y estructura de landing | recetas de landing (C4) |
| `pricing`, `oferta-completa` | Alternativa documentada al modelado de Matías | `recetas/metodo-consultor` como nota |
| `creativos`, `voz-cliente`, `investigar-mercado` | Ángulos y lenguaje del mercado para los 9 anuncios | skill `anuncios-333` (C4) |
| `cobro-por-mercado`, `quien-cobra` | Criterio de cobro por país | `[PENDIENTE: integrar en la ficha por mercado]` |
| `compliance-checker` | Solo en lo que **reduce** el engaño (promesas, claims de salud o dinero) | validadores de landing y anuncios |
| `higgsfield-product-photoshoot` | Referencia de prompts de producto | medios con tope (C4) |

## 5. Ramiro: descartado

| Skill | Por qué |
|---|---|
| `cloaker-xray` | Cloaking engaña al revisor y al usuario: viola D8 |
| `compliance-checker` usado para esquivar revisión | Mismo motivo; solo se toma la parte que reduce el engaño |
| `metodo-6c` con persona de IA presentada como cliente | Viola D8/D119; queda la estructura del guion como alternativa |
| `montar-landing-shopify` | El canal es Hotmart + Netlify (D69/D72) |
| `espia-ofertas`, `desarme-completo`, `radar-sesiones` | Superpuestos con el cazador de Matías; alternativa documentada `[PENDIENTE: decide Ramiro]` |
| `notebooklm-research`, `whisper-flow`, `skill-finder` | Herramientas de estudio, fuera del ciclo automático |
| Cualquier script del kit | No se ejecutan (TAREA 035); solo se lee el criterio |


## Desvío registrado en la revisión adversarial 035

| Decisión | Desvío respecto de | Autorizado por | Límites escritos |
|---|---|---|---|
| Activación y pausa automáticas (sin OK humano por producto) | Matías, `conocimiento/matias/skills/operador-meta-ads/SKILL.md:12,57` (el operador humano decide) y Ramiro, `conocimiento/kit/skills/meta-ads/SKILL.md:141-149` (prender y pausar son decisiones humanas) [PENDIENTE: verificar líneas; citas tomadas de la revisión 035] | TAREA 035 (Hyperflujo) | Solo con autorización escrita vigente en `datos/autorizaciones.local.json` (activar_campana, escalar), topes que fallan cerrado (`topes.py`), pausa confirmada por relectura, freno por rechazos. Es un criterio de Hyperflujo, no de la clase. |
