# Fricción resuelta (F1–F19)

Cada fila de `analisis/equipo/FRICCION_AUTOMATIZACION.md` (corrida 1, 2026-10-21/22) con su solución en este repo, o la razón por la que sigue siendo humana (`docs/LIMITES.md`). Las fricciones nuevas se registran con `herramientas/friccion.py`, nunca solo en texto.

| F | Qué no salió solo | Solución en hyperflujo-auto | Estado |
|---|---|---|---|
| F1 | Conectores de `.mcp.json` no aparecen en sesiones ya abiertas | Cada worker es un `claude -p` nuevo con `--strict-mcp-config --mcp-config .mcp.json` (I-0a): no hay sesiones viejas | resuelto en diseño |
| F2 | OAuth del conector `meta-ads` | Humano cada ~60 días (`docs/LIMITES.md` #1); el pre-vuelo lo detecta antes de escribir | humano `[PENDIENTE: confirmar persistencia entre llamadas claude -p]` |
| F3 | Hotmart sin API para crear productos, ofertas, bumps ni embudo | Robot Playwright `hotmart_alta.mjs` sobre la sesión del dueño (D69), seca antes de real | resuelto en diseño (C5) |
| F4 | Login del robot falla (Chromium bloqueado, 2FA, cookie de SSO) | Chrome real por CDP en 127.0.0.1 con perfil persistente; login humano una vez (onboarding paso 5) | parcial: renovar la sesión es humano |
| F5 | Alta real cortada en la pantalla de moneda | `recetas/hotmart/selectores.json` versionado + seca completa obligatoria + pruebas contra `pruebas/fixtures/c5/panel_falso/` | resuelto en diseño |
| F6 | Clasificador de permisos bloqueó al worker y al director | `--permission-mode dontAsk` con `--allowedTools` por etapa y hooks que fallan cerrado (D99); sin `bypassPermissions` | resuelto en diseño |
| F7 | Píxel, cuenta apta y página que firma los anuncios | Descubrimiento por el conector (`ads_get_datasets`, D84) en `/onboarding`; crear la página sigue siendo humano | parcial |
| F8 | Netlify «arrastrar y soltar» | `netlify_deploy.py` por API (D72), token una vez en `.env` | resuelto |
| F9 | Hotmart MCP con clave por variable (401) | Una sola vía: servidor HTTP en `.mcp.json` con `Authorization: Basic ${HOTMART_BASIC}` (I-0c); `claves.py` verifica | resuelto en diseño |
| F10 | Ramiro corrige la landing a mano antes de publicar | `compuerta_sitio.py` con casos que deben fallar (I-1v); autorización `publicar` escrita | parcial `[PENDIENTE: Ramiro describe el error para sumarlo como caso]` |
| F11 | Datos de Matías (CSV de Meta, ventas, PDF) no subidos | Medición propia por conectores: `metricas.py` + `importar_ventas_hotmart.py`; sus cifras solo con cita | resuelto para cuentas propias |
| F12 | Avisos dispersos en varios chats | Un solo canal: `estado/informes/AAAA-MM-DD.md` + `avisos.py` | resuelto en diseño |
| F13 | Falso positivo de «sesión abierta» | `hotmart_sesion.mjs verificar` con doble lectura y URL asentada | resuelto (heredado del taller) |
| F14 | Desplegables propios (`hot-select`) invisibles en el volcado | `hotmart_explorar.mjs` vuelca componentes y textos; selectores mapeados por seca | resuelto (heredado) |
| F15 | El conector no da la URL de checkout de un borrador | Robot en modo explorar lee código de producto y de oferta; checkout = `[CHECKOUT_URL]` armado y capturado | resuelto (heredado) |
| F16 | Cuadernillos que desbordan la hoja | Armado adaptativo en `herramientas/producto/` + `validacion_producto.json` (C3) | resuelto (heredado) |
| F17 | El director no puede iniciar sesiones de worker por mensajería | El director es Python y lanza `claude -p` por `lanzar_worker.py`; no depende de la app | resuelto en diseño |
| F18 | Nombres con anglicismos y marca que choca | Etapa `nombrada`: 5 opciones, medición en Biblioteca, `validar_nombre.py` (D83/D86) | resuelto en diseño `[PENDIENTE: Trends sin API]` |
| F19 | Libro y portal atados a un formato | Motor de producto genérico por formato y cantidad (C3); receta exige «motor y libro listos» antes de producir | resuelto (heredado) |
| F19bis | Prompts de permiso por herramientas pagas y gasto en Meta | Los topes en código (puerta + plan del día) reemplazan la tarjeta `ask`; lo pago en `allow` solo dentro del plan (decisión de Ramiro 10-22) | resuelto en diseño |

## Fricciones posteriores (F20–F39)

Se resuelven en `docs/ARQUITECTURA.md` (F21 orden portal → Hotmart; F22 escrituras del robot en `dontAsk`; F25 oferta de lanzamiento con código propio; F26 espera de aprobación como estado; F29 varias solicitudes «enviando»; F31 conteo de piezas validado; F33 cero «Imagen pendiente»; F35 workers secuenciales; F36 visitantes públicos; F37 relectura de idiomas; F38 testimonios ficticios: resuelto por D119, sin testimonios en el sistema). `[PENDIENTE: tabla completa F20–F39 al integrar]`
