# Límites: lo que sigue siendo humano y por qué

Lista cerrada. Todo lo que no figura acá lo hace el sistema (director, vigía, workers) o queda como estado `bloqueada_humano` con el motivo escrito en el informe del día. Fuente: `docs/ARQUITECTURA.md` §13 y §17; fricción F1–F19 en `docs/FRICCION_RESUELTA.md`.

| # | Qué hace una persona | Por qué no lo hace el agente | Frecuencia | Cómo se entera |
|---|---|---|---|---|
| 1 | Renovar el OAuth del conector `meta-ads` (F2) | Meta exige consentimiento interactivo; Claude no puede iniciarlo ni aceptarlo | ~60 días | `estado/informes/AAAA-MM-DD.md` y `avisos.py` |
| 2 | Renovar la sesión de Hotmart del robot (F4) | El robot nunca escribe credenciales, códigos 2FA ni resuelve captchas | cuando vence | el robot para y lo informa |
| 3 | Crear páginas de Meta y cuentas publicitarias (F7) | Meta no permite crear páginas por API; abrir cuentas es un acto del titular | por marca nueva | etapa `bloqueada_humano` |
| 4 | Fijar el límite de gasto de la cuenta publicitaria (D101) | Es la cerca externa al sistema; si la pone el mismo agente deja de ser cerca | una vez / al cambiar | `/onboarding` lo verifica por lectura |
| 5 | Aceptar términos de cualquier servicio | Aceptar condiciones compromete al titular; el agente nunca lo hace | por servicio | — |
| 6 | Firmar topes, autorizaciones (con techo y vigencia), reactivaciones y cambios de reglas | Decisión de plata del dueño (D60; Ramiro: guardianes que fallan cerrado) | cuando cambia | `estado/decisiones.jsonl` |
| 7 | Actualizar `recetas/hotmart/selectores.json` si Hotmart cambia el panel (F5, F14) | El robot detecta el cambio y para; inferir selectores en real sería escribir a ciegas | eventual | seca en rojo en el informe |
| 8 | «Finalizar registro» en Hotmart solo si la autorización escrita no está vigente (D88) | Con autorización vigente lo hace el robot; sin ella, nadie | por producto | informe |
| 9 | — (retirada: testimonios fuera del sistema, D119) | — | — | — |
| 10 | Responder a un producto en `bloqueada_humano` | Dos intentos fallidos no se reintentan a ciegas (regla 14 de `CLAUDE.md`) | eventual | informe |
| 11 | Mantener la PC encendida, con sesión de Windows iniciada y Chrome disponible a la hora de las corridas | El disparador es el Programador de tareas local (o tareas de la app) | diario | `programar.py estado` |
| 12 | Facturación del modelo (plan o API) y su tope mensual | Decisión del dueño | mensual | `[PENDIENTE: dueño]` |
| 13 | Cargar `REPO_PRODUCTOS_URL` (repo de productos: solo se sube el producto; sin reviews ni perfiles, D119) | El repo es del dueño | una vez | informe del director |
| 14 | Desactivar a mano la oferta de lanzamiento vencida (D78) mientras el flujo `desactivar_oferta` siga sin selectores verificados | El robot no escribe a ciegas en el panel | por producto, día 30 | informe (aviso D78) |
| 15 | Confirmar la lectura de D106 (vigía horario desde la hora 24, reemplazo automático) y los valores provisionales (`horas_max_sin_lectura` 24, freno de rechazos 3/7 días, techo de un día nulo = diario × 1,75) | Son decisiones del dueño; hoy están como provisionales de Hyperflujo | una vez | `datos/reglas_operacion.json` |
| 16 | Cargar `META_SYSTEM_USER_TOKEN` (usuario del sistema EMPLEADO) para que el vigía pause sin modelo | Sin token, una pausa urgente queda `bloqueada_humano` («pausar a mano») | una vez | `verificar_entorno.py` |

## Lo que el sistema nunca hará, aunque se le pida en el chat

- Gastar sin tope escrito, o con costo desconocido.
- Usar el Administrador de anuncios por navegador (línea roja de Ramiro, `cerebro-kit/.../claude/skills/meta-ads/SKILL.md`).
- Publicar testimonios o reseñas (fuera del sistema, D119), timers, cupos o «personas viendo» sin dato real.
- Cloaking o cualquier «compliance» para engañar (descartado del kit, ver `docs/DECISIONES_HEREDADAS.md`).
- Guardar secretos o IDs reales en archivos versionados.

## Pendientes

- `[PENDIENTE: dueño]` qué pasa con la oferta de Hotmart y la landing al retirar un producto.
- `[PENDIENTE]` confirmar si el OAuth de meta-ads persiste entre llamadas `claude -p` (F2); si no, sumar una fila.
- `[PENDIENTE: dueño]` token de usuario del sistema de Meta para vigilar sin modelo.
