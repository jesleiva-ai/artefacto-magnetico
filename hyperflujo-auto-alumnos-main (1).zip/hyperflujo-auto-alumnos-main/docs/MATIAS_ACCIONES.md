# Acciones de Matías sobre lo hecho (fuente: su análisis de OF-006)

Cada acción que Matías explique que hace él y el sistema no hace va acá, una fila por acción, con su cita literal y fecha. De acá sale:
- el cambio en la receta o skill que corresponde, citado «Matías, fecha»;
- lo que se construye (si es automatizable), dentro de la TAREA 041;
- una entrada en `docs/CAMBIOS_METODO.md` con la versión del motor (commit) para el Lab.

Si una acción contradice el método escrito (Cash Trap de Matías, Manual o el kit), **no se decide acá**: va a la sección «Desacuerdos» con las dos versiones y el dato, y la decide Ramiro (con Director_H1).

**Datos de campaña de OF-006.** Los entregó Director_H3 el 2026-10-25 19:07, solo lectura y sin datos de compradores. Están en `hyperflujo/ofertas/OF-006/campana/datos_para_A1.md` (tablas) y `datos_para_A1.json` (crudo).

**Resumen al 25/10 (el día es parcial):**

| Métrica | Valor |
|---|---|
| Gasto | USD 90,46 (30 por día, CBO, spend_cap 150) |
| Impresiones / clics | 2.988 / 69 (CTR 2,31 %) |
| Pedidos | 3: 3 principales + 5 bumps, ningún upsell ni downsell |
| Neto | 46,79 € |
| Origen de las ventas | todas de anuncios C3: V-C3 (video) ×2, C3-v2-A ×1 |
| Compras que vio el píxel | 1 de 3 (F62, consentimiento de cookies) |

**Tracking de Hotmart:** solo devuelve `source_sck`, no `utm_content`.

**Cronología:** activación el 23/10 00:45 → videos el 23/10 10:44 → reemplazo D122 el 23/10 16:36–16:52 (excepción a «48 h sin tocar», pedida por Ramiro). No hubo cambios de presupuesto.

**Matías:** todavía no dijo nada sobre OF-006.

**Actualización 2026-10-26:** DS-3 quedó respondido por Matías el 2026-10-25: «Es un píxel nuevo para cada país o para cada idioma» (`conocimiento/matias/memoria/pixel-nuevo-por-idioma.md`). Las reglas nuevas de Matías del 21 al 26/10 están en `conocimiento/matias/notas/2026-10-26_novedades_del_metodo.md` y en `docs/CAMBIOS_METODO.md`.

## Acciones

Fuente de todas las filas: Matías, 2026-10-25, análisis de OF-006 pegado por Ramiro. Texto literal en `conocimiento/matias/notas/2026-10-25_analisis_OF-006.md`; en la tabla, las citas cortas.

**M1 — Landing modelada tal cual la referencia, cambiando solo la paleta.**
- **Cita:** «Se modelo mal la pagina […] tenes que: modelar la pagina tal cual y cambiar solo la paleta de colroes».
- **Etapa:** revisar (landing).
- **Afecta:** `skills/landing`, `recetas/landing`, `piel_landing.py`.
- **Tipo:** automatizable; captura y medición de la referencia.
- **Qué se construye:** modelado sección por sección con el layout, los componentes y las animaciones de la referencia, cambiando la paleta.
- **Estado:** **en desacuerdo con D104 (DS-1)**: se documenta, no se construye hasta la decisión.

**M2 — Mockups del producto y de cada bono, más bonitos, con los de la referencia.**
- **Cita:** «no usamos los mockupts correspondientes, esteticamente el producto esta mal presentado […] hacele mockupts mas bonitos porque todo entra por los ojos».
- **Etapa:** producir / revisar.
- **Afecta:** `skills/producir-producto`, `skills/landing`.
- **Tipo:** automatizable, pero gasta créditos de Higgsfield (gasto_medios).
- **Qué se construye:** mockup del principal y uno propio por bono, sin texto adentro (el texto va con código), revisados contra los de la referencia.
- **Estado:** documentado; construir cuando se levante el deny.

**M3 — Botones de compra como los de la referencia.**
- **Cita:** «fijate que los botones de compra tambien se ven mucho mejor en office facile, analizala en profundidad».
- **Etapa:** revisar (landing).
- **Afecta:** `skills/landing`, `piel_landing.py` (`look.json`).
- **Tipo:** automatizable.
- **Qué se construye:** capturar del CTA de la referencia forma, tamaño, color relativo, animación y posición (barra fija), y reproducirlo.
- **Estado:** documentado; la barra con cuenta regresiva queda en **DS-4**.

**M4 — Mostrar el producto en videos cortos.**
- **Cita:** «podrias incluir el mostrar el producto en formato videitos cortos».
- **Etapa:** producir / revisar.
- **Afecta:** `skills/landing`, `skills/producir-producto`.
- **Tipo:** automatizable a consumo cero (grabación local del portal o del PDF con Playwright) o con Higgsfield (Kling, unos 6 créditos cada uno).
- **Qué se construye:** clips cortos del producto por dentro para la landing; ya estaba en el método (MODELADO §4.4).
- **Estado:** documentado; construir cuando se levante el deny.

**M5 — Logos de Office (Excel, Word y compañía): que se entienda qué se vende.**
- **Cita:** «te faltaron los logos de office en general, excel, word y compania, no se entiende que se vende».
- **Etapa:** revisar / anuncios.
- **Afecta:** `skills/landing`, `recetas/anuncios`.
- **Tipo:** automatizable.
- **Qué se construye:** dejar claro qué se vende arriba de todo.
- **Estado:** **en desacuerdo (DS-2)**: marcas de terceros.

**M6 — Microsoft Clarity en la landing (mapa de calor, scroll, dónde se van).**
- **Cita:** «conecta microsoft clarity para que lea toda la pagina, para analizar en que parte de la pagina se van los clientes y ver los puntos calientes y frios».
- **Etapa:** revisar / publicar / operar.
- **Afecta:** `skills/landing`, `skills/onboarding`, compuerta del sitio.
- **Tipo:**
  - Paso humano una vez: crear la cuenta y el proyecto de Clarity y anotar su ID.
  - Automatizable: insertar el script (después del consentimiento en es-ES), verificar que graba y leer los datos para `/operar`.
- **Qué se construye:** el script de Clarity en cada landing y el chequeo en la compuerta. Coincide con el kit: «Microsoft Clarity: va en TODA tienda, sin excepción» (`conocimiento/kit/skills/montar-landing-shopify/SKILL.md:372`).
- **Estado:** documentado; construir cuando se levante el deny.

**M7 — Un píxel por producto o por idioma, no uno solo para todo.**
- **Cita:** «hay que usar un pixel por producto o por idioma, no uno solo para todo como hicimos».
- **Etapa:** crear campaña, landing, Hotmart.
- **Afecta:** `pixel.py` (hoy, F63: el píxel de la cuenta), `datos/cuentas`, Hotmart (flujo `pixel`).
- **Tipo:** automatizable; el dataset se crea por Graph sin costo.
- **Qué se construye:** el píxel sale del producto o del mercado, no de la cuenta.
- **Estado:** **por decidir (DS-3)**: ¿por producto o por idioma?

**M8 — Modelar tal cual los anuncios de la competencia (estilo y lo que muestran), con la estrategia Cash Trap.**
- **Cita:** «hay que modelar tal cual los anuncios de la competencia, obviamente no con los mismos videos pero si el estilo y el que muestran, pero con nuestra estrategia de mati claro».
- **Etapa:** anuncios / crear campaña.
- **Afecta:** `recetas/anuncios`, `skills/meta-campana-cashtrap`, `cazar.py` (anuncios_ganadores).
- **Tipo:** automatizable; la captura de los anuncios ganadores de la Biblioteca no tiene costo.
- **Qué se construye:** por cada C1, C2 y C3, el anuncio de referencia que modela (formato, gancho, qué muestra), con piezas propias. Ya era el método: Prompt C (`conocimiento/matias/prompts/2026-10-20_2237_modelar-9-anuncios.md`).
- **Estado:** documentado; construir cuando se levante el deny.

## Decisión D126 (Ramiro, 2026-10-25, textual vía Director_H1)

«no, tal cual dijo Mati, mi trabajo es testear, no importa si se banea una cuenta o hay un reclamo, este limit testing es esencial».

| Desacuerdo | Decisión D126 | Qué reemplaza |
|---|---|---|
| DS-1 | Landing modelada **tal cual** la referencia: layout, componentes, CTA, animaciones y orden de bloques; cambia la paleta. Los textos se adaptan a los hechos de la ficha de nuestro producto | D104 queda reemplazada para el modelado de la landing |
| DS-2 | Logos de Microsoft/Office (y de marcas de terceros que muestren qué se vende) **permitidos** | El riesgo de marca y de la política de Meta queda asumido por el dueño |
| DS-3 | **Un píxel por producto o por idioma**, no uno solo para todo | F63 «el píxel de la cuenta»: el código pasa a tomar el píxel del producto o del mercado |
| DS-4 | **Barra con cuenta regresiva siempre presente**, contando hasta el vencimiento real del precio de lanzamiento (`precio_vencimiento.py`, D78); no se reinicia por visitante | La suspensión de los timers de la regla 2 de CLAUDE.md, solo para esta cuenta regresiva real |

Estado: documentado; se construye cuando Ramiro levante la pausa D125.

## Desacuerdos con el método actual (los decide Ramiro)

**DS-1 — Cuánto se copia de la landing de referencia.**
- **Matías (25/10):** «modelar la pagina tal cual y cambiar solo la paleta». Ya lo había pedido el 20/10 (`conocimiento/matias/00_linea_de_tiempo.md:36`).
- **Método escrito:**
  - **D104** (Ramiro, 22/10, `skills/landing/SKILL.md` §D104): «impronta de la marca (paleta girada, familias propias, radios). Nunca copia literal».
  - **Regla 1 de CLAUDE.md:** «la referencia aporta estructura, nunca hechos».
  - **el kit** (`conocimiento/kit/skills/higgsfield-product-photoshoot/SKILL.md:121`): «Se modela estructura y mecánica; el clon no se publica».
- **Dato de OF-006:** Matías lo ve mal presentado. La campaña: 69 clics, 3 pedidos, CTR 2,31 %.
- **Propuesta para decidir:** copiar layout, componentes, CTA y animaciones tal cual, y cambiar paleta y nombre. Los textos y las imágenes son propios. Los textos de la referencia no se copian, por la regla 1.

**DS-2 — Logos de Microsoft (Office, Excel, Word).**
- **Matías (25/10):** usarlos para que se entienda qué se vende.
- **Método escrito:** no hay una regla nuestra sobre marcas de terceros. El kit prohíbe imitar la marca o el logo de la referencia (línea 121). Usar logos de Microsoft en la landing y en los anuncios puede chocar con las normas de marca de Microsoft y con la política de propiedad intelectual de Meta (riesgo de rechazo del anuncio).
- **Dato de OF-006:** «no se entiende que se vende».
- **Alternativa de menor riesgo:** mostrar capturas reales de Excel y Word en uso y nombrarlos en el texto («para Excel, Word y PowerPoint»), sin los logos oficiales.

**DS-3 — ¿Un píxel por producto o por idioma?**
- **Matías (25/10):** «por producto o por idioma».
- **Método escrito:**
  - Hoy hay un píxel por cuenta: F63 y `pixel.py` lo toman de `datos/cuentas.local.json`.
  - No hay una regla escrita de Matías al respecto en `conocimiento/matias`.
- **Dato de OF-006:** el píxel único vio 1 de 3 compras.

  Ojo: eso es por el consentimiento de cookies y la falta de CAPI (F62), no por compartir el píxel.
- **Decidir:** por producto (más limpio, más píxeles) o por idioma (es / pt…).

**DS-4 — Barra fija con cuenta regresiva y botones que laten.**
- **Matías:** «Siempre: barra fija con el precio de lanzamiento y cuenta regresiva hasta una fecha real, botones grandes que laten» (`conocimiento/matias/cerebro/MODELADO_PASO_A_PASO.md:42`). «Tal cual» la referencia la trae si Office Facile la tiene.
- **Método escrito:** regla 2 de CLAUDE.md: «Sin timers, cuentas regresivas […] suspendido hasta que el vencimiento D78 esté implementado».
- **Dato de OF-006:** sin dato propio.
- **Decidir:** se habilita la cuenta regresiva hasta la fecha real de fin de la oferta de lanzamiento (D78, que ya existe en `precio_vencimiento.py`), o sigue suspendida.

## Pasos humanos que quedan

| # | Paso | Por qué no se automatiza | Quién y cuándo |
|---|---|---|---|
| H1 | Crear la cuenta de Microsoft Clarity y un proyecto por sitio; anotar el ID | Clarity no tiene API pública para crear proyectos | Ramiro, una vez por sitio (o se busca si un proyecto admite varios dominios) |
| H2 | Mirar la propia sesión en Clarity → Recordings después de instalar | El kit lo pide como compuerta visual; se puede reemplazar por la API de exportación de Clarity si da la sesión | Ramiro o el director con la API |
