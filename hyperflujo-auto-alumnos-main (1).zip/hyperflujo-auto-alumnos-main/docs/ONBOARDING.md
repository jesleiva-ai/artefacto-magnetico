# Onboarding (una sola vez por instalación)

> **TAREA 041 (2026-10-23):** el onboarding **detecta** lo que hay y pide solo lo que falta. Lo corre la sesión de Claude Code con `/onboarding` (o el prompt de `ARRANQUE.md`). Herramientas: `herramientas/detectar.py` (detección, anotaciones de la sesión, respuestas únicas, IDs descubiertos) y `herramientas/firmar.py` (la persona firma dueño, topes y autorizaciones en su terminal). Resultado: `estado/onboarding.json` con `ok_obligatorio: true` y `verificar_entorno.py` en verde.

Objetivo: menos de 30 minutos de trabajo humano, sin contar los prerrequisitos que pueden tardar días. Cada paso tiene una verificación gratuita y se vuelve a detectar después de cada uno.

## 0. Prerrequisitos (fuera de los 30 min)

- Meta: cuenta publicitaria en USD con medio de pago, píxel (dataset) y una página de Facebook (Meta no crea páginas por API, F7).
- Hotmart: cuenta verificada con cobro habilitado.
- Netlify, Higgsfield (con créditos), ElevenLabs (opcional) y Claude Code (app o CLI) con sesión iniciada.

## 1. Qué detecta solo y qué hace la persona

| # | Qué | Lo detecta | Si falta, la persona… |
|---|---|---|---|
| 1 | Python ≥ 3.10, Node ≥ 20, Git, Chrome; `npm ci` | `detectar.py` (→ `verificar_entorno.py`) | instala lo que falte |
| 2 | `.env` con `NETLIFY_AUTH_TOKEN`, `HOTMART_BASIC`, `META_SYSTEM_USER_TOKEN` (`ELEVENLABS_API_KEY` opcional) | por nombre, nunca el valor | pega la clave en `.env`, en la línea que le indica el director |
| 3 | Tokens válidos: Netlify, Graph de Meta, token de Hotmart | una lectura gratuita de cada uno | genera uno nuevo y lo reemplaza en `.env` |
| 4 | Conectores meta-ads e Higgsfield (Hotmart opcional) y saldo de Higgsfield | el director, con ToolSearch y una lectura | entra en el login que abre la app (OAuth); carga créditos |
| 5 | Cuenta, píxel y página en `datos/cuentas.local.json` | el director los descubre con el conector | elige si hay más de uno; crea la página si no hay |
| 6 | Límite de gasto de la cuenta ≥ campañas de la cuenta + un producto nuevo | Graph (`spend_cap`) | lo sube en Meta → Facturación y pagos → Límite de gasto |
| 7 | Sesión del robot de Hotmart | `hotmart_sesion.mjs --verificar` | corre `node herramientas/hotmart_sesion.mjs` e inicia sesión en ese Chrome |
| 8 | Dueño, topes y autorizaciones para todos los productos (techo y vigencia) | `detectar.py` | corre `python herramientas/firmar.py dueno`, `… topes`, `… autorizaciones` en **su** terminal |
| 8b | Checkout de Hotmart visto **desde el país** del mercado (E3): precio, moneda y medios de pago | la compuerta del sitio exige una confirmación firmada de los últimos 90 días | con una VPN de un país del mercado abre un checkout de ese mercado y corre `python herramientas/firmar.py checkout` (una vez por mercado; no hay conector ni proxy confiable que lo haga) |
| 9 | Página por mercado o por producto; productos que no se operan; Instagram | se pregunta una vez (`datos/respuestas.local.json`) | contesta |
| 10 | Tarea horaria del vigía | `programar.py` | nada: el director corre `programar.py instalar --confirmar --solo vigia` |

Las corridas principal y pulso por `claude -p` (`programar.py instalar` sin `--solo`) son opcionales: en esta etapa el director es la sesión de Claude Code (`/lanzar`, `/operar`).

## 2. Reglas del onboarding

- Ningún paso gasta: las verificaciones son lecturas gratuitas.
- El agente nunca acepta términos, escribe contraseñas, resuelve captchas ni firma por el dueño: eso lo hace la persona.
- Los IDs descubiertos (cuenta, píxel, página) van solo a `datos/cuentas.local.json` (fuera de git). En lo versionado: `[act_CUENTA]`, `[ID_PIXEL]`, `[ID_PAGINA]`.
- Si un secreto aparece en el chat: no se repite y se avisa que hay que rotarlo.

## 3. Después del onboarding

`/lanzar` saca un producto de punta a punta; `/operar` es la corrida diaria. Lo que sigue siendo humano está en `docs/LIMITES.md`. La operación diaria, en `docs/OPERACION_DIARIA.md`.

`[PENDIENTE: tiempos reales por paso medidos en una instalación limpia]`
