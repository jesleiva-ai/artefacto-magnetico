# Operación diaria

> **Qué incluye:** el director diario (`director.py`, con `lanzar_worker.py`, `ruta_claude.py`, `etapas.py` y `plan.py`) y el vigía horario (`vigia.py`); la caza de ofertas (`cazar.py` + `cazar_biblioteca.mjs`) y la importación de ofertas (`importar_oferta.py`); la landing y el portal (`producto/armar_sitio.py`, `compuerta_sitio.py`, `netlify_deploy.py` y el Profesor); el alta en Hotmart por robot (`hotmart_alta.mjs`); la campaña en Meta por el conector oficial (`meta_campana.py`) y su pausa (`meta_pausa.py`); la lectura de gasto y ventas (`meta_lector.py`, `hotmart_lector.py`); los topes mensual, por proveedor y por producto; el vencimiento del precio de lanzamiento (`precio_vencimiento.py`); la piel por marca (`piel_landing.py`) y la actualización diaria (`actualizar.py`). Entorno: `verificar_entorno.py`; las tareas diarias se registran con `programar.py instalar` al terminar el onboarding.

Qué pasa cada día sin nadie frente a la pantalla y qué tiene que mirar el dueño. Fuente: `docs/ARQUITECTURA.md` §4–§5 y §9. Horas por defecto; se cambian en `datos/config.local.json` (zona horaria de la cuenta publicitaria).

## 1. Calendario

| Hora | Proceso | Qué hace | Modelo |
|---|---|---|---|
| 00:07 | `python herramientas/director.py --modo principal` | Pre-vuelo (entorno, freno, topes, sesión de Hotmart, OAuth de Meta); **activa** lo que está en `lista_para_activar` (Matías larga a medianoche, `analisis/matias/repo/skills/cash-trap-cbo-oro/SKILL.md:92-94`); aplica subidas ya decididas; **opera** las campañas (`operar_campana.py`, una acción por día como máximo); **abre** un producto nuevo y lo avanza hasta `hotmart_enviado`; escribe el plan y el informe | workers por etapa |
| 12:07 | `director.py --modo pulso` | Avanza productos en curso sin abrir nuevos, relee aprobaciones y reescribe el informe (Matías mira al mediodía del día 3, `cash-trap-cbo-oro/SKILL.md:94`) | workers por etapa |
| :37 cada hora | `python herramientas/vigia.py` | Gasto de hoy contra lo autorizado; sonda HTTP de landing y checkout; D92 cada hora en las primeras 48 h; aprobación de Hotmart (si aprobó, dispara `director.py --modo avance --of OF-NNN`); solicitudes «enviando» de más de 30 min → `envio_incierto` | no |

Disparador: vía A `programar.py instalar` (Programador de tareas, «solo con sesión iniciada»); vía B tareas locales de la app de Claude. El director es el mismo en ambas.

## 1b. Lo que corre de verdad desde la TAREA 036

- **00:07 principal:** cerrojo → lecturas reales de ayer y hoy (Meta: gasto por anuncio y `effective_status`; Hotmart: ventas netas sin datos del comprador; lo que falla queda nulo) → repo de productos: sube lo listo (D119: solo el producto; no se recogen reviews ni perfiles) → vencimiento D78 → alta de un candidato si hay cupo (o reemplazo D106) → decisiones por producto (bajas primero) → workers `claude -p` con `--permission-mode dontAsk`, `--max-budget-usd`, entorno acotado y tickets del plan del día (D99) → informe y latido.
- **:37 cada hora, vigía:** gasto de hoy contra el diario × 1,10, doble sonda de landing y checkout, D106 (sin ninguna venta desde la hora 24 de la primera entrega → pausa por Graph y reemplazo) y medición de hoy. Solo pausa; nunca activa ni sube gasto. Sin token de Meta no puede pausar: deja el producto `bloqueada_humano` con «pausar a mano».
- Compuertas nuevas: sin espera de testimonios ni freno de calidad del panel (D119); `validar_anuncios` vigente antes de activar (D103); tope mensual global (un día con gasto nulo cuenta como diario × 1,75).

## 1b-bis. Primer ensayo real: modo solo lectura

`python herramientas/vigia.py --solo-lectura` y `python herramientas/director.py --modo pulso --solo-lectura` leen Meta y Hotmart de verdad y deciden sobre una **copia** del estado: informan «habría pausado / habría ejecutado» sin lanzar workers, sin pausar, sin publicar y sin tocar el estado real (informe en `estado/informes/<fecha>-pulso-solo-lectura.md`). Es el paso previo obligatorio antes de dejar correr el vigía y el director reales.

## 1c. Línea base de la corrida 1 (cierre de la TAREA 034)

| Medida | Valor | Fuente |
|---|---|---|
| Receta del método (hoy `recetas/metodo-consultor`) de punta a punta | ≈ 14,4 h de agente | cierre de la TAREA 034 (Director_H2, 2026-10-22) |
| Lo mismo hecho por Matías | ≈ 4 h | idem |
| OF-005 | publicado, campaña activa con 9 anuncios | idem; confirmado por lectura del conector el 2026-10-22 (campaña ACTIVE, diario USD 30, spend_cap USD 150) |
| Higgsfield usado en la corrida 1 | 132,5 de 500 créditos | idem |

El objetivo de la corrida 2 es bajar esas 14,4 h.

## 2. Vida de un producto

1. Día D 00:07: se caza, nombra, modela, produce, publica el portal, sube el producto al repo de productos, arma la landing borrador y da de alta en Hotmart (seca → real) hasta `hotmart_enviado`. `[PENDIENTE: medir horas reales de agente por etapa]`.
2. Cuando Hotmart aprueba, el vigía encadena las etapas deterministas: embudo, landing publicada, medios, campaña en pausa → `lista_para_activar`.
3. 00:07 siguiente: `activa`. D92 corre cada hora las primeras 48 h.
4. `operando` / `escalando` según `docs/REGLAS_META_ADS.md`; `retirada` cuando corresponde. Nada se borra.

## 3. Qué mira el dueño (un solo canal, F12)

`estado/informes/AAAA-MM-DD.md` (plantilla `plantillas/informe_diario.md`):

- **Plata:** gasto de Meta, neto de Hotmart, ROAS por producto, libro de gasto contra topes y autorizaciones.
- **Decisiones del día:** cada una con la regla que aplicó (D92, Matías `archivo:línea`, Manual) y el desvío si D92 pisó a Matías.
- **Productos:** etapa, intentos, bloqueos.
- **Lo humano pendiente:** `bloqueada_humano`, OAuth o sesión por vencer, tope que no alcanza para la subida, oferta de lanzamiento por vencer (aviso 3 días antes).
- **Fricción nueva** (F-n) y tiempos (agente, humano, espera).

## 4. Cómo interviene el dueño

Solo escribiendo en `estado/decisiones.jsonl`, firmado con un nombre exacto de `datos/dueno.local.json`:

| Decisión | Efecto |
|---|---|
| `veto` | El producto no avanza a la siguiente etapa pagada |
| `reactivar` (nombra la oferta) | Saca un producto de `retirada` |
| `cambiar_tope` | Nuevo techo; la subida pendiente se reevalúa en la próxima corrida |
| `freno` | Crea `estado/freno.json`: solo se permite pausar |

No hay OK por chat dentro del ciclo.

## 5. Si algo sale mal

| Situación | Qué hace el sistema | Qué hace la persona |
|---|---|---|
| Sesión de Hotmart vencida | El robot para, producto en `bloqueada_humano` | Iniciar sesión una vez en el Chrome del robot |
| OAuth de Meta vencido | Pre-vuelo en rojo; no se escribe en Meta | `/mcp` → Authenticate |
| `envio_incierto` | Bloquea solo ese producto | Conciliar por ID en el panel del proveedor y registrar la nota |
| Sin lectura de ventas > 6 h con gasto | `pausada_tecnica`; la ventana D92 se extiende | Revisar credenciales de Hotmart |
| Dos fallos de una etapa en el día | `fallida` o `bloqueada_humano` con lo probado | Leer el motivo en el informe |
| Gasto por encima del diario autorizado | Pausa y aviso | Firmar tope nuevo o dejar pausado |

## 6. Comandos útiles (todos en seco por defecto)

- `python herramientas/ensayo_seco.py --dias 3`
- `python herramientas/programar.py estado`
- `python herramientas/verificar_entorno.py --orquestacion`
- `python -m unittest discover -s pruebas -t .`
