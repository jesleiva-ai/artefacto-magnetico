# Hyperflujo con Overmart (guía aparte)

**Para quién es:** para el alumno que eligió **Overmart** en el onboarding (`datos/config.local.json → hosting: "overmart"`).
**Qué cambia:** con Overmart **no se usa Netlify, ni Cloudflare, ni Hotmart**. Overmart hace todo:
- el producto y la entrega (PDF y portal);
- la landing;
- el checkout;
- los order bumps, el upsell y el downsell;
- las ventas.

Si elegiste Netlify o Cloudflare, esta guía no es para vos: seguí `recetas/metodo-consultor/RECETA.md` como siempre.

> Overmart es la plataforma de Matías y Rami y **está en prueba**. **Si algo falla, anotalo y pasáselo a Matías** (Matías: «que si algo falla, que lo anote y me lo pase»). Cómo, en el §5. Las reglas del método (Cash Trap, Director de Videos, Profesor, sin precio en anuncios, Clarity, sin aviso de cookies) **son las mismas**.

**Cómo compra el cliente** (checkout nuevo):
- **En Argentina:** «Comprar» va directo a Mercado Pago. Los bumps, el upsell y el downsell aparecen **después** de pagar.
- **Fuera de Argentina:** checkout propio de Overmart con Whop. Los bumps van al costado de la tarjeta, el botón «Pagar US$ X» se actualiza solo al marcarlos y se paga todo junto. Después vienen el upsell y el downsell.
- Las tarjetas de los extras llevan imagen.

---

## 0. Antes de empezar (una sola vez)

1. **Cuenta y tienda en Overmart:** crear la cuenta en overmart.app y la tienda. El nombre de la tienda queda en la dirección: `https://<tienda>.overmart.site/`.
2. **Conector de Overmart en Claude:** conectarlo desde claude.ai (Conectores) con los permisos **leer, publicar, webhooks y tiendas**.
   - **Versión:** `tienda` muestra `conector.version_conector`. Tiene que ser **2026-11-15 o más nueva**.
   - **Varias tiendas:** el conector maneja todas tus tiendas sin reconectar. `tienda` dice en cuál estás y cuáles más tenés; `tiendas.puede_cambiar` tiene que venir en `true`.
   - **Reconectar** si la versión es más vieja, si `tiendas.puede_cambiar` viene en `false`, si `tienda` dice que falta «tiendas» o si faltan las herramientas `subdominio`, `carritos` o `avisos`: en Claude, Configuración → Conectores → Overmart → **Desconectar** y después **Conectar**, dejando marcado «Elegir tienda» cuando pida permisos. Después volvé a llamar a `tienda` y confirmá que quedó bien.
   - A veces hace falta reconectar dos veces.
3. **Cobros:** en overmart.app → Configuración → Pagos.
   - **USD:** Whop. La clave se crea en whop.com/dashboard/developer → «Account API Keys», con todos los permisos, incluido `payment:charge`. Sin `payment:charge` el comprador ve el checkout viejo de Whop: no se pierde la venta, pero no aparecen los bumps al costado de la tarjeta.
   - **ARS:** Mercado Pago, si vendés en Argentina.
   - Las claves las carga **el alumno** en la web de Overmart, nunca en el chat.
   - Después, `cobros` tiene que decir `real`, `checkout_nuevo_activo: true` y, en `permisos_clave`, ningún permiso faltante.
   - **Si falta un permiso:** la clave se reemplaza en overmart.app → Configuración → Pagos → Whop → «Reemplazar la API key», **sin desconectar** Whop. Nunca por el chat.
4. **Píxel de Meta:** cargarlo con la herramienta `pixel`, uno por producto. **Clarity:** un proyecto por producto, creado por el alumno en clarity.microsoft.com.
5. **Métricas de anuncios:** en overmart.app → Métricas → Anuncios va el ID de la **cuenta publicitaria** (`act_…`), **no** el del píxel.
6. **Subdominio de la tienda:** `subdominio` → `consultar` dice si un nombre está libre y `elegir` lo toma. Devuelve la `url_compartible`. El link viejo sigue andando y redirige al nuevo.
7. **Recuperación de carritos:** `carritos` → `estado`, y `activar` si está apagada. Manda 3 correos a quien escribió su correo en el checkout y no pagó, con baja de un clic.
8. **Avisos:** `avisos` lista lo que Overmart marca como pendiente. Los que no aplican a tu tienda se descartan.
9. **Dominio propio (opcional):** `dominio_agregar` con un subdominio tuyo (por ejemplo `ofertas.tumarca.com`). Overmart te da los registros DNS para cargar y después se confirma con `dominio_estado`.

**No hace falta:** `NETLIFY_AUTH_TOKEN`, `CLOUDFLARE_API_TOKEN`, cuenta de Hotmart, el robot `hotmart_alta.mjs` ni `netlify_deploy.py`.

---

## 1. Qué cambia en cada etapa del método

| Etapa | Con Netlify/Cloudflare + Hotmart | Con Overmart |
|---|---|---|
| Producto y escalera | igual | igual: se producen los PDF y el portal como siempre |
| Alta del producto | robot de Hotmart | `producto_crear_borrador` (principal) y `embudo` → `agregar` con `nuevo` (los extras, como «solo extra») |
| Entrega | mail de Hotmart con PDF de acceso + portal en Netlify | Overmart entrega el PDF y/o el portal (`portal_zip_base64`, el «libro navegable» de Hyperflujo). No hay portal aparte |
| Landing | Netlify o Cloudflare | **landing libre** de Overmart (ver §2) |
| Checkout | Hotmart | Overmart (Whop en USD y Mercado Pago en ARS) |
| Bumps, upsell y downsell | embudo de Hotmart | `embudo`: hasta 3 bumps y 3 upsells. **Los downsells, solo desde el estudio web** (el conector no los arma). `embudo` lista bumps, upsell y downsell, y la acción `precio` les carga el precio en pesos |
| Ventas para el ROAS | `hotmart_lector.py` | `ventas`, `metricas` y `metricas_anuncios` del conector. Vienen en **bruto**: Overmart no descuenta las comisiones de Whop ni de Mercado Pago (ver `cobros`) |
| Links de los anuncios | link a la landing con utm | `utm_generar` arma el link de cada anuncio, sobre el subdominio elegido |
| Campaña en Meta | igual | igual |

---

## 2. La landing en Overmart (lo más importante)

Hay dos tipos. **Usá siempre la landing LIBRE.**

- **Landing por bloques:** HTML sin `<script>`, dentro de un iframe. No corren ni el píxel, ni Clarity, ni el conversor de moneda, ni las animaciones con JS. **No sirve para el método.**
- **Landing libre:** un .zip con `index.html` y su carpeta (CSS, JS e imágenes), sin filtro. Queda en `https://<tienda>.overmart.site/<oferta>/`. Corren el píxel, Clarity, el conversor, Utmify y las animaciones. **Esta es la que va.**

Cómo se sube:
1. Armar la landing como siempre (`landing-modelada`, Profesor con nota 9 o más), con el píxel y Clarity cargando **al abrir**, sin aviso de cookies.
2. Los botones de compra apuntan al checkout de Overmart: en la landing libre el botón lo ponés vos, con el link que da `estado_producto`.
3. Comprimir la carpeta en .zip.
   - Si pesa más de unos 50 KB, **no** pegarlo en base64: `subida_crear {"tipo":"landing_zip","producto_id":"..."}`, después correr el `curl` que devuelve y después `landing_publicar` con `landing_subida_id`.
4. `landing_publicar` deja un **borrador** con una URL de revisión, que dura 24 h. Se revisa como cliente, en el celular.
5. `activar` lo publica. Después, verificar con curl:
   - que la página dé 200;
   - que estén el píxel y `clarity.ms/tag`;
   - que los botones lleven al checkout;
   - que las imágenes den 200.

**Imágenes:** WebP o JPG (el embudo **no acepta AVIF**), en buena calidad (unos 720 px). Hasta 28 MB todo el .zip.

---

## 3. Paso a paso de un lanzamiento con Overmart

1. **Producto y escalera:** las etapas de siempre (`hf-producir-producto`, `hf-producir-escalera`).
2. **Principal:** `producto_crear_borrador` con:
   - título, precio en USD (y en ARS si vendés en Argentina) y garantía de 7 días;
   - `idioma`;
   - el PDF (`archivo_subida_id`, con `subida_crear {"tipo":"pdf"}` si pesa) y/o el portal (`portal_zip_base64`).
3. **Landing libre:** §2.
4. **Extras:** `embudo` → `agregar` con `nuevo` para cada bump (USD 9,99) y para el upsell. El downsell se arma en el estudio web de overmart.app.
   - **Si vendés también en pesos:** `embudo` lista bumps, upsell y downsell; con la acción `precio` se carga el precio en ARS de cada uno y después `activar`. Sin ese paso, quien paga en pesos no ve los extras.
5. **Checkout:** `producto_editar` con `checkout` (título, color, imagen y logo).
   - En el checkout de Whop, confirmá con `estado_producto` y `producto_editar` → `checkout_donde_se_ve` que se vean el subtítulo, «Qué incluye» y la garantía de 7 días.
   - Miralo como cliente con `url_revision_checkout`.
6. **Revisar** (el conector marca el orden: cobros, productos, checkout, embudo, revisión, publicar y métricas):
   - en cada producto, que el checkout tenga imagen, logo, beneficios y garantía;
   - que tenga al menos un order bump y un upsell, y un downsell si el upsell es caro;
   - que cada bump, upsell y downsell tenga su imagen (mockup o miniatura) **propia**: nunca inventada ni de otros;
   - mirar como cliente los links de revisión: `url_revision` (landing), `url_revision_checkout` (checkout) y `url_revision_pos_pago` (upsell y downsell);
   - no cargar precios ni monedas que no estén decididos en la ficha;
   - `estado_producto`: que `cobro.cobra_en_real` sea true y que `que_falta` esté vacío;
   - `tienda` → `requisitos_real`;
   - `cobros` → `checkout_nuevo_activo` y `permisos_clave`;
   - `carritos` → `estado` activado;
   - `avisos`: sin pendientes que apliquen.
7. **Publicar:** `activar`.
8. **Anuncios:** como siempre (Director de Videos, sin precio, botón «Más información» o «Ver detalles»). El link de cada anuncio sale de `utm_generar`, sobre el subdominio de la tienda.
9. **Campaña:** como siempre, por el conector de Meta, con la Cash Trap.
10. **Seguimiento:**
    - `ventas` (por día y por utm);
    - `metricas` con `por_fuente=true` (visitas, checkouts y ventas por fuente);
    - `metricas_anuncios`: atribuye cada venta por `utm_content`, conjunto o sesión, y lo que no puede atribuir lo muestra como «Sin atribuir».
    - El ROAS se calcula con lo que entra de verdad (`cobros`).

**Compra de prueba:** `compra_prueba` («Probar mi compra») no cobra. No marques el producto como prueba para probar: `excluir_de_metricas` **no frena el cobro**.

---

## 4. Trabas conocidas (para no perder tiempo)

Salieron en la prueba de Matías con Kit Bocaditos Premium (noviembre de 2026):

1. **Imágenes del embudo y del checkout:** solo por URL pública o base64; todavía no hay `subida_crear` de imágenes.
   - **Truco:** subir una carpeta con las imágenes dentro de un .zip de landing en borrador y usar la URL de revisión (`…/_revision/<release>/…/x.webp`). Overmart guarda su propia copia.
2. **Al activar una landing nueva,** algunas imágenes dan 403 entre 20 y 30 segundos. Si hay anuncios corriendo, publicá en un horario con poco tráfico y verificá después.
3. **Con dos monedas (USD y ARS),** los extras sin precio en pesos no se le muestran a quien paga en pesos. Desde el conector 2026-11-15 se arregla con `embudo` → `precio` (ver §3, paso 4).
4. **`embudo` devuelve respuestas muy largas** (con los extras de toda la tienda). Fijate de no enganchar por error un extra de otro producto.
5. **Cambiar la clave de Whop** puede dejar la tienda sin cobrar en USD un rato. Usá «Reemplazar la API key» (sin desconectar), sin campaña corriendo, y revisá `cobros` después.
6. **El checkout nuevo** a veces no muestra los beneficios ni el bloque de garantía, aunque estén cargados. Revisalo con `checkout_donde_se_ve` y `url_revision_checkout` (§3, paso 5).
7. **Si cambiás algo con `producto_editar`,** el borrador nuevo se arma sobre el último borrador que haya, aunque sea de prueba.
8. **`metricas` con `visitas_detalle=true`** fue rechazado por el servidor en la prueba del conector 2026-11-15. Usá `por_fuente=true` y `metricas_anuncios` hasta que lo arreglen.

**Arreglado (8/11):** en un producto en USD con precio en ARS, quien elegía Mercado Pago terminaba pagando en dólares por Whop. Si ves en Whop órdenes argentinas sin pagar de antes del 8 de noviembre, vienen de ese error.

---

## 5. Si algo falla: anotalo y pasáselo a Matías

Matías: «que si algo falla, que lo anote y me lo pase». Overmart está en prueba y cada falla que llega sirve para arreglarla.

1. **Anotala** en `ofertas/OF-xxx/TRABAS_OVERMART.md` (si no existe, crealo), una por falla:
   - fecha y versión del conector (`tienda` → `conector.version_conector`);
   - qué herramienta o pantalla usaste (por ejemplo `embudo` → `precio`, o el checkout en el celular);
   - qué pasó (el mensaje de error tal cual) y qué esperabas;
   - qué probaste y si encontraste una vuelta.
   - **Sin** claves, contraseñas ni datos de compradores.
2. **Pasáselo a Matías:** mandale ese archivo o su contenido. No alcanza con anotarlo: si no le llega, no se arregla.
3. Seguí con lo que no dependa de esa falla.
