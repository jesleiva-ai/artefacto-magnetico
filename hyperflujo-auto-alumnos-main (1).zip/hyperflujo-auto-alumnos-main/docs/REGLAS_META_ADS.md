# Reglas de Meta Ads

Todo el conocimiento de campaña que usa el sistema, organizado y atribuido. **Precedencia: Matías > Manual Maestro**. Receta madre: `recetas/metodo-consultor/RECETA.md`. En el flujo se aplica Matías al pie de la letra (D91); donde Ramiro dice otra cosa, queda como alternativa documentada que él decide. Las reglas ejecutables viven en `datos/reglas_operacion.json` (las aplica `herramientas/operar_campana.py`, código determinista; ningún modelo decide plata).

Convención de citas: `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:<línea>` = skill Cash Trap de **Matías**; `conocimiento/matias/skills/operador-meta-ads/SKILL.md` = su operador; `conocimiento/manual/Manual_Maestro_v1.0.md:<líneas>` = **Manual Maestro** (ver `conocimiento/manual/indice_manual.md`); `conocimiento/kit/skills/meta-ads/SKILL.md` = **Ramiro**. Las cifras de Matías y de Ramiro aparecen solo con su cita; ninguna es una medición de este sistema.

## 1. Vía de acceso (Ramiro + Hyperflujo)

- Meta se toca **solo** por el conector oficial `meta-ads` (OAuth) o por Graph API con tope (`herramientas/meta_ads.py`). **Nunca** el Administrador de anuncios por navegador: línea roja de Ramiro (`conocimiento/kit/skills/meta-ads/SKILL.md`), adoptada.
- Toda escritura figura antes en `estado/planes/AAAA-MM-DD.json` y pasa por `herramientas/puerta.py` (D60). Cada escritura se **relee** (F37: el conector guarda locales distintos a los pedidos).
- IDs de cuenta, píxel y página: solo en `datos/cuentas.local.json`; en lo versionado `[act_CUENTA]`, `[ID_PIXEL]`, `[ID_PAGINA]`. Se descubren por lectura (`ads_get_datasets`, D84/F7).

## 2. Estructura Cash Trap / CBO Oro (Matías)

| Regla | Cita |
|---|---|
| Objetivo Ventas; presupuesto a nivel campaña (CBO); ABO solo si la CBO nunca funciona en esa cuenta | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:20-21` |
| Un solo conjunto de anuncios | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:22` |
| 9 anuncios: 3 C1, 3 C2, 3 C3, nombrados con su nivel | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:23` |
| Español: regiones América del Norte, Central, del Sur, Caribe + España, excluyendo Argentina, Nicaragua y Venezuela; idiomas Español, Español (España), Español (todos); Advantage+ en público y ubicaciones | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:24-28` |
| Audiencia abierta, sin intereses ni edades; país + idioma siempre | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:25-28` |
| Ubicaciones Advantage+ sin quitar ninguna; puntuación de recomendación ≥ 90 % | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:29-30` |
| Una sola campaña por cuenta; anuncios nunca reutilizados en otra campaña o cuenta; si la cuenta ya tiene campañas que venden, se usa otra cuenta | `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:84-88` |

Hyperflujo agrega: 6 reservas `RES-` en pausa (2 por nivel), CTA `LEARN_MORE` (D100), idiomas confirmados por relectura (F37, `[PENDIENTE: claves numéricas de idioma de Meta]`), `utm_content` = nombre del anuncio para atribuir con ventas de Hotmart.

## 3. Creativos por nivel de conciencia (Matías)

- **C1 (emoción):** blooper, antes y después con promesa real, problema cotidiano (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:58-60`).
- **C2 (enseñar):** tutorial, demostración, carrusel educativo (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:63-65`). El testimonio que Matías admite en C2 no se usa: testimonios fuera del sistema (D119).
- **C3 (cierre):** oferta directa, rompe objeciones, el producto por dentro (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:68-70`).
- Los 3 de un nivel distintos entre sí; nunca repetir; los C1 no se sacan aunque no vendan (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:76-79`).
- Hyperflujo (D8): en C2/C3 no hay testimonios ni reseñas (D119), ni timers, cupos ni «antes USD Y» sin dato; el par de precios solo con lista real (D77/D78/D93). Validación: `herramientas/validar_anuncios.py`.
- Ramiro `conocimiento/kit/skills/creativos/` y `conocimiento/kit/skills/metodo-6c/`: alternativa documentada para producir ángulos; las personas de IA presentadas como clientes reales quedan fuera por D8.

## 4. Presupuesto

| Fuente | Regla | Cita |
|---|---|---|
| Matías | Arranque USD 75 por día en cada oferta; de 1 a 5 ofertas a la vez | Matías, 2026-10-22 (`conocimiento/matias/memoria/campanas-prueba-y-escala.md`) |
| Hyperflujo | El presupuesto real es el que firma el dueño en la ficha y en `datos/autorizaciones.local.json`, con `spend_cap` de campaña y límite de la cuenta (D60, D101). Si el arranque de Matías no cabe en los topes, se usa el tope y el informe lo anota como desvío | D101 |

## 5. Tiempos (Matías)

- Activar a medianoche (00:07 en el sistema) y no tocar 48 h completas; mirar al mediodía del día 3 (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:92-94`).
- Vendió algo en 48 h → correr 5 días sin tocar; nada en 48 h → pausar o repensar (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:96-97`).
- El día 3 suele ser el peor; el día 5 arranca; decisiones desde el día 5–7; análisis por semana (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:98-102`).

**En el motor (desde el 2026-10-26):** `datos/reglas_operacion.json → corte.modo = "matias"`: 48 h sin ninguna venta → baja; con ventas, 5 días sin tocar y recién después del día 7, si los netos de Hotmart siguen debajo del gasto, baja. Alternativas: `d92` (24/48 h, Hyperflujo) y `brief_035`, con `HYPERFLUJO_CORTE=<modo>`.

## 6. Escalado (Matías)

- Decisión a nivel campaña con ROAS = ingresos **netos de Hotmart** / gasto de Meta, nunca con el píxel solo (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:106`; Hyperflujo D92).
- 48 h: sin ventas → se apaga; ROAS < 2 → correr hasta 5 días; ROAS ≥ 2 → +30 % (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:108`).
- Subidas siguientes cada 48 h con ROAS ≥ 2; 48 h sin tocar tras subir (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:109-111`).
- Nunca dos cambios el mismo día; 3 días tras cualquier cambio (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:112`).
- Con presupuesto acumulado, sumar anuncios de a uno por nivel, de 9 a 12 (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:113`).
- Sin «surfing» de presupuesto dentro del día (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:130-138`; Manual `conocimiento/manual/Manual_Maestro_v1.0.md:329-339`).
- Hyperflujo: la subida se aplica solo si cabe en los cuatro topes; si no, el informe pide tope nuevo.

## 7. Reemplazo de anuncios (Matías)

1. Perdedor = costo por venta mayor al precio del principal, o gastó ≥ precio sin venta, o no gastó (Matías, 2026-10-25; `conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:122`), atribuida por `utm_content`/`sck` (Hyperflujo). El nuevo va con ángulo nuevo y escenas nuevas; si el ángulo funcionaba, el mismo ángulo en otro formato.
2. Se apaga y se repone con uno **del mismo nivel**; nunca menos de 9 ni desbalanceado (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:123-127`).
3. 3 días antes de la próxima decisión (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:128`).
4. Con ROAS ≥ 2 no se toca ningún anuncio (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:167`).
5. Hyperflujo: sin reserva del nivel no se apaga nada y se encola producir una.

## 8. Diagnóstico (Matías)

Formato de 6 puntos: estado actual, diagnóstico, qué dice el método, **una** intervención, qué no tocar, cuándo volver a mirar (`conocimiento/matias/skills/cash-trap-cbo-oro/SKILL.md:144-151`). Lo genera `herramientas/diagnostico.py` en el informe. La lectura de Ramiro («sin ~50 resultados no concluir», ROAS marginal; `conocimiento/kit/skills/meta-ads/SKILL.md`) se muestra como nota y no decide.

## 9. Manual Maestro (contexto, no decide)

Lo usa el sistema como referencia cuando Matías no cubre el caso. Secciones útiles (líneas según `conocimiento/manual/indice_manual.md`):

| Tema | Líneas |
|---|---|
| Testing ABO / microtesting / 70-30 | 90–154 |
| Superposición en subasta y reutilización de anuncios | 155–173 |
| Estructuras de escala (CBO 1-1-1, Pocket, Mix, Gold, matriz) | 174–256 |
| Cost Cap y Bid Cap | 257–304 |
| Escalado gradual, agresivo, surfing, historial de ventas | 305–367 |

`[PENDIENTE: licencia del Manual Maestro]` (copiado a `conocimiento/manual/` por pedido del Arquitecto en TAREA 041 H, con la licencia todavía sin resolver). Las etiquetas del Manual ([MENTOR DICE], [INTERPRETACIÓN OPERATIVA], [NO DEFINIDO / AMBIGUO]) se conservan al citar.

## 10. Pendientes

- `[PENDIENTE]` claves numéricas de idioma confirmadas por relectura (F37).
- `[PENDIENTE: dueño]` arranque 50/75 de Matías contra el tope firmado de cada lanzamiento.
- `[PENDIENTE]` cruzar con `conocimiento/matias/skills/operador-meta-ads/SKILL.md:12-58` línea por línea; hoy se citan sus rangos desde `docs/ARQUITECTURA.md` §9.2.

## 11. Actualizaciones de Matías (2026-10-21 al 2026-10-26)

Fuente de todo: `conocimiento/matias/notas/2026-10-26_novedades_del_metodo.md` y `conocimiento/matias/memoria/`. Donde choca con lo de arriba, gana Matías, también en el código.

| Tema | Regla nueva | Cita |
|---|---|---|
| Arranque | USD 75 por día en cada oferta; de 1 a 5 ofertas a la vez | Matías, 2026-10-22 |
| Activar | El agente prende la campaña solo; 48 h sin tocar; sin ventas se apaga; con ventas 5 días sin tocar; después +30 % cada 48 h | Matías, 2026-10-22 |
| Ubicaciones | Por **regiones** de Meta, nunca país por país; siempre sin VE ni NI y sin los países donde vende el original | Matías, 2026-10-22 (`conocimiento/matias/cerebro/LECCIONES.md`) |
| Idiomas | Español, Español (España), Español (todos); nunca inglés (revisar en pantalla antes de guardar) | Matías, 2026-10-21 |
| Botón | «Más información» en C1/C2, «Ver detalles» en C3; nunca «Comprar», tampoco en el texto | Matías, 2026-10-22 |
| Píxel | Uno nuevo por idioma o país, en el portafolio de la cuenta publicitaria; cargado en Hotmart, Utmify y el conjunto | Matías, 2026-10-25 |
| Escala | **Una sola campaña por producto y mercado**: se sube la principal +30 % cada 48 h si gana. No duplicarla en otras cuentas con el mismo píxel (el 25/10 se pisaron: 47 compras en Meta, 30 en Hotmart; gasto ×9, ventas ×2–3) | Matías, 2026-10-26 (supera «una CBO Oro de USD 100 en cada cuenta», 2026-10-24) |
| Reemplazo | Se cambian los anuncios con costo por venta mayor al precio y los que no gastaron o gastaron sin vender; mismo nivel, ángulo nuevo, escenas nuevas | Matías, 2026-10-25 |
| Banco de reserva | Los anuncios de las campañas pausadas del mismo producto pasan a ser la reserva | Matías, 2026-10-26 |
| Creativos | Cada anuncio modela uno de los 9 mejores ganadores del original (días al aire + copias); tomas de 4 s como máximo | Matías, 2026-10-22 |
| Atribución | Utmify: parámetros de URL en cada anuncio y su script en las páginas antes del checkout; sin el código, la venta llega con «UTMs vacías» | Matías, 2026-10-21/22 (`conocimiento/matias/cerebro/UTMIFY.md`) |
| Antes de cargar | Cuenta con medio de pago, con la página y el píxel compartidos, y la moneda revisada | lecciones del lanzamiento en francés, 2026-10-25/26 |

