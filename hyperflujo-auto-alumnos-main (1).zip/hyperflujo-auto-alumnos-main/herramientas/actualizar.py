"""Actualización diaria del repo (Ramiro, 2026-10-27: «que el director haga todos los días un git pull para que se
mantenga actualizado»). Trae lo nuevo de origin con `git pull --ff-only`, como mucho una vez por día.

Nunca pisa nada de la persona: si hay cambios propios en archivos versionados, commits locales o la rama no es la
principal, no toca el repo y lo anota. Los datos propios (.env, datos/*.local.*, estado/, ofertas en curso) están fuera
de git y el pull no los toca.

Lo llaman:
- la corrida diaria del director (`director.py --modo principal`, al terminar: la versión nueva corre desde mañana);
- el hook SessionStart de `.claude/settings.json`, al abrir Claude Code (`--si-toca`: sale enseguida si ya se hizo hoy);
- `/actualizar`, a mano (sin `--si-toca`: prueba aunque ya se haya hecho hoy).

Kit de skills (Matías, 2026-11-11): si `kit-skills/` cambió desde la última vez,
corre su instalador (`kit-skills/instalar.py`), que deja sus skills, comandos y herramientas en la compu de la persona
(~/.claude/skills, ~/.claude/commands, ~/herramientas, ~/cerebro) sin borrar nada: lo que difiere queda con copia
.respaldo al lado. Se marca en ~/.hyperflujo/kit_skills.json; si falla, se reintenta la próxima vez.

    python herramientas/actualizar.py [--si-toca] [--hook]
Última línea: JSON del contrato. Con --hook imprime solo una línea corta (es lo que lee Claude Code al abrir).
"""
import argparse
import datetime as dt
import hashlib
import json
import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
MARCA = RAIZ / "estado" / "actualizacion.json"
RAMAS = ("main", "master")
KIT = RAIZ / "kit-skills"
MARCA_KIT = Path.home() / ".hyperflujo" / "kit_skills.json"
# Nombres viejos del kit (antes del 11/11/2026): se quitan al actualizar para que no queden duplicados.
VIEJOS_KIT = [Path.home() / ".claude" / "skills" / "quien-cobra-lbdp", Path.home() / ".hyperflujo" / "kit_biblia.json"]


def _huella_kit(kit=KIT):
    h = hashlib.sha256()
    for f in sorted(p for p in kit.rglob("*") if p.is_file() and "__pycache__" not in p.parts):
        h.update(f.relative_to(kit).as_posix().encode("utf-8"))
        h.update(f.read_bytes())
    return h.hexdigest()


def _quitar_viejos(viejos=None):
    """Borra la copia vieja de quien-cobra del kit y su marca anterior (ya vienen con el nombre nuevo)."""
    import shutil
    for v in (VIEJOS_KIT if viejos is None else viejos):
        try:
            if v.is_dir():
                shutil.rmtree(v)
            elif v.is_file():
                v.unlink()
        except OSError:
            pass


def instalar_kit(ejecutar=subprocess.run, kit=KIT, marca=MARCA_KIT):
    """Instala o actualiza el kit de skills si cambió. Nunca rompe a quien lo llama."""
    if not (kit / "instalar.py").is_file():
        return None
    try:
        if marca == MARCA_KIT:
            _quitar_viejos()
        huella = _huella_kit(kit)
        try:
            previa = json.loads(marca.read_text(encoding="utf-8"))
        except Exception:
            previa = {}
        if previa.get("huella") == huella and previa.get("ok"):
            return {"ok": True, "motivo": "kit de skills al día", "saltado": True}
        r = ejecutar([sys.executable, str(kit / "instalar.py")], capture_output=True, text=True,
                     encoding="utf-8", errors="replace", timeout=600)
        ok = r.returncode == 0
        res = {"ok": ok, "huella": huella, "fecha": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
               "motivo": "kit de skills instalado: skills, comandos y herramientas nuevas" if ok
               else "el instalador del kit de skills avisó un problema: correr `python kit-skills/instalar.py` y leer el final"}
        if not ok:
            res["salida"] = ((r.stdout or "") + (r.stderr or ""))[-1500:]
        marca.parent.mkdir(parents=True, exist_ok=True)
        marca.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
        return res
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "motivo": "no se pudo instalar el kit de skills: %s" % str(e)[:300]}


def _git(args, ejecutar=subprocess.run):
    r = ejecutar(["git", "-C", str(RAIZ)] + args, capture_output=True, text=True, timeout=120)
    return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()


def _leer_marca():
    try:
        return json.loads(MARCA.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _guardar(r):
    try:
        MARCA.parent.mkdir(parents=True, exist_ok=True)
        MARCA.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass


def actualizar(si_toca=False, ejecutar=subprocess.run, hoy=None):
    hoy = hoy or dt.date.today().isoformat()
    m = _leer_marca()
    if si_toca and m.get("fecha") == hoy and m.get("ok"):   # si falló, se reintenta en la próxima
        return {"ok": True, "codigo": 0, "motivo": "ya se actualizó hoy", "artefactos": [], "saltado": True}
    r = {"fecha": hoy, "hora": dt.datetime.now().astimezone().isoformat(timespec="seconds")}
    try:
        cod, rama, _ = _git(["rev-parse", "--abbrev-ref", "HEAD"], ejecutar)
        if cod != 0:
            r.update(ok=False, codigo=3, motivo="no es un repositorio git (se instaló sin clonar): actualizar a mano")
        elif rama not in RAMAS:
            r.update(ok=False, codigo=4, motivo="la rama actual es «%s», no la principal: no se toca" % rama)
        else:
            cod, cambios, _ = _git(["status", "--porcelain", "--untracked-files=no"], ejecutar)
            if cambios:
                r.update(ok=False, codigo=5, motivo="hay cambios propios en archivos del repo: no se actualiza para no pisarlos",
                         archivos=cambios.splitlines()[:20])
            else:
                _, antes, _ = _git(["rev-parse", "--short", "HEAD"], ejecutar)
                cod, sal, err = _git(["pull", "--ff-only", "--quiet"], ejecutar)
                _, despues, _ = _git(["rev-parse", "--short", "HEAD"], ejecutar)
                if cod != 0:
                    r.update(ok=False, codigo=6, motivo="git pull no pudo avanzar solo (sin red o commits propios): %s" % (err or sal)[:300])
                elif antes == despues:
                    r.update(ok=True, codigo=0, motivo="ya estaba al día (%s)" % despues)
                else:
                    _, log, _ = _git(["log", "--oneline", "--no-merges", "%s..%s" % (antes, despues)], ejecutar)
                    _, nombres, _ = _git(["diff", "--name-only", antes, despues], ejecutar)
                    r.update(ok=True, codigo=0, motivo="actualizado %s → %s" % (antes, despues), cambios=log.splitlines()[:30])
                    if "package.json" in nombres.splitlines() or "package-lock.json" in nombres.splitlines():
                        r["aviso"] = "cambiaron las dependencias de Node: correr `npm install`"
    except Exception as e:  # noqa: BLE001 — actualizar nunca rompe la corrida que lo llama
        r.update(ok=False, codigo=7, motivo="no se pudo actualizar: %s" % str(e)[:300])
    _guardar(r)
    r["artefactos"] = ["estado/actualizacion.json"]
    return r


def main(argv=None):
    ap = argparse.ArgumentParser(description="git pull --ff-only del repo, como mucho una vez por día, sin pisar cambios propios.")
    ap.add_argument("--si-toca", action="store_true", help="no hace nada si ya se actualizó hoy")
    ap.add_argument("--hook", action="store_true", help="salida de una línea para el hook SessionStart de Claude Code")
    a = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    r = actualizar(si_toca=a.si_toca)
    kit = instalar_kit()
    if kit:
        r["kit_skills"] = kit
    if a.hook:
        if not r.get("saltado"):
            linea = "hyperflujo: %s" % r["motivo"]
            if r.get("aviso"):
                linea += " · " + r["aviso"]
            if not r["ok"]:
                linea += " · contale a la persona y seguí (no es bloqueante)"
            print(linea)
        if kit and not kit.get("saltado"):
            print("hyperflujo: %s%s" % (kit["motivo"], "" if kit["ok"] else " · contale a la persona y seguí"))
        return 0
    print(json.dumps(r, ensure_ascii=False))
    return 0 if r["ok"] else r["codigo"]


if __name__ == "__main__":
    sys.exit(main())
