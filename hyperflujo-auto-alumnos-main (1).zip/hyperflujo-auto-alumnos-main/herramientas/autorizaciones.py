#!/usr/bin/env python3
"""autorizaciones.py — lector de datos/autorizaciones.local.json (Hyperflujo D82/D88; revisión 035 h. 6).

vigentes(oferta, hoy, raiz=None) -> set de alcances vigentes para esa oferta. Archivo faltante o ilegible = conjunto
vacío (todo paso que requiera autorización queda en espera). Una autorización sin firmante, texto literal o fecha no
cuenta. El archivo tiene deny de Edit para los workers (.claude/settings.json).
"""
import json
import os
from pathlib import Path

ALCANCES_VALIDOS = {"gasto_meta", "gasto_medios", "gasto_anthropic", "publicar", "finalizar_registro",
                    "activar_embudo", "activar_campana", "escalar", "reactivar", "campanas_compartidas",
                    "desactivar_oferta_al_vencer",   # TAREA 036 D: vencimiento D78
                    "elegir_candidato"}   # TAREA 041: el código elige el mejor candidato validado de la caza


def _raiz(raiz=None):
    return Path(raiz or os.environ.get("HYPERFLUJO_RAIZ") or Path(__file__).resolve().parents[1])


def _valida(a, oferta, hoy):
    if a.get("alcance") not in ALCANCES_VALIDOS:
        return False
    for k in ("texto_literal", "firmante", "fecha"):
        v = a.get(k)
        if not v or str(v).startswith("<") or v == "AAAA-MM-DD":
            return False
    ofs = a.get("ofertas")
    if ofs != "todas" and oferta not in (ofs or []):
        return False
    vh = a.get("vigente_hasta")
    return vh is None or str(hoy) <= str(vh)


def vigentes(oferta, hoy, raiz=None, datos=None):
    if datos is None:
        try:
            datos = json.loads((_raiz(raiz) / "datos" / "autorizaciones.local.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return set()
    return {a["alcance"] for a in datos.get("autorizaciones", []) if _valida(a, oferta, hoy)}
