#!/usr/bin/env python3
"""avisos.py — un solo canal de avisos al dueño (F12), configurado en datos/config.local.json → avisos.tipo.

    enviar(asunto, texto, nivel="alerta") -> {"ok", "canal", "motivo"}

  * archivo (por defecto): estado/avisos.jsonl + estado/AVISO_ULTIMO.md (lo muestran el informe, /operar y detectar.py).
  * smtp: correo a avisos.destinatario con SMTP_HOST, SMTP_PORT, SMTP_USER y SMTP_PASS del .env.
  * webhook: POST JSON {asunto, texto, nivel, hora} a AVISO_WEBHOOK_URL del .env.
Siempre se escribe además el archivo, aunque el canal externo falle (un aviso nunca se pierde en silencio). Nunca lleva
claves ni datos de compradores. Solo biblioteca estándar.
"""
import json
import os
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402


def _archivo(asunto, texto, nivel, hora):
    p = rutas.ruta("estado", "avisos.jsonl")
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps({"hora": hora, "nivel": nivel, "asunto": asunto, "texto": texto}, ensure_ascii=False) + "\n")
    rutas.ruta("estado", "AVISO_ULTIMO.md").write_text("# %s — %s\n\n%s\n\n%s\n" % (nivel.upper(), asunto, hora, texto),
                                                        encoding="utf-8")


def _smtp(asunto, texto, destinatario, claves):
    import smtplib
    from email.message import EmailMessage
    m = EmailMessage()
    m["Subject"], m["From"], m["To"] = "[hyperflujo] %s" % asunto, claves.clave("SMTP_USER"), destinatario
    m.set_content(texto)
    with smtplib.SMTP(claves.clave("SMTP_HOST"), int(claves.clave("SMTP_PORT")), timeout=30) as s:
        s.starttls()
        s.login(claves.clave("SMTP_USER"), claves.clave("SMTP_PASS"))
        s.send_message(m)


def _webhook(asunto, texto, nivel, hora, claves):
    datos = json.dumps({"asunto": asunto, "texto": texto, "nivel": nivel, "hora": hora}).encode("utf-8")
    req = urllib.request.Request(claves.clave("AVISO_WEBHOOK_URL"), data=datos, method="POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        r.read()


def enviar(asunto, texto, nivel="alerta", config=None, transporte=None):
    """transporte(canal, asunto, texto) inyectable para pruebas (nunca red en la suite)."""
    hora = rutas.ahora().isoformat(timespec="seconds")
    _archivo(asunto, texto, nivel, hora)
    conf = (rutas.cargar_dato("config", defecto={}) or {}) if config is None else config
    av = conf.get("avisos") or {}
    tipo = av.get("tipo") or "archivo"
    if tipo == "archivo":
        return {"ok": True, "canal": "archivo", "motivo": "estado/avisos.jsonl"}
    try:
        if transporte is not None:
            transporte(tipo, asunto, texto)
        else:
            import claves
            if tipo == "smtp":
                _smtp(asunto, texto, av.get("destinatario"), claves)
            elif tipo == "webhook":
                _webhook(asunto, texto, nivel, hora, claves)
            else:
                return {"ok": False, "canal": tipo, "motivo": "tipo de aviso desconocido: queda solo en el archivo"}
        return {"ok": True, "canal": tipo, "motivo": "enviado"}
    except Exception as e:   # el archivo ya está escrito: el aviso no se pierde
        return {"ok": False, "canal": tipo, "motivo": "%s: %s (queda en estado/avisos.jsonl)" % (type(e).__name__, str(e)[:120])}
