#!/usr/bin/env python3
"""calco_idioma.py — la web de un producto en otro idioma es un CALCO de la web que vende (Matías, 2026-10-26).

Matías, 2026-10-26: «Tiene que ser tal cual igual el calco… para todos los países donde se venda Método Consultor
tiene que ser la misma web traducida. Nada más. No puede cambiar nada» (`conocimiento/matias/cerebro/
WEB_EN_OTRO_IDIOMA_CALCO.md`). Vale para la landing, las páginas del embudo, la de gracias y el portal.

Compara el HTML publicado del idioma original con el del idioma nuevo y falla si cambió la estructura:
- mismas secciones, en el mismo orden (etiqueta + id + clases);
- la misma cantidad de títulos (h1–h3), imágenes, videos, botones y precios con `data-usd` (conversor de moneda);
- los mismos estilos (hojas `<link rel=stylesheet>` y bloques `<style>` idénticos: colores, fuentes, animaciones);
- `dir="rtl"` cuando el idioma nuevo es árabe o hebreo.
Lo que puede cambiar y solo se avisa: el texto, los links (checkout, portal), el píxel y el `src` de las imágenes con
texto visible (la misma foto editada en el idioma). No reemplaza la comparación de capturas de celular: la completa.

Uso: python herramientas/calco_idioma.py ORIGINAL.html NUEVO.html [--idioma he]
Sale 0 si es calco, 1 si no (con la lista de diferencias en JSON). Solo biblioteca estándar, sin red.
"""
import argparse
import hashlib
import json
import sys
from html.parser import HTMLParser

SECCIONES = {"section", "header", "footer", "main", "nav", "article", "aside"}
RTL = {"ar", "he", "fa", "ur"}


class _Lector(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.secciones, self.imagenes, self.estilos = [], [], []
        self.cuentas = {"títulos": 0, "videos": 0, "botones": 0, "precios data-usd": 0}
        self.html_attrs, self._en_style, self._style = {}, False, []

    def handle_starttag(self, tag, attrs):
        a = {k: (v or "") for k, v in attrs}
        if tag == "html":
            self.html_attrs = a
        if tag in SECCIONES:
            self.secciones.append(f"{tag}#{a.get('id', '')}.{'.'.join(sorted(a.get('class', '').split()))}")
        if tag in ("h1", "h2", "h3"):
            self.cuentas["títulos"] += 1
        if tag == "img":
            self.imagenes.append(a.get("src", ""))
        if tag == "video":
            self.cuentas["videos"] += 1
        if tag == "button" or (tag == "a" and any(c in a.get("class", "").split() for c in ("btn", "boton", "cta", "button"))):
            self.cuentas["botones"] += 1
        if "data-usd" in a:
            self.cuentas["precios data-usd"] += 1
        if tag == "link" and "stylesheet" in a.get("rel", "").lower():
            self.estilos.append("link:" + a.get("href", ""))
        if tag == "style":
            self._en_style, self._style = True, []

    def handle_endtag(self, tag):
        if tag == "style" and self._en_style:
            self._en_style = False
            css = "".join(self._style).strip()
            self.estilos.append("style:" + hashlib.sha256(css.encode("utf-8")).hexdigest()[:12])

    def handle_data(self, data):
        if self._en_style:
            self._style.append(data)


def leer(html):
    p = _Lector()
    p.feed(html or "")
    p.close()
    return p


def comparar(original, nuevo, idioma=None):
    """→ {ok, errores, avisos}. `original` y `nuevo` son el HTML como texto."""
    a, b = leer(original), leer(nuevo)
    errores, avisos = [], []
    if a.secciones != b.secciones:
        errores.append({"que": "secciones distintas (cantidad, orden, id o clases)", "original": a.secciones, "nuevo": b.secciones})
    for k in a.cuentas:
        if a.cuentas[k] != b.cuentas[k]:
            errores.append({"que": f"cantidad de {k} distinta", "original": a.cuentas[k], "nuevo": b.cuentas[k]})
    if len(a.imagenes) != len(b.imagenes):
        errores.append({"que": "cantidad de imágenes distinta: no se agregan ni se sacan fotos", "original": len(a.imagenes), "nuevo": len(b.imagenes)})
    else:
        for i, (x, y) in enumerate(zip(a.imagenes, b.imagenes), 1):
            if x != y:
                avisos.append({"que": f"imagen {i} cambió: solo vale si es la misma foto con el texto en el idioma", "original": x, "nuevo": y})
    if a.estilos != b.estilos:
        errores.append({"que": "estilos distintos (colores, fuentes o animaciones)", "original": a.estilos, "nuevo": b.estilos})
    lang = (idioma or b.html_attrs.get("lang", "")).split("-")[0].lower()
    if lang in RTL and b.html_attrs.get("dir", "").lower() != "rtl":
        errores.append({"que": f"el idioma {lang} se lee de derecha a izquierda: falta dir=\"rtl\" en <html>"})
    if lang and a.html_attrs.get("lang", "").split("-")[0].lower() == lang:
        avisos.append({"que": "el atributo lang de <html> no cambió", "nuevo": b.html_attrs.get("lang", "")})
    return {"ok": not errores, "errores": errores, "avisos": avisos}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("original")
    ap.add_argument("nuevo")
    ap.add_argument("--idioma", help="código del idioma nuevo (es, de, he…); si falta, se toma de <html lang>")
    x = ap.parse_args(argv)
    with open(x.original, encoding="utf-8") as f1, open(x.nuevo, encoding="utf-8") as f2:
        r = comparar(f1.read(), f2.read(), x.idioma)
    print(json.dumps(r, ensure_ascii=False, indent=2))
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
