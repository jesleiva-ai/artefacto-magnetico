#!/usr/bin/env node
/**
 * capturar_referencia.mjs — una sola visita a la página ganadora para el paso «modelar» (D104), en navegador limpio.
 *
 *   node herramientas/capturar_referencia.mjs --url https://ejemplo.com/ --salida ofertas/<OF>/entradas/modelar/ref
 *
 * Qué hace: abre Google Chrome con un contexto NUEVO y vacío (sin cookies ni perfil del dueño), carga la URL una vez,
 * baja la página para que cargue lo diferido, y guarda en `--salida` (siempre dentro de `entradas/`, fuera de git):
 *   - pagina.html: el DOM renderizado + el CSS de la página y los estilos computados de los elementos visibles
 *     (para que piel_landing.extraer_look lea paleta, fuentes, radios y bloques aunque la página use CSS externo);
 *   - captura_390.png y captura_1440.png (página completa);
 *   - estructura.json: secciones en orden (etiqueta, nivel de título, cantidad de botones e imágenes), sin texto.
 * Qué no hace: no hace clic, no completa formularios, no compra, no guarda texto de la referencia en nada versionado
 * (regla 1: la referencia aporta estructura y look, nunca hechos). Consumo: cero. Solo lectura pública.
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';

function args(argv) {
  const a = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--url') a.url = argv[++i];
    else if (argv[i] === '--salida') a.salida = argv[++i];
  }
  return a;
}

const a = args(process.argv.slice(2));
if (!a.url || !a.salida || !/[\\/]entradas[\\/]/.test(resolve(a.salida) + '/')) {
  console.log(JSON.stringify({ ok: false, codigo: 2, motivo: 'faltan --url y --salida (la salida va dentro de entradas/, fuera de git)' }));
  process.exit(2);
}
const { chromium } = await import('playwright');
let navegador;
for (const extra of [{ channel: 'chrome' }, { channel: 'msedge' }, {}]) {
  try { navegador = await chromium.launch({ headless: true, ...extra }); break; } catch { /* siguiente */ }
}
if (!navegador) { console.log(JSON.stringify({ ok: false, codigo: 2, motivo: 'no se pudo abrir un navegador local' })); process.exit(2); }
const salida = resolve(a.salida);
mkdirSync(salida, { recursive: true });
try {
  const ctx = await navegador.newContext({ locale: 'es-ES', viewport: { width: 1440, height: 900 } });
  const p = await ctx.newPage();
  await p.goto(a.url, { waitUntil: 'networkidle', timeout: 60000 }).catch(() => p.waitForTimeout(5000));
  for (let i = 0; i < 12; i++) { await p.mouse.wheel(0, 1200); await p.waitForTimeout(400); }
  await p.evaluate(() => window.scrollTo(0, 0));
  await p.waitForTimeout(800);
  const datos = await p.evaluate(() => {
    let css = '';
    for (const hoja of Array.from(document.styleSheets)) {
      try { css += Array.from(hoja.cssRules).map(r => r.cssText).join('\n') + '\n'; } catch { /* hoja de otro origen */ }
    }
    const comp = [];
    const sel = 'body, h1, h2, h3, p, a, button, section, header, footer, [class*="card"], [class*="btn"], [role="button"]';
    for (const el of Array.from(document.querySelectorAll(sel)).slice(0, 600)) {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      const s = getComputedStyle(el);
      comp.push(`${el.tagName.toLowerCase()}{color:${s.color};background-color:${s.backgroundColor};font-family:${s.fontFamily};border-radius:${s.borderRadius};${s.boxShadow !== 'none' ? 'box-shadow:' + s.boxShadow + ';' : ''}}`);
    }
    const bloques = [];
    const raiz = document.querySelector('main') || document.body;
    for (const el of Array.from(raiz.querySelectorAll('section, header, footer, form, details, blockquote, ul')).slice(0, 80)) {
      if (el.closest('section') && el.tagName !== 'SECTION' && el.closest('section') !== el) continue;
      const h = el.querySelector('h1, h2, h3');
      bloques.push({ etiqueta: el.tagName.toLowerCase(), titulo: h ? h.tagName.toLowerCase() : null,
        botones: el.querySelectorAll('button, a[href]').length, imagenes: el.querySelectorAll('img, svg, video').length,
        alto_px: Math.round(el.getBoundingClientRect().height) });
    }
    return { css, comp: comp.join('\n'), bloques, alto: document.body.scrollHeight };
  });
  const html = (await p.content()).replace('</head>', `<style>/* css de la página */\n${datos.css}\n/* estilos computados */\n${datos.comp}\n</style></head>`);
  writeFileSync(join(salida, 'pagina.html'), html, 'utf8');
  writeFileSync(join(salida, 'estructura.json'), JSON.stringify({ url: a.url, leido_en: new Date().toISOString(),
    alto_px: datos.alto, bloques: datos.bloques }, null, 1), 'utf8');
  await p.screenshot({ path: join(salida, 'captura_1440.png'), fullPage: true });
  await p.setViewportSize({ width: 390, height: 844 });
  await p.waitForTimeout(800);
  await p.screenshot({ path: join(salida, 'captura_390.png'), fullPage: true });
  console.log(JSON.stringify({ ok: true, codigo: 0, motivo: 'referencia capturada (una visita, navegador limpio)', bloques: datos.bloques.length,
    archivos: ['pagina.html', 'estructura.json', 'captura_1440.png', 'captura_390.png'] }));
} finally {
  await navegador.close();
}
