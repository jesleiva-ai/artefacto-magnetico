#!/usr/bin/env python3
"""cazar.py — etapa 0 del ciclo (por_cazar → candidato): busca en la Biblioteca de anuncios pública, sin sesión, ofertas
ganadoras para modelar, en TODOS los rubros y mercados de datos/cazar.json, y devuelve 5 candidatos con evidencia
(TAREA 037 parte A; criterios literales de Matías, citados en datos/cazar.json).

    python herramientas/cazar.py plan                                  # búsquedas que haría (rubro × mercado)
    python herramientas/cazar.py barrer   --dir <trabajo> [--max 70]   # búsquedas por palabra (robot anónimo)
    python herramientas/cazar.py perfiles --dir <trabajo> [--max 30]   # perfiles de los anunciantes que más aparecen
    python herramientas/cazar.py competencia --dir <trabajo> [--top 8] # idioma de destino de los mejores
    python herramientas/cazar.py procesar --dir <trabajo> [--revision revision.json] [--of OF-NNN]
    python herramientas/cazar.py verificar --of OF-NNN                 # verificar_cazada (lo usa el director)

<trabajo>: carpeta de la caza. En el ciclo es ofertas/OF-NNN (escaneos con IDs reales en entradas/cazar/, fuera de git;
candidatos con IDs enmascarados en referencia/). Para una pasada suelta: ofertas/_candidatos con --prefijo OF-NNN.
Lectura: herramientas/cazar_biblioteca.mjs (Chrome con contexto nuevo y vacío; nunca la sesión del dueño; captcha o
login → para). Lo que no ve el código (marca personal, si es digital, qué vende) lo escribe el worker en
revision.json; el código nunca lo inventa. Nunca se usa el total declarado («~N resultados») como conteo.
Consumo: cero. Solo biblioteca estándar.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

ROBOT = "cazar_biblioteca.mjs"
CITA_REGLAS = "analisis/matias/repo/skills/cazador-de-ofertas/SKILL.md:73-82"
CITA_COMPETENCIA = "analisis/matias/repo/skills/cazador-de-ofertas/references/competencia.md:65-70"
VEREDICTOS = ("azul", "viable", "competido", "saturado")


# ------------------------------------------------------------------ configuración
def cargar_config(ruta=None):
    p = Path(ruta) if ruta else rutas.ruta("datos", "cazar.json")
    cfg = json.loads(p.read_text(encoding="utf-8"))
    local = rutas.ruta("datos", "cazar.local.json")
    if ruta is None and local.exists():   # el dueño puede ampliar rubros o mercados sin tocar el versionado
        extra = json.loads(local.read_text(encoding="utf-8"))
        for k in ("rubros", "mercados"):
            cfg[k] = cfg.get(k, []) + [x for x in extra.get(k, []) if x.get("id") not in {y["id"] for y in cfg.get(k, [])}]
        for k in ("umbrales", "competencia", "puntaje", "barrido"):
            cfg.setdefault(k, {}).update(extra.get(k, {}))
    return cfg


def _norm(s):
    s = unicodedata.normalize("NFKD", str(s or "").lower())
    return "".join(c for c in s if not unicodedata.combining(c))


def plan_busquedas(cfg, maximo=None):
    """Búsquedas (rubro × mercado × término) intercaladas: primero un término de cada rubro en cada mercado, en ronda,
    para que un corte por --max no deje mercados ni rubros sin mirar (sin preferencia de nicho ni de país)."""
    rondas = defaultdict(list)
    for r in cfg["rubros"]:
        for m in cfg["mercados"]:
            for i, t in enumerate(r["terminos"].get(m["idioma"], [])):
                rondas[i].append({"rubro": r["id"], "mercado": m["id"], "idioma": m["idioma"], "termino": t,
                                  "pais": m.get("pais_busqueda") or "ALL"})
    out = []
    for i in sorted(rondas):
        lista = rondas[i]
        # intercalar mercados: rubro1-es, rubro1-pt, … para que cada tramo cubra todos los idiomas
        out += lista
    # orden final: por ronda, y dentro de la ronda alternando mercados
    por_mercado = defaultdict(list)
    for b in out:
        por_mercado[b["mercado"]].append(b)
    final = []
    while any(por_mercado.values()):
        for m in [x["id"] for x in cfg["mercados"]]:
            if por_mercado[m]:
                final.append(por_mercado[m].pop(0))
    return final[:maximo] if maximo else final


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", _norm(s)).strip("-")[:40] or "x"


# ------------------------------------------------------------------ lectura (robot)
def leer(argumentos, salida, *, ejecutar=None, timeout=150):
    """Corre el robot de lectura. `ejecutar` inyectable (pruebas: nunca red)."""
    salida = Path(salida)
    salida.parent.mkdir(parents=True, exist_ok=True)
    # El robot es CÓDIGO: se resuelve contra la carpeta de este script, no contra la raíz de datos (HYPERFLUJO_RAIZ),
    # y node corre en la carpeta del repo para encontrar node_modules/playwright (B en seco, 24/10).
    codigo = Path(__file__).resolve().parent
    cmd = ["node", str(codigo / ROBOT)] + list(argumentos) + ["--salida", str(Path(salida).resolve())]
    if ejecutar is not None:
        return ejecutar(cmd, salida)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=timeout, cwd=str(codigo.parent))
    except subprocess.TimeoutExpired:
        return {"ok": False, "codigo": 2, "motivo": "lectura sin respuesta en %d s" % timeout}
    lineas = [x for x in (r.stdout or "").strip().splitlines() if x.strip()]
    try:
        return json.loads(lineas[-1])
    except (IndexError, ValueError):
        return {"ok": False, "codigo": 2, "motivo": (r.stderr or r.stdout or "sin salida")[-300:]}


def dir_escaneos(trabajo):
    return Path(trabajo) / "entradas" / "cazar" / "escaneos"


def barrer(trabajo, cfg, maximo=None, ejecutar=None, minutos=None, log=print, mercados=None, rubros=None,
           esperar_freno=None, dormir=time.sleep):
    """Búsquedas por palabra. Se saltean las ya leídas (reanudable). Para en captcha/login/freno de Meta (código 6).
    `mercados` / `rubros`: subconjuntos opcionales; por defecto, todos. `esperar_freno`: segundos de espera ante el
    primer código 6 antes de reintentar UNA sola vez (nunca se evade el freno: si vuelve, se para)."""
    d = dir_escaneos(trabajo)
    inicio = time.time()
    hechos = []
    reintento_usado = False
    for b in plan_busquedas(cfg):
        if (mercados and b["mercado"] not in mercados) or (rubros and b["rubro"] not in rubros):
            continue
        if maximo is not None and len(hechos) >= maximo:
            break
        if minutos and (time.time() - inicio) > minutos * 60:
            log("corte por tiempo (%s min)" % minutos)
            break
        f = d / ("b_%s_%s_%s.json" % (b["mercado"], b["rubro"], _slug(b["termino"])))
        if f.exists():
            continue
        c = d / f.name.replace("b_", "c_", 1)
        if c.exists():   # la misma búsqueda ya se leyó para medir competencia: se reusa, no se vuelve a leer
            f.write_bytes(c.read_bytes())
            continue
        r = leer(["--busqueda", b["termino"], "--pais", b["pais"], "--scrolls",
                  str(cfg.get("barrido", {}).get("scrolls_busqueda", 2))], f, ejecutar=ejecutar)
        if f.exists():
            esc = json.loads(f.read_text(encoding="utf-8"))
            esc["busqueda"] = b
            f.write_text(json.dumps(esc, ensure_ascii=True, indent=1), encoding="utf-8")
        hechos.append({**b, "ok": r.get("ok"), "tarjetas": r.get("tarjetas"), "declarados": r.get("declarados")})
        log("%s %s/%s «%s»: %s tarjetas (~%s)" % ("ok" if r.get("ok") else "X", b["mercado"], b["rubro"], b["termino"],
                                                  r.get("tarjetas"), r.get("declarados")))
        if r.get("codigo") == 6:
            if esperar_freno and not reintento_usado:
                reintento_usado = True
                log("Meta frenó la lectura (código 6): espera de %d s y un solo reintento" % esperar_freno)
                for x in f.parent.glob(f.name):
                    x.unlink()   # la lectura frenada no cuenta como leída
                dormir(esperar_freno)
                continue
            log("Meta pidió captcha o login, o frenó la lectura: se para (no se resuelve ni se evade)")
            break
        time.sleep(cfg.get("barrido", {}).get("pausa_entre_lecturas_s", 2) if ejecutar is None else 0)
    return hechos


def _limpio(texto):
    """Quita sustitutos sueltos (un emoji partido) para que todo lo derivado se pueda escribir en UTF-8."""
    return texto.encode("utf-8", "surrogatepass").decode("utf-8", "replace") if texto else texto


def cargar_escaneos(trabajo, prefijo):
    out = []
    for f in sorted(dir_escaneos(trabajo).glob(prefijo + "_*.json")):
        try:
            out.append(json.loads(_limpio(json.dumps(json.loads(f.read_text(encoding="utf-8")), ensure_ascii=False))))
        except ValueError:
            continue
    return out


# ------------------------------------------------------------------ agregado
def excluido(anuncio_o_pagina, cfg):
    """Motivo de exclusión (nichos de OF-001/OF-005, circuito de Matías) o None."""
    ex = cfg.get("exclusiones", {})
    texto = _norm(" ".join(str(anuncio_o_pagina.get(k) or "") for k in ("pagina", "texto", "titulo", "dominio", "destino")))
    for a in ex.get("anunciantes", []):
        if _norm(a) and _norm(a) == _norm(anuncio_o_pagina.get("pagina")):
            return "circuito de Matías u oferta propia: %s" % a
    for d in ex.get("dominios", []):
        if d and d in _norm(anuncio_o_pagina.get("dominio") or anuncio_o_pagina.get("destino") or ""):
            return "dominio excluido: %s" % d
    for p in ex.get("palabras", []):   # comienzo de palabra: «связан» (relacionado) no es «вязание» (tejido)
        if _norm(p) and re.search(r"(?<!\w)" + re.escape(_norm(p)), texto):
            return "nicho excluido (OF-001/OF-005, tejido o manualidades): «%s»" % p
    return None


def contar_resultados(escaneo):
    """Cuenta solo lo visto: tarjetas activas sin pocas impresiones y sus copias. El declarado va aparte (cobertura)."""
    an = [a for a in escaneo.get("anuncios", []) if a.get("activo") and not a.get("pocas_impresiones")]
    copias = sum(int(a.get("copias") or 1) for a in an)
    decl = escaneo.get("declarados")
    return {"tarjetas": len(an), "copias": copias, "declarados": decl,
            "cobertura": (min(100, round(100 * copias / decl)) if decl else None),
            "pocas_impresiones": sum(1 for a in escaneo.get("anuncios", []) if a.get("pocas_impresiones"))}


def anunciantes_de_busquedas(escaneos, cfg):
    """Agrupa las búsquedas por página: en cuántas búsquedas aparece, mercados, copias vistas, ejemplo de texto."""
    pags = {}
    for esc in escaneos:
        b = esc.get("busqueda") or {}
        for a in esc.get("anuncios", []):
            pid = a.get("pagina_id")
            if not pid or not a.get("activo"):
                continue
            p = pags.setdefault(pid, {"pagina_id": pid, "pagina": a.get("pagina"), "busquedas": set(), "mercados": set(),
                                      "rubros": set(), "copias_vistas": 0, "anuncios": {}, "dominios": Counter()})
            p["busquedas"].add(b.get("termino"))
            p["mercados"].add(b.get("mercado"))
            p["rubros"].add(b.get("rubro"))
            if a["id"] not in p["anuncios"]:
                p["anuncios"][a["id"]] = a
                p["copias_vistas"] += int(a.get("copias") or 1)
                if a.get("dominio"):
                    p["dominios"][a["dominio"]] += int(a.get("copias") or 1)
    out = []
    for p in pags.values():
        muestra = next(iter(p["anuncios"].values()))
        motivo = excluido({"pagina": p["pagina"], "texto": " ".join((x.get("texto") or "") + " " + (x.get("titulo") or "")
                                                                   for x in p["anuncios"].values()),
                           "dominio": " ".join(p["dominios"])}, cfg)
        out.append({"pagina_id": p["pagina_id"], "pagina": p["pagina"], "apariciones": len(p["busquedas"]),
                    "mercados": sorted(x for x in p["mercados"] if x), "rubros": sorted(x for x in p["rubros"] if x),
                    "anuncios_vistos": len(p["anuncios"]), "copias_vistas": p["copias_vistas"],
                    "dominio_principal": (p["dominios"].most_common(1)[0][0] if p["dominios"] else None),
                    "texto_ejemplo": muestra.get("texto"), "excluido": motivo})
    out.sort(key=lambda x: (-x["copias_vistas"], -x["apariciones"]))
    return out


def resumen_perfil(escaneo, hoy=None):
    """Perfil escaneado (view_all_page_id): activos reales, copias, más antiguo, días, destinos y concentración."""
    hoy = hoy or rutas.ahora().date()
    an = [a for a in escaneo.get("anuncios", []) if a.get("activo") and not a.get("pocas_impresiones")]
    inicios = sorted(a["inicio"] for a in an if a.get("inicio"))
    dest = Counter()
    for a in an:
        dest[a.get("dominio") or "sin-destino"] += int(a.get("copias") or 1)
    copias = sum(dest.values())
    principal, c_principal = (dest.most_common(1)[0] if dest else (None, 0))
    dias = (hoy - date.fromisoformat(inicios[0])).days if inicios else None
    mas_15 = sum(1 for x in inicios if (hoy - date.fromisoformat(x)).days > 15)
    nuevos_7d = sum(1 for x in inicios if (hoy - date.fromisoformat(x)).days <= 7)
    decl = escaneo.get("declarados")
    return {"declarados": decl, "tarjetas": len(an), "copias": copias, "inicio_mas_antiguo": inicios[0] if inicios else None,
            "inicio_mas_reciente": inicios[-1] if inicios else None, "dias_mas_antiguo": dias,
            "tarjetas_mas_15_dias": mas_15, "nuevos_7d": nuevos_7d,
            "destinos": [{"dominio": k, "copias": v} for k, v in dest.most_common(5)],
            "destino_principal": principal, "copias_destino_principal": c_principal,
            "concentracion_porcentaje": round(100 * c_principal / copias) if copias else None,
            "cobertura_porcentaje": min(100, round(100 * copias / decl)) if decl else None,
            "pocas_impresiones": sum(1 for a in escaneo.get("anuncios", []) if a.get("pocas_impresiones")),
            "parcial_motivo": escaneo.get("parcial_motivo")}


def pistas(textos, cfg):
    """Pistas automáticas (no veredictos): físico, marca personal, gratis (lead magnet)."""
    t = _norm(" ".join(x or "" for x in textos))
    out = {}
    for clave, palabras in (cfg.get("descarte_automatico") or {}).items():
        if clave.startswith("_"):
            continue
        hits = sorted({p.strip() for p in palabras if _norm(p) in t})
        if hits:
            out[clave] = hits
    return out



# ------------------------------------------------------------------ perfiles y competencia (lecturas)
def _rev(revision, p):
    return (revision or {}).get(p.get("pagina_id")) or (revision or {}).get(p.get("pagina") or "") or {}


def descartado_por_revision(r):
    """No digital, marca personal, gratis o duplicado de otro anunciante (mismo producto en otra página)."""
    return r.get("digital") is False or r.get("marca_personal") is True or r.get("gratis") is True or bool(r.get("duplicado_de"))


def perfiles(trabajo, cfg, maximo=None, ejecutar=None, log=print, revision=None):
    """Escanea el perfil (view_all_page_id) de los anunciantes no excluidos que más copias mostraron en las búsquedas.
    Con `revision` (juicio del worker sobre los textos) se saltean los no digitales, marcas personales y gratis, y van
    primero los confirmados como digitales: cada lectura cuenta (Meta frena la lectura anónima si se abusa)."""
    pags = anunciantes_de_busquedas(cargar_escaneos(trabajo, "b"), cfg)
    rutas.escribir_json(Path(trabajo) / "entradas" / "cazar" / "anunciantes.json", pags)
    b = cfg.get("barrido", {})
    elegibles = [p for p in pags if not p["excluido"] and p["copias_vistas"] >= b.get("anunciantes_min_en_busquedas", 2)
                 and not descartado_por_revision(_rev(revision, p))]
    elegibles.sort(key=lambda p: (-int(_rev(revision, p).get("prioridad") or 0), _rev(revision, p).get("digital") is not True,
                                  -p["copias_vistas"]))
    hechos = []
    for p in elegibles[:maximo or b.get("perfiles_max", 30)]:
        f = dir_escaneos(trabajo) / ("p_%s.json" % p["pagina_id"])
        if f.exists():
            continue
        r = leer(["--perfil", p["pagina_id"], "--scrolls", str(b.get("scrolls_perfil", 5))], f, ejecutar=ejecutar)
        hechos.append({"pagina": p["pagina"], "ok": r.get("ok"), "tarjetas": r.get("tarjetas"), "declarados": r.get("declarados")})
        log("%s perfil %s: %s tarjetas (~%s)" % ("ok" if r.get("ok") else "X", p["pagina"], r.get("tarjetas"), r.get("declarados")))
        if r.get("codigo") == 6:
            log("Meta pidió captcha o login: se para (no se resuelve)")
            break
        time.sleep(b.get("pausa_entre_lecturas_s", 2) if ejecutar is None else 0)
    return hechos


def veredicto_paises(competidores, cfg=None):
    """Matías (competencia.md:65-70): cuenta solo competidores DIRECTOS (mismo tema y formato, activos hoy).
    competidores: [{"pagina", "copias", "dias"}]. Devuelve azul / viable / competido / saturado con el motivo."""
    c = (cfg or {}).get("competencia") or {}
    fuerte = c.get("copias_fuerte", 20)
    n = len(competidores)
    fuertes = [x for x in competidores if (x.get("copias") or 0) >= fuerte]
    viejos = [x for x in competidores if (x.get("dias") or 0) > 30]
    if n == 0:
        v = "azul"
    elif n >= 8 or len(fuertes) >= c.get("fuertes_saturado", 3):
        v = "saturado"
    elif n > c.get("viable_max", 3) or fuertes or viejos:
        v = "competido"
    else:
        v = "viable"
    return {"veredicto": v, "competidores": n, "fuertes": len(fuertes),
            "motivo": "%d directos, %d con %d+ copias, %d con más de 30 días (%s)" % (n, len(fuertes), fuerte, len(viejos), CITA_COMPETENCIA)}


FORMATOS = ("pdf", "ebook", "e-book", "guia", "guide", "livro", "apostila", "libro", "buch", "ratgeber", "livre", "plantilla",
            "template", "vorlage", "книга", "planner", "printable", "imprimible", "download", "descarga", "planilha",
            "planilla", "spreadsheet", "excel", "modeles", "cheat sheet", "workbook")


def competidores_directos(escaneo, propio=None, palabras_formato=FORMATOS):
    """Aproximación del código: anunciantes activos de la búsqueda en el idioma de destino cuyo texto nombra un formato
    digital. El worker confirma «mismo tema y formato» en revision.json (competencia.md:33-36). Si el original ya pauta
    en ese idioma, cuenta y se marca (`original: true`): Matías descarta lo que ya se vende en el idioma de destino."""
    hoy = rutas.ahora().date()
    por = {}
    for a in escaneo.get("anuncios", []):
        if not a.get("activo") or a.get("pocas_impresiones"):
            continue
        es_propio = bool(propio and a.get("pagina_id") == propio)
        t = _norm((a.get("texto") or "") + " " + (a.get("titulo") or "") + " " + (a.get("dominio") or ""))
        if not es_propio and not any(_norm(w) in t for w in palabras_formato):
            continue
        x = por.setdefault(a.get("pagina_id"), {"pagina": a.get("pagina"), "copias": 0, "dias": 0, "original": es_propio})
        x["copias"] += int(a.get("copias") or 1)
        if a.get("inicio"):
            x["dias"] = max(x["dias"], (hoy - date.fromisoformat(a["inicio"])).days)
    return sorted(por.values(), key=lambda x: -x["copias"])


def _frases(valor):
    return [valor] if isinstance(valor, str) else [x for x in (valor or []) if x]


def competencia(trabajo, cfg, candidatos, ejecutar=None, log=print):
    """Para cada candidato, búsquedas en el idioma de cada mercado de destino distinto del de origen. Matías pide dos
    búsquedas por país, una de nicho + formato digital (competencia.md:10-36): el worker puede dar una lista de frases
    por mercado en `consulta_destino`; si no da ninguna, se usa el término del rubro."""
    terminos = {r["id"]: r["terminos"] for r in cfg["rubros"]}
    for c in candidatos:
        propias = c.get("consulta_destino") or {}
        for m in cfg["mercados"]:
            if m["idioma"] == c.get("idioma_origen") or (propias and m["id"] not in propias):
                continue   # con frases propias del worker se miden solo esos mercados (cada lectura cuenta)
            frases = _frases(propias.get(m["id"])) or ((terminos.get(c.get("rubro")) or {}).get(m["idioma"]) or [])[:1]
            for consulta in frases:
                f = dir_escaneos(trabajo) / ("c_%s_%s_%s.json" % (m["id"], c.get("rubro"), _slug(consulta)))
                if f.exists() or (dir_escaneos(trabajo) / ("b_%s_%s_%s.json" % (m["id"], c.get("rubro"), _slug(consulta)))).exists():
                    continue   # ya leída
                r = leer(["--busqueda", consulta, "--pais", m.get("pais_busqueda") or "ALL", "--scrolls", "2"], f, ejecutar=ejecutar)
                if f.exists():
                    esc = json.loads(f.read_text(encoding="utf-8"))
                    esc["busqueda"] = {"mercado": m["id"], "idioma": m["idioma"], "rubro": c.get("rubro"), "termino": consulta}
                    f.write_text(json.dumps(esc, ensure_ascii=True, indent=1), encoding="utf-8")
                log("%s competencia %s/%s «%s»: %s tarjetas" % ("ok" if r.get("ok") else "X", m["id"], c.get("rubro"), consulta, r.get("tarjetas")))
                if r.get("codigo") == 6:
                    return
                time.sleep(cfg.get("barrido", {}).get("pausa_entre_lecturas_s", 2) if ejecutar is None else 0)


def paises_de(trabajo, cfg, candidato, escaneos_c=None):
    """Veredicto por mercado de destino: une los competidores directos de todas las búsquedas de ese mercado (las frases
    propias del worker si las dio; si no, las del rubro). Un competidor que aparece en dos búsquedas cuenta una vez."""
    propias = candidato.get("consulta_destino") or {}
    por_mercado = {}
    for esc in (escaneos_c if escaneos_c is not None else cargar_escaneos(trabajo, "c")):
        b = esc.get("busqueda") or {}
        if b.get("rubro") != candidato.get("rubro") or candidato.get("idioma_origen") == b.get("idioma"):
            continue
        frases = _frases(propias.get(b.get("mercado")))
        if (propias and not frases) or (frases and b.get("termino") not in frases):
            continue   # con frases propias, solo cuentan esas búsquedas (el término genérico del rubro puede ser otro producto)
        x = por_mercado.setdefault(b.get("mercado"), {"comp": {}, "consultas": [], "declarados": []})
        x["consultas"].append(b.get("termino"))
        x["declarados"].append(esc.get("declarados"))
        for cpt in competidores_directos(esc, propio=candidato.get("pagina_id")):
            previo = x["comp"].get(cpt["pagina"])
            if previo is None or cpt["copias"] > previo["copias"]:
                x["comp"][cpt["pagina"]] = cpt
    out = {}
    for mercado, x in por_mercado.items():
        comp = sorted(x["comp"].values(), key=lambda c: -c["copias"])
        v = veredicto_paises(comp, cfg)
        v.update(consultas=x["consultas"], declarados=x["declarados"], nombres=[c["pagina"] for c in comp[:6]],
                 original_presente=any(c.get("original") for c in comp))
        if v["original_presente"]:   # el original ya vende en ese idioma: nunca azul ni viable
            v["veredicto"] = "saturado" if v["veredicto"] == "saturado" else "competido"
            v["motivo"] += "; el original ya pauta en este idioma"
        out[mercado] = v
    return out


# ------------------------------------------------------------------ umbrales, puntaje y elección
def aplicar_umbrales(c, cfg):
    """Checklist de Matías (cumple / no_cumple / revisar / sin_dato) con su cita. No baja ningún umbral."""
    u = cfg["umbrales"]
    p = c.get("perfil") or {}
    rev = c.get("revision") or {}
    chk = {}
    tarjetas, decl, cob = p.get("tarjetas"), p.get("declarados"), p.get("cobertura_porcentaje")
    parcial = cob is None or cob < u.get("cobertura_min_para_descartar", 80)
    if tarjetas is None:
        chk["perfil_activos"] = "sin_dato"
    elif tarjetas >= u["perfil_activos_min"]:
        chk["perfil_activos"] = "cumple"
    elif parcial and (decl or 0) >= u["perfil_activos_min"]:
        chk["perfil_activos"] = "revisar"   # escaneo parcial: falta el conteo completo (SKILL.md:65)
    else:
        chk["perfil_activos"] = "no_cumple"
    copias = p.get("copias")
    if copias is None:
        chk["oferta_activos"] = "sin_dato"
    elif copias >= u["oferta_activos_min"]:
        chk["oferta_activos"] = "cumple"
    else:
        chk["oferta_activos"] = "revisar" if parcial and (decl or 0) >= u["oferta_activos_min"] else "no_cumple"
    dias = p.get("dias_mas_antiguo")
    chk["dias"] = "sin_dato" if dias is None else ("cumple" if dias > u["dias_min"] else "no_cumple")
    chk["pocas_impresiones_excluidas"] = "cumple"
    for clave, campo, malo in (("digital", "digital", False), ("sin_marca_personal", "marca_personal", True),
                               ("no_es_gratis", "gratis", True)):
        v = rev.get(campo)
        chk[clave] = "revisar" if v is None else ("no_cumple" if v == malo else "cumple")
    mercado = c.get("mercado_destino")
    v = ((c.get("paises") or {}).get(mercado) or {}).get("veredicto") if mercado else None
    chk["idioma_destino_libre"] = {"azul": "cumple", "viable": "cumple", "competido": "revisar", "saturado": "no_cumple"}.get(v, "sin_dato")
    if c.get("excluido") or "no_cumple" in (chk["digital"], chk["sin_marca_personal"], chk["no_es_gratis"]):
        ver = "descartada"
    elif any(chk[k] == "no_cumple" for k in ("perfil_activos", "oferta_activos", "dias", "idioma_destino_libre")):
        ver = "no_cumple_reglas"
    elif all(x == "cumple" for x in chk.values()):
        ver = "validada"
    else:
        ver = "falta_confirmar"
    return {"checklist": chk, "veredicto": ver, "cita": CITA_REGLAS}


HUECO = {"azul": 1.0, "viable": 0.8, "competido": 0.35, "saturado": 0.0}
ORDEN_VEREDICTO = {"validada": 0, "falta_confirmar": 1, "no_cumple_reglas": 2, "descartada": 3}


def puntaje(c, cfg):
    """Hipótesis 0-100 (pesos en datos/cazar.json → puntaje). No prueba ventas: ordena candidatos."""
    w = cfg["puntaje"]
    p = c.get("perfil") or {}
    v = ((c.get("paises") or {}).get(c.get("mercado_destino")) or {}).get("veredicto")
    partes = {
        "volumen_perfil": w["volumen_perfil"] * min(1.0, (p.get("tarjetas") or 0) / 60.0),
        "antiguedad": w["antiguedad"] * min(1.0, (p.get("dias_mas_antiguo") or 0) / 120.0),
        "copias_oferta": w["copias_oferta"] * min(1.0, (p.get("copias_destino_principal") or 0) / 60.0),
        "hueco_idioma": w["hueco_idioma"] * HUECO.get(v, 0.3),
        "digital_confirmado": w["digital_confirmado"] * (1.0 if (c.get("revision") or {}).get("digital") is True else 0.0),
    }
    return {"total": round(sum(partes.values())), "partes": {k: round(x, 1) for k, x in partes.items()}}


def mercados_habilitados(cfg=None):
    """Ids de mercado de la caza (datos/cazar.json → mercados[].id) cuyo idioma tiene un mercado de lanzamiento con
    «habilitado»: true en datos/mercados.json (Ramiro 2026-10-24: es-ES y es-LATAM). None = sin filtro (mercados.json
    sin la clave, instalaciones viejas)."""
    m = rutas.leer_json(rutas.ruta("datos", "mercados.json"), defecto={}) or {}
    lanz = [v for k, v in m.items() if not k.startswith("_") and isinstance(v, dict)]
    if not any("habilitado" in v for v in lanz):
        return None
    idiomas = {v.get("idioma") for v in lanz if v.get("habilitado") is True}
    cfg = cfg if cfg is not None else cargar_config()
    return {x["id"] for x in cfg.get("mercados", []) if x.get("idioma") in idiomas}


def elegir_mercado(c, habilitados=None):
    """Mercados de destino ordenados por competencia medida (azul > viable > competido > saturado), solo entre los
    habilitados para lanzar si se pasan (la competencia se mide en todos; el destino sale de los habilitados)."""
    paises = {k: v for k, v in (c.get("paises") or {}).items() if habilitados is None or k in habilitados}
    return [k for k, _ in sorted(paises.items(), key=lambda kv: (VEREDICTOS.index(kv[1]["veredicto"]), kv[1]["competidores"]))]


def elegir_cinco(candidatos, cfg, n=5, maximo_candidatos=12):
    """Los n mejores con rubro y mercado de destino distintos (pedido de la 037). Cada candidato puede ir a cualquiera de
    los mercados medidos; se elige la combinación con más candidatos, después la de mejores veredictos y después la de
    más puntaje (búsqueda exhaustiva acotada: pocos candidatos pasan las reglas). Nunca entra uno fuera de las reglas."""
    opciones = []
    habilitados = mercados_habilitados(cfg)
    # Con menos mercados habilitados que candidatos (hoy solo «es»), «mercado distinto» dejaría uno solo: se exige
    # rubro distinto y el mercado se repite (Ramiro 2026-10-24: se lanza en español).
    distinguir_mercado = habilitados is None or len(habilitados) >= n
    for c in candidatos:
        variantes = []
        destinos = elegir_mercado(c, habilitados)
        if c.get("paises") and not destinos:
            continue   # medido, pero ningún mercado habilitado es destino posible: no es candidato para lanzar
        for m in (destinos or [None]):
            x = dict(c, mercado_destino=m)
            x.update(umbrales=aplicar_umbrales(x, cfg), puntaje=puntaje(x, cfg))
            if x["umbrales"]["veredicto"] not in ("descartada", "no_cumple_reglas"):
                variantes.append(x)
        if variantes:
            opciones.append(variantes)
    opciones.sort(key=lambda vs: -max(v["puntaje"]["total"] for v in vs))
    opciones = opciones[:maximo_candidatos]
    mejor = {"sel": [], "valor": (0, 0, 0, 0)}

    def valor(sel):   # más candidatos; mejores veredictos; más mercados de destino medidos; más puntaje
        return (len(sel), -sum(ORDEN_VEREDICTO[x["umbrales"]["veredicto"]] for x in sel),
                sum(1 for x in sel if x.get("mercado_destino")), sum(x["puntaje"]["total"] for x in sel))

    def buscar(i, sel):
        if valor(sel) > mejor["valor"]:
            mejor.update(sel=list(sel), valor=valor(sel))
        if len(sel) == n or i == len(opciones) or len(sel) + len(opciones) - i < mejor["valor"][0]:
            return
        usados_r = {x.get("rubro") for x in sel}
        usados_m = {x.get("mercado_destino") for x in sel if x.get("mercado_destino")} if distinguir_mercado else set()
        for x in opciones[i]:
            if x.get("rubro") in usados_r or (x.get("mercado_destino") and x["mercado_destino"] in usados_m):
                continue
            sel.append(x)
            buscar(i + 1, sel)
            sel.pop()
        buscar(i + 1, sel)

    buscar(0, [])
    return sorted(mejor["sel"], key=lambda x: (ORDEN_VEREDICTO[x["umbrales"]["veredicto"]], -x["puntaje"]["total"]))


# ------------------------------------------------------------------ armado de candidatos y salida
def armar_candidatos(trabajo, cfg, revision=None, hoy=None):
    """Une búsquedas + perfiles + revisión del worker + competencia → candidatos con evidencia (IDs reales)."""
    revision = revision or {}
    pags = {p["pagina_id"]: p for p in anunciantes_de_busquedas(cargar_escaneos(trabajo, "b"), cfg)}
    esc_c = cargar_escaneos(trabajo, "b") + cargar_escaneos(trabajo, "c")   # las búsquedas del rubro en cada idioma sirven de competencia
    out = []
    for esc in cargar_escaneos(trabajo, "p"):
        pid = esc.get("pagina_id")
        base = pags.get(pid) or {"pagina_id": pid, "pagina": None, "rubros": [], "mercados": []}
        an = [a for a in esc.get("anuncios", []) if a.get("activo")]
        nombre = base.get("pagina") or (an[0]["pagina"] if an else None)
        rev = revision.get(pid) or revision.get(nombre or "") or {}
        textos = [(a.get("texto") or "") + " " + (a.get("titulo") or "") for a in an]
        perfil = resumen_perfil(esc, hoy)
        ganadores = sorted(an, key=lambda a: (-(a.get("copias") or 1), a.get("inicio") or "9999"))[:5]
        c = {"pagina_id": pid, "pagina": nombre, "rubro": rev.get("rubro") or (base.get("rubros") or [None])[0],
             "que_vende": rev.get("que_vende"), "mercados_vistos": base.get("mercados", []),
             "idioma_origen": rev.get("idioma_origen"), "consulta_destino": rev.get("consulta_destino"),
             "perfil": perfil, "revision": rev, "pistas": pistas(textos, cfg),
             "excluido": base.get("excluido") or excluido({"pagina": nombre, "texto": " ".join(textos),
                                                          "dominio": perfil.get("destino_principal")}, cfg),
             "anuncios_ganadores": [{"id": a["id"], "inicio": a.get("inicio"), "copias": a.get("copias"), "formato": a.get("formato"),
                                     "titulo": a.get("titulo"), "primera_linea": (a.get("texto") or "")[:140],
                                     "dominio": a.get("dominio")} for a in ganadores],
             "enlace_perfil": "https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL"
                              "&view_all_page_id=%s&search_type=page" % pid,
             "leido_en": esc.get("leido_en"), "fuente": esc.get("fuente")}
        c["paises"] = paises_de(trabajo, cfg, c, esc_c)
        out.append(c)
    return out


RE_ID = re.compile(r"(?<![\w-])\d{9,20}(?![\w-])")


def enmascarar(obj, mapa=None):
    """Reemplaza IDs de biblioteca y de página por [ID_n] (regla 8: nada real versionado)."""
    mapa = {} if mapa is None else mapa

    def sub(m):
        if m.group(0) not in mapa:
            mapa[m.group(0)] = "[ID_BIBLIOTECA_%d]" % (len(mapa) + 1)
        return mapa[m.group(0)]
    return json.loads(RE_ID.sub(sub, json.dumps(obj, ensure_ascii=False))), mapa


def documento(elegidos, todos, of=None):
    return {"of": of, "generado_en": rutas.ahora().isoformat(timespec="seconds"),
            "fuente": "biblioteca_publica_anonima (herramientas/cazar_biblioteca.mjs: Chrome con contexto nuevo, sin sesión)",
            "reglas": CITA_REGLAS, "competencia": CITA_COMPETENCIA, "consumo_usd": 0, "candidatos": elegidos,
            "elegido": None, "motivo_elegido": "lo confirma o veta el dueño en estado/decisiones.jsonl (confirmar_candidato / vetar_candidato)",
            "evaluados": len(todos),
            "descartados": [{"pagina": "[página con nombre de persona]" if (c.get("revision") or {}).get("persona") else c["pagina"],
                             "rubro": c.get("rubro"), "motivo": c.get("excluido") or (
                                 "%s, fuera de los 5 (rubro o mercado ya tomado por otro con más puntaje)" % c["umbrales"]["veredicto"]
                                 if c["umbrales"]["veredicto"] in ("validada", "falta_confirmar") else c["umbrales"]["veredicto"])}
                            for c in todos if c["pagina_id"] not in {e["pagina_id"] for e in elegidos}][:60]}


def salida_versionada(trabajo, doc, prefijo=None):
    """Candidatos con IDs enmascarados (versionable) + versión local con los reales (entradas/, fuera de git)."""
    trabajo = Path(trabajo)
    rutas.escribir_json(trabajo / "entradas" / "cazar" / ("%s_candidatos.local.json" % (prefijo or "candidatos")), doc)
    versionado, mapa = enmascarar(doc)
    for c in versionado.get("candidatos", []):   # página con nombre de persona: en lo versionado va su alias de producto
        rev = c.get("revision") or {}
        if rev.get("persona"):
            c["pagina"] = "%s (página con nombre de persona)" % (rev.get("alias") or "[producto]")
            rev.pop("nota", None)
    for c in versionado.get("candidatos", []):   # nombres de competidores (a veces personas): solo en la versión local
        for v in (c.get("paises") or {}).values():
            v.pop("nombres", None)
    rutas.escribir_json(trabajo / "entradas" / "cazar" / ("%s_ids.local.json" % (prefijo or "candidatos")),
                        {v: k for k, v in mapa.items()})
    if prefijo:
        destino = trabajo / ("%s_candidatos.json" % prefijo)
    else:
        destino = trabajo / "referencia" / "candidatos.json"
        rutas.escribir_json(trabajo / "referencia" / "paises.json",
                            {c["pagina"]: c.get("paises") for c in versionado["candidatos"]})
    rutas.escribir_json(destino, versionado)
    return destino


def verificar_cazada(of):
    """Verificación por artefacto (regla 7) antes de pasar a «candidato»: referencia/candidatos.json con 1 a 5
    candidatos con evidencia medida y checklist, fuente anónima, sin IDs reales y de 3 días o menos."""
    p = rutas.ruta("ofertas", of, "referencia", "candidatos.json")
    if not p.exists():
        return False, "falta ofertas/%s/referencia/candidatos.json" % of
    texto = p.read_text(encoding="utf-8")
    if RE_ID.search(texto):
        return False, "candidatos.json tiene IDs reales: van enmascarados (regla 8)"
    try:
        d = json.loads(texto)
    except ValueError:
        return False, "candidatos.json ilegible"
    cs = d.get("candidatos") or []
    if not 1 <= len(cs) <= 5:
        return False, "se esperan de 1 a 5 candidatos (hay %d); si ninguno pasa: «sin producto hoy», no se baja el umbral" % len(cs)
    if "anonima" not in str(d.get("fuente", "")):
        return False, "la fuente no es la Biblioteca pública anónima"
    for i, c in enumerate(cs, 1):
        per = c.get("perfil") or {}
        if per.get("tarjetas") is None or per.get("dias_mas_antiguo") is None:
            return False, "candidato %d sin conteo ni antigüedad medidos" % i
        u = c.get("umbrales") or {}
        if not u.get("checklist") or u.get("veredicto") in ("descartada", "no_cumple_reglas"):
            return False, "candidato %d sin checklist o fuera de las reglas" % i
        if not c.get("anuncios_ganadores"):
            return False, "candidato %d sin anuncios ganadores (evidencia)" % i
    try:
        gen = datetime.fromisoformat(str(d.get("generado_en")))
        if (rutas.ahora() - gen).total_seconds() > 3 * 86400:
            return False, "la caza tiene más de 3 días (cazador-de-ofertas/SKILL.md:45): repetir"
    except (TypeError, ValueError):
        return False, "candidatos.json sin fecha válida"
    return True, "%d candidatos con evidencia" % len(cs)


def adoptar(of, desde, look=None):
    """Usa una pasada suelta reciente (p. ej. ofertas/_candidatos/OF-006_candidatos.json) como la caza del producto.
    `look`: look.json ya modelado del candidato confirmado (D104), que se copia a referencia/look.json."""
    src = Path(desde) if Path(desde).is_absolute() else rutas.ruta(*Path(desde).parts)
    d = json.loads(src.read_text(encoding="utf-8"))
    d.update(of=of, adoptado_de=src.name)
    conf = [x for x in _decisiones_crudas(of) if x.get("tipo") == "confirmar_candidato"]
    if conf:   # el elegido lo dice la decisión escrita; el firmante lo valida la compuerta contra datos/dueno.local.json
        d["elegido"] = conf[-1].get("candidato")
        try:   # «elegido» cuenta desde 1 (OF-006: 3 = Office Facile); el nombre de la página no deja dudas
            d["elegido_pagina"] = d["candidatos"][int(d["elegido"]) - 1].get("pagina")
        except (TypeError, ValueError, IndexError):
            pass
        d["motivo_elegido"] = "confirmar_candidato de %s (%s, %s): «%s»" % (
            conf[-1].get("firmado_por"), conf[-1].get("fecha"), conf[-1].get("canal"), conf[-1].get("texto_literal"))
    rutas.escribir_json(rutas.ruta("ofertas", of, "referencia", "candidatos.json"), d)
    rutas.escribir_json(rutas.ruta("ofertas", of, "referencia", "paises.json"), {c["pagina"]: c.get("paises") for c in d["candidatos"]})
    for sufijo in ("candidatos.local.json", "ids.local.json"):
        local = src.parent / "entradas" / "cazar" / src.name.replace("candidatos.json", sufijo)
        if local.exists():
            rutas.escribir_json(rutas.ruta("ofertas", of, "entradas", "cazar", sufijo), json.loads(local.read_text(encoding="utf-8")))
    if look:
        lp = Path(look) if Path(look).is_absolute() else rutas.ruta(*Path(look).parts)
        rutas.escribir_json(rutas.ruta("ofertas", of, "referencia", "look.json"), json.loads(lp.read_text(encoding="utf-8")))
    return verificar_cazada(of)


def decisiones_dueno(of, raiz=None):
    """Líneas de estado/decisiones.jsonl de ese producto firmadas por un dueño de datos/dueno.local.json (regla 15)."""
    base = Path(raiz or rutas.RAIZ)
    try:
        duenos = json.loads((base / "datos" / "dueno.local.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    lista = duenos.get("duenos") or duenos.get("dueños") or []
    nombres = {d.get("nombre") for d in lista if isinstance(d, dict)} | {duenos.get("nombre")}
    nombres.discard(None)
    try:
        lineas = (base / "estado" / "decisiones.jsonl").read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in lineas:
        try:
            x = json.loads(ln)
        except ValueError:
            continue
        if isinstance(x, dict) and x.get("of") == of and x.get("firmado_por") in nombres:
            out.append(x)
    return out


def _decisiones_crudas(of, raiz=None):
    try:
        lineas = (Path(raiz or rutas.RAIZ) / "estado" / "decisiones.jsonl").read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in lineas:
        try:
            x = json.loads(ln)
        except ValueError:
            continue
        if isinstance(x, dict) and x.get("of") == of:
            out.append(x)
    return out


def potenciales(of, raiz=None):
    """Marcas «potencial» (tipo marcar_potencial) de estado/decisiones.jsonl: informativas; nunca confirman ni habilitan
    producir ni adoptar (pedido de Ramiro del 2026-10-22: «anotá el 1.º como potencial y hacé otra pasada»)."""
    try:
        lineas = (Path(raiz or rutas.RAIZ) / "estado" / "decisiones.jsonl").read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in lineas:
        try:
            x = json.loads(ln)
        except ValueError:
            continue
        if isinstance(x, dict) and x.get("of") == of and x.get("tipo") == "marcar_potencial":
            out.append(x)
    return out


def compuerta_candidato(producto, raiz=None):
    """«candidato» → producir: si el producto vino de la caza (pasó por por_cazar), el dueño confirma o veta el candidato
    (TAREA 037: «Ramiro veta o confirma»). Devuelve (estado, motivo): confirmado | esperando | vetado."""
    if not any(h.get("de") == "por_cazar" for h in producto.get("historial", [])):
        return "confirmado", "producto sin caza en el ciclo (alta directa)"
    ds = [d for d in decisiones_dueno(producto["of"], raiz) if d.get("tipo") in ("confirmar_candidato", "vetar_candidato")]
    pot = [d for d in potenciales(producto["of"], raiz)]
    if not ds:
        delegado = elegir_delegado(producto["of"], raiz)
        if delegado:
            return "confirmado", delegado
    if not ds and pot:
        return "esperando", ("candidato %s marcado como potencial (%s): no es una confirmación; falta "
                             "confirmar_candidato firmado" % (pot[-1].get("candidato"), pot[-1].get("decidido_por")))
    if not ds:
        return "esperando", ("esperando que el dueño confirme o vete el candidato (ofertas/%s/referencia/candidatos.json): "
                             "línea {\"tipo\": \"confirmar_candidato\", \"of\": \"%s\", \"candidato\": N, \"firmado_por\": ...} "
                             "en estado/decisiones.jsonl" % (producto["of"], producto["of"]))
    ultima = ds[-1]
    if ultima["tipo"] == "vetar_candidato" and ultima.get("candidato") in (None, "todos"):
        return "vetado", "el dueño vetó la caza entera: se vuelve a cazar"
    if ultima["tipo"] == "vetar_candidato":
        return "esperando", "el dueño vetó el candidato %s: falta confirmar otro o vetar la caza" % ultima.get("candidato")
    return "confirmado", "candidato %s confirmado por %s" % (ultima.get("candidato"), ultima.get("firmado_por"))


RE_NO_MODELABLE = re.compile(r"\b(test|quiz|suscripci[oó]n|subscription|abbonamento|app\b|membres[ií]a|plan personalizado)",
                             re.IGNORECASE)


def no_modelable(c):
    """La elección delegada no toma lo que no es un producto descargable modelable en Hotmart (B en seco, OF-008):
    embudos de test hacia un plan o app por suscripción, ni páginas de marca personal. → motivo o None."""
    rev = c.get("revision") or {}
    if rev.get("marca_personal") is True or rev.get("persona") or "nombre de persona" in str(c.get("pagina") or ""):
        return "marca personal"
    if rev.get("digital") is not True:
        return "no confirmado digital"
    texto = " ".join(str(x or "") for x in (rev.get("que_vende"), c.get("que_vende"), rev.get("nota")))
    m = RE_NO_MODELABLE.search(texto)
    return ("embudo de %s" % m.group(1).lower()) if m else None


def elegir_delegado(of, raiz=None):
    """TAREA 041: con la autorización escrita «elegir_candidato» vigente, el código elige el primer candidato «validada»
    de referencia/candidatos.json (ya ordenados por puntaje) sin esperar la confirmación del dueño, y lo deja escrito en
    «elegido». El dueño puede vetarlo después en estado/decisiones.jsonl. → motivo, o None si no corresponde."""
    import autorizaciones as AU
    base = Path(raiz or rutas.RAIZ)
    try:
        auts = json.loads((base / "datos" / "autorizaciones.local.json").read_text(encoding="utf-8")).get("autorizaciones", [])
    except (OSError, ValueError):
        return None
    hoy = rutas.hoy()
    aut = next((a for a in auts if a.get("alcance") == "elegir_candidato" and AU._valida(a, of, hoy)), None)
    p = base / "ofertas" / of / "referencia" / "candidatos.json"
    if aut is None or not p.exists():
        return None
    d = json.loads(p.read_text(encoding="utf-8"))
    if d.get("elegido"):
        return "candidato %s elegido antes (%s)" % (d["elegido"], d.get("motivo_elegido"))
    n = next((i for i, c in enumerate(d.get("candidatos") or [], 1)
              if (c.get("umbrales") or {}).get("veredicto") == "validada" and not no_modelable(c)), None)
    if n is None:
        return None
    d["elegido"] = n
    d["elegido_pagina"] = d["candidatos"][n - 1].get("pagina")   # «elegido» cuenta desde 1; el nombre no deja dudas
    d["motivo_elegido"] = ("elegido por el código: primer candidato «validada» (autorización %s «elegir_candidato» de %s, %s)"
                           % (aut.get("id"), aut.get("firmante"), aut.get("fecha")))
    rutas.escribir_json(p, d)
    return "candidato %d elegido por el código con la autorización %s" % (n, aut.get("id"))


def _ruta_dato(x):
    """Una ruta relativa de datos (--revision) se resuelve contra la raíz de la corrida (HYPERFLUJO_RAIZ), como --dir."""
    return Path(x) if Path(x).is_absolute() else rutas.ruta(*Path(x).parts)


def cmd_perfiles(trabajo, cfg, a):
    revision = json.loads(_ruta_dato(a.revision).read_text(encoding="utf-8")) if a.revision else None
    perfiles(trabajo, cfg, a.max, log=lambda s: print(s, flush=True), revision=revision)
    return 0


def cmd_competencia(trabajo, cfg, a):
    revision = json.loads(_ruta_dato(a.revision).read_text(encoding="utf-8")) if a.revision else {}
    cands = [c for c in armar_candidatos(trabajo, cfg, revision) if not c.get("excluido")
             and not descartado_por_revision(c.get("revision") or {})]
    cands.sort(key=lambda c: -((c["perfil"].get("tarjetas") or 0) + (c["perfil"].get("copias") or 0)))
    competencia(trabajo, cfg, cands[:a.top], log=lambda s: print(s, flush=True))
    return 0


def cmd_procesar(trabajo, cfg, a):
    revision = json.loads(_ruta_dato(a.revision).read_text(encoding="utf-8")) if a.revision else {}
    todos = armar_candidatos(trabajo, cfg, revision)
    habilitados = mercados_habilitados(cfg)
    for c in todos:
        c["mercado_destino"] = (elegir_mercado(c, habilitados) or [None])[0]
        c.update(umbrales=aplicar_umbrales(c, cfg), puntaje=puntaje(c, cfg))
    elegidos = elegir_cinco(todos, cfg)
    destino = salida_versionada(trabajo, documento(elegidos, todos, a.of or a.prefijo), prefijo=a.prefijo)
    print(json.dumps({"ok": bool(elegidos), "codigo": 0 if elegidos else 1, "candidatos": len(elegidos), "evaluados": len(todos),
                      "salida": os.path.relpath(destino, rutas.RAIZ).replace("\\", "/"),
                      "motivo": "ok" if elegidos else "ningún candidato cumple: «sin producto hoy» (no se baja el umbral)"},
                     ensure_ascii=False))
    return 0 if elegidos else 1


# ------------------------------------------------------------------ CLI
def main(argv=None):
    ap = argparse.ArgumentParser(description="Cazador de ofertas (Biblioteca pública, anónimo, sin límite de nicho ni región).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("plan")
    for c in ("barrer", "perfiles", "competencia", "procesar"):
        s = sub.add_parser(c)
        s.add_argument("--dir", required=True, help="carpeta de trabajo (ofertas/OF-NNN u ofertas/_candidatos)")
        s.add_argument("--max", type=int)
        s.add_argument("--minutos", type=float)
        s.add_argument("--top", type=int, default=8)
        s.add_argument("--revision")
        s.add_argument("--prefijo")
        s.add_argument("--of")
        s.add_argument("--mercados", help="lista separada por comas (solo barrer)")
        s.add_argument("--rubros", help="lista separada por comas (solo barrer)")
        s.add_argument("--esperar-freno", type=int, help="segundos de espera ante el freno de Meta, un solo reintento")
    v = sub.add_parser("verificar")
    v.add_argument("--of", required=True)
    ad = sub.add_parser("adoptar")
    ad.add_argument("--of", required=True)
    ad.add_argument("--desde", required=True)
    ad.add_argument("--look", help="look.json del candidato confirmado (D104), p. ej. ofertas/_candidatos/OF-006_look.json")
    a = ap.parse_args(argv)
    cfg = cargar_config()
    if a.cmd == "plan":
        for b in plan_busquedas(cfg):
            print("%-6s %-16s %-4s %s" % (b["mercado"], b["rubro"], b["pais"], b["termino"]))
        return 0
    if a.cmd in ("verificar", "adoptar"):
        ok, motivo = verificar_cazada(a.of) if a.cmd == "verificar" else adoptar(a.of, a.desde, getattr(a, "look", None))
        print(json.dumps({"ok": ok, "codigo": 0 if ok else 1, "motivo": motivo}, ensure_ascii=False))
        return 0 if ok else 1
    trabajo = rutas.ruta(*Path(a.dir).parts) if not Path(a.dir).is_absolute() else Path(a.dir)
    if a.cmd == "barrer":
        hechos = barrer(trabajo, cfg, a.max, minutos=a.minutos, log=lambda s: print(s, flush=True),
                        mercados=set(a.mercados.split(",")) if a.mercados else None,
                        rubros=set(a.rubros.split(",")) if a.rubros else None, esperar_freno=a.esperar_freno)
        bien = sum(1 for h in hechos if h.get("ok"))
        if hechos and not bien:   # B en seco: todas las lecturas fallaron → no es «0 resultados», es una falla (nulo ≠ 0)
            print(json.dumps({"ok": False, "codigo": 2, "lecturas": len(hechos), "lecturas_ok": 0,
                              "motivo": "ninguna lectura salió bien: falla del robot, no «sin producto»"}, ensure_ascii=False))
            return 2
        print(json.dumps({"ok": True, "codigo": 0, "lecturas": len(hechos), "lecturas_ok": bien}))
        return 0
    return globals()["cmd_" + a.cmd](trabajo, cfg, a)


if __name__ == "__main__":
    sys.exit(main())
