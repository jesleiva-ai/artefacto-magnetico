#!/usr/bin/env node
/**
 * cazar_biblioteca.mjs — lector anónimo de la Biblioteca de anuncios pública de Meta (TAREA 037 parte A, modo B del taller).
 *
 *   node herramientas/cazar_biblioteca.mjs --busqueda "pdf guide" --pais US [--exacta] [--scrolls 4] [--salida f.json]
 *   node herramientas/cazar_biblioteca.mjs --perfil <view_all_page_id> [--pais ALL] [--scrolls 6] [--salida f.json]
 *   node herramientas/cazar_biblioteca.mjs --archivo pagina.html [--modo busqueda|perfil]   (sin red: pruebas)
 *
 * Qué hace y qué no:
 *   - Abre Google Chrome con un contexto NUEVO y vacío (sin cookies ni perfil del dueño): el escaneo es siempre anónimo
 *     (Matías, `cazador-de-ofertas/SKILL.md:65`: «nunca uses una sesión personal»). Nunca inicia sesión, nunca hace clic
 *     en anuncios ni abre landings, nunca resuelve captchas: si Meta pide captcha o login, para con código 6 y lo que
 *     haya leído queda como parcial.
 *   - Lee los datos estructurados que la propia página trae (HTML inicial + respuestas de la página al bajar): id de
 *     biblioteca, página (id y nombre), activo, fecha de inicio, copias («N anuncios usan este contenido»), destino,
 *     CTA y texto. El total declarado («~N resultados») se guarda aparte: nunca se usa como conteo (cobertura).
 *   - Baja la página `--scrolls` veces con pausas de 2,5 s (ritmo de persona) y corta antes si no aparece nada nuevo.
 * Consumo: cero (página pública). Los IDs reales que devuelve van solo a `ofertas/<OF>/entradas/` (fuera de git).
 * Salida: JSON por stdout (o `--salida`); la última línea siempre es {ok, codigo, motivo, ...}.
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

export const VERSION = '2026.10.22b';
const BASE = 'https://www.facebook.com/ads/library/';

export function urlBusqueda(consulta, pais = 'ALL', exacta = false) {
  const q = new URLSearchParams({ active_status: 'active', ad_type: 'all', country: pais || 'ALL', q: consulta,
    search_type: exacta ? 'keyword_exact_phrase' : 'keyword_unordered', media_type: 'all' });
  return BASE + '?' + q.toString();
}

export function urlPerfil(paginaId, pais = 'ALL') {
  if (!/^\d{5,25}$/.test(String(paginaId))) throw new Error('view_all_page_id inválido');
  const q = new URLSearchParams({ active_status: 'active', ad_type: 'all', country: pais || 'ALL',
    view_all_page_id: String(paginaId), search_type: 'page', media_type: 'all' });
  return BASE + '?' + q.toString();
}

/** Objeto JSON balanceado que empieza en `inicio` (respeta cadenas y escapes). Devuelve el texto o null. */
function objetoBalanceado(texto, inicio) {
  let prof = 0; let enCadena = false; let escape = false;
  for (let i = inicio; i < texto.length; i++) {
    const c = texto[i];
    if (enCadena) {
      if (escape) escape = false; else if (c === '\\') escape = true; else if (c === '"') enCadena = false;
      continue;
    }
    if (c === '"') enCadena = true;
    else if (c === '{') prof++;
    else if (c === '}') { prof--; if (prof === 0) return texto.slice(inicio, i + 1); }
    if (i - inicio > 400000) return null;
  }
  return null;
}

function fecha(epoch) {
  const n = Number(epoch);
  if (!Number.isFinite(n) || n <= 0) return null;
  return new Date(n * 1000).toISOString().slice(0, 10);
}

function destinoReal(url) {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (/(^|\.)facebook\.com$/.test(u.hostname) && u.pathname === '/l.php' && u.searchParams.get('u')) return u.searchParams.get('u');
    return url;
  } catch { return url; }
}

/** Corta sin partir un emoji (pares sustitutos) y sin saltos de línea; quita sustitutos sueltos. */
export function cortar(texto, n) {
  if (!texto) return null;
  const limpio = Array.from(String(texto).replace(/\s+/g, ' '))
    .filter(ch => !(ch.length === 1 && ch.charCodeAt(0) >= 0xD800 && ch.charCodeAt(0) <= 0xDFFF));
  return limpio.slice(0, n).join('') || null;
}

function dominio(url) {
  try { return new URL(url).hostname.replace(/^www\./, '').toLowerCase(); } catch { return null; }
}

/** Normaliza un resultado colado de la Biblioteca a la forma que procesa herramientas/cazar.py. */
export function normalizar(o) {
  const s = o.snapshot || {};
  const carta = (s.cards || [])[0] || {};
  const destino = destinoReal(s.link_url || carta.link_url || null);
  const gated = o.gated_type || null;
  return {
    id: String(o.ad_archive_id),
    pagina_id: o.page_id ? String(o.page_id) : (s.page_id ? String(s.page_id) : null),
    pagina: cortar(s.page_name || o.page_name, 120),
    activo: o.is_active === true,
    inicio: fecha(o.start_date),
    fin: fecha(o.end_date),
    copias: Number.isInteger(o.collation_count) && o.collation_count > 0 ? o.collation_count : 1,
    formato: s.display_format || null,
    cta: s.cta_type || null,
    destino,
    dominio: destino ? dominio(destino) : (s.caption ? String(s.caption).toLowerCase() : null),
    titulo: cortar(s.title || carta.title, 160),
    texto: cortar((s.body && s.body.text) || carta.body, 400),
    seguidores: Number.isInteger(s.page_like_count) ? s.page_like_count : null,
    categorias_pagina: Array.isArray(s.page_categories) ? s.page_categories.slice(0, 5) : [],
    plataformas: Array.isArray(o.publisher_platform) ? o.publisher_platform : [],
    gated_type: gated,
    pocas_impresiones: gated ? /LOW|IMPRESSION/i.test(gated) && gated !== 'ELIGIBLE' : false,
  };
}

/** Extrae los anuncios de un texto (HTML de la página o respuesta de la página). Sin duplicados por id. */
export function extraerAnuncios(texto, vistos = new Map()) {
  const marca = /\{\s*"ad_archive_id"\s*:\s*"/g;
  let m;
  while ((m = marca.exec(texto)) !== null) {
    const crudo = objetoBalanceado(texto, m.index);
    if (crudo) {
      try {
        const o = JSON.parse(crudo);
        if (o && o.ad_archive_id && !vistos.has(String(o.ad_archive_id))) vistos.set(String(o.ad_archive_id), normalizar(o));
      } catch { /* fragmento que no es JSON puro: se ignora */ }
    }
  }
  return vistos;
}

export function declarados(texto) {
  const ms = [...texto.matchAll(/"search_results_connection"\s*:\s*\{\s*"count"\s*:\s*(\d+)/g)].map(m => Number(m[1]));
  return ms.length ? Math.max(...ms) : null;
}

export function pideCaptcha(texto) {
  return /"xfb_ad_library_is_captcha_required"\s*:\s*true/.test(texto);
}

export function resumen(anuncios, decl, extra = {}) {
  const lista = [...anuncios.values()];
  const validos = lista.filter(a => a.activo && !a.pocas_impresiones);
  const copias = validos.reduce((s, a) => s + a.copias, 0);
  const cobertura = decl ? Math.min(100, Math.round(100 * copias / decl)) : null;
  return { version: VERSION, fuente: 'biblioteca_publica_anonima', declarados: decl, tarjetas: lista.length,
    activos_validos: validos.length, copias_validas: copias, cobertura_porcentaje: cobertura, ...extra, anuncios: lista };
}

function args(argv) {
  const a = { scrolls: 4, pais: null, exacta: false, visible: false };
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    if (k === '--busqueda') a.busqueda = argv[++i];
    else if (k === '--perfil') a.perfil = argv[++i];
    else if (k === '--pais') a.pais = argv[++i];
    else if (k === '--exacta') a.exacta = true;
    else if (k === '--scrolls') a.scrolls = Math.max(0, Math.min(12, Number(argv[++i]) || 0));
    else if (k === '--salida') a.salida = argv[++i];
    else if (k === '--archivo') a.archivo = argv[++i];
    else if (k === '--modo') a.modo = argv[++i];
    else if (k === '--visible') a.visible = true;
  }
  return a;
}

async function leerEnVivo(url, scrolls, visible) {
  const { chromium } = await import('playwright');
  let navegador;
  const errores = [];
  for (const extra of [{ channel: 'chrome' }, { channel: 'msedge' }, {}]) {   // contexto nuevo: nunca el perfil del dueño
    try { navegador = await chromium.launch({ headless: !visible, ...extra }); break; } catch (e) { errores.push(String(e).slice(0, 120)); }
  }
  if (!navegador) return { error: 'no se pudo abrir un navegador local: ' + errores.join(' | ') };
  const textos = [];
  try {
    const ctx = await navegador.newContext({ locale: 'es-ES', viewport: { width: 1280, height: 1600 } });
    const pagina = await ctx.newPage();
    pagina.on('response', async r => {
      if (/\/api\/graphql\//.test(r.url())) { try { textos.push(await r.text()); } catch { /* respuesta cerrada */ } }
    });
    let navegaciones = 0;
    pagina.on('framenavigated', f => { if (f === pagina.mainFrame()) navegaciones++; });
    await pagina.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await pagina.waitForTimeout(5000);
    // Freno de Meta a la lectura anónima: la página se recarga sola en bucle. Se para y se informa; nunca se evade
    // (ni proxys, ni cambios de huella, ni la sesión del dueño). Se reintenta otro día o después de una pausa larga.
    const frenada = 'Meta frenó la lectura anónima (la página se recarga sola): se para y no se evade';
    if (navegaciones > 3) return { textos, bloqueo: frenada };
    try { textos.push(await pagina.content()); } catch (e) {
      if (/navigating/i.test(String(e))) return { textos, bloqueo: frenada };
      throw e;
    }
    const final = pagina.url();
    if (/\/login|checkpoint/.test(final)) return { textos, bloqueo: 'Meta pidió iniciar sesión (' + final.split('?')[0] + ')' };
    let sinNuevos = 0; let previo = extraerAnuncios(textos.join('\n')).size;
    for (let i = 0; i < scrolls && sinNuevos < 2; i++) {
      await pagina.mouse.wheel(0, 5000);
      await pagina.waitForTimeout(2500);
      const n = extraerAnuncios(textos.join('\n')).size;
      sinNuevos = n > previo ? 0 : sinNuevos + 1;
      previo = n;
      if (pideCaptcha(textos.join('\n'))) break;
    }
    return { textos };
  } finally {
    await navegador.close();
  }
}

export async function main(argv) {
  const a = args(argv);
  const modo = a.perfil ? 'perfil' : (a.busqueda ? 'busqueda' : (a.modo || 'busqueda'));
  let url = null; let textos = []; let bloqueo = null;
  try {
    if (a.archivo) {
      textos = [readFileSync(resolve(a.archivo), 'utf8')];
    } else if (a.perfil) {
      url = urlPerfil(a.perfil, a.pais || 'ALL');
    } else if (a.busqueda) {
      url = urlBusqueda(a.busqueda, a.pais || 'ALL', a.exacta);
    } else {
      throw new Error('falta --busqueda, --perfil o --archivo');
    }
    if (url) {
      const r = await leerEnVivo(url, a.scrolls, a.visible);
      if (r.error) { console.log(JSON.stringify({ ok: false, codigo: 2, motivo: r.error })); return 2; }
      textos = r.textos; bloqueo = r.bloqueo || null;
    }
  } catch (e) {
    console.log(JSON.stringify({ ok: false, codigo: 2, motivo: String(e.message || e) }));
    return 2;
  }
  const todo = textos.join('\n');
  const anuncios = extraerAnuncios(todo);
  const captcha = pideCaptcha(todo);
  const out = resumen(anuncios, declarados(todo), {
    modo, url, consulta: a.busqueda || null, pagina_id: a.perfil || null, pais: a.pais || 'ALL', exacta: a.exacta,
    leido_en: new Date().toISOString(),
    parcial_motivo: captcha ? 'captcha: no se resuelve (Meta lo pidió)' : bloqueo,
  });
  const codigo = (captcha || bloqueo) ? 6 : 0;
  if (a.salida) {
    mkdirSync(dirname(resolve(a.salida)), { recursive: true });
    writeFileSync(resolve(a.salida), JSON.stringify(out, null, 1), 'utf8');
  } else {
    console.log(JSON.stringify(out));
  }
  console.log(JSON.stringify({ ok: codigo === 0, codigo, motivo: out.parcial_motivo || 'leído', tarjetas: out.tarjetas,
    declarados: out.declarados, salida: a.salida || null }));
  return codigo;
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main(process.argv.slice(2)).then(c => process.exit(c), e => { console.log(JSON.stringify({ ok: false, codigo: 2, motivo: String(e) })); process.exit(2); });
}
