#!/usr/bin/env python3
"""Carga .env del repo sin dependencias y dice qué claves están definidas. Nunca imprime valores.

    python herramientas/claves.py            # tabla definida / no definida
Uso como módulo:  from claves import clave;  clave("HF_API_KEY_ID")  -> str o ErrorClave
"""
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOMBRES = ["KIE_API_KEY", "HF_API_KEY_ID", "HF_API_KEY_SECRET", "ELEVENLABS_API_KEY", "HEYGEN_API_KEY",
           "PEXELS_API_KEY", "PIXABAY_API_KEY", "HYPERFLUJO_TOKEN", "SELLORA_TOKEN",
           "ANTHROPIC_API_KEY",
           "CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID",   # solo si el hosting elegido es Cloudflare (Matías, 2026-10-26)
           # Meta Marketing API (TAREA 032, D60): token del usuario del sistema, cuenta act_..., página; Instagram opcional
           "META_ACCESS_TOKEN", "META_AD_ACCOUNT_ID", "META_PAGE_ID", "META_INSTAGRAM_ID",
           # Netlify (TAREA 032 act. 11, D72): token personal del dueño para publicar la landing
           "NETLIFY_AUTH_TOKEN",
           # TAREA 036: vigilancia sin modelo (Graph con usuario del sistema), lectura de Hotmart, repo de productos
           "META_SYSTEM_USER_TOKEN", "HOTMART_BASIC", "HOTMART_CLIENT_ID", "HOTMART_CLIENT_SECRET", "REPO_PRODUCTOS_URL", "REPO_PRODUCTOS_TOKEN"]


class ErrorClave(Exception):
    pass


def leer_env(ruta=None):
    ruta = ruta or os.path.join(RAIZ, ".env")
    valores = {}
    if not os.path.exists(ruta):
        return valores
    with open(ruta, encoding="utf-8-sig") as f:
        for linea in f:
            linea = linea.strip()
            if not linea or linea.startswith("#") or "=" not in linea:
                continue
            k, v = linea.split("=", 1)
            v = v.strip().strip('"').strip("'")
            if v:
                valores[k.strip()] = v
    return valores


def clave(nombre, ruta=None):
    """Valor de la variable de entorno o de .env. Lanza ErrorClave si falta (sin revelar nada)."""
    v = os.environ.get(nombre) or leer_env(ruta).get(nombre)
    if not v:
        raise ErrorClave("Falta %s en .env del repo (ver .env.ejemplo)." % nombre)
    return v


def estado(ruta=None):
    env = leer_env(ruta)
    return {n: bool(os.environ.get(n) or env.get(n)) for n in NOMBRES}


if __name__ == "__main__":
    existe = os.path.exists(os.path.join(RAIZ, ".env"))
    print(".env: %s" % ("presente" if existe else "no existe (copiar .env.ejemplo)"))
    for n, ok in estado().items():
        print("  %-20s %s" % (n, "definida" if ok else "no definida"))
    sys.exit(0)
