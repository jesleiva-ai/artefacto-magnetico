#!/usr/bin/env python3
"""compuerta_sitio.py — el sitio PUBLICADO se lee entero y falla cerrado antes de activar y después de cada deploy
(TAREA 041 E3, condición para OF-008; F63/F65: «es terrible lo que sucedió», Ramiro).

    python herramientas/compuerta_sitio.py OF-NNN [--url https://…] [--retiro] [--sin-campana]

Lee la página publicada y todas las internas que enlaza, más las legales conocidas (impressum, datenschutz,
aviso-legal, privacidad, condiciones, cookies), y rechaza:
  * relleno en cualquier HTML: marcadores, datos de ejemplo, «Calle 1», correos de relleno (legales.problemas);
  * testimonios o reseñas (D119, F66): TESTIMONIOS:INICIO, #opiniones, img/testimonios, ★, «panel de probadores»;
  * legales vacíos: no hay página legal, o no trae el nombre del dueño ni un correo real (datos/dueno.local.json);
  * píxel ≠ el de la cuenta (pixel.problemas);
  * checkout ≠ registrado en externo.local.json, o que no responde 200 desde esta máquina; con --retiro no tiene que
    haber checkout;
  * sin confirmación escrita del checkout abierto DESDE EL PAÍS del mercado (VPN; precio y moneda vistos), firmada
    por el dueño con `firmar.py checkout` en los últimos 90 días: no hay conector ni proxy gratuito confiable para
    sondearlo desde otro país (E3 c), así que es un paso humano, una vez por mercado;
  * CTA ≠ LEARN_MORE (D100): la relectura de la campaña (meta_campana.ruta_verificacion) tiene que estar en verde.
Sin excepción por chat: no hay bandera para saltearla. Cada rechazo queda en estado/bloqueos.jsonl. Solo GET públicos.
Última línea: JSON {"ok","codigo","motivo","artefactos"}.
"""
import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import guardia_landing  # noqa: E402
import legales  # noqa: E402
import pixel as PX  # noqa: E402
import rutas  # noqa: E402

LEGALES = ("impressum", "datenschutz", "aviso-legal", "privacidad", "condiciones", "cookies")
MAX_PAGINAS = 40
RE_HREF = re.compile(r"""href\s*=\s*["']([^"'#]+)["']""", re.IGNORECASE)
RE_CHECKOUT = re.compile(r"""https://pay\.hotmart\.com/[A-Za-z0-9]+(?:\?[^"'\s<>]*)?""")
RE_CORREO = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]{2,}")


def leer_http(url):   # lectura-gratuita: GET público
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (hyperflujo compuerta_sitio)"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return None, ""


def checkouts_registrados(of):
    ext = rutas.externo(of)
    out = set()
    if ext.get("checkout_url"):
        out.add(ext["checkout_url"])
    for pieza in (ext.get("hotmart") or {}).values():
        if isinstance(pieza, dict) and pieza.get("checkout_url"):
            out.add(pieza["checkout_url"])
    return out


def _clave_checkout(url):
    """pay.hotmart.com/CODIGO?off=OFERTA → (CODIGO, OFERTA): lo demás de la query (sck, src…) no cuenta."""
    p = urllib.parse.urlparse(url)
    return p.path.strip("/"), (urllib.parse.parse_qs(p.query).get("off") or [None])[0]


def _internas(base, html):
    host = urllib.parse.urlparse(base).netloc
    out = []
    for h in RE_HREF.findall(html or ""):
        u = urllib.parse.urljoin(base + "/", h.strip())
        pu = urllib.parse.urlparse(u)
        if pu.netloc == host and pu.scheme in ("http", "https") and not re.search(r"\.(png|jpe?g|webp|gif|svg|css|js|pdf|mp4|ico|woff2?)$", pu.path, re.I):
            out.append(urllib.parse.urlunparse(pu._replace(query="", fragment="")).rstrip("/"))
    return out


def _nombres_dueno():
    try:
        d = rutas.cargar_dato("dueno")
    except rutas.FaltaDato:
        return set()
    n = set()
    for clave in [k for k in d if k.startswith("legal_")]:
        b = d.get(clave) or {}
        for campo in ("nombre", "titular"):
            if b.get(campo):
                n.add(str(b[campo]).strip())
    return n


def pendientes_medios(of):
    """Fuente única de los pendientes de medios (mockups, imágenes, video) que un worker no pudo producir:
    ofertas/OF-NNN/landing/pendientes_medios.json = {"pendientes": [{"medio", "donde", "detalle", "bloqueado_por",
    "resuelto": false}]}. → lista de textos de lo que sigue sin resolver. Sin archivo = sin pendientes. Si el archivo
    existe y no se puede leer o no tiene la forma esperada, falla cerrado (devuelve un problema)."""
    p = rutas.dir_oferta(of) / "landing" / "pendientes_medios.json"
    if not os.path.exists(p):
        return []
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        items = d["pendientes"]
        if not isinstance(items, list):
            raise ValueError("pendientes no es una lista")
        return ["%s en %s: %s" % (x.get("medio", "medio"), x.get("donde", "?"), x.get("detalle", ""))
                for x in items if isinstance(x, dict) and not x.get("resuelto")] +                ["entrada ilegible: %r" % (x,) for x in items if not isinstance(x, dict)]
    except (OSError, ValueError, KeyError, TypeError) as e:
        return ["no se pudo leer %s (%s)" % (p, e)]


def mensaje_pendientes_medios(pend):
    return ("la landing tiene pendientes de medios sin resolver (%s). Generalos con Higgsfield (mockups hiperrealistas con "
            "las portadas reales como referencia, imágenes, video), marcá «resuelto»: true en landing/pendientes_medios.json "
            "y recién ahí se publica" % "; ".join(pend[:6]))


def revisar(of, url=None, leer=leer_http, retiro=False, exigir_campana=True):
    """→ {"ok", "problemas": [...], "paginas": [...], "nota"}. No escribe nada (bloquear() registra)."""
    problemas = []
    if not retiro:
        pend = pendientes_medios(of)
        if pend:
            problemas.append(mensaje_pendientes_medios(pend))
    if url is None:
        import director
        url = director.urls_de(of)[0]
    if not url:
        return {"ok": False, "problemas": ["%s no tiene URL publicada registrada" % of], "paginas": [], "nota": ""}
    base = url.rstrip("/")
    try:
        ficha = rutas.leer_json(rutas.ruta_ficha(of), defecto={}) or {}
        propio = PX.del_producto(of, (ficha.get("mercado") or {}).get("id"), (ficha.get("campana") or {}).get("cuenta_ref"))
    except PX.SinPixel as e:
        propio, problemas = None, problemas + ["píxel de la cuenta: %s" % e]
    pendientes, vistas, paginas = [base] + ["%s/%s" % (base, n) for n in LEGALES], set(), {}
    while pendientes and len(vistas) < MAX_PAGINAS:
        u = pendientes.pop(0)
        if u in vistas:
            continue
        vistas.add(u)
        st, html = leer(u)
        if st != 200:
            if u == base:
                problemas.append("la página publicada %s responde %s" % (u, st))
            continue
        paginas[u] = html
        pendientes += [x for x in _internas(base, html) if x not in vistas]
    for u, html in paginas.items():
        rel = u[len(base):] or "/"
        problemas += ["%s: %s" % (rel, p) for p in legales.problemas(html)]
        problemas += ["%s: testimonios fuera del sistema (D119/F66): %s" % (rel, p) for p in guardia_landing.rastros(html)]
        if propio:
            problemas += ["%s: %s" % (rel, p) for p in PX.problemas(html, propio)]
    legales_vistas = {u: h for u, h in paginas.items() if any(u.endswith("/" + n) or u.endswith("/" + n + ".html") for n in LEGALES)}
    if not legales_vistas:
        problemas.append("no hay ninguna página legal publicada (%s)" % ", ".join(LEGALES))
    nombres = _nombres_dueno()
    for u, h in legales_vistas.items():
        if any(u.endswith(x) for x in ("/impressum", "/aviso-legal", "/impressum.html", "/aviso-legal.html", "/datenschutz", "/privacidad")):
            texto = re.sub(r"<[^>]+>", " ", h)
            if not any(n and n in texto for n in nombres):
                problemas.append("%s: no trae el nombre del dueño (datos/dueno.local.json)" % u[len(base):])
            if not [c for c in RE_CORREO.findall(texto) if not legales.problemas(c)]:
                problemas.append("%s: sin un correo real" % u[len(base):])
    enlazados = {c for h in paginas.values() for c in RE_CHECKOUT.findall(h)}
    if retiro:
        if enlazados:
            problemas.append("retiro con checkout enlazado: %s" % ", ".join(sorted(enlazados))[:200])
    else:
        registrados = {_clave_checkout(c) for c in checkouts_registrados(of)}
        if not registrados:
            problemas.append("no hay checkout registrado en externo.local.json para %s" % of)
        if not enlazados:
            problemas.append("la página publicada no enlaza ningún checkout de Hotmart")
        for c in sorted(enlazados):
            if _clave_checkout(c) not in registrados:
                problemas.append("checkout enlazado no registrado: %s" % c[:120])
            else:
                st, _ = leer(c)
                if st != 200:
                    problemas.append("checkout %s responde %s" % (c[:80], st))
    if not retiro:   # E3 (c): sin conector ni proxy confiable, el checkout desde el país lo confirma la persona por escrito
        mercado = ((rutas.leer_json(rutas.ruta_ficha(of), defecto={}) or {}).get("mercado") or {})
        mercado = mercado.get("id") if isinstance(mercado, dict) else mercado
        conf = confirmacion_checkout(mercado)
        if conf is None:
            problemas.append("falta la confirmación escrita del checkout abierto desde el país del mercado %s (VPN), "
                             "con fecha de los últimos %d días: python herramientas/firmar.py checkout" % (mercado, VIGENCIA_CHECKOUT))
    if exigir_campana and not retiro:
        try:
            import meta_campana
            v = rutas.leer_json(meta_campana.ruta_verificacion(of), defecto=None)
        except Exception:
            v = None
        if not v:
            problemas.append("sin relectura de la campaña (CTA LEARN_MORE, D100): meta_campana no verificó")
        elif not v.get("ok"):
            problemas.append("la relectura de la campaña no está en verde: %s" % "; ".join(v.get("errores") or [])[:200])
    return {"ok": not problemas, "problemas": problemas, "paginas": sorted(u[len(base):] or "/" for u in paginas),
            "nota": "checkout leído desde esta máquina; [PENDIENTE: sonda desde el país del mercado]"}


VIGENCIA_CHECKOUT = 90


def confirmacion_checkout(mercado, hoy=None):
    """Última confirmación firmada (datos/confirmaciones.local.json → checkout_pais) de ese mercado, de los últimos
    VIGENCIA_CHECKOUT días, con «se ve bien» y firmante de datos/dueno.local.json. None si no hay."""
    import datetime
    if not mercado:
        return None
    c = rutas.leer_json(rutas.ruta("datos", "confirmaciones.local.json"), defecto={}) or {}
    try:
        duenos = {x.get("nombre") for x in (rutas.cargar_dato("dueno").get("duenos") or [])}
    except rutas.FaltaDato:
        return None
    hoy = datetime.date.fromisoformat(hoy or rutas.hoy())
    validas = []
    for x in c.get("checkout_pais") or []:
        try:
            f = datetime.date.fromisoformat(str(x.get("fecha")))
        except ValueError:
            continue
        if x.get("mercado") == mercado and x.get("se_ve_bien") is True and x.get("firmante") in duenos \
                and 0 <= (hoy - f).days <= VIGENCIA_CHECKOUT:
            validas.append(x)
    return validas[-1] if validas else None


def bloquear(of, r, origen):
    """Cada rechazo queda en estado/bloqueos.jsonl (lo lee el informe)."""
    p = rutas.ruta("estado", "bloqueos.jsonl")
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps({"hora": rutas.ahora().isoformat(timespec="seconds"), "of": of, "herramienta": "compuerta_sitio",
                            "origen": origen, "motivo": r["problemas"][:20]}, ensure_ascii=False) + "\n")


def exigir(of, origen, **k):
    """revisar() + bloquear() si falla. → resultado. Para el director (activar) y netlify_deploy (relectura)."""
    r = revisar(of, **k)
    if not r["ok"]:
        bloquear(of, r, origen)
    return r


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Lee el sitio publicado entero y falla cerrado (E3).")
    ap.add_argument("of")
    ap.add_argument("--url")
    ap.add_argument("--retiro", action="store_true")
    ap.add_argument("--sin-campana", action="store_true", help="antes de crear la campaña: no exige su relectura")
    a = ap.parse_args()
    r = exigir(rutas.validar_of(a.of), "cli", url=a.url, retiro=a.retiro, exigir_campana=not a.sin_campana)
    for p in r["problemas"]:
        print("RECHAZO: " + p)
    print(json.dumps({"ok": r["ok"], "codigo": 0 if r["ok"] else 2, "motivo": "sitio publicado limpio" if r["ok"] else
                      "%d problemas (estado/bloqueos.jsonl)" % len(r["problemas"]), "artefactos": []}, ensure_ascii=False))
    sys.exit(0 if r["ok"] else 2)
