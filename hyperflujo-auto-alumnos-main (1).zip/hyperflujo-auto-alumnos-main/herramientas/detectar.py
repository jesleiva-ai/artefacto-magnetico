#!/usr/bin/env python3
"""detectar.py — qué hay y qué falta para que hyperflujo-auto ande solo (TAREA 041 Parte 1 A2).

    python herramientas/detectar.py                     # cuadro disponible / falta y el próximo paso manual
    python herramientas/detectar.py --siguiente         # solo el próximo faltante obligatorio, con su paso
    python herramientas/detectar.py --sin-red           # sin lecturas a Netlify, Meta, Hotmart ni ElevenLabs
    python herramientas/detectar.py --completar         # además escribe lo descubrible (equipo de Netlify, zona de Meta)
    python herramientas/detectar.py --anotar conector.meta-ads=disponible     # lo que solo ve la sesión de Claude
    python herramientas/detectar.py --respuesta paginas="una por mercado"      # lo no detectable: se pregunta una vez
    python herramientas/detectar.py --fijar meta.cuenta=act_… --fijar meta.pixel=…   # lo descubierto con el conector

No pregunta nada: detecta. Cada ítem tiene estado (disponible | falta | no_verificado | en_sesion), si es obligatorio y
el paso manual con el lugar exacto donde tocar. «en_sesion» = solo lo puede ver la sesión de Claude (conectores, saldo de
Higgsfield): el director lo prueba con ToolSearch y una lectura gratis y lo anota con --anotar (vale por el día).
Las lecturas en red son gratuitas (GET o token): Netlify /user y ancho de banda, Graph act_…?fields=spend_cap, token de
Hotmart, suscripción de ElevenLabs, y la sesión del robot (`hotmart_sesion.mjs --verificar`). Nunca imprime valores de
claves ni IDs. Escribe estado/onboarding.json; lo no detectable va a datos/respuestas.local.json (fuera de git).
Solo biblioteca estándar. Última línea de stdout: JSON {"ok","codigo","motivo","artefactos"}.
"""
import argparse
import json
import os
import re
from datetime import datetime
import subprocess
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

DISP, FALTA, NOVER, SESION = "disponible", "falta", "no_verificado", "en_sesion"

# Alcances que un producto nuevo necesita para salir de punta a punta sin volver a preguntar (TAREA 041 Parte 0.1).
ALCANCES_LANZAR = ("elegir_candidato", "publicar", "finalizar_registro", "activar_embudo", "activar_campana",
                   "gasto_meta", "gasto_medios", "gasto_anthropic")
CON_TECHO = ("gasto_meta", "gasto_medios", "gasto_anthropic")

# Lo que solo ve la sesión de Claude: (id, qué, obligatorio, cómo lo prueba el director, paso para la persona)
EN_SESION = (
    ("conector.meta-ads", "Conector de Meta (meta-ads)", True,
     "ToolSearch «meta-ads» y mcp__meta-ads__ads_get_ad_accounts",
     "En la app de Claude: Configuración → Conectores. El repo ya lo declara en .mcp.json (https://mcp.facebook.com/ads); "
     "la primera llamada abre el login de Meta: entrá, elegí la cuenta publicitaria y la página, y aceptá. Si no aparece, "
     "«Agregar conector personalizado» con esa URL. Después reiniciá la sesión de Claude en esta carpeta."),
    ("conector.hotmart", "Conector de Hotmart (lecturas de ventas y productos)", False,
     "ToolSearch «hotmart» y hotmart_products_list (sirve mcp__Hotmart__ o mcp__hotmart__)",
     "Opcional si la credencial HOTMART_BASIC del .env lee la API (el vigía la usa). Para tenerlo en la sesión: "
     "developers.hotmart.com → descargar la extensión hotmart.mcpb → doble clic (se instala en la app de Claude) → en su "
     "configuración pegá la credencial Basic. Nunca en el chat."),
    ("conector.higgsfield", "Conector de Higgsfield (imágenes y videos de los anuncios)", True,
     "ToolSearch «higgsfield» y mcp__higgsfield__balance",
     "En la app de Claude: Configuración → Conectores; el repo lo declara en .mcp.json (https://mcp.higgsfield.ai/mcp). "
     "La primera llamada abre el login de Higgsfield: entrá con tu cuenta y aceptá."),
    ("saldo.higgsfield", "Saldo de Higgsfield (créditos)", True,
     "mcp__higgsfield__balance y anotar los créditos: --anotar saldo.higgsfield=<créditos>",
     "Cargá créditos en higgsfield.ai → Pricing / Credits. Un producto usa del orden del tope "
     "por_producto_defecto.higgsfield de datos/topes.local.json."),
)

# Lo que no se detecta: se pregunta una sola vez y se guarda en datos/respuestas.local.json.
PREGUNTAS = (
    ("paginas", True, "¿Una página de Facebook genérica por mercado (es, de, en…), creada una vez y reutilizada, o una "
     "por producto creada a mano? (Meta no crea páginas por API)", ("una por mercado", "una por producto")),
    ("instagram", False, "¿Vinculás una cuenta de Instagram a la página? Es opcional: los anuncios ya corren en Instagram "
     "con la identidad de la página.", ("si", "no", "despues")),
    ("no_operar", True, "¿Hay productos con campaña viva que opera otra persona y /operar no debe tocar? «ninguno» o la "
     "lista (OF-006,OF-007)", ("ninguno", "OF-NNN,OF-NNN…")),
)
RE_LISTA_OF = r"^OF-\d{3,}(,OF-\d{3,})*$"


def _item(id_, que, estado, obligatorio, paso="", nota="", abrir=None, quien="persona"):
    """quien: «persona» (paso manual) o «director» (lo resuelve la sesión de Claude sin preguntar)."""
    d = {"id": id_, "que": que, "estado": estado, "obligatorio": obligatorio, "nota": nota, "paso": paso, "quien": quien}
    if abrir:
        d["abrir"] = abrir
    return d


def _vacio(v):
    return v is None or (isinstance(v, str) and (not v.strip() or v.startswith(("[", "<")) or v == "AAAA-MM-DD"))


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0


def _get(d, ruta):
    for k in ruta.split("."):
        if isinstance(d, list):
            d = d[int(k)] if k.isdigit() and int(k) < len(d) else None
        elif isinstance(d, dict):
            d = d.get(k)
        else:
            return None
    return d


def _dato(nombre):
    return rutas.leer_json(rutas.ruta("datos", "%s.local.json" % nombre), defecto=None)


# ------------------------------------------------------------------ 1. entorno (verificar_entorno.py)
PASOS_ENTORNO = {
    "python": "Instalá Python 3.10 o más nuevo (python.org/downloads; en Windows tildá «Add python.exe to PATH»).",
    "node": "Instalá Node 20 o más nuevo (nodejs.org, versión LTS).",
    "npm": "npm viene con Node: reinstalá Node LTS.",
    "playwright": "En una terminal, en la carpeta del repo: npm ci",
    "package-lock": "Falta package-lock.json: volvé a clonar el repo.",
    "git": "Instalá Git (git-scm.com).",
    "Chrome": "Instalá Google Chrome (google.com/chrome); si está en otra carpeta, poné su ruta en .env → CHROME_PATH=.",
    "CLI de Claude": "Opcional en esta etapa (solo para el lanzador headless): instalá Claude Code o poné su ruta en .env "
                     "→ HYPERFLUJO_CLAUDE_EXE=.",
    "hook": "Volvé a clonar el repo: falta el guardián de gasto (.claude/settings.json o herramientas/hooks/guardian_gasto.py).",
    "deny": "Volvé a clonar el repo: .claude/settings.json perdió las reglas deny.",
    "guardián": "El guardián de gasto no niega un gasto sin ticket: revisá que «python» corra en la terminal.",
}
DE_ESTE_DETECTOR = (".env", "clave ", "datos/", "workers.", "vía B")   # los mira este detector con su propio paso


def entorno(raiz, ejecutar):
    import verificar_entorno
    out = []
    for nombre, ok, oblig, nota in verificar_entorno.revisar(raiz=raiz, ejecutar=ejecutar, orquestacion=False):
        if nombre.startswith(DE_ESTE_DETECTOR):
            continue
        paso = next((p for k, p in PASOS_ENTORNO.items() if nombre.lower().startswith(k.lower())), "") or \
            next((p for k, p in PASOS_ENTORNO.items() if k in nombre), "")   # «playwright … (npm ci)» no es «npm»
        out.append(_item("entorno." + nombre.split()[0].lower(), nombre, DISP if ok else FALTA,
                         oblig and not nombre.startswith("CLI de Claude"), paso, nota))
    return out


# ------------------------------------------------------------------ 2. claves (.env, solo por nombre)
CLAVES = (
    ("NETLIFY_AUTH_TOKEN", True, "publicar la landing y el portal",
     "app.netlify.com → tu avatar (arriba a la derecha) → User settings → Applications → Personal access tokens → "
     "New access token. Pegalo en .env, línea NETLIFY_AUTH_TOKEN=", "https://app.netlify.com/user/applications"),
    ("HOTMART_BASIC", True, "leer ventas netas y aprobación (vigía)",
     "developers.hotmart.com → Credenciales (o en Hotmart: Herramientas → Credenciales de desarrollador) → Crear "
     "credencial → copiá el valor «Basic». Pegalo en .env, línea HOTMART_BASIC= (alternativa: HOTMART_CLIENT_ID y "
     "HOTMART_CLIENT_SECRET)", "https://developers.hotmart.com/"),
    ("META_SYSTEM_USER_TOKEN", True, "leer gasto y pausar sin modelo (vigía) y leer el límite de la cuenta",
     "business.facebook.com → Configuración del negocio → Usuarios → Usuarios del sistema → Agregar (rol Empleado, "
     "nunca Administrador) → Asignar activos: la cuenta publicitaria con «Administrar campañas» → Generar token "
     "(permisos ads_management y ads_read). Pegalo en .env, línea META_SYSTEM_USER_TOKEN=",
     "https://business.facebook.com/settings/system-users"),
    ("ELEVENLABS_API_KEY", False, "voz de los reels",
     "elevenlabs.io → tu perfil → API Keys → Create. Pegalo en .env, línea ELEVENLABS_API_KEY=",
     "https://elevenlabs.io/app/settings/api-keys"),
    ("ANTHROPIC_API_KEY", False, "solo si los workers headless facturan por API",
     "console.anthropic.com → API Keys. Pegalo en .env, línea ANTHROPIC_API_KEY= (vacío = usa el plan de Claude)", None),
)


def _claves_estado(raiz):
    import claves
    est = claves.estado(os.path.join(str(raiz), ".env"))
    env = claves.leer_env(os.path.join(str(raiz), ".env"))
    return {n: bool(est.get(n) or env.get(n) or os.environ.get(n)) for n in set(est) | set(env) | {c[0] for c in CLAVES}}


def claves_items(raiz):
    out = []
    hay_env = (raiz / ".env").exists()
    out.append(_item("env", "archivo .env", DISP if hay_env else FALTA, True,
                     "Copiá .env.ejemplo a .env en la carpeta del repo y abrilo con un editor de texto (Bloc de notas sirve). "
                     "Las claves se pegan ahí, nunca en el chat."))
    est = _claves_estado(raiz) if hay_env else {}
    for nombre, oblig, para, paso, url in CLAVES:
        ok = est.get(nombre, False)
        if nombre == "HOTMART_BASIC":
            ok = ok or (est.get("HOTMART_CLIENT_ID") and est.get("HOTMART_CLIENT_SECRET"))
        out.append(_item("clave." + nombre, "clave %s (%s)" % (nombre, para), DISP if ok else FALTA, oblig, paso, abrir=url))
    return out, est


# ------------------------------------------------------------------ 3. datos del dueño (sin valores)
def dueno_items():
    d = _dato("dueno")
    if d is None:
        return [_item("datos.dueno", "datos/dueno.local.json (quién autoriza)", FALTA, True,
                      "Decile al director tu nombre exacto (el que firma) y la identificación del vendedor para el aviso "
                      "legal (razón social o nombre, país, contacto): `python herramientas/firmar.py dueno` lo escribe.")]
    nombres = [x.get("nombre") for x in d.get("duenos") or [] if not _vacio(x.get("nombre"))]
    falt = ([] if nombres else ["duenos[].nombre"]) + (["identificacion_vendedor"] if _vacio(d.get("identificacion_vendedor")) else [])
    return [_item("datos.dueno", "datos/dueno.local.json (quién autoriza)", FALTA if falt else DISP, True,
                  "Completar en datos/dueno.local.json: " + ", ".join(falt) if falt else "", "falta: " + ", ".join(falt) if falt else "")]


def config_items():
    c = _dato("config")
    if c is None:
        return [_item("datos.config", "datos/config.local.json", FALTA, True,
                      "Copiá datos/config.ejemplo.json a datos/config.local.json (python herramientas/onboarding.py --crear-locales).")]
    falt = []
    if not _num(_get(c, "workers.max_budget_usd_por_worker")):
        falt.append("workers.max_budget_usd_por_worker")
    if _vacio(c.get("zona")):
        falt.append("zona")
    return [_item("datos.config", "datos/config.local.json (zona, tope por worker)", FALTA if falt else DISP, True,
                  "En datos/config.local.json completá: " + ", ".join(falt) if falt else "")]


def cuentas_items(respuestas):
    c = _dato("cuentas")
    if c is None:
        return [_item("datos.cuentas", "datos/cuentas.local.json (cuenta, píxel, página)", FALTA, True,
                      "El director la crea con --completar y la llena con --fijar descubriendo cuenta, píxel y página "
                      "con el conector meta-ads (lecturas); la persona solo elige si hay más de una.", quien="director")], None
    cuenta = (_get(c, "meta.cuentas") or [None])[0] or {}
    out = []
    falt = [k for k in ("id", "pixel") if _vacio(cuenta.get(k))]
    out.append(_item("cuentas.meta", "cuenta publicitaria y píxel en datos/cuentas.local.json", FALTA if falt else DISP, True,
                     "El director los descubre con mcp__meta-ads__ads_get_ad_accounts (cuenta en USD, con medio de pago e "
                     "is_ads_mcp_enabled) y ads_get_datasets, y los escribe con --fijar meta.cuenta=… --fijar meta.pixel=…; "
                     "si hay más de uno, elige la persona." if falt else "", "falta: " + ", ".join(falt) if falt else "",
                     quien="director"))
    paginas = [p for p in (cuenta.get("paginas") or []) + [_get(c, "meta.pagina_defecto")] if not _vacio(p)]
    por_mercado = _get(c, "meta.paginas_por_mercado") or {}
    ok_pag = bool(paginas) or any(not _vacio(v) for v in por_mercado.values())
    out.append(_item("cuentas.pagina", "página de Facebook para los anuncios", DISP if ok_pag else FALTA, True,
                     "Meta no crea páginas por API: facebook.com/pages/create → nombre de la página (genérica del mercado, "
                     "p. ej. «Guías prácticas») → Crear. Después el director la lee con ads_get_ad_account_pages y la anota.",
                     abrir="https://www.facebook.com/pages/create"))
    soporte = _get(c, "hotmart.correo_soporte")
    out.append(_item("cuentas.soporte", "correo de soporte para Hotmart y la landing", FALTA if _vacio(soporte) else DISP, True,
                     "Decile al director el correo de soporte que ven los compradores; queda en datos/cuentas.local.json."))
    return out, cuenta


def topes_items(nombres_duenos):
    t = _dato("topes")
    if t is None:
        return [_item("datos.topes", "datos/topes.local.json (topes de gasto)", FALTA, True,
                      "Se firman con `python herramientas/firmar.py` en tu terminal (te pregunta cada número).")], None
    falt = [k for k in ("tope_diario_global_usd", "tope_mensual_global_usd", "max_productos_activos", "max_nuevos_por_dia")
            if not _num(t.get(k))]
    for k in ("por_producto_defecto.meta.diario", "por_producto_defecto.meta.dias", "por_producto_defecto.higgsfield.tope",
              "por_producto_defecto.elevenlabs.tope", "por_producto_defecto.anthropic.tope",
              "por_proveedor_dia.higgsfield.tope", "por_proveedor_dia.elevenlabs.tope", "por_proveedor_dia.anthropic.tope"):
        if not _num(_get(t, k)):
            falt.append(k)
    if _get(t, "firmado.quien") not in nombres_duenos:
        falt.append("firmado.quien (igual exacto a un nombre de datos/dueno.local.json)")
    return [_item("datos.topes", "topes de gasto firmados (diario, mensual, por proveedor, por producto)",
                  FALTA if falt else DISP, True,
                  "En tu terminal, en la carpeta del repo: python herramientas/firmar.py topes --recomendado (pone el mínimo "
                  "recomendado en lo que falta; solo pide tu nombre y «firmo»; sin --recomendado pregunta cada número)." if falt else "",
                  "faltan: " + ", ".join(falt) if falt else "")], t


def checkout_pais_items():
    """E3 (c): el checkout de Hotmart abierto DESDE EL PAÍS del mercado (VPN), firmado con firmar.py checkout, una vez
    por mercado y cada 90 días. Obligatorio para el mercado por defecto; los demás se informan (los pide la compuerta
    al activar un producto de ese mercado)."""
    import compuerta_sitio as CS
    conf = _dato("config") or {}
    lanz = rutas.leer_json(rutas.ruta("datos", "mercados.json"), defecto={}) or {}
    habilitados = {k for k, v in lanz.items() if not k.startswith("_") and isinstance(v, dict) and v.get("habilitado") is True}
    defecto = conf.get("mercado_defecto") or "es-LATAM"
    mercados = {defecto} | habilitados
    for d in sorted(rutas.ruta("ofertas").glob("OF-*")):
        m = (rutas.leer_json(d / "oferta.json", defecto={}) or {}).get("mercado")
        m = m.get("id") if isinstance(m, dict) else m
        if m:
            mercados.add(m)
    out = []
    for m in sorted(mercados):
        ok = CS.confirmacion_checkout(m) is not None
        out.append(_item("checkout_pais." + m, "checkout de Hotmart confirmado desde el país del mercado %s" % m,
                         DISP if ok else FALTA, m == defecto or m in habilitados,
                         "" if ok else "Con una VPN de un país del mercado %s, abrí el checkout de Hotmart de un producto de ese mercado "
                                       "(pay.hotmart.com/…), mirá precio, moneda y medios de pago, y en tu terminal corré: "
                                       "python herramientas/firmar.py checkout (vale 90 días)." % m))
    return out


def autorizaciones_items(nombres_duenos, hoy):
    import autorizaciones as AU
    d = _dato("autorizaciones")
    lista = (d or {}).get("autorizaciones") or []
    out = []
    for alc in ALCANCES_LANZAR:
        cands = [a for a in lista if a.get("alcance") == alc and a.get("ofertas") == "todas" and AU._valida(a, "OF-999", hoy)]
        probl = ""
        if not cands:
            probl = "no hay una vigente con ofertas «todas»"
        else:
            buenas = [a for a in cands if a.get("firmante") in nombres_duenos and not _vacio(a.get("vigente_hasta"))
                      and (alc not in CON_TECHO or _num(a.get("techo_usd")))]
            if not buenas:
                probl = "la vigente no tiene vigencia, techo_usd o firmante de datos/dueno.local.json"
        out.append(_item("autorizacion." + alc, "autorización escrita «%s» para todos los productos" % alc,
                         FALTA if probl else DISP, True,
                         "En tu terminal, en la carpeta del repo: python herramientas/firmar.py autorizaciones --recomendado "
                         "(textos propuestos, techo desde los topes y 90 días; solo pide tu nombre y «firmo»)." if probl else "",
                         probl))
    return out


# ------------------------------------------------------------------ 4. lecturas en red (gratuitas)
def _http_json(url, cabeceras=None, metodo="GET", datos=None, timeout=30):
    req = urllib.request.Request(url, data=datos, method=metodo, headers=cabeceras or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8") or "{}")


def _error(e):
    code = getattr(e, "code", None)
    return "HTTP %s" % code if code else type(e).__name__


def red_netlify(est, red):
    if not est.get("NETLIFY_AUTH_TOKEN"):
        return [], None
    import claves
    import netlify_deploy as nd
    try:
        t = red.get("netlify") or nd.TransporteHTTP(claves.clave("NETLIFY_AUTH_TOKEN"), timeout=30)
        t("GET", "/user")
        slug = (t("GET", "/accounts") or [{}])[0].get("slug")
    except Exception as e:
        return [_item("red.netlify", "token de Netlify válido", FALTA, True,
                      "El token del .env no sirve (vencido o revocado): generá uno nuevo en app.netlify.com → User settings "
                      "→ Applications → Personal access tokens y reemplazalo en .env → NETLIFY_AUTH_TOKEN=", _error(e),
                      "https://app.netlify.com/user/applications")], None
    out = [_item("red.netlify", "token de Netlify válido", DISP, True)]
    try:
        b = nd.ancho_de_banda(t)
        out.append(_item("red.netlify_saldo", "Netlify con margen (ancho de banda < 70 %)", FALTA if b["alerta"] else DISP, True,
                         "Netlify corta los deploys sin créditos (403 en la corrida 2): app.netlify.com → Team settings → "
                         "Billing → subí el plan o comprá créditos.", "%s %% usado" % b["porcentaje"],
                         "https://app.netlify.com/teams/%s/billing/general" % b["cuenta"]))
    except Exception as e:
        out.append(_item("red.netlify_saldo", "Netlify con margen (ancho de banda)", NOVER, False, "", _error(e)))
    return out, slug


def _sum_caps_otros(cuenta_id, archivadas=()):
    """(suma de spend_cap, cantidad) de las campañas de la cuenta que cuentan para el límite (D101), sin las que Meta
    ya tiene archivadas o borradas aunque el repo no lo haya anotado (F64: OF-001 archivada seguía ocupando USD 150)."""
    try:
        import meta_campana
        caps = meta_campana._campanas_de_la_cuenta(str(cuenta_id).replace("act_", ""), "OF-NUEVA")
    except Exception:
        return None, None
    caps = [(o, x) for o, x in caps if o not in archivadas]
    if any(x is None for _, x in caps):
        return None, None
    return sum(x for _, x in caps), len(caps)


def _archivadas_en_meta(t, cuenta_id):
    """{OF: estado} de los productos cuya campaña Meta ya tiene ARCHIVED o DELETED (lectura gratuita de Graph)."""
    ids = {}
    for d in sorted(rutas.ruta("ofertas").glob("OF-*")):
        m = (rutas.leer_json(d / "externo.local.json", defecto={}) or {}).get("meta") or {}
        if m.get("campana") and str(m.get("estado") or "").upper() not in ("ARCHIVED", "DELETED"):
            ids[str(m["campana"])] = d.name
    if not ids:
        return {}
    out = {}
    for cid, of in ids.items():   # una lectura por campaña: Graph ya no acepta ?ids= (v26+)
        st = str((t("GET", cid, {"fields": "effective_status"}) or {}).get("effective_status") or "").upper()
        if st in ("ARCHIVED", "DELETED"):
            out[of] = st
    return out


def red_meta(est, cuenta, topes, red):
    if not est.get("META_SYSTEM_USER_TOKEN") or not cuenta or _vacio(cuenta.get("id")):
        return [], None
    import claves
    import meta_ads
    try:
        t = red.get("meta") or meta_ads.TransporteHTTP(claves.clave("META_SYSTEM_USER_TOKEN"), timeout=30)
        acc = t("GET", "act_%s" % str(cuenta["id"]).replace("act_", ""),
                {"fields": "spend_cap,amount_spent,currency,timezone_name,account_status"})
    except Exception as e:
        return [_item("red.meta", "token de Meta (usuario del sistema) lee la cuenta", FALTA, True,
                      "El token no lee la cuenta: en business.facebook.com → Usuarios del sistema → tu usuario → Asignar "
                      "activos → la cuenta publicitaria con «Administrar campañas»; si venció, Generar token nuevo y "
                      "reemplazalo en .env → META_SYSTEM_USER_TOKEN=", _error(e),
                      "https://business.facebook.com/settings/system-users")], None
    out = [_item("red.meta", "token de Meta (usuario del sistema) lee la cuenta", DISP, True,
                 nota="cuenta activa" if acc.get("account_status") == 1 else "estado de cuenta %s" % acc.get("account_status"))]
    cap = int(acc.get("spend_cap") or 0) / 100.0
    gastado = int(acc.get("amount_spent") or 0) / 100.0
    diario, dias = _get(topes or {}, "por_producto_defecto.meta.diario"), _get(topes or {}, "por_producto_defecto.meta.dias")
    try:
        archivadas = _archivadas_en_meta(t, cuenta["id"])
    except Exception:
        archivadas = {}
    otros, n_otras = _sum_caps_otros(cuenta["id"], archivadas)
    if not (_num(diario) and _num(dias)) or otros is None:
        out.append(_item("red.meta_limite", "límite de gasto de la cuenta publicitaria", NOVER, True,
                         "Primero completá los topes por producto (meta.diario y meta.dias).",
                         "límite USD %.2f, gastado USD %.2f" % (cap, gastado) if cap else "sin límite fijado"))
        return out, acc
    necesario = round(otros + diario * dias, 2)   # misma cuenta que meta_campana._limite_cuenta (D101)
    ok = cap > 0 and cap >= necesario
    out.append(_item("red.meta_limite", "límite de gasto de la cuenta ≥ campañas de la cuenta + un producto nuevo",
                     DISP if ok else FALTA, True,
                     "Meta → Facturación y pagos → Límite de gasto de la cuenta → Cambiar → poné USD %.0f o más (suma de los "
                     "spend_cap de las campañas de la cuenta, USD %.0f, más un producto nuevo, USD %.0f). Después decile al "
                     "director «listo»." % (necesario, otros, diario * dias),
                     "límite USD %.2f (gastado USD %.2f), hace falta USD %.2f" % (cap, gastado, necesario),
                     "https://business.facebook.com/billing_hub/accounts/details?asset_id=%s" % str(cuenta["id"]).replace("act_", "")))
    import autorizaciones as AU
    maximo = cuenta.get("campanas_max") or 1
    compartidas = "campanas_compartidas" in AU.vigentes("OF-999", rutas.hoy())
    lugar = n_otras + 1 <= maximo or compartidas
    out.append(_item("red.meta_lugar", "lugar para una campaña más en la cuenta (Matías: una por cuenta)", DISP if lugar else FALTA,
                     True, "La cuenta ya tiene %d campañas vivas y campanas_max = %d. Archivá en Meta la campaña de un producto "
                     "retirado (Administrador de anuncios → la campaña → Archivar), o firmá la autorización «campanas_compartidas» "
                     "(desvío D90) y subí campanas_max en datos/cuentas.local.json." % (n_otras, maximo),
                     "%d de %d%s" % (n_otras, maximo, ", con campanas_compartidas" if compartidas else "")))
    acc["_archivadas"] = archivadas
    decl = (cuenta.get("limite_gasto") or {}).get("usd")
    if cap and decl != cap:
        out.append(_item("cuentas.limite_declarado", "límite de la cuenta declarado en datos/cuentas.local.json = el de Meta",
                         FALTA, True, "Lo sincroniza el director sin la persona: python herramientas/detectar.py --completar",
                         "declarado %s, en Meta %.2f" % (decl, cap), quien="director"))
    return out, acc


def red_hotmart(red):
    import claves
    import hotmart_lector as HL
    basic = HL._basic_desde_claves(claves)
    if not basic:
        return []
    try:
        (red.get("hotmart") or HL.LectorAPI(basic))._cabeceras()
        return [_item("red.hotmart", "credencial de Hotmart obtiene token", DISP, True)]
    except Exception as e:
        return [_item("red.hotmart", "credencial de Hotmart obtiene token", FALTA, True,
                      "La credencial del .env no da token: en developers.hotmart.com → Credenciales, copiá de nuevo el "
                      "valor «Basic» (es base64 de client_id:client_secret) y reemplazalo en .env → HOTMART_BASIC=",
                      _error(e), "https://developers.hotmart.com/")]


def red_elevenlabs(est, red):
    if not est.get("ELEVENLABS_API_KEY"):
        return []
    import claves
    try:
        s = (red.get("elevenlabs") or (lambda: _http_json("https://api.elevenlabs.io/v1/user/subscription",
                                                         {"xi-api-key": claves.clave("ELEVENLABS_API_KEY")})))()
        libres = int(s.get("character_limit") or 0) - int(s.get("character_count") or 0)
        return [_item("red.elevenlabs", "crédito de ElevenLabs (caracteres libres)", DISP if libres > 5000 else FALTA, False,
                      "elevenlabs.io → Subscription: subí el plan o esperá el reinicio mensual.", "%d caracteres libres" % libres,
                      "https://elevenlabs.io/app/subscription")]
    except Exception as e:
        return [_item("red.elevenlabs", "crédito de ElevenLabs", NOVER, False, "", _error(e))]


def robot_hotmart(raiz, ejecutar):
    try:
        r = ejecutar(["node", str(raiz / "herramientas" / "hotmart_sesion.mjs"), "--verificar"],
                     capture_output=True, text=True, timeout=120)
        codigo = r.returncode
    except Exception as e:
        return _item("robot.hotmart", "sesión del robot de Hotmart (Chrome con perfil persistente)", NOVER, True, "", _error(e))
    paso = ("En una terminal, en la carpeta del repo: node herramientas/hotmart_sesion.mjs → se abre un Chrome: iniciá "
            "sesión en Hotmart vos (usuario, clave y verificación) y dejá esa ventana abierta. Decile al director «listo».")
    nota = {0: "", 1: "sesión vencida", 2: "no hay perfil todavía"}.get(codigo, "código %s" % codigo)
    return _item("robot.hotmart", "sesión del robot de Hotmart (Chrome con perfil persistente)", DISP if codigo == 0 else FALTA,
                 True, "" if codigo == 0 else paso, nota)


def vigia_item(ejecutar, sistema=None):
    import programar
    try:
        p = programar.plan(sistema=sistema, solo=["vigia"])[0]
        sistema = sistema or sys.platform
        raiz = os.path.normcase(str(rutas.RAIZ))
        otra = False   # la tarea existe pero corre otra carpeta (un clon nuevo en la misma PC): no es de esta instalación
        apagada = False   # 25/10: la tarea existía pero estaba deshabilitada y el vigía no corrió por más de un día
        if sistema.startswith("win"):
            r = ejecutar(p["estado"] + ["/XML"], capture_output=True, text=True)
            ok = r.returncode == 0
            otra = ok and raiz not in os.path.normcase(r.stdout or "")
            apagada = ok and bool(re.search(r"<Settings>.*?<Enabled>\s*false\s*</Enabled>", r.stdout or "", re.S | re.I))
        elif sistema == "darwin":
            ok = ejecutar(p["estado"], capture_output=True, text=True).returncode == 0
            otra = ok and p["archivo"].exists() and raiz not in os.path.normcase(p["archivo"].read_text(encoding="utf-8"))
        else:
            lineas = [x for x in (ejecutar(["crontab", "-l"], capture_output=True, text=True).stdout or "").splitlines()
                      if ("# %s:%s" % (programar.PREFIJO, p["nombre"])) in x]
            ok, otra = bool(lineas), bool(lineas) and not any(raiz in os.path.normcase(x) for x in lineas)
    except Exception as e:
        return _item("vigia", "tarea programada del vigía (cada hora, :37)", NOVER, True, "", _error(e))
    que = "tarea programada del vigía (cada hora, :37)"
    reinstalar = "python herramientas/programar.py instalar --confirmar --solo vigia"
    if otra:
        return _item("vigia", que, FALTA, True, "La tarea del vigía de esta PC corre otra carpeta del repo. Si esta es la "
                     "instalación que va a operar: %s (la reemplaza)." % reinstalar, "registrada para otra carpeta")
    if apagada:
        return _item("vigia", que, FALTA, True, "La tarea existe pero está deshabilitada: el vigía no pausa ni lee nada. %s "
                     "(la vuelve a registrar habilitada)." % reinstalar, "tarea deshabilitada", quien="director")
    if not ok:
        return _item("vigia", que, FALTA, True, "Último paso, cuando todo lo demás esté: %s" % reinstalar)
    ultimo = rutas.leer_json(rutas.ruta("estado", "vigia_ultimo.json"), defecto=None) or {}
    try:
        horas = (rutas.ahora() - datetime.fromisoformat(ultimo["hora"])).total_seconds() / 3600.0
    except (KeyError, ValueError, TypeError):
        return _item("vigia", que, NOVER, True, "Esperar la primera corrida (a los :37) y volver a detectar.",
                     "registrada, sin corridas todavía", quien="director")
    if horas > 2:
        return _item("vigia", que, FALTA, True, "El vigía no corre hace %.1f h aunque la tarea está registrada: revisar "
                     "estado/vigia.lock (pid vivo) y el último resultado de la tarea; si hace falta, %s." % (horas, reinstalar),
                     "última corrida hace %.1f h" % horas, quien="director")
    return _item("vigia", que, DISP, True, nota="última corrida hace %.1f h" % horas)


def latido_items(ejecutar, sistema=None):
    """F67: la tarea del latido (chequeo independiente del vigía) y el canal por el que avisa al dueño."""
    import programar
    out = []
    try:
        p = programar.plan(sistema=sistema, solo=["latido"])[0]
        sistema = sistema or sys.platform
        if sistema.startswith("win"):
            r = ejecutar(p["estado"] + ["/XML"], capture_output=True, text=True)
            ok = r.returncode == 0 and not re.search(r"<Settings>.*?<Enabled>\s*false\s*</Enabled>", r.stdout or "", re.S | re.I)
        elif sistema == "darwin":
            ok = ejecutar(p["estado"], capture_output=True, text=True).returncode == 0
        else:
            ok = ("# %s:latido" % programar.PREFIJO) in (ejecutar(["crontab", "-l"], capture_output=True, text=True).stdout or "")
        out.append(_item("latido", "latido del vigía (tarea independiente, :07)", DISP if ok else FALTA, True,
                         "" if ok else "python herramientas/programar.py instalar --confirmar --solo latido",
                         quien="director"))
    except Exception as e:
        out.append(_item("latido", "latido del vigía (tarea independiente, :07)", NOVER, True, "", _error(e), quien="director"))
    if rutas.ruta("estado", "ALERTA_VIGIA.json").exists():
        out.append(_item("alerta_vigia", "alerta del latido: el vigía no corre", FALTA, True,
                         "Ver estado/ALERTA_VIGIA.json y estado/AVISO_ULTIMO.md; arreglar el vigía (tarea, lock).",
                         "alerta abierta", quien="director"))
    tipo = ((_dato("config") or {}).get("avisos") or {}).get("tipo") or "archivo"
    out.append(_item("avisos", "canal de avisos al dueño (%s)" % tipo, DISP if tipo != "archivo" else FALTA, False,
                     "" if tipo != "archivo" else "Los avisos quedan solo en estado/avisos.jsonl: para recibirlos, en "
                     "datos/config.local.json → avisos.tipo = smtp (y SMTP_* en .env) o webhook (AVISO_WEBHOOK_URL en .env)."))
    return out


# ------------------------------------------------------------------ 5. sesión y respuestas
def _onboarding():
    return rutas.leer_json(rutas.ruta("estado", "onboarding.json"), defecto={}) or {}


def sesion_items(hoy, est, topes=None):
    anot = _onboarding().get("sesion") or {}
    necesario = _get(topes or {}, "por_producto_defecto.higgsfield.tope")
    out = []
    for id_, que, oblig, como, paso in EN_SESION:
        a = anot.get(id_) or {}
        if id_ == "conector.higgsfield" and est.get("HF_API_KEY_ID") and est.get("HF_API_KEY_SECRET"):
            oblig = False   # hay API de Higgsfield por .env
        if id_ == "saldo.higgsfield" and a.get("fecha") == hoy and _num(necesario):
            try:
                saldo = float(str(a.get("valor")).replace(",", "."))
            except ValueError:
                saldo = None
            if saldo is not None and saldo < necesario:   # un producto entero no entra en el saldo: no se lanza
                out.append(_item(id_, que, FALTA, oblig,
                                 "Cargá créditos en Higgsfield (higgsfield.ai → Pricing / Top up): hacen falta %.0f por producto "
                                 "(datos/topes.local.json → por_producto_defecto.higgsfield.tope) y hay %.2f. O bajá ese tope con "
                                 "python herramientas/firmar.py topes. Después decile al director «listo»." % (necesario, saldo),
                                 "%.2f créditos, hacen falta %.0f" % (saldo, necesario), "https://higgsfield.ai/pricing"))
                continue
        if a.get("fecha") == hoy and a.get("valor") not in (None, "", FALTA, "no_disponible"):
            out.append(_item(id_, que, DISP, oblig, nota="anotado hoy"))
        elif a.get("fecha") == hoy:
            out.append(_item(id_, que, FALTA, oblig, paso, "anotado hoy: no disponible"))
        else:
            out.append(_item(id_, que, SESION, oblig, paso, "el director lo prueba: " + como, quien="director"))
    return out


def respuestas_items():
    r = rutas.leer_json(rutas.ruta("datos", "respuestas.local.json"), defecto={}) or {}
    return [_item("respuesta." + k, pregunta, DISP if not _vacio(r.get(k)) else FALTA, oblig,
                  "Se pregunta una vez; el director lo guarda con: python herramientas/detectar.py --respuesta %s=\"…\" "
                  "(opciones: %s)" % (k, " | ".join(ops)) if _vacio(r.get(k)) else "")
            for k, oblig, pregunta, ops in PREGUNTAS], r


# ------------------------------------------------------------------ armado
def detectar(raiz=None, ejecutar=subprocess.run, con_red=True, red=None, completar=False, sistema=None):
    from pathlib import Path
    raiz = Path(raiz or rutas.RAIZ)
    red = red or {}
    hoy = rutas.hoy()
    items = entorno(raiz, ejecutar)
    k, est = claves_items(raiz)
    items += k
    items += dueno_items()
    d = _dato("dueno") or {}
    nombres = [x.get("nombre") for x in d.get("duenos") or [] if not _vacio(x.get("nombre"))]
    items += config_items()
    resp_items, _resp = respuestas_items()
    ci, cuenta = cuentas_items(_resp)
    items += ci
    ti, topes = topes_items(nombres)
    items += ti
    items += autorizaciones_items(nombres, hoy)
    items += checkout_pais_items()
    items += sesion_items(hoy, est, topes)
    items += resp_items
    descubierto = {}
    if con_red:
        ni, slug = red_netlify(est, red)
        items += ni
        mi, acc = red_meta(est, cuenta, topes, red)
        items += mi
        items += red_hotmart(red)
        items += red_elevenlabs(est, red)
        items.append(robot_hotmart(raiz, ejecutar))
        if slug:
            descubierto["netlify.equipo"] = slug
        if acc and acc.get("timezone_name"):
            descubierto["zona"] = acc["timezone_name"]
        if acc and int(acc.get("spend_cap") or 0) > 0:
            descubierto["limite_gasto"] = int(acc["spend_cap"]) / 100.0
        if acc and acc.get("_archivadas"):
            descubierto["archivadas"] = acc["_archivadas"]
    items.append(vigia_item(ejecutar, sistema))
    items += latido_items(ejecutar, sistema)
    escritos = _completar(descubierto) if completar else []
    return items, escritos


def _completar(descubierto):
    """Escribe solo lo que se descubre por lectura y está vacío o con marcador; nunca pisa una decisión del dueño."""
    escritos = []
    for nombre in ("config", "cuentas"):   # clon limpio: se copian del ejemplo; dueño, topes y autorizaciones los firma la persona
        local, ejemplo = rutas.ruta("datos", "%s.local.json" % nombre), rutas.ruta("datos", "%s.ejemplo.json" % nombre)
        if not local.exists() and ejemplo.exists():
            rutas.escribir_json(local, rutas.leer_json(ejemplo))
            escritos.append("datos/%s.local.json (copiado del ejemplo)" % nombre)
    c = _dato("cuentas")
    if c is not None and descubierto.get("netlify.equipo") and _vacio(_get(c, "netlify.equipo")):
        c.setdefault("netlify", {})["equipo"] = descubierto["netlify.equipo"]
        rutas.escribir_json(rutas.ruta("datos", "cuentas.local.json"), c)
        escritos.append("datos/cuentas.local.json → netlify.equipo")
    if c is not None and descubierto.get("limite_gasto"):
        cuenta = (_get(c, "meta.cuentas") or [None])[0]
        if cuenta is not None and (cuenta.get("limite_gasto") or {}).get("usd") != descubierto["limite_gasto"]:
            # D101: el límite lo fija una persona en Meta (el conector no lo escribe); acá solo se copia lo leído por Graph
            cuenta["limite_gasto"] = {"usd": descubierto["limite_gasto"], "fijado_por": "dueño en Meta (leído por Graph)",
                                      "fecha": rutas.hoy(), "fuente": "detectar.py --completar"}
            rutas.escribir_json(rutas.ruta("datos", "cuentas.local.json"), c)
            escritos.append("datos/cuentas.local.json → meta.cuentas[0].limite_gasto (leído de Meta)")
    for of, st in (descubierto.get("archivadas") or {}).items():   # F64: lo que Meta ya archivó deja de contar
        rutas.guardar_externo(of, meta={"estado": st, "estado_leido": rutas.hoy()})
        escritos.append("ofertas/%s/externo.local.json → meta.estado %s (leído de Meta)" % (of, st))
    conf = _dato("config")
    if conf is not None and descubierto.get("zona") and conf.get("zona") in (None, "", "UTC"):
        try:
            rutas.zona_horaria(descubierto["zona"])   # Windows sin tzdata no conoce zonas con horario de verano
        except rutas.FaltaDato:
            return escritos
        conf["zona"] = descubierto["zona"]
        rutas.escribir_json(rutas.ruta("datos", "config.local.json"), conf)
        escritos.append("datos/config.local.json → zona (de la cuenta publicitaria)")
    return escritos


FIJABLES = {"meta.cuenta": ("meta.cuentas.0.id", r"^(act_)?\d+$"), "meta.pixel": ("meta.cuentas.0.pixel", r"^\d+$"),
            "meta.moneda": ("meta.cuentas.0.moneda", r"^[A-Z]{3}$"), "meta.pagina": ("meta.pagina_defecto", r"^\d+$"),
            "hotmart.correo_soporte": ("hotmart.correo_soporte", r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
            "hotmart.responsable": ("hotmart.responsable", r"^.{2,}$")}


def fijar(pares):
    """Escribe en datos/cuentas.local.json lo que el director descubrió por lectura con el conector (o la persona
    dictó: correo de soporte). meta.pagina.<mercado>=ID guarda una página por mercado (es, de, en…). Nunca claves."""
    import re
    p = rutas.ruta("datos", "cuentas.local.json")
    c = rutas.leer_json(p, defecto=None)
    if c is None:
        c = rutas.leer_json(rutas.ruta("datos", "cuentas.ejemplo.json"), defecto={}) or {}
    for par in pares:
        k, _, v = par.partition("=")
        v = v.strip().strip('"')
        m = re.match(r"^meta\.pagina\.([a-z]{2}(?:-[A-Za-z]+)?)$", k)
        if m and re.match(r"^\d+$", v):
            c.setdefault("meta", {}).setdefault("paginas_por_mercado", {})[m.group(1)] = v
            continue
        if k not in FIJABLES or not re.match(FIJABLES[k][1], v):
            raise SystemExit("--fijar: «%s=…» no vale (fijables: %s, meta.pagina.<mercado>)" % (k, ", ".join(FIJABLES)))
        destino = c
        ks = FIJABLES[k][0].split(".")
        for i, x in enumerate(ks[:-1]):
            if x.isdigit():
                while len(destino) <= int(x):
                    destino.append({})
                destino = destino[int(x)]
            else:
                destino = destino.setdefault(x, [] if ks[i + 1].isdigit() else {})
        destino[ks[-1]] = v
        if k == "meta.pagina":
            cu = c["meta"].setdefault("cuentas", [{}])[0]
            cu["paginas"] = [x for x in cu.get("paginas") or [] if not _vacio(x) and x != v] + [v]
    rutas.escribir_json(p, c)


def anotar(pares, hoy=None):
    hoy = hoy or rutas.hoy()
    validos = {x[0] for x in EN_SESION}
    o = _onboarding()
    s = o.setdefault("sesion", {})
    for par in pares:
        k, _, v = par.partition("=")
        if k not in validos:
            raise SystemExit("--anotar: «%s» no es anotable (válidos: %s)" % (k, ", ".join(sorted(validos))))
        s[k] = {"valor": v.strip(), "fecha": hoy}
    rutas.escribir_json(rutas.ruta("estado", "onboarding.json"), o)


def responder(pares):
    p = rutas.ruta("datos", "respuestas.local.json")
    r = rutas.leer_json(p, defecto={}) or {}
    validas = {x[0]: x[3] for x in PREGUNTAS}
    for par in pares:
        k, _, v = par.partition("=")
        v = v.strip().strip('"')
        import re
        if k == "no_operar" and re.match(RE_LISTA_OF, v.replace(" ", "")):
            v = v.replace(" ", "")
        elif k not in validas or v not in validas[k]:
            raise SystemExit("--respuesta: «%s» no vale (preguntas: %s)" % (par, "; ".join(
                "%s=%s" % (n, "|".join(o)) for n, o in validas.items())))
        r[k] = v
    rutas.escribir_json(p, r)


def siguiente(items):
    """El próximo faltante obligatorio que depende de la persona (lo del director se resuelve antes, sin preguntar)."""
    return next((i for i in items if i["obligatorio"] and i["estado"] == FALTA and i["quien"] == "persona"), None)


def guardar(items, escritos):
    o = _onboarding()
    faltan = [i["id"] for i in items if i["obligatorio"] and i["estado"] != DISP]
    o.update({"hora": rutas.ahora().isoformat(timespec="seconds"), "ok_obligatorio": not faltan, "faltan": faltan,
              "items": [{k: v for k, v in i.items() if k in ("id", "estado", "obligatorio", "nota")} for i in items],
              "completado_por_lectura": escritos})
    rutas.escribir_json(rutas.ruta("estado", "onboarding.json"), o)
    return faltan


def main(argv=None):
    ap = argparse.ArgumentParser(description="Detecta qué hay y qué falta para que hyperflujo-auto ande solo.")
    ap.add_argument("--sin-red", action="store_true")
    ap.add_argument("--siguiente", action="store_true")
    ap.add_argument("--completar", action="store_true")
    ap.add_argument("--anotar", action="append", default=[])
    ap.add_argument("--respuesta", action="append", default=[])
    ap.add_argument("--fijar", action="append", default=[], help="lo descubierto con el conector: meta.cuenta=…, meta.pixel=…")
    a = ap.parse_args(argv)
    if a.fijar:
        fijar(a.fijar)
    if a.anotar:
        anotar(a.anotar)
    if a.respuesta:
        responder(a.respuesta)
    items, escritos = detectar(con_red=not a.sin_red, completar=a.completar)
    faltan = guardar(items, escritos)
    sig = siguiente(items)
    if a.siguiente:
        print(json.dumps(sig or {}, ensure_ascii=False, indent=1))
    else:
        for i in items:
            marca = {"disponible": "disponible", "falta": "FALTA", "no_verificado": "no verificado", "en_sesion": "lo ve la sesión"}[i["estado"]]
            print("%-62s %-16s %s%s" % (i["que"][:62], marca, "obligatorio" if i["obligatorio"] else "opcional",
                                        ("  · " + i["nota"]) if i["nota"] else ""))
        for e in escritos:
            print("completado por lectura: " + e)
        pend = [i["id"] for i in items if i["quien"] == "director" and i["estado"] != DISP]
        if pend:
            print("\nPara el director (sin la persona): " + ", ".join(pend))
        if sig:
            print("\nPróximo paso manual [%s]: %s%s" % (sig["id"], sig["paso"], ("\nAbrir: " + sig["abrir"]) if sig.get("abrir") else ""))
    print(json.dumps({"ok": not faltan, "codigo": 0 if not faltan else 3,
                      "motivo": "todo lo obligatorio disponible" if not faltan else "faltan: " + ", ".join(faltan),
                      "artefactos": ["estado/onboarding.json"] + escritos}, ensure_ascii=False))
    return 0 if not faltan else 3


if __name__ == "__main__":
    sys.exit(main())
