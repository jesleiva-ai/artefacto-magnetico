#!/usr/bin/env python3
"""director.py — corrida diaria real de hyperflujo-auto (TAREA 036 parte A). Python determinista, sin LLM.

    python herramientas/director.py --modo principal          # 00:07: abre, avanza, opera e informa
    python herramientas/director.py --modo pulso              # 12:07: avanza lo que está en curso, no abre nuevos
    python herramientas/director.py --modo principal --simular --estado <tmp>   # lanzador simulado (pruebas)

Qué hace, en orden:
  1. Pre-vuelo: cerrojo estado/director.lock (huérfano a las 3 h), freno del dueño (estado/freno.json: solo pausas),
     CLI de Claude (ruta_claude.py), topes (topes.py, falla cerrado) y autorizaciones (autorizaciones.py).
  2. Principal: abre un producto nuevo en «por_cazar» si hay cupo (max_nuevos_por_dia) y ninguno espera en «candidato» o
     «por_cazar» (TAREA 037 A: la caza es la primera etapa; con --solo OF-NNN solo abre ese número y no toca los demás).
  2b. Lee gasto (meta_lector) y ventas netas (hotmart_lector) de ayer y hoy de los activos (nulo ≠ 0).
  2c. Repo de productos (D119): sube lo que está listo (solo el producto; testimonios fuera del sistema).
      Vencimiento D78 de la oferta de lanzamiento. Compuertas: validar_anuncios vigente (D103) antes de activar.
  3. Decide por producto (orquestador.decidir: D92 > Matías > Manual; bajas primero) y ejecuta:
       acciones «python» (verificar, bajar, pausa técnica…) con las herramientas sin modelo;
       acciones «worker» con lanzar_worker.py (claude -p, entorno acotado, --max-budget-usd, timeout duro),
       en serie o en paralelo acotado (datos/config.local.json → workers.paralelo_max).
  4. Escribe estado/informes/<fecha>[-pulso].md y estado/ultimo_latido.json. Cada corrida termina (sin bucles).
Solo biblioteca estándar.
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import autorizaciones as AU  # noqa: E402
import estado as E  # noqa: E402
import etapas  # noqa: E402
import informe_diario  # noqa: E402
import lanzar_worker as LW  # noqa: E402
import orquestador as O  # noqa: E402
import rutas  # noqa: E402
import topes as T  # noqa: E402

ACCIONES_DE_PAUSA = ("bajar", "pausa_tecnica")
HORAS_CERROJO = 3


class Ocupado(RuntimeError):
    pass


# ------------------------------------------------------------------ cerrojo
HORAS_CERROJO_POR_NOMBRE = {"vigia": 2}   # 2 × el intervalo horario del vigía (Director_H1, 25/10: quedó parado > 1 día)


def pid_vivo(pid):
    """¿Existe el proceso? Nunca lo toca (en Windows os.kill(pid, 0) lo terminaría). None = no se puede saber."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if sys.platform.startswith("win"):
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            codigo = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(codigo))
            k.CloseHandle(h)
            return bool(ok) and codigo.value == 259   # STILL_ACTIVE
        except Exception:
            return None
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return None


def tomar_cerrojo(nombre="director", ahora=None, vivo=pid_vivo):
    ahora = ahora or rutas.ahora()
    p = rutas.ruta("estado", "%s.lock" % nombre)
    nota = None
    if p.exists():
        try:
            previo = json.loads(p.read_text(encoding="utf-8"))
            desde = datetime.fromisoformat(previo["hora"])
            if desde.tzinfo is None:
                desde = desde.replace(tzinfo=ahora.tzinfo)
            horas = HORAS_CERROJO_POR_NOMBRE.get(nombre, HORAS_CERROJO)
            if ahora - desde < timedelta(hours=horas) and vivo(previo.get("pid")) is not False:
                raise Ocupado("otra corrida tiene el cerrojo desde %s (pid %s)" % (previo.get("hora"), previo.get("pid")))
            nota = "cerrojo huérfano de %s tomado (pid %s %s)" % (
                previo.get("hora"), previo.get("pid"), "inexistente" if vivo(previo.get("pid")) is False else "vencido")
        except (ValueError, KeyError):
            nota = "cerrojo ilegible reemplazado"
    rutas.escribir_json(p, {"pid": os.getpid(), "hora": ahora.isoformat(timespec="seconds")})
    return nota


def soltar_cerrojo(nombre="director"):
    try:
        rutas.ruta("estado", "%s.lock" % nombre).unlink()
    except FileNotFoundError:
        pass


def freno_dueno():
    """estado/freno.json presente = solo se permite pausar. Ilegible también cuenta como freno (falla cerrado)."""
    p = rutas.ruta("estado", "freno.json")
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("motivo") or "freno del dueño"
    except (OSError, ValueError):
        return "freno ilegible (cuenta como activo)"


# ------------------------------------------------------------------ gasto del modelo
def gasto_anthropic_hoy(fecha):
    """Suma del consumo por API de los workers de hoy (estado/trabajos.jsonl). Un dato nulo = total nulo."""
    p = rutas.ruta("estado", "trabajos.jsonl")
    if not p.exists():
        return 0.0
    total = 0.0
    try:
        for linea in p.read_text(encoding="utf-8").splitlines():
            if not linea.strip():
                continue
            t = json.loads(linea)
            if str(t.get("inicio", "")).startswith(fecha):
                if t.get("consumo") is None:
                    return None
                total += t["consumo"]
    except (OSError, ValueError):
        return None
    return total


# ------------------------------------------------------------------ lanzador real
RE_CODIGO = re.compile(r"CODIGO_SALIDA=(\d+)")


def traducir_worker(r):
    """Resultado de lanzar_worker → forma que entiende el orquestador. Códigos del worker (PLAN §3.8):
    3 humano y 5 envío incierto → bloqueo humano; 4 tope/autorización y 6 freno → espera sin contar fallo."""
    codigo = r.get("codigo")
    for pend in (r.get("salida") or {}).get("pendientes", []):
        m = RE_CODIGO.search(pend)
        if m:
            codigo = int(m.group(1))
    out = {"ok": r.get("ok", False), "codigo": codigo, "motivo": r.get("motivo"), "consumo": r.get("consumo"),
           "total_cost_usd": r.get("total_cost_usd"), "session_id": r.get("session_id"), "log": r.get("log")}
    if codigo in (3, 5):
        humanos = [x for x in (r.get("salida") or {}).get("pendientes", []) if not RE_CODIGO.search(x)]
        out.update(ok=False, humano=True, accion_humana=(humanos[0] if humanos else
                   "envío incierto: conciliar por ID en el panel del proveedor" if codigo == 5 else "ver " + str(r.get("log"))))
    elif codigo in (4, 6):
        out.update(ok=False, espera=True)
    return out


def construir_lanzador(config, topes, *, exe=None, extra_env=(), manejadores=None, freno=None, fecha=None, via="claude_p"):
    """Función decisión → resultado. Las acciones «python» van a `manejadores`; las «worker», a lanzar_worker
    (via «claude_p») o a un pedido para la sesión de Claude Code que corre el director (via «sesion», TAREA 041:
    pedidos_sesion.py; la corrida siguiente recoge la salida y la verifica por artefacto igual que con claude -p)."""
    manejadores = manejadores_reales() if manejadores is None else manejadores

    def lanzador(decision):
        if freno and decision["accion"] not in ACCIONES_DE_PAUSA:
            return {"ok": False, "espera": True, "consumo": 0, "motivo": "freno del dueño: solo se permite pausar (%s)" % freno}
        try:
            d = etapas.definicion(decision["accion"])
        except KeyError as e:
            return {"ok": False, "codigo": 2, "consumo": 0, "motivo": str(e)}
        if d["ejecutor"] == "python":
            h = manejadores.get(decision["accion"])
            if h is None:
                return {"ok": False, "espera": True, "consumo": 0,
                        "motivo": "[PENDIENTE: herramienta sin modelo para «%s»]" % decision["accion"]}
            return h(decision)
        import plan
        maximos = None
        if decision["accion"] == "cazar":   # TAREA 037: caza ya adoptada y verificada por artefacto → sin worker ni modelo
            import cazar
            ok_c, mot_c = cazar.verificar_cazada(decision["of"])
            if ok_c:
                if via == "sesion":   # el worker de la sesión ya dejó la caza: su pedido se cierra (no se repite)
                    import pedidos_sesion as PS
                    PS.cerrar(decision, "caza verificada por artefacto")
                return {"ok": True, "cazada": True, "consumo": 0, "motivo": "caza ya adoptada y verificada (%s): sin worker" % mot_c}
        if decision["accion"] == "crear_campana":   # TAREA 037 B: compuertas y llamadas exactas antes de lanzar el worker
            pre = preparar_campana(decision["of"], topes, fecha)
            if pre is not None:
                return pre
            import meta_campana as MC
            maximos = MC.maximos_pendientes(decision["of"])
        if decision["accion"] in ("activar", "escalar"):   # D105: el tope del producto está en la ficha, si no, no se gasta
            ficha = rutas.leer_json(rutas.ruta_ficha(decision["of"]), defecto={})
            tf = T.tope_ficha(ficha, "meta")
            if tf is None:
                return {"ok": False, "espera": True, "consumo": 0,
                        "motivo": "D105: la ficha de %s no tiene campana.presupuesto completo (diario, días, autorizado_por)" % decision["of"]}
            nuevo = (decision.get("parametros") or {}).get("nuevo_diario")
            maximo = ((ficha.get("campana") or {}).get("presupuesto") or {}).get("diario_max")
            if decision["accion"] == "escalar" and (maximo is None or nuevo is None or nuevo > maximo):
                return {"ok": False, "espera": True, "consumo": 0,
                        "motivo": "D105: el nuevo diario %s supera el diario_max de la ficha (%s)" % (nuevo, maximo)}
        if decision["accion"] == "activar":   # 037 B: Hotmart aprobado + landing y checkout 200 releídos en ESTA corrida
            espera = sondear_antes_de_activar(decision, manejadores)
            if espera is not None:
                return espera
        minutos = int(d.get("timeout_min") or 30) + 5

        def emitir_tickets():
            ids = plan.emitir(decision["of"], decision["accion"], fecha=fecha, minutos=minutos, regla=decision.get("regla"),
                              maximos=maximos)
            if decision["accion"] in plan.ETAPAS_CON_MEDIOS:   # imágenes y voces dentro de los techos firmados
                import medios
                ids += medios.emitir(decision["of"], fecha=fecha, minutos=minutos, regla=decision.get("regla"))["tickets"]
            return ids

        if via == "sesion":
            import pedidos_sesion as PS
            hecho = PS.recoger(decision)
            if hecho is None:   # sin salida todavía: deja (o mantiene) el pedido con sus tickets y espera a la sesión
                return PS.crear(decision, config=config, fecha=fecha, minutos=minutos, emitir=emitir_tickets)
            tickets = hecho.pop("tickets_pedido", [])
            r = traducir_worker(hecho)
        else:
            tickets = emitir_tickets()
            r = traducir_worker(LW.lanzar(decision, exe=exe, config=config, topes=topes, extra_env=extra_env,
                                          gastado_hoy_anthropic=gasto_anthropic_hoy(fecha or rutas.hoy())))
        if decision["accion"] == "crear_campana":   # regla 7: vale la relectura guardada, no el texto del worker
            r = verificar_campana(decision["of"], r)
        if decision["accion"] == "cazar":   # TAREA 037 A: vale referencia/candidatos.json verificado, no el texto del worker
            r = verificar_caza(decision["of"], r)
        plan.cerrar(tickets, ok=bool(r.get("ok")), fecha=fecha)
        if tickets:
            r["tickets"] = tickets
        if decision["accion"] == "activar" and r.get("ok"):   # regla 7: vale la relectura, no el texto del worker
            releer = manejadores.get("releer_campana")
            r["estado_meta"] = releer(decision["of"]) if releer else None
        return r
    return lanzador


def verificar_caza(of, r):
    """Después del worker cazar: cazar.verificar_cazada manda (1 a 5 candidatos con evidencia, anónima, sin IDs reales).
    Ninguno cumple → «sin producto hoy»: espera sin contar fallo (no se baja el umbral)."""
    import cazar
    ok, motivo = cazar.verificar_cazada(of)
    if ok:
        return {**r, "ok": True, "cazada": True, "motivo": motivo}
    if r.get("ok") and "1 a 5 candidatos" in motivo:
        return {**r, "ok": False, "espera": True, "cazada": False, "motivo": "sin producto hoy: " + motivo}
    return {**r, "ok": False, "cazada": False, "motivo": "caza no verificada: %s" % motivo}


# ------------------------------------------------------------------ TAREA 037 B: campaña en pausa y activación
def preparar_campana(of, topes, fecha):
    """meta_campana.preparar: None si se puede lanzar el worker; si no, el resultado de espera o de bloqueo humano."""
    import meta_campana as MC
    if topes is None:
        return {"ok": False, "espera": True, "consumo": 0, "motivo": "sin topes: no se prepara la campaña (falla cerrado)"}
    try:
        MC.preparar(of, fecha=fecha, topes=topes)
    except MC.BloqueoHumano as e:
        return {"ok": False, "codigo": 3, "humano": True, "consumo": 0, "motivo": str(e), "accion_humana": str(e)}
    except (MC.ErrorPlan, MC.ErrorTopes, T.TopesFaltantes, rutas.FaltaDato) as e:
        return {"ok": False, "espera": True, "consumo": 0, "motivo": "campaña en pausa: %s" % e}
    return None


def verificar_campana(of, r):
    """Después del worker crear_campana: envío incierto → humano (código 5); si no, la verificación por relectura manda."""
    import meta_campana as MC
    try:
        llamadas = MC._cargar(of)["llamadas"]
    except Exception as e:
        return {**r, "ok": False, "campana_en_pausa": False, "motivo": "sin llamadas.json: %s" % e}
    inciertas = [x["clave"] for x in llamadas if x["estado"] == "enviando"]
    if inciertas:
        m = "envío incierto en «%s»: conciliar por ID en el panel de Meta y registrarlo antes de seguir (regla 7)" % inciertas[0]
        return {**r, "ok": False, "codigo": 5, "humano": True, "accion_humana": m, "motivo": m, "campana_en_pausa": False}
    ok, motivo = MC.verificar_campana_en_pausa(of)
    if not ok:
        return {**r, "ok": False, "campana_en_pausa": False, "motivo": "verificación de la campaña en pausa: %s" % motivo}
    return {**r, "ok": True, "campana_en_pausa": True, "motivo": motivo}


def sondear_antes_de_activar(decision, manejadores):
    """Activación solo por el director con Hotmart aprobado, landing 200 y checkout 200 leídos en esta corrida.
    Sin manejador «verificar» no se activa (falla cerrado). Devuelve None si se puede seguir."""
    h = manejadores.get("verificar")
    if h is None:
        return {"ok": False, "espera": True, "consumo": 0,
                "motivo": "sin sonda de Hotmart, landing y checkout: no se activa (falla cerrado)"}
    try:
        v = h(decision) or {}
    except Exception as e:
        return {"ok": False, "espera": True, "consumo": 0, "motivo": "sonda previa a activar: %s: %s" % (type(e).__name__, e)}
    if v.get("hotmart_aprobado") is True and v.get("landing_http") == 200 and v.get("checkout_http") == 200:
        # TAREA 041 E3: además, el sitio PUBLICADO entero pasa la compuerta (relleno, legales, píxel, checkout, CTA).
        # Sin compuerta no se activa (falla cerrado); no hay excepción por chat.
        c = manejadores.get("compuerta_sitio")
        if c is None:
            return {"ok": False, "espera": True, "consumo": 0, "motivo": "sin compuerta del sitio publicado: no se activa (E3)"}
        try:
            rc = c(decision) or {}
        except Exception as e:
            return {"ok": False, "espera": True, "consumo": 0, "motivo": "compuerta del sitio: %s: %s" % (type(e).__name__, e)}
        if rc.get("ok") is True:
            return None
        return {"ok": False, "espera": True, "consumo": 0,
                "motivo": "E3: el sitio publicado no pasa la compuerta: %s" % "; ".join((rc.get("problemas") or ["sin detalle"])[:4])}
    return {"ok": False, "espera": True, "consumo": 0,
            "motivo": "antes de activar: hotmart_aprobado=%s, landing=%s, checkout=%s (se exige aprobado y 200 en ambos)"
                      % (v.get("hotmart_aprobado"), v.get("landing_http"), v.get("checkout_http"))}


# Acciones sin modelo (parte B): lectores reales y pausa por Graph. Inyectables para pruebas y ensayo.
def urls_de(of):
    ext = rutas.externo(of)
    nt = ext.get("netlify") or {}
    landing = nt.get("url") or (nt.get("landing") or {}).get("url")
    if not landing:   # F60: respaldo en la ficha (url_destino de producción)
        try:
            landing = (rutas.ficha(of) or {}).get("url_destino") or None
        except Exception:
            landing = None
    return (landing, ((ext.get("hotmart") or {}).get("principal") or {}).get("checkout_url"))


def manejadores_reales(*, lector_hotmart=None, sondear=None, transporte_meta=None, compuerta_sitio=None):
    import hotmart_lector
    import meta_pausa
    import vigia
    sondear = sondear or vigia.sonda_http

    def verificar(decision):
        of = decision["of"]
        ap = hotmart_lector.estado_aprobacion(of, lector_hotmart)
        landing, checkout = urls_de(of)
        r = {"ok": True, "consumo": 0, "hotmart_aprobado": ap["aprobado"],
             "landing_http": vigia.seguro(sondear, landing) if landing else None,
             "checkout_http": vigia.seguro(sondear, checkout) if checkout else None}
        if ap["aprobado"] is None:
            r["motivo_espera"] = "aprobación de Hotmart desconocida (%s): no avanza" % ap["motivo"]
        elif ap["aprobado"] is False:
            r["motivo_espera"] = "Hotmart todavía no aprobó (status %s)" % ap["status"]
        return r

    def pausar(decision):
        return meta_pausa.pausar(decision["of"], decision.get("motivo") or decision["accion"], transporte=transporte_meta,
                                 actor="director")

    def releer_campana(of):
        """status de la campaña releído por Graph (sin token = None: la activación no se da por confirmada)."""
        t = transporte_meta or meta_pausa.transporte_por_defecto()
        camp = ((rutas.externo(of).get("meta") or {}).get("campana"))
        if t is None or not camp:
            return None
        try:
            return t("GET", camp, {"fields": "status,effective_status"}).get("status")
        except Exception:
            return None

    def compuerta(decision):
        import compuerta_sitio as CS
        return CS.exigir(decision["of"], "activar")

    return {"verificar": verificar, "bajar": pausar, "pausa_tecnica": pausar, "releer_campana": releer_campana,
            "compuerta_sitio": compuerta_sitio or compuerta}


def sincronizar_campana(archivo=None):
    """campana.diario / diario_max / precio de cada producto salen de su ficha (D105), nunca se cargan a mano
    (revisión 036 h. 5: sin esto el orquestador no activa y el vigía no sabe qué diario vigilar)."""
    for p in E.productos(archivo=archivo):
        ficha = rutas.leer_json(rutas.ruta_ficha(p["of"]), defecto=None) if rutas.RE_OF.match(p["of"]) else None
        if not ficha:
            continue
        pr = (ficha.get("campana") or {}).get("presupuesto") or {}
        precio = ficha.get("precio") or {}
        nuevo = {"diario": pr.get("diario"), "diario_max": pr.get("diario_max"),
                 "precio": precio.get("lanzamiento") if precio.get("lanzamiento") is not None else precio.get("monto")}
        actual = p.get("campana") or {}
        cambios = {k: v for k, v in nuevo.items() if v is not None and actual.get(k) != v}
        if cambios:
            E.marcar(p["of"], "campana", {**actual, **cambios}, archivo=archivo)


def actualizar_mediciones(fecha, archivo=None, *, lector_meta=None, lector_hotmart=None):
    """Lee gasto (Meta) y ventas netas (Hotmart) de ayer y hoy para los productos activos y las registra.
    Lo que no se pudo leer queda nulo (nunca 0): la pausa técnica por lectura caída lo resuelve."""
    import hotmart_lector
    import meta_lector
    from datetime import date
    ayer = (date.fromisoformat(fecha) - timedelta(days=1)).isoformat()
    hechos = []
    for p in E.productos(archivo=archivo):
        if p["estado"] not in E.ACTIVOS:
            continue
        m = meta_lector.leer(p["of"], ayer, fecha, lector_meta)
        v = hotmart_lector.ventas(p["of"], ayer, fecha, lector_hotmart)
        for f in (ayer, fecha):
            gasto = None if m is None else m["gasto_por_dia"].get(f, 0.0 if m["filas"] else None)
            dia = None if v is None else v["por_dia"].get(f, {"compras": 0, "netos": 0.0})
            E.registrar_medicion(p["of"], f, gasto=gasto, ventas=None if dia is None else dia["compras"],
                                 ingresos=None if dia is None else dia["netos"],
                                 rechazados=None if m is None or f != fecha else len(m["rechazados"]), archivo=archivo)
        hechos.append(p["of"])
    return hechos


# ------------------------------------------------------------------ repo de productos (D119) y vencimiento D78
LISTOS_PARA_REPO = ("producido", "en_revision", "hotmart_enviado")


def fase_repo(fecha, archivo=None, repo=None, solo=None):
    """D119: sube al repo de productos los productos listos que todavía no se subieron. Es lo único que el sistema hace
    con ese repo: no pide, no recoge ni valida reviews, testimonios ni perfiles, y nada espera por ellos.
    `repo`: módulo con publicar/publicado_en/url_repo (inyectable en pruebas). Devuelve avisos."""
    repo = repo or __import__("repo_productos")
    avisos = []
    if not repo.url_repo():
        return ["repo de productos: sin REPO_PRODUCTOS_URL; no se sube nada (se informa)"]
    for p in E.productos(archivo=archivo):
        if solo and p["of"] != solo:
            continue
        if p["estado"] in LISTOS_PARA_REPO and not repo.publicado_en(p["of"]):
            try:
                r = repo.publicar(p["of"])
                avisos.append("repo de productos: %s subido (%s)" % (p["of"], r["commit"][:8]))
            except Exception as e:
                avisos.append("repo de productos: no se pudo subir %s: %s" % (p["of"], str(e)[:200]))
    return avisos


def compuertas_reales():
    """Compuertas del orquestador. D119: no hay compuerta de testimonios ni freno de calidad del panel."""
    import validar_anuncios
    import meta_campana
    return {"anuncios": lambda p: validar_anuncios.validacion_vigente(p["of"]),
            "campana": lambda p: meta_campana.campana_registrada(p["of"]),   # TAREA 037 B
            "candidato": lambda p: __import__("cazar").compuerta_candidato(p)}   # TAREA 037 A: confirma o veta el dueño


def fase_precio(fecha, archivo=None, solo=None):
    """D78: aviso 3 días antes y, al vencer, landing a precio regular + desactivar oferta (con autorización)."""
    import precio_vencimiento as PV
    avisos = []
    for p in E.productos(archivo=archivo):
        if p["estado"] not in E.ACTIVOS or (solo and p["of"] != solo):
            continue
        ficha = rutas.leer_json(rutas.ruta_ficha(p["of"]), defecto={})
        r = PV.revisar(p, ficha, fecha)
        if r["estado"] == "aviso":
            avisos.append("D78: la oferta de lanzamiento de %s vence el %s" % (p["of"], r["fin"]))
        elif r["estado"] == "vencido":
            try:
                a = PV.aplicar(p["of"], p, ficha, archivo=archivo,
                               autorizado="desactivar_oferta_al_vencer" in AU.vigentes(p["of"], fecha))
                avisos.append("D78 %s: %s" % (p["of"], a["motivo"]))
            except Exception as e:
                avisos.append("D78 %s: %s" % (p["of"], str(e)[:200]))
    return avisos


# ------------------------------------------------------------------ altas
def pausas_recientes(fecha):
    """Pausas del vigía y del director desde ayer (estado/pausas.jsonl), con su motivo, para el informe (D106)."""
    from datetime import date
    p = rutas.ruta("estado", "pausas.jsonl")
    if not p.exists():
        return []
    desde = (date.fromisoformat(fecha) - timedelta(days=1)).isoformat()
    out = []
    for linea in p.read_text(encoding="utf-8").splitlines():
        try:
            f = json.loads(linea)
        except ValueError:
            continue
        if str(f.get("hora", ""))[:10] >= desde:
            out.append("pausa %s de %s (%s): %s — %s" % (f.get("actor"), f.get("of"), f.get("hora"), f.get("motivo"),
                                                       "confirmada" if f.get("ok") else "NO confirmada: " + str(f.get("accion_humana") or f.get("motivo"))))
    return out


def no_operar():
    """Productos que opera otra persona (respuesta «no_operar» del onboarding): el director no los toca."""
    r = (rutas.leer_json(rutas.ruta("datos", "respuestas.local.json"), defecto={}) or {}).get("no_operar") or ""
    return tuple(x for x in str(r).split(",") if rutas.RE_OF.match(x.strip()))


def siguiente_of(archivo=None):
    usados = {p["of"] for p in E.productos(archivo=archivo)}
    usados |= {d.name for d in rutas.ruta("ofertas").glob("OF-*") if rutas.RE_OF.match(d.name)}
    n = max([int(x[3:]) for x in usados] + [0]) + 1
    return "OF-%03d" % n


def abrir_nuevo(fecha, archivo=None, topes=None, estado_inicial="por_cazar", solo=None):
    """Da de alta un producto nuevo si hay cupo y no hay otro esperando. Devuelve el OF o None con el motivo.
    TAREA 037 A: entra en «por_cazar» (la caza es la primera etapa del ciclo). `solo`: en una corrida supervisada de un
    solo producto, solo se abre si ese es el número que toca (nunca se saltea ni se reusa un número)."""
    if topes is None:
        return None, "sin topes: no se abre nada (falla cerrado)"
    prods = E.productos(archivo=archivo)
    if solo and any(p["of"] == solo for p in prods):
        return None, "%s ya existe: no se abre otro" % solo
    if any(p["estado"] in ("candidato", "por_cazar") for p in prods):
        return None, "ya hay un candidato esperando o en caza"
    # TAREA 037: un número preparado de antemano (carpeta ofertas/OF-NNN con la caza adoptada y la ficha, sin alta en
    # el estado) se abre con ese mismo número en la corrida supervisada; nunca se saltea ni se reusa otro.
    preparado = bool(solo) and rutas.ruta("ofertas", solo).is_dir() and not any(p["of"] == solo for p in prods)
    if solo and not preparado and siguiente_of(archivo) != solo:
        return None, "--solo %s: el próximo número libre es %s; no se abre nada" % (solo, siguiente_of(archivo))
    # TAREA 037 D: un producto importado del taller (importar_oferta.py) no es un alta nueva de hoy
    nuevos = sum(1 for p in prods if str(p.get("creado", "")).startswith(fecha) and not p.get("importado"))
    reemplazos = [p for p in prods if p.get("reemplazo_pendiente")]
    ok, mot = T.cupo_producir(topes, nuevos)
    if not ok and not reemplazos:
        return None, mot
    of = solo if preparado else siguiente_of(archivo)
    nombre = ((rutas.leer_json(rutas.ruta_ficha(of), defecto={}) or {}).get("producto") or {}).get("nombre") if preparado else None
    E.alta(of, nombre or "[PENDIENTE: lo define cazar-oferta]", archivo=archivo, estado_inicial=estado_inicial)
    if not ok:   # D106: la baja sin ventas libera un lugar aunque ya se haya usado el cupo de nuevos del día
        E.marcar(reemplazos[0]["of"], "reemplazo_pendiente", False, archivo=archivo)
        E.marcar(reemplazos[0]["of"], "reemplazado_por", of, archivo=archivo)
        return of, "alta de %s como reemplazo de %s (D106)" % (of, reemplazos[0]["of"])
    for r in reemplazos[:1]:
        E.marcar(r["of"], "reemplazo_pendiente", False, archivo=archivo)
        E.marcar(r["of"], "reemplazado_por", of, archivo=archivo)
    return of, "alta de %s" % of + (" (reemplaza a %s, D106)" % reemplazos[0]["of"] if reemplazos else "")


# ------------------------------------------------------------------ corrida
def correr(modo="principal", archivo=None, fecha=None, simular=False, exe=None, extra_env=(), manejadores=None,
           abrir=None, config=None, lectores=None, repo=None, compuertas=None, solo_lectura=False, solo=None, via="claude_p",
           excluir=None):
    config = (rutas.cargar_dato("config", defecto={}) or {}) if config is None else config
    fecha = fecha or rutas.hoy()
    avisos = []
    nota = tomar_cerrojo()
    if nota:
        avisos.append(nota)
    try:
        try:
            topes = T.cargar()
        except T.TopesFaltantes as e:
            topes = None
            avisos.append("[PENDIENTE: topes] %s" % e)
        freno = freno_dueno()
        if freno:
            avisos.append("freno del dueño activo: solo pausas (%s)" % freno)
        abrir = ((config.get("director") or {}).get("abrir_nuevos", True)) if abrir is None else abrir
        avisos += pausas_recientes(fecha)
        if solo_lectura:
            abrir = False
            avisos.append("SOLO LECTURA: se leyó Meta y Hotmart y se decidió sobre una copia del estado; no se lanzó ningún "
                          "worker, no se pausó, no se publicó ni se cambió el estado real")
        if modo == "principal" and abrir and not freno:
            of, mot = abrir_nuevo(fecha, archivo, topes, solo=solo)
            avisos.append(mot)
        if not simular:   # lecturas reales antes de decidir; con --simular no se lee nada afuera
            try:
                sincronizar_campana(archivo)
                actualizar_mediciones(fecha, archivo, **(lectores or {}))
            except Exception as e:   # una lectura rota nunca corta la corrida: queda nulo y lo ve la pausa técnica
                avisos.append("lecturas: %s: %s" % (type(e).__name__, e))
            for fase in (() if solo_lectura else (lambda: fase_repo(fecha, archivo, repo, solo),
                                                   lambda: fase_precio(fecha, archivo, solo) if modo == "principal" else [])):
                try:
                    avisos += fase()
                except Exception as e:   # una fase rota no corta la corrida: se informa
                    avisos.append("fase: %s: %s" % (type(e).__name__, str(e)[:200]))
            if compuertas is None:
                compuertas = compuertas_reales()
        if simular:
            lanzador = O.lanzador_simulado
        else:
            lanzador = construir_lanzador(config, topes, exe=exe, extra_env=extra_env, manejadores=manejadores,
                                          freno=freno, fecha=fecha, via=via)
        if solo_lectura:
            lanzador = lambda d: {"ok": False, "espera": True, "consumo": 0,
                                  "motivo": "SOLO LECTURA: habría ejecutado «%s» (%s)" % (d["accion"], d.get("motivo"))}
        workers = LW.config_workers(config)
        res = O.corrida_diaria(fecha, archivo=archivo, autorizaciones=lambda of: AU.vigentes(of, fecha),
                               lanzador=lanzador, topes=topes, modo=modo, paralelo_max=max(1, int(workers["paralelo_max"])),
                               compuertas=compuertas, solo=solo, excluir=no_operar() if excluir is None else excluir)
        salida = rutas.ruta("estado", "informes", "%s%s%s.md" % (fecha, "" if modo == "principal" else "-" + modo,
                                                                 "-solo-lectura" if solo_lectura else ""))
        texto = informe_diario.generar(fecha, res, archivo=archivo, salida=str(salida),
                                       titulo="Informe diario (%s)" % modo + (" — SIMULADO" if simular else ""))
        if avisos:
            texto = texto + "\n## Avisos del director\n\n" + "\n".join("- %s" % a for a in avisos) + "\n"
            salida.write_text(texto, encoding="utf-8")
        rutas.escribir_json(rutas.ruta("estado", "ultimo_latido.json"),
                            {"hora": rutas.ahora().isoformat(timespec="seconds"), "modo": modo, "productos": len(res),
                             "simulado": bool(simular)})
        return {"resultados": res, "informe": salida, "avisos": avisos}
    finally:
        soltar_cerrojo()


def main(argv=None):
    ap = argparse.ArgumentParser(description="Director diario de hyperflujo-auto (sin LLM; lanza workers claude -p).")
    ap.add_argument("--modo", choices=("principal", "pulso"), default="principal")
    ap.add_argument("--estado", help="archivo de estado (por defecto estado/productos.json)")
    ap.add_argument("--fecha", help="AAAA-MM-DD (por defecto hoy en la zona del dueño)")
    ap.add_argument("--simular", action="store_true", help="lanzador simulado; exige --estado temporal")
    ap.add_argument("--sin-abrir", action="store_true", help="no da de alta productos nuevos")
    ap.add_argument("--solo", metavar="OF-NNN", help="corrida supervisada de un solo producto (TAREA 037 D): abre ese número "
                    "si es el que toca y no toca los demás")
    ap.add_argument("--via", choices=("claude_p", "sesion"), default="claude_p",
                    help="quién corre los workers: claude -p (tareas programadas) o la sesión de Claude Code (/lanzar, /operar)")
    ap.add_argument("--solo-lectura", action="store_true",
                    help="primer ensayo real: lee y decide sobre una copia del estado; no lanza workers ni pausa ni publica")
    a = ap.parse_args(argv)
    if a.solo_lectura:
        import shutil
        import tempfile
        origen = Path(a.estado or E.archivo_defecto())
        copia = Path(tempfile.mkdtemp(prefix="hf_director_lectura_")) / "productos.json"
        if origen.exists():
            shutil.copy2(origen, copia)
        a.estado = str(copia)
    if a.simular and (not a.estado or Path(a.estado).resolve() == Path(E.archivo_defecto()).resolve()):
        print(json.dumps({"ok": False, "codigo": 2, "motivo": "--simular exige --estado temporal (revisión 035 h. 1)", "artefactos": []}))
        return 2
    if a.solo == "nuevo":   # /lanzar: el número lo elige el director (el próximo libre), nunca la sesión
        a.solo = siguiente_of(a.estado)
    elif a.solo:
        a.solo = rutas.validar_of(a.solo)
    try:
        r = correr(a.modo, archivo=a.estado, fecha=a.fecha, simular=a.simular, abrir=False if a.sin_abrir else None,
                   solo_lectura=a.solo_lectura, solo=a.solo, via=a.via)
    except Ocupado as e:
        print(json.dumps({"ok": False, "codigo": 6, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
        return 6
    for d in r["resultados"]:
        print(d["of"], d["estado"], "→", d["accion"], "|", d["motivo"])
    salida = {"ok": True, "codigo": 0, "motivo": "corrida %s terminada" % a.modo,
              "artefactos": [os.path.relpath(r["informe"], rutas.RAIZ).replace("\\", "/")]}
    if a.via == "sesion":
        import pedidos_sesion as PS
        salida.update(solo=a.solo, pedidos=[p for p in PS.pendientes() if not a.solo or p["of"] == a.solo])
    if a.modo == "principal" and not (a.simular or a.solo_lectura):   # git pull diario al terminar (actualizar.py)
        import actualizar
        u = actualizar.actualizar(si_toca=True)
        print("actualización:", u["motivo"])
    print(json.dumps(salida, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
