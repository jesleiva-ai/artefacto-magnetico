"""director_videos.py — el Director de Videos (subagente `.claude/agents/director-videos.md`). Sin aprobado, el anuncio no se carga.

Matías, 2026-10-30: «a veces me pasa que los videos están mal hechos y me los carga igual… la voz no coincide con la boca
o no tiene música, o el video empieza una voz y después cambia la voz y se corta… está pixelado… las fotos se trasluce con
otra imagen… los avatares no se ven bien, le faltan dedos». La vara está en `skills/director-videos/SKILL.md`.

    python herramientas/director_videos.py revisar --anuncio <carpeta del anuncio> [--idioma ja]
    python herramientas/director_videos.py revisar --archivo <video o imagen> [--salida <carpeta>] [--idioma ja]
    python herramientas/director_videos.py sellar --anuncio <carpeta> --nota 9.2 --veredicto aprobado \
        --materias '{"modelado": 9, ...}' --boletin <boletin_director.md> [--aplazos '["…"]']
    python herramientas/director_videos.py verificar --anuncio <carpeta>      (uno)
    python herramientas/director_videos.py verificar --anuncios <carpeta>     (todos los anuncios del producto)

- `revisar` es el examen técnico que el Director lee antes de mirar: tamaño, formato, cuadros por segundo, audio, silencios
  (arranque mudo, cortes de voz, música que termina antes), saturación, cuadros negros o congelados, largo de cada toma,
  nitidez cuadro por cuadro, posibles cambios de voz y, si está `faster-whisper`, la transcripción con el idioma. Deja en
  `<anuncio>/_director/` las tiras de cuadros con la onda del audio debajo (para ver si la boca se mueve cuando hay voz) y
  `examen.json`. No juzga: marca lo que hay que mirar. Necesita ffmpeg; Pillow, numpy y opencv si están.
- `sellar` escribe `boletin_director.json` en la carpeta del anuncio con la huella de sus videos e imágenes. El aprobado se
  rechaza si no alcanza la vara: promedio 9 o más, ninguna materia por debajo de 8, las 10 calificadas y ningún aplazo.
- `verificar` dice si hay aprobado vigente: si alguien cambió un video o una imagen después, vuelve al Director.
  `meta_campana.py preparar` lo exige para cada anuncio (falla cerrado).
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime

MATERIAS = (
    "modelado",              # se parece al ganador que modela: formato, escena, encuadre, luz, gancho, estructura
    "gancho_y_mensaje",      # primer segundo, nivel C1/C2/C3 correcto, el mensaje coincide con el producto y la web
    "idioma_y_texto",        # idioma nativo del mercado, texto sin deformar, ortografía, subtítulos legibles y a tiempo
    "imagen",                # nítida, sin pixelado, sin artefactos de IA, sin imágenes que se traslucen, buena luz
    "personas",              # manos y dedos completos, caras y ojos bien, misma persona en todas las tomas, labios a tiempo
    "voz",                   # una sola voz por narrador, nativa, natural, sin cortes, pareja, distinta en cada anuncio del set
    "musica_y_sonido",       # música hasta el último cuadro, por debajo de la voz, sin saturar, sin baches
    "edicion",               # habla desde el segundo 0, tomas de 4 s o menos, cortes limpios, cierre con el producto
    "formato",               # 9:16 en video, 1:1 o 4:5 en placa y carrusel, 1080 o más, texto fuera de las zonas tapadas
    "oferta_y_politicas",    # datos iguales a la ficha, nada inventado, aviso de IA, botón correcto, políticas de Meta
)
NOTA_MINIMA = 8.9  # Mat, 2026-10-31: se aprueba con 8,9 si no hay errores que note un cliente
MATERIA_MINIMA = 8.0
NOMBRE = "boletin_director.json"
CARPETA_EXAMEN = "_director"
VIDEOS = (".mp4", ".mov", ".m4v", ".webm")
IMAGENES = (".png", ".jpg", ".jpeg", ".webp")
MEDIOS = VIDEOS + IMAGENES

# Umbrales del examen técnico (marcan para mirar; el veredicto es del Director).
LADO_MINIMO = 1080
FPS_MINIMO = 24
SILENCIO_DB = -38
ARRANQUE_MUDO_S = 0.4
BACHE_S = 0.7
FINAL_MUDO_S = 0.8
TOMA_MAXIMA_S = 4.5
NITIDEZ_MINIMA = 60.0          # varianza del laplaciano en el cuadro llevado a 1080 de ancho
SALTO_DE_VOZ = 0.35            # diferencia relativa de tono mediano entre tramos de voz seguidos
PROPORCIONES = {"9:16": 9 / 16, "4:5": 4 / 5, "1:1": 1.0, "16:9": 16 / 9}


class ErrorDirector(Exception):
    pass


# ------------------------------------------------------------------ huella y boletín
def medios_de(anuncio):
    """Videos e imágenes de la carpeta del anuncio (sin `_director/`), ordenados por ruta relativa."""
    out = []
    for base, dirs, nombres in os.walk(anuncio):
        dirs[:] = [d for d in dirs if d != CARPETA_EXAMEN]
        for n in nombres:
            if n.lower().endswith(MEDIOS):
                out.append(os.path.join(base, n))
    return sorted(out, key=lambda r: os.path.relpath(r, anuncio).replace("\\", "/"))


def huella(anuncio):
    rutas = medios_de(anuncio)
    if not rutas:
        raise ErrorDirector("la carpeta %s no tiene videos ni imágenes: no hay nada que dirigir" % anuncio)
    h = hashlib.sha256()
    for r in rutas:
        h.update(os.path.relpath(r, anuncio).replace("\\", "/").encode("utf-8"))
        with open(r, "rb") as f:
            for bloque in iter(lambda: f.read(1 << 20), b""):
                h.update(bloque)
    return h.hexdigest()


def faltas_para_aprobar(nota, materias, aplazos):
    faltas = []
    if nota < NOTA_MINIMA:
        faltas.append("promedio %.1f: el aprobado empieza en %.0f" % (nota, NOTA_MINIMA))
    sin_nota = [m for m in MATERIAS if m not in materias]
    if sin_nota:
        faltas.append("materias sin calificar: %s" % ", ".join(sin_nota))
    bajas = ["%s (%s)" % (m, v) for m, v in materias.items() if m in MATERIAS and float(v) < MATERIA_MINIMA]
    if bajas:
        faltas.append("materias por debajo de %.0f: %s" % (MATERIA_MINIMA, ", ".join(bajas)))
    if aplazos:
        faltas.append("aplazos automáticos: %s" % "; ".join(aplazos))
    return faltas


def ruta_boletin(anuncio):
    return os.path.join(os.path.abspath(anuncio), NOMBRE)


def leer(anuncio):
    try:
        with open(ruta_boletin(anuncio), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def sellar(anuncio, nota, veredicto, materias, boletin, aplazos=(), ahora=None):
    if veredicto not in ("aprobado", "desaprobado"):
        raise ErrorDirector("veredicto: aprobado | desaprobado")
    if not os.path.isfile(boletin):
        raise ErrorDirector("falta el boletín escrito (%s): el Director siempre deja sus correcciones por escrito" % boletin)
    materias = {k: float(v) for k, v in (materias or {}).items()}
    nota = float(nota)
    if veredicto == "aprobado":
        faltas = faltas_para_aprobar(nota, materias, list(aplazos))
        if faltas:
            raise ErrorDirector("no se puede sellar aprobado: " + " | ".join(faltas))
    anterior = leer(anuncio) or {}
    datos = {
        "veredicto": veredicto,
        "nota": nota,
        "materias": materias,
        "aplazos": list(aplazos),
        "boletin": os.path.abspath(boletin),
        "medios": [os.path.relpath(r, anuncio).replace("\\", "/") for r in medios_de(anuncio)],
        "huella": huella(anuncio),
        "vuelta": int(anterior.get("vuelta", 0)) + 1,
        "fecha": (ahora or datetime.now()).isoformat(timespec="seconds"),
    }
    destino = ruta_boletin(anuncio)
    tmp = destino + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, destino)
    return datos


def verificar(anuncio):
    """→ (bool, motivo). Aprobado vigente = veredicto aprobado, vara cumplida y la misma huella que hoy."""
    b = leer(anuncio)
    nombre = os.path.basename(os.path.abspath(anuncio))
    if not b:
        return False, "%s: el Director de Videos no lo revisó (no hay %s)" % (nombre, NOMBRE)
    if b.get("veredicto") != "aprobado":
        return False, "%s: el Director lo desaprobó con %s (vuelta %s): corregir y volver a presentarlo" % (
            nombre, b.get("nota"), b.get("vuelta"))
    faltas = faltas_para_aprobar(float(b.get("nota", 0)), b.get("materias") or {}, b.get("aplazos") or [])
    if faltas:
        return False, "%s: el boletín no alcanza la vara: %s" % (nombre, " | ".join(faltas))
    try:
        actual = huella(anuncio)
    except ErrorDirector as e:
        return False, str(e)
    if b.get("huella") != actual:
        return False, "%s: el video o la imagen cambió después del aprobado: vuelve al Director" % nombre
    return True, "%s: aprobado por el Director con %s (vuelta %s)" % (nombre, b.get("nota"), b.get("vuelta"))


def carpetas_de_anuncios(anuncios):
    """Subcarpetas con videos o imágenes propios (cada una es un anuncio, reservas RES- incluidas)."""
    out = []
    for n in sorted(os.listdir(anuncios)):
        p = os.path.join(anuncios, n)
        if os.path.isdir(p) and n != CARPETA_EXAMEN and not n.startswith((".", "_")) and medios_de(p):
            out.append(p)
    return out


def verificar_todos(anuncios):
    """→ (bool, motivo). Todos los anuncios del producto con aprobado vigente."""
    if not os.path.isdir(anuncios):
        return False, "no existe la carpeta de anuncios %s" % anuncios
    carpetas = carpetas_de_anuncios(anuncios)
    if not carpetas:
        return False, "no hay anuncios con video o imagen en %s" % anuncios
    malos = [m for ok, m in (verificar(c) for c in carpetas) if not ok]
    if malos:
        return False, "Director de Videos: %d de %d sin aprobado — %s" % (len(malos), len(carpetas), "; ".join(malos[:4]))
    return True, "los %d anuncios tienen el aprobado del Director de Videos" % len(carpetas)


def exigir(anuncios):
    ok, motivo = verificar_todos(anuncios)
    if not ok:
        raise ErrorDirector(motivo)
    return motivo


# ------------------------------------------------------------------ examen técnico
def _correr(args, timeout=600):
    r = subprocess.run(args, capture_output=True, timeout=timeout)
    return r.returncode, r.stdout, r.stderr.decode("utf-8", "replace")


def _ffmpeg():
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise ErrorDirector("falta ffmpeg en el PATH: sin él no hay examen técnico del video")


def _sondeo(ruta):
    _ffmpeg()
    code, out, err = _correr(["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", ruta])
    if code != 0:
        raise ErrorDirector("ffprobe no pudo leer %s: %s" % (ruta, err.strip()[:200]))
    return json.loads(out.decode("utf-8", "replace"))


def _fps(txt):
    try:
        a, b = str(txt).split("/")
        return float(a) / float(b) if float(b) else 0.0
    except (ValueError, ZeroDivisionError):
        return 0.0


def _proporcion(w, h):
    r = w / float(h)
    nombre = min(PROPORCIONES, key=lambda k: abs(PROPORCIONES[k] - r))
    return nombre if abs(PROPORCIONES[nombre] - r) < 0.02 else "%.3f" % r


def _tramos(err, clave_ini, clave_fin):
    """Pares (inicio, fin) de las líneas de silencedetect / blackdetect / freezedetect."""
    out, ini = [], None
    for linea in err.splitlines():
        if clave_ini in linea:
            try:
                ini = float(linea.split(clave_ini)[1].split()[0].strip("|"))
            except (IndexError, ValueError):
                ini = None
        elif clave_fin in linea and ini is not None:
            try:
                out.append((ini, float(linea.split(clave_fin)[1].split()[0].strip("|"))))
            except (IndexError, ValueError):
                pass
            ini = None
    return out


def _pcm(ruta, tasa=16000):
    """Audio mono como numpy float32 en [-1, 1], o None."""
    try:
        import numpy as np
    except ImportError:
        return None
    code, out, _ = _correr(["ffmpeg", "-v", "error", "-i", ruta, "-vn", "-ac", "1", "-ar", str(tasa), "-f", "s16le", "-"])
    if code != 0 or not out:
        return None
    return np.frombuffer(out, dtype="<i2").astype("float32") / 32768.0


def _tono(x, tasa):
    """Tono fundamental (Hz) de una ventana por autocorrelación, o None si no es voz."""
    import numpy as np
    if len(x) < 32:   # ventana vacía al final del audio (AAC decodifica unos ms menos que la duración del contenedor)
        return None
    x = x - x.mean()
    if np.sqrt((x ** 2).mean()) < 0.01:
        return None
    c = np.correlate(x, x, "full")[len(x) - 1:]
    lo, hi = int(tasa / 400), int(tasa / 70)
    if hi >= len(c):
        return None
    k = lo + int(np.argmax(c[lo:hi]))
    return tasa / float(k) if c[k] > 0.3 * c[0] else None


def _cambios_de_voz(pcm, tasa, silencios, duracion):
    """Tramos de voz entre silencios con su tono mediano; marca saltos grandes entre tramos seguidos."""
    import numpy as np
    bordes, t = [], 0.0
    for a, b in silencios:
        if a - t > 0.6:
            bordes.append((t, a))
        t = b
    if duracion - t > 0.6:
        bordes.append((t, duracion))
    partidos = []   # con música de fondo casi no hay silencios: se compara de a 2 s
    for a, b in bordes:
        while b - a > 3.0:
            partidos.append((a, a + 2.0))
            a += 2.0
        partidos.append((a, b))
    bordes = partidos
    tramos = []
    for a, b in bordes:
        tonos = []
        for s in np.arange(a, b - 0.04, 0.04):
            i = int(s * tasa)
            v = _tono(pcm[i:i + int(0.04 * tasa)], tasa)
            if v:
                tonos.append(v)
        if len(tonos) >= 5:
            tramos.append({"desde": round(a, 2), "hasta": round(b, 2), "tono_hz": round(float(np.median(tonos)), 1)})
    saltos = []   # una voz sube y baja al hablar: solo cuenta un cambio que se sostiene (2 tramos antes contra 2 después)
    tonos = [t["tono_hz"] for t in tramos]
    for i in range(2, len(tonos) - 1):
        antes, despues = float(np.median(tonos[i - 2:i])), float(np.median(tonos[i:i + 2]))
        if abs(despues - antes) / max(antes, 1) > SALTO_DE_VOZ and (tramos[i]["hasta"] - tramos[i]["desde"]) >= 1.0:
            if not saltos or tramos[i]["desde"] - float(saltos[-1][0]) > 2.5:
                saltos.append((tramos[i]["desde"], antes, despues))
    return tramos, ["posible cambio de voz en %.1f s (%.0f Hz → %.0f Hz): escuchar" % s for s in saltos]


def _transcribir(ruta, idioma):
    """Segmentos con tiempos e idioma detectado si está faster-whisper; si no, None."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
    raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    modelo = WhisperModel(os.environ.get("HF_WHISPER", "small"), device="cpu", compute_type="int8",
                          download_root=os.path.join(raiz, ".modelos"))
    audio = _pcm(ruta, 16000)   # se decodifica con ffmpeg: el lector propio de faster-whisper choca con algunas versiones de PyAV
    if audio is None:
        raise ErrorDirector("no se pudo leer el audio para transcribir")
    segs, info = modelo.transcribe(audio, vad_filter=False)
    out = {"idioma_detectado": info.language, "confianza": round(info.language_probability, 2),
           "segmentos": [{"desde": round(s.start, 2), "hasta": round(s.end, 2), "texto": s.text.strip()} for s in segs]}
    if idioma and info.language != idioma:
        out["alerta"] = "la voz está en «%s» y el mercado es «%s»" % (info.language, idioma)
    return out


def _nitidez(img_bgr):
    import cv2
    h, w = img_bgr.shape[:2]
    if w != 1080:
        img_bgr = cv2.resize(img_bgr, (1080, max(1, int(h * 1080 / w))))
    return float(cv2.Laplacian(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY), cv2.CV_64F).var())


def _tiras(cuadros, energia, salida, nombre, por_tira=8, alto=480, sufijo="tira"):
    """Tiras de cuadros con el segundo y una barra de volumen debajo: se ve si la boca se mueve cuando hay voz.
    Las líneas rojas marcan las franjas que tapa la interfaz de Reels (arriba 14 %, abajo 20 %): ahí no va texto."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return []
    out = []
    for k in range(0, len(cuadros), por_tira):
        grupo = cuadros[k:k + por_tira]
        ims = [Image.open(p).convert("RGB") for _, p in grupo]
        ims = [im.resize((max(1, int(im.width * alto / im.height)), alto)) for im in ims]
        ancho = sum(im.width for im in ims) + 4 * (len(ims) + 1)
        hoja = Image.new("RGB", (ancho, alto + 70), (20, 20, 20))
        d = ImageDraw.Draw(hoja)
        x = 4
        for (t, _), im in zip(grupo, ims):
            hoja.paste(im, (x, 4))
            if im.height > im.width:   # vertical: zonas tapadas de Reels
                for y in (4 + int(alto * 0.14), 4 + int(alto * 0.80)):
                    for xx in range(x, x + im.width, 12):
                        d.line([xx, y, min(xx + 6, x + im.width), y], fill=(255, 40, 40), width=2)
            d.text((x + 6, 8), "%.1f s" % t, fill=(255, 235, 0))
            e = energia(t)
            d.rectangle([x, alto + 14, x + int((im.width - 2) * e), alto + 40], fill=(0, 200, 120) if e > 0.08 else (90, 90, 90))
            d.text((x + 4, alto + 46), "audio %.0f%%" % (e * 100), fill=(220, 220, 220))
            x += im.width + 4
        p = os.path.join(salida, "%s_%s_%02d.jpg" % (nombre, sufijo, k // por_tira + 1))
        hoja.save(p, quality=85)
        out.append(p)
    return out


def examinar_video(ruta, salida, idioma=None, paso=0.5):
    _ffmpeg()
    os.makedirs(salida, exist_ok=True)
    nombre = os.path.splitext(os.path.basename(ruta))[0]
    info = _sondeo(ruta)
    v = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in info.get("streams", []) if s.get("codec_type") == "audio"), None)
    if not v:
        raise ErrorDirector("%s no tiene imagen de video" % ruta)
    w, h = int(v.get("width", 0)), int(v.get("height", 0))
    dur = float(info.get("format", {}).get("duration") or v.get("duration") or 0)
    fps = _fps(v.get("avg_frame_rate") or v.get("r_frame_rate"))
    ex = {"archivo": ruta, "tipo": "video", "ancho": w, "alto": h, "proporcion": _proporcion(w, h), "fps": round(fps, 2),
          "duracion_s": round(dur, 2), "kbps": int(int(info.get("format", {}).get("bit_rate") or 0) / 1000),
          "audio": bool(a), "alertas": [], "mirar": []}
    if min(w, h) < LADO_MINIMO:
        ex["alertas"].append("resolución %dx%d: el lado menor tiene que ser %d o más (se ve pixelado)" % (w, h, LADO_MINIMO))
    if ex["proporcion"] not in ("9:16", "4:5", "1:1"):
        ex["alertas"].append("proporción %s: video de anuncio en 9:16 (o 4:5 / 1:1 para el feed)" % ex["proporcion"])
    if fps and fps < FPS_MINIMO:
        ex["alertas"].append("%.1f cuadros por segundo: se ve trabado (mínimo %d)" % (fps, FPS_MINIMO))
    if ex["kbps"] and ex["kbps"] < 1500 and min(w, h) >= LADO_MINIMO:
        ex["mirar"].append("bitrate bajo (%d kbps): mirar si hay bloques o pixelado en movimiento" % ex["kbps"])

    # audio: silencios, saturación
    if not a:
        ex["alertas"].append("no tiene audio: sin voz ni música")
    else:
        _, _, err = _correr(["ffmpeg", "-hide_banner", "-i", ruta, "-vn", "-af",
                             "silencedetect=noise=%ddB:d=0.3,volumedetect" % SILENCIO_DB, "-f", "null", "-"])
        sil = _tramos(err, "silence_start:", "silence_end:")
        if "silence_start:" in err.rsplit("silence_end:", 1)[-1]:   # silencio que llega hasta el final
            try:
                sil.append((float(err.rsplit("silence_start:", 1)[1].split()[0]), dur))
            except (IndexError, ValueError):
                pass
        ex["silencios"] = [(round(x, 2), round(y, 2)) for x, y in sil]
        for x, y in sil:
            if x <= 0.05 and y > ARRANQUE_MUDO_S:
                ex["alertas"].append("arranca mudo %.1f s: tiene que hablar desde el segundo 0" % y)
            elif y >= dur - 0.05 and dur - x > FINAL_MUDO_S:
                ex["alertas"].append("los últimos %.1f s no tienen sonido: la música tiene que llegar al último cuadro" % (dur - x))
            elif x > 0.05 and y - x > BACHE_S:
                ex["alertas"].append("bache de silencio de %.1f s en %.1f s: voz o música cortada" % (y - x, x))
        for linea in err.splitlines():
            if "max_volume:" in linea:
                try:
                    mx = float(linea.split("max_volume:")[1].split()[0])
                    ex["volumen_max_db"] = mx
                    if mx > -0.3:
                        ex["alertas"].append("audio saturado (pico %.1f dB): se escucha roto" % mx)
                except (IndexError, ValueError):
                    pass
            if "mean_volume:" in linea:
                try:
                    ex["volumen_medio_db"] = float(linea.split("mean_volume:")[1].split()[0])
                except (IndexError, ValueError):
                    pass
        if ex.get("volumen_medio_db") is not None and ex["volumen_medio_db"] < -30:
            ex["alertas"].append("volumen medio %.0f dB: se escucha muy bajo" % ex["volumen_medio_db"])

    # imagen: negros, congelados, cortes
    _, _, err = _correr(["ffmpeg", "-hide_banner", "-i", ruta, "-an", "-vf",
                         "blackdetect=d=0.1:pic_th=0.97,freezedetect=n=0.003:d=0.8", "-f", "null", "-"])
    for x, y in _tramos(err, "black_start:", "black_end:"):
        ex["alertas"].append("cuadro negro de %.1f a %.1f s" % (x, y))
    for linea in err.splitlines():
        if "freeze_start:" in linea:
            ex["mirar"].append("imagen quieta desde %s s: ¿congelado o plano fijo a propósito?" % linea.split("freeze_start:")[1].split()[0])
    _, _, err = _correr(["ffmpeg", "-hide_banner", "-i", ruta, "-an", "-vf", "select='gt(scene,0.30)',showinfo", "-f", "null", "-"])
    cortes = []
    for linea in err.splitlines():
        if "pts_time:" in linea:
            try:
                cortes.append(round(float(linea.split("pts_time:")[1].split()[0]), 2))
            except (IndexError, ValueError):
                pass
    ex["cortes_s"] = cortes
    bordes = [0.0] + cortes + [dur]
    tomas = [round(y - x, 2) for x, y in zip(bordes, bordes[1:]) if y - x > 0.05]
    ex["toma_mas_larga_s"] = max(tomas) if tomas else round(dur, 2)
    if ex["toma_mas_larga_s"] > TOMA_MAXIMA_S:
        ex["alertas"].append("una toma dura %.1f s: tomas de 4 s como máximo" % ex["toma_mas_larga_s"])

    # cuadros cada `paso` segundos, nitidez y tiras con la energía del audio
    dir_cuadros = os.path.join(salida, nombre + "_cuadros")
    os.makedirs(dir_cuadros, exist_ok=True)
    _correr(["ffmpeg", "-v", "error", "-y", "-i", ruta, "-vf", "fps=%s" % (1.0 / paso), "-q:v", "3",
             os.path.join(dir_cuadros, "c_%04d.jpg")])
    cuadros = sorted(os.listdir(dir_cuadros))
    cuadros = [(round(i * paso, 2), os.path.join(dir_cuadros, n)) for i, n in enumerate(cuadros)]
    try:
        import cv2
        borrosos = []
        for t, p in cuadros:
            img = cv2.imread(p)
            if img is not None:
                n = _nitidez(img)
                if n < NITIDEZ_MINIMA:
                    borrosos.append("%.1f s (%.0f)" % (t, n))
        if borrosos:
            ex["mirar"].append("cuadros poco nítidos (borroso o pixelado): " + ", ".join(borrosos[:12]))
    except ImportError:
        ex["mirar"].append("sin opencv: la nitidez se mira a ojo")

    tasa = 16000
    pcm = _pcm(ruta, tasa) if a else None
    if pcm is not None and len(pcm):
        import numpy as np
        rms_max = float(np.sqrt(np.mean(pcm ** 2)) * 4 or 1)

        def energia(t):
            i = int(t * tasa)
            trozo = pcm[i:i + int(paso * tasa)]
            return min(1.0, float(np.sqrt(np.mean(trozo ** 2))) / rms_max) if len(trozo) else 0.0
        tramos, saltos = _cambios_de_voz(pcm, tasa, ex.get("silencios", []), dur)
        ex["tramos_de_voz"] = tramos
        ex["mirar"].extend(saltos)
    else:
        def energia(t):
            return 0.0
    ex["tiras"] = _tiras(cuadros, energia, salida, nombre)
    # tiras finas cada 0,2 s para la boca: con 0,5 s no se ve si los labios siguen a la voz
    dir_finos = os.path.join(salida, nombre + "_cuadros_finos")
    os.makedirs(dir_finos, exist_ok=True)
    _correr(["ffmpeg", "-v", "error", "-y", "-i", ruta, "-vf", "fps=5,scale=-2:640", "-q:v", "4",
             os.path.join(dir_finos, "f_%04d.jpg")])
    finos = [(round(i * 0.2, 2), os.path.join(dir_finos, n)) for i, n in enumerate(sorted(os.listdir(dir_finos)))]
    ex["tiras_finas"] = _tiras(finos, energia, salida, nombre, por_tira=10, alto=360, sufijo="boca")

    if a:
        try:
            tr = _transcribir(ruta, idioma)
        except Exception as e:   # el modelo no bajó o no corre: el Director escucha a ojo… y lo dice
            tr = {"error": str(e)[:200]}
        if tr is None:
            ex["mirar"].append("sin faster-whisper: no hay transcripción; idioma y cortes de voz se controlan con el guion")
        else:
            ex["transcripcion"] = tr
            if tr.get("alerta"):
                ex["alertas"].append(tr["alerta"])
            segs = tr.get("segmentos") or []
            if segs and segs[0]["desde"] > ARRANQUE_MUDO_S + 0.2:
                ex["alertas"].append("la primera palabra llega en %.1f s: tiene que hablar desde el segundo 0" % segs[0]["desde"])
    return ex


def examinar_imagen(ruta):
    ex = {"archivo": ruta, "tipo": "imagen", "alertas": [], "mirar": []}
    try:
        from PIL import Image
        with Image.open(ruta) as im:
            w, h = im.size
    except ImportError:
        info = _sondeo(ruta)
        s = info["streams"][0]
        w, h = int(s["width"]), int(s["height"])
    ex.update({"ancho": w, "alto": h, "proporcion": _proporcion(w, h)})
    if min(w, h) < LADO_MINIMO:
        ex["alertas"].append("resolución %dx%d: el lado menor tiene que ser %d o más" % (w, h, LADO_MINIMO))
    if ex["proporcion"] not in ("1:1", "4:5", "9:16"):
        ex["alertas"].append("proporción %s: placa y carrusel en 1:1 o 4:5 (historia en 9:16)" % ex["proporcion"])
    try:
        import cv2
        import numpy as np
        img = cv2.imdecode(np.fromfile(ruta, dtype=np.uint8), cv2.IMREAD_COLOR)
        if img is not None:
            ex["nitidez"] = round(_nitidez(img), 1)
            if ex["nitidez"] < NITIDEZ_MINIMA:
                ex["mirar"].append("nitidez baja (%.0f): mirar si está borrosa o pixelada" % ex["nitidez"])
    except ImportError:
        ex["mirar"].append("sin opencv: la nitidez se mira a ojo")
    return ex


def examinar_anuncio(anuncio, idioma=None):
    salida = os.path.join(anuncio, CARPETA_EXAMEN)
    os.makedirs(salida, exist_ok=True)
    medios = medios_de(anuncio)
    if not medios:
        raise ErrorDirector("la carpeta %s no tiene videos ni imágenes" % anuncio)
    exs = [examinar_video(m, salida, idioma) if m.lower().endswith(VIDEOS) else examinar_imagen(m) for m in medios]
    imgs = [e for e in exs if e["tipo"] == "imagen"]
    general = []
    if len(imgs) > 1 and len({(e["ancho"], e["alto"]) for e in imgs}) > 1:
        general.append("carrusel con tarjetas de distinto tamaño: todas iguales")
    out = {"anuncio": os.path.basename(os.path.abspath(anuncio)), "fecha": datetime.now().isoformat(timespec="seconds"),
           "idioma": idioma, "medios": exs, "alertas_generales": general,
           "total_alertas": sum(len(e["alertas"]) for e in exs) + len(general)}
    with open(os.path.join(salida, "examen.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    return out


# ------------------------------------------------------------------ línea de comandos
def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("revisar")
    g = r.add_mutually_exclusive_group(required=True)
    g.add_argument("--anuncio")
    g.add_argument("--archivo")
    r.add_argument("--salida")
    r.add_argument("--idioma", help="código del idioma del mercado (es, it, ja, ar, he, sv, de…)")
    s = sub.add_parser("sellar")
    s.add_argument("--anuncio", required=True)
    s.add_argument("--nota", required=True, type=float)
    s.add_argument("--veredicto", required=True)
    s.add_argument("--materias", required=True, help="JSON {materia: nota}")
    s.add_argument("--boletin", required=True)
    s.add_argument("--aplazos", default="[]", help="JSON [texto]")
    v = sub.add_parser("verificar")
    gv = v.add_mutually_exclusive_group(required=True)
    gv.add_argument("--anuncio")
    gv.add_argument("--anuncios")
    a = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")   # la consola de Windows no imprime japonés, árabe ni flechas
    except (AttributeError, ValueError):
        pass
    try:
        if a.cmd == "revisar":
            if a.anuncio:
                d = examinar_anuncio(a.anuncio, a.idioma)
            else:
                salida = a.salida or os.path.join(os.path.dirname(os.path.abspath(a.archivo)), CARPETA_EXAMEN)
                d = examinar_video(a.archivo, salida, a.idioma) if a.archivo.lower().endswith(VIDEOS) else examinar_imagen(a.archivo)
            print(json.dumps(d, ensure_ascii=False, indent=2))
            return 0
        if a.cmd == "sellar":
            d = sellar(a.anuncio, a.nota, a.veredicto, json.loads(a.materias), a.boletin, json.loads(a.aplazos))
            print(json.dumps({"ok": True, "veredicto": d["veredicto"], "nota": d["nota"], "vuelta": d["vuelta"]}, ensure_ascii=False))
            return 0
        ok, motivo = verificar(a.anuncio) if a.anuncio else verificar_todos(a.anuncios)
        print(json.dumps({"ok": ok, "motivo": motivo}, ensure_ascii=False))
        return 0 if ok else 2
    except (ErrorDirector, ValueError) as e:
        print(json.dumps({"ok": False, "motivo": str(e)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())
