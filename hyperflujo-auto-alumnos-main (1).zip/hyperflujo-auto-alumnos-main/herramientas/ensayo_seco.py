#!/usr/bin/env python3
"""ensayo_seco.py — recorre días enteros con proveedores simulados y produce el informe (Hyperflujo, TAREA 035/036).

Todo es FICTICIO: productos OF-9xx de demostración, mediciones inventadas para la prueba (marcadas ficticio), topes y
autorizaciones de ensayo que NO son criterio de operación. Reglas: las reales de datos/reglas_operacion.json.
Hay estados esperados para cada día (1 a 8).

Dos lanzadores (TAREA 036 F):
  * --lanzador real (por defecto): el de producción. director.construir_lanzador + lanzar_worker.lanzar corren
    procesos de verdad contra pruebas/fakes/claude_falso.py (un `claude` falso: mismos flags, salida JSON, sin red ni
    consumo); verificar, pausar y releer la activación pasan por las herramientas sin modelo (hotmart_lector, sonda,
    meta_pausa) con transportes falsos; compuerta de anuncios (D103) activa. Corre sobre una
    copia temporal del repo (HYPERFLUJO_RAIZ), así que no ensucia el árbol.
  * --lanzador simulado: el doble del orquestador (lanzador_simulado), como en la TAREA 035.
CLI: python herramientas/ensayo_seco.py [--dias N] [--lanzador real|simulado] [--salida estado/informes/ensayo.md]
"""
import argparse
import json
import os
import shutil
import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import estado as E  # noqa: E402
import informe_diario  # noqa: E402
import orquestador  # noqa: E402

# Todo FICTICIO (solo ensayo, no operación). Revisión 035 h. 17: el ensayo usa la configuración real de reglas
# (datos/reglas_operacion.json) y solo inyecta topes, autorizaciones y campañas de demostración.
TOPES_FICTICIOS = {"tope_diario_global_usd": 100, "tope_mensual_global_usd": 3000, "max_productos_activos": 3,
                   "max_nuevos_por_dia": 6}
AUTORIZACIONES_FICTICIAS = ("publicar", "activar_campana", "escalar", "gasto_meta")
CAMPANA_FICTICIA = {"diario": 10, "diario_max": 20, "precio": 17}
# OF → {día: (gasto, ventas, netos)}; None = lectura caída. Las mediciones se cargan si el producto está activo.
GUION = {
    "OF-901": {5: (6, 1, 17), 6: (5, 2, 34), 7: (5, 1, 17)},       # vende con ROAS > 2 → escala a las 48 h
    "OF-902": {5: (12, 0, 0), 6: (3, 0, 0)},                     # 24 h sin ventas → D92b → en_baja → retirado
    "OF-903": {5: (None, None, None)},                           # lectura caída → pausa técnica (nulo ≠ 0)
    "OF-904": {},                                                # Hotmart no aprueba → queda en hotmart_enviado
    "OF-905": {},                                                # sesión de Hotmart vencida → bloqueada
}
_A = ["producido", "en_revision", "hotmart_enviado", "lista_para_activar", "activo"]
ESPERADO = {   # estado después de cada día 0..7 (invariantes del ensayo para cualquier --dias entre 1 y 8)
    "OF-901": _A + ["activo", "activo", "escalando"],
    "OF-902": _A + ["activo", "en_baja", "retirado"],
    "OF-903": _A + ["pausada_tecnica"] * 3,
    "OF-904": _A[:3] + ["hotmart_enviado"] * 5,
    "OF-905": _A[:2] + ["bloqueada_humano"] * 6,
}
# TAREA 037 B (solo con el lanzador real): OF-906 llega a lista_para_activar SIN campaña → crear_campana con el conector
# meta-ads falso del claude falso → campana_en_pausa verificada por relectura → activar.
GUION_REAL = dict(GUION, **{"OF-906": {6: (4, 1, 17), 7: (4, 1, 17)}})
ESPERADO_REAL = dict(ESPERADO, **{"OF-906": _A[:4] + ["campana_en_pausa"] + ["activo"] * 3})
MAX_DIAS = 8
RAIZ_REPO = Path(__file__).resolve().parents[1]
CLAUDE_FALSO = [sys.executable, str(RAIZ_REPO / "pruebas" / "fakes" / "claude_falso.py")]
GUION_CLAUDE = {"OF-905:publicar": {"modo": "fallo", "codigo": 3, "pendientes": [
    "Sesión de Hotmart vencida: iniciar sesión en el Chrome del robot (perfil en operacion/sesiones/) y esperar la próxima corrida."]}}



def _director_ficticio(anuncios):
    """El ensayo no tiene videos de verdad: una placa ficticia con el aprobado del Director (la vara real la prueba test_director_videos)."""
    import director_videos
    d = anuncios / "C1-DEMO"
    d.mkdir(parents=True, exist_ok=True)
    (d / "C1-DEMO.png").write_bytes(b"placa ficticia")
    (d / "boletin_director.md").write_text("BOLETÍN FICTICIO (ensayo)", encoding="utf-8")
    director_videos.sellar(str(d), 9.5, "aprobado", {m: 9.5 for m in director_videos.MATERIAS}, str(d / "boletin_director.md"))

def lanzador_ensayo(d):
    r = orquestador.lanzador_simulado(d)
    if d["of"] == "OF-904" and d["accion"] == "verificar":
        r["hotmart_aprobado"] = False
    if d["of"] == "OF-905" and d["accion"] == "publicar":
        r = {"ok": False, "codigo": 5, "motivo": "sesión de Hotmart vencida (simulado)", "consumo": 0}
    return r


def esperado(dias, real=False):
    tabla = ESPERADO_REAL if real else ESPERADO
    return {of: serie[dias - 1] for of, serie in tabla.items()} if 1 <= dias <= MAX_DIAS else None


def _campana_por_crear(of, rutas):
    """OF-906 (FICTICIO): todo lo que pide meta_campana.preparar, con IDs falsos y cifras de demostración."""
    rutas.escribir_json(rutas.ruta("datos", "cuentas.local.json"), {"_ficticio": True, "meta": {"cuentas": [{
        "ref": "CUENTA-ENSAYO", "id": "act_9001", "moneda": "USD", "pixel": "9002", "paginas": ["9003"], "campanas_max": 1,
        "limite_gasto": {"usd": 100, "fijado_por": "Dueño FICTICIO", "fecha": "2026-01-01"}}]}})
    rutas.escribir_json(rutas.ruta("datos", "autorizaciones.local.json"), {"_ficticio": True, "autorizaciones": [
        {"id": "AUT-ENSAYO", "alcance": "gasto_meta", "ofertas": "todas", "texto_literal": "ensayo FICTICIO",
         "firmante": "Dueño FICTICIO", "fecha": "2026-01-01", "vigente_hasta": None, "techo_usd": 50}]})
    base = "https://%s-portal.invalid/medios/" % of.lower()
    rutas.guardar_externo(of, netlify={"url": "https://%s.invalid/" % of.lower()}, medios={"base_url": base},
                          hotmart={"principal": {"codigo": "[CODIGO_PRODUCTO_%s]" % of, "checkout_url": "https://pay.invalid/%s?off=x" % of}})
    camp = "%s_es_CT333_2026-01-05" % of
    anuncios = []
    for nivel in ("C1", "C2", "C3"):
        for i in range(5):
            res = i >= 3
            final = "%s-es-%s-angulo%d-4x5" % (of.replace("-", ""), nivel, i)
            anuncios.append({"anuncio_id": ("RES-" if res else "") + final, "utm_content": final, "nivel": nivel, "reserva": res,
                             "texto_primario": "Texto de demostración (FICTICIO)", "titulo": "Título FICTICIO", "cta": "Más información",
                             "archivos": {"4x5": "%s_4x5.png" % final},
                             "url_con_utm": "https://%s.invalid/?utm_source=meta&utm_medium=paid&utm_campaign=%s&utm_content=%s"
                                            % (of.lower(), camp, final)})
    rutas.escribir_json(rutas.dir_oferta(of) / "campana" / "v001" / "plan_campana.json",
                        {"ficticio": True, "estructura": "cash_trap_333", "campana": {"nombre": camp},
                         "conjunto": {"nombre": camp + "_ADV"}, "anuncios": anuncios})
    ficha = rutas.ficha(of)
    ficha["campana"].update(cuenta_ref="CUENTA-ENSAYO", self_ai_disclosure="OPT_OUT",
                            segmentacion={"regiones": ["América del Sur"], "locales": [6, 23]})
    rutas.escribir_json(rutas.ruta_ficha(of), ficha)


# ------------------------------------------------------------------ dobles del ensayo real
class MetaEnsayo:
    """Graph falso: POST guarda el status; GET lo devuelve (la activación del worker falso deja la campaña ACTIVE)."""
    def __init__(self):
        self.objetos = {}

    def __call__(self, metodo, ruta, params=None, archivo=None):
        if metodo == "POST":
            self.objetos.setdefault(ruta, {}).update(params or {})
            return {"success": True}
        return {"status": self.objetos.get(ruta, {}).get("status", "ACTIVE"), "effective_status": "ACTIVE"}


class HotmartEnsayo:
    """Lector falso de Hotmart: todos aprobados salvo OF-904 (en revisión)."""
    def productos(self, producto_id=None):
        return {"items": [{"id": producto_id, "status": "IN_REVIEW" if "904" in str(producto_id) else "ACTIVE"}]}

    def ventas(self, *a):
        return {"items": []}


def _preparar_raiz():
    tmp = Path(tempfile.mkdtemp(prefix="hf_ensayo_real_"))
    for c in ("plantillas", "datos", "skills", "recetas"):
        shutil.copytree(RAIZ_REPO / c, tmp / c, ignore=shutil.ignore_patterns("*.local.*"))
    (tmp / "estado").mkdir()
    (tmp / "datos" / "config.local.json").write_text(json.dumps({
        "_ficticio": True, "zona": "UTC", "workers": {"permission_mode": "dontAsk", "facturacion": "suscripcion",
                                                      "max_budget_usd_por_worker": 1.0, "paralelo_max": 1, "timeout_min_defecto": 2},
        "modelos": {}}), encoding="utf-8")
    return tmp


def correr_real(dias=MAX_DIAS, salida=None, inicio=None):
    """El ensayo con el lanzador de producción contra el `claude` falso (procesos reales, sin red ni consumo)."""
    if not 1 <= dias <= MAX_DIAS:
        raise ValueError(f"--dias entre 1 y {MAX_DIAS}")
    import rutas
    raiz = _preparar_raiz()
    previos = {k: os.environ.get(k) for k in ("HYPERFLUJO_RAIZ", "HYPERFLUJO_AHORA", "HYPERFLUJO_FALSO_GUION", "HYPERFLUJO_FALSO_REGISTRO",
                                              "HYPERFLUJO_CORTE")}
    raiz_previa = rutas.RAIZ
    os.environ.update(HYPERFLUJO_RAIZ=str(raiz), HYPERFLUJO_CORTE="d92", HYPERFLUJO_FALSO_GUION=json.dumps(GUION_CLAUDE),
                      HYPERFLUJO_FALSO_REGISTRO=str(raiz / "estado" / "llamadas_claude.jsonl"))
    rutas.RAIZ = raiz
    try:
        import director
        import validar_anuncios
        archivo = str(raiz / "estado" / "productos.json")
        for of in GUION_REAL:
            E.alta(of, f"Producto de demostración {of} (ficticio)", archivo=archivo, ficticio=True)
            E.marcar(of, "campana", dict(CAMPANA_FICTICIA), archivo=archivo)
            if of in GUION:   # OF-906 llega sin campaña: la crea la etapa nueva (037 B)
                rutas.guardar_externo(of, meta={"campana": "[ID_CAMPANA_%s]" % of}, netlify={"url": "https://%s.invalid/" % of.lower()},
                                      hotmart={"principal": {"codigo": "[CODIGO_PRODUCTO_%s]" % of, "checkout_url": "https://pay.invalid/%s?off=x" % of}})
            rutas.escribir_json(rutas.ruta_ficha(of), {"id": of, "ficticio": True, "precio": {"lanzamiento": 17, "moneda": "USD"},
                                                       "campana": {"presupuesto": {"diario": 10, "dias": 5, "diario_max": 20,
                                                                                   "autorizado_por": "Dueño FICTICIO", "autorizacion_ref": "AUT-ENSAYO"}}})
            if of not in GUION:
                _campana_por_crear(of, rutas)
            anuncios = rutas.dir_oferta(of) / "anuncios"
            anuncios.mkdir(parents=True, exist_ok=True)
            (anuncios / "copy.json").write_text(json.dumps({"ficticio": True, "anuncios": [
                {"nombre": "%s-C%d" % (of, n), "texto": "Aprendé paso a paso (DEMOSTRACIÓN)", "incrustado": ""} for n in (1, 2, 3)]}), encoding="utf-8")
            validar_anuncios.validar_archivo(of)
            _director_ficticio(anuncios)
        config = json.loads((raiz / "datos" / "config.local.json").read_text(encoding="utf-8"))
        meta = MetaEnsayo()
        # E3: en el ensayo no hay sitio publicado de verdad; la compuerta simulada aprueba y lo dice (la real la prueba
        # pruebas/test_compuerta_sitio.py con un sitio sucio)
        man = director.manejadores_reales(lector_hotmart=HotmartEnsayo(), sondear=lambda u: 200, transporte_meta=meta,
                                          compuerta_sitio=lambda d: {"ok": True, "problemas": [], "nota": "ensayo: sitio simulado"})
        lanzador = director.construir_lanzador(config, TOPES_FICTICIOS, exe=CLAUDE_FALSO, manejadores=man)
        compuertas = director.compuertas_reales()
        informes = []
        inicio = inicio or date(2026, 1, 1)
        for d in range(dias):
            f = (inicio + timedelta(days=d)).isoformat()
            os.environ["HYPERFLUJO_AHORA"] = f + "T12:07:00+00:00"
            for of, serie in GUION_REAL.items():
                if d in serie and E.obtener(of, archivo)["estado"] in ("activo", "escalando"):
                    g, v, n = serie[d]
                    E.registrar_medicion(of, f, gasto=g, ventas=v, ingresos=n, archivo=archivo)
            res = orquestador.corrida_diaria(f, archivo=archivo, topes=TOPES_FICTICIOS, autorizaciones=AUTORIZACIONES_FICTICIAS,
                                             lanzador=lanzador, compuertas=compuertas)
            informes.append(informe_diario.generar(f, res, archivo=archivo, titulo="Ensayo seco con lanzador real (FICTICIO)"))
        texto = "\n\n---\n\n".join(informes)
        if salida:
            Path(salida).parent.mkdir(parents=True, exist_ok=True)
            Path(salida).write_text(texto, encoding="utf-8")
        llamadas = (raiz / "estado" / "llamadas_claude.jsonl")
        llamadas = [json.loads(x) for x in llamadas.read_text(encoding="utf-8").splitlines()] if llamadas.exists() else []
        trabajos = (raiz / "estado" / "trabajos.jsonl")
        trabajos = [json.loads(x) for x in trabajos.read_text(encoding="utf-8").splitlines()] if trabajos.exists() else []
        pausas = (raiz / "estado" / "pausas.jsonl")
        return {"archivo": archivo, "informe": texto, "estados": {p["of"]: p["estado"] for p in E.productos(archivo=archivo)},
                "workers": len(llamadas), "trabajos": len(trabajos),
                "modos_permiso": sorted({x["permission_mode"] for x in llamadas}),
                "api_key_heredada": any("ANTHROPIC_API_KEY" in x["env"] for x in llamadas),
                "pausas": len(pausas.read_text(encoding="utf-8").splitlines()) if pausas.exists() else 0}
    finally:
        rutas.RAIZ = raiz_previa
        for k, v in previos.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(raiz, ignore_errors=True)


def correr(dias=MAX_DIAS, archivo=None, salida=None, inicio=None):
    if not 1 <= dias <= MAX_DIAS:
        raise ValueError(f"--dias entre 1 y {MAX_DIAS} (el guion ficticio cubre {MAX_DIAS} días)")
    archivo = archivo or os.path.join(tempfile.mkdtemp(prefix="hf_ensayo_"), "productos.json")
    for of in GUION:
        E.alta(of, f"Producto de demostración {of} (ficticio)", archivo=archivo, ficticio=True)
        E.marcar(of, "campana", dict(CAMPANA_FICTICIA), archivo=archivo)
    inicio = inicio or date(2026, 1, 1)
    reloj_previo, corte_previo = os.environ.get("HYPERFLUJO_AHORA"), os.environ.get("HYPERFLUJO_CORTE")
    os.environ["HYPERFLUJO_CORTE"] = "d92"   # el guion ficticio de 8 días se escribió para el corte D92 (24/48 h)
    try:
        return _dias(dias, archivo, salida, inicio)
    finally:   # el reloj fijo del ensayo no se filtra al resto del proceso
        for k, v in (("HYPERFLUJO_AHORA", reloj_previo), ("HYPERFLUJO_CORTE", corte_previo)):
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def _dias(dias, archivo, salida, inicio):
    informes = []
    for d in range(dias):
        f = (inicio + timedelta(days=d)).isoformat()
        os.environ["HYPERFLUJO_AHORA"] = f + "T12:07:00"   # corrida principal de las 12:07 (OPERACION_DIARIA)
        for of, serie in GUION.items():
            if d in serie and E.obtener(of, archivo)["estado"] in ("activo", "escalando"):
                g, v, n = serie[d]
                E.registrar_medicion(of, f, gasto=g, ventas=v, ingresos=n, archivo=archivo)
        res = orquestador.corrida_diaria(f, archivo=archivo, topes=TOPES_FICTICIOS,
                                         autorizaciones=AUTORIZACIONES_FICTICIAS, lanzador=lanzador_ensayo)
        informes.append(informe_diario.generar(f, res, archivo=archivo, titulo="Ensayo seco (FICTICIO)"))
    texto = "\n\n---\n\n".join(informes)
    if salida:
        Path(salida).parent.mkdir(parents=True, exist_ok=True)
        Path(salida).write_text(texto, encoding="utf-8")
    return {"archivo": archivo, "informe": texto, "estados": {p["of"]: p["estado"] for p in E.productos(archivo=archivo)}}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Ensayo seco del núcleo con productos FICTICIOS (consumo cero).")
    ap.add_argument("--dias", type=int, default=MAX_DIAS)
    ap.add_argument("--lanzador", choices=("real", "simulado"), default="real",
                    help="real: lanzador de producción contra un claude falso (por defecto); simulado: el doble de 035")
    ap.add_argument("--salida")
    a = ap.parse_args()
    r = correr_real(a.dias, salida=a.salida) if a.lanzador == "real" else correr(a.dias, salida=a.salida)
    print(r["estados"])
    if a.lanzador == "real":
        print("workers lanzados: %d | trabajos registrados: %d | modo de permisos: %s | ANTHROPIC_API_KEY heredada: %s | pausas por Graph falso: %d"
              % (r["workers"], r["trabajos"], ",".join(r["modos_permiso"]) or "-", "sí" if r["api_key_heredada"] else "no", r["pausas"]))
    # Contrato de CLI: la última línea es JSON.
    esp = esperado(a.dias, real=a.lanzador == "real")
    ok = esp is not None and r["estados"] == esp and "Consumo pago de esta corrida: 0" in r["informe"]
    if a.lanzador == "real":
        ok = ok and not r["api_key_heredada"]
    print(json.dumps({"ok": ok, "codigo": 0 if ok else 2,
                      "motivo": "ensayo completo (lanzador %s)" % a.lanzador if ok else "estados finales distintos de los esperados",
                      "artefactos": [a.salida] if a.salida else []}, ensure_ascii=False))
    sys.exit(0 if ok else 2)
