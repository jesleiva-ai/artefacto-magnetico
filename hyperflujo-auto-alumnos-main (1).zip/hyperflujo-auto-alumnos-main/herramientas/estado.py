#!/usr/bin/env python3
"""estado.py — base local de productos de hyperflujo-auto (módulo núcleo, Hyperflujo TAREA 035).

Archivo JSON (estado/productos.json por defecto; se puede pasar otro con archivo=). Escritura atómica.
Ciclo de vida de un producto:
    [por_cazar →] candidato → producido → en_revision → hotmart_enviado → lista_para_activar → [campana_en_pausa] → activo → escalando
    → en_baja → retirado
    (+ rechazo_meta, pausada_tecnica, bloqueada_humano, fallida: revisión adversarial 035, hallazgos 4, 10 y 11)
    TAREA 037 B: lista_para_activar sin campaña → crear_campana → campana_en_pausa (verificada por relectura) → activar;
    con campaña ya registrada (importada) → activar directo.
Reglas: medición desconocida = None (nulo), nunca 0 (regla 8 del taller). Toda transición queda en el historial.
Solo biblioteca estándar.
"""
import json
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path

ESTADOS = ["por_cazar", "candidato", "producido", "en_revision", "hotmart_enviado", "lista_para_activar", "campana_en_pausa", "activo", "escalando",
           "rechazo_meta", "pausada_tecnica", "en_baja", "retirado", "bloqueada_humano", "fallida"]
_SALIDAS = {"retirado", "bloqueada_humano"}
TRANSICIONES = {
    "por_cazar": {"candidato", "fallida"} | _SALIDAS,                   # TAREA 037 A: caza verificada por artefacto
    "candidato": {"producido", "por_cazar", "fallida"} | _SALIDAS,      # 037 A: el dueño veta la caza entera → se recaza
    "producido": {"en_revision", "fallida"} | _SALIDAS,
    "en_revision": {"hotmart_enviado", "producido", "fallida"} | _SALIDAS,   # rechazo de revisión → vuelve a producido
    "hotmart_enviado": {"lista_para_activar", "fallida"} | _SALIDAS,   # espera Hotmart (035 h. 4)
    "lista_para_activar": {"activo", "campana_en_pausa", "fallida"} | _SALIDAS,   # Hotmart aprobado + landing y checkout 200
    "campana_en_pausa": {"activo", "fallida"} | _SALIDAS,   # TAREA 037 B: creada y releída en PAUSED
    "activo": {"escalando", "en_baja", "pausada_tecnica", "rechazo_meta"} | _SALIDAS,
    "escalando": {"activo", "en_baja", "pausada_tecnica", "rechazo_meta"} | _SALIDAS,
    "rechazo_meta": {"lista_para_activar", "en_baja"} | _SALIDAS,         # repuesto desde RES- → vuelve a revisión de activación
    "pausada_tecnica": {"lista_para_activar", "en_baja"} | _SALIDAS,      # reactivar exige autorización «reactivar»
    "en_baja": {"lista_para_activar"} | _SALIDAS,                         # reactivar exige autorización «reactivar»
    "bloqueada_humano": {"por_cazar", "candidato", "producido", "en_revision", "hotmart_enviado", "lista_para_activar", "campana_en_pausa", "en_baja",
                         "retirado", "pausada_tecnica"},   # 036: el vigía reintenta la pausa no confirmada
    "fallida": {"por_cazar", "candidato", "retirado"},
    "retirado": set(),
}
ACTIVOS = ("activo", "escalando")


class TransicionInvalida(ValueError):
    pass


def _raiz():
    return Path(os.environ.get("HYPERFLUJO_RAIZ") or Path(__file__).resolve().parents[1])


def archivo_defecto():
    return _raiz() / "estado" / "productos.json"


def _ahora():
    """Hora con zona del dueño vía rutas.ahora() (PLAN §2: respeta HYPERFLUJO_AHORA en pruebas y ensayo)."""
    try:
        import rutas
        return rutas.ahora().isoformat(timespec="seconds")
    except Exception:  # rutas ilegible o config rota: hora local, nunca se corta la escritura del estado
        return datetime.now().astimezone().isoformat(timespec="seconds")


def cargar(archivo=None):
    p = Path(archivo or archivo_defecto())
    if not p.exists():
        return {"version": 1, "productos": {}}
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def guardar(base, archivo=None):
    p = Path(archivo or archivo_defecto())
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(base, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def alta(of, nombre, archivo=None, ficticio=False, estado_inicial="candidato"):
    """estado_inicial: «candidato» (alta directa, ensayo) o «por_cazar» (el director abre un producto nuevo: TAREA 037 A)."""
    if estado_inicial not in ("candidato", "por_cazar"):
        raise ValueError("estado inicial inválido: %s" % estado_inicial)
    base = cargar(archivo)
    if of in base["productos"]:
        raise ValueError(f"{of} ya existe")
    base["productos"][of] = {"of": of, "nombre": nombre, "estado": estado_inicial, "ficticio": bool(ficticio),
                             "creado": _ahora(), "historial": [], "mediciones": {}, "intentos": {}}
    guardar(base, archivo)
    return base["productos"][of]


def obtener(of, archivo=None):
    p = cargar(archivo)["productos"].get(of)
    if p is None:
        raise KeyError(of)
    return p


def productos(estado=None, archivo=None):
    ps = list(cargar(archivo)["productos"].values())
    return [p for p in ps if estado is None or p["estado"] == estado]


def transicionar(of, nuevo, motivo, archivo=None, datos=None):
    if nuevo not in ESTADOS:
        raise TransicionInvalida(f"estado desconocido: {nuevo}")
    base = cargar(archivo)
    p = base["productos"][of]
    if nuevo not in TRANSICIONES[p["estado"]]:
        raise TransicionInvalida(f"{of}: {p['estado']} → {nuevo} no permitida")
    h = {"de": p["estado"], "a": nuevo, "motivo": motivo, "hora": _ahora()}
    if datos:
        h["datos"] = datos
    p["historial"].append(h)
    p["estado"] = nuevo
    if nuevo == "bloqueada_humano":
        p["bloqueo"] = {"desde": h["de"], "motivo": motivo, **(datos or {})}
    elif "bloqueo" in p:
        p.pop("bloqueo")
    guardar(base, archivo)
    return p


def registrar_medicion(of, fecha, gasto=None, ventas=None, ingresos=None, clics=None, rechazados=None, archivo=None):
    """Upsert por fecha. None = desconocido (nunca se convierte en 0).

    Además: `primera_entrega_en` = hora de la primera lectura con gasto > 0 (arranque del reloj D92, revisión 035 h. 10;
    es conservador: nunca antes de la entrega real) y `ultima_lectura_en` = hora de la última lectura completa
    (gasto, ventas e ingresos conocidos), que usa la pausa técnica por lectura caída (h. 3)."""
    base = cargar(archivo)
    p = base["productos"][of]
    m = p["mediciones"].setdefault(fecha, {})
    for k, v in (("gasto", gasto), ("ventas", ventas), ("ingresos", ingresos), ("clics", clics), ("rechazados", rechazados)):
        if v is not None or k not in m:
            m[k] = v
    hora = _ahora()
    if m.get("gasto") is not None and m["gasto"] > 0 and not p.get("primera_entrega_en"):
        p["primera_entrega_en"] = hora
    if all(m.get(k) is not None for k in ("gasto", "ventas", "ingresos")):
        p["ultima_lectura_en"] = hora
    guardar(base, archivo)
    return m


def marcar(of, campo, valor, archivo=None):
    """Guarda un dato operativo del producto (ultima_subida, ultimo_cambio_anuncios, campana...)."""
    base = cargar(archivo)
    base["productos"][of][campo] = valor
    guardar(base, archivo)
    return base["productos"][of]


def registrar_fallo(of, etapa, motivo, codigo=None, archivo=None):
    """Fallos acumulados por etapa ENTRE días (revisión 035 h. 11); se reinician cuando la etapa sale bien."""
    base = cargar(archivo)
    p = base["productos"][of]
    f = p.setdefault("fallos", {}).setdefault(etapa, {"n": 0})
    f.update(n=f["n"] + 1, ultimo_motivo=motivo, codigo=codigo, hora=_ahora())
    guardar(base, archivo)
    return f["n"]


def reiniciar_fallos(of, etapa, archivo=None):
    base = cargar(archivo)
    base["productos"][of].setdefault("fallos", {}).pop(etapa, None)
    guardar(base, archivo)


def sumar_intento(of, etapa, fecha, archivo=None):
    base = cargar(archivo)
    p = base["productos"][of]
    clave = f"{fecha}:{etapa}"
    p["intentos"][clave] = p["intentos"].get(clave, 0) + 1
    guardar(base, archivo)
    return p["intentos"][clave]


def acumulado(producto):
    """Totales estrictos (revisión 035 h. 3): si CUALQUIER medición de la ventana tiene el campo en None, el total es
    None. Un 0 temprano seguido de lecturas nulas no se convierte en «0 ventas». Sin mediciones: None."""
    tot = {}
    ms = list(producto["mediciones"].values())
    for k in ("gasto", "ventas", "ingresos", "clics"):
        vals = [m.get(k) for m in ms]
        tot[k] = None if (not vals or any(v is None for v in vals)) else sum(vals)
    tot["rechazados"] = sum(m.get("rechazados") or 0 for m in ms)
    return tot


if __name__ == "__main__":
    for p in productos():
        print(p["of"], p["estado"], p["nombre"])
    if not productos():
        print("(sin productos)", file=sys.stderr)
