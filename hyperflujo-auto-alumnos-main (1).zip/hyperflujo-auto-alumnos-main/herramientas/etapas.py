#!/usr/bin/env python3
"""etapas.py — qué hace cada acción del director y con qué permisos corre su worker (TAREA 036 parte A).

Cada acción de orquestador.decidir tiene un ejecutor:
  * "python": la ejecuta el director sin modelo (lecturas, pausas). Decide el código (CLAUDE.md regla 3).
  * "worker": un `claude -p` con la skill de la etapa, allowlist propia y deny duro. El worker produce o ejecuta lo que
    está en el plan; nunca cambia el estado (lo cambia el director verificando artefactos).
Las listas `allowed` nunca incluyen escrituras de Meta que gasten (ads_create_*, ads_activate_entity, ads_update_entity):
siguen en deny en .claude/settings.json hasta que el dueño decida pasarlas al guardián (docs/LIMITES.md).
Solo biblioteca estándar.
"""
LECTURAS_META = ["mcp__meta-ads__ads_get_ad_entities", "mcp__meta-ads__ads_get_creatives", "mcp__meta-ads__ads_get_ad_preview",
                 "mcp__meta-ads__ads_get_errors", "mcp__meta-ads__ads_get_ad_accounts", "mcp__meta-ads__ads_library_search"]
BASE_ALLOWED = ["Read", "Glob", "Grep", "Edit(ofertas/**)", "Write(ofertas/**)", "Bash(python herramientas/*)",
                "Bash(py -3 herramientas/*)", "Bash(git status *)", "Bash(git diff *)"]
# Recorte duro adicional de cada worker (vale aunque settings.json cambie): nada que gaste, active o publique.
BASE_DISALLOWED = ["mcp__meta-ads__ads_create_*", "mcp__meta-ads__ads_activate_entity", "mcp__meta-ads__ads_update_entity",
                   "mcp__meta-ads__ads_creative_*", "mcp__higgsfield__generate_*", "mcp__Hotmart__*", "mcp__hotmart__*",
                   "mcp__claude-in-chrome__*", "mcp__computer-use__*", "mcp__Claude_Browser__*", "mcp__terminal__*",
                   "WebFetch", "Bash(curl *)", "Bash(git push *)", "Bash(rm -rf *)",
                   # revisión 036 h. 1: un worker no escribe código propio ni toca estado/ (plan, freno, topes)
                   "Write(ofertas/**/*.py)", "Write(ofertas/**/*.mjs)", "Write(ofertas/**/*.js)", "Edit(ofertas/**/*.py)",
                   "Write(estado/**)", "Edit(estado/**)", "Write(herramientas/**)", "Edit(herramientas/**)"]

ETAPAS = {
    # TAREA 037 A: la caza lee la Biblioteca pública con el robot anónimo (Chrome sin sesión); nada de MCP ni navegadores
    # del dueño. El worker juzga lo que el código no ve (marca personal, digital, qué vende) en revision.json.
    "cazar": {"ejecutor": "worker", "skill": "skills/cazar-oferta/SKILL.md", "rol": "produce", "timeout_min": 90,
              "allowed": BASE_ALLOWED + ["Bash(node herramientas/cazar_biblioteca.mjs *)"]},
    "producir": {"ejecutor": "worker", "skill": "skills/producir-producto/SKILL.md", "rol": "produce", "timeout_min": 120,
                 "allowed": BASE_ALLOWED + ["mcp__meta-ads__ads_library_search", "Bash(node herramientas/*)"]},
    "revisar": {"ejecutor": "worker", "skill": "skills/landing/SKILL.md", "rol": "revisa", "timeout_min": 45,
                "allowed": BASE_ALLOWED},
    "publicar": {"ejecutor": "worker", "skill": "skills/hotmart-robot/SKILL.md", "rol": "revisa", "timeout_min": 60,
                 "allowed": BASE_ALLOWED + ["Bash(node herramientas/hotmart_alta.mjs *)"]},
    "escalar": {"ejecutor": "worker", "skill": "skills/meta-operacion-diaria/SKILL.md", "rol": "revisa", "timeout_min": 20,
                "allowed": BASE_ALLOWED + LECTURAS_META},
    "reemplazar": {"ejecutor": "worker", "skill": "skills/meta-operacion-diaria/SKILL.md", "rol": "revisa", "timeout_min": 20,
                   "allowed": BASE_ALLOWED + LECTURAS_META},
    "reponer": {"ejecutor": "worker", "skill": "skills/diagnostico-y-baja/SKILL.md", "rol": "revisa", "timeout_min": 30,
                "allowed": BASE_ALLOWED + LECTURAS_META},
    "activar": {"ejecutor": "worker", "skill": "skills/meta-campana-cashtrap/SKILL.md", "rol": "mecanico", "timeout_min": 15,
                "allowed": BASE_ALLOWED + LECTURAS_META},
    # TAREA 037 B: creación en pausa. Ejecuta, una por una, las llamadas que armó meta_campana.preparar (director); solo
    # las ads_create_*/ads_creative_upload_media de plan.TICKETS["crear_campana"], con ticket. Nunca activa.
    "crear_campana": {"ejecutor": "worker", "skill": "skills/meta-campana-cashtrap/SKILL.md", "rol": "mecanico", "timeout_min": 45,
                      "allowed": BASE_ALLOWED + LECTURAS_META + ["mcp__meta-ads__ads_get_creatives"]},
    # Sin modelo (los conecta el director; parte B):
    "verificar": {"ejecutor": "python"},
    "bajar": {"ejecutor": "python"},
    "pausa_tecnica": {"ejecutor": "python"},
}


# Si una etapa necesita una herramienta que cae bajo un patrón del recorte duro (p. ej. ads_create_* para
# crear_campana), se saca el patrón y se niegan una por una las demás herramientas que ese patrón cubría.
CUBIERTAS_POR_PATRON = {
    "mcp__meta-ads__ads_create_*": ["mcp__meta-ads__ads_create_custom_audience"],
    "mcp__meta-ads__ads_creative_*": ["mcp__meta-ads__ads_creative_update", "mcp__meta-ads__ads_creative_delete"],
}


def definicion(accion):
    """D99: la etapa que gasta suma a `allowed` sus herramientas del plan (plan.TICKETS) y las saca del recorte duro;
    igual las niega el hook guardian_gasto salvo ticket vigente del director para ese producto."""
    import fnmatch
    import plan
    if accion not in ETAPAS:
        raise KeyError("acción sin etapa definida: %s" % accion)
    d = dict(ETAPAS[accion])
    if d["ejecutor"] == "worker":
        propias = [t[0] for t in plan.TICKETS.get(accion, [])]
        if accion in plan.ETAPAS_CON_MEDIOS:   # imágenes y voces: también con ticket (medios.emitir), nunca sin él
            propias += [t[0] for t in plan.TICKETS["medios"]]
        d["allowed"] = list(d.get("allowed", [])) + propias
        dis = []
        for x in BASE_DISALLOWED:
            if x in propias:
                continue
            if any(fnmatch.fnmatchcase(p, x) for p in propias):
                dis += [y for y in CUBIERTAS_POR_PATRON.get(x, []) if y not in propias]
                continue
            dis.append(x)
        d.setdefault("disallowed", dis)
    return d


def herramientas_worker(accion):
    d = definicion(accion)
    return list(d.get("allowed", [])), list(d.get("disallowed", []))
