#!/usr/bin/env python3
"""firmar.py — la persona firma, en SU terminal, lo que el sistema puede hacer sin volver a preguntar (TAREA 041 Parte 0).

    python herramientas/firmar.py dueno            # nombre exacto de quien firma e identificación del vendedor
    python herramientas/firmar.py topes            # topes de gasto (diario, mensual, por proveedor, por producto)
    python herramientas/firmar.py autorizaciones   # autorizaciones escritas para TODOS los productos, con techo y vigencia
    python herramientas/firmar.py checkout         # checkout abierto desde el país del mercado (VPN): precio y moneda vistos
    python herramientas/firmar.py medios           # «¿Cómo querés el gasto en imágenes y voces?» (mínimo, personalizado, libre)
    python herramientas/firmar.py todo
    python herramientas/firmar.py todo --recomendado   # mínimo recomendado en todo lo que falta: solo nombre y «firmo»

Es el único paso del onboarding que escribe datos/dueno|topes|autorizaciones.local.json, y solo corre en una terminal
interactiva: desde Claude (sin terminal) se niega, para que ningún modelo firme por el dueño (CLAUDE.md reglas 4 y 15).
Muestra el valor actual de cada campo (Enter lo deja), propone el texto literal de cada autorización (Enter lo acepta,
o se escribe otro), pide el nombre exacto de quien firma (tiene que estar en datos/dueno.local.json) y la palabra
«firmo». No borra autorizaciones existentes: agrega las nuevas con id AUT-NNN siguiente. Solo biblioteca estándar.
"""
import argparse
import datetime
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

VIGENCIA_DIAS = 90

# alcance → (texto propuesto, condiciones del ejemplo, techo: None | clave de topes que lo sugiere)
AUTORIZACIONES = (
    ("elegir_candidato", "Autorizo que el sistema elija por mí el mejor candidato validado de la caza, sin esperar mi "
     "confirmación en estado/decisiones.jsonl; puedo vetarlo después.", [], None),
    ("publicar", "Autorizo publicar en Netlify la landing y el portal de cada producto que el sistema produzca, si sus "
     "validadores están en verde.", ["validadores_en_verde"], None),
    ("finalizar_registro", "Autorizo que el robot finalice el registro en Hotmart de cada producto, después de la prueba "
     "en seco.", ["seca_ok"], None),
    ("activar_embudo", "Autorizo activar en Hotmart las ofertas de la escalera (bumps, upsell y downsells) de cada producto.",
     [], None),
    ("activar_campana", "Autorizo activar la campaña de Meta de cada producto cuando Hotmart lo aprobó, el checkout está "
     "verificado, la landing publicada, el embudo cableado y los topes leídos.",
     ["hotmart_aprobado", "checkout_verificado", "produccion_publicada", "embudo_cableado", "topes_leidos_ok"], None),
    ("gasto_meta", "Autorizo gastar en Meta Ads hasta el techo por producto, dentro del tope diario global.", [],
     "meta"),
    ("gasto_medios", "Autorizo gastar en Higgsfield y ElevenLabs hasta el techo por producto para los creativos.", [],
     "medios"),
    ("gasto_anthropic", "Autorizo gastar en Claude por API hasta el techo por producto para los workers.", [],
     "anthropic"),
)
OPCIONALES = (
    ("escalar", "Autorizo subir el presupuesto de una campaña un 30 % cuando el ROAS neto es 2 o más, con 48 h entre "
     "subidas (reglas de Matías), dentro de los topes.", [], None),
)

# Mínimo recomendado (Ramiro, TAREA 041: «poné lo recomendado mínimo, después lo elige el usuario final»). Solo llena lo que
# falta; lo que ya está firmado se respeta. Meta: 20 × 5 = spend_cap de USD 100, el mínimo que exige Meta por campaña
# (meta_ads.py MIN_SPEND_CAP_CAMPANA_USD); Matías arranca con 50 o 75 por día (cash-trap-cbo-oro/SKILL.md:35) cuando
# hay caja. Higgsfield: la corrida 1 usó 132,5 créditos por producto (docs/OPERACION_DIARIA.md §1c).
RECOMENDADO = {
    "tope_diario_global_usd": 40, "tope_mensual_global_usd": 300, "max_productos_activos": 1, "max_nuevos_por_dia": 1,
    "por_producto_defecto.meta.diario": 20, "por_producto_defecto.meta.dias": 5,
    "por_producto_defecto.higgsfield.tope": 150, "por_producto_defecto.elevenlabs.tope": 5,
    "por_producto_defecto.anthropic.tope": 5, "por_proveedor_dia.higgsfield.tope": 150,
    "por_proveedor_dia.elevenlabs.tope": 5, "por_proveedor_dia.anthropic.tope": 10,
    "workers.max_budget_usd_por_worker": 2,
}

CAMPOS_TOPES = (
    ("tope_diario_global_usd", "Tope diario global, todo junto (USD)", float),
    ("tope_mensual_global_usd", "Tope mensual global (USD)", float),
    ("max_productos_activos", "Máximo de productos con campaña activa a la vez", int),
    ("max_nuevos_por_dia", "Productos nuevos por día", int),
    ("por_producto_defecto.meta.diario", "Meta: presupuesto diario por producto (USD; Matías arranca con 50 o 75)", float),
    ("por_producto_defecto.meta.dias", "Meta: días de ese diario (spend_cap = diario × días)", int),
    ("por_producto_defecto.anthropic.tope", "Claude por API: USD por producto (0 si usás el plan)", float),
    ("por_proveedor_dia.anthropic.tope", "Claude por API: USD por día, todo junto (0 si usás el plan)", float),
)
# Higgsfield y ElevenLabs no se preguntan número por número: una sola pregunta (Ramiro vía Director_H1, 2026-10-28).
PREGUNTA_MEDIOS = ("¿Cómo querés el gasto en imágenes y voces? mínimo (150 créditos de Higgsfield y 5 USD de ElevenLabs "
                   "por producto) / personalizado (ponés los números) / libre (gasta lo razonable, con techos por producto, "
                   "día y mes que podés cambiar)")
CAMPOS_MEDIOS = (("producto", "por producto"), ("dia", "por día, todo junto"), ("mes", "por mes, todo junto"))


class NoInteractivo(SystemExit):
    pass


def _get(d, ruta):
    for k in ruta.split("."):
        d = d.get(k) if isinstance(d, dict) else None
    return d


def _set(d, ruta, v):
    ks = ruta.split(".")
    for k in ks[:-1]:
        d = d.setdefault(k, {})
    d[ks[-1]] = v


def _cargar(nombre):
    p = rutas.ruta("datos", "%s.local.json" % nombre)
    if p.exists():
        return rutas.leer_json(p)
    ej = rutas.ruta("datos", "%s.ejemplo.json" % nombre)
    return rutas.leer_json(ej) if ej.exists() else {}


def _guardar(nombre, d):
    rutas.escribir_json(rutas.ruta("datos", "%s.local.json" % nombre), d)
    return "datos/%s.local.json" % nombre


def _vacio(v):
    return v is None or (isinstance(v, str) and (not v.strip() or v.startswith(("[", "<"))))


class Firma:
    def __init__(self, preguntar=input, decir=print, recomendado=False):
        self.preguntar, self.decir, self.auto = preguntar, decir, recomendado

    def pedir(self, texto, actual=None, tipo=str, obligatorio=True, recomendado=None, siempre=False):
        """Enter deja el actual o, si falta, el recomendado. Con --recomendado no pregunta lo que tiene valor
        (salvo `siempre`: el nombre y la palabra «firmo» los escribe siempre la persona)."""
        fuente = "actual" if not _vacio(actual) else "recomendado"
        if _vacio(actual) and recomendado is not None:
            actual = recomendado
        if self.auto and not siempre and not _vacio(actual):
            self.decir("  %s: %s (%s)" % (texto, actual, fuente))
            return actual
        while True:
            r = self.preguntar("%s%s: " % (texto, "" if _vacio(actual) else " [%s]" % actual)).strip()
            if not r and not _vacio(actual):
                return actual
            if not r and not obligatorio:
                return None
            if not r:
                continue
            try:
                v = tipo(r.replace(",", ".")) if tipo in (int, float) else r
            except ValueError:
                self.decir("  número, por favor")
                continue
            if tipo in (int, float) and v < 0:
                self.decir("  no puede ser negativo")
                continue
            return v

    def firmante(self, duenos):
        nombres = [x.get("nombre") for x in duenos.get("duenos") or [] if not _vacio(x.get("nombre"))]
        if not nombres:
            raise SystemExit("Primero: python herramientas/firmar.py dueno")
        while True:
            n = self.pedir("Tu nombre exacto para firmar (%s)" % " | ".join(nombres), siempre=True)
            if n in nombres:
                return n
            self.decir("  tiene que ser igual, letra por letra, a un nombre de datos/dueno.local.json")

    def confirmar(self):
        return self.pedir("Escribí «firmo» para guardar (otra cosa cancela)", obligatorio=False, siempre=True) == "firmo"

    # ---------------------------------------------------------- secciones
    def dueno(self):
        d = _cargar("dueno")
        duenos = d.get("duenos") or [{}]
        actual = duenos[0].get("nombre")
        nombre = self.pedir("Nombre exacto de quien firma las autorizaciones", actual)
        duenos[0]["nombre"] = nombre
        duenos[0].setdefault("puede", ["gasto", "publicar", "finalizar_registro", "activar", "escalar", "reactivar",
                                       "topes", "decisiones"])
        d["duenos"] = duenos
        pa = [n for n in d.get("puede_aceptar") or [] if not _vacio(n)]
        d["puede_aceptar"] = pa if nombre in pa else pa + [nombre]
        d["identificacion_vendedor"] = self.pedir("Identificación del vendedor para el aviso legal de la landing "
                                                  "(razón social o nombre, país, contacto)", d.get("identificacion_vendedor"))
        return [_guardar("dueno", d)]

    def elegir_medios(self, t):
        """La pregunta única de medios. Escribe t["medios"] y deja por_producto_defecto / por_proveedor_dia de Higgsfield y
        ElevenLabs iguales a los techos elegidos (los usan topes.cabe y registro.py)."""
        import medios as MD
        actual = ((t.get("medios") or {}).get("modo")) or "minimo"
        while True:
            r = str(self.pedir(PREGUNTA_MEDIOS, actual)).strip().lower().replace("í", "i")
            if r in MD.MODOS:
                break
            self.decir("  escribí mínimo, personalizado o libre")
        m = {"modo": r, "aviso_pct": MD.AVISO_PCT}
        conf = MD.configuracion(dict(t, medios={"modo": r}))
        for p in MD.PROVEEDORES:
            techos = {k: conf[p][k] for k, _ in CAMPOS_MEDIOS}
            if r == "personalizado":
                previo = (t.get("medios") or {}).get(p) or {}
                for k, texto in CAMPOS_MEDIOS:
                    techos[k] = self.pedir("%s: %s %s" % (p.capitalize(), MD.UNIDAD[p], texto), previo.get(k), float,
                                           recomendado=MD.MINIMO[p][k])
            m[p] = dict(techos, unidad=MD.UNIDAD[p])
            _set(t, "por_producto_defecto.%s.tope" % p, techos["producto"])
            _set(t, "por_producto_defecto.%s.unidad" % p, MD.UNIDAD[p])
            _set(t, "por_proveedor_dia.%s.tope" % p, techos["dia"])
            _set(t, "por_proveedor_dia.%s.unidad" % p, MD.UNIDAD[p])
        if r == "libre":
            self.decir("  Libre: tickets automáticos sin pedirte nada, siempre dentro de estos techos (se cambian en "
                       "datos/topes.local.json → medios o con firmar.py medios): " +
                       "; ".join("%s %s/%s/%s %s por producto/día/mes" % (p, m[p]["producto"], m[p]["dia"], m[p]["mes"],
                                                                         MD.UNIDAD[p]) for p in MD.PROVEEDORES) +
                       ". Te aviso al pasar el %d %%." % MD.AVISO_PCT)
        t["medios"] = m
        return t

    def topes(self):
        t = _cargar("topes")
        for ruta, texto, tipo in CAMPOS_TOPES:
            _set(t, ruta, self.pedir(texto, _get(t, ruta), tipo, recomendado=RECOMENDADO.get(ruta)))
        t = self.elegir_medios(t)   # con --recomendado no pregunta: deja lo elegido antes o el mínimo
        quien = self.firmante(_cargar("dueno"))
        texto = self.pedir("Texto literal con el que fijás estos topes",
                           "Fijo estos topes de gasto para hyperflujo-auto; nada se gasta por encima de ellos.")
        if not self.confirmar():
            self.decir("Cancelado: no se guardó nada.")
            return []
        t["firmado"] = {"quien": quien, "fecha": rutas.hoy(), "texto": texto}
        escritos = [_guardar("topes", t)]
        conf = _cargar("config")
        actual = _get(conf, "workers.max_budget_usd_por_worker")
        tope_w = self.pedir("Tope por worker de Claude en USD (corta un worker que se pasa)", actual, float,
                            recomendado=RECOMENDADO["workers.max_budget_usd_por_worker"])
        if tope_w != actual:
            _set(conf, "workers.max_budget_usd_por_worker", tope_w)
            escritos.append(_guardar("config", conf))
        return escritos

    def medios(self):
        """Cambiar solo el gasto en imágenes y voces, sin repasar todos los topes."""
        t = _cargar("topes")
        t = self.elegir_medios(t)
        quien = self.firmante(_cargar("dueno"))
        if not self.confirmar():
            self.decir("Cancelado: no se guardó nada.")
            return []
        t["medios"]["firmado"] = {"quien": quien, "fecha": rutas.hoy(),
                                  "texto": "Elijo el gasto en imágenes y voces en modo %s, con estos techos." % t["medios"]["modo"]}
        if _vacio((t.get("firmado") or {}).get("quien")):
            t["firmado"] = dict(t["medios"]["firmado"])
        return [_guardar("topes", t)]

    def _techo(self, clave, topes):
        p = topes.get("por_producto_defecto") or {}
        if clave == "meta":
            m = p.get("meta") or {}
            return (m.get("diario") or 0) * (m.get("dias") or 0) or None
        if clave == "medios":
            return (p.get("elevenlabs") or {}).get("tope") or None
        return (p.get(clave) or {}).get("tope")

    def autorizaciones(self):
        a = _cargar("autorizaciones")
        lista = a.setdefault("autorizaciones", [])
        topes = _cargar("topes")
        hasta = (datetime.date.fromisoformat(rutas.hoy()) + datetime.timedelta(days=VIGENCIA_DIAS)).isoformat()
        hasta = self.pedir("Vigencia de estas autorizaciones (AAAA-MM-DD; %d días)" % VIGENCIA_DIAS, hasta)
        nuevas = []
        for alcance, texto, cond, techo in AUTORIZACIONES + OPCIONALES:
            opcional = (alcance, texto, cond, techo) in OPCIONALES
            self.decir("\n— %s%s" % (alcance, " (opcional)" if opcional else ""))
            if opcional and self.pedir("¿La firmás? (si/no)", "no") != "si":
                continue
            t = self.pedir("Texto literal (Enter acepta el propuesto)", texto)
            nueva = {"alcance": alcance, "ofertas": "todas", "texto_literal": t, "vigente_hasta": hasta, "condiciones": cond}
            if techo:
                nueva["techo_usd"] = self.pedir("Techo por producto en USD", self._techo(techo, topes), float)
            nuevas.append(nueva)
        quien = self.firmante(_cargar("dueno"))
        if not self.confirmar():
            self.decir("Cancelado: no se guardó nada.")
            return []
        import re   # ids existentes pueden ser «AUT-007» o con nombre («AUT-OF006-META»): se numera sobre los numéricos
        n = max([int(m.group(1)) for m in (re.match(r"^AUT-(\d+)$", str(x.get("id", ""))) for x in lista) if m] + [0])
        for i, x in enumerate(nuevas, 1):
            lista.append(dict({"id": "AUT-%03d" % (n + i)}, firmante=quien, fecha=rutas.hoy(), **x))
        return [_guardar("autorizaciones", a)]


VIGENCIA_CHECKOUT_DIAS = 90


def _checkout(self):
    """E3: el checkout de Hotmart abierto DESDE EL PAÍS del mercado (con VPN de ese país), precio y moneda vistos.
    No hay conector que lo haga: es el paso humano, una vez por mercado y cada 90 días. Lo exige compuerta_sitio."""
    mercados = sorted(k for k in (rutas.leer_json(rutas.ruta("datos", "mercados.json"), defecto={}) or {}) if not k.startswith("_"))
    self.decir("Abrí un checkout de Hotmart de un producto de ese mercado con una VPN del país, y mirá precio y moneda.")
    mercado = self.pedir("Mercado (p. ej. es-ES, de-DE; conocidos: %s)" % ", ".join(mercados))
    pais = self.pedir("País desde el que lo abriste (VPN), p. ej. ES")
    url = self.pedir("URL del checkout que abriste (pay.hotmart.com/…)")
    precio = self.pedir("Precio que viste en el checkout", tipo=float)
    moneda = self.pedir("Moneda que viste (EUR, USD…)").upper()
    bien = self.pedir("¿Se veía bien, en el idioma del país y con medios de pago locales? (si/no)", "si")
    quien = self.firmante(_cargar("dueno"))
    if not self.confirmar():
        self.decir("Cancelado: no se guardó nada.")
        return []
    c = rutas.leer_json(rutas.ruta("datos", "confirmaciones.local.json"), defecto={}) or {}
    c.setdefault("checkout_pais", []).append({"mercado": mercado, "pais": pais.upper(), "url": url, "precio_visto": precio,
                                              "moneda_vista": moneda, "se_ve_bien": bien == "si", "fecha": rutas.hoy(),
                                              "firmante": quien})
    rutas.escribir_json(rutas.ruta("datos", "confirmaciones.local.json"), c)
    return ["datos/confirmaciones.local.json"]


Firma.checkout = _checkout


def main(argv=None, preguntar=input, tty=None):
    ap = argparse.ArgumentParser(description="La persona firma, en su terminal, dueño, topes y autorizaciones.")
    ap.add_argument("seccion", choices=("dueno", "topes", "autorizaciones", "checkout", "medios", "todo"))
    ap.add_argument("--recomendado", action="store_true",
                    help="acepta el mínimo recomendado en todo lo que falta; solo pide tu nombre y «firmo»")
    a = ap.parse_args(argv)
    if not (sys.stdin.isatty() if tty is None else tty):
        print(json.dumps({"ok": False, "codigo": 2, "artefactos": [],
                          "motivo": "firmar.py solo corre en la terminal de la persona (nadie firma por el dueño): "
                                    "abrí una terminal en la carpeta del repo y corré python herramientas/firmar.py %s"
                                    % a.seccion}, ensure_ascii=False))
        return 2
    f = Firma(preguntar, recomendado=a.recomendado)
    escritos = []
    for s in (("dueno", "topes", "autorizaciones") if a.seccion == "todo" else (a.seccion,)):
        print("\n=== %s ===" % s)
        escritos += getattr(f, s)()
    print("\nListo. Volvé al chat y decile al director «listo»: vuelve a detectar.")
    print(json.dumps({"ok": bool(escritos), "codigo": 0 if escritos else 3, "motivo": "firmado" if escritos else "cancelado",
                      "artefactos": escritos}, ensure_ascii=False))
    return 0 if escritos else 3


if __name__ == "__main__":
    sys.exit(main())
