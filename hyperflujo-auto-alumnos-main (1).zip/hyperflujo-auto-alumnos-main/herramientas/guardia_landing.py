#!/usr/bin/env python3
"""guardia_landing.py — ninguna landing generada o desplegada lleva un bloque de testimonios o reseñas (D119).

D119 (Ramiro, 2026-10-23): «testimonios fuera del sistema: quitá el código». No hay código que pida, recoja, valide,
espere ni inserte testimonios. Esta guardia solo PROHÍBE: la usan los armadores de sitios (producto/armar_sitio.py,
kit/sitio.py) para sacar un bloque viejo de una fuente que no se puede tocar (D118: la landing publicada de OF-006 lo
conserva) y netlify_deploy.py para negarse a desplegar un sitio que lo traiga. Solo biblioteca estándar.
"""
import re

# Matías, 2026-10-26: en la web de cada idioma van «las 6 opiniones de tu página en español, traducidas tal cual», con
# el aviso de que son de la edición original y el link a cada captura. Las opiniones REALES van entre estos marcadores,
# con la fuente de las capturas; lo que está adentro no cuenta como rastro. Todo testimonio fuera de ellos (inventado,
# sin fuente) sigue prohibido (D119, F66).
RE_REALES = re.compile(r"<!--\s*OPINIONES-REALES:INICIO\s+fuente=\"([^\"]+)\"\s*-->(.*?)<!--\s*OPINIONES-REALES:FIN\s*-->",
                       re.IGNORECASE | re.DOTALL)


def sin_opiniones_reales(texto):
    """→ el HTML sin los bloques de opiniones reales con fuente (para revisar lo que queda)."""
    return RE_REALES.sub(lambda m: "" if m.group(1).strip() else m.group(0), texto or "")


def opiniones_reales(texto):
    """[fuente] de cada bloque de opiniones reales del HTML."""
    return [m.group(1).strip() for m in RE_REALES.finditer(texto or "") if m.group(1).strip()]

INICIO, FIN = "<!-- TESTIMONIOS:INICIO -->", "<!-- TESTIMONIOS:FIN -->"
RE_SECCION = re.compile(r"<section\b[^>]*class=\"[^\"]*\btestimonios?\b[^\"]*\"[^>]*>.*?</section>", re.IGNORECASE | re.DOTALL)
RE_RASTRO = re.compile(r"TESTIMONIOS:INICIO|class=\"[^\"]*\btestimonio(?:s|-card|-legal|-texto)?\b", re.IGNORECASE)
CARPETA = "testimonios"   # img/testimonios/ nunca se copia ni se despliega
# F66 (OF-006 estuvo en línea con los testimonios inventados del incidente I-2): cualquier rastro en cualquier HTML
RASTROS = ((re.compile(r"TESTIMONIOS:(?:INICIO|FIN)", re.IGNORECASE), "marcador TESTIMONIOS"),
           (re.compile(r"class=\"[^\"]*\btestimonio(?:s|-card|-legal|-texto)?\b", re.IGNORECASE), "clase testimonio"),
           (re.compile(r"""(?:href|id)\s*=\s*["']#?opiniones\b""", re.IGNORECASE), "ancla #opiniones"),
           (re.compile(r"img/testimonios", re.IGNORECASE), "imagen de img/testimonios"),
           (re.compile("★"), "estrella ★ (reseña)"),
           (re.compile(r"panel de probadores", re.IGNORECASE), "«panel de probadores»"))


def rastros(texto):
    """[qué rastro de testimonios o reseñas trae el HTML] (vacío = limpio)."""
    resto = sin_opiniones_reales(texto)
    return [que for pat, que in RASTROS if pat.search(resto)]


def tiene_bloque(texto):
    """¿El HTML trae un bloque de testimonios o cualquier rastro de ellos (F66)?"""
    return bool(rastros(texto))


def quitar_bloque(texto):
    """→ (texto sin bloques de testimonios, cuántos se quitaron). Quita lo que hay entre marcadores (marcadores
    incluidos) y cualquier <section class="testimonios">. Los bloques de opiniones reales con fuente se conservan."""
    guardados = []

    def _guardar(m):
        if not m.group(1).strip():
            return m.group(0)
        guardados.append(m.group(0))
        return "\x00REALES%d\x00" % (len(guardados) - 1)
    texto = RE_REALES.sub(_guardar, texto or "")
    n = 0
    while INICIO in texto and FIN in texto[texto.index(INICIO):]:
        i = texto.index(INICIO)
        j = texto.index(FIN, i) + len(FIN)
        texto, n = texto[:i] + texto[j:], n + 1
    texto, k = RE_SECCION.subn("", texto)
    for i, b in enumerate(guardados):
        texto = texto.replace("\x00REALES%d\x00" % i, b)
    return texto, n + k
