#!/usr/bin/env python3
"""guardian_gasto.py — hook PreToolUse que niega toda escritura que gasta, activa o publica sin autorización vigente
y sin ticket del plan del día (TAREA 036 parte C; CLAUDE.md reglas 4 y 5; ARQUITECTURA §7.2).

Registro en .claude/settings.json (matcher "mcp__.*|Bash|PowerShell"). Claude Code le pasa por stdin
{"tool_name", "tool_input", ...}. Salida: código 0 = permite (sin texto); código 2 = niega, con el motivo en stderr
(Claude Code bloquea la herramienta y le muestra el motivo al modelo). Cada negación queda en estado/bloqueos.jsonl.

Qué vigila (lo demás pasa sin mirar):
  * Meta (conector): ads_create_*, ads_creative_*, ads_activate_entity, ads_update_entity (salvo una pausa pura:
    solo status=PAUSED, siempre permitida aun con freno, D60), ads_boost_ig_post, audiencias.
  * Higgsfield pago: generate_*, upscale_*, outpaint, reframe, motion_control, dubbing, voice_change, 3D, shorts…
  * ElevenLabs (conector): todo salvo lecturas (get_/list_/search_/check_). Sus tickets salen de plan.TICKETS["medios"].
  * Hotmart: reembolsos, cupones, suscripciones y negociaciones → siempre negado (no son del ciclo).
  * Bash/PowerShell: hotmart_alta.mjs --modo real, netlify_deploy.py … publicar, meta_ads.py crear|estado,
    higgsfield.py / elevenlabs.py (pedidos pagos).
Para permitir algo vigilado hacen falta TODAS: freno del dueño apagado; producto identificado (HYPERFLUJO_OF, que
pone lanzar_worker.py, un OF-NNN en el comando, o el pedido vigente de la sesión en estado/sesion_worker.json); autorización vigente del alcance (autorizaciones.vigentes);
acción del plan de hoy (estado/planes/<hoy>*.json) para esa herramienta o prefijo de comando y ese producto, en
estado «en_curso», con ticket de menos de 10 min y llamadas_usadas < max_llamadas (al permitir, suma una llamada).
Cualquier error leyendo plan, autorizaciones o la entrada = niega (falla cerrado). Solo biblioteca estándar.
"""
import fnmatch
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))

MINUTOS_TICKET = 10
META_GASTO = re.compile(r"^(ads_create_.*|ads_creative_.*|ads_boost_ig_post|ads_update_custom_audience.*|ads_delete_custom_audience)$")
HIGGS_PAGO = re.compile(r"^(generate_.*|upscale_.*|outpaint_image|reframe|remove_background|motion_control|voice_change|dubbing|"
                        r"shorts_studio_create|scene_builder_3d_generate.*|ai_influencer_generate|execute_preset|ads_studio_generate|"
                        r"create_voice.*|media_import_url)$")
# ElevenLabs (conector MCP, 2026-10-28): todo lo que no sea una lectura cobra o puede cobrar (voz, efectos, clonado,
# doblaje, agentes); se vigila por exclusión para fallar cerrado ante herramientas nuevas.
ELEVEN_LECTURA = re.compile(r"^(get_|list_|search_|check_)")
HOTMART_PROHIBIDO = re.compile(r"^hotmart_(sale_refund|coupon_create|coupon_delete|subscription_.*|batch_subscriptions_.*|negotiation_generate)$")
META_SIN_EFECTO = {"advertiser_job", "advertiser_request", "client_conversation_id", "client_model", "id", "entity_id",
                   "entity_type", "ad_account_id", "object_id", "level"}
CLAVES_ID = ("entity_id", "object_ids", "object_id", "campaign_id", "adset_id", "ad_set_id", "video_id", "id")   # 037 B: esquema real
SOLO_DIRECTOR = [(re.compile(r"\b%s\b" % x, re.IGNORECASE), y) for x, y in (
    (r"director\.py", "director.py"), (r"vigia\.py", "vigia.py"), (r"programar\.py", "programar.py"),
    (r"repo_productos\.py", "repo_productos.py"), (r"meta_pausa\.py", "meta_pausa.py"),
    (r"precio_vencimiento\.py\s+aplicar", "precio_vencimiento.py aplicar"),
    (r"lanzar_worker\.py", "lanzar_worker.py"), (r"ensayo_seco\.py", "ensayo_seco.py"),
    (r"plan\.py", "plan.py (un worker no se emite sus propios tickets)"))]
COMANDOS = [   # (regex sobre el comando, alcance, tipo de acción del plan)
    (re.compile(r"hotmart_alta\.mjs.*--modo\s+real.*finalizar_registro|hotmart_alta\.mjs.*finalizar_registro.*--modo\s+real"), "finalizar_registro", "hotmart_finalizar"),
    (re.compile(r"hotmart_alta\.mjs.*--modo\s+real"), "publicar", "hotmart_real"),
    (re.compile(r"netlify_deploy\.py.*\b(publicar|medios|crear|desplegar|retiro)\b"), "publicar", "netlify_publicar"),
    (re.compile(r"meta_ads\.py\s+(crear|estado)\b"), "gasto_meta", "meta_crear_campana"),
    (re.compile(r"\b(higgsfield|elevenlabs)\.py\b"), "gasto_medios", "medios_lote"),
]


def clasificar(tool, entrada, worker=False, raiz=None):
    """→ None (no vigilado) | ("pausa", None) | ("prohibido", motivo) | (alcance, descripcion)."""
    partes = (tool or "").split("__")
    if len(partes) >= 3 and partes[0] == "mcp":
        srv, herr = partes[1].lower().replace("_", "-"), "__".join(partes[2:])
        srv = ("meta-ads" if ("meta" in srv and "ads" in srv) else "higgsfield" if "higgsfield" in srv else
               "hotmart" if "hotmart" in srv else "elevenlabs" if "elevenlabs" in srv else srv)
        if srv == "meta-ads":
            if herr == "ads_update_entity":
                campos = campos_update(entrada)
                if campos is None:   # fields ilegible: nunca cuenta como pausa
                    return ("gasto_meta", herr)
                claves = {k for k, v in campos.items() if v not in (None, "")} - META_SIN_EFECTO
                estado = str(campos.get("status") or campos.get("configured_status") or "").upper()
                if claves <= {"status", "configured_status"} and estado == "PAUSED":
                    return ("pausa", None)
                return ("escalar" if any("budget" in k or "spend_cap" in k for k in claves) else "gasto_meta", herr)
            if herr == "ads_activate_entity":
                return ("activar_campana", herr)
            if META_GASTO.match(herr):
                return ("gasto_meta", herr)
            return None
        if srv == "higgsfield" and HIGGS_PAGO.match(herr):
            return ("gasto_medios", herr)
        if srv == "elevenlabs" and not ELEVEN_LECTURA.match(herr):
            return ("gasto_medios", herr)
        if srv == "hotmart" and HOTMART_PROHIBIDO.match(herr):
            return ("prohibido", "escritura de Hotmart fuera del ciclo (reembolso, cupón, suscripción): siempre a mano")
        return None
    if tool in ("Bash", "PowerShell"):
        cmd = re.sub(r"[\"'`^]", "", str((entrada or {}).get("command") or ""))   # sin comillas: --modo "real" = --modo real
        if worker:
            motivo = comando_ajeno(cmd, raiz)
            if motivo:
                return ("prohibido", motivo)
        for rx, alcance, tipo in COMANDOS:
            if rx.search(cmd):
                return (alcance, tipo)
    return None


def campos_update(entrada):
    """ads_update_entity real: {ad_account_id, entity_id, entity_type, fields: "<json>"}; también acepta claves sueltas."""
    e = dict(entrada or {})
    f = e.pop("fields", None)
    if isinstance(f, str):
        try:
            f = json.loads(f)
        except ValueError:
            return None
    if isinstance(f, dict):
        e.update(f)
    elif f is not None:
        return None
    return e


def comando_ajeno(cmd, raiz=None):
    """Para un worker: motivo si el comando corre algo fuera de herramientas/ o algo que solo hace el director."""
    if re.search(r"\.\.[\\/]", cmd):
        return "ruta con «..»: un worker solo corre scripts de herramientas/"
    if re.search(r"\b(python[\d.]*|py|node)(\.exe)?\s+(-\S*\s+)*-(c|e|-eval)\b", cmd, re.IGNORECASE):
        return "código en línea (-c/-e): un worker solo corre scripts de herramientas/"
    for rx, quien in SOLO_DIRECTOR:
        if rx.search(cmd):
            return "%s lo corre el director, nunca un worker" % quien
    base = Path(raiz or _raiz()).resolve() / "herramientas"
    for tok in re.findall(r"[^\s;&|<>()]+\.(?:py|mjs|cjs|js)\b", cmd, re.IGNORECASE):
        p = Path(tok)
        p = (p if p.is_absolute() else Path(raiz or _raiz()) / p).resolve()
        if base not in p.parents:
            return "script fuera de herramientas/ (%s): un worker no corre código propio" % p.name
    return None


def _raiz():
    return Path(os.environ.get("HYPERFLUJO_RAIZ") or os.environ.get("CLAUDE_PROJECT_DIR") or AQUI.parents[1])


def _registrar(raiz, fila):
    try:
        p = raiz / "estado" / "bloqueos.jsonl"
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(fila, ensure_ascii=False) + "\n")
    except OSError:
        pass   # registrar no puede volver permisivo al guardián: la negación sigue en pie


def _ahora():
    import rutas
    return rutas.ahora()


def _planes(raiz, fecha):
    """Acciones de estado/planes/<fecha>*.json. Un archivo ilegible lanza (→ niega)."""
    acciones = []
    for p in sorted((raiz / "estado" / "planes").glob("%s*.json" % fecha)):
        datos = json.loads(p.read_text(encoding="utf-8"))
        acciones += [(p, a) for a in datos.get("acciones", [])]
    return acciones


def _ticket(raiz, fecha, of, tool, entrada, ahora):
    cmd = str((entrada or {}).get("command") or "")
    for p, a in _planes(raiz, fecha):
        if a.get("of") != of or a.get("estado") != "en_curso":
            continue
        coincide = (a.get("herramienta") and fnmatch.fnmatchcase(tool, a["herramienta"])) or \
            (a.get("comando") and cmd.strip().startswith(a["comando"]))
        if not coincide:
            continue
        try:
            desde = datetime.fromisoformat(a.get("ticket_en") or "")
        except ValueError:
            continue
        if desde.tzinfo is None:
            desde = desde.replace(tzinfo=ahora.tzinfo)
        try:
            vence = datetime.fromisoformat(a["vence_en"]) if a.get("vence_en") else desde + timedelta(minutes=MINUTOS_TICKET)
        except ValueError:
            continue
        if vence.tzinfo is None:
            vence = vence.replace(tzinfo=ahora.tzinfo)
        if ahora > vence or ahora < desde:
            continue
        if (a.get("llamadas_usadas") or 0) >= (a.get("max_llamadas") or 1):
            continue
        return p, a
    return None, None


def _ids(v):
    if isinstance(v, str):
        try:
            v = json.loads(v) if v.strip().startswith("[") else v
        except ValueError:
            pass
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v]
    return [] if v in (None, "") else [str(v)]


def _valores(x):
    if isinstance(x, dict):
        for v in x.values():
            yield from _valores(v)
    elif isinstance(x, list):
        for v in x:
            yield from _valores(v)
    elif x not in (None, ""):
        yield str(x)


def ids_ajenos(raiz, of, tool, entrada):
    """Meta: los IDs que toca la llamada tienen que ser del producto (ofertas/<OF>/externo.local.json → meta).
    Activar o actualizar sin ID o con un ID ajeno = niega (un ticket de OF-001 no sirve para la campaña de OF-002)."""
    if not str(tool).startswith("mcp__") or "ads_" not in str(tool):
        return None
    pedidos = [i for k in CLAVES_ID for i in _ids((entrada or {}).get(k))]
    cre = (entrada or {}).get("creative")   # ads_create_ad real: creative = '{"creative_id": "…"}' (TAREA 037 B)
    if isinstance(cre, str):
        try:
            cre = json.loads(cre)
        except ValueError:
            cre = None
    if isinstance(cre, dict) and cre.get("creative_id"):
        pedidos.append(str(cre["creative_id"]))
    campos = campos_update(entrada) or {}
    pedidos += [i for k in ("campaign_id", "adset_id") for i in _ids(campos.get(k))]
    exigir = tool.endswith(("ads_activate_entity", "ads_update_entity"))
    if not pedidos:
        return "la llamada no dice qué objeto toca: no se puede atar al producto" if exigir else None
    try:
        ext = json.loads((Path(raiz) / "ofertas" / of / "externo.local.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        ext = {}
    propios = set(_valores(ext.get("meta") or {}))
    ajenos = [i for i in pedidos if i not in propios]
    return ("objeto(s) de Meta que no son de %s según externo.local.json: %d" % (of, len(ajenos))) if ajenos else None


def _sumar_llamada(p, accion):
    datos = json.loads(p.read_text(encoding="utf-8"))
    for a in datos.get("acciones", []):
        if a.get("id") == accion.get("id"):
            a["llamadas_usadas"] = (a.get("llamadas_usadas") or 0) + 1
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, p)


def decidir(evento, raiz=None):
    """→ (permitido: bool, motivo: str, clasificacion). Pura salvo la suma de la llamada al permitir."""
    raiz = Path(raiz or _raiz())
    tool, entrada = evento.get("tool_name"), evento.get("tool_input") or {}
    c = clasificar(tool, entrada, worker=bool(os.environ.get("HYPERFLUJO_OF")), raiz=raiz)
    if c is None:
        return True, "no vigilado", None
    alcance, detalle = c
    if alcance == "pausa":
        return True, "pausa pura (status=PAUSED): siempre permitida (D60)", c
    if alcance == "prohibido":
        return False, detalle, c
    if (raiz / "estado" / "freno.json").exists():
        return False, "freno del dueño activo: solo se permite pausar", c
    of = os.environ.get("HYPERFLUJO_OF")
    if not of:
        m = re.search(r"\bOF-\d{3,}\b", str(entrada.get("command") or "") + " " + json.dumps(entrada, ensure_ascii=False))
        of = m.group(0) if m else None
    if not of:   # TAREA 041: subagente de la sesión (/lanzar): el producto del pedido en curso (estado/sesion_worker.json)
        import pedidos_sesion
        of = pedidos_sesion.of_en_curso(raiz=raiz)
    if not of:
        return False, "no se puede identificar el producto (HYPERFLUJO_OF): sin producto no hay autorización", c
    ahora = _ahora()
    fecha = ahora.date().isoformat()
    import autorizaciones
    if alcance not in autorizaciones.vigentes(of, fecha, raiz=raiz):
        return False, "sin autorización vigente «%s» para %s en datos/autorizaciones.local.json" % (alcance, of), c
    ajenos = ids_ajenos(raiz, of, tool, entrada)
    if ajenos:
        return False, ajenos, c
    p, accion = _ticket(raiz, fecha, of, tool, entrada, ahora)
    if accion is None:
        return False, "sin ticket en el plan de hoy (estado/planes/%s*.json) para %s %s: en curso, < %d min y con llamadas" % (
            fecha, of, tool, MINUTOS_TICKET), c
    _sumar_llamada(p, accion)
    return True, "ticket %s" % accion.get("id"), c


def main():
    raiz = _raiz()
    try:
        evento = json.loads(sys.stdin.read() or "{}")
    except ValueError:
        print("guardian_gasto: entrada ilegible: se niega (falla cerrado)", file=sys.stderr)
        return 2
    try:
        ok, motivo, c = decidir(evento, raiz)
    except Exception as e:   # plan o autorizaciones ilegibles, lo que sea: niega
        ok, motivo, c = False, "error del guardián (%s): se niega (falla cerrado)" % type(e).__name__, ("?", None)
    if ok:
        return 0
    entrada = json.dumps(evento.get("tool_input") or {}, ensure_ascii=False, sort_keys=True)
    _registrar(raiz, {"hora": datetime.now().astimezone().isoformat(timespec="seconds"), "herramienta": evento.get("tool_name"),
                      "alcance": c[0] if c else None, "of": os.environ.get("HYPERFLUJO_OF"), "motivo": motivo,
                      "entrada_sha256": hashlib.sha256(entrada.encode("utf-8")).hexdigest()})
    print("BLOQUEADO por guardian_gasto: %s" % motivo, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
