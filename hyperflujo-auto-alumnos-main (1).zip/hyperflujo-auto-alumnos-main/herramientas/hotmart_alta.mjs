// Origen: hyperflujo/herramientas/hotmart_alta.mjs (copia del taller; [PENDIENTE: traducir códigos de salida a PLAN §3.8 en recetas/hotmart/RECETA.md]).
// Alta de un producto en Hotmart EN BORRADOR con Playwright sobre la sesión del dueño (TAREA 032 act. 10, D69).
//
//   node herramientas/hotmart_alta.mjs <carpeta canales/hotmart> --modo seco                      # no guarda nada
//   node herramientas/hotmart_alta.mjs <carpeta canales/hotmart> --modo real --ej <registro.json>  # crea el borrador
//   opciones: --via perfil|cdp (por defecto perfil) · --cdp <url> (por defecto http://127.0.0.1:9222) · --selectores <json>
//             (por defecto recetas/hotmart/selectores.json) · --oculto · --desde <paso> --producto <id>
//   node herramientas/hotmart_alta.mjs <carpeta> --modo seco|real --flujo <nombre> --producto <id> [--ej <registro.json>] [--version N]
//             flujos de selectores.json sobre un producto ya creado: contenido (PDF), soporte, pixel, precio_base,
//             oferta_lanzamiento, leer_oferta, finalizar_registro (este exige --ok-publicar "<OK literal>" [--ok-de "<quién/canal>"]).
//             Cada clic que guarda se registra antes (solicitud gratuita, clave flujo:oferta:paso).
//
// Entrada: ficha_hotmart.json, para_pegar/*.txt, medios/manifiesto.json (portada y PDF) y config_sitio.json (píxel,
// soporte) de la carpeta del canal. Los pasos y selectores viven en el JSON de selectores: si el panel cambia, se
// corrige ese archivo, no este.
// Seco: recorre y llena hasta el primer botón que guarda, lo marca en la captura y NO lo pulsa.
// Real: pulsa los botones que guardan; el que crea el producto se registra antes (solicitud gratuita, regla 6) y el ID
// de Hotmart se guarda apenas se lee. Al final escribe el ID y la URL de checkout en la ficha del canal, en
// oferta.json → destino.hotmart y en config_sitio.json.
// Nunca: credenciales (si la sesión venció, para), captcha (para), publicar, enviar a revisión ni activar ventas
// (un clic cuyo texto lo sugiera se rechaza siempre).
import { abrir, esHotmart, perfilExiste, CDP_DEFECTO } from './hotmart_navegador.mjs';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

// --- Guardas agregadas en la revisión adversarial 035 ---
function falla(m) { throw new Error(`${m} (revisión 035)`); }
function diasGarantia(ficha) {
  const d = ficha.garantia?.dias ?? ficha.garantia?.valor;
  if (!Number.isInteger(Number(d)) || Number(d) <= 0 || d === null || d === '') falla('garantia.dias no es un entero');
  return Number(d);
}
// h. 6: el OK para publicar tiene que coincidir con el texto literal de una autorización vigente de alcance
// «publicar» o «finalizar_registro» en datos/autorizaciones.local.json (deny de Edit para los workers); cualquier texto no basta.
function okPublicarValido(ok) {
  if (!ok) return false;
  try {
    const raiz = process.env.HYPERFLUJO_RAIZ || RAIZ;
    const d = JSON.parse(readFileSync(join(raiz, 'datos', 'autorizaciones.local.json'), 'utf8'));
    const hoy = new Date().toISOString().slice(0, 10);
    return (d.autorizaciones || []).some((x) => ['publicar', 'finalizar_registro'].includes(x.alcance) &&
      x.texto_literal === ok && x.firmante && !String(x.firmante).startsWith('<') && (!x.vigente_hasta || hoy <= x.vigente_hasta));
  } catch { return false; }
}
const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
// «Finalizar registro» envía el producto a revisión de Hotmart (pantalla del producto, EJ-029): también prohibido.
const PROHIBIDO = /publicar|publish|activar|ativar|enviar\s+(a|para)\s+(revis|aprova|aprob)|submit\s+for|solicitar\s+aprova|finalizar\s+(el\s+)?(registro|cadastro)/i;
const PY = existsSync(join(RAIZ, '.venv', 'Scripts', 'python.exe')) ? join(RAIZ, '.venv', 'Scripts', 'python.exe') : 'python';

const leerJSON = (r) => JSON.parse(readFileSync(r, 'utf8').replace(/^﻿/, ''));
const escribirJSON = (r, d) => writeFileSync(r, JSON.stringify(d, null, 1) + '\n', 'utf8');
const leerTexto = (r) => readFileSync(r, 'utf8').replace(/^﻿/, '').trimEnd();

function args(argv) {
  const a = { modo: 'seco', selectores: join(RAIZ, 'recetas', 'hotmart', 'selectores.json'), via: 'perfil', cdp: CDP_DEFECTO, oculto: false };
  const pos = [];
  for (let i = 0; i < argv.length; i++) {
    const x = argv[i];
    if (x === '--oculto') a.oculto = true;
    else if (x === '--volcar') a.volcar = true;
    else if (x.startsWith('--')) a[x.slice(2)] = argv[++i];
    else pos.push(x);
  }
  a.carpeta = pos[0];
  return a;
}

export const precioRegex = (n) => {
  const [e, d] = Number(n).toFixed(2).split('.');
  return d === '00' ? `^${e}([.,]00)?$` : `^${e}[.,]${d}$`;
};

export function datosDelCanal(carpeta) {
  const ficha = leerJSON(join(carpeta, 'ficha_hotmart.json'));
  const oferta = resolve(carpeta, '..', '..');
  const manifiesto = leerJSON(join(carpeta, 'medios', 'manifiesto.json'));
  const config = existsSync(join(carpeta, 'config_sitio.json')) ? leerJSON(join(carpeta, 'config_sitio.json')) : {};
  const p = ficha.producto;
  const op = ficha.oferta_precio;
  const pegar = (n) => leerTexto(join(carpeta, 'para_pegar', n));
  return {
    oferta_id: ficha.oferta_id,
    pieza: ficha.pieza || null,   // TAREA 037 D: los 6 secundarios comparten oferta_id; la clave del registro lleva la pieza
    nombre: pegar('1_nombre.txt'),
    descripcion_corta: pegar('2_descripcion_corta.txt'),
    descripcion_larga: pegar('3_descripcion_larga.txt'),
    garantia_texto: pegar('4_garantia.txt'),
    idioma: [p.idioma.valor, 'Espanhol', 'Spanish'],
    // revisión 035 h. 13: la categoría sale de la ficha (falla cerrado); antes estaba fija en Hobbies/Artesanato
    categoria: ficha.hotmart?.categoria ? [].concat(ficha.hotmart.categoria) : falla('falta hotmart.categoria en la ficha'),
    precio: String(ficha.oferta_precio.precio.valor),
    // el campo de precio tiene máscara: se verifica «9,99» / «17,00» y, si fill no lo deja, se tipea en centavos
    precio_regex: precioRegex(ficha.oferta_precio.precio.valor),
    precio_centavos: String(Math.round(ficha.oferta_precio.precio.valor * 100)),
    // el panel muestra el nombre completo (seca EJ-029): «Dólar estadounidense»; coincidencia exacta (no «Dólar canadiense»)
    moneda: [({ USD: 'Dólar estadounidense', ARS: 'Peso argentino', BRL: 'Real brasileño', EUR: 'Euro', MXN: 'Peso mexicano' })[ficha.oferta_precio.precio.moneda] || ficha.oferta_precio.precio.moneda],
    // revisión 035 h. 18/25: la plantilla define garantia.dias; entero o falla (nunca «NaN días»)
    garantia_dias: String(diasGarantia(ficha)),
    garantia_opcion: [`${diasGarantia(ficha)} días`],
    forma_pago: ['Pago al contado'],
    portada: join(carpeta, manifiesto.archivos.find((x) => x.archivo.endsWith('portada_600.png')).archivo),
    pdf: join(oferta, manifiesto.entrega.archivo),
    pdf_sha256: manifiesto.entrega.sha256,
    pixel_id: config.pixel_id || null,
    correo_soporte: config.correo_soporte || null,
    pagina_ventas: config.url_landing || null,
    // D77: precio base del producto (lista) y oferta de lanzamiento; sin esos datos, el precio de venta
    precio_base: String(op.precio_base?.valor ?? op.precio.valor),
    precio_base_regex: precioRegex(op.precio_base?.valor ?? op.precio.valor),
    precio_base_centavos: String(Math.round((op.precio_base?.valor ?? op.precio.valor) * 100)),
    precio_lanzamiento: String(op.oferta_lanzamiento?.valor ?? op.precio.valor),
    precio_lanzamiento_regex: precioRegex(op.oferta_lanzamiento?.valor ?? op.precio.valor),
    precio_lanzamiento_centavos: String(Math.round((op.oferta_lanzamiento?.valor ?? op.precio.valor) * 100)),
    nombre_oferta: op.oferta_lanzamiento?.nombre || null,
    // TAREA 037 D (es-ES): precio con IVA incluido → casilla «Incluir impuestos en el precio» (input#vatValueEmbedded)
    impuestos_incluidos: ficha.hotmart?.precio_con_iva ? 'si' : null,
  };
}

const sustituir = (s, v) => {
  // dos pasadas: una URL de `urls` puede traer a su vez {{producto_id}}
  // TAREA 036 E: una lista (p. ej. categoria) se sustituye por su primera opción
  for (let i = 0; i < 2; i++) s = s.replace(/\{\{(\w+)\}\}/g, (_, k) => (Array.isArray(v[k]) ? v[k][0] : v[k]) ?? `{{${k}}}`);
  return s;
};

async function primero(pagina, selectores, ms = 8000, ocultoOk = false) {
  const fin = Date.now() + ms;
  while (Date.now() < fin) {
    for (const s of selectores) {
      const loc = pagina.locator(s).first();
      if (await loc.count().catch(() => 0) && (ocultoOk || await loc.isVisible().catch(() => false))) return { loc, selector: s };
    }
    await pagina.waitForTimeout(300);
  }
  return null;
}

async function volcar(pagina, archivo) {
  const inventario = await pagina.evaluate(() => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const etiqueta = (e) => (e.labels && e.labels[0] && e.labels[0].innerText) || e.getAttribute('aria-label') || '';
    return {
      url: location.href, titulo: document.title,
      encabezados: [...document.querySelectorAll('h1,h2,h3')].filter(vis).map((e) => e.innerText.trim()).slice(0, 30),
      campos: [...document.querySelectorAll('input,textarea,select,[contenteditable="true"]')].filter((e) => vis(e) || e.type === 'file')
        .map((e) => ({ tag: e.tagName.toLowerCase(), type: e.type || null, name: e.name || null, id: e.id || null,
          placeholder: e.placeholder || null, etiqueta: etiqueta(e).trim().slice(0, 80), testid: e.getAttribute('data-testid') }))
        .filter((c) => c.type !== 'password').slice(0, 80),
      // componentes propios (desplegables del sistema de diseño, combobox) y el HTML alrededor de las etiquetas visibles
      componentes: [...document.querySelectorAll('[role=combobox],[role=listbox],[aria-haspopup],*')]
        .filter((e) => (e.getAttribute('role') || e.getAttribute('aria-haspopup') || e.tagName.includes('-')) && vis(e))
        .map((e) => ({ tag: e.tagName.toLowerCase(), role: e.getAttribute('role'), id: e.id || null,
          clase: (e.getAttribute('class') || '').slice(0, 80), texto: (e.innerText || '').trim().slice(0, 60) })).slice(0, 60),
      html_principal: (() => { const m = document.querySelector('main') || document.querySelector('[class*=content i]');
        return m ? m.outerHTML.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, '').replace(/<svg[\s\S]*?<\/svg>/g, '<svg/>').slice(0, 15000) : null; })(),
      // textos visibles cortos de hojas del árbol: muestra las opciones de un desplegable abierto
      textos_visibles: [...new Set([...document.querySelectorAll('main *')].filter((e) => !e.children.length && vis(e))
        .map((e) => (e.innerText || '').trim()).filter((t) => t && t.length <= 50))].slice(0, 250),
      botones: [...document.querySelectorAll('button,[role=button],a[href]')].filter(vis)
        .map((e) => ({ texto: (e.innerText || e.getAttribute('aria-label') || '').trim().slice(0, 60), href: e.getAttribute('href'),
          testid: e.getAttribute('data-testid') })).filter((b) => b.texto).slice(0, 120),
    };
  });
  writeFileSync(archivo, JSON.stringify(inventario, null, 1) + '\n', 'utf8');
}

function registro(...a) {
  try { return { codigo: 0, salida: execFileSync(PY, [join(RAIZ, 'herramientas', 'hotmart_registro.py'), ...a], { encoding: 'utf8', env: { ...process.env, PYTHONIOENCODING: 'utf-8' } }).trim() }; }
  catch (e) { return { codigo: e.status ?? 1, salida: String(e.stdout || e.message).trim() }; }
}

export async function correr(a) {
  if (!a.carpeta) throw new Error('Falta la carpeta canales/hotmart de la oferta.');
  if (!['seco', 'real', 'explorar'].includes(a.modo)) throw new Error('--modo seco | real | explorar');
  if (a.modo === 'real' && !a.ej) throw new Error('--modo real exige --ej <registro.json> (regla 4).');
  const carpeta = resolve(a.carpeta);
  const sel = leerJSON(a.selectores);
  const datos = datosDelCanal(carpeta);
  const v = { ...sel.urls, producto_id: a.producto || null, checkout_url: null };
  const pasos = a.flujo ? (sel.flujos || {})[a.flujo] : sel.pasos;
  if (!pasos) throw new Error(`No hay flujo «${a.flujo}» en ${a.selectores}`);
  if (a.flujo && !a.producto) throw new Error('--flujo exige --producto <id> (producto ya creado).');
  const nombreSalida = `${a.flujo || 'alta'}_${a.modo}`;
  const salida = a.ej ? join(dirname(resolve(a.ej)), 'resultados', nombreSalida) : join(carpeta, 'capturas_alta', nombreSalida);
  mkdirSync(salida, { recursive: true });
  const bitacora = [];
  const log = (paso, estado, detalle = null) => { bitacora.push({ paso, estado, detalle }); console.log(`${estado.padEnd(10)} ${paso}${detalle ? ' — ' + detalle : ''}`); };

  if (a.modo === 'real') {
    const est = registro('estado', resolve(a.ej));
    if (est.codigo === 3) throw new Error('Registro en envio_incierto: conciliar con hotmart_products_list antes de repetir (regla 7).');
  }
  // Vías (hotmart_navegador.mjs): perfil persistente de Chrome (por defecto) (la vía CDP al Chrome personal se eliminó en la revisión 035 h. 18).
  // Con selectores de prueba (usar_sesion_falsa) la vía «perfil» pasa a «prueba»; «cdp» se respeta (test de pestañas).
  const via = sel.usar_sesion_falsa && a.via === 'perfil' ? 'prueba' : a.via;
  if (via === 'perfil' && !perfilExiste()) throw new Error('No hay perfil de Hotmart: correr node herramientas/hotmart_sesion.mjs y que Ramiro haga el login.');
  const nav = await abrir({ via, visible: !a.oculto, cdp: a.cdp });
  const pagina = nav.pagina;
  const logueadoRe = new RegExp(sel.logueado_si_url);
  // Solo la pestaña propia y solo hotmart.com (file:// únicamente con el panel falso de los tests)
  const permitida = () => esHotmart(pagina.url(), !!sel.usar_sesion_falsa);
  let n = 0, codigo = 0, sid = null;
  let activo = !a.desde;
  if (a.modo === 'explorar') {
    try {
      await pagina.goto(sustituir(a.url || sel.urls.producto, v), { waitUntil: 'domcontentloaded', timeout: 60000 });
      await pagina.waitForTimeout(4000);
      if (!permitida() || !logueadoRe.test(pagina.url())) { log('explorar', 'PARADO', 'sesión vencida o fuera de hotmart.com'); codigo = 5; }
      const pestanas = (a.pestanas ? a.pestanas.split('|') : sel.explorar || []);
      for (const [k, t] of pestanas.entries()) {
        if (codigo) break;
        const tag = `${String(k + 1).padStart(2, '0')}_${t.replace(/[^A-Za-z0-9]+/g, '_').slice(0, 30)}`;
        if (PROHIBIDO.test(t)) { log(t, 'RECHAZADO', 'pestaña con texto prohibido'); continue; }
        const loc = pagina.getByText(t, { exact: true }).first();
        if (!(await loc.count().catch(() => 0))) { log(t, 'AVISO', 'no está en pantalla'); continue; }
        await loc.click();
        await pagina.waitForTimeout(3500);
        await pagina.screenshot({ path: join(salida, `${tag}.png`), fullPage: true });
        await volcar(pagina, join(salida, `${tag}_volcado.json`));
        log(t, 'OK', pagina.url());
      }
    } finally {
      await nav.cerrar();
    }
    return { codigo, producto_id: v.producto_id, checkout_url: null, salida };
  }
  try {
    for (const paso of pasos) {
      if (!activo) { if (paso.id === a.desde) activo = true; else continue; }
      n += 1;
      const tag = `${String(n).padStart(2, '0')}_${paso.id}`;
      const falta = (paso.requiere || []).filter((k) => !datos[k] && !v[k]);
      if (falta.length) { log(paso.id, 'SALTADO', `falta ${falta.join(', ')}`); continue; }
      if (paso.accion === 'ir') {
        await pagina.goto(sustituir(paso.url, v), { waitUntil: 'domcontentloaded', timeout: 60000 });
        await pagina.waitForTimeout(paso.espera_ms ?? 2000);
        if (!permitida() || !logueadoRe.test(pagina.url())) { log(paso.id, 'PARADO', 'sesión vencida o fuera de hotmart.com: correr hotmart_sesion.mjs'); codigo = 5; break; }
      }
      if (await pagina.locator('iframe[src*="captcha"], iframe[title*="captcha" i]').count().catch(() => 0)) {
        log(paso.id, 'PARADO', 'captcha en pantalla: lo resuelve Ramiro, no el script'); codigo = 6; break;
      }
      if (paso.accion === 'ir') { await pagina.screenshot({ path: join(salida, `${tag}.png`) }); log(paso.id, 'OK'); continue; }
      if (paso.accion === 'leer') {
        const fuente = paso.de === 'url' ? pagina.url() : paso.de === 'visible' ? await pagina.innerText('body') : await pagina.content();
        const m = fuente.match(new RegExp(sustituir(paso.regex, { ...datos, ...v })));
        if (!m) { await volcar(pagina, join(salida, `${tag}_volcado.json`)); log(paso.id, paso.opcional ? 'AVISO' : 'FALTA', 'no se encontró el dato'); if (!paso.opcional) { codigo = 4; break; } continue; }
        v[paso.guardar_como] = (m[1] || m[0]).replace(/&amp;/g, '&');
        log(paso.id, 'OK', `${paso.guardar_como}=${v[paso.guardar_como]}`);
        if (paso.guardar_como === 'producto_id' && sid) { registro('id', resolve(a.ej), sid, String(v.producto_id)); sid = null; }
        continue;
      }
      const hallado = await primero(pagina, (paso.selectores || []).map((s) => sustituir(s, { ...datos, ...v })), paso.espera_ms ?? 8000, paso.accion === 'archivo' || paso.accion === 'marcar');
      if (!hallado) {
        await pagina.screenshot({ path: join(salida, `${tag}_falta.png`), fullPage: true });
        await volcar(pagina, join(salida, `${tag}_volcado.json`));
        log(paso.id, paso.opcional ? 'AVISO' : 'FALTA', 'selector no encontrado; ver volcado');
        if (paso.opcional) continue;
        codigo = 4; break;
      }
      const { loc } = hallado;
      if (!permitida() || !logueadoRe.test(pagina.url())) { log(paso.id, 'PARADO', 'fuera del panel: no se escribe nada'); codigo = 5; break; }
      if (paso.accion === 'clic') {
        const texto = ((await loc.innerText().catch(() => '')) || (await loc.getAttribute('aria-label').catch(() => '')) || '').trim();
        // D88: «Finalizar registro» (enviar a revisión = publicar) solo en el flujo finalizar_registro, en un paso marcado
        // publica, y en real solo con --ok-publicar "<texto literal del OK escrito del dueño>". Activar ventas, nunca.
        const publicaConOk = paso.publica && a.flujo === 'finalizar_registro' && (a.modo === 'seco' || okPublicarValido(a['ok-publicar']));
        if ((PROHIBIDO.test(texto) && !publicaConOk) || paso.activa || (paso.publica && !publicaConOk)) {
          log(paso.id, 'RECHAZADO', `«${texto}»: publicar/activar no se automatiza${paso.publica ? ' sin --ok-publicar' : ''}`); codigo = 8; break;
        }
        if (paso.guarda && a.modo === 'seco') {
          await loc.evaluate((e) => { e.style.outline = '4px solid #d00'; });
          await pagina.screenshot({ path: join(salida, `${tag}_NO_SE_PULSA.png`), fullPage: true });
          await volcar(pagina, join(salida, `${tag}_volcado.json`));
          log(paso.id, 'SECO', `botón «${texto}» encontrado, no se pulsa; la seca termina acá`);
          break;
        }
        if (paso.crea_producto) {
          const r = registro('inicio', resolve(a.ej), `alta:${datos.oferta_id}${datos.pieza ? ':' + datos.pieza : ''}`, JSON.stringify({ herramienta: 'hotmart_alta.mjs', paso: paso.id, nombre: datos.nombre, precio: datos.precio, moneda: datos.moneda, pdf_sha256: datos.pdf_sha256 }));
          if (r.codigo !== 0) { log(paso.id, 'PARADO', `registro: ${r.salida}`); codigo = 1; break; }
          sid = r.salida;
        }
        let sidGuarda = null;
        if (paso.guarda && !paso.crea_producto && a.modo === 'real') {
          const clave = `${a.flujo || 'alta'}:${datos.oferta_id}${datos.pieza ? ':' + datos.pieza : ''}:${paso.id}${a.version ? ':v' + a.version : ''}`;
          const r = registro('inicio', resolve(a.ej), clave, JSON.stringify({ herramienta: 'hotmart_alta.mjs', flujo: a.flujo || 'alta', paso: paso.id, producto_id: v.producto_id, dato: paso.registra ? datos[paso.registra] : null,
            ...(paso.publica ? { ok_publicar: a['ok-publicar'], ok_de: a['ok-de'] || null, fecha_ok_registrada: new Date().toISOString() } : {}) }));
          if (r.codigo !== 0) { log(paso.id, 'PARADO', `registro: ${r.salida}`); codigo = 1; break; }
          sidGuarda = r.salida;
        }
        await loc.click();
        await pagina.waitForTimeout(paso.espera_despues_ms ?? 2500);
        if (sidGuarda) {
          await pagina.screenshot({ path: join(salida, `${tag}_guardado.png`), fullPage: true });
          const r = registro('id', resolve(a.ej), sidGuarda, `${v.producto_id}:${paso.id}`);
          log(paso.id, r.codigo === 0 ? 'REGISTRADO' : 'INCIERTO', r.salida);
        }
      } else if (paso.accion === 'llenar') {
        await loc.fill(String(datos[paso.dato]));
        if (paso.verificar) {
          const re = new RegExp(sustituir(paso.verificar, { ...datos, ...v }));
          if (!re.test(await loc.inputValue())) {
            await loc.click(); await loc.press('Control+A'); await loc.press('Backspace');
            await loc.pressSequentially(paso.tipear ? sustituir(paso.tipear, { ...datos, ...v }) : String(datos[paso.dato]), { delay: 80 });
          }
          const valor = await loc.inputValue();
          if (!re.test(valor)) { await volcar(pagina, join(salida, `${tag}_volcado.json`)); log(paso.id, 'FALTA', `el campo quedó en «${valor}»`); codigo = 4; break; }
        }
      } else if (paso.accion === 'elegir') {
        const opciones = [].concat(datos[paso.dato]);
        let elegido = null;
        if (await loc.evaluate((e) => e.tagName === 'SELECT')) {
          for (const o of opciones) { try { await loc.selectOption({ label: o }); elegido = o; break; } catch { /* siguiente */ } }
        } else {
          await loc.click();
          for (const o of opciones) {
            const op = pagina.getByRole('option', { name: o }).or(pagina.getByText(o, { exact: true }))
              .or(pagina.locator('li, [role=option], [class*=option i]').filter({ hasText: o })).first();
            if (await op.count().catch(() => 0)) { await op.click(); elegido = o; break; }
          }
        }
        if (!elegido) { await pagina.screenshot({ path: join(salida, `${tag}_falta.png`) }); await volcar(pagina, join(salida, `${tag}_volcado.json`)); log(paso.id, paso.opcional ? 'AVISO' : 'FALTA', `ninguna opción de ${opciones.join(' / ')}`); if (!paso.opcional) { codigo = 4; break; } continue; }
      } else if (paso.accion === 'marcar') {   // TAREA 037 D: casilla que tiene que quedar marcada (idempotente)
        if (!(await loc.isChecked().catch(() => false))) await loc.check({ force: true }).catch(async () => { await pagina.locator(`label[for="${await loc.getAttribute('id')}"]`).click(); });
        if (!(await loc.isChecked().catch(() => false))) { await volcar(pagina, join(salida, `${tag}_volcado.json`)); log(paso.id, 'FALTA', 'la casilla no quedó marcada'); codigo = 4; break; }
      } else if (paso.accion === 'archivo') {
        // La portada del asistente se guarda recién con «continuar»; un archivo con guarda=true (PDF en Contenido) se
        // guarda al subirlo: en seco no se sube y en real se registra antes (regla 6).
        if (!paso.guarda) { await loc.setInputFiles(datos[paso.dato]); await pagina.waitForTimeout(paso.espera_despues_ms ?? 3000); }
        else if (a.modo === 'seco') { log(paso.id, 'SECO', `no se sube ${relative(RAIZ, datos[paso.dato])}; la seca termina acá`); break; }
        else {
          const r = registro('inicio', resolve(a.ej), `${a.flujo || 'alta'}:${datos.oferta_id}${datos.pieza ? ':' + datos.pieza : ''}:${paso.id}${a.version ? ':v' + a.version : ''}`,
            JSON.stringify({ herramienta: 'hotmart_alta.mjs', flujo: a.flujo || 'alta', paso: paso.id, producto_id: v.producto_id, sha256: datos.pdf_sha256 }));
          if (r.codigo !== 0) { log(paso.id, 'PARADO', `registro: ${r.salida}`); codigo = 1; break; }
          await loc.setInputFiles(datos[paso.dato]);
          await pagina.waitForTimeout(paso.espera_despues_ms ?? 3000);
          const ri = registro('id', resolve(a.ej), r.salida, `${v.producto_id}:${paso.id}:${String(datos.pdf_sha256).slice(0, 12)}`);
          log(paso.id, ri.codigo === 0 ? 'REGISTRADO' : 'INCIERTO', ri.salida);
        }
      } else {
        throw new Error(`Acción desconocida: ${paso.accion}`);
      }
      await pagina.screenshot({ path: join(salida, `${tag}.png`) });
      if (a.volcar) await volcar(pagina, join(salida, `${tag}_volcado.json`));
      log(paso.id, 'OK');
    }
  } finally {
    if (sid) log('registro', 'INCIERTO', `${sid} quedó «enviando» sin ID: conciliar con hotmart_products_list antes de repetir`);
    const resumen = { modo: a.modo, fecha: new Date().toISOString(), oferta_id: datos.oferta_id, producto_id: v.producto_id,
      checkout_url: v.checkout_url, codigo, pasos: bitacora, capturas: relative(RAIZ, salida).replace(/\\/g, '/') };
    writeFileSync(join(salida, 'resumen.json'), JSON.stringify(resumen, null, 1) + '\n', 'utf8');
    await nav.cerrar();
  }
  if (a.modo === 'real' && codigo === 0 && v.producto_id && !a.flujo) escribirResultados(carpeta, v, a.ej);
  if (a.modo === 'real' && codigo === 0 && v.oferta_codigo) escribirOferta(carpeta, v, a.ej);
  return { codigo, producto_id: v.producto_id, checkout_url: v.checkout_url, salida };
}

// D77/Act. 19: el código de la oferta de lanzamiento va a la ficha del canal, a oferta.json y al checkout de la landing.
function escribirOferta(carpeta, v, ej) {
  const ficha = leerJSON(join(carpeta, 'ficha_hotmart.json'));
  const codigo = ficha.hotmart?.codigo || (v.checkout_url || '').match(/pay\.hotmart\.com\/([A-Za-z0-9]+)/)?.[1];
  const url = codigo ? `https://pay.hotmart.com/${codigo}?off=${v.oferta_codigo}&checkoutMode=10` : null;
  ficha.oferta_precio.oferta_lanzamiento = { ...ficha.oferta_precio.oferta_lanzamiento, codigo: v.oferta_codigo, checkout_url: url,
    ejecucion: relative(RAIZ, resolve(ej)).replace(/\\/g, '/') };
  escribirJSON(join(carpeta, 'ficha_hotmart.json'), ficha);
  const pOferta = resolve(carpeta, '..', '..', 'oferta.json');
  const oferta = leerJSON(pOferta);
  oferta.precio.codigo_oferta_lanzamiento = v.oferta_codigo;   // revisión 035 h. 12: campo propio, no pisa el precio
  if (oferta.destino?.hotmart) oferta.destino.hotmart.oferta_lanzamiento = { codigo: v.oferta_codigo, url_checkout: url };
  escribirJSON(pOferta, oferta);
  if (url && existsSync(join(carpeta, 'config_sitio.json'))) {
    const c = leerJSON(join(carpeta, 'config_sitio.json'));
    c.checkout_url = url;
    escribirJSON(join(carpeta, 'config_sitio.json'), c);
  }
}

function escribirResultados(carpeta, v, ej) {
  const fecha = new Date().toISOString().slice(0, 10);
  const ejecucion = ej ? relative(RAIZ, resolve(ej)).replace(/\\/g, '/') : null;
  const ficha = leerJSON(join(carpeta, 'ficha_hotmart.json'));
  ficha.estado = 'borrador creado en Hotmart (D69); ventas NO activadas';
  const previo = ficha.hotmart || {};
  ficha.hotmart = { ...previo, producto_id: String(v.producto_id), checkout_url: v.checkout_url || previo.checkout_url || null,
    estado: 'borrador', fecha, ejecucion };
  escribirJSON(join(carpeta, 'ficha_hotmart.json'), ficha);
  const pOferta = resolve(carpeta, '..', '..', 'oferta.json');
  const oferta = leerJSON(pOferta);
  oferta.destino = oferta.destino || {};
  const previoO = oferta.destino.hotmart || {};
  oferta.destino.hotmart = { ...previoO, producto_id: String(v.producto_id), url_checkout: v.checkout_url || previoO.url_checkout || previoO.checkout_url || null,
    estado: previoO.estado || 'borrador', fecha, ejecucion, fuente: 'hotmart_alta.mjs (D69)' };
  escribirJSON(pOferta, oferta);
  if (v.checkout_url) {
    const pc = join(carpeta, 'config_sitio.json');
    const c = leerJSON(pc);
    c.checkout_url = v.checkout_url;
    escribirJSON(pc, c);
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const r = await correr(args(process.argv.slice(2)));
    console.log(`Capturas y resumen: ${relative(RAIZ, r.salida)}`);
    if (r.producto_id) console.log(`Producto ${r.producto_id} · checkout ${r.checkout_url || '(no leído)'}`);
    process.exit(r.codigo);
  } catch (e) { console.error('ERROR: ' + e.message); process.exit(2); }
}
