// Origen: hyperflujo/herramientas/hotmart_explorar.mjs (copia del taller; [PENDIENTE: traducir códigos de salida a PLAN §3.8 en recetas/hotmart/RECETA.md]).
// Exploración de SOLO LECTURA del panel de Hotmart sobre el perfil vivo (D69): navega, abre menús y modales y deja
// captura + volcado de cada paso, para escribir selectores.json sin adivinar. Nunca guarda nada.
//
//   node herramientas/hotmart_explorar.mjs <carpeta_salida> '<pasos JSON>'
//   pasos: [{"ir": "https://app.hotmart.com/..."}, {"clic": "<selector Playwright>"}, {"tecla": "Escape"},
//           {"llenar": "<selector>", "texto": "..."} (solo buscadores y filtros), {"captura": "nombre"}]
//   Los clics y llenados prueban la página y después cada iframe (el panel de Hotmart monta secciones en iframes).
//
// Un clic cuyo texto sugiera guardar, crear, borrar, publicar, activar o enviar a revisión se rechaza y el guion para.
// Solo app.hotmart.com (y el editor custom-checkout.hotmart.com); si la sesión venció, para.
//
// Modo paso a paso (editores de varias pantallas: página de pago con order bumps, embudo de un clic, D79):
//   --mantener                 no cierra la pestaña al terminar
//   --reusar <regex de URL>    sigue en la pestaña abierta que coincida (si no hay, abre una nueva)
//   --escribe --ej <registro.json> --clave <prefijo>
//                              permite los clics con "guarda": true en el paso; cada uno se registra ANTES (solicitud
//                              gratuita, regla 6) y se cierra con el texto del botón después
//   --ok-publicar "<OK literal>"  además permite «Publicar» en pasos "publica": true (D88).
//   --ok-activar "<OK literal>"   permite «Activar» solo en pasos "activa": true (p. ej. el embudo, con el OK escrito de Ramiro).
import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { abrir, esHotmart, logueado } from './hotmart_navegador.mjs';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const ACTIVA = /activar|ativar|activate/i;
const PUBLICA = /publicar|publish/i;

function registro(...a) {
  try { return { codigo: 0, salida: execFileSync(process.platform === 'win32' ? 'python' : 'python3', [join(RAIZ, 'herramientas', 'hotmart_registro.py'), ...a], { encoding: 'utf8', env: { ...process.env, PYTHONIOENCODING: 'utf-8' } }).trim() }; }
  catch (e) { return { codigo: e.status ?? 1, salida: String(e.stdout || e.message).trim() }; }
}

export const QUE_GUARDA = /guardar|salvar|save|crear|criar|create|confirmar|confirm|aplicar|publicar|publish|activar|ativar|desactivar|eliminar|excluir|borrar|delete|remover|enviar|submit|finalizar|definir\s+como|duplicar|agregar|adicionar|añadir|subir|upload/i;

// Volcado de la página y de cada iframe de hotmart.com (el panel monta secciones en app-vlc.hotmart.com).
async function volcar(pagina) {
  const marcos = pagina.frames().filter((f) => f === pagina.mainFrame() || /^https:\/\/[\w-]+\.hotmart\.com\//.test(f.url()));
  const salida = [];
  for (const f of marcos) salida.push(await volcarMarco(f).catch((e) => ({ url: f.url(), error: String(e).slice(0, 200) })));
  return salida.length === 1 ? salida[0] : { ...salida[0], marcos: salida.slice(1) };
}

async function volcarMarco(pagina) {
  return pagina.evaluate(() => {
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const txt = (e) => (e.innerText || e.value || e.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 80);
    return {
      url: location.href,
      iframes: [...document.querySelectorAll('iframe')].map((f) => f.src).filter(Boolean).slice(0, 10),
      encabezados: [...document.querySelectorAll('h1,h2,h3,h4,label,legend')].filter(vis).map(txt).filter(Boolean).slice(0, 60),
      campos: [...document.querySelectorAll('input,textarea,select')].filter((e) => vis(e) || e.type === 'file')
        .filter((e) => e.type !== 'password')
        .map((e) => ({ tag: e.tagName.toLowerCase(), type: e.type || null, name: e.name || null, id: e.id || null,
          placeholder: e.placeholder || null, testid: e.getAttribute('data-testid'), valor: e.type === 'checkbox' ? e.checked : null })).slice(0, 80),
      botones: [...document.querySelectorAll('button,a,[role=button],[role=tab],[role=menuitem],img[alt]')].filter(vis)
        .map((e) => ({ tag: e.tagName.toLowerCase(), texto: txt(e) || e.getAttribute('alt') || '', href: e.getAttribute('href'), testid: e.getAttribute('data-testid') }))
        .filter((b) => b.texto || b.testid).slice(0, 120),
    };
  });
}

async function buscar(p, selector) {
  for (const marco of [p.mainFrame(), ...p.frames().filter((f) => f !== p.mainFrame())]) {
    const loc = marco.locator(selector).first();
    if (await loc.count().catch(() => 0)) return loc;
  }
  return null;
}

export async function explorar(salida, pasos, abrirNav = abrir, op = {}) {
  mkdirSync(salida, { recursive: true });
  const nav = await abrirNav({ via: 'perfil' });
  let p = nav.pagina;
  if (op.reusar && nav.contexto) {
    const re = new RegExp(op.reusar);
    const vieja = nav.contexto.pages().find((x) => x !== p && re.test(x.url()));
    if (vieja) { await p.close().catch(() => {}); p = vieja; }
  }
  const log = [];
  try {
    for (const [i, paso] of pasos.entries()) {
      const tag = String(i + 1).padStart(2, '0');
      if (paso.ir) {
        await p.goto(paso.ir, { waitUntil: 'domcontentloaded', timeout: 60000 });
        await p.waitForTimeout(paso.espera_ms ?? 5000);
        const editor = /^https:\/\/custom-checkout\.hotmart\.com\//.test(p.url()); // editor de la página de pago (D79)
        if (!esHotmart(p.url()) || (!logueado(p.url()) && !editor)) { log.push({ paso: tag, estado: 'PARADO', detalle: 'sesión vencida o fuera de hotmart' }); break; }
      } else if (paso.clic) {
        const loc = await buscar(p, paso.clic);
        if (!loc) { log.push({ paso: tag, estado: 'AVISO', detalle: 'no está: ' + paso.clic }); continue; }
        const texto = ((await loc.innerText().catch(() => '')) || (await loc.getAttribute('aria-label').catch(() => '')) || '').trim();
        const guarda = QUE_GUARDA.test(texto) || QUE_GUARDA.test(paso.clic) || !!paso.guarda;
        const permitido = guarda && paso.guarda && op.escribe && op.ej
          && (!ACTIVA.test(texto) || (paso.activa && op.okActivar))
          && (!PUBLICA.test(texto) || (paso.publica && op.okPublicar));
        if (guarda && !permitido) { log.push({ paso: tag, estado: 'RECHAZADO', detalle: texto || paso.clic }); break; }
        let sid = null;
        if (permitido) {
          const r = registro('inicio', resolve(op.ej), `${op.clave || 'explorar'}:${paso.id || tag}`, JSON.stringify({ herramienta: 'hotmart_explorar.mjs', paso: paso.id || tag, boton: texto, url: p.url(), ...(paso.publica ? { ok_publicar: op.okPublicar } : {}), ...(paso.activa ? { ok_activar: op.okActivar } : {}) }));
          if (r.codigo !== 0) { log.push({ paso: tag, estado: 'PARADO', detalle: 'registro: ' + r.salida }); break; }
          sid = r.salida;
        }
        await loc.click({ timeout: 10000 });
        await p.waitForTimeout(paso.espera_ms ?? 2500);
        if (sid) {
          const r = registro('id', resolve(op.ej), sid, `${(op.clave || 'explorar')}:${paso.id || tag}:${texto.slice(0, 40)}`);
          log.push({ paso: tag, estado: r.codigo === 0 ? 'REGISTRADO' : 'INCIERTO', detalle: r.salida });
        }
      } else if (paso.llenar) {
        const loc = await buscar(p, paso.llenar);
        if (!loc) { log.push({ paso: tag, estado: 'AVISO', detalle: 'no está: ' + paso.llenar }); continue; }
        await loc.fill(paso.texto ?? '');
        await p.waitForTimeout(paso.espera_ms ?? 2500);
      } else if (paso.tecla) {
        await p.keyboard.press(paso.tecla);
        await p.waitForTimeout(800);
      }
      const nombre = `${tag}_${(paso.captura || paso.ir || paso.clic || paso.llenar || paso.tecla).replace(/[^A-Za-z0-9]+/g, '_').slice(-40)}`;
      // la captura de página completa a veces se cuelga esperando fuentes (editor de embudos): no tumba el guion
      await p.screenshot({ path: join(salida, nombre + '.png'), fullPage: true, timeout: 15000 })
        .catch(() => p.screenshot({ path: join(salida, nombre + '.png'), timeout: 15000 }).catch(() => log.push({ paso: tag, estado: 'AVISO', detalle: 'sin captura' })));
      writeFileSync(join(salida, nombre + '_volcado.json'), JSON.stringify(await volcar(p), null, 1));
      log.push({ paso: tag, estado: 'OK', url: p.url(), archivo: nombre });
    }
  } finally {
    if (!op.mantener) await (p === nav.pagina ? nav.cerrar() : p.close().catch(() => {}));
    writeFileSync(join(salida, 'log.json'), JSON.stringify(log, null, 1));
  }
  return log;
}

if (process.argv[1] && process.argv[1].endsWith('hotmart_explorar.mjs')) {
  const pos = [], op = {};
  const av = process.argv.slice(2);
  for (let i = 0; i < av.length; i++) {
    const x = av[i];
    if (x === '--mantener') op.mantener = true;
    else if (x === '--escribe') op.escribe = true;
    else if (x === '--reusar') op.reusar = av[++i];
    else if (x === '--ej') op.ej = av[++i];
    else if (x === '--clave') op.clave = av[++i];
    else if (x === '--ok-publicar') op.okPublicar = av[++i];
    else if (x === '--ok-activar') op.okActivar = av[++i];
    else pos.push(x);
  }
  const [salida, pasos] = pos;
  if (!salida || !pasos) { console.error("uso: node herramientas/hotmart_explorar.mjs <salida> '<pasos JSON>' [--mantener] [--reusar <re>] [--escribe --ej <reg> --clave <c>] [--ok-publicar <OK>]"); process.exit(2); }
  const log = await explorar(salida, JSON.parse(pasos), abrir, op);
  for (const l of log) console.log(l.paso, l.estado, l.url || l.detalle || '', l.archivo || '');
  process.exit(log.some((l) => !['OK', 'AVISO', 'REGISTRADO'].includes(l.estado)) ? 1 : 0);
}
