#!/usr/bin/env python3
"""hotmart_flujos.py — flujos del robot de Hotmart como pasos declarativos (Hyperflujo, TAREA 035).

Cada flujo devuelve una lista de pasos {accion: ir|llenar|clic|leer, sel, valor}. Los ejecuta:
  * hotmart_alta.mjs (hotmart_robot.mjs se borró en la revisión 035 h. 18: no tenía guardas) (Playwright, sesión persistente del dueño, --modo real) o
  * PanelFalso (este archivo) en las pruebas, sin red.
Reglas: el robot nunca escribe credenciales, nunca resuelve captchas ni acepta términos. finalizar_registro exige una
autorización escrita (AUT-...). Selectores en recetas/hotmart/selectores.json [PENDIENTE: copiar limpio del taller y
verificar los de oferta de lanzamiento, bumps y embudo, que el taller no tenía probados].
Sin testimonios, timers ni cupos: el robot no carga textos que no estén en la ficha.
"""
import json
import re
import sys

FLUJOS = ("alta_borrador", "precio_lista", "oferta_lanzamiento", "finalizar_registro", "bumps", "embudo")


class SinAutorizacion(PermissionError):
    pass


def _precio(v):
    if not isinstance(v, (int, float)) or v <= 0:
        raise ValueError("precio inválido: %r [PENDIENTE: precio de la ficha]" % (v,))
    return "%.2f" % v


def pasos(flujo, datos, autorizacion=None):
    if flujo == "alta_borrador":
        return [{"accion": "ir", "valor": "/productos/nuevo"},
                {"accion": "llenar", "sel": "nombre", "valor": datos["nombre"]},
                {"accion": "llenar", "sel": "descripcion", "valor": datos["descripcion"]},
                {"accion": "clic", "sel": "guardar_borrador"},
                {"accion": "leer", "sel": "codigo_producto", "guardar": "codigo_producto"}]
    if flujo == "precio_lista":
        return [{"accion": "ir", "valor": "/productos/%s/precio" % datos["codigo_producto"]},
                {"accion": "llenar", "sel": "precio", "valor": _precio(datos["precio_lista"])},
                {"accion": "clic", "sel": "guardar"}]
    if flujo == "oferta_lanzamiento":
        fin = datos.get("fin_oferta")
        if not fin or not re.match(r"^\d{4}-\d{2}-\d{2}$", fin):
            raise ValueError("la oferta de lanzamiento necesita fecha de fin AAAA-MM-DD")
        if datos["precio_oferta"] >= datos["precio_lista"]:
            raise ValueError("la oferta debe ser menor que el precio de lista")
        # Revisión 035 h. 12 (precio.py en línea, falla cerrado): d ∈ [0,60; 0,70] (ARQUITECTURA §10) y fin ≥ aprobación + 30 d.
        d = 1 - float(datos["precio_oferta"]) / float(datos["precio_lista"])
        if not (0.60 <= round(d, 4) <= 0.70):
            raise ValueError("descuento %.2f fuera de [0,60; 0,70]" % d)
        apr = datos.get("aprobacion")
        if not apr or not re.match(r"^\d{4}-\d{2}-\d{2}$", apr):
            raise ValueError("falta la fecha de aprobación de Hotmart (AAAA-MM-DD) para fijar el fin de la oferta")
        from datetime import date, timedelta
        if date.fromisoformat(fin) < date.fromisoformat(apr) + timedelta(days=30):
            raise ValueError("el fin de la oferta debe estar a 30 días o más de la aprobación")
        return [{"accion": "ir", "valor": "/productos/%s/ofertas/nueva" % datos["codigo_producto"]},
                {"accion": "llenar", "sel": "oferta_precio", "valor": _precio(datos["precio_oferta"])},
                {"accion": "llenar", "sel": "oferta_fin", "valor": fin},
                {"accion": "clic", "sel": "guardar"},
                {"accion": "leer", "sel": "codigo_oferta", "guardar": "codigo_oferta"}]
    if flujo == "finalizar_registro":
        if not autorizacion or not str(autorizacion).startswith("AUT-"):
            raise SinAutorizacion("finalizar_registro exige --autorizacion AUT-... (OK escrito del dueño)")
        return [{"accion": "ir", "valor": "/productos/%s" % datos["codigo_producto"]},
                {"accion": "clic", "sel": "enviar_revision"},
                {"accion": "leer", "sel": "estado", "guardar": "estado"}]
    if flujo == "bumps":
        out = []
        for b in datos.get("bumps", []):
            out += [{"accion": "ir", "valor": "/productos/%s/bumps/nuevo" % datos["codigo_producto"]},
                    {"accion": "llenar", "sel": "bump_codigo", "valor": b["codigo"]},
                    {"accion": "clic", "sel": "guardar"}]
        return out
    if flujo == "embudo":
        return [{"accion": "ir", "valor": "/productos/%s/embudo" % datos["codigo_producto"]},
                {"accion": "llenar", "sel": "upsell_codigo", "valor": datos["upsell_codigo"]},
                {"accion": "clic", "sel": "guardar"}]
    raise ValueError("flujo desconocido: %s" % flujo)


class PanelFalso:
    """Panel de Hotmart en memoria para pruebas: ejecuta pasos y devuelve lo leído. Códigos con marcador FALSO-."""

    def __init__(self):
        self.productos, self.n, self.registro = {}, 0, []
        self._form, self._ruta, self._ultimo, self._ultimo_oferta = {}, "", None, None

    def ejecutar(self, lista):
        leido = {}
        for p in lista:
            self.registro.append(p)
            if p["accion"] == "ir":
                self._ruta, self._form = p["valor"], {}
            elif p["accion"] == "llenar":
                self._form[p["sel"]] = p["valor"]
            elif p["accion"] == "clic":
                self._clic(p["sel"])
            elif p["accion"] == "leer":
                leido[p["guardar"]] = self._leer(p["sel"])
        return leido

    def _clic(self, sel):
        partes = self._ruta.strip("/").split("/")
        if self._ruta == "/productos/nuevo" and sel == "guardar_borrador":
            self.n += 1
            self._ultimo = "FALSO-P%d" % self.n
            self.productos[self._ultimo] = dict(self._form, estado="borrador", ofertas=[], bumps=[])
            return
        prod = self.productos[partes[1]]
        if sel == "enviar_revision":
            prod["estado"] = "en_revision"
        elif "precio" in partes:
            prod["precio_lista"] = self._form["precio"]
        elif "ofertas" in partes:
            prod["ofertas"].append({"precio": self._form["oferta_precio"], "fin": self._form["oferta_fin"]})
            self._ultimo_oferta = "FALSO-O%d" % len(prod["ofertas"])
        elif "bumps" in partes:
            prod["bumps"].append(self._form["bump_codigo"])
        elif "embudo" in partes:
            prod["upsell"] = self._form["upsell_codigo"]
        self._ultimo = partes[1]

    def _leer(self, sel):
        if sel == "codigo_producto":
            return self._ultimo
        if sel == "codigo_oferta":
            return self._ultimo_oferta
        if sel == "estado":
            return self.productos[self._ultimo]["estado"]
        return None


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="Imprime los pasos de un flujo (para hotmart_alta.mjs (hotmart_robot.mjs se borró en la revisión 035 h. 18: no tenía guardas)). Modo seco.")
    ap.add_argument("flujo", choices=FLUJOS)
    ap.add_argument("datos", help="JSON con los datos del flujo")
    ap.add_argument("--autorizacion")
    a = ap.parse_args(argv)
    with open(a.datos, encoding="utf-8") as f:
        print(json.dumps(pasos(a.flujo, json.load(f), a.autorizacion), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
