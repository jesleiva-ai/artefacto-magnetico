#!/usr/bin/env python3
"""hotmart_lector.py — estado de aprobación y ventas por día desde Hotmart (TAREA 036 parte B).

    python herramientas/hotmart_lector.py --of OF-001 [--desde AAAA-MM-DD --hasta AAAA-MM-DD] [--archivo-productos f --archivo-ventas f]

Fuentes, misma salida:
  * API REST de Hotmart con HOTMART_BASIC (credencial «Basic» del dueño en .env): token por client_credentials y
    GET de productos y del historial de ventas. [PENDIENTE: confirmar URLs y campos con la primera lectura real; están
    aisladas en URL_TOKEN / URL_PRODUCTOS / URL_VENTAS].
  * MCP de Hotmart (extensión de claude.ai): un worker llama hotmart_products_list / hotmart_sales_history_list y guarda
    la respuesta en estado/lecturas/; este módulo la parsea. Formato real grabado: {"result": "<json en texto>"}
    (pruebas/fixtures/formato_real/hotmart_mcp_*.json).
Reglas:
  * Aprobado = status ACTIVE. NOT_APPROVED / DRAFT / IN_REVIEW / CHANGES_PENDING_ON_PRODUCT = no aprobado. Otro = None.
  * Nunca se lee ni se guarda nada del comprador (nombre, correo, documento, dirección): el parser toma solo producto,
    transacción, estado, fechas, precio, tarifa y tracking (sck/src para cruzar con utm_content).
  * Neto = precio − tarifa de Hotmart (− comisión de afiliado si viene). Falta el precio o la tarifa → neto None.
  * Una lectura que falla devuelve None (nulo ≠ 0); una lectura exitosa sin ventas es 0 ventas.
Solo biblioteca estándar.
"""
import argparse
import base64
import json
import os
import sys
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

URL_TOKEN = "https://api-sec-vlc.hotmart.com/security/oauth/token"
URL_PRODUCTOS = "https://developers.hotmart.com/products/api/v1/products"
URL_VENTAS = "https://developers.hotmart.com/payments/api/v1/sales/history"
APROBADO = ("ACTIVE",)
NO_APROBADO = ("NOT_APPROVED", "DRAFT", "IN_REVIEW", "CHANGES_PENDING_ON_PRODUCT", "PAUSED", "BLOCKED", "DELETED")
VENTA_VALIDA = ("APPROVED", "COMPLETE")
VENTA_DEVUELTA = ("REFUNDED", "CHARGEBACK", "PARTIALLY_REFUNDED", "PROTESTED")


class LecturaFallida(RuntimeError):
    pass


def _cuerpo(respuesta):
    """MCP: {"result": "<json>"}; API: dict. Devuelve el dict interno."""
    if isinstance(respuesta, dict) and isinstance(respuesta.get("result"), str):
        return json.loads(respuesta["result"])
    if isinstance(respuesta, dict):
        return respuesta
    raise LecturaFallida("respuesta de Hotmart inesperada")


def _num(v):
    if isinstance(v, dict):
        v = v.get("value")
    if v is None or v == "" or isinstance(v, bool):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def parse_productos(respuesta):
    """{id (texto): status} de la lista de productos."""
    return {str(p.get("id")): p.get("status") for p in _cuerpo(respuesta).get("items", [])}


def aprobado(status):
    if status in APROBADO:
        return True
    if status in NO_APROBADO:
        return False
    return None


def _fecha(ms, zona=None):
    if ms is None:
        return None
    try:
        d = datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)
    except (TypeError, ValueError, OverflowError):
        return None
    return d.astimezone(rutas.zona_horaria(zona)).date().isoformat()


def parse_ventas(respuesta, zona=None):
    """Ventas sin datos del comprador: [{transaccion, producto, estado, fecha, precio, tarifa, neto, moneda, sck, src}]."""
    ventas = []
    for it in _cuerpo(respuesta).get("items", []):
        compra = it.get("purchase") or {}
        precio = _num(compra.get("price"))
        tarifa = _num(compra.get("hotmart_fee", {}).get("total") if isinstance(compra.get("hotmart_fee"), dict) else None)
        afiliado = _num((it.get("affiliate_commission") or {}).get("value")) if it.get("affiliate_commission") else 0.0
        neto = None if precio is None or tarifa is None or afiliado is None else round(precio - tarifa - afiliado, 2)
        track = compra.get("tracking") or {}
        ventas.append({"transaccion": compra.get("transaction"), "producto": str((it.get("product") or {}).get("id")),
                       "estado": compra.get("status"), "fecha": _fecha(compra.get("approved_date") or compra.get("order_date"), zona),
                       "precio": precio, "tarifa": tarifa, "neto": neto,
                       "moneda": (compra.get("price") or {}).get("currency_code") if isinstance(compra.get("price"), dict) else None,
                       "sck": track.get("source_sck"), "src": track.get("source"), "oferta": (compra.get("offer") or {}).get("code")})
    return ventas


def por_dia(ventas):
    """{fecha: {compras, brutos, netos, reembolsos}}; un neto desconocido deja netos del día en None."""
    dias = {}
    for v in ventas:
        if not v.get("fecha"):
            continue
        d = dias.setdefault(v["fecha"], {"compras": 0, "brutos": 0.0, "netos": 0.0, "reembolsos": 0})
        if v["estado"] in VENTA_VALIDA:
            d["compras"] += 1
            d["brutos"] = None if (d["brutos"] is None or v["precio"] is None) else round(d["brutos"] + v["precio"], 2)
            d["netos"] = None if (d["netos"] is None or v["neto"] is None) else round(d["netos"] + v["neto"], 2)
        elif v["estado"] in VENTA_DEVUELTA:
            d["reembolsos"] += 1
    return dias


# ------------------------------------------------------------------ lectores
class LectorAPI:
    """API REST con HOTMART_BASIC. `transporte(url, metodo, cabeceras, datos) -> dict` inyectable (pruebas)."""

    def __init__(self, basic, transporte=None):
        self._basic = basic
        self.t = transporte or _http
        self._token = None

    def _cabeceras(self):
        if self._token is None:
            r = self.t(URL_TOKEN + "?grant_type=client_credentials", "POST", {"Authorization": "Basic " + self._basic}, b"")
            self._token = r.get("access_token")
            if not self._token:
                raise LecturaFallida("Hotmart no devolvió token")
        return {"Authorization": "Bearer " + self._token, "Content-Type": "application/json"}

    def productos(self, producto_id=None):
        q = "?" + urllib.parse.urlencode({"id": producto_id}) if producto_id else ""
        return self.t(URL_PRODUCTOS + q, "GET", self._cabeceras(), None)

    def ventas(self, producto_id, desde_ms, hasta_ms):
        items, token = [], None
        while True:
            q = {"product_id": producto_id, "start_date": desde_ms, "end_date": hasta_ms, "max_results": 500}
            if token:
                q["page_token"] = token
            r = self.t(URL_VENTAS + "?" + urllib.parse.urlencode(q), "GET", self._cabeceras(), None)
            items += r.get("items", [])
            token = (r.get("page_info") or {}).get("next_page_token")
            if not token:
                return {"items": items}


class LectorArchivo:
    """Respuestas del MCP guardadas por un worker."""

    def __init__(self, productos=None, ventas=None):
        self.p, self.v = productos, ventas

    def productos(self, producto_id=None):
        return json.loads(Path(self.p).read_text(encoding="utf-8"))

    def ventas(self, producto_id, desde_ms, hasta_ms):
        return json.loads(Path(self.v).read_text(encoding="utf-8"))


def _http(url, metodo, cabeceras, datos):   # lectura-gratuita: GET/token de la API de Hotmart, sin escritura
    req = urllib.request.Request(url, data=datos, method=metodo, headers=cabeceras or {})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode("utf-8"))


def _basic_desde_claves(claves):
    """HOTMART_BASIC directo (con o sin el prefijo «Basic »), o armado desde HOTMART_CLIENT_ID + HOTMART_CLIENT_SECRET
    (base64 de «id:secret», que es lo que Hotmart muestra al crear la credencial). Nunca imprime valores."""
    def _get(n):
        v = os.environ.get(n)
        if v is None:
            try:
                v = claves.clave(n) if claves.estado().get(n) else None
            except Exception:
                v = None
        return (v or "").strip().strip('"').strip("'") or None
    b = _get("HOTMART_BASIC")
    if b:
        return b[6:].strip() if b.lower().startswith("basic ") else b
    cid, sec = _get("HOTMART_CLIENT_ID"), _get("HOTMART_CLIENT_SECRET")
    if cid and sec:
        return base64.b64encode(("%s:%s" % (cid, sec)).encode("utf-8")).decode("ascii")
    return None


def lector_por_defecto(of, fecha=None):
    try:
        import claves
        basic = _basic_desde_claves(claves)
    except Exception:
        basic = None
    if basic:
        return LectorAPI(basic)
    f = fecha or rutas.hoy()
    pp = rutas.ruta("estado", "lecturas", "hotmart_productos_%s.json" % f)
    pv = rutas.ruta("estado", "lecturas", "hotmart_ventas_%s_%s.json" % (of, f))
    if pp.exists() or pv.exists():
        return LectorArchivo(pp if pp.exists() else None, pv if pv.exists() else None)
    return None


def producto_de(of):
    """Código del producto principal: `codigo` o `producto_id` (F61: externo.local.json usa producto_id)."""
    p = (rutas.externo(of).get("hotmart") or {}).get("principal") or {}
    return str(p.get("codigo") or p.get("producto_id") or "") or None


def estado_aprobacion(of, lector=None):
    """{"aprobado": True|False|None, "status": str|None}. None en aprobado = no se pudo saber (no avanza)."""
    lector = lector or lector_por_defecto(of)
    pid = producto_de(of)
    if lector is None or pid is None:
        return {"aprobado": None, "status": None, "motivo": "sin lector de Hotmart o sin código de producto en externo.local.json"}
    try:
        st = parse_productos(lector.productos(pid)).get(pid)
    except Exception as e:
        return {"aprobado": None, "status": None, "motivo": "lectura fallida: %s" % type(e).__name__}
    return {"aprobado": aprobado(st), "status": st, "motivo": "status %s" % st}


def _ms(fecha_iso, fin=False):
    d = datetime.fromisoformat(fecha_iso + ("T23:59:59" if fin else "T00:00:00")).replace(tzinfo=rutas.zona_horaria())
    return int(d.timestamp() * 1000)


def ventas(of, desde, hasta, lector=None):
    """{"por_dia": {...}, "compras", "netos", "ventas": [...]} o None si la lectura falló (nulo ≠ 0)."""
    lector = lector or lector_por_defecto(of, hasta)
    pid = producto_de(of)
    if lector is None or pid is None:
        return None
    try:
        vs = [v for v in parse_ventas(lector.ventas(pid, _ms(desde), _ms(hasta, True))) if v["producto"] in (pid, "None")]
    except Exception:
        return None
    dias = por_dia(vs)
    netos = 0.0
    for d in dias.values():
        netos = None if (netos is None or d["netos"] is None) else round(netos + d["netos"], 2)
    return {"por_dia": dias, "compras": sum(d["compras"] for d in dias.values()), "netos": netos, "ventas": vs}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Lee aprobación y ventas por día de un producto en Hotmart (sin datos del comprador).")
    ap.add_argument("--of", required=True)
    ap.add_argument("--desde")
    ap.add_argument("--hasta")
    ap.add_argument("--archivo-productos")
    ap.add_argument("--archivo-ventas")
    a = ap.parse_args()
    of = rutas.validar_of(a.of)
    lec = LectorArchivo(a.archivo_productos, a.archivo_ventas) if (a.archivo_productos or a.archivo_ventas) else None
    ap_ = estado_aprobacion(of, lec)
    hoy = rutas.hoy()
    v = ventas(of, a.desde or hoy, a.hasta or hoy, lec) if (lec is None or a.archivo_ventas) else None
    print("aprobado:", ap_["aprobado"], "| status:", ap_["status"])
    print("compras:", None if v is None else v["compras"], "| netos:", None if v is None else v["netos"])
    ok = ap_["aprobado"] is not None
    print(json.dumps({"ok": ok, "codigo": 0 if ok else 3, "motivo": ap_["motivo"], "artefactos": []}, ensure_ascii=False))
    sys.exit(0 if ok else 3)
