// Origen: hyperflujo/herramientas/hotmart_navegador.mjs (copia del taller; [PENDIENTE: traducir códigos de salida a PLAN §3.8 en recetas/hotmart/RECETA.md]).
// Navegador para Hotmart (D69): dos vías, el mismo código para la sesión y el alta. Nunca credenciales.
//
// Vía 1 «perfil» (por defecto): Chrome real con perfil propio en operacion/sesiones/hotmart-perfil/ (fuera de git).
//   La cookie de sesión de Hotmart (SSO) muere al cerrar Chrome, así que ese Chrome se lanza como proceso aparte
//   («perfil vivo»: chrome.exe directo, sin marcas de automatización, con depuración solo en 127.0.0.1:9223) y queda
//   abierto: Ramiro entra una vez y el alta se conecta a esa ventana. `hotmart_sesion.mjs --cerrar` lo cierra.
// Vía 2 «cdp»: Ramiro abre SU Chrome con --remote-debugging-port=9222 y entra a Hotmart como siempre; el script se conecta
//   (connectOverCDP) y abre UNA pestaña propia: no lee, no navega ni cierra ninguna otra pestaña, y solo trabaja sobre
//   hotmart.com. Al terminar cierra su pestaña y se desconecta sin cerrar el Chrome de Ramiro.
// Vía «prueba» (solo tests): Chromium de Playwright sin sesión, para el panel falso local.
import { chromium } from 'playwright';
import { existsSync, mkdirSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const PERFIL = join(RAIZ, 'operacion', 'sesiones', 'hotmart-perfil');
export const CDP_DEFECTO = 'http://127.0.0.1:9222';
export const APP = 'https://app.hotmart.com/';
export const PUERTO_PERFIL = 9223;
const URL_PERFIL = `http://127.0.0.1:${PUERTO_PERFIL}`;

export async function perfilVivo() {
  try {
    const r = await fetch(`${URL_PERFIL}/json/version`, { signal: AbortSignal.timeout(1500) });
    return r.ok;
  } catch { return false; }
}

// TAREA 036 C: CHROME_PATH primero; después las ubicaciones estándar de Windows, macOS y Linux.
export function chromeExe() {
  if (process.env.CHROME_PATH) {
    if (existsSync(process.env.CHROME_PATH)) return process.env.CHROME_PATH;
    throw new Error('CHROME_PATH no apunta a un archivo existente.');
  }
  const win = ['ProgramFiles', 'ProgramFiles(x86)', 'LOCALAPPDATA'].filter((v) => process.env[v])
    .map((v) => join(process.env[v], 'Google', 'Chrome', 'Application', 'chrome.exe'));
  const c = process.platform === 'win32' ? win
    : process.platform === 'darwin' ? ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']
      : ['/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser'];
  const e = c.find((x) => x && existsSync(x));
  if (!e) throw new Error('No encuentro Google Chrome instalado (fijar CHROME_PATH).');
  return e;
}

// Lanza el Chrome del perfil como proceso independiente (sigue abierto aunque el script termine).
export async function lanzarPerfilVivo(perfil = PERFIL) {
  if (await perfilVivo()) return true;
  mkdirSync(perfil, { recursive: true });
  const p = spawn(chromeExe(), [`--user-data-dir=${perfil}`, `--remote-debugging-port=${PUERTO_PERFIL}`,
    '--remote-debugging-address=127.0.0.1', '--no-first-run', '--no-default-browser-check', APP],
  { detached: true, stdio: 'ignore' });
  p.unref();
  const fin = Date.now() + 30000;
  while (Date.now() < fin) { if (await perfilVivo()) return true; await new Promise((r) => setTimeout(r, 500)); }
  throw new Error('Chrome del perfil no respondió en el puerto local.');
}

// Logueado = estamos en app.hotmart.com y no en una pantalla de login/sso.
export const logueado = (url) => /^https:\/\/app\.hotmart\.com\//.test(url) && !/login|signin|sso\.|\/auth\//i.test(url);

// Chequeo firme (no solo la URL al instante): Hotmart redirige al SSO por JavaScript después de cargar, así que se
// espera a que la URL se asiente y además no tiene que haber un campo de clave en pantalla. Dos lecturas iguales.
export async function estaLogueado(pagina, asentarMs = 4000) {
  await pagina.waitForTimeout(asentarMs);
  for (let i = 0; i < 2; i++) {
    if (!logueado(pagina.url())) return false;
    if (await pagina.locator('input[type=password]').count().catch(() => 0)) return false;
    if (i === 0) await pagina.waitForTimeout(2000);
  }
  return true;
}

// Pestaña permitida para el script: hotmart.com (o la pestaña nueva en blanco). file:// solo en tests.
export const esHotmart = (url, permitirArchivo = false) =>
  /^https:\/\/([a-z0-9-]+\.)*hotmart\.com(\/|$)/i.test(url) || url === 'about:blank' || (permitirArchivo && url.startsWith('file://'));

export function perfilExiste(perfil = PERFIL) { return existsSync(perfil); }

export async function abrir({ via = 'perfil', visible = true, cdp = CDP_DEFECTO, perfil = PERFIL, propia = true } = {}) {
  if (via === 'perfil' && await perfilVivo()) {
    // Chrome del perfil ya abierto (lanzarPerfilVivo): es nuestro, no el de Ramiro. propia=false reutiliza su pestaña
    // visible (para el login); propia=true abre una pestaña nueva y al terminar solo cierra esa.
    const navegador = await chromium.connectOverCDP(URL_PERFIL);
    const contexto = navegador.contexts()[0];
    const existente = contexto.pages().find((p) => esHotmart(p.url()));
    const pagina = !propia && existente ? existente : await contexto.newPage();
    return { via: 'perfil-vivo', contexto, pagina, navegador,
      cerrar: async () => { if (propia) await pagina.close().catch(() => {}); } };
  }
  if (via === 'perfil') {
    mkdirSync(perfil, { recursive: true });
    let contexto;
    try {
      contexto = await chromium.launchPersistentContext(perfil, { channel: 'chrome', headless: !visible, viewport: { width: 1366, height: 900 } });
    } catch (e) {
      throw new Error('No se pudo abrir Chrome con el perfil de Hotmart (¿Chrome instalado? ¿perfil abierto en otra ventana del script?): '
        + String(e.message).split('\n')[0]);
    }
    const pagina = contexto.pages()[0] || await contexto.newPage();
    return { via, contexto, pagina, cerrar: async () => { await contexto.close().catch(() => {}); } };
  }
  if (via === 'cdp') {
    let navegador;
    throw new Error('Vía «cdp» al Chrome personal del dueño eliminada (revisión 035 h. 18): cualquier proceso local podría navegar con todas sus sesiones. Usar la vía «perfil» (operacion/sesiones/).');
    try { navegador = await chromium.connectOverCDP(cdp); } catch (e) {
      throw new Error(`No hay Chrome escuchando en ${cdp}: Ramiro tiene que abrir su Chrome con --remote-debugging-port=9222 (ver RECETA.md).`);
    }
    const contexto = navegador.contexts()[0];
    if (!contexto) throw new Error('El Chrome conectado no tiene contexto por defecto.');
    const pagina = await contexto.newPage();     // pestaña propia; las demás no se tocan
    return { via, contexto, pagina, cerrar: async () => { await pagina.close().catch(() => {}); } };
    // sin navegador.close(): no se cierra el Chrome de Ramiro; el proceso se desconecta al salir
  }
  if (via === 'prueba') {
    let navegador;
    for (const extra of [{}, { channel: 'chrome' }, { channel: 'msedge' }]) {
      try { navegador = await chromium.launch({ headless: !visible, ...extra }); break; } catch { /* siguiente */ }
    }
    if (!navegador) throw new Error('No se pudo abrir el navegador de prueba.');
    const contexto = await navegador.newContext({ viewport: { width: 1366, height: 900 } });
    const pagina = await contexto.newPage();
    return { via, contexto, pagina, cerrar: async () => { await navegador.close(); } };
  }
  throw new Error(`Vía desconocida: ${via} (perfil | cdp)`);
}
