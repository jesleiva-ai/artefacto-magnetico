// Flujo «quitar_archivo» del robot de Hotmart (OF-006, 2026-10-23): elimina de «Contenido del Producto» SOLO el archivo
// identificado como versión vieja (v1) de un PDF que está subido dos veces con el mismo nombre, y verifica después que
// quede exactamente la versión vigente (v2, la del repo). Selectores: recetas/hotmart/selectores.json → «quitar_archivo».
//
//   node herramientas/hotmart_quitar_archivo.mjs --producto <id> --archivo <nombre.pdf> --v2 <ruta del PDF vigente> --modo seco
//   node herramientas/hotmart_quitar_archivo.mjs ... --modo real --ej <registro.json> --pieza <pieza> --oferta OF-NNN
//        --ok "<texto literal del OK del dueño>" --ok-de "<quién, canal, fecha>"
//   opciones: --salida <carpeta> (por defecto resultados/ de la EJ o la carpeta temporal) · --panel-falso <ruta.html> (solo pruebas)
//
// Identificación (sin descargar nada): en la pantalla hay exactamente DOS tarjetas con ese nombre; la v2 es la que muestra
// el tamaño del PDF vigente (bytes/1024 con un decimal, como lo muestra Hotmart) y la v1 es la otra. Cualquier otra
// situación (una sola tarjeta, tres, ninguna con el tamaño vigente, dos iguales) = ambiguo: para sin tocar nada.
// Seco: marca en rojo el botón «Eliminar» de la v1, captura y NO lo pulsa.
// Real: registra la solicitud ANTES (regla 6, gratuita), pulsa «Eliminar» de la v1, confirma el diálogo solo si su botón
// es un «Eliminar/Confirmar» y el diálogo no pide clave, código, captcha ni aceptar términos; recarga y verifica que
// quede una sola tarjeta con ese nombre y el tamaño de la v2. Nunca credenciales; si la sesión venció, para.
// Códigos: 0 ok · 4 no se encontró/ambiguo · 5 sesión vencida o fuera de hotmart · 6 captcha · 7 verificación falló ·
//          8 diálogo no autorizado o sin confirmación · 1 registro · 2 uso.
import { abrir, esHotmart, logueado } from './hotmart_navegador.mjs';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PY = existsSync(join(RAIZ, '.venv', 'Scripts', 'python.exe')) ? join(RAIZ, '.venv', 'Scripts', 'python.exe') : 'python';

export const kbHotmart = (bytes) => (Math.round((bytes / 1024) * 10) / 10).toFixed(1);
const norm = (kb) => String(kb).replace(',', '.');

// Tarjetas leídas [{indice, nombre, kb}] → {v1, v2} o {error}. Función pura (se prueba sin navegador).
export function identificar(tarjetas, archivo, bytesV2) {
  const kbV2 = kbHotmart(bytesV2);
  const mismas = tarjetas.filter((t) => t.nombre === archivo);
  if (mismas.length !== 2) return { error: `hay ${mismas.length} tarjeta(s) «${archivo}» (se esperaban 2: v1 y v2)`, kbV2 };
  const v2 = mismas.filter((t) => norm(t.kb) === kbV2);
  if (v2.length !== 1) return { error: `${v2.length} tarjeta(s) con el tamaño de la v2 (${kbV2} KB): ambiguo`, kbV2 };
  const v1 = mismas.find((t) => t !== v2[0]);
  return { v1, v2: v2[0], kbV2 };
}

// Después de quitar: exactamente una tarjeta con ese nombre y es la v2.
export function verificar(tarjetas, archivo, bytesV2, antes) {
  const kbV2 = kbHotmart(bytesV2);
  const mismas = tarjetas.filter((t) => t.nombre === archivo);
  const ok = mismas.length === 1 && norm(mismas[0].kb) === kbV2 && (antes == null || tarjetas.length === antes - 1);
  return { ok, quedan: mismas.map((t) => `${t.nombre} ${t.kb} KB`), total: tarjetas.length, kbV2 };
}

function registro(...a) {
  try { return { codigo: 0, salida: execFileSync(PY, [join(RAIZ, 'herramientas', 'hotmart_registro.py'), ...a], { encoding: 'utf8', env: { ...process.env, PYTHONIOENCODING: 'utf-8' } }).trim() }; }
  catch (e) { return { codigo: e.status ?? 1, salida: String(e.stdout || e.message).trim() }; }
}

function args(argv) {
  const a = { modo: 'seco' };
  for (let i = 0; i < argv.length; i++) if (argv[i].startsWith('--')) a[argv[i].slice(2)] = argv[++i];
  return a;
}

async function leerTarjetas(pagina, s) {
  const tarjetas = pagina.locator(s.tarjeta);
  const n = await tarjetas.count();
  const r = [];
  for (let i = 0; i < n; i++) {
    const t = (await tarjetas.nth(i).innerText().catch(() => '')).replace(/\s+/g, ' ').trim();
    const m = t.match(new RegExp(s.texto_tarjeta_regex, 'i'));
    if (m) r.push({ indice: i, nombre: m[1], kb: m[2].replace(',', '.') });
  }
  return r;
}

export async function correr(a, abrirNav = abrir) {
  if (!a.producto || !a.archivo || !a.v2) throw new Error('faltan --producto, --archivo o --v2');
  if (!['seco', 'real'].includes(a.modo)) throw new Error('--modo seco | real');
  if (a.modo === 'real' && !(a.ej && a.ok && a['ok-de'] && a.pieza && a.oferta)) throw new Error('--modo real exige --ej, --pieza, --oferta, --ok y --ok-de (regla 4, OK escrito del dueño).');
  const sel = JSON.parse(readFileSync(a.selectores || join(RAIZ, 'recetas', 'hotmart', 'selectores.json'), 'utf8').replace(/^﻿/, ''));
  const s = sel.quitar_archivo;
  const bytesV2 = statSync(resolve(a.v2)).size;
  const falso = !!a['panel-falso'];
  const salida = resolve(a.salida || (a.ej ? join(dirname(resolve(a.ej)), 'resultados', `quitar_archivo_${a.modo}_${a.producto}`) : join(tmpdir(), `quitar_archivo_${a.modo}_${a.producto}`)));
  mkdirSync(salida, { recursive: true });
  const url = falso ? pathToFileURL(resolve(a['panel-falso'].split('?')[0])).href + (a['panel-falso'].includes('?') ? '?' + a['panel-falso'].split('?')[1] : '') : sel.urls.contenido.replace('{{producto_id}}', a.producto);
  const res = { modo: a.modo, fecha: new Date().toISOString(), producto_id: a.producto, archivo: a.archivo, kb_v2: kbHotmart(bytesV2), codigo: 0, pasos: [] };
  const log = (paso, estado, detalle = null) => { res.pasos.push({ paso, estado, detalle }); console.log(`${estado.padEnd(10)} ${paso}${detalle ? ' — ' + (typeof detalle === 'string' ? detalle : JSON.stringify(detalle)) : ''}`); };
  if (a.modo === 'real' && registro('estado', resolve(a.ej)).codigo === 3) throw new Error('registro en envio_incierto: conciliar antes (regla 7)');
  const nav = await abrirNav({ via: falso ? 'prueba' : 'perfil', propia: true });
  const p = nav.pagina;
  const enPanel = () => esHotmart(p.url(), falso) && (falso || logueado(p.url()));
  const cap = (n) => p.screenshot({ path: join(salida, n + '.png'), fullPage: true, timeout: 15000 }).catch(() => {});
  let sid = null;
  try {
    await p.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await p.waitForTimeout(falso ? 300 : (s.espera_ms ?? 7000));
    if (!enPanel()) { log('abrir', 'PARADO', 'sesión vencida o fuera de hotmart.com'); res.codigo = 5; return res; }
    if (await p.locator('iframe[src*="captcha"], iframe[title*="captcha" i]').count().catch(() => 0)) { log('abrir', 'PARADO', 'captcha'); res.codigo = 6; return res; }
    const antes = await leerTarjetas(p, s);
    res.antes = antes;
    await cap('01_antes');
    const id = identificar(antes, a.archivo, bytesV2);
    if (id.error) { log('identificar', 'FALTA', id.error); res.codigo = 4; return res; }
    res.v1 = id.v1; res.v2 = id.v2;
    log('identificar', 'OK', `v1 = tarjeta ${id.v1.indice + 1} (${id.v1.kb} KB) · v2 = tarjeta ${id.v2.indice + 1} (${id.v2.kb} KB, igual al PDF del repo)`);
    const tarjeta = p.locator(s.tarjeta).nth(id.v1.indice);
    const boton = tarjeta.locator(s.eliminar).first();
    if (!(await boton.count())) { log('eliminar', 'FALTA', 'sin botón Eliminar en la tarjeta v1'); res.codigo = 4; return res; }
    // relectura inmediata de la tarjeta a pulsar: tiene que seguir siendo la v1
    const txt = (await tarjeta.innerText()).replace(/\s+/g, ' ');
    if (!txt.includes(a.archivo) || !new RegExp(`\\b${id.v1.kb.replace('.', '[.,]')}\\s*KB`, 'i').test(txt)) { log('eliminar', 'FALTA', 'la tarjeta cambió antes del clic'); res.codigo = 4; return res; }
    if (a.modo === 'seco') {
      await boton.evaluate((e) => { e.style.outline = '4px solid #d00'; e.closest('[data-slot=card]')?.style.setProperty('outline', '3px dashed #d00'); });
      await tarjeta.scrollIntoViewIfNeeded().catch(() => {});
      await cap('02_v1_eliminar_NO_SE_PULSA');
      log('eliminar', 'SECO', `botón «${await boton.getAttribute('title')}» de la v1 encontrado y marcado; no se pulsa`);
      return res;
    }
    // --- real ---
    const r = registro('inicio', resolve(a.ej), `quitar_archivo:${a.oferta}:${a.pieza}:v1`, JSON.stringify({ herramienta: 'hotmart_quitar_archivo.mjs', producto_id: a.producto,
      archivo: a.archivo, kb_v1: id.v1.kb, kb_v2: id.v2.kb, ok_dueno: a.ok, ok_de: a['ok-de'], fecha_ok_registrada: new Date().toISOString() }));
    if (r.codigo !== 0) { log('registro', 'PARADO', r.salida); res.codigo = 1; return res; }
    sid = r.salida;
    await boton.click({ timeout: 10000 });
    await p.waitForTimeout(1500);
    const dlg = p.locator(s.dialogo).filter({ visible: true }).first();
    const hayDialogo = await dlg.waitFor({ state: 'visible', timeout: 6000 }).then(() => true).catch(() => false);
    if (hayDialogo) {
      const texto = (await dlg.innerText()).replace(/\s+/g, ' ').trim();
      const botones = (await dlg.locator('button').allInnerTexts()).map((x) => x.trim()).filter(Boolean);
      res.dialogo = { texto: texto.slice(0, 500), botones };
      await cap('02_dialogo');
      log('dialogo', 'OK', res.dialogo);
      if (new RegExp(s.dialogo_prohibido, 'i').test(texto) || await dlg.locator('input[type=password]').count()) {
        await p.keyboard.press('Escape'); log('dialogo', 'PARADO', 'el diálogo pide algo no autorizado'); res.codigo = 8;
      } else if (!new RegExp(s.dialogo_esperado_regex, 'i').test(texto)) {
        await p.keyboard.press('Escape'); log('dialogo', 'PARADO', 'el diálogo no es la confirmación de quitar el archivo'); res.codigo = 8;
      } else {
        const conf = dlg.locator('button').filter({ hasText: new RegExp(s.confirmar_regex, 'i') }).filter({ hasNotText: /cancel|^\s*no\s*$/i });
        const nConf = await conf.count();
        if (nConf !== 1) { await p.keyboard.press('Escape'); log('dialogo', 'PARADO', nConf ? 'más de un botón de confirmación' : 'sin botón de confirmación reconocible'); res.codigo = 8; }
        else { const t = (await conf.innerText()).trim(); await conf.click({ timeout: 10000 }); log('confirmar', 'OK', `«${t}»`); }
      }
    } else log('dialogo', 'AVISO', 'no apareció diálogo de confirmación');
    await p.waitForTimeout(falso ? 300 : 4000);
    await cap('03_despues_clic');
    if (res.codigo === 8) {
      const sigue = identificar(await leerTarjetas(p, s), a.archivo, bytesV2);
      if (!sigue.error) { registro('rechazo', resolve(a.ej), sid, 'no se confirmó la eliminación: ' + res.pasos.at(-1).detalle); sid = null; }
      return res;
    }
    if (!falso) { await p.reload({ waitUntil: 'domcontentloaded', timeout: 60000 }); await p.waitForTimeout(s.espera_ms ?? 7000); }
    if (!enPanel()) { log('verificar', 'PARADO', 'sesión vencida al recargar'); res.codigo = 5; return res; }
    const despues = await leerTarjetas(p, s);
    res.despues = despues;
    await cap('04_verificado');
    const v = verificar(despues, a.archivo, bytesV2, antes.length);
    res.verificacion = v;
    if (v.ok) {
      const ri = registro('id', resolve(a.ej), sid, `${a.producto}:quitado:${a.archivo}:${id.v1.kb}KB`); sid = null;
      log('verificar', 'OK', `queda solo ${v.quedan.join(', ')} (${ri.salida})`);
    } else {
      // nada se quitó (la v1 sigue) → rechazo; si cambió otra cosa, queda «enviando» para conciliar a mano (regla 7)
      if (!identificar(despues, a.archivo, bytesV2).error) { registro('rechazo', resolve(a.ej), sid, 'la v1 sigue en el panel después del clic'); sid = null; }
      log('verificar', 'FALLA', v); res.codigo = 7;
    }
    return res;
  } finally {
    if (sid) log('registro', 'INCIERTO', `${sid} quedó «enviando»: conciliar en el panel antes de repetir`);
    writeFileSync(join(salida, 'resumen.json'), JSON.stringify(res, null, 1) + '\n', 'utf8');
    await nav.cerrar();
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const r = await correr(args(process.argv.slice(2)));
    console.log(JSON.stringify({ codigo: r.codigo, v1: r.v1 || null, verificacion: r.verificacion || null }));
    process.exit(r.codigo);
  } catch (e) { console.error('ERROR: ' + e.message); process.exit(2); }
}
