#!/usr/bin/env python3
"""Registro de las altas de Hotmart que hace hotmart_alta.mjs (TAREA 032 act. 10, D69). Solo stdlib.
Origen: hyperflujo/herramientas/hotmart_registro.py (copia SIN ADAPTAR — [PENDIENTE: MOTIVO con texto del taller; usar dueno.local.json y rutas.py]). No se importa en la suite.

    python herramientas/hotmart_registro.py estado  <registro.json>                # sale 3 si hay envío incierto
    python herramientas/hotmart_registro.py inicio  <registro.json> <clave> '<json parámetros>'   # imprime SOL-NNN
    python herramientas/hotmart_registro.py id      <registro.json> <SOL> <id Hotmart>
    python herramientas/hotmart_registro.py rechazo <registro.json> <SOL> "<error>"

Crear un producto en borrador no cobra: solicitud gratuita (regla 5). Orden de la regla 6: inicio (planificada →
enviando) → un solo clic de guardar → id apenas se lee. Si el navegador se cierra entre el clic y el id, la solicitud
queda «enviando» y al reabrir el registro pasa a envio_incierto: conciliar con hotmart_products_list antes de repetir.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import registro as R  # noqa: E402

MOTIVO = ("Alta de producto en Hotmart en BORRADOR con el navegador sobre la sesión del dueño (D69): Hotmart no cobra "
          "por crear ni guardar productos; no se activan ventas.")


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 2
    cmd, ruta = argv[1], argv[2]
    try:
        if cmd == "estado":
            reg = R.abrir(ruta)
            print(reg["estado"])
            return 3 if reg["estado"] == "envio_incierto" else 0
        if cmd == "inicio":
            sid = R.agregar_solicitud(ruta, "api", "hotmart", clave=argv[3], estimado=0, gratuita=True,
                                      motivo_gratuita=MOTIVO, parametros=json.loads(argv[4]) if len(argv) > 4 else {})
            R.marcar_enviando(ruta, sid)
            print(sid)
            return 0
        if cmd == "id":
            R.guardar_id_externo(ruta, argv[3], argv[4])
            R.cambiar_estado(ruta, "completada", solicitud_id=argv[3])
            print("%s -> %s" % (argv[3], argv[4]))
            return 0
        if cmd == "rechazo":
            R.marcar_rechazada(ruta, argv[3], argv[4])
            print("%s -> fallida" % argv[3])
            return 0
    except R.ErrorRegistro as e:
        print("ERROR: %s" % e)
        return 1
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
