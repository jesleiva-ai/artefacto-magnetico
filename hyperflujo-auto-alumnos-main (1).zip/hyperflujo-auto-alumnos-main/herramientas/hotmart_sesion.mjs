// Origen: hyperflujo/herramientas/hotmart_sesion.mjs (copia del taller; [PENDIENTE: traducir códigos de salida a PLAN §3.8 en recetas/hotmart/RECETA.md]).
// Sesión de Hotmart para el alta automatizada (TAREA 032 act. 10, D69).
//
//   node herramientas/hotmart_sesion.mjs                  # vía 1: abre Chrome real VISIBLE con el perfil y lo deja abierto
//   node herramientas/hotmart_sesion.mjs --cerrar         # cierra ese Chrome (la sesión de Hotmart se pierde: hay que reentrar)
//   node herramientas/hotmart_sesion.mjs --verificar      # ¿sigue abierta la sesión del perfil? (sin mostrarla)
//   node herramientas/hotmart_sesion.mjs --cdp [url]      # vía 2: verifica la sesión en el Chrome de Ramiro (puerto 9222)
//   opción: --espera-min N (por defecto 0 = sin límite)
//
// Ramiro inicia sesión él mismo. Este script NUNCA lee ni escribe usuario, clave, código de verificación ni captcha: no
// toca ningún campo, solo espera a que la URL deje de ser la del login. La sesión queda en el perfil
// operacion/sesiones/hotmart-perfil/ (fuera de git) o en el Chrome de Ramiro (vía 2). Nada se imprime ni se copia.
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { abrir, estaLogueado, perfilExiste, perfilVivo, lanzarPerfilVivo, APP, CDP_DEFECTO, PUERTO_PERFIL } from './hotmart_navegador.mjs';

const argv = process.argv.slice(2);
const iEspera = argv.indexOf('--espera-min');
const ESPERA_MIN = iEspera >= 0 ? Number(argv[iEspera + 1]) : 0;
const ESPERA_MS = ESPERA_MIN > 0 ? ESPERA_MIN * 60 * 1000 : Infinity;

async function verificar(via, cdp) {
  if (via === 'perfil' && !perfilExiste()) { console.log('Sesión de Hotmart: no hay perfil (correr sin --verificar y hacer el login).'); return 2; }
  const n = await abrir({ via, visible: false, cdp });
  try {
    await n.pagina.goto(APP, { waitUntil: 'domcontentloaded', timeout: 60000 });
    const ok = await estaLogueado(n.pagina);
    console.log(`Sesión de Hotmart (${via}): ${ok ? 'abierta' : 'no iniciada o vencida'}`);
    return ok ? 0 : 1;
  } finally { await n.cerrar(); }
}

async function cerrar() {
  if (!(await perfilVivo())) { console.log('El Chrome del perfil no está abierto.'); return 0; }
  const b = await chromium.connectOverCDP(`http://127.0.0.1:${PUERTO_PERFIL}`);
  await b.close();
  console.log('Chrome del perfil de Hotmart cerrado.');
  return 0;
}

async function login() {
  await lanzarPerfilVivo();
  const n = await abrir({ via: 'perfil', visible: true, propia: false });
  try {
    await n.pagina.goto(APP, { waitUntil: 'domcontentloaded', timeout: 60000 });
    if (await estaLogueado(n.pagina)) { console.log('SESION_OK: el Chrome del perfil ya tiene la sesión de Hotmart abierta (queda abierto).'); return 0; }
    console.log('VENTANA_ABIERTA: Ramiro, iniciá sesión en Hotmart en esta ventana de Chrome (usuario, clave y verificación los ponés vos).');
    console.log('El script no toca ningún campo y espera sin límite. NO cierres esa ventana de Chrome: la sesión vive mientras esté abierta.');
    const limite = Date.now() + ESPERA_MS;
    let avisoCaptcha = false;
    while (Date.now() < limite) {
      if (n.pagina.isClosed()) { console.log('La ventana se cerró antes del login: relanzar el script.'); return 1; }
      if (await estaLogueado(n.pagina, 0)) break;
      if (!avisoCaptcha && await n.pagina.locator('iframe[src*="captcha"], iframe[title*="captcha" i]').count().catch(() => 0)) {
        console.log('Hay un captcha o una verificación: resolvelo vos; el script espera.');
        avisoCaptcha = true;
      }
      await n.pagina.waitForTimeout(1500);
    }
    if (!(await estaLogueado(n.pagina, 0))) { console.log(`Pasaron ${ESPERA_MIN} min sin login: relanzar el script.`); return 1; }
    await n.pagina.waitForTimeout(3000);   // que el panel termine de guardar sus cookies en el perfil
    console.log('SESION_OK: sesión de Hotmart abierta en el Chrome del perfil (queda abierto; cerrarlo con --cerrar al terminar).');
    return 0;
  } finally { await n.cerrar(); }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const iCdp = argv.indexOf('--cdp');
  let codigo;
  try {
    if (iCdp >= 0) codigo = await verificar('cdp', argv[iCdp + 1] && !argv[iCdp + 1].startsWith('--') ? argv[iCdp + 1] : CDP_DEFECTO);
    else if (argv.includes('--cerrar')) codigo = await cerrar();
    else if (argv.includes('--verificar')) codigo = await verificar('perfil');
    else codigo = await login();
  } catch (e) { console.log('ERROR: ' + e.message); codigo = 2; }
  process.exit(codigo);
}
