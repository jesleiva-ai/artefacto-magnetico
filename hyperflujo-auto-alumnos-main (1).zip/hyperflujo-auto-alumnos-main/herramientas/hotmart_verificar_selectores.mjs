// hotmart_verificar_selectores.mjs — verifica recetas/hotmart/selectores.json contra el panel de Hotmart SOLO LEYENDO
// (TAREA 036 parte E). Nunca hace clic, nunca llena, nunca sube nada: solo navega (goto) a pantallas que no cambian
// nada y cuenta cuántos elementos encuentra cada selector.
//
//   node herramientas/hotmart_verificar_selectores.mjs --producto <id>          # panel real con la sesión del robot
//   node herramientas/hotmart_verificar_selectores.mjs --panel-falso <carpeta>  # pruebas: HTML locales (file://)
//
// Panel real: usa el Chrome del perfil del robot SOLO si ya está abierto y logueado (127.0.0.1:9223, hotmart_sesion.mjs).
// No lo lanza ni pide login: si no está, sale con código 3 y la verificación queda [PENDIENTE]. Abre una pestaña propia y
// al terminar cierra solo esa. Dominio limitado a app.hotmart.com. El ID del producto entra por argumento y no se guarda.
// Salida: JSON con el conteo por selector (sin IDs), y con --capturar <carpeta> deja HTML mínimos reconstruidos con los
// atributos de los elementos encontrados (tag, id, name, type, data-testid, accept, rol y rótulo corto saneado): el
// panel_falso de las pruebas, sin datos del dueño.
import { writeFileSync, mkdirSync, readFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const argv = process.argv.slice(2);
const opt = (k) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
const PRODUCTO = opt('--producto');
const FALSO = opt('--panel-falso');
const CAPTURAR = opt('--capturar');
const SELECTORES = opt('--selectores') || join(RAIZ, 'recetas', 'hotmart', 'selectores.json');
const MUESTRA = { categoria: opt('--categoria') || 'Entretenimiento' };   // {{dato}} de ejemplo para contar selectores con plantilla

// Pantallas que se pueden abrir sin efectos (ir y mirar). Lo que exige clics previos queda «no verificable sin interacción».
const PANTALLAS = [
  { id: 'alta_formato', url: 'https://app.hotmart.com/products/add', pasos: ['tipo_ebook', 'continuar_tipo'] },
  { id: 'alta_info', url: 'https://app.hotmart.com/products/add/4/info', pasos: ['nombre', 'descripcion', 'idioma', 'categoria', 'portada', 'continuar_info'] },
  { id: 'producto', url: 'https://app.hotmart.com/products/manage/{{producto_id}}', pasos: ['finalizar_registro/finalizar_registro'] },
  { id: 'contenido', url: 'https://app.hotmart.com/products/manage/{{producto_id}}/content', pasos: ['pdf', 'contenido/pdf'] },
  { id: 'soporte', url: 'https://app.hotmart.com/products/manage/{{producto_id}}/tools/checkout/settings', pasos: ['soporte/soporte', 'soporte/guardar_soporte'] },
  { id: 'pixel', url: 'https://app.hotmart.com/tools/pixel/checkout/{{producto_id}}', pasos: ['pixel/pixel_facebook'] },
  { id: 'ofertas', url: 'https://app.hotmart.com/products/manage/{{producto_id}}/offers', pasos: ['precio_base/acciones_base'] },
  { id: 'oferta_nueva', url: 'https://app.hotmart.com/products/manage/{{producto_id}}/offers/add',
    pasos: ['oferta_lanzamiento/nombre_oferta', 'oferta_lanzamiento/moneda', 'oferta_lanzamiento/forma_pago', 'oferta_lanzamiento/precio_lanzamiento', 'oferta_lanzamiento/guardar_oferta'] },
];
const SIN_INTERACCION = ['tipo_ebook→continuar_info abre la pantalla 3: moneda, reembolso, forma_pago, precio, crear_producto',
  'pixel: pixel (providerId) y siguientes aparecen después de elegir la tarjeta de Facebook',
  'precio_base: editar_base, precio_base y guardar_precio_base aparecen después de abrir Acciones',
  'finalizar_registro/confirmar_envio: diálogo que aparece al apretar el botón (prohibido para el robot sin autorización)'];

const sanear = (t) => String(t || '').replace(/\s+/g, ' ').trim().slice(0, 60)
  .replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, '[CORREO]').replace(/\d{5,}/g, '[N]');

function pasoDe(sel, ref) {
  const [flujo, id] = ref.includes('/') ? ref.split('/') : [null, ref];
  const lista = flujo ? sel.flujos[flujo] : sel.pasos;
  return (Array.isArray(lista) ? lista : []).find((p) => p.id === id) || null;
}

async function main() {
  const sel = JSON.parse(readFileSync(SELECTORES, 'utf8'));
  const { abrir, perfilVivo, estaLogueado, esHotmart } = await import('./hotmart_navegador.mjs');
  let nav;
  if (FALSO) {
    nav = await abrir({ via: 'prueba', visible: false });
  } else {
    if (!PRODUCTO || !/^\d{5,}$/.test(PRODUCTO)) { console.log(JSON.stringify({ ok: false, codigo: 2, motivo: 'falta --producto <id numérico>' })); return 2; }
    if (!(await perfilVivo())) {
      console.log(JSON.stringify({ ok: false, codigo: 3, motivo: '[PENDIENTE] el Chrome del robot no está abierto (hotmart_sesion.mjs): no se pide login' }));
      return 3;
    }
    nav = await abrir({ via: 'perfil', propia: true });
  }
  const pagina = nav.pagina;
  const informe = { fecha: new Date().toISOString().slice(0, 10), modo: FALSO ? 'panel_falso' : 'panel_real', pantallas: {},
    no_verificable_sin_interaccion: SIN_INTERACCION, version_selectores: sel.version };
  try {
    for (const p of PANTALLAS) {
      const url = FALSO ? pathToFileURL(join(resolve(FALSO), `${p.id}.html`)).href : p.url.replace('{{producto_id}}', PRODUCTO);
      if (FALSO && !existsSync(fileURLToPath(url))) { informe.pantallas[p.id] = { estado: 'sin_archivo' }; continue; }
      await pagina.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
      if (!FALSO) {
        if (!(await estaLogueado(pagina, 5000))) { informe.pantallas[p.id] = { estado: 'sesion_vencida' }; informe.sesion = 'vencida'; break; }
      }
      if (!esHotmart(pagina.url(), Boolean(FALSO))) { informe.pantallas[p.id] = { estado: 'fuera_de_dominio' }; continue; }
      const pasos = {};
      const capturas = [];
      for (const ref of p.pasos) {
        const paso = pasoDe(sel, ref);
        if (!paso) { pasos[ref] = { estado: 'paso_inexistente_en_selectores' }; continue; }
        const conteos = [];
        let primero = null;
        for (const s0 of paso.selectores || []) {
          const s = s0.replace(/\{\{(\w+)\}\}/g, (_, k) => MUESTRA[k] ?? `{{${k}}}`);
          let n = 0;
          try { n = await pagina.locator(s).count(); } catch { n = -1; }
          conteos.push({ selector: s, n });
          if (n > 0 && !primero) {
            primero = s;
            const attrs = await pagina.locator(s).first().evaluate((el) => {
              const a = (k) => el.getAttribute(k);
              const rotulable = ['BUTTON', 'LABEL', 'A', 'OPTION', 'SPAN', 'P', 'H1', 'H2', 'H3'].includes(el.tagName);
              return { tag: el.tagName.toLowerCase(), id: a('id'), name: a('name'), type: a('type'), testid: a('data-testid'),
                accept: a('accept'), role: a('role'), src: a('src') && /facebook/i.test(a('src')) ? 'facebook.svg' : null,
                texto: rotulable ? (el.innerText || '') : '' };
            }).catch(() => null);
            if (attrs) capturas.push({ ref, ...attrs, texto: sanear(attrs.texto) });
          }
        }
        pasos[ref] = { estado: primero ? 'confirmado' : 'no_encontrado', selector_que_coincide: primero, conteos };
      }
      informe.pantallas[p.id] = { estado: 'leida', pasos };
      if (CAPTURAR) {
        mkdirSync(CAPTURAR, { recursive: true });
        const esc = (v) => String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
        const cuerpo = capturas.map((c) => {
          const at = ['id', 'name', 'type', 'accept', 'role'].filter((k) => c[k]).map((k) => `${k}="${esc(c[k])}"`)
            .concat(c.testid ? [`data-testid="${esc(c.testid)}"`] : []).concat(c.src ? [`src="${c.src}"`] : []).join(' ');
          const vacio = ['input', 'img'].includes(c.tag);
          return `<!-- ${c.ref} -->\n<${c.tag}${at ? ' ' + at : ''}${vacio ? '>' : `>${esc(c.texto)}</${c.tag}>`}`;
        }).join('\n');
        writeFileSync(join(CAPTURAR, `${p.id}.html`), `<!doctype html>\n<!-- Reconstruido del DOM real de Hotmart (${informe.fecha}) con hotmart_verificar_selectores.mjs: solo atributos de los elementos que buscan los selectores; sin datos del dueño. -->\n<html><body>\n${cuerpo}\n</body></html>\n`);
      }
    }
  } finally {
    await nav.cerrar();
  }
  const pasos = Object.values(informe.pantallas).flatMap((x) => Object.values(x.pasos || {}));
  informe.resumen = { confirmados: pasos.filter((x) => x.estado === 'confirmado').length, no_encontrados: pasos.filter((x) => x.estado === 'no_encontrado').length };
  const ok = informe.sesion !== 'vencida';
  console.log(JSON.stringify(informe, null, 1));
  console.log(JSON.stringify({ ok, codigo: ok ? 0 : 3, motivo: ok ? `selectores: ${informe.resumen.confirmados} confirmados, ${informe.resumen.no_encontrados} sin coincidencia` : 'sesión de Hotmart vencida: [PENDIENTE] login humano', artefactos: [] }));
  return ok ? 0 : 3;
}

main().then((c) => process.exit(c)).catch((e) => { console.log(JSON.stringify({ ok: false, codigo: 1, motivo: String(e.message).split('\n')[0] })); process.exit(1); });
