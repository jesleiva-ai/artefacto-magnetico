#!/usr/bin/env python3
"""importar_hotmart.py — importador de ventas Hotmart en seco (Hyperflujo, TAREA 035).

Agrega ventas por anuncio (sck / utm_content) sin datos del comprador. El transporte real (MCP Hotmart de solo lectura
o export CSV) lo inyecta el orquestador [PENDIENTE: cablear importar_ventas_hotmart.py del taller, copiado aquí].
Una lectura fallida devuelve None (nunca 0): consumo real desconocido = nulo (regla 8 del taller).
"""
CAMPOS_PROHIBIDOS = ("email", "nombre", "name", "telefono", "phone", "documento", "buyer")


def _neto(f):
    v = f.get("neto")
    return None if v is None or v == "" else float(v)


def agregar(filas):
    """Revisión 035 h. 3c: una venta (o reembolso) sin neto deja los netos en None (desconocido), nunca 0."""
    tot = {"brutas": 0.0, "reembolsos": 0.0, "netas": 0.0, "compras": 0, "por_sck": {}}
    netos_desconocidos = False
    for f in filas:
        estado = (f.get("estado") or "").upper()
        neto = _neto(f)
        if neto is None and estado in ("APPROVED", "COMPLETE", "REFUNDED", "CHARGEBACK"):
            netos_desconocidos = True
            neto = 0.0
        sck = f.get("sck") or f.get("utm_content") or "(sin_sck)"
        if estado in ("APPROVED", "COMPLETE"):
            tot["compras"] += 1
            tot["brutas"] += float(f.get("bruto") or 0)
            tot["netas"] += neto
            d = tot["por_sck"].setdefault(sck, {"compras": 0, "netas": 0.0})
            d["compras"] += 1
            d["netas"] += neto
        elif estado in ("REFUNDED", "CHARGEBACK"):
            tot["reembolsos"] += float(f.get("bruto") or 0)
            tot["netas"] -= neto
    tot = {k: (round(v, 2) if isinstance(v, float) else v) for k, v in tot.items()}
    if netos_desconocidos:
        tot["netas"] = None
        tot["netos_desconocidos"] = True
    return tot


def importar(transporte, desde, hasta):
    try:
        filas = transporte.leer(desde, hasta)
    except Exception:
        return None
    if filas is None:
        return None
    limpias = [{k: v for k, v in f.items() if k.lower() not in CAMPOS_PROHIBIDOS} for f in filas]
    return agregar(limpias)
