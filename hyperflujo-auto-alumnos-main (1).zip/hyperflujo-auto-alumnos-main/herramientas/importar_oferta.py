#!/usr/bin/env python3
"""importar_oferta.py — trae una oferta del taller (hyperflujo/ofertas/OF-NNN) a hyperflujo-auto (TAREA 037 parte C).

    python herramientas/importar_oferta.py --of OF-005                  # seco (por defecto): muestra el plan, no escribe
    python herramientas/importar_oferta.py --of OF-005 --aplicar [--d107 10] [--estado activo] [--forzar]
    python herramientas/importar_oferta.py --of OF-005 --origen <carpeta de la oferta en el taller>

Para que el vigía y el director reales administren un producto que nació en el taller (corrida 1) y le apliquen D92 y,
si el dueño lo pide, el corte puntual D107 (analisis/equipo/ESTADO.md: gasto acumulado ≥ USD 10 con 0 ventas).

Qué hace (importar = leer: el taller nunca se escribe):
  1. Ficha: `oferta.json` del taller → `ofertas/OF-NNN/oferta.json` en el formato de este repo (precio D78 con
     `monto`/`lanzamiento`/`lista`, `campana.presupuesto` con diario/días/diario_max/autorizado_por que leen
     topes.tope_ficha y director.sincronizar_campana). Va a git: IDs reales, URLs propias, correos, rutas de usuario y
     nombres de los testimonios del taller se reemplazan por marcadores; si quedara alguno, falla cerrado. Los
     testimonios del taller no se copian (fuera del sistema, D119). Lo que falta queda en null o
     `[PENDIENTE: …]` (nunca un `[PENDIENTE]` en un campo que se lee por verdad, como autorizado_por o un tope).
  2. IDs reales → `ofertas/OF-NNN/externo.local.json` (fuera de git), en la forma que leen meta_pausa, meta_lector,
     hotmart_lector, director.urls_de, precio_vencimiento y el hook guardian_gasto: meta.{campana, conjunto, anuncios,
     creativos, medios, cuenta, pagina, pixel}, hotmart.{principal.{codigo, referencia, oferta_base,
     oferta_lanzamiento, checkout_url}, escalera, embudo}, netlify.{url, portal_url}. Fuentes: los registro.json de
     las ejecuciones (artefacto), la ficha y canales/hotmart/*.json del taller.
  3. Estado: alta en estado/productos.json (estado.py) y transiciones por el camino normal hasta el estado real
     (activo si la campaña figura activa), con la hora real de la aprobación de Hotmart y de la activación en el
     historial, y `primera_entrega_en` = campana/*/diario/inicio_d92.txt (reloj D92 desde el primer gasto). Si el
     taller dice que la campaña está en pausa, no se adivina: hace falta `--estado`.
  4. Registro: una ejecución nueva (`registro.py`, módulo «importar») con la ruta y el sha256 de la ficha de origen.
Idempotente: reimportar lo mismo no duplica nada; un estado distinto (por ejemplo más avanzado) o una ficha o un
externo con valores distintos no se pisan sin `--forzar`. La salida por consola nunca muestra un ID real.
Solo biblioteca estándar.
"""
import argparse
import hashlib
import json
import os
import re
import sys
from collections import deque
from datetime import datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import estado as E  # noqa: E402
import rutas  # noqa: E402

# Camino normal del ciclo (estado.py): solo por acá se reconstruye el historial. Nunca a través de bloqueada_humano,
# ni fallida. Los estados que no existan en estado.ESTADOS se ignoran (el ciclo puede crecer).
CAMINO = ["por_cazar", "candidato", "cazada", "producido", "en_revision", "hotmart_enviado", "lista_para_activar",
          "campana_en_pausa", "activo"]
ESTADOS_IMPORTABLES = ("hotmart_enviado", "lista_para_activar", "campana_en_pausa", "activo", "escalando",
                       "pausada_tecnica", "en_baja", "retirado")
PROVEEDORES_FICHA = {"higgsfield_plan": "higgsfield", "higgsfield": "higgsfield", "elevenlabs": "elevenlabs",
                     "anthropic": "anthropic", "kie": "kie", "heygen": "heygen"}
CAMPOS_CONTENIDO = ("producto", "publico", "problema", "promesa", "limites", "tono", "afirmaciones", "evidencias",
                    "no_se_puede_afirmar", "condiciones_comerciales", "escalera", "referencias", "contexto_mercado",
                    "estado_aprobacion", "definido_por", "responsable_revision", "aceptacion_piezas")
MARCADORES = [
    (re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+"), "[CORREO]"),
    (re.compile(r"[A-Za-z]:[\\/]+Users[\\/]+[^\s\"'»)]+", re.I), "[RUTA_USUARIO]"),
    (re.compile(r"/(?:home|Users)/[^\s\"'»)/]+"), "/[RUTA_USUARIO]"),
    (re.compile(r"(?:https?://)?pay\.hotmart\.com/[^\s\"'»)]*"), "[CHECKOUT_URL]"),
    (re.compile(r"(?:https?://)?[\w.-]*hotmart\.com/[^\s\"'»)]*"), "[URL_HOTMART]"),
    (re.compile(r"(?:https?://)?[\w-]+\.netlify\.app[^\s\"'»)]*"), "[URL_NETLIFY]"),
    (re.compile(r"\boff=[A-Za-z0-9]+"), "off=[CODIGO_OFERTA]"),
    (re.compile(r"\b[A-Z]\d{6,}[A-Z]\b"), "[CODIGO_PRODUCTO]"),
    (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I), "[ID]"),
    (re.compile(r"\b[0-9a-f]{16,}\b", re.I), "[ID]"),
    (re.compile(r"\b\d{6,}\b"), "[ID]"),
]


class ErrorImportacion(Exception):
    """Origen inexistente o ilegible, o un estado que no se puede fundamentar: no se escribe nada."""


# ------------------------------------------------------------------ utilidades
def _leer(p, defecto=None):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defecto


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _url(v):
    if not isinstance(v, str):
        return None
    v = v.strip()
    if v.startswith(("http://", "https://")):
        return v
    if re.match(r"^[\w.-]+\.(?:com|app|org|net|xyz)/", v):
        return "https://" + v
    return None


def _ahora_iso():
    return rutas.ahora().isoformat(timespec="seconds")


def origen_defecto(of):
    """La carpeta hermana del repo: ../hyperflujo/ofertas/OF-NNN."""
    return rutas.RAIZ.parent / "hyperflujo" / "ofertas" / of


def _sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def _hojas(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            yield from _hojas(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _hojas(v)
    elif obj is not None and not isinstance(obj, bool):
        yield str(obj)


def reales_de(externo, extra=()):
    """Valores que nunca pueden aparecer en algo versionado ni en la consola: IDs, códigos, URLs propias y nombres."""
    vals = set(x for x in extra if x and len(str(x)) >= 3)
    for k, v in (externo or {}).items():
        if k.startswith("_"):
            continue
        for h in _hojas(v):
            if len(h) >= 5 and (re.search(r"\d{4,}", h) or h.startswith("http") or re.fullmatch(r"[a-z0-9]{8}", h)
                                or re.fullmatch(r"act_\d+", h)):
                vals.add(h)
    return vals


def enmascarar(texto, reales):
    """Reemplaza valores reales conocidos y patrones de ID, correo, URL propia o ruta de usuario por marcadores."""
    if not isinstance(texto, str):
        return texto
    for r in sorted(reales, key=len, reverse=True):
        if r not in texto:
            continue
        if re.search(r"\d", r) or r.startswith("http"):
            texto = texto.replace(r, "[ID]")
        else:   # nombres de personas: solo palabra completa
            texto = re.sub(r"(?<!\w)%s(?!\w)" % re.escape(r), "[NOMBRE]", texto)
    for rx, marca in MARCADORES:
        texto = rx.sub(marca, texto)
    return texto


def sanitizar(obj, reales):
    if isinstance(obj, dict):
        return {k: sanitizar(v, reales) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitizar(v, reales) for v in obj]
    return enmascarar(obj, reales)


def fugas(obj, reales):
    """Lista de valores reales que siguen apareciendo (vacía = limpio)."""
    texto = json.dumps(obj, ensure_ascii=False)
    return sorted(r for r in reales if len(r) >= 5 and r in texto)


# ------------------------------------------------------------------ lectura del taller
def leer_origen(origen):
    origen = Path(origen)
    p_ficha = origen / "oferta.json"
    if not origen.is_dir():
        raise ErrorImportacion("origen inexistente: %s (esperado <taller>/ofertas/OF-NNN)" % origen)
    if not p_ficha.exists():
        raise ErrorImportacion("el origen no tiene oferta.json: %s" % origen)
    ficha = _leer(p_ficha)
    if not isinstance(ficha, dict):
        raise ErrorImportacion("oferta.json ilegible en %s" % origen)
    registros = []
    for p in sorted(origen.glob("ejecuciones/EJ-*/registro.json")):
        r = _leer(p)
        if isinstance(r, dict):
            registros.append(r)
    diarios = []
    for p in sorted(origen.glob("campana/*/diario/*.md")):
        if re.match(r"^\d{4}-\d{2}-\d{2}\.md$", p.name):
            try:
                diarios.append((p.parent.parent.name, p.name, p.read_text(encoding="utf-8")))
            except OSError:
                pass
    inicio = None
    for p in sorted(origen.glob("campana/*/diario/inicio_d92.txt")):
        try:
            t = p.read_text(encoding="utf-8").strip()
            datetime.fromisoformat(t)
            inicio = t if (inicio is None or t < inicio) else inicio
        except (OSError, ValueError):
            pass
    return {"dir": origen, "ficha": ficha, "sha256": _sha256(p_ficha), "registros": registros, "diarios": diarios,
            "inicio_d92": inicio, "embudo": _leer(origen / "canales" / "hotmart" / "embudo.json", {}) or {},
            "aprobacion": _leer(origen / "canales" / "hotmart" / "estado_aprobacion.json", {}) or {}}


def _solicitudes_meta(registros):
    ss = []
    for r in registros:
        for s in r.get("solicitudes", []):
            if s.get("proveedor") == "meta" and s.get("estado") == "completada":
                ss.append(s)
    return sorted(ss, key=lambda s: str(s.get("enviada_en") or s.get("creada_en") or ""))


def objetos_meta(o):
    """IDs de Meta desde los registros (artefacto) y, si faltan, desde la ficha. Estado de campaña y hora de activación."""
    avisos = []
    camp = conj = None
    anuncios, creativos, medios = {}, [], []
    ss = _solicitudes_meta(o["registros"])
    for s in ss:
        pa = s.get("parametros") or {}
        h, prm, iid = pa.get("herramienta"), pa.get("params") or {}, s.get("id_externo")
        if not iid:
            continue
        if h == "ads_create_campaign":
            camp = str(iid)
        elif h == "ads_create_ad_set":
            conj = str(iid)
        elif h == "ads_create_ad":
            anuncios[str(iid)] = {"id": str(iid), "nombre": prm.get("ad_name") or prm.get("name"),
                                  "estado_taller": prm.get("status")}
        elif h == "ads_create_creative":
            creativos.append(str(iid))
        elif h == "ads_creative_upload_media":
            medios.append(str(iid))
    ids_ficha = ((o["ficha"].get("campana") or {}).get("meta_ids") or {})
    for clave, actual in (("campana", camp), ("conjunto", conj)):
        f = ids_ficha.get(clave)
        if f and actual and str(f) != actual:
            avisos.append("la ficha y los registros del taller no coinciden en el ID de %s: se usa el del registro" % clave)
        elif f and not actual:
            if clave == "campana":
                camp = str(f)
            else:
                conj = str(f)
    estado_camp, activada = None, None
    for s in ss:
        pa = s.get("parametros") or {}
        h, prm = pa.get("herramienta"), pa.get("params") or {}
        ent = str(prm.get("entity_id") or "")
        hora = s.get("enviada_en") or s.get("creada_en")
        if h == "ads_activate_entity":
            if ent in anuncios:
                anuncios[ent]["estado_taller"] = "ACTIVE"
            if ent and ent == camp or (not ent and prm.get("entity_type") == "campaign"):
                estado_camp = "ACTIVE"
                activada = activada or hora
        elif h == "ads_update_entity" and prm.get("status"):
            if ent in anuncios:
                anuncios[ent]["estado_taller"] = prm["status"]
            if ent and ent == camp:
                estado_camp = prm["status"]
    if activada is None:
        for _, _, txt in o["diarios"]:
            m = re.search(r"Activaci[oó]n:\**\s*(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s*\(([+-]\d{2}:\d{2})\)", txt)
            if m:
                activada = "%sT%s:00%s" % m.groups()
                break
    return {"campana": camp, "conjunto": conj, "anuncios": list(anuncios.values()), "creativos": creativos,
            "medios": medios, "estado_campana": estado_camp, "activada_en": activada, "avisos": avisos}


def estado_diario(o):
    """Último estado de campaña escrito en el diario del taller (texto humano, no verificado): ACTIVA/PAUSADA/None."""
    if not o["diarios"]:
        return None, None
    _, nombre, txt = sorted(o["diarios"], key=lambda d: d[1])[-1]
    for linea in reversed(txt.splitlines()):
        m = re.search(r"\b(ACTIVA|PAUSADA)\b", linea)
        if m:
            return m.group(1), nombre
    return None, nombre


def aprobacion_hotmart(o, pid):
    """(aprobado: bool|None, fecha AAAA-MM-DD|None) desde canales/hotmart/estado_aprobacion.json o el texto de la ficha."""
    ap = o["aprobacion"] or {}
    fecha = None
    for c in ap.get("cambios", []) or []:
        if str(c.get("producto")) == str(pid) and c.get("a") == "ACTIVE":
            fecha = str(c.get("fecha", ""))[:10] or None
            break
    st = ((ap.get("ultimo") or {}).get("estados") or {}).get(str(pid))
    if st == "ACTIVE":
        return True, fecha or str((ap.get("ultimo") or {}).get("fecha", ""))[:10] or None
    if st:
        return False, None
    texto = json.dumps(o["ficha"].get("precio") or {}, ensure_ascii=False) + json.dumps(
        (o["ficha"].get("destino") or {}).get("hotmart") or {}, ensure_ascii=False)
    m = re.search(r"Aprobaci[oó]n de Hotmart (\d{4}-\d{2}-\d{2})", texto) or re.search(
        r"aprobado \(ACTIVE\) (\d{4}-\d{2}-\d{2})", texto)
    if m:
        return True, m.group(1)
    return None, None


def extraer_externo(o, meta):
    f = o["ficha"]
    camp = f.get("campana") or {}
    dest = f.get("destino") or {}
    dh = dest.get("hotmart") or {}
    de = dest.get("externo") or {}
    emb = o["embudo"] or {}
    pri = emb.get("principal") or {}
    ext = {"_importado": {"desde": "hyperflujo/ofertas/%s" % f.get("oferta_id", "?"), "en": _ahora_iso(),
                          "por": "herramientas/importar_oferta.py (TAREA 037 C)"}}
    m = {k: meta[k] for k in ("campana", "conjunto") if meta.get(k)}
    if meta["anuncios"]:
        m["anuncios"] = meta["anuncios"]
    if meta["creativos"]:
        m["creativos"] = meta["creativos"]
    if meta["medios"]:
        m["medios"] = meta["medios"]
    cuenta = (camp.get("cuenta") or camp.get("cuenta_publicitaria") or {})
    if cuenta.get("id"):
        m["cuenta"] = str(cuenta["id"])
        if cuenta.get("nombre"):
            m["cuenta_nombre"] = cuenta["nombre"]
    pag = camp.get("pagina") or {}
    if pag.get("id"):
        m["pagina"] = str(pag["id"])
        if pag.get("nombre"):
            m["pagina_nombre"] = pag["nombre"]
    pixel = cuenta.get("pixel") or camp.get("pixel") or de.get("pixel")
    if pixel and re.fullmatch(r"\d{6,}", str(pixel)):
        m["pixel"] = str(pixel)
    if m:
        ext["meta"] = m
    lanz = pri.get("oferta_lanzamiento") or (dh.get("oferta_lanzamiento") or {}).get("codigo") or (f.get("precio") or {}).get("oferta_lanzamiento")
    p = {}
    pid = pri.get("producto_id") or dh.get("producto_id")
    if pid:
        p["codigo"] = str(pid)
    ref = pri.get("codigo") or dh.get("codigo")
    if ref:
        p["referencia"] = str(ref)
    if dh.get("oferta"):
        p["oferta_base"] = str(dh["oferta"])
    if lanz:
        p["oferta_lanzamiento"] = str(lanz)
    candidatos = [de.get("url_checkout"), dh.get("url_checkout"), (dh.get("oferta_lanzamiento") or {}).get("url_checkout"),
                  (emb.get("checkout") or {}).get("enlace")]
    urls = [u for u in (_url(c) for c in candidatos) if u]
    con_lanz = [u for u in urls if lanz and ("off=%s" % lanz) in u]
    if con_lanz or urls:
        p["checkout_url"] = (con_lanz or urls)[0]
    h = {}
    if p:
        h["principal"] = p
    esc = []
    for b in ((emb.get("checkout") or {}).get("order_bumps") or emb.get("order_bumps") or []):
        if b.get("producto_id"):
            esc.append({"clave": b.get("codigo"), "rol": "order_bump", "producto_id": str(b["producto_id"])})
    eu = emb.get("embudo_un_clic") or {}
    for et in eu.get("etapas") or []:
        if et.get("producto_id"):
            esc.append({"clave": et.get("codigo") or et.get("etapa"), "rol": "embudo", "producto_id": str(et["producto_id"]),
                        "oferta": et.get("oferta")})
    if esc:
        h["escalera"] = esc
    if eu.get("id"):
        h["embudo"] = str(eu["id"])
    if h:
        ext["hotmart"] = h
    landing = _url(de.get("url_landing_publica")) or _url(f.get("url_destino"))
    n = {}
    if landing:
        n["url"] = landing
    portal = _url(de.get("url_portal"))
    if portal:
        n["portal_url"] = portal
    if n:
        ext["netlify"] = n
    return ext


# ------------------------------------------------------------------ ficha
def traducir_ficha(o, of, ext, reales):
    t = o["ficha"]
    pend = []
    out = {"_origen": {"taller": "hyperflujo/ofertas/%s/oferta.json" % of, "sha256": o["sha256"],
                       "version_taller": t.get("version"), "importado_por": "herramientas/importar_oferta.py (TAREA 037 C)",
                       "_nota": "Ficha traída del taller: el contenido manda igual que allá (regla 1). IDs reales solo en "
                                "externo.local.json; testimonios fuera del sistema (D119)."},
           "_version": "1.0", "ficticio": False, "id": of}
    for k in CAMPOS_CONTENIDO:
        if k in t:
            out[k] = t[k]
    nombre = ((t.get("producto") or {}).get("nombre"))
    if not nombre:
        pend.append("producto.nombre")
    merc = dict(t.get("mercado") or {})
    pr = t.get("precio") or {}
    if pr.get("moneda") and not merc.get("moneda"):
        merc["moneda"] = pr["moneda"]
    if not merc.get("id"):
        if merc.get("idioma") == "es" and "LATAM" in str(merc.get("pais", "")):
            merc["id"] = "es-LATAM"
        else:
            merc["id"] = None
            pend.append("mercado.id (clave de datos/mercados.json)")
    out["mercado"] = merc
    venta = _num(pr.get("monto")) if _num(pr.get("monto")) is not None else _num(pr.get("venta"))
    lanz = _num(pr.get("lanzamiento")) if _num(pr.get("lanzamiento")) is not None else (venta if pr.get("oferta_lanzamiento") else None)
    out["precio"] = {"monto": venta, "lanzamiento": lanz, "lista": _num(pr.get("lista")), "moneda": pr.get("moneda"),
                     "fin_lanzamiento": pr.get("fin_lanzamiento"), "duracion_lanzamiento_dias": pr.get("duracion_lanzamiento_dias"),
                     "oferta_lanzamiento": "[CODIGO_OFERTA]" if pr.get("oferta_lanzamiento") else None,
                     "texto_lanzamiento": pr.get("texto_lanzamiento"), "texto_lista": pr.get("texto_lista"),
                     "fuente": "taller: precio.venta (lanzamiento) y precio.lista (D77/D78/D80/D93)",
                     "_nota_taller": pr.get("_nota") or pr.get("_propuesta")}
    for k in ("monto", "lista", "moneda"):
        if out["precio"][k] is None:
            pend.append("precio.%s" % k)
    marca = t.get("marca") or {}
    out["marca"] = {"nombre": marca.get("nombre"), "dominio": "[DOMINIO]", "colores": marca.get("colores") or [],
                    "tipografias": marca.get("tipografias") or []}
    out["externo"] = {"pixel": "[ID_PIXEL]", "pagina": "[ID_PAGINA]", "cuenta": "[act_CUENTA]",
                      "producto_hotmart": "[CODIGO_PRODUCTO]", "oferta_hotmart": "[CODIGO_OFERTA]", "checkout": "[CHECKOUT_URL]",
                      "landing": "[URL_LANDING]", "_nota": "IDs reales solo en ofertas/%s/externo.local.json (fuera de git)." % of}
    # D105: topes por proveedor. El consumo del taller no está en el libro de gasto de este repo: el tope queda en null
    # (no se gasta) hasta que el dueño escriba el saldo; el valor del taller queda como referencia.
    por = {}
    for k, v in (((t.get("presupuesto") or {}).get("por_proveedor")) or {}).items():
        prov = PROVEEDORES_FICHA.get(k)
        if not prov or not isinstance(v, dict):
            continue
        por[prov] = {"tope_autorizado": None, "unidad": "creditos" if "credit" in str(v.get("unidad", "")) else (v.get("unidad") or "USD"),
                     "autorizado_por": None, "autorizacion_ref": None,
                     "_taller": {"tope": _num(v.get("tope")) if _num(v.get("tope")) is not None else _num(v.get("tope_usd")),
                                 "unidad": v.get("unidad"), "autorizado_por": v.get("autorizado_por"),
                                 "autorizacion": v.get("autorizacion_ref"), "alcance": v.get("alcance")}}
        pend.append("presupuesto.por_proveedor.%s.tope_autorizado (saldo tras el consumo del taller, firmado)" % prov)
    out["presupuesto"] = {"por_proveedor": por, "_regla": "D105: null = no se gasta en ese proveedor. Importado del taller "
                          "sin saldo: el consumo previo está en los registros del taller, no en estado/libro_gasto.jsonl."}
    camp = t.get("campana") or {}
    cp = camp.get("presupuesto") or {}
    diario = _num(cp.get("diario")) if _num(cp.get("diario")) is not None else _num(cp.get("diario_usd"))
    dias = _num(cp.get("dias"))
    autor = cp.get("autorizado_por") if isinstance(cp.get("autorizado_por"), str) and cp.get("autorizado_por").strip() else None
    out["campana"] = {
        "presupuesto": {"diario": diario, "dias": dias, "diario_max": _num(cp.get("diario_max")),
                        "moneda": cp.get("moneda") or "USD", "autorizado_por": autor, "autorizacion_ref": None,
                        "autorizacion_texto": cp.get("autorizacion_ref"), "fecha": cp.get("fecha"),
                        "spend_cap_taller": _num(cp.get("spend_cap_usd")) if _num(cp.get("spend_cap_usd")) is not None else _num(cp.get("total"))},
        "segmentacion": camp.get("segmentacion_meta") or camp.get("segmentacion"),
        "estructura": camp.get("estructura"), "cuenta": "[act_CUENTA]", "pagina": "[ID_PAGINA]", "pixel": "[ID_PIXEL]",
        "_regla": "D105: tope de Meta del producto = diario × días (spend_cap). diario_max null = no se escala hasta que el "
                  "dueño lo escriba. autorizado_por tiene que ser igual exacto a un nombre de datos/dueno.local.json."}
    for k, v in (("diario", diario), ("dias", dias), ("autorizado_por", autor)):
        if v is None:
            pend.append("campana.presupuesto.%s" % k)
    pend.append("campana.presupuesto.diario_max (sin él no se escala)")
    pend.append("campana.presupuesto.autorizacion_ref (AUT-… de datos/autorizaciones.local.json)")
    out["metodo"] = "Importado del taller (corrida 1). Lanzamiento: método de Matías. Criterio de producto: Ramiro."
    limpio = sanitizar(out, reales)
    limpio["_origen"]["sha256"] = o["sha256"]   # el hash de la ficha de origen no es un ID: se restituye tras enmascarar
    restos = fugas(limpio, reales)
    if restos:
        raise ErrorImportacion("la ficha traducida conserva %d valor(es) real(es): no se escribe (falla cerrado)" % len(restos))
    return limpio, pend


# ------------------------------------------------------------------ estado
def _camino(desde, hasta):
    """BFS por el camino normal (sin bloqueos ni fallas) de estado.TRANSICIONES."""
    nodos = [x for x in CAMINO if x in E.ESTADOS] + [hasta]
    vistos, cola = {desde: None}, deque([desde])
    while cola:
        x = cola.popleft()
        if x == hasta:
            break
        for y in sorted(E.TRANSICIONES.get(x, ())):
            if y in nodos and y not in vistos:
                vistos[y] = x
                cola.append(y)
    if hasta not in vistos:
        return None
    pasos, x = [], hasta
    while x != desde:
        pasos.append(x)
        x = vistos[x]
    return list(reversed(pasos))


def inferir_estado(o, ext, meta, forzado=None):
    """(objetivo|None, fechas, avisos)."""
    avisos = list(meta["avisos"])
    pid = ((ext.get("hotmart") or {}).get("principal") or {}).get("codigo")
    aprobado, f_aprob = aprobacion_hotmart(o, pid) if pid else (None, None)
    st_diario, archivo_diario = estado_diario(o)
    fechas = {"aprobado_en": f_aprob, "activada_en": meta["activada_en"], "primera_entrega_en": o["inicio_d92"],
              "estado_campana_registro": meta["estado_campana"], "estado_campana_diario": st_diario,
              "diario": archivo_diario}
    objetivo = None
    pausada = meta["estado_campana"] == "PAUSED" or st_diario == "PAUSADA"
    if meta["campana"] and (meta["estado_campana"] == "ACTIVE" or st_diario == "ACTIVA") and not pausada:
        objetivo = "activo"
    elif meta["campana"] and pausada:
        avisos.append("la campaña figura en pausa en el taller (registro: %s, diario: %s): no se adivina el estado; "
                      "decidir con --estado (en_baja, retirado o pausada_tecnica)" % (meta["estado_campana"], st_diario))
    elif meta["campana"]:
        avisos.append("hay campaña pero el taller no dice si está activa: decidir con --estado")
    elif pid and aprobado:
        objetivo = "lista_para_activar"
    elif pid:
        objetivo = "hotmart_enviado"
    else:
        avisos.append("sin campaña ni producto de Hotmart en el taller: no hay estado importable")
    if forzado:
        if forzado not in ESTADOS_IMPORTABLES or forzado not in E.ESTADOS:
            raise ErrorImportacion("--estado %s no es importable (opciones: %s)" % (
                forzado, ", ".join(x for x in ESTADOS_IMPORTABLES if x in E.ESTADOS)))
        if objetivo and forzado != objetivo:
            avisos.append("--estado %s reemplaza lo inferido del taller (%s)" % (forzado, objetivo))
        objetivo = forzado
    if objetivo in ("activo", "escalando", "en_baja", "retirado", "pausada_tecnica"):
        if not fechas["primera_entrega_en"]:
            avisos.append("sin inicio_d92.txt: primera_entrega_en queda null y el reloj D92 arrancaría con la primera lectura "
                          "con gasto > 0 de este repo (más tarde que la real) [PENDIENTE: cargarla a mano]")
        if not fechas["activada_en"]:
            avisos.append("hora de activación desconocida: el historial usa la hora de importación [PENDIENTE]")
        if fechas["primera_entrega_en"]:
            desde = fechas["primera_entrega_en"][:10]
            ayer = (rutas.ahora().date().toordinal() - 1)
            faltan = [datetime.fromordinal(d).date().isoformat() for d in range(datetime.fromisoformat(desde).toordinal(), ayer)]
            if faltan:
                avisos.append("días con gasto anteriores a ayer sin medición en este repo (%s): el director solo lee ayer y "
                              "hoy; cargarlos con meta_lector/hotmart_lector por fecha [PENDIENTE] o el acumulado de D92/D107 "
                              "queda corto" % ", ".join(faltan))
    if objetivo not in (None, "hotmart_enviado") and not fechas["aprobado_en"]:
        avisos.append("fecha de aprobación de Hotmart desconocida: el historial usa la de importación y el vencimiento D78 "
                      "se calcularía desde ahí [PENDIENTE]")
    return objetivo, fechas, avisos


def _orden(estado):
    orden = [x for x in CAMINO if x in E.ESTADOS] + ["escalando", "rechazo_meta", "pausada_tecnica", "en_baja", "retirado"]
    return orden.index(estado) if estado in orden else -1


def _ajustar_horas(of, fechas, archivo):
    """La aprobación de Hotmart y la activación quedan en el historial con su hora real del taller (las leen
    precio_vencimiento.aprobado_en y orquestador.activada_en)."""
    base = E.cargar(archivo)
    p = base["productos"][of]
    for h in p["historial"]:
        if not (h.get("datos") or {}).get("importado"):
            continue
        if h.get("a") == "lista_para_activar" and fechas.get("aprobado_en"):
            h["hora"] = datetime.fromisoformat(fechas["aprobado_en"]).replace(tzinfo=rutas.zona_horaria()).isoformat(timespec="seconds")
            h["datos"]["hora_real"] = "aprobación de Hotmart según el taller"
        if h.get("a") == "activo" and fechas.get("activada_en"):
            h["hora"] = fechas["activada_en"]
            h["datos"]["hora_real"] = "activación de la campaña según el taller"
    E.guardar(base, archivo)


def importar_estado(of, nombre, objetivo, fechas, *, campana, d107=None, sha=None, forzar=False, archivo=None):
    """Devuelve (accion, detalle). accion: creado | igual | conflicto | reemplazado."""
    actual = E.cargar(archivo)["productos"].get(of)
    if actual is not None:
        if actual["estado"] == objetivo:
            cambios = {}
            if not actual.get("primera_entrega_en") and fechas.get("primera_entrega_en"):
                cambios["primera_entrega_en"] = fechas["primera_entrega_en"]
            if d107 is not None and (actual.get("reglas_corte") or {}).get("D107", {}).get("gasto_sin_ventas_usd") != d107:
                cambios["reglas_corte"] = {**(actual.get("reglas_corte") or {}), "D107": _d107(d107)}
            for k, v in cambios.items():
                E.marcar(of, k, v, archivo=archivo)
            return ("igual" if not cambios else "actualizado"), "ya estaba en %s" % objetivo
        if not forzar:
            mas = "más avanzado" if _orden(actual["estado"]) > _orden(objetivo) else "distinto"
            return "conflicto", "ya existe en %s (%s que %s): no se pisa sin --forzar" % (actual["estado"], mas, objetivo)
        base = E.cargar(archivo)
        previo = base["productos"].pop(of)
        E.guardar(base, archivo)
    else:
        previo = None
    p = E.alta(of, nombre or "[PENDIENTE: nombre]", archivo=archivo)
    pasos = _camino(p["estado"], objetivo)
    if pasos is None:
        raise ErrorImportacion("no hay camino normal de %s a %s en estado.py" % (p["estado"], objetivo))
    for x in pasos:
        E.transicionar(of, x, "importación desde el taller (TAREA 037 C): estado reconstruido, no ejecutado por este sistema",
                       archivo=archivo, datos={"importado": True})
    _ajustar_horas(of, fechas, archivo)
    if fechas.get("primera_entrega_en"):
        E.marcar(of, "primera_entrega_en", fechas["primera_entrega_en"], archivo=archivo)
    if campana:
        E.marcar(of, "campana", campana, archivo=archivo)
    if d107 is not None:
        E.marcar(of, "reglas_corte", {"D107": _d107(d107)}, archivo=archivo)
    E.marcar(of, "importado", {"desde": "hyperflujo/ofertas/%s" % of, "en": _ahora_iso(), "sha256_ficha": sha,
                               "estado_previo": (previo or {}).get("estado")}, archivo=archivo)
    if previo:
        E.marcar(of, "historial_previo", previo.get("historial", []), archivo=archivo)
        return "reemplazado", "estaba en %s; reimportado en %s por --forzar" % (previo["estado"], objetivo)
    return "creado", "alta y %d transición(es) hasta %s" % (len(pasos), objetivo)


def _d107(usd):
    return {"gasto_sin_ventas_usd": usd, "fuente": "analisis/equipo/ESTADO.md D107 (Ramiro, 2026-10-22): puntual, solo "
            "OF-001/OF-005 de la corrida 1; al sobreviviente ya no se le aplica", "aplica": "vigía y director [PENDIENTE: leerlo]"}


# ------------------------------------------------------------------ plan y aplicación
def planificar(of, origen=None, estado=None, d107=None):
    of = rutas.validar_of(of)
    o = leer_origen(origen or origen_defecto(of))
    if o["ficha"].get("oferta_id") and o["ficha"]["oferta_id"] != of:
        raise ErrorImportacion("el origen es %s, no %s" % (o["ficha"]["oferta_id"], of))
    meta = objetos_meta(o)
    ext = extraer_externo(o, meta)
    nombres = [x.get("nombre") for x in (o["ficha"].get("testimonios") or []) if isinstance(x, dict)]
    reales = reales_de(ext, extra=[n for n in nombres if n])
    ficha, pend = traducir_ficha(o, of, ext, reales)
    objetivo, fechas, avisos = inferir_estado(o, ext, meta, estado)
    pr = ficha["campana"]["presupuesto"]
    campana = {k: v for k, v in (("diario", pr.get("diario")), ("diario_max", pr.get("diario_max")),
                                 ("precio", ficha["precio"].get("lanzamiento") if ficha["precio"].get("lanzamiento") is not None
                                  else ficha["precio"].get("monto"))) if v is not None}
    if not (ext.get("netlify") or {}).get("url"):
        pend.append("externo.netlify.url (landing): sin ella el vigía no puede sondear")
    if not ((ext.get("hotmart") or {}).get("principal") or {}).get("checkout_url"):
        pend.append("externo.hotmart.principal.checkout_url: sin él el vigía no puede sondear el checkout")
    if not (ext.get("meta") or {}).get("campana"):
        pend.append("externo.meta.campana: sin ella no hay lectura de gasto ni pausa")
    return {"of": of, "origen": o["dir"], "sha256": o["sha256"], "ficha": ficha, "externo": ext, "objetivo": objetivo,
            "fechas": fechas, "campana": campana, "nombre": ((o["ficha"].get("producto") or {}).get("nombre")),
            "pendientes": pend, "avisos": avisos, "d107": d107, "reales": reales}


def _cuenta(v):
    return len(v) if isinstance(v, list) else ("disponible" if v else "no disponible")


def resumen(plan):
    """Lo que se puede mostrar: sin un solo ID real."""
    ext = plan["externo"]
    m, h, n = ext.get("meta") or {}, ext.get("hotmart") or {}, ext.get("netlify") or {}
    pri = h.get("principal") or {}
    anuncios = m.get("anuncios") or []
    estados = {}
    for a in anuncios:
        estados[a.get("estado_taller") or "?"] = estados.get(a.get("estado_taller") or "?", 0) + 1
    r = {"of": plan["of"], "nombre": plan["nombre"], "estado_objetivo": plan["objetivo"], "fechas": plan["fechas"],
         "campana_estado": plan["campana"], "d107": plan["d107"],
         "ficha": {"precio": {k: plan["ficha"]["precio"].get(k) for k in ("monto", "lanzamiento", "lista", "moneda", "fin_lanzamiento")},
                   "campana.presupuesto": {k: plan["ficha"]["campana"]["presupuesto"].get(k)
                                           for k in ("diario", "dias", "diario_max", "autorizado_por")},
                   "mercado.id": plan["ficha"]["mercado"].get("id")},
         "externo": {"meta.campana": _cuenta(m.get("campana")), "meta.conjunto": _cuenta(m.get("conjunto")),
                     "meta.anuncios": "%d (%s)" % (len(anuncios), ", ".join("%s %d" % kv for kv in sorted(estados.items()))),
                     "meta.creativos": len(m.get("creativos") or []), "meta.medios": len(m.get("medios") or []),
                     "meta.cuenta": _cuenta(m.get("cuenta")), "meta.pagina": _cuenta(m.get("pagina")), "meta.pixel": _cuenta(m.get("pixel")),
                     "hotmart.principal.codigo": _cuenta(pri.get("codigo")), "hotmart.principal.oferta_lanzamiento": _cuenta(pri.get("oferta_lanzamiento")),
                     "hotmart.principal.checkout_url": _cuenta(pri.get("checkout_url")),
                     "hotmart.escalera": len(h.get("escalera") or []), "hotmart.embudo": _cuenta(h.get("embudo")),
                     "netlify.url": _cuenta(n.get("url")), "netlify.portal_url": _cuenta(n.get("portal_url"))},
         "pendientes": plan["pendientes"], "avisos": plan["avisos"]}
    return sanitizar(r, plan["reales"])


def _escribir_si(p, datos, forzar, ignorar=("en", "importado_por")):
    """creado | igual | conflicto | reemplazado. Compara sin las marcas de hora de la importación."""
    def limpio(d):
        if isinstance(d, dict):
            return {k: limpio(v) for k, v in d.items() if k not in ignorar}
        if isinstance(d, list):
            return [limpio(v) for v in d]
        return d
    if p.exists():
        previo = _leer(p)
        if limpio(previo) == limpio(datos):
            return "igual"
        if not forzar:
            return "conflicto"
        rutas.escribir_json(p, datos)
        return "reemplazado"
    rutas.escribir_json(p, datos)
    return "creado"


def aplicar(plan, forzar=False, archivo=None):
    of = plan["of"]
    if plan["objetivo"] is None:
        raise ErrorImportacion("estado indeterminado para %s: %s" % (of, "; ".join(plan["avisos"]) or "sin datos"))
    acc = {}
    acc["ficha"] = _escribir_si(rutas.ruta_ficha(of), plan["ficha"], forzar)
    p_ext = rutas.dir_oferta(of) / "externo.local.json"
    if p_ext.exists() and not forzar:
        previo = _leer(p_ext, {}) or {}
        choques = [k for k in plan["externo"] if not k.startswith("_") and k in previo and previo[k] != plan["externo"][k]]
        if choques:
            acc["externo"] = "conflicto (%s)" % ", ".join(choques)
        else:
            nuevos = {k: v for k, v in plan["externo"].items() if k not in previo}
            if any(not k.startswith("_") for k in nuevos):
                rutas.guardar_externo(of, **nuevos)
                acc["externo"] = "completado"
            else:
                acc["externo"] = "igual"
    else:   # nuevo, o --forzar: las claves de la importación pisan; las demás (p. ej. repo_productos) se conservan
        acc["externo"] = "reemplazado" if p_ext.exists() else "creado"
        rutas.escribir_json(p_ext, {**(_leer(p_ext, {}) or {}), **plan["externo"]})
    acc["estado"], acc["estado_detalle"] = importar_estado(
        of, plan["nombre"], plan["objetivo"], plan["fechas"], campana=plan["campana"], d107=plan["d107"],
        sha=plan["sha256"], forzar=forzar, archivo=archivo)
    if any(v in ("creado", "reemplazado", "completado", "actualizado") for v in (acc["ficha"], acc["externo"], acc["estado"])):
        acc["registro"] = _registrar(of, plan, acc)
    return acc


def _registrar(of, plan, acc):
    import registro as R
    base = rutas.dir_oferta(of) / "ejecuciones"
    n = max([int(p.name[3:]) for p in base.glob("EJ-*") if p.name[3:].isdigit()] + [0]) + 1
    ej = "EJ-%03d" % n
    ruta = base / ej / "registro.json"
    R.crear_ejecucion(str(ruta), of, ej, "importar", "herramientas/importar_oferta.py",
                      ficha="ofertas/%s/oferta.json (desde hyperflujo/ofertas/%s/oferta.json sha256 %s)" % (of, of, plan["sha256"]),
                      brief="analisis/equipo/tareas/TAREA_037_primer_producto_desde_cero_hyperflujo_auto.md (parte C)")
    if acc["ficha"] in ("creado", "reemplazado"):
        R.agregar_archivo(str(ruta), "ofertas/%s/oferta.json" % of, "fuente", "v001")
    R.cambiar_estado(str(ruta), "en_revision")
    return "ofertas/%s/ejecuciones/%s/registro.json" % (of, ej)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Importa una oferta del taller a hyperflujo-auto (seco por defecto).")
    ap.add_argument("--of", required=True)
    ap.add_argument("--origen", help="carpeta de la oferta en el taller (por defecto ../hyperflujo/ofertas/OF-NNN)")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--seco", action="store_true", help="solo muestra el plan (por defecto)")
    g.add_argument("--aplicar", action="store_true", help="escribe ficha, externo.local.json, estado y registro")
    ap.add_argument("--estado", help="estado a importar si el taller no lo fundamenta (%s)" % ", ".join(ESTADOS_IMPORTABLES))
    ap.add_argument("--d107", type=float, help="marca el corte puntual D107 (USD gastados sin ventas, p. ej. 10)")
    ap.add_argument("--forzar", action="store_true", help="pisa ficha, externo o estado distintos (el historial previo se guarda)")
    ap.add_argument("--archivo", help="archivo de estado (por defecto estado/productos.json)")
    a = ap.parse_args(argv)
    try:
        plan = planificar(a.of, a.origen, a.estado, a.d107)
    except (ErrorImportacion, ValueError) as e:
        print(json.dumps({"ok": False, "codigo": 2, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
        return 2
    r = resumen(plan)
    r["modo"] = "aplicar" if a.aplicar else "seco"
    if a.aplicar:
        try:
            r["acciones"] = aplicar(plan, forzar=a.forzar, archivo=a.archivo)
        except ErrorImportacion as e:
            r["error"] = str(e)
            print(json.dumps(sanitizar(r, plan["reales"]), ensure_ascii=False, indent=1))
            print(json.dumps({"ok": False, "codigo": 3, "motivo": sanitizar(str(e), plan["reales"]), "artefactos": []}, ensure_ascii=False))
            return 3
    texto = json.dumps(sanitizar(r, plan["reales"]), ensure_ascii=False, indent=1)
    print(texto)
    conflicto = a.aplicar and any("conflicto" in str(v) for v in r["acciones"].values())
    arts = [] if not a.aplicar else ["ofertas/%s/oferta.json" % plan["of"]] + (
        [r["acciones"]["registro"]] if r["acciones"].get("registro") else [])
    ok = (plan["objetivo"] is not None) and not conflicto
    print(json.dumps({"ok": ok, "codigo": 0 if ok else 3,
                      "motivo": ("importación %s de %s" % (r["modo"], plan["of"])) if ok else
                      ("conflicto: usar --forzar o revisar" if conflicto else "estado indeterminado: usar --estado"),
                      "artefactos": arts}, ensure_ascii=False))
    return 0 if ok else 3


if __name__ == "__main__":
    sys.exit(main())
