#!/usr/bin/env python3
"""Adaptador de ventas de Hotmart → `ventas.v1.1` (la misma forma que consume importar_ventas.py). Sin red.
Origen: hyperflujo/herramientas/importar_ventas_hotmart.py (copia SIN ADAPTAR — [PENDIENTE: importa `sellora_api` (fuera de alcance: el brief pide sin Sellora); quitar esa dependencia]). No se importa en la suite.

    python herramientas/importar_ventas_hotmart.py <export.csv> [--producto "Tejer a Dos Agujas desde Cero"]
                                                   [--salida ventas.json] [--zona America/Sao_Paulo] [--usd] [--sintetico]

Entrada: CSV de Hotmart → Ventas/Vendas → Exportar (español o portugués; separador `;` `,` o tab; utf-8 con/sin BOM o
latin-1/cp1252; montos con coma decimal). Los encabezados se normalizan (sin acentos, minúsculas, signos → espacio) y se
buscan por sinónimos; lo que no se reconoce queda en `columnas_no_reconocidas` y NO se lee. Las columnas del comprador
(nombre, correo, teléfono, documento, dirección) jamás se leen ni se guardan ni se imprimen.

Convención de atribución (nuestra): la landing pasa `src=<anuncio_id>` (p. ej. OF001-es-A1) y `sck=<ad.id de Meta>`.
`utm_content` de la fila v1.1 = `src` si existe; si no, la columna utm_content; si no, utm_term. Sin ninguno → utm_content
null. Los cuatro UTM null = «sin atribución». `utm_source/medium/campaign` salen de las columnas utm_* si existen (null
si no: no se inventan). `sck` no entra en la cuaterna: se resume en `sck_por_anuncio` ({anuncio: [ad.id]}).

Reglas:
  - Estado (normalizado): aprobada/aprobado/aprovado/approved/complete/completo/completed = venta; reembolsado/
    refunded/chargeback/contracargo/devuelto/devolvido/estornado = venta + reembolso; cancelado/expirado/boleto
    impreso/esperando pago/atrasado/recusado/en disputa/… = ignorada y contada en `descartadas`; un estado que no se
    conoce también se descarta (motivo `estado_desconocido`, con aviso): ante la duda no se cuenta.
  - Una fila por (día, moneda). Una venta reembolsada cuenta orden + brutas en el día de su venta; el reembolso resta
    en el día del REEMBOLSO si la exportación trae columna de fecha de reembolso con valor; si no, en el día de la
    venta (aviso). El reembolso se atribuye al mismo anuncio que la venta. Monto reembolsado = columna «valor
    reembolsado» si existe; si no, el total de la venta.
  - Día de la venta: fecha de aprobación/confirmación si existe; si no, fecha de venta/compra. Formatos dd/mm/aaaa
    [HH:MM[:SS]] (día primero, nunca mm/dd) y aaaa-mm-dd[ T]HH:MM:SS. Zona horaria: la que se declare (`--zona`); por
    defecto America/Sao_Paulo con aviso (Hotmart exporta en la zona de la cuenta: confirmar).
  - Monto: «Preço Total»/«Precio total»/«Valor de compra» (lo pagado por el comprador, en la moneda de compra). Si falta,
    «Preço do Produto» (no incluye bumps/impuestos; aviso). Con `usd=True`/`--usd` y una columna de precio en USD, se
    usa esa columna y la moneda es USD. Montos: «1.234,56», «17,00», «17.00», «US$ 17,00»; exactamente 3 dígitos tras
    el único separador = miles (los precios no tienen 3 decimales). Redondeo a 2 decimales.
  - Dedupe por ID de transacción: se cuenta una vez (si alguna copia es reembolso, gana el reembolso). Filas sin ID se
    cuentan todas (aviso).
  - Sin precio, sin moneda o sin fecha → descartada (v1.1 no admite montos null por entrada). comisiones, neto_comisiones
    y bumps_incluidos: null (desconocido, nunca 0).
  - Moneda: se deja la de la exportación. `SA.validar_ventas` solo admite USD/ARS: otra moneda (BRL, MXN…) queda en el
    resultado con aviso y `importar_ventas.leer` la rechazaría; el cruce con Meta pide la misma moneda.
"""
import argparse
import csv
import io
import json
import math
import os
import re
import sys
import unicodedata
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:   # revisión 035 h. 19: sellora_api no está en este repo; el módulo se importa igual y falla recién al usarlo
    import sellora_api as SA  # noqa: E402
except ImportError:  # [PENDIENTE: portar sellora_api (UTM_CAMPOS, validar_ventas) sin la dependencia de Sellora]
    class _SinSellora:
        def __getattr__(self, n):
            raise RuntimeError("importar_ventas_hotmart necesita sellora_api, que no está en hyperflujo-auto [PENDIENTE]")
    SA = _SinSellora()

ZONA_DEFECTO = "America/Sao_Paulo"
V11 = "ventas.v1.1"


class ErrorHotmart(Exception):
    pass


# ---- sinónimos de encabezados (ya normalizados) -------------------------------------------------------------------
CAMPOS = {
    "transaccion": ["transacao", "codigo da transacao", "codigo de transacao", "codigo de transaccion", "transaccion",
                    "id da transacao", "id de transaccion", "id de la transaccion", "transaction", "transaction code",
                    "transaction id", "numero da transacao", "numero de transaccion"],
    # De más específico a más genérico (revisión 032, H4): «Estado» a secas puede ser la provincia/UF del comprador.
    "estado": ["status da transacao", "estado de la transaccion", "status de la transaccion", "estado da transacao",
               "transaction status", "status", "situacao", "situacion", "estado"],
    "fecha_aprob": ["data de aprovacao", "data de confirmacao", "data da aprovacao", "fecha de aprobacion",
                    "fecha de confirmacion", "approval date", "confirmation date", "data de aprovacao do pagamento"],
    "fecha_venta": ["data da venda", "data de venda", "data da compra", "data de compra", "fecha de compra",
                    "fecha de venta", "purchase date", "sale date", "order date", "data do pedido", "fecha del pedido"],
    "fecha_reembolso": ["data de reembolso", "data do reembolso", "data de estorno", "data do estorno", "fecha de reembolso",
                        "fecha de devolucion", "fecha del reembolso", "refund date"],
    "moneda": ["moeda", "moneda", "moeda de compra", "moneda de compra", "moeda da compra", "currency",
               "purchase currency", "codigo da moeda"],
    "precio": ["preco total", "precio total", "valor de compra", "valor da compra", "valor total", "total price",
               "preco total com impostos", "total amount"],
    "precio_producto": ["preco do produto", "precio del producto", "precio de producto", "product price", "preco base",
                        "preco", "precio", "price"],
    "monto_reembolso": ["valor do reembolso", "valor reembolsado", "valor de reembolso", "monto reembolsado",
                        "monto del reembolso", "refund amount", "refunded amount", "valor estornado"],
    "producto": ["produto", "producto", "nome do produto", "nombre del producto", "nombre de producto", "product",
                 "product name"],
    "pais": ["pais", "pais do comprador", "pais del comprador", "pais de compra", "pais comprador", "country",
             "buyer country"],
    "src": ["src", "codigo src", "codigo src da venda", "hotmart src", "hotmart src code"],
    "sck": ["sck", "codigo sck", "hotmart sck", "hotmart sck code"],
    "utm_source": ["utm source"], "utm_medium": ["utm medium"], "utm_campaign": ["utm campaign"],
    "utm_content": ["utm content"], "utm_term": ["utm term"],
}

VENTA = {"aprobada", "aprobado", "aprovada", "aprovado", "approved", "complete", "completo", "completa", "completed",
         "pagada", "pagado", "paga", "pago", "paid", "concluida", "concluido"}
REEMBOLSO = {"reembolsada", "reembolsado", "refunded", "chargeback", "contracargo", "devuelta", "devuelto", "devolvida",
             "devolvido", "estornada", "estornado", "reembolso", "charged back"}
IGNORAR = {"cancelada", "cancelado", "canceled", "cancelled", "expirada", "expirado", "expired", "boleto impreso",
           "boleto impresso", "esperando pago", "aguardando pagamento", "waiting payment", "waiting for payment",
           "atrasada", "atrasado", "overdue", "recusada", "recusado", "rechazada", "rechazado", "declined", "refused",
           "abandono de carrito", "abandono de carrinho", "abandoned cart", "iniciada", "iniciado", "started", "pendiente",
           "pendente", "pending", "en espera", "em espera", "en disputa", "em disputa", "disputa", "protesto", "dispute",
           "bloqueada", "bloqueado", "blocked", "multiplos pagamentos", "multiples pagos", "parcelamento atrasado"}
MONEDAS = {"us$": "USD", "usd": "USD", "u$s": "USD", "dolar": "USD", "ar$": "ARS", "ars": "ARS", "r$": "BRL", "brl": "BRL",
           "eur": "EUR", "€": "EUR"}


def _norm(s):
    s = unicodedata.normalize("NFKD", (s or "").replace("﻿", ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9$€]+", " ", s).strip()


def _decodificar(b):
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("latin-1")


def _delimitador(linea):
    c = {d: linea.count(d) for d in (";", ",", "\t")}
    return max(c, key=c.get) if max(c.values()) else ";"


def leer_filas(ruta):
    """(encabezados, [dict normalizado→valor por fila]) — encabezados originales en orden."""
    with open(ruta, "rb") as f:
        texto = _decodificar(f.read())
    lineas = texto.splitlines()
    while lineas and not lineas[0].strip():
        lineas.pop(0)
    if not lineas:
        raise ErrorHotmart("archivo vacío")
    delim = _delimitador(lineas[0])
    filas = [r for r in csv.reader(io.StringIO("\n".join(lineas)), delimiter=delim) if any(c.strip() for c in r)]
    cab = [c.replace("﻿", "").strip() for c in filas[0]]
    return cab, [r + [""] * (len(cab) - len(r)) for r in filas[1:]]


def mapear(cab, usd=False):
    """campo → índice de columna (la primera que coincide). Devuelve (mapa, {campo: encabezado}, no_reconocidas)."""
    norm = [_norm(c) for c in cab]
    mapa = {}
    for campo, sinonimos in CAMPOS.items():
        # más palabras = más específico: se prueba primero (orden estable entre los de igual longitud)
        for s in sorted(sinonimos, key=lambda x: -len(x.split())):
            if s in norm:
                mapa[campo] = norm.index(s)
                break
    if usd:
        for i, n in enumerate(norm):
            if ("usd" in n.split() or "dolar" in n or "dolares" in n) and re.search(r"preco|precio|valor|price|total", n):
                mapa["precio_usd"] = i
                break
    usados = set(mapa.values())
    return mapa, {k: cab[i] for k, i in mapa.items()}, [c for i, c in enumerate(cab) if i not in usados and c]


# ---- valores ------------------------------------------------------------------------------------------------------
def parse_monto(v):
    """'1.234,56' → 1234.56; '17,00' → 17.0; 'US$ 17.00' → 17.0. Vacío/ilegible → None."""
    s = re.sub(r"[^0-9,.\-]", "", v or "")
    if not s or s in ("-", ".", ","):
        return None
    neg = s.startswith("-")
    s = s.lstrip("-").replace("-", "")
    puntos, comas = s.count("."), s.count(",")
    if puntos and comas:                     # el último separador es el decimal; el otro, miles
        dec = "." if s.rfind(".") > s.rfind(",") else ","
        s = s.replace("," if dec == "." else ".", "").replace(dec, ".")
    elif puntos + comas:
        sep = "." if puntos else ","
        if s.count(sep) > 1 or len(s.rsplit(sep, 1)[1]) == 3:      # 1.234.567 / 1.234 / 1,234: miles
            s = s.replace(sep, "")
        else:
            s = s.replace(sep, ".")
    try:
        x = float(s)
    except ValueError:
        return None
    if not math.isfinite(x):
        return None
    return round(-x if neg else x, 2)


RE_ISO = re.compile(r"^\s*(\d{4})[-/](\d{1,2})[-/](\d{1,2})")
RE_DMY = re.compile(r"^\s*(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})")


def parse_dia(v):
    """Fecha → 'AAAA-MM-DD' (día primero en dd/mm/aaaa). Vacío o inválido → None."""
    v = v or ""
    m = RE_ISO.match(v)
    if m:
        a, mes, d = (int(x) for x in m.groups())
    else:
        m = RE_DMY.match(v)
        if not m:
            return None
        d, mes, a = (int(x) for x in m.groups())
    try:
        return date(a, mes, d).isoformat()
    except ValueError:
        return None


def parse_moneda(v):
    t = _norm(v)
    if not t:
        return None
    if t in MONEDAS:
        return MONEDAS[t]
    return t.upper() if re.fullmatch(r"[a-z]{3}", t) else None


RE_UTM_BAD = re.compile(r"[^A-Za-z0-9._~%+:-]")


def limpiar_utm(v):
    """Valor UTM tal cual llega (sin decodificar); lo que el contrato no admite se codifica en %XX; vacío → None; ≤ 120."""
    v = (v or "").strip()
    if not v:
        return None
    v = RE_UTM_BAD.sub(lambda m: "".join("%%%02X" % b for b in m.group(0).encode("utf-8")), v)
    return v[:120]


def estado_clase(texto):
    t = _norm(texto)
    if t in VENTA:
        return "venta"
    if t in REEMBOLSO:
        return "reembolso"
    if t in IGNORAR:
        return "ignorar"
    return "desconocido"


# ---- importación --------------------------------------------------------------------------------------------------
def importar(ruta, producto=None, zona=None, moneda=None, usd=False):
    """Exportación de Hotmart → dict `ventas.v1.1` (+ origen, columnas, descartadas, resumen, avisos). Sin datos personales."""
    cab, filas = leer_filas(ruta)
    mapa, reconocidas, no_rec = mapear(cab, usd)
    avisos = []
    if "estado" not in mapa:
        raise ErrorHotmart("no se encontró la columna de estado (Status/Estado): no se puede saber qué es una venta")
    if "fecha_aprob" not in mapa and "fecha_venta" not in mapa:
        raise ErrorHotmart("no se encontró ninguna columna de fecha (Data da Venda / Fecha de compra / Data de Aprovação)")
    if "precio_usd" in mapa:
        col_precio, mon_fija = "precio_usd", "USD"
    elif "precio" in mapa:
        col_precio, mon_fija = "precio", None
    elif "precio_producto" in mapa:
        col_precio, mon_fija = "precio_producto", None
        avisos.append("sin «Preço Total»: se usó «%s» (precio del producto, sin bumps ni impuestos)" % reconocidas["precio_producto"])
    else:
        raise ErrorHotmart("no se encontró columna de precio (Preço Total / Precio total / Valor de compra)")
    if usd and "precio_usd" not in mapa:
        avisos.append("se pidió USD pero no hay columna de precio en USD: se usó la moneda de compra")
    mon_fija = mon_fija or (moneda.upper() if moneda else None)
    if mon_fija is None and "moneda" not in mapa:
        raise ErrorHotmart("no se encontró columna de moneda (Moeda/Moneda); pasá moneda= / --moneda")
    if "transaccion" not in mapa:
        avisos.append("sin columna de transacción: no se puede deduplicar")
    if "fecha_aprob" not in mapa:
        avisos.append("sin fecha de aprobación: el día de la venta es la fecha de venta/compra")
    if "src" not in mapa and "utm_content" not in mapa and "utm_term" not in mapa:
        avisos.append("sin columnas src/utm_content/utm_term: todas las ventas quedan «sin atribución»")
    zona_decl = zona or ZONA_DEFECTO
    if not zona:
        avisos.append("zona horaria no declarada: se asumió %s (Hotmart exporta en la zona de la cuenta); confirmar" % ZONA_DEFECTO)

    def val(r, campo):
        i = mapa.get(campo)
        return r[i].strip() if i is not None and i < len(r) else ""

    filtro = _norm(producto) if producto else None
    descartadas, motivos = 0, {}
    productos_vistos, desconocidos = set(), 0

    def descartar(motivo):
        nonlocal descartadas
        descartadas += 1
        motivos[motivo] = motivos.get(motivo, 0) + 1

    ventas, por_id, duplicadas, sin_id, otro_producto = [], {}, 0, 0, 0
    for r in filas:
        nom = val(r, "producto")
        if nom:
            productos_vistos.add(nom)
        clase = estado_clase(val(r, "estado"))
        if clase == "ignorar":
            descartar("estado_ignorado")
            continue
        if clase == "desconocido":
            desconocidos += 1
            descartar("estado_desconocido")
            continue
        if filtro and "producto" in mapa:
            n = _norm(nom)
            if n != filtro and filtro not in n:
                otro_producto += 1
                continue
        dia = parse_dia(val(r, "fecha_aprob")) or parse_dia(val(r, "fecha_venta"))
        mon = mon_fija or parse_moneda(val(r, "moneda"))
        monto = parse_monto(val(r, col_precio))
        if dia is None:
            descartar("sin_fecha")
            continue
        if mon is None:
            descartar("sin_moneda")
            continue
        if monto is None or monto < 0:
            descartar("sin_precio")
            continue
        reemb = None
        dia_reemb = None
        if clase == "reembolso":
            m_r = parse_monto(val(r, "monto_reembolso"))
            reemb = monto if m_r is None else abs(m_r)
            dia_reemb = parse_dia(val(r, "fecha_reembolso")) or dia
        src, sck = limpiar_utm(val(r, "src")), limpiar_utm(val(r, "sck"))
        content = src or limpiar_utm(val(r, "utm_content")) or limpiar_utm(val(r, "utm_term"))
        v = {"dia": dia, "moneda": mon, "monto": monto, "reembolso": reemb, "dia_reembolso": dia_reemb,
             "pais": val(r, "pais") or None, "sck": sck, "src": src,
             "utm": (limpiar_utm(val(r, "utm_source")), limpiar_utm(val(r, "utm_medium")), limpiar_utm(val(r, "utm_campaign")), content)}
        tid = val(r, "transaccion")
        if not tid:
            sin_id += 1
            ventas.append(v)
        elif tid in por_id:
            duplicadas += 1
            if v["reembolso"] is not None and por_id[tid]["reembolso"] is None:
                por_id[tid].update(v)                 # si alguna copia es reembolso, gana el reembolso
        else:
            por_id[tid] = v
            ventas.append(v)

    if desconocidos:
        # sin valores crudos (H4): solo la columna y el conteo
        avisos.append("%d filas con estado no reconocido en la columna «%s» (descartadas)" % (desconocidos, reconocidas.get("estado")))
    if sin_id:
        avisos.append("%d filas sin ID de transacción: no se pudieron deduplicar" % sin_id)
    if filtro and "producto" not in mapa:
        avisos.append("se pidió filtrar por producto pero no hay columna de producto: no se filtró")
    if filtro and "producto" in mapa and not ventas:
        avisos.append("ninguna venta coincide con el producto %r; productos en la exportación: %s" %
                      (producto, ", ".join(sorted(productos_vistos)) or "—"))
    if any(x["reembolso"] is not None for x in ventas) and "fecha_reembolso" not in mapa:
        avisos.append("sin fecha de reembolso: los reembolsos restan en el día de la venta")

    # (día, moneda) → cuaterna → acumuladores
    acum = {}
    for x in ventas:
        e = acum.setdefault((x["dia"], x["moneda"]), {}).setdefault(x["utm"], [0, 0.0, 0.0])
        e[0] += 1
        e[1] += x["monto"]
        if x["reembolso"] is not None:
            er = acum.setdefault((x["dia_reembolso"], x["moneda"]), {}).setdefault(x["utm"], [0, 0.0, 0.0])
            er[2] += x["reembolso"]
    out_filas = []
    for (dia, mon) in sorted(acum, key=lambda k: (k[0], k[1])):
        entradas = []
        for cuaterna, (o, b, rr) in acum[(dia, mon)].items():
            if o == 0 and rr == 0:
                continue
            e = dict(zip(SA.UTM_CAMPOS, cuaterna))
            e.update(ordenes=o, brutas=round(b, 2), reembolsos=round(rr, 2))
            entradas.append(e)
        if not entradas:
            continue
        nulas = [e for e in entradas if all(e[c] is None for c in SA.UTM_CAMPOS)]
        resto = sorted((e for e in entradas if e not in nulas), key=SA._clave_orden_utm)
        utm = resto + nulas
        o = sum(e["ordenes"] for e in utm)
        b = round(sum(e["brutas"] for e in utm), 2)
        rr = round(sum(e["reembolsos"] for e in utm), 2)
        out_filas.append({"dia": dia, "moneda": mon, "ordenes": o, "brutas": b, "reembolsos": rr,
                          "neto_reembolsos": round(b - rr, 2), "comisiones": None, "neto_comisiones": None,
                          "bumps_incluidos": None, "utm": utm})

    if not out_filas:
        avisos.append("la exportación no trae ventas utilizables")
    monedas = sorted({f["moneda"] for f in out_filas})
    fuera = [m for m in monedas if m not in ("USD", "ARS")]
    if fuera:
        avisos.append("moneda %s: ventas.v1.1 / importar_ventas solo admiten USD y ARS; el cruce con Meta no es posible tal cual"
                      % ", ".join(fuera))
    if len(monedas) > 1:
        avisos.append("más de una moneda (%s): nunca se suma entre monedas" % ", ".join(monedas))

    sck_por = {}
    paises = {}
    for x in ventas:
        if x["src"] and x["sck"] and x["sck"] not in sck_por.setdefault(x["src"], []):
            sck_por[x["src"]].append(x["sck"])
        if x["pais"]:
            paises[x["pais"]] = paises.get(x["pais"], 0) + 1
    resumen = resumir(out_filas)
    resp = {"esquema": V11, "origen": "hotmart", "zona_horaria": zona_decl,
            "desde": out_filas[0]["dia"] if out_filas else None, "hasta": out_filas[-1]["dia"] if out_filas else None,
            "producto_id": None, "producto_filtro": producto, "montos": "unidades de la moneda (no centavos)",
            "filas": out_filas, "descartadas": descartadas, "descartadas_detalle": motivos,
            "duplicadas": duplicadas, "otro_producto": otro_producto, "filas_leidas": len(filas),
            "columnas_reconocidas": reconocidas, "columnas_no_reconocidas": no_rec,
            "sck_por_anuncio": sck_por, "paises": paises, "resumen": resumen, "avisos": avisos}
    return resp


def resumir(filas):
    """Por moneda: días, órdenes, brutas, reembolsos y órdenes sin atribución (entrada con los cuatro UTM null)."""
    out = {}
    for f in filas:
        r = out.setdefault(f["moneda"], {"dias": 0, "ordenes": 0, "brutas": 0.0, "reembolsos": 0.0, "sin_atribucion": 0})
        r["dias"] += 1
        r["ordenes"] += f["ordenes"]
        r["brutas"] = round(r["brutas"] + f["brutas"], 2)
        r["reembolsos"] = round(r["reembolsos"] + f["reembolsos"], 2)
        r["sin_atribucion"] += sum(e["ordenes"] for e in f["utm"] if all(e[c] is None for c in SA.UTM_CAMPOS))
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description="Importa la exportación de ventas de Hotmart a ventas.v1.1")
    ap.add_argument("export")
    ap.add_argument("--producto")
    ap.add_argument("--salida", help="ventas.json de salida (ventas.v1.1; lo lee importar_ventas.py)")
    ap.add_argument("--zona", help="zona horaria de la exportación (por defecto %s, con aviso)" % ZONA_DEFECTO)
    ap.add_argument("--moneda", help="moneda si la exportación no trae columna de moneda")
    ap.add_argument("--usd", action="store_true", help="usar la columna de precio en USD si existe")
    ap.add_argument("--sintetico", action="store_true", help="marca la salida como sintética")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")      # consolas cp1252 de Windows
    try:
        resp = importar(a.export, a.producto, zona=a.zona, moneda=a.moneda, usd=a.usd)
    except (ErrorHotmart, OSError) as e:
        print("ERROR %s" % e)
        return 1
    if a.sintetico:
        resp["sintetico"] = True
    if a.salida:
        os.makedirs(os.path.dirname(os.path.abspath(a.salida)), exist_ok=True)
        with open(a.salida, "w", encoding="utf-8") as f:
            json.dump(resp, f, ensure_ascii=False, indent=1)
    print("Hotmart -> ventas.v1.1 (%s a %s, zona %s)" % (resp["desde"] or "-", resp["hasta"] or "-", resp["zona_horaria"]))
    for mon, r in sorted(resp["resumen"].items()):
        print("  %s: dias=%d ordenes=%d brutas=%.2f reembolsos=%.2f sin_atribucion=%d" %
              (mon, r["dias"], r["ordenes"], r["brutas"], r["reembolsos"], r["sin_atribucion"]))
    print("  descartadas=%d %s duplicadas=%d" % (resp["descartadas"], json.dumps(resp["descartadas_detalle"], ensure_ascii=False), resp["duplicadas"]))
    print("  columnas no reconocidas: %d" % len(resp["columnas_no_reconocidas"]))
    for av in resp["avisos"]:
        print("  Aviso: %s" % av)
    if a.salida:
        print("  salida: %s" % a.salida)
    return 0


if __name__ == "__main__":
    sys.exit(main())
