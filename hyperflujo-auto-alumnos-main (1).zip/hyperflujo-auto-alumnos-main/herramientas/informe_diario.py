#!/usr/bin/env python3
"""informe_diario.py — informe Markdown de la corrida diaria (Hyperflujo, TAREA 035).

generar(fecha, resultados, archivo=None, salida=None) -> str. Sin cifras inventadas: lo desconocido se muestra «nulo».
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import estado as E  # noqa: E402


def _v(x):
    return "nulo" if x is None else str(x)


def consumo(resultados):
    """Suma el consumo que devuelven los workers (revisión 035 h. 17). Un worker sin dato de consumo = nulo, nunca 0."""
    total = 0
    for r in resultados:
        res = r.get("resultado")
        if res is None:
            continue
        c = res.get("consumo")
        if c is None:
            return None
        total += c
    return total


def generar(fecha, resultados, archivo=None, salida=None, titulo="Informe diario"):
    bloq = [r for r in resultados if r.get("bloqueo") or r["accion"] in ("bloqueado", "fallo", "marcar_rechazo", "pausa_tecnica")]
    ls = [f"# {titulo} — {fecha}", "", f"Generado por hyperflujo-auto (núcleo). Consumo pago de esta corrida: {_v(consumo(resultados))}.", "",
          "## Bloqueos, rechazos y pausas (primero)", ""] + ([f"- **{r['of']}** ({r['estado']} → {r['accion']}): {r['motivo']}" for r in bloq] or ["- Ninguno."]) + ["",
          "## Decisiones", "", "| Producto | Estado | Acción | Worker | Resultado | Motivo |", "|---|---|---|---|---|---|"]
    for r in resultados:
        res = r.get("resultado")
        ok = "—" if res is None else ("ok" if res.get("ok") else "falló")
        ls.append(f"| {r['of']} | {r['estado']} | {r['accion']} | {r.get('worker') or '—'} | {ok} | {r['motivo']} |")
    ls += ["", "## Estado de productos", "", "| Producto | Estado | Gasto | Ventas | Ingresos | Ficticio |", "|---|---|---|---|---|---|"]
    for p in E.productos(archivo=archivo):
        t = E.acumulado(p)
        ls.append(f"| {p['of']} | {p['estado']} | {_v(t['gasto'])} | {_v(t['ventas'])} | {_v(t['ingresos'])} | {'sí' if p.get('ficticio') else 'no'} |")
    pend = [r for r in resultados if "PENDIENTE" in r["motivo"] or r["accion"] in ("esperar", "bloqueado")]
    ls += ["", "## Para el dueño", ""] + ([f"- {r['of']}: {r['motivo']}" for r in pend] or ["- Nada pendiente."]) + [""]
    texto = "\n".join(ls)
    if salida:
        Path(salida).parent.mkdir(parents=True, exist_ok=True)
        Path(salida).write_text(texto, encoding="utf-8")
    return texto
