"""Reimplementación en el repo de las reglas del kit de skills (el kit, método Ramiro) que usa OF-007.

Fuente (solo lectura): ../cerebro-kit/cerebro-kit/claude/skills/<skill>/SKILL.md. Cada función cita la skill y la
sección. Solo stdlib, sin red: los datos entran ya leídos (conector de Meta en modo lectura, HTML guardado en disco).
"""
