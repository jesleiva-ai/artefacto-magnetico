"""activar.py — compuerta «activar_si_corresponde» de OF-007 (TAREA 040), para la estructura el kit (ABO, un conjunto por ángulo).

Decide con datos leídos (conector de Meta + HTTP), sin red propia; el agente activa por el conector solo si devuelve ok.
Exige, todo a la vez (D60, D88, D101, regla 4):
  - topes escritos en la ficha (diario × días, moneda USD, autorizado_por = dueño exacto, autorizacion_ref);
  - autorizaciones vigentes `activar_campana` y `gasto_meta` (techo_usd ≥ diario × días) para la oferta;
  - campaña PAUSED con spend_cap = diario × días; suma de daily_budget de los conjuntos = diario;
  - ningún anuncio rechazado ni en revisión (DISAPPROVED, WITH_ISSUES, PENDING_REVIEW, IN_PROCESS);
  - límite de la cuenta ≥ suma de spend_cap de las campañas NO archivadas (las archivadas no se pueden editar ni gastar);
  - landing y checkout respondiendo 200;
  - TAREA 041 E3: el sitio publicado entero pasa compuerta_sitio (`sitio=compuerta(of)`, parámetro obligatorio).
"""
NO_ACTIVABLES = {"DISAPPROVED", "WITH_ISSUES", "PENDING_REVIEW", "IN_PROCESS", "PREAPPROVED_PENDING"}
ARCHIVADAS = {"ARCHIVED", "DELETED"}


def _usd(v):
    if isinstance(v, dict):
        v = v.get("value")
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def suma_caps_no_archivadas(campanas):
    """campanas: [{effective_status, spend_cap}] → (suma USD, None si alguna no archivada no tiene cap conocido)."""
    total = 0.0
    for c in campanas:
        if str(c.get("effective_status") or c.get("status") or "").upper() in ARCHIVADAS:
            continue
        cap = _usd(c.get("spend_cap"))
        if cap is None:
            return None
        total += cap
    return total


def compuerta(of):
    """E3: el sitio PUBLICADO entero pasa compuerta_sitio (relleno, legales, píxel, checkout, testimonios, CTA,
    confirmación del checkout desde el país). Deja el bloqueo en estado/bloqueos.jsonl si falla."""
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import compuerta_sitio
    return compuerta_sitio.exigir(of, "activar_kit")


def activar_si_corresponde(ficha, alcances, techo_gasto_meta, campana, conjuntos, anuncios, campanas_cuenta,
                           limite_cuenta_usd, http, duenos, *, sitio):
    """`sitio` es OBLIGATORIO (E3, sin bypass): el resultado de compuerta(of) leído en esta misma corrida."""
    razones = []
    if not (isinstance(sitio, dict) and sitio.get("ok") is True):
        razones.append("E3: el sitio publicado no pasó compuerta_sitio: %s" % "; ".join(
            ((sitio or {}).get("problemas") if isinstance(sitio, dict) else None) or ["sin resultado de la compuerta"])[:300])
    p = (ficha.get("campana") or {}).get("presupuesto") or {}
    diario, dias = p.get("diario"), p.get("dias")
    if not (isinstance(diario, (int, float)) and diario > 0 and isinstance(dias, int) and dias > 0) or p.get("moneda") != "USD":
        razones.append("ficha sin diario/días/moneda USD")
        total = None
    else:
        total = round(diario * dias, 2)
    if str(p.get("autorizado_por", "")).strip() not in duenos or not p.get("autorizacion_ref"):
        razones.append("ficha: autorizado_por no es un dueño exacto o falta autorizacion_ref")
    for a in ("activar_campana", "gasto_meta"):
        if a not in alcances:
            razones.append("falta autorización vigente «%s»" % a)
    if total is not None and (techo_gasto_meta is None or techo_gasto_meta < total):
        razones.append("techo de gasto_meta %s < diario × días %s" % (techo_gasto_meta, total))
    if str(campana.get("effective_status")) != "PAUSED":
        razones.append("la campaña no está en PAUSED (%s)" % campana.get("effective_status"))
    if total is not None and _usd(campana.get("spend_cap")) != total:
        razones.append("spend_cap de campaña %s ≠ %s" % (_usd(campana.get("spend_cap")), total))
    suma_conj = sum(_usd(c.get("daily_budget")) or 0 for c in conjuntos)
    if diario and abs(suma_conj - diario) > 1e-6:
        razones.append("suma de daily_budget de conjuntos %s ≠ diario %s" % (suma_conj, diario))
    malos = [a.get("name") for a in anuncios if str(a.get("effective_status")).upper() in NO_ACTIVABLES]
    if malos or not anuncios:
        razones.append("anuncios no activables (rechazados o en revisión): %s" % (malos or "ninguno cargado"))
    suma = suma_caps_no_archivadas(campanas_cuenta)
    if suma is None:
        razones.append("una campaña no archivada de la cuenta no tiene spend_cap conocido: falla cerrado")
    elif limite_cuenta_usd is None or suma > limite_cuenta_usd:
        razones.append("límite de la cuenta %s < suma de spend_cap no archivados %s" % (limite_cuenta_usd, suma))
    for k in ("landing", "checkout"):
        if http.get(k) != 200:
            razones.append("%s no responde 200 (%s)" % (k, http.get(k)))
    return {"ok": not razones, "razones": razones, "total_autorizado": total, "suma_caps_no_archivadas": suma}
