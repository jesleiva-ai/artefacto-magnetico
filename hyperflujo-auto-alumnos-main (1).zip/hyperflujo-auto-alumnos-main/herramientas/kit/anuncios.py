"""anuncios.py — creativos estáticos 4:5 (1080×1350) de OF-007 con texto exacto (HTML → PNG con pdf.mjs --png).

  python -m herramientas.kit.anuncios OF-007   → ofertas/OF-007/anuncios/html/*.html + anuncios/png/*.png + guiones.md

El kit `creativos`: un ángulo por conjunto, cada pieza con guion y ángulo nombrados, nombre de archivo = nombre del anuncio
(dos dígitos, slug del ángulo, formato). El texto quemado se escribe acá (no lo dibuja la IA) y solo dice lo que la ficha
respalda (validacion_producto.json). Las fotos son KI-generadas y se aclara en la pieza.
"""
import json
import os
import subprocess
import sys

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

BASE_CSS = """
@font-face{font-family:'Oswald';font-weight:700;src:url('../../landing/fonts/Oswald-700.woff2')}
@font-face{font-family:'Oswald';font-weight:600;src:url('../../landing/fonts/Oswald-600.woff2')}
@font-face{font-family:'Inter';font-weight:600;src:url('../../landing/fonts/Inter-600.woff2')}
@font-face{font-family:'Inter';font-weight:700;src:url('../../landing/fonts/Inter-700.woff2')}
@font-face{font-family:'Source Serif 4';font-weight:400;src:url('../../landing/fonts/SourceSerif4-400.woff2')}
html,body{margin:0;width:1080px;height:1350px;overflow:hidden;font-family:'Inter';color:#2A211B;background:#FBF7F0}
.foto{position:absolute;inset:0;background-size:cover;background-position:center}
.oben{position:absolute;left:0;right:0;top:0;padding:60px 64px 40px;background:linear-gradient(#FBF7F0 72%,rgba(251,247,240,0))}
h1{font-family:'Oswald';font-weight:700;text-transform:uppercase;font-size:96px;line-height:1;margin:0}
h1 em{font-style:normal;color:#B4432F}
.sub{font-family:'Source Serif 4';font-size:42px;margin-top:18px;line-height:1.2}
.drei{position:absolute;left:64px;right:64px;bottom:150px;display:grid;grid-template-columns:1fr 1fr 1.35fr;gap:16px}
.drei div{background:#2A211B;color:#fff;border-radius:18px;padding:18px 10px;text-align:center}
.drei small{display:block;font-size:22px;letter-spacing:.14em;text-transform:uppercase;opacity:.8}
.drei b{font-family:'Oswald';font-size:50px}
.leiste{position:absolute;left:0;right:0;bottom:0;height:110px;background:#B4432F;color:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 64px;font-family:'Oswald';font-weight:600;font-size:40px;text-transform:uppercase}
.leiste span{font-family:'Inter';font-weight:600;font-size:26px;text-transform:none;opacity:.95}
.ki{position:absolute;right:16px;bottom:118px;font-size:18px;color:#fff;text-shadow:0 0 6px rgba(0,0,0,.8)}
.raster{position:absolute;left:48px;right:48px;top:400px;bottom:140px;display:grid;grid-template-columns:1fr 1fr;gap:20px}
.raster div{border-radius:18px;overflow:hidden;position:relative;background-size:cover;background-position:center}
.raster p{position:absolute;left:0;right:0;bottom:0;margin:0;background:rgba(42,33,27,.88);color:#fff;padding:12px 14px;font-size:24px;line-height:1.25}
.raster p b{font-family:'Oswald';font-size:30px;display:block}
.chips{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}
.chips span{background:#B4432F;color:#fff;font-family:'Oswald';font-weight:600;font-size:30px;padding:8px 18px;border-radius:10px;text-transform:uppercase}
"""

PIEZAS = [
    {"archivo": "01-pommes-falle_4x5", "angulo": "pommes-falle", "guion": "contraste injusto",
     "foto": "hero.jpg", "h1": "Schluss mit <em>nur Pommes</em>.",
     "sub": "100 deutsche Klassiker aus dem Airfryer – mit Temperatur, Zeit und Wende-Hinweis.",
     "drei": ("200 °C", "10 Min.", "nach 5 Min.")},
    {"archivo": "02-pommes-falle_4x5", "angulo": "pommes-falle", "guion": "contraste injusto",
     "foto": "pommes_falle.jpg", "h1": "Dein Airfryer kann <em>mehr</em>.",
     "sub": "Schnitzel, Frikadellen, Kartoffelpuffer, Kaiserschmarrn: 100 Klassiker, jeder mit drei Zahlen.",
     "chips": ["8 Kapitel", "48 vegetarisch", "+5 Bonus"]},
    {"archivo": "03-drei-zahlen_4x5", "angulo": "drei-zahlen", "guion": "miedo al error costoso",
     "foto": "hero.jpg", "h1": "Nie wieder <em>Minuten raten</em>.",
     "sub": "Über jedem Rezept: Temperatur, Zeit und wann du wendest. Hier: Schnitzel Wiener Art.",
     "drei": ("200 °C", "10 Min.", "nach 5 Min.")},
    {"archivo": "04-drei-zahlen_4x5", "angulo": "drei-zahlen", "guion": "miedo al error costoso",
     "raster": [("plato_frikadellen.jpg", "Frikadellen", "180 °C · 14 Min. · nach 7"),
                ("plato_kartoffelpuffer.jpg", "Kartoffelpuffer", "200 °C · 14 Min. · nach 8"),
                ("plato_haehnchen.jpg", "Hähnchenschenkel", "190 °C · 28 Min. · nach 14"),
                ("plato_currywurst.jpg", "Currywurst", "200 °C · 10 Min. · nach 5")],
     "h1": "Drei Zahlen. <em>Fertig.</em>", "sub": "Temperatur · Zeit · Wenden – über jedem der 100 Rezepte."},
    {"archivo": "05-hausmannskost_4x5", "angulo": "hausmannskost", "guion": "valor primero",
     "foto": "mockup_tablet.jpg", "pos": "center bottom", "h1": "Hausmannskost <em>aus dem Korb</em>.",
     "sub": "Das E-Book mit 100 deutschen Klassikern für deinen Airfryer.", "chips": ["100 Rezepte", "5 Bonus", "PDF"]},
    {"archivo": "06-hausmannskost_4x5", "angulo": "hausmannskost", "guion": "valor primero",
     "raster": [("plato_flammkuchen.jpg", "Flammkuchen", "200 °C · 7 Min."), ("plato_bratapfel.jpg", "Bratapfel", "170 °C · 20 Min."),
                ("plato_kartoffelpuffer.jpg", "Kartoffelpuffer", "200 °C · 14 Min."), ("plato_frikadellen.jpg", "Frikadellen", "180 °C · 14 Min.")],
     "h1": "Vom Strammen Max bis <em>Kaiserschmarrn</em>.", "sub": "100 Klassiker, die du kennst – angepasst an den Airfryer."},
]

TEXTOS = {
    "pommes-falle": {
        "primario": ("Dein Airfryer macht fast nur Pommes?\n\nDabei kann er Schnitzel, Frikadellen, Kartoffelpuffer und "
                     "Kaiserschmarrn. Was fehlt, sind die richtigen Zahlen.\n\nKorbklassiker: 100 deutsche Klassiker für den "
                     "Airfryer – über jedem Rezept Temperatur, Zeit und wann du wendest.\n✓ 8 Kapitel, 48 vegetarische Rezepte\n"
                     "✓ Zutaten aus jedem Supermarkt\n✓ 5 Bonus, u. a. Umrechnungs-Tabelle Backofen → Airfryer\n✓ PDF, sofort per E-Mail, kein Abo\n\n"
                     "Hol dir die Korbklassiker."),
        "titular": "100 Klassiker statt nur Pommes", "descripcion": "E-Book · 14,90 € einmalig · kein Abo"},
    "drei-zahlen": {
        "primario": ("Außen zu dunkel, innen noch roh? Beim Airfryer liegt es fast immer an Zeit und Temperatur.\n\n"
                     "In den Korbklassikern steht über jedem Rezept, was du am Gerät einstellst: °C, Minuten und wann du wendest. "
                     "Ablesen, einstellen, fertig – auch ohne Airfryer-Erfahrung.\n✓ 100 deutsche Klassiker\n✓ Kerntemperaturen bei "
                     "Fleisch, Geflügel und Fisch\n✓ Tiefkühl-Spickzettel mit 25 Produkten\n\nHol dir die Korbklassiker."),
        "titular": "Drei Zahlen über jedem Rezept", "descripcion": "E-Book · 14,90 € einmalig · kein Abo"},
    "hausmannskost": {
        "primario": ("Die Gerichte, mit denen du aufgewachsen bist – jetzt aus dem Airfryer.\n\nKorbklassiker ist ein E-Book mit 100 "
                     "Rezepten der deutschen Hausmannskost: Frühstück & Brotzeit, Fleisch, Geflügel, Fisch, Kartoffeln, Gemüse, Snacks "
                     "und Süßes.\n✓ Jedes Rezept mit Temperatur, Zeit und Wende-Hinweis\n✓ 4-Wochen-Plan mit Einkaufslisten\n✓ 15 Tage "
                     "Geld-zurück-Garantie\n\nHol dir die Korbklassiker."),
        "titular": "Hausmannskost aus dem Airfryer", "descripcion": "E-Book · 14,90 € einmalig · kein Abo"},
}


def html_pieza(p):
    if p.get("raster"):
        celdas = "".join("<div style=\"background-image:url('../../medios/web/%s')\"><p><b>%s</b>%s</p></div>" % (f.replace(".jpg", ".jpg"), t, s)
                         for f, t, s in p["raster"])
        cuerpo = "<div class='oben' style='background:#FBF7F0'><h1>%s</h1><div class='sub'>%s</div></div><div class='raster'>%s</div>" % (p["h1"], p["sub"], celdas)
    else:
        extra = ""
        if p.get("drei"):
            a, b, c = p["drei"]
            extra = "<div class='drei'><div><small>Temperatur</small><b>%s</b></div><div><small>Zeit</small><b>%s</b></div><div><small>Wenden</small><b>%s</b></div></div>" % (a, b, c)
        chips = "<div class='chips'>%s</div>" % "".join("<span>%s</span>" % c for c in p.get("chips", [])) if p.get("chips") else ""
        cuerpo = ("<div class='foto' style=\"background-image:url('../../medios/web/%s');background-position:%s\"></div><div class='oben'><h1>%s</h1><div class='sub'>%s</div>%s</div>%s"
                  % (p["foto"], p.get("pos", "center"), p["h1"], p["sub"], chips, extra))
    return ("<!doctype html><html lang='de'><head><meta charset='utf-8'><style>%s</style></head><body>%s<div class='ki'>Abbildungen KI-generiert</div>"
            "<div class='leiste'>Korbklassiker<span>100 Rezepte · E-Book</span></div></body></html>" % (BASE_CSS, cuerpo))


def construir(of):
    base = os.path.join(RAIZ, "ofertas", of, "anuncios")
    os.makedirs(os.path.join(base, "html"), exist_ok=True)
    os.makedirs(os.path.join(base, "png"), exist_ok=True)
    guiones = ["# Guiones y ángulos — OF-007 (kit creativos)\n",
               "Un ángulo por conjunto. Nombre del anuncio = nombre del archivo. Texto quemado escrito (no dibujado por la IA) y "
               "cotejado con producto/validacion_producto.json. Fotos KI-generadas (aclarado en cada pieza).\n"]
    for p in PIEZAS:
        h = os.path.join(base, "html", p["archivo"] + ".html")
        open(h, "w", encoding="utf-8").write(html_pieza(p))
        subprocess.run(["node", os.path.join(RAIZ, "herramientas", "kit", "pdf.mjs"), h, "x", "--png",
                        os.path.join(base, "png", p["archivo"] + ".png"), "--ancho", "1080", "--alto", "1350"], check=True,
                       capture_output=True)
        guiones.append("- `%s` · ángulo **%s** · guion madre «%s» · texto quemado: %s / %s" % (
            p["archivo"], p["angulo"], p["guion"], p["h1"].replace("<em>", "").replace("</em>", ""), p["sub"]))
    guiones.append("\n## Textos por conjunto (copy del anuncio)\n")
    for k, t in TEXTOS.items():
        guiones.append("### %s\n- Titular: %s\n- Descripción: %s\n- Texto principal:\n\n```\n%s\n```\n" % (k, t["titular"], t["descripcion"], t["primario"]))
    guiones.append("### video (presentadora de IA, metodo-6c)\n- `07-drei-zahlen-video_9x16` · ángulo **drei-zahlen** · la presentadora "
                   "es una persona generada con IA que presenta el producto (no es clienta ni testimonio); dice: «Dein Airfryer macht nur "
                   "Pommes? In den Korbklassikern steht über jedem Rezept: Temperatur, Zeit und wann du wendest. Hundert deutsche Klassiker.» "
                   "Rótulo permanente «KI-generierte Person» + divulgación de IA de Meta.\n")
    open(os.path.join(base, "guiones.md"), "w", encoding="utf-8").write("\n".join(guiones))
    json.dump({"piezas": [p["archivo"] for p in PIEZAS], "textos": TEXTOS}, open(os.path.join(base, "anuncios.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return [p["archivo"] for p in PIEZAS]


if __name__ == "__main__":
    print(construir(sys.argv[1] if len(sys.argv) > 1 else "OF-007"))
