"""bitacora.py — registro por etapa de OF-007 (TAREA 040): ejecución en registro.py + línea en estado/.

  python -m herramientas.kit.bitacora abrir  OF-007 EJ-001 cazar "<operador>" [--brief ruta] [--ficha ruta]
  python -m herramientas.kit.bitacora cerrar OF-007 EJ-001 --agente 12 [--espera 0] [--humano 0]
        [--archivos a,b] [--consumo "proveedor=real:unidad"] [--pendiente "..."] [--parar "..."]

Escribe estado/OF-007_bitacora.jsonl (estado vivo, fuera de git) para el informe diario y la tabla comparativa.
Consumo real desconocido = null, nunca 0 (regla 4).
"""
import argparse
import datetime
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from herramientas import registro  # noqa: E402

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _ahora():
    return datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat(timespec="seconds")


def ruta_reg(of, ej):
    return os.path.join(RAIZ, "ofertas", of, "ejecuciones", ej, "registro.json")


def anotar(of, linea):
    os.makedirs(os.path.join(RAIZ, "estado"), exist_ok=True)
    linea = dict(linea, of=of, hora=_ahora())
    with open(os.path.join(RAIZ, "estado", f"{of}_bitacora.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(linea, ensure_ascii=False) + "\n")
    return linea


def abrir(of, ej, modulo, operador, brief=None, ficha=None, deriva_de=None):
    r = ruta_reg(of, ej)
    ent = os.path.join(os.path.dirname(r), "entradas")
    os.makedirs(ent, exist_ok=True)
    copias = {}
    for clave, origen in (("brief", brief), ("ficha", ficha)):
        if origen:
            destino = os.path.join(ent, os.path.basename(origen))
            shutil.copyfile(origen, destino)
            copias[clave] = os.path.relpath(destino, os.path.dirname(r)).replace("\\", "/")
    registro.crear_ejecucion(r, of, ej, modulo, operador, deriva_de=deriva_de, **copias)
    registro.cambiar_estado(r, "en_trabajo")
    return anotar(of, {"evento": "inicio", "ejecucion": ej, "etapa": modulo})


def cerrar(of, ej, agente=0, espera=0, humano=0, archivos=(), consumo=(), pendientes=(), parar=None, estado="en_revision"):
    r = ruta_reg(of, ej)
    registro.registrar_tiempo(r, humano_min=humano, espera_min=espera, agente_min=agente)
    for a in archivos:
        registro.agregar_archivo(r, a, "exportacion", "v001")
    cons = {}
    for c in consumo:
        prov, _, resto = c.partition("=")
        real, _, unidad = resto.partition(":")
        cons[prov] = {"real": None if real in ("", "null", "None") else float(real), "unidad": unidad or None}
    registro.cambiar_estado(r, estado)
    return anotar(of, {"evento": "fin", "ejecucion": ej, "etapa": registro.leer(r)["modulo"],
                       "minutos": {"agente": agente, "espera": espera, "humano": humano},
                       "consumo": cons, "pendientes": list(pendientes), "parar": parar})


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("accion", choices=("abrir", "cerrar"))
    p.add_argument("of")
    p.add_argument("ej")
    p.add_argument("modulo", nargs="?")
    p.add_argument("operador", nargs="?")
    p.add_argument("--brief")
    p.add_argument("--ficha")
    p.add_argument("--deriva-de")
    p.add_argument("--agente", type=float, default=0)
    p.add_argument("--espera", type=float, default=0)
    p.add_argument("--humano", type=float, default=0)
    p.add_argument("--archivos", default="")
    p.add_argument("--consumo", action="append", default=[])
    p.add_argument("--pendiente", action="append", default=[])
    p.add_argument("--parar")
    a = p.parse_args(argv)
    if a.accion == "abrir":
        print(json.dumps(abrir(a.of, a.ej, a.modulo, a.operador, a.brief, a.ficha, a.deriva_de), ensure_ascii=False))
    else:
        arch = [x for x in a.archivos.split(",") if x]
        print(json.dumps(cerrar(a.of, a.ej, a.agente, a.espera, a.humano, arch, a.consumo, a.pendiente, a.parar),
                         ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
