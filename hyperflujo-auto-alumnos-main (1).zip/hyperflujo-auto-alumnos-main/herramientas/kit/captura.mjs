#!/usr/bin/env node
/** captura.mjs — captura de página completa de un HTML local o URL a un ancho dado (390 = celular; el kit mide a 384/681).
 *  node herramientas/kit/captura.mjs <html|url> <salida.png> [ancho=390] [--botones]  → con --botones imprime la
 *  posición (px y %) de cada enlace de compra (a.cta) y del bloque #angebot: compuerta 1 «tobogán» de evaluar-landing. */
import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { existsSync } from 'node:fs';
const [ent, sal, ancho = '390'] = process.argv.slice(2);
const exe = ['C:/Program Files/Google/Chrome/Application/chrome.exe'].find(p => existsSync(p));
const b = await chromium.launch(exe ? { executablePath: exe } : {});
const p = await (await b.newContext({ viewport: { width: Number(ancho), height: 681 }, deviceScaleFactor: 1 })).newPage();
await p.goto(/^https?:/.test(ent) ? ent : pathToFileURL(resolve(ent)).href, { waitUntil: 'networkidle' });
await p.evaluate(async () => { for (let y = 0; y < document.body.scrollHeight; y += 600) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 60)); } window.scrollTo(0, 0); });
if (process.argv.includes('--botones')) {
  const r = await p.evaluate(() => { const H = document.body.scrollHeight; const of = document.querySelector('#angebot');
    return { alto: H, oferta_px: of ? Math.round(of.getBoundingClientRect().top + scrollY) : null,
      botones: [...document.querySelectorAll('a.cta, button.cta, a[href*="pay.hotmart"]')].map(a => ({ texto: a.textContent.trim().slice(0, 40), px: Math.round(a.getBoundingClientRect().top + scrollY), pct: Math.round(100 * (a.getBoundingClientRect().top + scrollY) / H) })) }; });
  console.log(JSON.stringify(r));
}
await p.screenshot({ path: resolve(sal), fullPage: true });
await b.close();
