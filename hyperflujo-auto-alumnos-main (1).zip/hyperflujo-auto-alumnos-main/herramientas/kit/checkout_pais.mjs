// Mira el checkout PÚBLICO de Hotmart como comprador de un país (solo lectura: no llena datos ni compra).
// Chrome local sin sesión (no usa el perfil del robot). Cambia el país con «Cambiar país» y deja captura móvil
// y de escritorio + un JSON con el texto visible relevante (precio, IVA, order bumps, medios de pago).
//
//   node herramientas/kit/checkout_pais.mjs <url_checkout> <carpeta> --pais "España|Spain" --locale es-ES --tz Europe/Madrid
//        [--buscar "Plantillas de documentos" --buscar "Chuleta"]
// Sale 0 si encontró todo lo pedido en --buscar; 1 si falta algo.
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const av = process.argv.slice(2);
const pos = [], op = { buscar: [] };
for (let i = 0; i < av.length; i++) {
  if (av[i] === '--pais') op.pais = av[++i];
  else if (av[i] === '--locale') op.locale = av[++i];
  else if (av[i] === '--tz') op.tz = av[++i];
  else if (av[i] === '--buscar') op.buscar.push(av[++i]);
  else pos.push(av[i]);
}
const [url, sal] = pos;
if (!/^https:\/\/pay\.hotmart\.com\//.test(url || '') || !sal || !op.pais) {
  console.error('uso: checkout_pais.mjs <https://pay.hotmart.com/...> <carpeta> --pais "<regex>" [--locale xx-XX --tz Zona] [--buscar texto]...');
  process.exit(2);
}
mkdirSync(sal, { recursive: true });

async function mirar(b, ancho, alto, nombre) {
  const ctx = await b.newContext({ locale: op.locale || 'es-ES', timezoneId: op.tz || 'Europe/Madrid', viewport: { width: ancho, height: alto } });
  const p = await ctx.newPage();
  await p.goto(url, { waitUntil: 'networkidle', timeout: 60000 }).catch(() => {});
  await p.waitForTimeout(3000);
  let cambio = false;
  const boton = p.getByText(/Cambiar pa[ií]s|Alterar pa[ií]s|Ändern|Change country/i).first();
  if (await boton.count()) {
    await boton.click({ timeout: 8000 }).catch(() => {});
    await p.waitForTimeout(1500);
    const opc = p.getByText(new RegExp(`^(${op.pais})$`, 'i')).first();
    if (await opc.count()) { await opc.click({ timeout: 8000 }).catch(() => {}); cambio = true; }
    await p.waitForTimeout(6000);
  }
  const t = (await p.innerText('body').catch(() => '')).replace(/\s+/g, ' ');
  await p.screenshot({ path: join(sal, nombre + '.png'), fullPage: true });
  await ctx.close();
  return { cambio, texto: t };
}

const b = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe' });
const movil = await mirar(b, 430, 1100, 'checkout_movil');
const escritorio = await mirar(b, 1366, 900, 'checkout_escritorio');
await b.close();
const t = movil.texto;
const cerca = (re, antes = 80, despues = 220) => { const i = t.search(re); return i < 0 ? null : t.slice(Math.max(0, i - antes), i + despues); };
const salida = {
  url_sin_codigo: url.replace(/\/[A-Z][0-9]{6,}[A-Z]/, '/***'),
  hora: new Date().toISOString(),
  pais_cambiado: movil.cambio && escritorio.cambio,
  precio: cerca(/€|EUR/, 60, 160),
  iva: cerca(/IVA|USt|VAT|impuesto/i),
  medios_pago: cerca(/Tarjeta|PayPal|Google Pay|Apple Pay|Bizum|SEPA|Klarna/i, 40, 260),
  buscados: Object.fromEntries(op.buscar.map((s) => [s, cerca(new RegExp(s.replace(/[^\p{L}\p{N} ]/gu, '.'), 'iu'), 40, 260)])),
};
writeFileSync(join(sal, 'checkout.json'), JSON.stringify(salida, null, 1));
console.log(JSON.stringify(salida, null, 1));
process.exit(Object.values(salida.buscados).some((v) => !v) || !salida.pais_cambiado ? 1 : 0);
