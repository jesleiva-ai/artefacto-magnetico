"""chequeo.py — Paso 0 de `investigar-mercado` (el kit): chequeo liviano de potencial, 10 preguntas, 3 asesinas.

Cita: cerebro-kit/claude/skills/investigar-mercado/SKILL.md «Paso 0 — Chequeo liviano de potencial».
Veredicto GO / DUDOSA / NO. Una asesina (☠) en «no» = NO. Solo con GO se sigue al paso 1.
Cada respuesta es {"si": bool|None, "evidencia": str}. None = sin dato (cuenta como duda, nunca como sí).
"""

PREGUNTAS = {
    1: ("¿Está escalada? Días activos + cantidad de anuncios + regla de 3 anunciantes.", False),
    2: ("¿Es replicable sin la cara/autoridad del que la corre? ¿No es VSL larga?", True),
    3: ("¿El resultado se ve en video en 3 segundos?", False),
    4: ("¿Qué hay gratis del tema y de qué se quejan? (hay hueco frente a lo gratis)", False),
    5: ("¿La promesa se puede escribir sin pisar categorías restringidas de Meta?", True),
    6: ("¿Hay deseo adyacente obvio para bump y upsell? Sin AOV no cierra.", True),
    7: ("¿Hay volumen en el idioma que se va a atacar?", False),
    8: ("¿Se puede producir el producto?", False),
    9: ("¿Es estacional? (respuesta «sí» = NO es un problema de estacionalidad)", False),
    10: ("¿El precio del front aguanta el CPA esperable?", False),
}


class ChequeoIncompleto(ValueError):
    pass


def veredicto(respuestas):
    """Devuelve (veredicto, detalle). Exige las 10 preguntas."""
    faltan = [n for n in PREGUNTAS if n not in (respuestas or {})]
    if faltan:
        raise ChequeoIncompleto(f"faltan preguntas: {faltan}")
    asesinas_no, dudas, noes = [], [], []
    for n, (texto, asesina) in PREGUNTAS.items():
        v = respuestas[n].get("si")
        if v is False and asesina:
            asesinas_no.append(n)
        elif v is False:
            noes.append(n)
        elif v is None:
            dudas.append(n)
    if asesinas_no:
        return "NO", {"asesinas": asesinas_no, "noes": noes, "dudas": dudas}
    # una asesina sin dato tampoco deja pasar a GO
    dudas_asesinas = [n for n in dudas if PREGUNTAS[n][1]]
    if dudas_asesinas or len(noes) + len(dudas) >= 3:
        return "DUDOSA", {"asesinas": [], "noes": noes, "dudas": dudas}
    return "GO", {"asesinas": [], "noes": noes, "dudas": dudas}
