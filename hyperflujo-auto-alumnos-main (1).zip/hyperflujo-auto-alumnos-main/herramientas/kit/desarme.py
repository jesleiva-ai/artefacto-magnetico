"""desarme.py — pasada automática mínima de `desarme-completo` (el kit) sobre un HTML ya guardado en disco.

Cita: cerebro-kit/claude/skills/desarme-completo/SKILL.md (Paso 1: fuente, anatomía, copy, paleta) y
espia-ofertas/SKILL.md FASE 0 (firma de la oferta: entregable, precio y ancla, orden de secciones, plataforma,
proporción imágenes/HTML, fuentes/paleta). No reemplaza mirar las fotos (Paso 2): solo mide lo que el HTML trae.
Sin red y sin dependencias.
"""
import re
from collections import Counter
from html.parser import HTMLParser

PLATAFORMAS = ("shopify", "woocommerce", "elementor", "systeme", "clickfunnels", "hotmart", "kajabi", "kiwify",
               "eduzz", "monetizze", "lovable", "wix", "webflow", "gumroad", "stripe", "impultienda", "netlify")
VSL = ("vturb", "converteai", "wistia", "vimeo.com/video", "youtube.com/embed", "panda video", "pandavideo")
PRECIO = re.compile(r"(?:(?:US)?\$|€|R\$|£)\s?\d{1,4}(?:[.,]\d{2})?|\d{1,4}(?:[.,]\d{2})?\s?(?:€|EUR|USD|BRL|MXN)")


class _Lector(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.titulos, self.texto, self.imgs, self.videos, self.iframes = [], [], 0, 0, []
        self._en = None
        self._saltar = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style", "noscript"):
            self._saltar += 1
        if tag in ("h1", "h2", "h3"):
            self._en = tag
            self.titulos.append([tag, ""])
        if tag == "img":
            self.imgs += 1
        if tag == "video":
            self.videos += 1
        if tag == "iframe":
            self.iframes.append(a.get("src") or "")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript") and self._saltar:
            self._saltar -= 1
        if tag == self._en:
            self._en = None

    def handle_data(self, data):
        if self._saltar:
            return
        s = data.strip()
        if not s:
            return
        self.texto.append(s)
        if self._en and self.titulos:
            self.titulos[-1][1] = (self.titulos[-1][1] + " " + s).strip()


def colores(html, n=8):
    """Colores hex más repetidos en el CSS/HTML (aproximación al TOKENS.txt; el render da los roles)."""
    hexes = [h.lower() for h in re.findall(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b", html)]
    norm = ["#" + (h if len(h) == 6 else "".join(c * 2 for c in h)) for h in hexes]
    return Counter(norm).most_common(n)


def fuentes(html):
    fam = re.findall(r"font-family\s*:\s*([^;}\"]+)", html, flags=re.I)
    google = re.findall(r"fonts\.googleapis\.com/css2?\?family=([^\"'&]+)", html)
    return sorted({f.strip().split(",")[0].strip("'\" ") for f in fam} | {g.split(":")[0].replace("+", " ") for g in google})


def firma(html):
    """Firma de la oferta medible desde el fuente."""
    lec = _Lector()
    lec.feed(html or "")
    bajo = (html or "").lower()
    texto = " ".join(lec.texto)
    precios = PRECIO.findall(texto)
    vsl = any(v in bajo for v in VSL)
    return {
        "plataformas": [p for p in PLATAFORMAS if p in bajo],
        "titulos": [f"{t}: {s}" for t, s in lec.titulos if s][:40],
        "imgs": lec.imgs,
        "videos": lec.videos,
        "iframes": lec.iframes[:10],
        "palabras": len(texto.split()),
        "proporcion_img_por_100_palabras": round(100 * lec.imgs / max(1, len(texto.split())), 2),
        "precios_vistos": precios[:20],
        "sospecha_vsl": vsl,
        "colores": colores(html or ""),
        "fuentes": fuentes(html or ""),
        "checkout": [p for p in ("pay.hotmart.com", "checkout", "kiwify", "stripe", "paypal", "shopify") if p in bajo],
    }
