"""espia.py — reglas de `espia-ofertas` (el kit) sobre anuncios ya leídos de la Biblioteca.

Cita: cerebro-kit/claude/skills/espia-ofertas/SKILL.md
  FASE 1  dos ejes (días activos del anuncio activo MÁS VIEJO y ≥10 anuncios prendidos), canal web vs WhatsApp/DM,
          regla de 3 anunciantes, orden por días × anuncios.
  FASE 3  score de replicabilidad /10 con descarte inmediato (VSL, SaaS, servicio, físico, membresía compleja).
  FASE 3.5 semáforo por mercado VIRGEN / FLOJO / SATURADO.
Sin red: recibe los dicts que devuelve `ads_library_search` (id, page_id, page_name, ad_delivery_start_time, ...).
"""
import time

DIAS_DESCARTE = 14      # «descartar <14 días»
DIAS_ESTUDIO = 30       # «estudiar 30-90+ días»
ACTIVOS_ESCALA = 10     # «ANUNCIOS PRENDIDOS ≥ 10»

PISTAS_WHATSAPP = ("api.whatsapp.com", "wa.me", "whatsapp", "chatea con nosotros", "envíanos un mensaje",
                   "instagram.com", "m.me/", "messenger")


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def dias_activos(inicio_epoch, ahora=None):
    """Días = hoy − ad_delivery_start_time (epoch en segundos). None si no hay dato."""
    i = _num(inicio_epoch)
    if i is None:
        return None
    a = time.time() if ahora is None else float(ahora)
    return max(0, int((a - i) // 86400))


def por_pagina(anuncios, ahora=None):
    """Agrupa por page_id: activos vistos, días del anuncio activo más viejo, títulos y monedas."""
    pags = {}
    for ad in anuncios or []:
        pid = str(ad.get("page_id") or "")
        if not pid:
            continue
        p = pags.setdefault(pid, {"page_id": pid, "page_name": ad.get("page_name"), "activos": 0,
                                  "inicio_mas_viejo": None, "titulos": [], "monedas": []})
        p["activos"] += 1
        i = _num(ad.get("ad_delivery_start_time"))
        if i is not None and (p["inicio_mas_viejo"] is None or i < p["inicio_mas_viejo"]):
            p["inicio_mas_viejo"] = i
        t = (ad.get("ad_creative_link_title") or "").strip()
        if t and t not in p["titulos"]:
            p["titulos"].append(t)
        m = ad.get("currency")
        if m and m not in p["monedas"]:
            p["monedas"].append(m)
    for p in pags.values():
        p["dias"] = dias_activos(p["inicio_mas_viejo"], ahora)
    return pags


def dos_ejes(dias, activos, dias_min=DIAS_DESCARTE, activos_min=ACTIVOS_ESCALA):
    """«La escala se mide con DOS ejes, y hacen falta los dos».

    escala            → pasa los dos (días ≥ 14 y activos ≥ 10)
    demanda_probada   → pasa uno solo: «demanda probada, escala sin confirmar» (no se borra, va a lista aparte)
    descartar         → no pasa ninguno
    Un dato faltante nunca cuenta como pasado.
    """
    eje1 = dias is not None and dias >= dias_min
    eje2 = activos is not None and activos >= activos_min
    if eje1 and eje2:
        return "escala"
    if eje1 or eje2:
        return "demanda_probada"
    return "descartar"


def canal(destino, texto=""):
    """Canal de venta leído en el destino del anuncio: 'whatsapp_dm' o 'web' (None si no hay destino)."""
    d = (destino or "").lower()
    t = (texto or "").lower()
    if not d and not t:
        return None
    if any(p in d for p in PISTAS_WHATSAPP) or any(p in t for p in PISTAS_WHATSAPP[3:5]):
        return "whatsapp_dm"
    return "web" if d else None


def regla_3_anunciantes(paginas, dias_min=DIAS_DESCARTE):
    """«PROBADA cuando 3+ anunciantes DISTINTOS corren el mismo hook/oferta/formato 14+ días».

    `paginas`: iterable de dicts con page_id y dias (de la misma oferta/formato). Devuelve (probada, n_distintos).
    """
    distintos = {str(p.get("page_id")) for p in paginas or [] if (p.get("dias") or 0) >= dias_min and p.get("page_id") not in (None, "")}
    return len(distintos) >= 3, len(distintos)


DESCARTE_INMEDIATO = ("vsl", "saas", "software", "servicio_1a1", "fisico", "membresia_compleja")


def score_replicabilidad(rasgos):
    """Score /10 de la FASE 3. `rasgos` es un dict de booleanos.

    Descarte inmediato (0) si alguno de DESCARTE_INMEDIATO es True.
    +3 entregable digital simple · +2 landing de comunicación directa · +2 contenido generable con IA
    +2 precio impulso (USD 10-40) · +1 plataforma simple.
    """
    r = rasgos or {}
    if any(r.get(k) for k in DESCARTE_INMEDIATO):
        return 0
    puntos = {"entregable_simple": 3, "landing_directa": 2, "generable_ia": 2, "precio_impulso": 2,
              "plataforma_simple": 1}
    return sum(v for k, v in puntos.items() if r.get(k))


def semaforo(escalados_bien_ejecutados, existentes, landings_flojas=None):
    """FASE 3.5: VIRGEN (nadie la corre) · FLOJO (existe con landings malas o sin escala) ·
    SATURADO (3+ jugadores escalados y bien ejecutados).

    escalados_bien_ejecutados: jugadores que pasan los dos ejes con ejecución sólida.
    existentes: anunciantes de la misma oferta vistos en ese mercado (cualquier escala).
    """
    if (escalados_bien_ejecutados or 0) >= 3:
        return "SATURADO"
    if (existentes or 0) == 0:
        return "VIRGEN"
    return "FLOJO"


def ordenar(candidatos):
    """Orden dentro de cada bloque de canal: días activos × nº de anuncios prendidos (desc)."""
    return sorted(candidatos, key=lambda c: -((c.get("dias") or 0) * (c.get("activos") or 0)))


def informe_por_canal(candidatos):
    """Bloques separados por canal; un bloque vacío se declara, no se omite."""
    bloques = {"web": [], "whatsapp_dm": []}
    for c in candidatos:
        bloques.setdefault(c.get("canal") or "web", []).append(c)
    salida = {}
    for k, v in bloques.items():
        salida[k] = ordenar(v) if v else f"no encontré ninguna de {k} con ≥{ACTIVOS_ESCALA} anuncios"
    return salida
