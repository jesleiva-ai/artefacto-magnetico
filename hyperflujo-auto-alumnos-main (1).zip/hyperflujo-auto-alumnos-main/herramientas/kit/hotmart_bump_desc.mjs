#!/usr/bin/env node
/** hotmart_bump_desc.mjs — corrige la descripción del order bump en la página de pago ya publicada (OF-007).
 *  node herramientas/kit/hotmart_bump_desc.mjs <regex url builder> <texto> <salida_dir> [--real --ej <registro.json>]
 *  Seco: abre el editor del componente y llena el texto, captura y NO guarda. Real: además «Guardar cambios» y
 *  «Actualizar publicación», cada clic registrado antes (solicitud gratuita) y cerrado después (regla 6). */
import { chromium } from 'playwright';
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
const [re, texto, sal] = process.argv.slice(2);
const real = process.argv.includes('--real'); const ej = process.argv[process.argv.indexOf('--ej') + 1];
mkdirSync(sal, { recursive: true });
const reg = (...a) => execFileSync('python', ['herramientas/hotmart_registro.py', ...a], { encoding: 'utf8', env: { ...process.env, PYTHONIOENCODING: 'utf-8' } }).trim();
const b = await chromium.connectOverCDP('http://127.0.0.1:9223');
const p = b.contexts()[0].pages().find(x => new RegExp(re).test(x.url()));
if (!p) { console.log('sin pestaña del editor'); process.exit(2); }
await p.bringToFront(); await p.waitForTimeout(1500);
const card = p.locator('text=Ja, ich will die 24').first();
await card.scrollIntoViewIfNeeded().catch(() => {});
const box = await card.boundingBox();
const pencils = await p.locator('[class*=edit i], [class*=pencil i], button:has(svg)').all();
let abierto = false;
for (const el of pencils) { const bb = await el.boundingBox().catch(() => null); if (bb && box && bb.y < box.y && bb.y > box.y - 140 && bb.x > box.x) { await el.click({ force: true }); abierto = true; break; } }
if (!abierto && box) { await p.mouse.click(box.x + box.width - 20, box.y - 75); }
await p.waitForTimeout(2500);
const ta = p.locator('textarea[placeholder="Escribe las características del producto"]').first();
if (!(await ta.count())) { await p.screenshot({ path: join(sal, 'sin_textarea.png') }); console.log('no se abrió el editor del bump'); process.exit(3); }
await ta.fill(texto); await p.waitForTimeout(800);
await p.screenshot({ path: join(sal, '01_llenado.png') });
const ins = p.locator('button:text-is("Guardar"), button:has-text("Insertar")').first();
if (await ins.count()) { await ins.click(); await p.waitForTimeout(2000); }
await p.screenshot({ path: join(sal, '02_aplicado.png') });
if (!real) { console.log('SECO: texto cargado en el editor, sin guardar'); process.exit(0); }
for (const [clave, sel] of [['guardar_cambios', 'button:has-text("Guardar cambios")'], ['actualizar_publicacion', 'button:has-text("Actualizar publicación")']]) {
  const bt = p.locator(sel).first();
  if (!(await bt.count())) { console.log('falta botón', clave); process.exit(4); }
  const sid = reg('inicio', ej, `checkout:OF-007:bump_desc:${clave}`, JSON.stringify({ herramienta: 'hotmart_bump_desc.mjs', paso: clave, url: p.url() }));
  await bt.click(); await p.waitForTimeout(5000);
  console.log(clave, reg('id', ej, sid, `checkout:OF-007:bump_desc:${clave}`));
  await p.screenshot({ path: join(sal, `03_${clave}.png`) });
}
process.exit(0);
