#!/usr/bin/env node
/** hotmart_mirar.mjs — SOLO LECTURA: abre una pestaña propia en el Chrome del perfil del robot (127.0.0.1:9223), va a una
 * URL de app.hotmart.com, captura la pantalla y lista las capas que interceptan clics (p. ej. el tour «productfruits»).
 * Con --cerrar-tour pulsa el botón de cierre del tour si existe (no guarda nada del producto). Cierra solo su pestaña.
 *   node herramientas/kit/hotmart_mirar.mjs <url> <salida.png> [--cerrar-tour] [--archivos] */
import { abrir, esHotmart } from '../hotmart_navegador.mjs';
const [url, sal] = process.argv.slice(2);
if (!/^https:\/\/app\.hotmart\.com\//.test(url)) { console.log('solo app.hotmart.com'); process.exit(2); }
const { pagina, cerrar } = await abrir({ via: 'perfil', propia: true });
try {
  await pagina.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await pagina.waitForTimeout(6000);
  const info = await pagina.evaluate(() => [...document.querySelectorAll('[class*=productfruits], [id*=productfruits]')].map(e => ({ tag: e.tagName, clase: String(e.className).slice(0, 80), visible: !!(e.offsetWidth || e.offsetHeight), botones: [...e.querySelectorAll('button, [role=button], a')].map(b => (b.innerText || b.getAttribute('aria-label') || '').trim().slice(0, 40)) })));
  console.log(JSON.stringify(info));
  if (process.argv.includes('--cerrar-tour')) {
    const b = pagina.locator('.productfruits--container button[aria-label*=lose i], .productfruits--container button:has-text("Omitir"), .productfruits--container button:has-text("Cerrar"), .productfruits--container [class*=close]');
    console.log('botones de cierre:', await b.count());
    if (await b.count()) { await b.first().click({ timeout: 5000 }).catch(e => console.log('no se pudo:', String(e).slice(0, 80))); await pagina.waitForTimeout(1500); }
  }
  const ti = process.argv.indexOf('--entendido');
  if (ti >= 0) {
    // aviso informativo de producto (no es aceptar términos): se busca «Entendido» en la página y en sus marcos;
    // si vive en un shadow DOM cerrado, se pulsa por posición relativa a la ventana (pasada como fracción x,y).
    let hecho = false;
    for (const f of pagina.frames()) {
      const b = f.getByRole('button', { name: 'Entendido' });
      if (await b.count().catch(() => 0)) { await b.first().click({ timeout: 5000 }).catch(() => {}); hecho = true; break; }
    }
    if (!hecho && process.argv[ti + 1]) {
      const [fx, fy] = process.argv[ti + 1].split(',').map(Number); const vp = pagina.viewportSize() || await pagina.evaluate(() => ({ width: innerWidth, height: innerHeight }));
      await pagina.mouse.click(Math.round(vp.width * fx), Math.round(vp.height * fy)); hecho = 'posicion';
    }
    console.log('entendido:', hecho); await pagina.waitForTimeout(2000);
  }
  if (process.argv.includes('--checkout')) {
    const html = await pagina.content() + ' ' + await pagina.innerText('body').catch(() => '');
    const m = [...new Set((html.match(/(?:pay|go)\.hotmart\.com\/[A-Za-z0-9]{6,}/g) || []))];
    console.log(JSON.stringify({ checkout_codigos: m.map(x => x.split('/')[1]) }));
  }
  if (process.argv.includes('--archivos')) {   // lista los archivos que muestra la página (p. ej. Contenido del Producto), sin tocar nada
    const lineas = [];
    for (const f of pagina.frames()) {
      const t = await f.innerText('body').catch(() => '');
      for (const l of t.split(/\r?\n/)) if (/\.(pdf|zip|docx|xlsx|pptx|epub)\b/i.test(l)) lineas.push(l.trim().slice(0, 160));
    }
    console.log(JSON.stringify({ archivos: [...new Set(lineas)] }));
  }
  await pagina.screenshot({ path: sal });
} finally { await cerrar(); }
process.exit(0);
