"""libro.py — arma el HTML imprimible del recetario de OF-007 (principal, bonus y bump) desde producto/contenido/*.json.

  python -m herramientas.kit.libro OF-007            → producto/html/{korbklassiker,bonus_*,advent}.html + validacion
  node herramientas/kit/pdf.mjs <html> <pdf>         → PDF A5 (Playwright, Chrome local)

Reglas: solo lo que trae el contenido (la ficha manda); cada receta en su página con la 3-Zahlen-Methode arriba
(°C · Minuten · Wenden); aclaración de IA y de valores orientativos en la primera página (D8). Sin red.
"""
import html
import json
import os
import sys

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# Fotos disponibles por receta (las demás van sin foto: la landing no promete foto en cada receta).
FOTOS_RECETA = {"R011": "hero.jpg", "R013": "plato_frikadellen.jpg", "R016": "plato_currywurst.jpg",
                "R027": "plato_haehnchen.jpg", "R053": "plato_kartoffelpuffer.jpg", "R071": "plato_flammkuchen.jpg",
                "R091": "plato_bratapfel.jpg"}
FOTOS_KAPITEL = {"Frühstück & Brotzeit": "tapa_fondo.jpg", "Fleisch": "plato_frikadellen.jpg",
                 "Geflügel": "plato_haehnchen.jpg", "Fisch": "tapa_fondo.jpg", "Kartoffeln & Beilagen": "plato_kartoffelpuffer.jpg",
                 "Gemüse & Vegetarisch": "plato_flammkuchen.jpg", "Snacks & Fingerfood": "plato_currywurst.jpg",
                 "Süßes & Gebäck": "plato_bratapfel.jpg"}

CSS = """
@font-face{font-family:'Oswald';font-weight:700;src:url('FONTS/Oswald-700.woff2') format('woff2')}
@font-face{font-family:'Oswald';font-weight:600;src:url('FONTS/Oswald-600.woff2') format('woff2')}
@font-face{font-family:'Inter';font-weight:400;src:url('FONTS/Inter-400.woff2') format('woff2')}
@font-face{font-family:'Inter';font-weight:600;src:url('FONTS/Inter-600.woff2') format('woff2')}
@font-face{font-family:'Inter';font-weight:700;src:url('FONTS/Inter-700.woff2') format('woff2')}
@font-face{font-family:'Source Serif 4';font-weight:400;src:url('FONTS/SourceSerif4-400.woff2') format('woff2')}
@font-face{font-family:'Source Serif 4';font-style:italic;font-weight:400;src:url('FONTS/SourceSerif4-400i.woff2') format('woff2')}
@page{size:A5;margin:0}
:root{--papier:#FBF7F0;--tinte:#2A211B;--paprika:#B4432F;--paprika-hell:#F3E1D8;--grau:#6E625A;--linie:#E6DCD0}
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:var(--papier);color:var(--tinte);font-family:'Inter',sans-serif;font-size:9.4pt;line-height:1.42}
.seite{width:148mm;height:210mm;padding:13mm 12mm 12mm;position:relative;page-break-after:always;overflow:hidden;background:var(--papier)}
.seite:last-child{page-break-after:auto}
h1,h2,h3{font-family:'Oswald',sans-serif;font-weight:700;letter-spacing:.01em;margin:0;line-height:1.05;text-transform:uppercase}
.fuss{position:absolute;bottom:6mm;left:12mm;right:12mm;font-size:7pt;color:var(--grau);display:flex;justify-content:space-between;border-top:.3mm solid var(--linie);padding-top:1.6mm}
.tapa{padding:0;background:#efe7db}
.tapa .kopf{padding:14mm 12mm 6mm;text-align:center}
.tapa h1{font-size:40pt;color:var(--tinte)}
.tapa .unter{font-family:'Source Serif 4',serif;font-size:15pt;margin-top:3mm}
.tapa .linie3{margin:5mm auto 0;display:inline-flex;gap:2mm;font-family:'Oswald';font-weight:600;font-size:10pt;text-transform:uppercase}
.tapa .linie3 span{background:var(--paprika);color:#fff;padding:1.2mm 3mm;border-radius:1mm}
.tapa .bild{position:absolute;left:0;right:0;bottom:0;height:118mm;background-size:cover;background-position:center}
.tapa .marke{position:absolute;bottom:5mm;left:0;right:0;text-align:center;color:#fff;font-family:'Oswald';font-size:9pt;letter-spacing:.2em;text-shadow:0 0 3mm rgba(0,0,0,.6)}
.text p{margin:0 0 2.6mm}
.text h2{font-size:17pt;margin-bottom:4mm;color:var(--paprika)}
.box{background:var(--paprika-hell);border-radius:2mm;padding:3mm 3.5mm;margin:3mm 0;font-size:8.6pt}
.box b{color:var(--paprika)}
.inhalt h2{font-size:17pt;color:var(--paprika);margin-bottom:3mm}
.inhalt .kap{font-family:'Oswald';font-weight:600;text-transform:uppercase;font-size:9.5pt;margin:2.4mm 0 .8mm;color:var(--tinte)}
.inhalt .liste{columns:2;column-gap:5mm;font-size:7.3pt;line-height:1.3}
.inhalt .liste div{break-inside:avoid}
.inhalt .nr{color:var(--paprika);font-weight:700;display:inline-block;width:7mm}
.kapitel{padding:0}
.kapitel .bild{position:absolute;inset:0;background-size:cover;background-position:center}
.kapitel .schild{position:absolute;left:10mm;right:10mm;bottom:16mm;background:var(--papier);padding:6mm;border-radius:2mm}
.kapitel .schild h2{font-size:24pt;color:var(--paprika)}
.kapitel .schild p{margin:2mm 0 0;font-family:'Source Serif 4',serif;font-size:10.5pt}
.rezept .nr{font-family:'Oswald';font-weight:600;color:var(--paprika);font-size:9pt;letter-spacing:.08em}
.rezept h3{font-size:17pt;margin:1mm 0 1.2mm}
.rezept .ut{font-family:'Source Serif 4',serif;font-style:italic;color:var(--grau);font-size:9.6pt;margin-bottom:3mm}
.drei{display:grid;grid-template-columns:1fr 1fr 1.5fr;gap:1.6mm;margin-bottom:3mm}
.drei div{background:var(--tinte);color:#fff;border-radius:1.6mm;padding:1.8mm 2mm;text-align:center}
.drei div small{display:block;font-size:6.3pt;letter-spacing:.12em;text-transform:uppercase;opacity:.75}
.drei div b{font-family:'Oswald';font-weight:700;font-size:13pt;line-height:1.1}
.drei div.w b{font-size:9.6pt;font-family:'Inter';font-weight:700;line-height:1.25;display:block;padding-top:.6mm}
.meta{font-size:7.6pt;color:var(--grau);margin-bottom:3mm}
.foto{height:42mm;border-radius:2mm;background-size:cover;background-position:center;margin-bottom:3mm}
.spalten{display:grid;grid-template-columns:38%  1fr;gap:4mm}
.spalten h4{font-family:'Oswald';font-weight:600;text-transform:uppercase;font-size:8.6pt;color:var(--paprika);margin:0 0 1.4mm;letter-spacing:.06em}
.spalten ul{margin:0;padding-left:3.6mm;font-size:8.3pt}
.spalten ol{margin:0;padding-left:4.2mm;font-size:8.6pt}
.spalten li{margin-bottom:1.1mm}
.tipp{margin-top:3mm;border-left:1mm solid var(--paprika);padding:1.4mm 2.6mm;font-size:8.2pt;background:#fff8f2}
.kern{margin-top:2mm;font-size:7.8pt;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:7.4pt}
th{background:var(--tinte);color:#fff;text-align:left;padding:1.3mm 1.6mm;font-weight:600}
td{padding:1.2mm 1.6mm;border-bottom:.25mm solid var(--linie);vertical-align:top}
tr:nth-child(even) td{background:#fff9f3}
.plan h3{font-size:12pt;color:var(--paprika);margin:2mm 0 1.5mm}
.plan .tage div{display:flex;gap:2mm;font-size:8.2pt;margin-bottom:.8mm}
.plan .tage b{width:17mm;flex:none}
.plan .eink{columns:2;column-gap:4mm;font-size:7.3pt;margin-top:2mm}
.plan .eink div{break-inside:avoid;margin-bottom:1.6mm}
.fehler div{margin-bottom:2.2mm;break-inside:avoid}
.fehler b{color:var(--paprika)}
"""


def e(s):
    return html.escape(str(s if s is not None else ""))


def leer(of):
    base = os.path.join(RAIZ, "ofertas", of, "producto", "contenido")
    j = lambda n: json.load(open(os.path.join(base, n), encoding="utf-8"))
    return j("rezepte.json"), j("advent.json"), j("bonus.json"), j("einleitung.json")


def doc(titel, cuerpo, fonts, img):
    return ("<!doctype html><html lang='de'><head><meta charset='utf-8'><title>%s</title><style>%s</style></head><body>%s"
            "</body></html>") % (e(titel), CSS.replace("FONTS", fonts), cuerpo.replace("IMG/", img + "/"))


def fuss(links, rechts):
    return "<div class='fuss'><span>%s</span><span>%s</span></div>" % (e(links), e(rechts))


def drei(r):
    return ("<div class='drei'><div><small>Temperatur</small><b>%s °C</b></div><div><small>Zeit</small><b>%s Min.</b></div>"
            "<div class='w'><small>Wenden</small><b>%s</b></div></div>") % (e(r["grad"]), e(r["minuten"]), e(r["wenden"]))


def seite_rezept(r, nr_txt, marke):
    foto = FOTOS_RECETA.get(r["id"])
    f = "<div class='foto' style=\"background-image:url('IMG/%s')\"></div>" % foto if foto else ""
    meta = "%s · Vorbereitung %s Min.%s" % (
        ("%s Portionen" % r["portionen"]) if (r.get("portionen") or 0) <= 12 else ("%s Stück" % r["portionen"]),
        e(r.get("vorbereitung_min")), " · Airfryer 3 Min. vorheizen" if r.get("vorheizen") else "")
    zut = "".join("<li>%s</li>" % e(z) for z in r["zutaten"])
    sch = "".join("<li>%s</li>" % e(s) for s in r["schritte"])
    kern = "<div class='kern'>Kerntemperatur: %s</div>" % e(r["kerntemperatur"]) if r.get("kerntemperatur") else ""
    tipp = "<div class='tipp'><b>Tipp:</b> %s</div>" % e(r["tipp"]) if r.get("tipp") else ""
    veg = " · vegetarisch" if r.get("vegetarisch") else ""
    return ("<section class='seite rezept'><div class='nr'>%s · %s%s</div><h3>%s</h3><div class='ut'>%s</div>%s%s"
            "<div class='meta'>%s</div><div class='spalten'><div><h4>Zutaten</h4><ul>%s</ul></div><div><h4>So geht's</h4>"
            "<ol>%s</ol>%s%s</div></div>%s</section>") % (
        e(nr_txt), e(r["kapitel"]), veg, e(r["titel"]), e(r.get("untertitel")), drei(r), f, meta, zut, sch, tipp, kern,
        fuss(marke, "Richtwerte – je nach Gerät anpassen"))


def libro_principal(rez, ein, marke="Korbklassiker"):
    p = []
    p.append("<section class='seite tapa'><div class='kopf'><h1>Korbklassiker</h1><div class='unter'>100 deutsche Klassiker "
             "aus dem Airfryer</div><div class='linie3'><span>°C</span><span>Minuten</span><span>Wenden</span></div></div>"
             "<div class='bild' style=\"background-image:url('IMG/hero.jpg')\"></div><div class='marke'>MIT DER 3-ZAHLEN-METHODE</div></section>")
    so = "".join("<p>%s</p>" % e(x) for x in ein["so_benutzt_du"])
    hin = "".join("<p>• %s</p>" % e(x) for x in ein["hinweise"])
    p.append("<section class='seite text'><h2>So benutzt du dieses Buch</h2>%s%s</section>" % (so, fuss(marke, "Einleitung")))
    p.append("<section class='seite text'><h2>Wichtige Hinweise</h2><div class='box'>%s</div>%s</section>" % (hin, fuss(marke, "Hinweise")))
    # Inhalt
    kaps = []
    for r in rez:
        if r["kapitel"] not in kaps:
            kaps.append(r["kapitel"])
    for parte, grupo in enumerate((kaps[:4], kaps[4:])):
        lst = ""
        for k in grupo:
            items = "".join("<div><span class='nr'>%d</span>%s</div>" % (int(r["id"][1:]), e(r["titel"])) for r in rez if r["kapitel"] == k)
            lst += "<div class='kap'>%s</div><div class='liste'>%s</div>" % (e(k), items)
        p.append("<section class='seite inhalt'><h2>Inhalt%s</h2>%s%s</section>" % ("" if parte == 0 else " (Fortsetzung)", lst, fuss(marke, "Rezeptnummern")))
    for k in kaps:
        n = sum(1 for r in rez if r["kapitel"] == k)
        p.append("<section class='seite kapitel'><div class='bild' style=\"background-image:url('IMG/%s')\"></div><div class='schild'>"
                 "<h2>%s</h2><p>%d Rezepte mit Temperatur, Zeit und Wende-Hinweis.</p></div></section>" % (FOTOS_KAPITEL.get(k, "tapa_fondo.jpg"), e(k), n))
        for r in rez:
            if r["kapitel"] == k:
                p.append(seite_rezept(r, "Nr. %d" % int(r["id"][1:]), marke))
    p.append("<section class='seite text'><h2>Guten Appetit!</h2><p>Du hast jetzt 100 Klassiker mit der 3-Zahlen-Methode. "
             "Fang mit einem Gericht an, das du gut kennst – so merkst du am schnellsten, wie dein Gerät heizt, und kannst "
             "die Richtwerte für alle anderen Rezepte anpassen.</p><div class='box'>Dieses E-Book ist ausschließlich für den "
             "privaten Gebrauch bestimmt. Weitergabe und Vervielfältigung sind nicht gestattet. © 2026 Korbklassiker.</div>%s</section>"
             % fuss(marke, "Ende"))
    return "".join(p)


def libro_advent(adv, marke="Korbklassiker"):
    p = ["<section class='seite tapa'><div class='kopf'><h1 style='font-size:30pt'>Advents- &amp; Weihnachtsklassiker</h1>"
         "<div class='unter'>24 Rezepte aus dem Airfryer</div><div class='linie3'><span>°C</span><span>Minuten</span><span>Wenden</span>"
         "</div></div><div class='bild' style=\"background-image:url('IMG/bump_advent.jpg')\"></div><div class='marke'>KORBKLASSIKER · EXTRA</div></section>"]
    for r in adv:
        p.append(seite_rezept(r, "Nr. %s" % r["id"], marke + " · Advent"))
    return "".join(p)


def bonus_umrechnung(b, marke):
    u = b["umrechnung"]
    reg = "".join("<p>• %s</p>" % e(x) for x in u["regel"])
    rows = "".join("<tr><td>%s</td><td>%s</td><td><b>%s</b></td><td>%s</td></tr>" % (e(t["lebensmittel"]), e(t["backofen"]), e(t["airfryer"]), e(t.get("hinweis"))) for t in u["tabelle"])
    filas = ["<tr><td>%s</td><td>%s</td><td><b>%s</b></td><td>%s</td></tr>" % (e(t["lebensmittel"]), e(t["backofen"]), e(t["airfryer"]), e(t.get("hinweis"))) for t in u["tabelle"]]
    cab = "<table><tr><th>Lebensmittel</th><th>Backofen</th><th>Airfryer</th><th>Hinweis</th></tr>%s</table>"
    return ("<section class='seite text'><div class='nr' style='color:#B4432F;font-family:Oswald'>BONUS 1</div><h2>%s</h2><div class='box'>%s</div>%s</section>"
            % (e(u["titel"]), reg, fuss(marke, "Bonus 1"))
            + "".join("<section class='seite text'><h2>%s</h2>%s%s</section>" % (e(u["titel"]), cab % "".join(filas[i:i + 10]), fuss(marke, "Bonus 1")) for i in range(0, len(filas), 10)))


def bonus_tiefkuehl(b, marke):
    t = b["tiefkuehl"]
    rows = "".join("<tr><td>%s</td><td><b>%s °C</b></td><td><b>%s Min.</b></td><td>%s</td><td>%s</td></tr>" % (e(x["produkt"]), e(x["grad"]), e(x["minuten"]), e(x["wenden"]), e(x.get("hinweis"))) for x in t["tabelle"])
    filas = ["<tr><td>%s</td><td><b>%s °C</b></td><td><b>%s Min.</b></td><td>%s</td><td>%s</td></tr>" % (e(x["produkt"]), e(x["grad"]), e(x["minuten"]), e(x["wenden"]), e(x.get("hinweis"))) for x in t["tabelle"]]
    cab = "<table><tr><th>Produkt</th><th>°C</th><th>Zeit</th><th>Wenden</th><th>Hinweis</th></tr>%s</table>"
    paginas = []
    for n, i in enumerate(range(0, len(filas), 9)):
        intro = "<div class='nr' style='color:#B4432F;font-family:Oswald'>BONUS 2</div>" if n == 0 else ""
        box = "<div class='box'>%s</div>" % e(t.get("hinweis")) if n == 0 else ""
        paginas.append("<section class='seite text'>%s<h2>%s</h2>%s%s%s</section>" % (intro, e(t["titel"]), box, cab % "".join(filas[i:i + 9]), fuss(marke, "Bonus 2")))
    return "".join(paginas)


def bonus_plan(b, rez, marke):
    w = b["wochenplan"]
    tit = {r["id"]: r["titel"] for r in rez}
    out = []
    for wo in w["wochen"]:
        tage = "".join("<div><b>%s</b><span>%s%s</span></div>" % (e(t["tag"]), e("Nr. %d %s" % (int(t["rezept_id"][1:]), tit.get(t["rezept_id"], ""))),
                       e(" + Nr. %d %s" % (int(t["beilage_id"][1:]), tit.get(t["beilage_id"], ""))) if t.get("beilage_id") else "") for t in wo["tage"])
        ek = "".join("<div><b>%s</b><br>%s</div>" % (e(x["bereich"]), e(", ".join(x["artikel"]))) for x in wo["einkaufsliste"])
        out.append("<section class='seite plan'><div class='nr' style='color:#B4432F;font-family:Oswald'>BONUS 3 · WOCHE %s</div><h3>%s</h3>"
                   "<div class='tage'>%s</div><h3>Einkaufsliste</h3><div class='eink'>%s</div>%s</section>" % (e(wo["woche"]), e(w["titel"]), tage, ek, fuss(marke, "Bonus 3")))
    if w.get("hinweis"):
        out.insert(0, "<section class='seite text'><div class='nr' style='color:#B4432F;font-family:Oswald'>BONUS 3</div><h2>%s</h2><p>%s</p>%s</section>" % (e(w["titel"]), e(w["hinweis"]), fuss(marke, "Bonus 3")))
    return "".join(out)


def bonus_fehler(b, marke):
    f = b["fehler"]
    items = "".join("<div><b>%d. %s</b><br>Warum: %s<br>Lösung: %s</div>" % (i + 1, e(x["fehler"]), e(x["warum"]), e(x["loesung"])) for i, x in enumerate(f["punkte"]))
    mitte = len(f["punkte"]) // 2
    return ("<section class='seite text fehler'><div class='nr' style='color:#B4432F;font-family:Oswald'>BONUS 4</div><h2>%s</h2>%s%s</section>" % (e(f["titel"]), items.split("<div><b>%d." % (mitte + 1))[0], fuss(marke, "Bonus 4"))
            + "<section class='seite text fehler'><h2>%s</h2>%s%s</section>" % (e(f["titel"]) + " (Fortsetzung)", "<div><b>%d." % (mitte + 1) + items.split("<div><b>%d." % (mitte + 1))[1], fuss(marke, "Bonus 4")))


def bonus_reinigung(b, marke):
    r = b["reinigung"]
    s = "".join("<li>%s</li>" % e(x) for x in r["schritte"])
    n = "".join("<li>%s</li>" % e(x) for x in r["nie"])
    p = "".join("<li>%s</li>" % e(x) for x in r["pflege"])
    return ("<section class='seite text'><div class='nr' style='color:#B4432F;font-family:Oswald'>BONUS 5</div><h2>%s</h2><ol>%s</ol>%s</section>"
            "<section class='seite text'><h2>%s</h2><h3 style='font-size:11pt;margin:3mm 0 1mm'>Bitte nie</h3><ul>%s</ul><h3 style='font-size:11pt;margin:3mm 0 1mm'>Pflege</h3><ul>%s</ul>%s</section>") % (
        e(r["titel"]), s, fuss(marke, "Bonus 5"), e(r["titel"]), n, p, fuss(marke, "Bonus 5"))


def construir(of):
    rez, adv, bon, ein = leer(of)
    salida = os.path.join(RAIZ, "ofertas", of, "producto", "html")
    os.makedirs(salida, exist_ok=True)
    fonts = "../../landing/fonts"
    img = "../../medios/web"
    m = "Korbklassiker"
    piezas = {
        "korbklassiker": ("Korbklassiker – 100 deutsche Klassiker aus dem Airfryer", libro_principal(rez, ein, m)),
        "bonus_1_umrechnung": ("Bonus 1 – Umrechnungs-Tabelle", bonus_umrechnung(bon, m)),
        "bonus_2_tiefkuehl": ("Bonus 2 – Tiefkühl-Spickzettel", bonus_tiefkuehl(bon, m)),
        "bonus_3_wochenplan": ("Bonus 3 – 4-Wochen-Plan", bonus_plan(bon, rez, m)),
        "bonus_4_fehler": ("Bonus 4 – Die 12 häufigsten Airfryer-Fehler", bonus_fehler(bon, m)),
        "bonus_5_reinigung": ("Bonus 5 – Reinigung in 5 Minuten", bonus_reinigung(bon, m)),
        "advent": ("Advents- & Weihnachtsklassiker aus dem Airfryer", libro_advent(adv, m)),
    }
    trenner = ("<section class='seite text'><h2>Deine 5 Bonus</h2><p>Auf den nächsten Seiten findest du die fünf Bonus: "
               "Umrechnungs-Tabelle, Tiefkühl-Spickzettel, 4-Wochen-Plan mit Einkaufslisten, die 12 häufigsten Fehler und "
               "Reinigung in 5 Minuten.</p>%s</section>" % fuss(m, "Bonus"))
    piezas["korbklassiker_komplett"] = ("Korbklassiker – komplett mit 5 Bonus", piezas["korbklassiker"][1] + trenner + "".join(
        piezas[k][1] for k in ("bonus_1_umrechnung", "bonus_2_tiefkuehl", "bonus_3_wochenplan", "bonus_4_fehler", "bonus_5_reinigung")))
    for nombre, (titulo, cuerpo) in piezas.items():
        with open(os.path.join(salida, nombre + ".html"), "w", encoding="utf-8") as f:
            f.write(doc(titulo, cuerpo, fonts, img))
    val = {"recetas_principal": len(rez), "capitulos": len({r["kapitel"] for r in rez}), "recetas_advent": len(adv),
           "bonus": 5, "recetas_con_foto": len(FOTOS_RECETA), "vegetarisch": sum(1 for r in rez if r.get("vegetarisch")), "recetas_max20min": sum(1 for r in rez if r["minuten"] <= 20),
           "piezas": sorted(piezas)}
    json.dump(val, open(os.path.join(RAIZ, "ofertas", of, "producto", "validacion_producto.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return val


if __name__ == "__main__":
    print(json.dumps(construir(sys.argv[1] if len(sys.argv) > 1 else "OF-007"), ensure_ascii=False))
