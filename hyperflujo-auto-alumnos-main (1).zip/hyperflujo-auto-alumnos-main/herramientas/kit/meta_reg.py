"""meta_reg.py — registro de escrituras del conector de Meta para OF-007 (regla 5/6) en modo borrador.

  python -m herramientas.kit.meta_reg antes <registro.json> <clave> [<clave> ...]   → imprime {clave: SOL}
  python -m herramientas.kit.meta_reg despues <registro.json> <SOL> <id_externo>
El conector crea en BORRADOR del Administrador (no publica ni gasta): cada escritura va como solicitud gratuita.
"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import registro  # noqa: E402

MOTIVO = "conector meta-ads en modo borrador: la escritura queda en el borrador del Administrador, no publica ni gasta"


def antes(ruta, claves):
    out = {}
    for c in claves:
        s = registro.agregar_solicitud(ruta, "api", "meta", clave=c, estimado=0, gratuita=True, motivo_gratuita=MOTIVO)
        registro.marcar_enviando(ruta, s)
        out[c] = s
    return out


def despues(ruta, sid, id_externo):
    registro.guardar_id_externo(ruta, sid, id_externo)
    registro.cambiar_estado(ruta, "completada", solicitud_id=sid)


if __name__ == "__main__":
    if sys.argv[1] == "antes":
        print(json.dumps(antes(sys.argv[2], sys.argv[3:])))
    else:
        despues(sys.argv[2], sys.argv[3], sys.argv[4])
        print("ok")
