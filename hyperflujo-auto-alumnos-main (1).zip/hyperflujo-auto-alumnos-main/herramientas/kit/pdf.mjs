#!/usr/bin/env node
/**
 * pdf.mjs — HTML local → PDF A5 con Playwright (Chrome local). Sin red: solo file://.
 *   node herramientas/kit/pdf.mjs <entrada.html> <salida.pdf> [--png salida.png --ancho 1080 --alto 1350]
 * Con --png renderiza la página como imagen (creativos de anuncio con texto exacto) en vez de PDF.
 */
import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { existsSync } from 'node:fs';

const args = process.argv.slice(2);
const [entrada, salida] = args;
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const cands = [process.env.CHROME_PATH, 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe'].filter(Boolean);
const exe = cands.find(p => existsSync(p));
const navegador = await chromium.launch(exe ? { executablePath: exe } : {});
const ctx = await navegador.newContext({ viewport: { width: Number(opt('--ancho', 1080)), height: Number(opt('--alto', 1350)) } });
const pag = await ctx.newPage();
await pag.route('**/*', r => r.request().url().startsWith('file:') || r.request().url().startsWith('data:') ? r.continue() : r.abort());
await pag.goto(pathToFileURL(resolve(entrada)).href, { waitUntil: 'load' });
await pag.evaluate(() => document.fonts.ready);
if (args.includes('--png')) {
  await pag.screenshot({ path: resolve(opt('--png')), fullPage: false });
  console.log(JSON.stringify({ ok: true, png: opt('--png') }));
} else {
  await pag.pdf({ path: resolve(salida), preferCSSPageSize: true, printBackground: true });
  console.log(JSON.stringify({ ok: true, pdf: salida }));
}
await navegador.close();
