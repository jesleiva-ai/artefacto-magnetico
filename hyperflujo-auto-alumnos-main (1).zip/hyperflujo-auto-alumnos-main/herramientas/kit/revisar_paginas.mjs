#!/usr/bin/env node
/** revisar_paginas.mjs — detecta páginas A5 cuyo contenido no entra (scrollHeight > alto) en un HTML del libro.
 *  node herramientas/kit/revisar_paginas.mjs <html> [--foto n salida.png]  */
import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { existsSync } from 'node:fs';
const a = process.argv.slice(2);
const exe = ['C:/Program Files/Google/Chrome/Application/chrome.exe'].find(p => existsSync(p));
const b = await chromium.launch(exe ? { executablePath: exe } : {});
const p = await (await b.newContext({ viewport: { width: 560, height: 800 } })).newPage();
await p.goto(pathToFileURL(resolve(a[0])).href);
await p.evaluate(() => document.fonts.ready);
const r = await p.evaluate(() => [...document.querySelectorAll('.seite')].map((s, i) => {
  const fuss = s.querySelector('.fuss'); const kids = [...s.children].filter(c => c !== fuss);
  const bottom = Math.max(...kids.map(c => c.getBoundingClientRect().bottom), 0) - s.getBoundingClientRect().top;
  const limite = (fuss ? fuss.getBoundingClientRect().top - s.getBoundingClientRect().top : s.clientHeight);
  return { i, titulo: (s.querySelector('h1,h2,h3')||{}).textContent || '', exceso: Math.round(bottom - limite) };
}).filter(x => x.exceso > 0));
console.log(JSON.stringify(r));
const fi = a.indexOf('--foto');
if (fi >= 0) { const n = Number(a[fi + 1]); const el = (await p.$$('.seite'))[n]; await el.screenshot({ path: resolve(a[fi + 2]) }); }
await b.close();
