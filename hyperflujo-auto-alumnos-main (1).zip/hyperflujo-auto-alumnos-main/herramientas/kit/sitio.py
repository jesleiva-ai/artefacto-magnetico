"""sitio.py — arma canales/hotmart/sitio/ de OF-007 desde landing/*.plantilla.html (el kit maqueta-landing, piel propia D104).

  python -m herramientas.kit.sitio OF-007

Datos: precio de la ficha (oferta.json → precio.lanzamiento); checkout y píxel de ofertas/OF-007/externo.local.json
(fuera de git; regla 8); datos del Impressum de externo.local.json → impressum {name, adresse, email}.
Lo que falte queda como hueco visible y sitio/estado.json dice publicable=false con la lista `faltan` (netlify_deploy.py
no publica así). Sin red.
"""
import json
import os
import re
import shutil
import sys

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(RAIZ, "herramientas"))
import guardia_landing  # noqa: E402  (D119: guardia de bloques de testimonios)
CHECKOUT_OK = re.compile(r"^https://pay\.hotmart\.com/[A-Za-z0-9]+(\?[^\s\"'<>]*)?$")


def precio_txt(v):
    return ("%.2f" % v).replace(".", ",") + " €"


def armar(of, externo=None):
    base = os.path.join(RAIZ, "ofertas", of)
    ficha = json.load(open(os.path.join(base, "oferta.json"), encoding="utf-8"))
    if externo is None:
        p = os.path.join(base, "externo.local.json")
        externo = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    faltan = []
    precio = ficha["precio"]["lanzamiento"]
    checkout = externo.get("checkout_url") or ""
    if not CHECKOUT_OK.match(checkout):
        faltan.append("checkout de Hotmart (externo.local.json → checkout_url)")
        checkout = "#angebot"
    import pixel as PX   # F63: el píxel sale de la cuenta (datos/cuentas.local.json), nunca de un marcador
    import pixel_nuevo   # Matías 2026-10-27: si falta el píxel de este producto y mercado, el agente lo crea solo
    pixel_nuevo.antes_de_armar(ficha.get("id"), (ficha.get("mercado") or {}).get("id"), (ficha.get("campana") or {}).get("cuenta_ref"))
    try:
        pixel = PX.del_producto(ficha.get("id"), (ficha.get("mercado") or {}).get("id"), (ficha.get("campana") or {}).get("cuenta_ref"))   # Matías 2026-10-25: píxel por producto y mercado
    except PX.SinPixel as e:
        faltan.append("píxel de Meta: %s" % e)
        pixel = ""
    previo = str(externo.get("pixel_id") or "")
    if pixel and previo and previo != pixel:
        faltan.append("externo.local.json → pixel_id (%s) no es el píxel de la cuenta: se usa el de la cuenta" % previo)
    import legales   # F65: los legales salen de datos/dueno.local.json → legal_de, nunca de externo ni de la plantilla
    try:
        imp = legales.impressum_de()
    except legales.FaltaLegal as e:
        faltan.append("Impressum: %s" % e)
        imp = {}
    vals = {}
    for k in ("name", "adresse", "email", "steuer"):
        v = (imp.get(k) or "").strip()
        if not v and k == "steuer":
            vals[k] = "—"
            continue
        if not v:
            faltan.append("Impressum: %s del responsable (§5 DDG)" % k)
            v = "[PENDIENTE: %s]" % k
        elif "[PENDIENTE" in v:
            faltan.append("Impressum: %s con marcador visible (no se publica así)" % k)
        vals[k] = v
    sitio = os.path.join(base, "canales", "hotmart", "sitio")
    os.makedirs(sitio, exist_ok=True)
    reemplazos = {"{{PREIS}}": precio_txt(precio), "{{PREIS_NUM}}": "%.2f" % precio, "{{CHECKOUT}}": checkout,
                  "{{PIXEL}}": pixel, "{{IMPRESSUM_NAME}}": vals["name"], "{{IMPRESSUM_ADRESSE}}": vals["adresse"],
                  "{{IMPRESSUM_EMAIL}}": vals["email"], "{{IMPRESSUM_STEUER}}": vals["steuer"]}
    for plantilla, salida in (("index", "index.html"), ("impressum", "impressum.html"), ("datenschutz", "datenschutz.html")):
        t = open(os.path.join(base, "landing", plantilla + ".plantilla.html"), encoding="utf-8").read()
        for k, v in reemplazos.items():
            t = t.replace(k, v)
        if "{{" in t:
            raise ValueError("marcador sin reemplazar en %s" % plantilla)
        t, _ = guardia_landing.quitar_bloque(t)   # D119: ninguna landing lleva bloque de testimonios
        open(os.path.join(sitio, salida), "w", encoding="utf-8", newline="\n").write(t)
    for carpeta in ("fonts",):
        origen = os.path.join(base, "landing", carpeta)
        if os.path.isdir(origen):
            shutil.copytree(origen, os.path.join(sitio, carpeta), dirs_exist_ok=True, ignore=shutil.ignore_patterns("*.css"))
    estado = {"publicable": not faltan, "faltan": faltan, "precio": precio_txt(precio)}
    json.dump(estado, open(os.path.join(sitio, "estado.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return estado


if __name__ == "__main__":
    print(json.dumps(armar(sys.argv[1] if len(sys.argv) > 1 else "OF-007"), ensure_ascii=False))
