"""transcribir.py — verificación literal del habla de un video (paso 7 de metodo-6c) con Speech-to-Text de ElevenLabs.

  python -m herramientas.kit.transcribir <audio.wav> --ej <registro.json> --clave <clave> --idioma deu --esperado "<texto>"

Regla 5/6: agregar_solicitud(estimado > 0) → marcar_enviando → UNA llamada → guardar_id_externo. La clave sale de .env
por claves.py y nunca se imprime. Devuelve la transcripción y la comparación palabra por palabra con el guion.
"""
import argparse
import json
import os
import re
import sys
import urllib.request
import uuid

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import claves  # noqa: E402
import registro  # noqa: E402

URL = "https://api.elevenlabs.io/v1/speech-to-text"


def normalizar(t):
    t = t.lower().replace("ß", "ss")
    return [w for w in re.split(r"[^\wäöü]+", t) if w]


def comparar(esperado, obtenido):
    a, b = normalizar(esperado), normalizar(obtenido)
    faltan = [w for w in a if w not in b]
    sobran = [w for w in b if w not in a]
    return {"coincide": a == b, "palabras_guion": len(a), "palabras_dichas": len(b), "faltan": faltan, "sobran": sobran}


def multipart(campos, archivo):
    lim = uuid.uuid4().hex
    partes = []
    for k, v in campos.items():
        partes.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (lim, k, v)).encode())
    partes.append(("--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\nContent-Type: audio/wav\r\n\r\n"
                   % (lim, os.path.basename(archivo))).encode() + open(archivo, "rb").read() + b"\r\n")
    partes.append(("--%s--\r\n" % lim).encode())
    return b"".join(partes), "multipart/form-data; boundary=%s" % lim


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("audio")
    p.add_argument("--ej", required=True)
    p.add_argument("--clave", required=True)
    p.add_argument("--idioma", default="deu")
    p.add_argument("--esperado", required=True)
    p.add_argument("--estimado", type=float, default=0.01)
    a = p.parse_args(argv)
    sid = registro.agregar_solicitud(a.ej, "api", "elevenlabs", clave=a.clave, estimado=a.estimado, modelo="scribe_v1",
                                     parametros={"uso": "verificación literal metodo-6c", "idioma": a.idioma})
    registro.marcar_enviando(a.ej, sid)
    cuerpo, tipo = multipart({"model_id": "scribe_v1", "language_code": a.idioma}, a.audio)
    req = urllib.request.Request(URL, data=cuerpo, method="POST",
                                 headers={"xi-api-key": claves.clave("ELEVENLABS_API_KEY"), "Content-Type": tipo})
    try:
        r = json.loads(urllib.request.urlopen(req, timeout=120).read().decode("utf-8"))
    except Exception as e:  # noqa: BLE001
        registro.marcar_rechazada(a.ej, sid, str(e)[:300])
        raise
    registro.guardar_id_externo(a.ej, sid, r.get("transcription_id") or ("stt:%s" % sid))
    registro.cambiar_estado(a.ej, "completada", solicitud_id=sid)
    texto = r.get("text", "")
    print(json.dumps({"solicitud": sid, "texto": texto, "comparacion": comparar(a.esperado, texto)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
