#!/usr/bin/env node
/** verificar_pixel.mjs — prueba del píxel con consentimiento (DSGVO) en navegador alemán, solo lectura.
 *  node herramientas/kit/verificar_pixel.mjs <url> <salida.json>
 *  (c) sin aceptar: cero pedidos a Facebook y fbq inexistente · (a) tras «Akzeptieren»: fbevents.js + config del
 *  píxel + PageView procesado por fbq (getState().pixels[0].eventCount) · (b) clic en el CTA: llamada
 *  fbq('track','InitiateCheckout',{value,currency}) registrada con un envoltorio. La navegación al checkout se corta.
 *  Nota: desde un Chrome automatizado el envío /tr no aparece en la red (igual en la landing de OF-001 con el mismo
 *  píxel); la prueba verifica las llamadas al píxel, y la recepción se confirma en el Administrador de eventos. */
import { chromium } from 'playwright';
import { existsSync, writeFileSync } from 'node:fs';
const [url, sal] = process.argv.slice(2);
const exe = ['C:/Program Files/Google/Chrome/Application/chrome.exe'].find(p => existsSync(p));
const b = await chromium.launch(exe ? { executablePath: exe } : {});
const ctx = await b.newContext({ locale: 'de-DE', timezoneId: 'Europe/Berlin', viewport: { width: 390, height: 800 } });
const p = await ctx.newPage();
const red = []; let fase = 'sin_aceptar';
p.on('request', r => { if (/facebook\.(net|com)/.test(r.url())) red.push({ fase, url: r.url().replace(/\d{12,}/g, '<pixel>').slice(0, 120) }); });
await p.route('https://pay.hotmart.com/**', r => r.abort());
await p.goto(url, { waitUntil: 'networkidle' }); await p.waitForTimeout(3000);
const c = { pedidos_facebook: red.length, fbq: await p.evaluate(() => typeof window.fbq) };
fase = 'tras_aceptar';
await p.evaluate(() => document.getElementById('c-ja').click());
await p.waitForFunction(() => window.fbq && window.fbq.getState && window.fbq.getState().pixels.length, null, { timeout: 20000 }).catch(() => {});
await p.waitForTimeout(3000);
const a = await p.evaluate(() => { const s = window.fbq && window.fbq.getState ? window.fbq.getState() : null; return { fbq: typeof window.fbq, pixeles: s ? s.pixels.length : 0, eventos_procesados: s && s.pixels[0] ? s.pixels[0].eventCount : null, consentimiento: localStorage.getItem('kk_consent') }; });
a.fbevents = red.some(x => /fbevents\.js/.test(x.url)); a.config = red.some(x => /signals\/config/.test(x.url));
await p.evaluate(() => { const o = window.fbq; window.__llamadas = []; window.fbq = function () { window.__llamadas.push([...arguments]); return o.apply(this, arguments); }; Object.assign(window.fbq, o); });
fase = 'clic_cta';
await p.evaluate(() => { document.addEventListener('click', e => e.preventDefault(), true); const x = document.querySelector('a.cta'); x.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); });
await p.waitForTimeout(3000);
const bb = await p.evaluate(() => ({ llamadas: window.__llamadas, eventos_procesados: window.fbq.getState ? window.fbq.getState().pixels[0].eventCount : null }));
const r = { url, fecha: new Date().toISOString(), navegador: 'Chrome de-DE, Europe/Berlin', c_sin_aceptar: c, a_tras_aceptar: a, b_clic_cta: bb, red };
writeFileSync(sal, JSON.stringify(r, null, 1));
console.log(JSON.stringify({ c, a, b: bb }));
await b.close();
