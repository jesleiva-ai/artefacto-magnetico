#!/usr/bin/env node
/** verificar_publicacion.mjs — lectura de la landing publicada (regla 7: verificar por artefacto).
 *  node herramientas/kit/verificar_publicacion.mjs <url> <off_esperado>
 *  Comprueba: HTTP 200, CTAs → pay.hotmart.com con ?off=<off_esperado>, cero pedidos a connect.facebook.net antes del
 *  consentimiento y al menos uno después de «Akzeptieren». Imprime JSON (sin el código del producto). */
import { chromium } from 'playwright';
import { existsSync } from 'node:fs';
const [url, off] = process.argv.slice(2);
const exe = ['C:/Program Files/Google/Chrome/Application/chrome.exe'].find(p => existsSync(p));
const b = await chromium.launch(exe ? { executablePath: exe } : {});
const ctx = await b.newContext({ viewport: { width: 390, height: 800 }, locale: 'de-DE', timezoneId: 'Europe/Berlin' });
const p = await ctx.newPage();
const fb = []; p.on('request', r => { if (/facebook\.(net|com)/.test(r.url())) fb.push(r.url()); });
const resp = await p.goto(url, { waitUntil: 'networkidle' });
await p.waitForTimeout(2500);
const antes = fb.length;
const ctas = await p.evaluate(() => [...document.querySelectorAll('a.cta')].map(a => a.href));
const banner = await p.evaluate(() => !document.getElementById('cookie').hidden);
await p.click('#c-ja'); await p.waitForTimeout(4000);
const despues = fb.length;
const r = { http: resp.status(), ctas: ctas.length, ctas_a_hotmart: ctas.every(h => /^https:\/\/pay\.hotmart\.com\/[A-Z0-9]+\?off=/.test(h)),
  ctas_con_oferta_lanzamiento: ctas.every(h => h.includes('off=' + off)), banner_visible_al_entrar: banner,
  pedidos_facebook_antes_del_consentimiento: antes, pedidos_facebook_despues_de_aceptar: despues };
for (const pth of ['impressum.html', 'datenschutz.html']) { const x = await p.goto(new URL(pth, url).href); r[pth] = x.status(); }
console.log(JSON.stringify(r)); await b.close();
