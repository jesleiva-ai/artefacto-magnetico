#!/usr/bin/env python3
"""lanzar_worker.py — corre un worker `claude -p` de verdad, en la carpeta del repo y con entorno acotado (TAREA 036 A).

    python herramientas/lanzar_worker.py --of OF-001 --accion revisar --mostrar     # imprime el comando, no ejecuta

Comando (flags verificados con `claude --help` 2.1.304; no existe --max-turns: el corte duro es el timeout):
    <claude> -p "<prompt>" --permission-mode <modo> --max-budget-usd <tope> --output-format json
             --json-schema "<worker_salida.json>" --allowedTools ... --disallowedTools ... [--model ...] [--advisor ...]
             [--mcp-config .mcp.json --strict-mcp-config] [--append-system-prompt "<skill>"]
Reglas:
  * Modo de permisos configurable (datos/config.local.json -> workers.permission_mode, por defecto dontAsk). Nunca
    bypassPermissions ni --dangerously-skip-permissions ni --bare (saltea los hooks guardianes): se rechazan.
  * --max-budget-usd obligatorio, > 0 y finito. Con facturación «api» sale de los topes de anthropic (lo que queda del
    día); con «suscripcion», de workers.max_budget_usd_por_worker. Sin tope: no se lanza (falla cerrado).
  * Entorno acotado: solo variables del sistema necesarias + HYPERFLUJO_* (sin secretos) + las que pida la etapa.
    ANTHROPIC_API_KEY solo pasa si la facturación es «api»; si no, se quita aunque esté en el entorno del programador.
  * Captura stdout, stderr y código; log en operacion/logs/ (fuera de git); trabajo en estado/trabajos.jsonl.
  * No cree en el texto: devuelve la salida estructurada y verifica los artefactos (ruta + sha256).
Solo biblioteca estándar.
"""
import hashlib
import json
import math
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

MODOS_PERMITIDOS = ("dontAsk", "acceptEdits", "auto", "plan", "manual")
PROHIBIDOS = ("bypassPermissions", "--dangerously-skip-permissions", "--bare", "--allow-dangerously-skip-permissions")
# Asesor (/advisor de Claude Code 2.1.260+): el worker consulta a un modelo más fuerte en los puntos de decisión.
# datos/config.local.json → advisor.<rol> manda; "advisor": false lo apaga del todo.
ADVISOR_DEFECTO = {"produce": "opus", "revisa": "opus"}
RANGO = {"haiku": 0, "sonnet": 1, "opus": 2, "fable": 3}
VARIABLES_SISTEMA = ("PATH", "PATHEXT", "SYSTEMROOT", "SystemRoot", "WINDIR", "COMSPEC", "TEMP", "TMP", "TMPDIR",
                     "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "HOME", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA",
                     "ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "CommonProgramFiles", "NUMBER_OF_PROCESSORS",
                     "PROCESSOR_ARCHITECTURE", "OS", "USERNAME", "USER", "LOGNAME", "SHELL", "LANG", "LC_ALL", "TERM",
                     "TZ", "XDG_CONFIG_HOME", "XDG_RUNTIME_DIR", "CLAUDE_CODE_GIT_BASH_PATH", "PYTHONIOENCODING")
SECRETOS = ("ANTHROPIC_API_KEY", "HYPERFLUJO_TOKEN", "META_ACCESS_TOKEN", "META_SYSTEM_USER_TOKEN", "HOTMART_BASIC",
            "HOTMART_CLIENT_SECRET", "NETLIFY_AUTH_TOKEN", "GITHUB_TOKEN", "REPO_PRODUCTOS_TOKEN", "ELEVENLABS_API_KEY",
            "HF_API_KEY_SECRET", "KIE_API_KEY")


class SinTope(RuntimeError):
    """No hay un tope válido para --max-budget-usd: el worker no se lanza."""


class ComandoProhibido(ValueError):
    pass


def config_workers(config=None):
    if config is None:
        config = rutas.cargar_dato("config", defecto={}) or {}
    w = dict(config.get("workers") or {})
    w.setdefault("permission_mode", "dontAsk")
    w.setdefault("facturacion", "suscripcion")
    w.setdefault("paralelo_max", 1)
    w.setdefault("timeout_min_defecto", 30)
    return w


def _numero_valido(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and x > 0


def tope_worker(workers, topes=None, gastado_hoy_anthropic=None):
    """USD para --max-budget-usd. Falla cerrado (SinTope) si no hay un número > 0 finito."""
    por_worker = workers.get("max_budget_usd_por_worker")
    if workers.get("facturacion") == "api":
        t = (((topes or {}).get("por_proveedor_dia") or {}).get("anthropic") or {}).get("tope")
        if not _numero_valido(t):
            raise SinTope("facturación por API sin tope diario de anthropic en datos/topes.local.json")
        if gastado_hoy_anthropic is None:
            raise SinTope("gasto de hoy en anthropic desconocido (nulo != 0): no se lanza por API")
        restante = t - gastado_hoy_anthropic
        valor = min(restante, por_worker) if _numero_valido(por_worker) else restante
    else:
        valor = por_worker
    if not _numero_valido(valor):
        raise SinTope("sin tope por worker: completar workers.max_budget_usd_por_worker en datos/config.local.json "
                      "(o queda 0 en el tope diario de anthropic)")
    return round(float(valor), 2)


def entorno_acotado(base=None, facturacion="suscripcion", extra=()):
    """Copia solo lo necesario del entorno del proceso. Nunca hereda secretos salvo los que la etapa pida en `extra`."""
    base = os.environ if base is None else base
    env = {k: v for k, v in base.items() if k in VARIABLES_SISTEMA}
    env.update({k: v for k, v in base.items() if k.startswith("HYPERFLUJO_") and k not in SECRETOS})
    for k in extra:
        if k in base and k != "ANTHROPIC_API_KEY":
            env[k] = base[k]
    if facturacion == "api" and "ANTHROPIC_API_KEY" in base:
        env["ANTHROPIC_API_KEY"] = base["ANTHROPIC_API_KEY"]
    else:
        env.pop("ANTHROPIC_API_KEY", None)
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def advisor_de(config, rol, modelo=None):
    """Modelo asesor del rol, o None. Fable no se usa para workers (Ramiro, TAREA 041): pasa a opus. Un asesor por
    debajo del modelo del worker no vale (la CLI lo rechaza): None."""
    conf = (config or {}).get("advisor", ADVISOR_DEFECTO)
    if not isinstance(conf, dict):
        return None
    a = conf.get(rol)
    if not a or a == "off":
        return None
    a = "opus" if a == "fable" else a
    if RANGO.get(a, 0) < RANGO.get(modelo or "", 0):
        return None
    return a


def armar_comando(exe, prompt, *, permission_mode, max_budget_usd, allowed=(), disallowed=(), json_schema=None,
                  model=None, advisor=None, mcp_config=None, strict_mcp=True, append_system_prompt=None):
    """Lista de argumentos (exe puede ser una lista, p. ej. [python, claude_falso.py] en pruebas)."""
    if permission_mode not in MODOS_PERMITIDOS:
        raise ComandoProhibido("modo de permisos no permitido: %r (permitidos: %s)" % (permission_mode, ", ".join(MODOS_PERMITIDOS)))
    if not _numero_valido(max_budget_usd):
        raise SinTope("--max-budget-usd debe ser > 0 y finito")
    base = list(exe) if isinstance(exe, (list, tuple)) else [exe]
    cmd = base + ["-p", prompt, "--permission-mode", permission_mode, "--max-budget-usd", "%.2f" % max_budget_usd,
                  "--output-format", "json"]
    if json_schema is not None:
        cmd += ["--json-schema", json_schema if isinstance(json_schema, str) else json.dumps(json_schema, ensure_ascii=False)]
    if allowed:
        cmd += ["--allowedTools", ",".join(allowed)]
    if disallowed:
        cmd += ["--disallowedTools", ",".join(disallowed)]
    if model:
        cmd += ["--model", model]
    if advisor:
        cmd += ["--advisor", advisor]
    if mcp_config:
        cmd += ["--mcp-config", str(mcp_config)] + (["--strict-mcp-config"] if strict_mcp else [])
    if append_system_prompt:
        cmd += ["--append-system-prompt", append_system_prompt]
    for parte in cmd[len(base):]:
        if parte in PROHIBIDOS:
            raise ComandoProhibido("flag prohibido en un worker: %s" % parte)
    return cmd


def esquema_salida():
    return json.loads(rutas.ruta("plantillas", "esquemas", "worker_salida.json").read_text(encoding="utf-8"))


def armar_prompt(decision, fecha=None):
    """Prompt de la etapa desde plantillas/prompts/<accion>.md (+ plantillas/prompts/_comun.md)."""
    accion = decision["accion"]
    p = rutas.ruta("plantillas", "prompts", "%s.md" % accion)
    plantilla = p.read_text(encoding="utf-8") if p.exists() else "Etapa «{accion}» del producto {of}. [PENDIENTE: prompt de la etapa]"
    comun = rutas.ruta("plantillas", "prompts", "_comun.md")
    texto = plantilla + ("\n\n" + comun.read_text(encoding="utf-8") if comun.exists() else "")
    valores = {"of": decision["of"], "accion": accion, "motivo": decision.get("motivo", ""), "fecha": fecha or rutas.hoy(),
               "parametros": json.dumps(decision.get("parametros") or {}, ensure_ascii=False), "estado": decision.get("estado", "")}
    for k, v in valores.items():
        texto = texto.replace("{%s}" % k, str(v))
    import preferencias   # ~/.hyperflujo/preferencias.md: cómo quiere usar el sistema su dueño
    pref = preferencias.bloque()
    return texto + ("\n\n" + pref if pref else "")


def _matar_arbol(proc):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True, timeout=30)
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        proc.kill()


def ejecutar_proceso(cmd, *, cwd, env, timeout_s):
    """Corre el proceso con corte duro (mata el árbol entero al vencer). Devuelve (código, stdout, stderr, timeout)."""
    extra = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    proc = subprocess.Popen(cmd, cwd=str(cwd), env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", **extra)
    try:
        out, err = proc.communicate(timeout=timeout_s)
        return proc.returncode, out, err, False
    except subprocess.TimeoutExpired:
        _matar_arbol(proc)
        out, err = proc.communicate()
        return None, out, err, True


def interpretar_salida(stdout):
    """JSON de `--output-format json` -> (datos_cli, salida_estructurada|None, motivo)."""
    try:
        cli = json.loads((stdout or "").strip().splitlines()[-1]) if stdout and stdout.strip() else None
    except (ValueError, IndexError):
        cli = None
    if not isinstance(cli, dict):
        return None, None, "la salida del worker no es el JSON de --output-format json"
    estructurada = cli.get("structured_output")
    if estructurada is None and isinstance(cli.get("result"), str):
        try:
            estructurada = json.loads(cli["result"])
        except ValueError:
            estructurada = None
    if cli.get("is_error"):
        return cli, estructurada, "la CLI informó error: %s" % str(cli.get("subtype") or cli.get("result"))[:300]
    if not isinstance(estructurada, dict):
        return cli, None, "sin salida estructurada (worker_salida.json)"
    faltan = [k for k in esquema_salida()["required"] if k not in estructurada]
    if faltan:
        return cli, None, "salida estructurada incompleta: faltan %s" % ", ".join(faltan)
    return cli, estructurada, ""


def verificar_artefactos(salida, raiz=None):
    """Regla 7: vale el artefacto, no el texto. Cada artefacto tiene que existir dentro del repo y coincidir en sha256."""
    raiz = Path(raiz or rutas.RAIZ).resolve()
    problemas = []
    for a in (salida or {}).get("artefactos", []):
        p = (raiz / a.get("ruta", "")).resolve()
        if raiz not in p.parents:
            problemas.append("artefacto fuera del repo: %s" % a.get("ruta"))
            continue
        if not p.is_file():
            problemas.append("artefacto inexistente: %s" % a.get("ruta"))
            continue
        if hashlib.sha256(p.read_bytes()).hexdigest() != a.get("sha256"):
            problemas.append("sha256 distinto: %s" % a.get("ruta"))
    return problemas


def registrar_trabajo(fila):
    p = rutas.ruta("estado", "trabajos.jsonl")
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(fila, ensure_ascii=False) + "\n")


def lanzar(decision, *, exe=None, config=None, topes=None, gastado_hoy_anthropic=None, timeout_s=None, entorno_base=None,
           extra_env=(), ejecutar=ejecutar_proceso, cwd=None, mcp=False):
    """Corre el worker de `decision["accion"]` para `decision["of"]`. Devuelve un dict con ok, codigo, motivo, salida
    (estructurada), consumo, total_cost_usd, num_turns, duration_ms, session_id y log."""
    import etapas
    import ruta_claude
    if config is None:
        config = rutas.cargar_dato("config", defecto={}) or {}
    workers = config_workers(config)
    d = etapas.definicion(decision["accion"])
    inicio = rutas.ahora().isoformat(timespec="seconds")
    base = {"of": decision["of"], "accion": decision["accion"], "inicio": inicio}
    exe = exe or ruta_claude.resolver()
    if not exe:
        return {**base, "ok": False, "codigo": 3, "consumo": 0,
                "motivo": "no se encontró la CLI de Claude Code (ruta_claude.py): instalarla o fijar HYPERFLUJO_CLAUDE_EXE"}
    try:
        tope = tope_worker(workers, topes, gastado_hoy_anthropic)
        allowed, disallowed = etapas.herramientas_worker(decision["accion"])
        skill = rutas.ruta(d["skill"]) if d.get("skill") else None
        modelo = (config.get("modelos") or {}).get(d.get("rol"))
        cmd = armar_comando(exe, armar_prompt(decision), permission_mode=workers["permission_mode"], max_budget_usd=tope,
                            allowed=allowed, disallowed=disallowed, json_schema=esquema_salida(), model=modelo or None,
                            advisor=advisor_de(config, d.get("rol"), modelo), mcp_config=rutas.ruta(".mcp.json") if mcp else None,
                            append_system_prompt=skill.read_text(encoding="utf-8") if skill and skill.exists() else None)
    except (SinTope, ComandoProhibido) as e:
        r = {**base, "ok": False, "codigo": 4, "motivo": str(e), "consumo": 0}
        registrar_trabajo({**r, "fin": rutas.ahora().isoformat(timespec="seconds")})
        return r
    env = entorno_acotado(entorno_base, workers["facturacion"], tuple(extra_env) + tuple(d.get("variables", ())))
    env.update(HYPERFLUJO_OF=decision["of"], HYPERFLUJO_ACCION=decision["accion"])   # los lee el hook guardian_gasto
    timeout_s = timeout_s or 60 * int(d.get("timeout_min") or workers["timeout_min_defecto"])
    t0 = time.monotonic()
    codigo_proc, out, err, vencio = ejecutar(cmd, cwd=cwd or rutas.RAIZ, env=env, timeout_s=timeout_s)
    log = rutas.ruta("operacion", "logs", "worker_%s_%s_%s.log" % (inicio[:10], decision["of"], decision["accion"]))
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "a", encoding="utf-8") as f:
        f.write("=== %s código=%s timeout=%s\n--- stdout\n%s\n--- stderr\n%s\n" % (inicio, codigo_proc, vencio, out, err))
    cli, salida, motivo = interpretar_salida(out)
    costo = (cli or {}).get("total_cost_usd")
    r = {**base, "returncode": codigo_proc, "timeout": vencio, "salida": salida, "total_cost_usd": costo,
         "num_turns": (cli or {}).get("num_turns"),
         "duration_ms": (cli or {}).get("duration_ms") or int((time.monotonic() - t0) * 1000),
         "session_id": (cli or {}).get("session_id"), "max_budget_usd": tope,
         "log": os.path.relpath(log, rutas.RAIZ).replace("\\", "/")}
    # Consumo pago: por API = total_cost_usd; por suscripción el costo marginal es 0 (el nominal queda aparte). Sin dato = nulo.
    if workers["facturacion"] == "api":
        r["consumo"] = costo if isinstance(costo, (int, float)) and not isinstance(costo, bool) else None
    else:
        r["consumo"], r["costo_nominal_usd"] = (0 if cli is not None else None), costo
    if vencio:
        r.update(ok=False, codigo=1, motivo="timeout de %d s: se cortó el árbol de procesos" % timeout_s)
    elif codigo_proc != 0:
        r.update(ok=False, codigo=1, motivo="código de salida %s%s" % (codigo_proc, (": " + motivo) if motivo else ""))
    elif motivo:
        r.update(ok=False, codigo=2, motivo=motivo)
    elif salida.get("of") != decision["of"]:
        r.update(ok=False, codigo=2, motivo="la salida es de otro producto (%s)" % salida.get("of"))
    else:
        problemas = verificar_artefactos(salida)
        if problemas:
            r.update(ok=False, codigo=2, motivo="verificación por artefacto fallida: " + "; ".join(problemas[:5]))
        elif salida.get("resultado") != "ok":
            r.update(ok=False, codigo=2, motivo="el worker devolvió «%s»: %s" % (salida.get("resultado"), "; ".join(salida.get("pendientes", [])[:3])))
        else:
            r.update(ok=True, codigo=0, motivo="worker ok con artefactos verificados")
    registrar_trabajo({k: v for k, v in {**r, "fin": rutas.ahora().isoformat(timespec="seconds")}.items() if k != "salida"})
    return r


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Lanza un worker claude -p para una acción de un producto (o lo muestra).")
    ap.add_argument("--of", required=True)
    ap.add_argument("--accion", required=True)
    ap.add_argument("--mostrar", action="store_true", help="solo imprime el comando (sin ejecutar, sin consumo)")
    a = ap.parse_args()
    dec = {"of": rutas.validar_of(a.of), "accion": a.accion, "motivo": "lanzamiento manual", "estado": "?"}
    if a.mostrar:
        import etapas
        import ruta_claude
        w = config_workers()
        al, dis = etapas.herramientas_worker(a.accion)
        try:
            cmd = armar_comando("claude", "<prompt de %s>" % a.accion, permission_mode=w["permission_mode"],
                                max_budget_usd=tope_worker(w), allowed=al, disallowed=dis, json_schema="<worker_salida.json>")
            print(" ".join(cmd))
            print(json.dumps({"ok": True, "codigo": 0, "motivo": "comando mostrado, no ejecutado", "artefactos": []}))
        except (SinTope, ComandoProhibido) as e:
            print(json.dumps({"ok": False, "codigo": 4, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
            sys.exit(4)
    else:
        r = lanzar(dec)
        print(json.dumps({"ok": r["ok"], "codigo": r["codigo"], "motivo": r["motivo"],
                          "artefactos": [r["log"]] if r.get("log") else []}, ensure_ascii=False))
        sys.exit(r["codigo"])
