#!/usr/bin/env python3
"""latido.py — chequeo independiente de que el vigía corre (F67, Director_H1 2026-10-25).

    python herramientas/latido.py            # lo corre su propia tarea programada (cada hora a los :07)

El 25/10 el vigía llevaba más de un día sin correr (tarea deshabilitada) y nadie se enteró. El latido no depende del
vigía: lee estado/vigia_ultimo.json y, si tiene más de 90 minutos (o no existe), avisa al dueño por el canal de
avisos (avisos.py) y deja estado/ALERTA_VIGIA.json, que leen detectar.py, el informe y la sesión del director. Un
aviso por episodio; si sigue caído, repite cada 6 h. Cuando el vigía vuelve, borra la alerta y lo informa una vez.
No lee ni escribe nada afuera salvo el aviso. Solo biblioteca estándar.
"""
import json
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import avisos  # noqa: E402
import rutas  # noqa: E402

MAX_MIN = 90
REPETIR_H = 6


def tarea_del_vigia():
    """→ None si la tarea está registrada y habilitada para esta carpeta; si no, el motivo (deshabilitada, otra carpeta,
    no registrada). Pedido de Director_H3 (25/10): avisar apenas la tarea figura deshabilitada, sin esperar 90 min."""
    import subprocess
    import detectar
    v = detectar.vigia_item(subprocess.run)
    nota = v.get("nota") or ""
    if v["estado"] == "falta" and "última corrida" not in nota:
        return nota or "la tarea del vigía no está registrada"
    return None


def revisar(ahora=None, enviar=avisos.enviar, tarea=tarea_del_vigia):
    ahora = ahora or rutas.ahora()
    ultimo = rutas.leer_json(rutas.ruta("estado", "vigia_ultimo.json"), defecto=None) or {}
    p_alerta = rutas.ruta("estado", "ALERTA_VIGIA.json")
    alerta = rutas.leer_json(p_alerta, defecto=None)
    try:
        minutos = (ahora - datetime.fromisoformat(ultimo["hora"])).total_seconds() / 60.0
    except (KeyError, ValueError, TypeError):
        minutos = None
    try:
        problema_tarea = tarea() if tarea else None
    except Exception as e:
        problema_tarea = None   # no se pudo consultar el Programador: decide la hora de la última corrida
        _ = e
    caido = minutos is None or minutos > MAX_MIN or bool(problema_tarea)
    if not caido:
        if alerta:
            p_alerta.unlink()
            enviar("vigía otra vez en marcha", "El vigía volvió a correr (última corrida hace %.0f min)." % minutos, nivel="info")
            return {"ok": True, "estado": "recuperado", "minutos": minutos}
        return {"ok": True, "estado": "en_marcha", "minutos": minutos}
    if alerta:
        try:
            if ahora - datetime.fromisoformat(alerta["avisado"]) < timedelta(hours=REPETIR_H):
                return {"ok": False, "estado": "caido_ya_avisado", "minutos": minutos}
        except (KeyError, ValueError, TypeError):
            pass
    if problema_tarea:
        desde = "tiene la tarea en problema (%s)%s" % (problema_tarea, "" if minutos is None else "; última corrida hace %.0f min" % minutos)
    else:
        desde = "nunca corrió" if minutos is None else "no corre hace %.0f min (última: %s)" % (minutos, ultimo.get("hora"))
    texto = ("El vigía de hyperflujo-auto %s. Sin vigía no se pausa por reglas ni se lee el gasto de Meta. Revisar: "
             "Programador de tareas → \\hyperflujo-auto\\vigia (¿deshabilitada?), estado/vigia.lock y el último resultado. "
             "Arreglo: python herramientas/programar.py instalar --confirmar --solo vigia." % desde)
    r = enviar("el vigía no corre", texto, nivel="alerta")
    rutas.escribir_json(p_alerta, {"desde": ultimo.get("hora"), "avisado": ahora.isoformat(timespec="seconds"),
                                   "minutos": minutos, "canal": r.get("canal"), "envio_ok": r.get("ok")})
    return {"ok": False, "estado": "caido_avisado", "minutos": minutos, "aviso": r}


if __name__ == "__main__":
    r = revisar()
    print(json.dumps({"ok": r["ok"], "codigo": 0 if r["ok"] else 3, "motivo": r["estado"],
                      "artefactos": [] if r["ok"] else ["estado/ALERTA_VIGIA.json", "estado/avisos.jsonl"]}, ensure_ascii=False))
    sys.exit(0)
