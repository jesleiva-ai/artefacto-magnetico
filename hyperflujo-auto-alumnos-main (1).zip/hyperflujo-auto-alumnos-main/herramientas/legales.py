#!/usr/bin/env python3
"""legales.py — los datos legales salen del dueño y ningún HTML con relleno se despliega (F65, TAREA 041 Parte 1 E).

F65 (GRAVE): la landing de OF-007 estuvo en línea con un Impressum de relleno («N», «Calle 1, [PENDIENTE: Ort]», «a@b.c»)
y un Datenschutz sin datos reales. Reglas:
  * de_dueno(clave) → datos legales de datos/dueno.local.json (legal_de, legal_es, … según el mercado:
    datos/mercados.json → <mercado>.legal, o legal_<idioma>). Nunca de una plantilla ni de externo.local.json.
    Un campo obligatorio vacío o con relleno = FaltaLegal (no se arma ni se publica).
  * impressum_de() → {name, adresse, email, steuer} para la piel alemana (§5 DDG), desde legal_de.
  * problemas(texto) → relleno visible en un HTML: «[PENDIENTE», «{{», «Calle 1», correos de ejemplo (a@b.c,
    @example., @ejemplo., test@), «lorem ipsum», marcadores <…>/[…] en mayúsculas. netlify_deploy.py lo corre sobre
    TODOS los HTML del sitio antes de cualquier deploy (landing, retiro, corrección).
Solo biblioteca estándar.
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

RELLENO = (
    (re.compile(r"\[PENDIENTE", re.IGNORECASE), "marcador [PENDIENTE]"),
    (re.compile(r"\{\{\s*[A-Z_]+\s*\}\}"), "marcador {{…}} sin reemplazar"),
    (re.compile(r"\bCalle\s+1\b", re.IGNORECASE), "dirección de relleno «Calle 1»"),
    (re.compile(r"(?<![\w.+-])[A-Za-z0-9]@[A-Za-z0-9]\.[A-Za-z]{1,3}\b"), "correo de relleno (x@y.z)"),
    (re.compile(r"[\w.+-]+@(?:example|ejemplo|beispiel|test|prueba)\.[a-z]{2,}", re.IGNORECASE), "correo de ejemplo"),
    (re.compile(r"\b(?:test|prueba|nombre|correo)@", re.IGNORECASE), "correo de ejemplo"),
    (re.compile(r"lorem ipsum", re.IGNORECASE), "texto lorem ipsum"),
    (re.compile(r"pay\.hotmart\.com/A1B2C3"), "checkout de prueba (A1B2C3)"),
    (re.compile(r"\[(?:NOMBRE|DIRECCION|DIRECCIÓN|CORREO|EMAIL|ORT|NAME|ADRESSE)[^\]]*\]", re.IGNORECASE), "marcador entre corchetes"),
    (re.compile(r"<(?:NOMBRE|NOMBRE_EXACTO|CORREO|DIRECCION)[^>]*>"), "marcador entre <>"),
)
OBLIGATORIOS = {"legal_de": ("nombre", "domicilio", "ciudad", "codigo_postal", "pais", "correo"),
                "legal_es": ("titular", "domicilio", "pais", "correo_contacto")}


class FaltaLegal(RuntimeError):
    pass


def problemas(texto):
    out = []
    for pat, que in RELLENO:
        m = pat.search(texto or "")
        if m:
            out.append("%s («%s»)" % (que, m.group(0)[:40]))
    return out


def clave_de(mercado):
    """Qué bloque de dueno.local.json usa un mercado: mercados.json → <mercado>.legal, si no legal_<idioma>."""
    m = (rutas.leer_json(rutas.ruta("datos", "mercados.json"), defecto={}) or {}).get(mercado) or {}
    if m.get("legal"):
        return m["legal"]
    idioma = (m.get("idioma") or str(mercado or "").split("-")[0] or "").lower()
    return "legal_%s" % idioma


def de_dueno(clave):
    try:
        d = rutas.cargar_dato("dueno")
    except rutas.FaltaDato as e:
        raise FaltaLegal(str(e))
    bloque = d.get(clave)
    if not isinstance(bloque, dict):
        raise FaltaLegal("datos/dueno.local.json no tiene «%s» (datos legales de este mercado)" % clave)
    for campo in OBLIGATORIOS.get(clave, ()):
        v = str(bloque.get(campo) or "").strip()
        if not v or problemas(v):
            raise FaltaLegal("datos/dueno.local.json → %s.%s vacío o con relleno" % (clave, campo))
    return bloque


def impressum_de():
    """{name, adresse, email, steuer} del Impressum alemán desde dueno.local.json → legal_de."""
    b = de_dueno("legal_de")
    lugar = " ".join(x for x in (str(b.get("codigo_postal") or "").strip(), str(b.get("ciudad") or "").strip()) if x)
    partes = [str(b.get("domicilio") or "").strip(), lugar, str(b.get("provincia") or "").strip(), str(b.get("pais") or "").strip()]
    steuer = str(b.get("cuit") or b.get("steuer") or "").strip()
    return {"name": str(b["nombre"]).strip(), "adresse": ", ".join(p for p in partes if p), "email": str(b["correo"]).strip(),
            "steuer": ("Steuernummer (CUIT, Argentinien): %s" % steuer) if steuer and b.get("cuit") else (steuer or "—")}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Revisa HTML por relleno legal (F65) o los datos legales del dueño.")
    ap.add_argument("html", nargs="*")
    ap.add_argument("--clave", help="legal_de, legal_es…: valida ese bloque de datos/dueno.local.json (sin imprimir valores)")
    a = ap.parse_args()
    malos = {}
    for f in a.html:
        p = problemas(open(f, encoding="utf-8", errors="replace").read())
        if p:
            malos[f] = p
    if a.clave:
        try:
            de_dueno(a.clave)
        except FaltaLegal as e:
            malos[a.clave] = [str(e)]
    print(json.dumps({"ok": not malos, "codigo": 0 if not malos else 2, "motivo": malos or "sin relleno", "artefactos": []},
                     ensure_ascii=False))
    sys.exit(0 if not malos else 2)
