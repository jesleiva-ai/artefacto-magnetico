#!/usr/bin/env python3
"""medios.py — gasto en imágenes y voces (Higgsfield, ElevenLabs): de la elección firmada del dueño a tickets del plan del
día con tope de llamadas y de créditos o USD (pedido de Ramiro vía Director_H1, 2026-10-28; CLAUDE.md reglas 4 y 5).

La elección vive en datos/topes.local.json → «medios» y la firma `firmar.py` (una sola pregunta: «¿Cómo querés el gasto
en imágenes y voces?»):
  * minimo        — lo recomendado de hoy: 150 créditos de Higgsfield y 5 USD de ElevenLabs por producto.
  * personalizado — los números que escribe el dueño.
  * libre         — «que gaste dentro de lo razonable lo que quiera» (Ramiro): tickets automáticos sin pedir nada, pero
                    siempre con techo por producto, por día y mensual por proveedor (LIBRE, editables en el archivo).
En los tres modos: la ficha manda si trae su tope (D105, presupuesto.por_proveedor.<proveedor>.tope_autorizado); costo o
consumo desconocido = no hay ticket (nulo ≠ 0); al cruzar el 80 % de un techo se avisa al dueño (avisos.py) una vez por
techo y día. El cupo en créditos o USD se pasa a llamadas con el costo máximo por llamada (COSTO_MAX_LLAMADA, editable):
cada llamada sigue pasando por registro.py con su estimado > 0 y la conciliación real va al libro de gasto.

    emitir(of, *, fecha=None, minutos=60, regla=None, raiz=None) -> {"ok", "motivo", "tickets", "cupos", "avisos"}
    configuracion(topes) -> {"modo", "higgsfield": {...}, "elevenlabs": {...}, "costo_max_llamada": {...}, "aviso_pct"}
Solo biblioteca estándar. Sin red.
"""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

MODOS = ("minimo", "personalizado", "libre")
PROVEEDORES = ("higgsfield", "elevenlabs")
UNIDAD = {"higgsfield": "creditos", "elevenlabs": "USD"}
# minimo: los 150 créditos por producto que firmó Ramiro como recomendado (TAREA 041, firmar.RECOMENDADO); el diario y el
# mensual acompañan a 1 producto nuevo por día.
MINIMO = {"higgsfield": {"producto": 150, "dia": 150, "mes": 1500}, "elevenlabs": {"producto": 5, "dia": 5, "mes": 50}}
# libre: techos «razonables» por defecto (se pueden cambiar en datos/topes.local.json → medios). Referencias: OF-006 usó
# ~200 créditos entre mockups e imágenes de Hotmart (EJ-021 + EJ-023), un plan de Higgsfield ronda los miles por mes.
LIBRE = {"higgsfield": {"producto": 500, "dia": 800, "mes": 5000}, "elevenlabs": {"producto": 20, "dia": 30, "mes": 150}}
# Costo máximo de UNA llamada, para convertir el cupo en llamadas: GPT Image 2.5 high 2k = 2,75–3,5 créditos; un video
# corto puede costar varias decenas. Una llamada más cara que esto queda igual frenada por registro.py y por los topes.
COSTO_MAX_LLAMADA = {"higgsfield": 12, "elevenlabs": 1.0}
AVISO_PCT = 80
# Tipo del ticket (plan.TICKETS["medios"]) → proveedor
PROVEEDOR_TIPO = {"medios_lote": "higgsfield", "medios_mejora": "higgsfield", "medios_voz": "elevenlabs"}


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v >= 0


def configuracion(topes):
    """La elección de medios del dueño, completa. Sin sección «medios» (topes firmados antes de este cambio) = modo
    «minimo» con los números que ya estaban (por_producto_defecto y por_proveedor_dia) y, si faltan, los de MINIMO."""
    m = dict((topes or {}).get("medios") or {})
    modo = m.get("modo") if m.get("modo") in MODOS else "minimo"
    base = LIBRE if modo == "libre" else MINIMO
    ppd = (topes or {}).get("por_producto_defecto") or {}
    ppd_dia = (topes or {}).get("por_proveedor_dia") or {}
    conf = {"modo": modo, "aviso_pct": m.get("aviso_pct") if _num(m.get("aviso_pct")) else AVISO_PCT,
            "costo_max_llamada": dict(COSTO_MAX_LLAMADA, **{k: v for k, v in (m.get("costo_max_llamada") or {}).items()
                                                           if k in PROVEEDORES and _num(v) and v > 0})}
    for p in PROVEEDORES:
        dado = m.get(p) or {}
        viejo = {"producto": (ppd.get(p) or {}).get("tope"), "dia": (ppd_dia.get(p) or {}).get("tope")}
        techos = {}
        for k in ("producto", "dia", "mes"):
            v = dado.get(k)
            if not _num(v) and modo != "libre":
                v = viejo.get(k)          # lo firmado antes de la sección «medios» se respeta
            if not _num(v) and modo != "personalizado":
                v = base[p][k]
            techos[k] = v if _num(v) else None   # personalizado sin número = sin techo = no se gasta
        conf[p] = dict(techos, unidad=UNIDAD[p])
    return conf


def _firmados(topes):
    f = (topes or {}).get("firmado") or {}
    q = f.get("quien")
    return isinstance(q, str) and q.strip() and not q.startswith(("<", "["))


def _tope_ficha(of, proveedor):
    import topes as T
    ficha = rutas.leer_json(rutas.ruta_ficha(of), defecto={}) or {}
    tf = T.tope_ficha(ficha, proveedor)
    return tf["tope"] if tf else None


def cupos(of, conf, fecha, raiz=None):
    """Por proveedor: {"producto", "dia", "mes", "usado", "cupo", "aviso"} con lo que queda. Libro ilegible o techo
    nulo → cupo None (no hay ticket)."""
    import topes as T
    out = {}
    for p in PROVEEDORES:
        c = conf[p]
        techo_producto = _tope_ficha(of, p)
        if techo_producto is None:
            techo_producto = c["producto"]
        techos = {"producto": techo_producto, "dia": c["dia"], "mes": c["mes"]}
        try:
            usado = {"producto": T.gastado(proveedor=p, of=of, raiz=raiz),
                     "dia": T.gastado(proveedor=p, desde=fecha, hasta=fecha, raiz=raiz),
                     "mes": T.gastado(proveedor=p, desde=fecha[:8] + "01", hasta=fecha, raiz=raiz)}
        except T.TopesFaltantes as e:
            out[p] = {"cupo": None, "motivo": str(e)}
            continue
        if any(v is None for v in techos.values()):
            falta = [k for k, v in techos.items() if v is None]
            out[p] = {"cupo": None, "motivo": "sin techo %s para %s: no se gasta" % ("/".join(falta), p), **techos}
            continue
        if any(v is None for v in usado.values()):
            out[p] = {"cupo": None, "motivo": "consumo de %s desconocido (nulo ≠ 0): no se gasta" % p, **techos}
            continue
        restos = {k: round(techos[k] - usado[k], 4) for k in techos}
        avisos = ["%s %s: %s de %s %s (%d %%)" % (p, k, usado[k], techos[k], c["unidad"], round(100 * usado[k] / techos[k]))
                  for k in techos if techos[k] > 0 and usado[k] / techos[k] * 100 >= conf["aviso_pct"]]
        out[p] = dict(techos, usado=usado, cupo=max(0.0, min(restos.values())), unidad=c["unidad"], avisos=avisos)
    return out


def _avisar(of, fecha, lineas, pct=AVISO_PCT):
    """Un aviso por techo y día (no repite en cada ticket del mismo día). Devuelve las líneas avisadas."""
    if not lineas:
        return []
    marcas_p = rutas.ruta("estado", "medios_avisos.json")
    marcas = rutas.leer_json(marcas_p, defecto={}) or {}
    nuevas = [x for x in lineas if marcas.get("%s|%s|%s" % (fecha, of, x.split(":")[0])) is None]
    if not nuevas:
        return []
    import avisos
    avisos.enviar("Gasto en imágenes y voces de %s pasó el %d %%" % (of, pct),
                  "Techos de medios (datos/topes.local.json → medios):\n- " + "\n- ".join(nuevas) +
                  "\nSe sigue gastando hasta el techo; para cambiarlo: python herramientas/firmar.py medios", nivel="aviso")
    for x in nuevas:
        marcas["%s|%s|%s" % (fecha, of, x.split(":")[0])] = rutas.ahora().isoformat(timespec="seconds")
    rutas.escribir_json(marcas_p, marcas)
    return nuevas


def emitir(of, *, fecha=None, minutos=60, regla=None, raiz=None):
    """Tickets «medios» para `of` dentro de lo que queda de cada techo. No emite nada si los topes no están firmados,
    si un techo falta o si el consumo es desconocido."""
    import plan
    import topes as T
    fecha = fecha or rutas.hoy()
    try:
        topes = T.cargar(raiz)
    except T.TopesFaltantes as e:
        return {"ok": False, "motivo": str(e), "tickets": [], "cupos": {}, "avisos": []}
    if not _firmados(topes):
        return {"ok": False, "motivo": "topes sin firmar (python herramientas/firmar.py topes): no hay tickets de medios",
                "tickets": [], "cupos": {}, "avisos": []}
    conf = configuracion(topes)
    cs = cupos(of, conf, fecha, raiz)
    maximos, detalles = {}, {}
    for herramienta, maximo, tipo, _alcance in plan.TICKETS["medios"]:
        p = PROVEEDOR_TIPO[tipo]
        c = cs.get(p) or {}
        if not c.get("cupo"):
            maximos[herramienta] = 0
            continue
        maximos[herramienta] = min(maximo, int(c["cupo"] // conf["costo_max_llamada"][p]))
        detalles[herramienta] = {"objeto": "medios.%s" % p, "gratuita": False, "estimado": c["cupo"], "unidad": c["unidad"],
                                 "costo_max_llamada": conf["costo_max_llamada"][p], "modo_medios": conf["modo"],
                                 "tope_ref": "datos/topes.local.json#medios.%s" % p}
    ids = plan.emitir(of, "medios", fecha=fecha, minutos=minutos, regla=regla or "medios (%s)" % conf["modo"],
                      maximos=maximos, detalles=detalles)
    avisados = _avisar(of, fecha, [x for p in PROVEEDORES for x in (cs.get(p) or {}).get("avisos", [])], conf["aviso_pct"])
    sin = ["%s: %s" % (p, (cs.get(p) or {}).get("motivo") or "cupo agotado") for p in PROVEEDORES if not (cs.get(p) or {}).get("cupo")]
    motivo = "%d ticket(s) de medios en modo %s" % (len(ids), conf["modo"]) + ("; sin cupo → " + "; ".join(sin) if sin else "")
    return {"ok": bool(ids), "motivo": motivo, "tickets": ids, "cupos": cs, "avisos": avisados, "modo": conf["modo"]}


if __name__ == "__main__":
    print(json.dumps(configuracion(json.loads(sys.stdin.read() or "{}")), ensure_ascii=False, indent=1))
