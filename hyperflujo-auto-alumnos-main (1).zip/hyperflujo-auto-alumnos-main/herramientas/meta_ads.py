#!/usr/bin/env python3
"""Registro, topes y camino alternativo para la campaña de Meta (TAREA 032, D60; act. 3 y 4). Solo stdlib.
Origen: hyperflujo/herramientas/meta_ads.py (copia SIN ADAPTAR — [PENDIENTE: importa `claves` (no existe aún, C2) y textos del taller; adaptar a rutas.py, puerta.py y freno_meta.py]). No se importa en la suite.

VÍA PRINCIPAL: el conector oficial `meta-ads` (https://mcp.facebook.com/ads, OAuth, sin claves; operacion/meta_mcp.md).
El agente llama sus herramientas (`mcp__meta-ads__ads_create_campaign`, `…ads_create_ad_set`, `…ads_create_creative`,
`…ads_create_ad`, `…ads_activate_entity`, `…ads_update_entity`; reporting con `…ads_get_ad_entities`) y este módulo
pone el REGISTRO y los TOPES alrededor de cada escritura:

    python herramientas/meta_ads.py topes      <plan_campana.json>   # topes de la ficha → daily_budget y spend_cap
    python herramientas/meta_ads.py mcp-inicio <plan> --ej <reg> --herramienta ads_create_campaign --clave campana --params '{...}'
    python herramientas/meta_ads.py mcp-id     --ej <reg> --sol SOL-001 --id <id de Meta>
    python herramientas/meta_ads.py mcp-rechazo --ej <reg> --sol SOL-001 --error "<lo que respondió el conector>"

CAMINO ALTERNATIVO (Graph API, `Cliente`): solo si el OAuth falla (meta_mcp.md §5, token de usuario del sistema en .env:
META_ACCESS_TOKEN, META_AD_ACCOUNT_ID, META_PAGE_ID) o para lo que el conector no expone (subir medios locales,
límite de gasto de la CUENTA):

    python herramientas/meta_ads.py claves                       # META_* definida / no definida (nunca valores)
    python herramientas/meta_ads.py plan    <plan_campana.json>  # simulación: llamadas que haría, sin red
    python herramientas/meta_ads.py crear   <plan_campana.json> --ej <registro.json>
    python herramientas/meta_ads.py insights <plan_campana.json> --desde AAAA-MM-DD --hasta AAAA-MM-DD --csv <salida.csv>
    python herramientas/meta_ads.py estado  <plan_campana.json> --objeto <id> --a ACTIVE --ok "<cita del OK del dueño>" --ej <registro.json>
    python herramientas/meta_ads.py vigilar <plan_campana.json> --ej <registro.json>

`filas_csv`/`escribir_csv` dan la forma de campanas/mapeo.json (para importar_csv) con cualquiera de los dos caminos.

Reglas (D60, regla 5 adaptada):
- Sin topes escritos en la ficha (oferta.json → campana.presupuesto: diario, dias, moneda, autorizado_por <dueño de datos/dueno.local.json>,
  autorizacion_ref) no se crea nada: SinTope.
- Todo se crea con status PAUSED. Pasar a ACTIVE exige --ok con la cita del OK escrito del dueño; queda en el registro.
- Cada escritura es una solicitud gratuita en el registro (crear/editar objetos no cobra; el gasto real lo mide
  insights y se concilia con registrar_consumo). Orden: agregar_solicitud → marcar_enviando → enviar una vez →
  guardar_id_externo.
- Pausa automática (sin OK) solo si el gasto del día supera el diario autorizado o la landing/el checkout no responden.
- El token nunca se imprime ni se guarda: los parámetros registrados no incluyen access_token.
"""
import argparse
import base64
import csv
import json
import math
import mimetypes
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import date

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
sys.path.insert(0, AQUI)
import claves as _claves  # noqa: E402
import registro as _registro  # noqa: E402

VERSION_API = "v23.0"   # confirmar con la primera llamada real (GET /me); cambiar acá si Meta la retira
BASE = "https://graph.facebook.com/%s/" % VERSION_API
NOMBRES_CLAVES = ["META_ACCESS_TOKEN", "META_AD_ACCOUNT_ID", "META_PAGE_ID", "META_INSTAGRAM_ID"]
OBLIGATORIAS = NOMBRES_CLAVES[:3]
MIN_SPEND_CAP_CAMPANA_USD = 100
def _duenos_autorizantes():
    """Nombres exactos desde datos/dueno.local.json (PLAN §3.4); sin archivo = nadie autoriza (no se gasta)."""
    try:
        with open(os.path.join(RAIZ, "datos", "dueno.local.json"), encoding="utf-8") as f:
            return tuple(d["nombre"] for d in json.load(f).get("duenos", []) if "gasto" in d.get("puede", []))
    except (OSError, ValueError, KeyError):
        return ()


DUENOS_AUTORIZANTES = _duenos_autorizantes()   # quién puede autorizar gasto en Meta (D59/D60); igualdad exacta   # Meta: el límite de gasto de campaña mínimo es ~USD 100
MOTIVO_GRATUITA = ("Marketing API: crear o editar objetos no cobra; el gasto lo mide insights y se concilia con "
                   "registrar_consumo (D60).")
UTM = "utm_source=FB&utm_medium={{adset.id}}&utm_campaign={{campaign.id}}&utm_content={{ad.id}}&utm_term=%s"
CABECERA_CSV = ["Account ID", "Account name", "Campaign name", "Ad set name", "Ad name", "Ad ID", "Day", "Currency",
                "Attribution setting", "Amount spent", "Impressions", "Reach", "Link clicks", "Landing page views",
                "3-second video plays", "Checkouts initiated", "Purchases", "Purchases conversion value",
                "Reporting starts", "Reporting ends"]
CAMPOS_INSIGHTS = ("account_id,account_name,account_currency,campaign_name,adset_name,ad_name,ad_id,spend,impressions,"
                   "reach,inline_link_clicks,actions,action_values")


class ErrorMeta(Exception):
    pass


class SinAcceso(ErrorMeta):
    pass


class SinTope(ErrorMeta):
    pass


class SinOK(ErrorMeta):
    pass


# ---------------------------------------------------------------- transporte
class TransporteHTTP:
    """Llamadas reales a graph.facebook.com. Devuelve el JSON; lanza ErrorMeta con el mensaje de Meta (sin token)."""

    def __init__(self, token, timeout=120):
        self._token = token
        self.timeout = timeout

    def __call__(self, metodo, ruta, params=None, archivo=None):
        params = dict(params or {})
        params["access_token"] = self._token
        url = ruta if ruta.startswith("http") else BASE + ruta.lstrip("/")
        datos, cab = None, {}
        if metodo == "GET":
            # paging.next ya trae access_token y el resto de la consulta: no repetir (revisión 032, H5)
            if "access_token" in urllib.parse.parse_qs(urllib.parse.urlparse(url).query):
                params.pop("access_token")
            if params:
                url += ("&" if "?" in url else "?") + urllib.parse.urlencode(_plano(params))
        elif archivo:
            datos, tipo = _multipart(_plano(params), archivo)
            cab["Content-Type"] = tipo
        else:
            datos = urllib.parse.urlencode(_plano(params)).encode()
        req = urllib.request.Request(url, data=datos, method=metodo, headers=cab)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                err = json.loads(e.read().decode("utf-8")).get("error", {})
                msg = "%s (code %s/%s)" % (err.get("message"), err.get("code"), err.get("error_subcode"))
            except Exception:
                msg = "HTTP %s" % e.code
            raise ErrorMeta("Meta rechazó %s %s: %s" % (metodo, ruta.split("?")[0], msg)) from None


class TransporteFalso:
    """Para tests y para `plan`: registra las llamadas y devuelve IDs sucesivos. `respuestas` = {(metodo, sufijo): dict}."""

    def __init__(self, respuestas=None):
        self.llamadas = []
        self.respuestas = respuestas or {}
        self.objetos = {}                 # estado de objetos (cuenta, campaña) que las escrituras actualizan
        self.ignorar_escrituras = set()   # objetos cuyo cambio Meta «no aplica» (para probar la relectura)
        self._n = 0

    def __call__(self, metodo, ruta, params=None, archivo=None):
        self.llamadas.append({"metodo": metodo, "ruta": ruta, "params": dict(params or {}),
                              "archivo": os.path.basename(archivo[1]) if archivo else None})
        objeto = "/" not in ruta and not ruta.startswith("http")
        if objeto and metodo == "POST":   # actualización de un objeto (estado, límite de la cuenta)
            if ruta not in self.ignorar_escrituras:
                self.objetos.setdefault(ruta, {}).update(params or {})
            return {"success": True}
        for (m, sufijo), r in self.respuestas.items():
            if m == metodo and ruta.endswith(sufijo):
                r = r(params) if callable(r) else r
                return dict(r, **self.objetos.get(ruta, {})) if objeto else r
        if objeto and ruta in self.objetos:
            return dict(self.objetos[ruta])
        if metodo == "GET":
            return {"data": []}
        if ruta.endswith("adimages"):
            nombre = params.get("name", "img")
            return {"images": {nombre: {"hash": "hash_%s" % nombre}}}
        self._n += 1
        return {"id": "9%014d" % self._n}


def _plano(params):
    return {k: (json.dumps(v, ensure_ascii=False, separators=(",", ":")) if isinstance(v, (dict, list)) else v)
            for k, v in params.items()}


def _multipart(campos, archivo):
    nombre_campo, ruta = archivo
    limite = "----hyperflujo" + uuid.uuid4().hex
    partes = []
    for k, v in campos.items():
        partes.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (limite, k, v)).encode())
    with open(ruta, "rb") as f:
        contenido = f.read()
    tipo = mimetypes.guess_type(ruta)[0] or "application/octet-stream"
    partes.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n"
                   % (limite, nombre_campo, os.path.basename(ruta), tipo)).encode() + contenido + b"\r\n")
    partes.append(("--%s--\r\n" % limite).encode())
    return b"".join(partes), "multipart/form-data; boundary=%s" % limite


# ---------------------------------------------------------------- claves y topes
def estado_claves(ruta_env=None):
    env = _claves.leer_env(ruta_env)
    return {n: bool(os.environ.get(n) or env.get(n)) for n in NOMBRES_CLAVES}


def acceso(ruta_env=None):
    faltan = [n for n, ok in estado_claves(ruta_env).items() if n in OBLIGATORIAS and not ok]
    if faltan:
        raise SinAcceso("Espera acceso: faltan %s en .env (los carga el dueño, nunca por chat)." % ", ".join(faltan))
    leer = lambda n: _claves.clave(n, ruta_env)  # noqa: E731
    cuenta = leer("META_AD_ACCOUNT_ID")
    cuenta = cuenta if cuenta.startswith("act_") else "act_" + cuenta
    ig = os.environ.get("META_INSTAGRAM_ID") or _claves.leer_env(ruta_env).get("META_INSTAGRAM_ID")
    return {"token": leer("META_ACCESS_TOKEN"), "cuenta": cuenta, "pagina": leer("META_PAGE_ID"), "instagram": ig}


def topes(ficha):
    """Topes escritos en la ficha. Sin ellos no se crea nada (regla 5 adaptada, D60)."""
    p = (ficha.get("campana") or {}).get("presupuesto") or {}
    diario, dias = p.get("diario"), p.get("dias")
    errores = []
    if not (isinstance(diario, (int, float)) and not isinstance(diario, bool) and math.isfinite(diario) and diario > 0):
        errores.append("campana.presupuesto.diario (número > 0)")
    if not (isinstance(dias, int) and not isinstance(dias, bool) and dias > 0):
        errores.append("campana.presupuesto.dias (entero > 0)")
    if p.get("moneda") != "USD":
        errores.append("campana.presupuesto.moneda = USD")
    # igualdad exacta contra los dueños que autorizan gasto (revisión 032, H3): «Director (… lo fija Ramiro …)» no vale
    if str(p.get("autorizado_por", "")).strip() not in DUENOS_AUTORIZANTES:
        errores.append("campana.presupuesto.autorizado_por = %s (exacto)" % " | ".join(DUENOS_AUTORIZANTES))
    if not (isinstance(p.get("autorizacion_ref"), str) and p["autorizacion_ref"].strip()):
        errores.append("campana.presupuesto.autorizacion_ref (dónde está el OK escrito)")
    if errores:
        raise SinTope("Sin topes escritos en la ficha no se crea nada. Falta: " + "; ".join(errores))
    total = round(diario * dias, 2)
    if total < MIN_SPEND_CAP_CAMPANA_USD:
        raise SinTope("Meta exige un límite de gasto de campaña ≥ USD %d; diario × días = %s."
                      % (MIN_SPEND_CAP_CAMPANA_USD, total))
    return {"diario": float(diario), "dias": dias, "total": total, "moneda": "USD",
            "autorizado_por": p["autorizado_por"].strip(), "autorizacion_ref": p["autorizacion_ref"].strip()}


def _centavos_leidos(v):
    return int(round(float(v or 0)))


def verificar_topes_campana(t, campana):
    """Solo los topes de la campaña (spend_cap y daily_budget en centavos), para el desvío sin_tope_cuenta."""
    errores = []
    if _centavos_leidos(campana.get("spend_cap")) != centavos(t["total"]):
        errores.append("spend_cap de campaña %s ≠ %d" % (campana.get("spend_cap"), centavos(t["total"])))
    if _centavos_leidos(campana.get("daily_budget")) != centavos(t["diario"]):
        errores.append("daily_budget %s ≠ %d" % (campana.get("daily_budget"), centavos(t["diario"])))
    if errores:
        raise SinTope("No se activa: " + "; ".join(errores))
    return True


def verificar_topes_leidos(t, campana, cuenta):
    """Antes de ACTIVAR (revisión 032, H2; D60): lo que Meta tiene escrito tiene que coincidir con la ficha.
    campana = {spend_cap, daily_budget} y cuenta = {spend_cap, amount_spent}, en centavos (subunidad de la moneda)."""
    errores = []
    if _centavos_leidos(campana.get("spend_cap")) != centavos(t["total"]):
        errores.append("spend_cap de campaña %s ≠ %d (USD %.2f autorizados)" % (campana.get("spend_cap"), centavos(t["total"]), t["total"]))
    if _centavos_leidos(campana.get("daily_budget")) != centavos(t["diario"]):
        errores.append("daily_budget %s ≠ %d (USD %.2f/día)" % (campana.get("daily_budget"), centavos(t["diario"]), t["diario"]))
    cap, gastado = _centavos_leidos(cuenta.get("spend_cap")), _centavos_leidos(cuenta.get("amount_spent"))
    if cap <= 0 or cap - gastado > centavos(t["total"]):
        errores.append("límite de la cuenta %s − gastado %s: sin límite o margen mayor que lo autorizado (%d)"
                       % (cuenta.get("spend_cap"), cuenta.get("amount_spent"), centavos(t["total"])))
    if errores:
        raise SinTope("No se activa: " + "; ".join(errores))
    return True


def centavos(usd):
    return int(round(usd * 100))


# ---------------------------------------------------------------- cliente
class Cliente:
    def __init__(self, cuenta, pagina, transporte, registro=None, instagram=None, base_archivos=None):
        self.cuenta = cuenta if cuenta.startswith("act_") else "act_" + cuenta
        self.pagina, self.instagram = pagina, instagram
        self.t = transporte
        self.registro = registro              # ruta a registro.json de la EJ (None = sin registro: solo tests/plan)
        self.base = base_archivos or RAIZ

    # Escritura con registro: una solicitud gratuita por operación, ID guardado apenas llega.
    def _escribir(self, clave, ruta, params, archivo=None, id_de=None):
        sid = None
        if self.registro:
            reg_params = {"ruta": ruta, "params": {k: v for k, v in params.items() if k != "access_token" and k != "bytes"}}
            sid = _registro.agregar_solicitud(self.registro, "api", "meta", clave=clave, estimado=0, gratuita=True,
                                              motivo_gratuita=MOTIVO_GRATUITA, parametros=reg_params)
            _registro.marcar_enviando(self.registro, sid)
        try:
            r = self.t("POST", ruta, params, archivo)
        except ErrorMeta as e:
            if sid:
                _registro.marcar_rechazada(self.registro, sid, str(e))
            raise
        ident = id_de(r) if id_de else (r.get("id") or ("ok" if r.get("success") else None))
        if not ident:
            raise ErrorMeta("Meta no devolvió id para %s: %s" % (clave, json.dumps(r)[:200]))
        if sid:
            _registro.guardar_id_externo(self.registro, sid, str(ident))
            _registro.cambiar_estado(self.registro, "completada", solicitud_id=sid)
        return ident

    def leer(self, ruta, params=None):
        return self.t("GET", ruta, params or {})

    def _todas(self, ruta, params):
        r = self.leer(ruta, params)
        datos = list(r.get("data", []))
        while (r.get("paging") or {}).get("next"):
            r = self.t("GET", r["paging"]["next"], {})
            datos += r.get("data", [])
        return datos

    # --- cuenta
    def cuenta_info(self):
        return self.leer(self.cuenta, {"fields": "name,currency,account_status,spend_cap,amount_spent,timezone_name"})

    def fijar_limite_cuenta(self, tope_usd, clave="cuenta_spend_cap"):
        info = self.cuenta_info()
        if info.get("currency") and info["currency"] != "USD":
            raise SinTope("La cuenta publicitaria está en %s; los topes están en USD. Revisar antes de seguir." % info["currency"])
        # Revisión 032, H1: el spend_cap de la cuenta va en subunidad (centavos) y se compara con amount_spent ACUMULADO
        # de toda la vida de la cuenta: tope = gastado + autorizado. Se relee después de escribirlo.
        gastado = _centavos_leidos(info.get("amount_spent"))
        nuevo = gastado + centavos(tope_usd)
        self._escribir(clave, self.cuenta, {"spend_cap": nuevo}, id_de=lambda r: self.cuenta if r.get("success") else None)
        leido = _centavos_leidos(self.cuenta_info().get("spend_cap"))
        if leido != nuevo:
            raise SinTope("El límite de la cuenta releído (%d) no es el escrito (%d = gastado %d + autorizado %d): no se sigue."
                          % (leido, nuevo, gastado, centavos(tope_usd)))
        if self.registro:
            _registro.registrar_consumo(self.registro, "meta", quien="meta_ads (relectura)",
                                        nota="límite de la cuenta verificado: spend_cap %d = gastado %d + autorizado %d (centavos)"
                                        % (nuevo, gastado, centavos(tope_usd)))
        return {"cuenta": self.cuenta, "spend_cap_centavos": nuevo, "amount_spent_centavos": gastado}

    # --- objetos
    def crear_campana(self, nombre, diario_usd, tope_usd, clave="campana"):
        return self._escribir(clave, "%s/campaigns" % self.cuenta, {
            "name": nombre, "objective": "OUTCOME_SALES", "status": "PAUSED", "buying_type": "AUCTION",
            "special_ad_categories": [], "daily_budget": centavos(diario_usd), "spend_cap": centavos(tope_usd),
            "bid_strategy": "LOWEST_COST_WITHOUT_CAP"})

    def crear_conjunto(self, campana_id, nombre, pixel_id, paises, edad_min=18, clave="conjunto"):
        return self._escribir(clave, "%s/adsets" % self.cuenta, {
            "name": nombre, "campaign_id": campana_id, "status": "PAUSED",
            "optimization_goal": "OFFSITE_CONVERSIONS", "billing_event": "IMPRESSIONS",
            "promoted_object": {"pixel_id": str(pixel_id), "custom_event_type": "PURCHASE"},
            "targeting": {"geo_locations": {"countries": list(paises)}, "age_min": edad_min,
                          "targeting_automation": {"advantage_audience": 1}}})

    def subir_imagen(self, ruta_rel, clave=None):
        ruta = os.path.join(self.base, ruta_rel)
        nombre = os.path.basename(ruta)
        with open(ruta, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        return self._escribir(clave or "img:" + nombre, "%s/adimages" % self.cuenta, {"bytes": b64, "name": nombre},
                              id_de=lambda r: next(iter((r.get("images") or {}).values()), {}).get("hash"))

    def subir_video(self, ruta_rel, clave=None):
        ruta = os.path.join(self.base, ruta_rel)
        return self._escribir(clave or "video:" + os.path.basename(ruta), "%s/advideos" % self.cuenta,
                              {"name": os.path.basename(ruta)}, archivo=("source", ruta))

    def _identidad(self):
        spec = {"page_id": self.pagina}
        if self.instagram:
            spec["instagram_user_id"] = self.instagram
        return spec

    def crear_creativo(self, anuncio, hashes, video_id=None, clave=None):
        """anuncio = entrada de plan_campana.anuncios; hashes = {archivo_rel: image_hash}."""
        link = anuncio["url_destino"]
        cta = {"type": anuncio.get("cta_tipo", "LEARN_MORE"), "value": {"link": link}}   # D100: nunca SHOP_NOW
        spec = self._identidad()
        if anuncio["formato"].startswith("carrusel"):
            spec["link_data"] = {"link": link, "message": anuncio["texto_primario"], "call_to_action": cta,
                                 "multi_share_optimized": False, "multi_share_end_card": False,
                                 "child_attachments": [{"link": link, "image_hash": hashes[l["archivo"]], "name": l["titulo"],
                                                        "description": l.get("descripcion", ""), "call_to_action": cta}
                                                       for l in anuncio["laminas"]]}
        elif anuncio["formato"].startswith("video"):
            spec["video_data"] = {"video_id": video_id, "image_hash": hashes[anuncio["miniatura"]],
                                  "message": anuncio["texto_primario"], "title": anuncio["titulo"],
                                  "link_description": anuncio.get("descripcion", ""), "call_to_action": cta}
        else:
            spec["link_data"] = {"link": link, "image_hash": hashes[anuncio["archivo"]], "message": anuncio["texto_primario"],
                                 "name": anuncio["titulo"], "description": anuncio.get("descripcion", ""), "call_to_action": cta}
        return self._escribir(clave or "creativo:" + anuncio["anuncio_id"], "%s/adcreatives" % self.cuenta, {
            "name": anuncio["anuncio_id"], "object_story_spec": spec, "url_tags": UTM % anuncio["anuncio_id"]})

    def crear_anuncio(self, conjunto_id, anuncio_id, creativo_id, clave=None):
        return self._escribir(clave or "anuncio:" + anuncio_id, "%s/ads" % self.cuenta, {
            "name": anuncio_id, "adset_id": conjunto_id, "creative": {"creative_id": creativo_id}, "status": "PAUSED"})

    def cambiar_estado(self, objeto_id, estado, ok=None, motivo=None, clave=None, ficha=None, campana_id=None):
        if estado not in ("ACTIVE", "PAUSED"):
            raise ErrorMeta("Estado inválido: %s" % estado)
        if estado == "ACTIVE":
            if not (ok and ok.strip()):
                raise SinOK("Activar exige el OK escrito del dueño (--ok con la cita y dónde está).")
            if ficha is None:
                raise ErrorMeta("Activar exige la ficha para releer los topes (revisión 032, H2).")
            camp = self.leer(campana_id or objeto_id, {"fields": "spend_cap,daily_budget"})
            verificar_topes_leidos(topes(ficha), camp, self.cuenta_info())
        params = {"status": estado}
        clave = clave or "estado:%s:%s:%s" % (objeto_id, estado, _registro.ahora())
        if self.registro:
            # el OK o el motivo de la pausa automática quedan en el registro junto a la llamada
            params_reg = dict(params, ok=ok, motivo=motivo)
            sid = _registro.agregar_solicitud(self.registro, "api", "meta", clave=clave, estimado=0, gratuita=True,
                                              motivo_gratuita=MOTIVO_GRATUITA, parametros={"ruta": objeto_id, "params": params_reg})
            _registro.marcar_enviando(self.registro, sid)
            try:
                r = self.t("POST", objeto_id, params)
            except ErrorMeta as e:
                _registro.marcar_rechazada(self.registro, sid, str(e))
                raise
            _registro.guardar_id_externo(self.registro, sid, objeto_id)
            _registro.cambiar_estado(self.registro, "completada", solicitud_id=sid)
            return r
        return self.t("POST", objeto_id, params)

    # --- lectura
    def insights(self, desde, hasta, nivel="ad", objeto=None):
        return self._todas("%s/insights" % (objeto or self.cuenta), {
            "level": nivel, "time_increment": 1, "fields": CAMPOS_INSIGHTS, "limit": 500,
            "time_range": {"since": desde, "until": hasta}})


# ---------------------------------------------------------------- insights → CSV (forma de campanas/mapeo.json, idioma en)
def _accion(lista, tipos):
    for t in tipos:   # primer tipo presente (sin sumar variantes: evita contar dos veces la misma compra)
        for a in lista or []:
            if a.get("action_type") == t:
                return float(a.get("value", 0))
    return 0.0


def filas_csv(datos):
    filas = []
    for d in datos:
        acc, val = d.get("actions"), d.get("action_values")
        filas.append({
            "Account ID": d.get("account_id"), "Account name": d.get("account_name"), "Campaign name": d.get("campaign_name"),
            "Ad set name": d.get("adset_name"), "Ad name": d.get("ad_name"), "Ad ID": d.get("ad_id"),
            "Day": d.get("date_start"), "Currency": d.get("account_currency"),
            "Attribution setting": "7-day click or 1-day view",
            "Amount spent": d.get("spend"), "Impressions": d.get("impressions"), "Reach": d.get("reach"),
            "Link clicks": d.get("inline_link_clicks") or _accion(acc, ["link_click"]),
            "Landing page views": _accion(acc, ["landing_page_view", "omni_landing_page_view"]),
            "3-second video plays": _accion(acc, ["video_view"]),
            "Checkouts initiated": _accion(acc, ["offsite_conversion.fb_pixel_initiate_checkout", "initiate_checkout", "omni_initiated_checkout"]),
            "Purchases": _accion(acc, ["offsite_conversion.fb_pixel_purchase", "purchase", "omni_purchase"]),
            "Purchases conversion value": _accion(val, ["offsite_conversion.fb_pixel_purchase", "purchase", "omni_purchase"]),
            "Reporting starts": d.get("date_start"), "Reporting ends": d.get("date_stop")})
    return filas


def escribir_csv(filas, salida):
    os.makedirs(os.path.dirname(os.path.abspath(salida)), exist_ok=True)
    with open(salida, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CABECERA_CSV)
        w.writeheader()
        for fila in filas:
            w.writerow(fila)
    return salida


# ---------------------------------------------------------------- operaciones de alto nivel
def leer_json(ruta):
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


def ficha_del_plan(plan, ruta_plan):
    return leer_json(os.path.join(RAIZ, "ofertas", plan["oferta_id"], "oferta.json"))


def validar_plan(plan):
    errores = []
    c = plan.get("campana", {})
    if c.get("tipo") != "Cash Trap CBO":
        errores.append("campana.tipo debe ser 'Cash Trap CBO'")
    if not c.get("pixel_id") or "PENDIENTE" in str(c.get("pixel_id")):
        errores.append("campana.pixel_id pendiente")
    if not c.get("paises") or any("PENDIENTE" in str(p) for p in c["paises"]):
        errores.append("campana.paises pendientes")
    n = len(plan.get("anuncios", []))
    if not 5 <= n <= 7:
        errores.append("Cash Trap pide 5 a 7 anuncios (§10.1); hay %d" % n)
    for a in plan.get("anuncios", []):
        if "PENDIENTE" in a.get("url_destino", "") or not a.get("url_destino", "").startswith("https://"):
            errores.append("%s: url_destino pendiente" % a.get("anuncio_id"))
    return errores


def crear_todo(plan, cliente, ficha):
    """Campaña + límite de cuenta + conjunto + medios + creativos + anuncios, todo en PAUSA. Devuelve los IDs."""
    t = topes(ficha)
    errores = validar_plan(plan)
    if errores:
        raise ErrorMeta("Plan incompleto: " + "; ".join(errores))
    c = plan["campana"]
    ids = {"topes": t, "anuncios": {}}
    ids["cuenta_spend_cap"] = cliente.fijar_limite_cuenta(t["total"])
    ids["campana"] = cliente.crear_campana(c["nombre"], t["diario"], t["total"])
    ids["conjunto"] = cliente.crear_conjunto(ids["campana"], c["conjunto"], c["pixel_id"], c["paises"])
    hashes = {}
    for a in plan["anuncios"]:
        archivos = [l["archivo"] for l in a.get("laminas", [])] or ([a["archivo"]] if a.get("archivo") else [])
        if a.get("miniatura"):
            archivos.append(a["miniatura"])
        for r in archivos:
            if r not in hashes:   # una imagen se sube una sola vez aunque la usen dos anuncios
                hashes[r] = cliente.subir_imagen(os.path.join(plan["_base"], r))
        video = cliente.subir_video(os.path.join(plan["_base"], a["video"])) if a.get("video") else None
        creativo = cliente.crear_creativo(a, hashes, video_id=video)
        ids["anuncios"][a["anuncio_id"]] = {"creativo": creativo, "anuncio": cliente.crear_anuncio(ids["conjunto"], a["anuncio_id"], creativo)}
    return ids


def responde(url, timeout=15):
    try:
        req = urllib.request.Request(url, method="GET", headers={"User-Agent": "hyperflujo-vigilancia"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return 200 <= r.status < 400
    except Exception:
        return False


# Hyperflujo D92 (decisión del dueño, 2026-10-22, textual): «si en 2 días está en negativo el producto se apagan los anuncios y se da por muerto,
# incluso si no hubo ni una venta en el primer período de 24 horas también se mata». Gana sobre las esperas de Matías y
# del Manual (desvío del dueño, OPERACION.md). Pausa automática sin OK; nada se reenciende sin decisión escrita del dueño.
def veredicto_d92(activada_en, ahora, ventas, ingresos_netos, gasto):
    """activada_en/ahora: datetime con zona; ventas: compras aprobadas (Hotmart o Purchase); ingresos_netos: lo que
    Hotmart deja al productor (USD); gasto: gasto total de la campaña en Meta (USD). Devuelve {accion, motivo, horas}."""
    horas = (ahora - activada_en).total_seconds() / 3600
    if horas >= 24 and ventas == 0:
        return {"accion": "PAUSAR", "producto": "muerto", "horas": round(horas, 1),
                "motivo": "D92: %.0f h desde la activación sin ninguna venta (gasto USD %.2f)" % (horas, gasto)}
    if horas >= 48 and ingresos_netos < gasto:
        return {"accion": "PAUSAR", "producto": "muerto", "horas": round(horas, 1),
                "motivo": "D92: a las %.0f h los ingresos netos de Hotmart (USD %.2f) no cubren el gasto en Meta (USD %.2f)"
                          % (horas, ingresos_netos, gasto)}
    return {"accion": None, "producto": "vivo", "horas": round(horas, 1), "motivo": None}


def vigilar(plan, cliente, ficha, hoy=None, sonda=responde, d92=None):
    """Pausa automática (sin OK) si el gasto de hoy supera el diario autorizado, si la landing/el checkout no responden
    o si D92 da el producto por muerto (d92 = argumentos de veredicto_d92)."""
    t = topes(ficha)
    hoy = hoy or date.today().isoformat()
    campana_id = plan["campana"].get("id")
    if not campana_id:
        raise ErrorMeta("El plan no tiene campana.id (¿se creó?).")
    datos = cliente.insights(hoy, hoy, nivel="campaign", objeto=campana_id)
    gasto = sum(float(d.get("spend") or 0) for d in datos)
    motivos = []
    if gasto > t["diario"]:
        motivos.append("gasto de hoy USD %.2f > diario autorizado USD %.2f" % (gasto, t["diario"]))
    for nombre, url in (("landing", plan["campana"].get("url_landing")), ("checkout", plan["campana"].get("url_checkout"))):
        if url and not sonda(url):
            motivos.append("%s no responde (%s)" % (nombre, url))
    v92 = veredicto_d92(**d92) if d92 else None
    if v92 and v92["accion"]:
        motivos.append(v92["motivo"])
    accion = None
    if motivos:
        cliente.cambiar_estado(campana_id, "PAUSED", motivo="pausa automática: " + "; ".join(motivos))
        accion = "PAUSADA"
    return {"fecha": hoy, "gasto_hoy": round(gasto, 2), "diario_autorizado": t["diario"], "motivos": motivos, "accion": accion,
            "d92": v92}


# ---------------------------------------------------------------- conector oficial meta-ads (TAREA 032 act. 3)
# El agente llama las herramientas del conector (mcp__meta-ads__*); este módulo solo pone el registro y los topes
# alrededor de cada escritura: mcp_inicio (antes, lanza si no corresponde) → una llamada → mcp_id (o mcp_rechazo).
MCP_CREAN = {"ads_create_campaign", "ads_create_ad_set", "ads_create_creative", "ads_create_ad", "ads_create_custom_audience"}
MCP_DINERO = {"ads_activate_entity", "ads_update_entity", "ads_update_custom_audience_users", "ads_delete_custom_audience",
              "ads_boost_ig_post"}
MOTIVO_MCP = "conector meta-ads: creación en pausa, sin gasto; el gasto lo mide insights y se concilia con registrar_consumo (D60)."


def _estado_en(params):
    for k in ("status", "estado", "configured_status"):
        if k in params:
            return str(params[k]).upper()
    return None


def mcp_inicio(ej, ficha, herramienta, clave, params, ok=None, spend_cap_aparte=None, verificacion=None):
    """Valida y registra una escritura por el conector ANTES de llamarla. Devuelve el SOL-…; si lanza, no se llama.

    - Crear: exige topes en la ficha; nada en estado distinto de PAUSED; la campaña lleva spend_cap = diario × días
      (en centavos o en USD) salvo spend_cap_aparte = cómo se fija (Graph API o el dueño en Ads Manager, verificado).
    - Gastar/cambiar dinero: exige el OK escrito del dueño (ok), salvo pasar a PAUSED con motivo (pausa automática).
      Un presupuesto diario por encima del autorizado se rechaza aunque haya OK: primero va el tope nuevo a la ficha.
    """
    herramienta = herramienta.replace("mcp__meta-ads__", "")
    params = dict(params or {})
    if herramienta in MCP_CREAN:
        t = topes(ficha)
        estado = _estado_en(params)
        if estado and estado != "PAUSED":
            raise ErrorMeta("%s: todo se crea en pausa (status=%s)." % (herramienta, estado))
        if herramienta == "ads_create_campaign":
            cap = params.get("spend_cap", params.get("campaign_spend_cap"))   # nombres del Graph API o del conector
            if cap is None and not spend_cap_aparte:
                raise SinTope("La campaña se crea con límite de gasto = USD %.2f (spend_cap); si el conector no lo acepta, "
                              "indicar spend_cap_aparte." % t["total"])
            if cap is not None and float(cap) not in (t["total"], float(centavos(t["total"]))):
                raise SinTope("spend_cap %s ≠ diario × días autorizados (USD %.2f)." % (cap, t["total"]))
            presu = params.get("daily_budget", params.get("campaign_daily_budget"))
            if presu is not None and float(presu) not in (t["diario"], float(centavos(t["diario"]))):
                raise SinTope("daily_budget %s ≠ diario autorizado (USD %.2f)." % (presu, t["diario"]))
        motivo = MOTIVO_MCP
    elif herramienta in MCP_DINERO:
        pausa = herramienta == "ads_update_entity" and _estado_en(params) == "PAUSED" and set(params) <= {
            "status", "estado", "configured_status", "id", "entity_id", "motivo"}
        if not pausa and not (ok and ok.strip()):
            raise SinOK("%s gasta o cambia dinero: exige el OK escrito del dueño (cita y dónde)." % herramienta)
        if herramienta == "ads_activate_entity" or (herramienta == "ads_update_entity" and _estado_en(params) == "ACTIVE"):
            # H2: el agente lee antes por el conector (ads_get_ad_entities) los topes que Meta tiene escritos
            if not verificacion:
                raise SinTope("Activar exige verificacion={campana:{spend_cap,daily_budget}, cuenta:{spend_cap,amount_spent}} "
                              "leídos del conector, en centavos.")
            if verificacion.get("sin_tope_cuenta"):
                # Desvío de D60 decidido por escrito (p. ej. el conector no lee ni escribe el límite de la cuenta): solo campaña.
                if not str(verificacion["sin_tope_cuenta"]).strip():
                    raise SinTope("sin_tope_cuenta exige el motivo y quién lo decidió.")
                verificar_topes_campana(topes(ficha), verificacion.get("campana") or {})
            else:
                verificar_topes_leidos(topes(ficha), verificacion.get("campana") or {}, verificacion.get("cuenta") or {})
        if "daily_budget" in params:
            t = topes(ficha)
            if float(params["daily_budget"]) > max(t["diario"], float(centavos(t["diario"]))):
                raise SinTope("daily_budget %s supera el diario autorizado (USD %.2f): primero el tope nuevo en la ficha."
                              % (params["daily_budget"], t["diario"]))
        motivo = MOTIVO_MCP if pausa else "conector meta-ads: %s con OK escrito; el gasto lo acota spend_cap y lo mide insights." % herramienta
    else:
        raise ErrorMeta("%s no es una escritura conocida del conector: las lecturas no se registran." % herramienta)
    sid = _registro.agregar_solicitud(ej, "api", "meta", clave=clave, estimado=0, gratuita=True, motivo_gratuita=motivo,
                                      parametros={"herramienta": herramienta, "params": params, "ok": ok,
                                                  "spend_cap_aparte": spend_cap_aparte, "verificacion": verificacion})
    if herramienta in MCP_CREAN:
        t = topes(ficha)
        _registro.registrar_consumo(ej, "meta", tope_autorizado=t["total"], unidad="USD", autorizacion_ref=t["autorizacion_ref"])
    _registro.marcar_enviando(ej, sid)
    return sid


def mcp_id(ej, sid, id_externo):
    _registro.guardar_id_externo(ej, sid, str(id_externo))
    _registro.cambiar_estado(ej, "completada", solicitud_id=sid)


def mcp_rechazo(ej, sid, error):
    _registro.marcar_rechazada(ej, sid, error)


# ---------------------------------------------------------------- CLI
def _cargar_plan(ruta):
    plan = leer_json(ruta)
    plan["_base"] = os.path.relpath(os.path.dirname(os.path.abspath(ruta)), RAIZ)
    return plan


def _cliente_real(ej=None):
    a = acceso()
    return Cliente(a["cuenta"], a["pagina"], TransporteHTTP(a["token"]), registro=ej, instagram=a["instagram"])


def main(argv=None):
    ap = argparse.ArgumentParser(description="Registro y topes del conector meta-ads; Graph API como alternativa (TAREA 032).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("claves")
    p = sub.add_parser("topes", help="topes de la ficha y valores a usar en la campaña")
    p.add_argument("plan_campana")
    p = sub.add_parser("mcp-inicio", help="registra y valida una escritura del conector meta-ads ANTES de llamarla")
    p.add_argument("plan_campana")
    p.add_argument("--ej", required=True)
    p.add_argument("--herramienta", required=True)
    p.add_argument("--clave", required=True)
    p.add_argument("--params", default="{}", help="JSON con los parámetros que se le pasan a la herramienta")
    p.add_argument("--ok")
    p.add_argument("--spend-cap-aparte")
    p.add_argument("--verificacion", help="JSON con los topes leídos del conector (obligatorio para activar)")
    p = sub.add_parser("mcp-id", help="guarda el id que devolvió el conector")
    p.add_argument("--ej", required=True)
    p.add_argument("--sol", required=True)
    p.add_argument("--id", required=True)
    p = sub.add_parser("mcp-rechazo", help="el conector respondió con error")
    p.add_argument("--ej", required=True)
    p.add_argument("--sol", required=True)
    p.add_argument("--error", required=True)
    p = sub.add_parser("veredicto", help="D92: ¿se apaga? (24 h sin ventas / 48 h con ingresos netos < gasto)")
    p.add_argument("--activada", required=True, help="ISO con zona, p. ej. 2026-10-23T00:00-03:00")
    p.add_argument("--ahora", help="ISO con zona (por defecto, ahora)")
    p.add_argument("--ventas", type=int, required=True)
    p.add_argument("--ingresos-netos", type=float, required=True)
    p.add_argument("--gasto", type=float, required=True)
    for n in ("plan", "crear", "insights", "estado", "vigilar"):
        p = sub.add_parser(n)
        p.add_argument("plan_campana")
        p.add_argument("--ej", help="registro.json de la ejecución (obligatorio para escribir)")
        if n == "insights":
            p.add_argument("--desde", required=True)
            p.add_argument("--hasta", required=True)
            p.add_argument("--csv", required=True)
        if n == "estado":
            p.add_argument("--objeto", required=True)
            p.add_argument("--a", required=True, choices=["ACTIVE", "PAUSED"])
            p.add_argument("--ok", help="cita del OK escrito del dueño (obligatorio para ACTIVE)")
    a = ap.parse_args(argv)
    if a.cmd == "veredicto":
        from datetime import datetime as _dt
        ahora = _dt.fromisoformat(a.ahora) if a.ahora else _dt.now().astimezone()
        print(json.dumps(veredicto_d92(_dt.fromisoformat(a.activada), ahora, a.ventas, a.ingresos_netos, a.gasto), ensure_ascii=False))
        return 0
    try:
        if a.cmd == "claves":
            for n, ok in estado_claves().items():
                print("  %-20s %s" % (n, "definida" if ok else "no definida"))
            return 0
        if a.cmd == "mcp-id":
            mcp_id(a.ej, a.sol, a.id)
            print("%s → %s" % (a.sol, a.id))
            return 0
        if a.cmd == "mcp-rechazo":
            mcp_rechazo(a.ej, a.sol, a.error)
            print("%s → fallida" % a.sol)
            return 0
        plan = _cargar_plan(a.plan_campana)
        ficha = ficha_del_plan(plan, a.plan_campana)
        if a.cmd == "topes":
            t = topes(ficha)
            print(json.dumps(dict(t, daily_budget_centavos=centavos(t["diario"]), spend_cap_centavos=centavos(t["total"])),
                             ensure_ascii=False))
            return 0
        if a.cmd == "mcp-inicio":
            print(mcp_inicio(a.ej, ficha, a.herramienta, a.clave, json.loads(a.params), ok=a.ok,
                             spend_cap_aparte=a.spend_cap_aparte,
                             verificacion=json.loads(a.verificacion) if a.verificacion else None))
            return 0
        if a.cmd == "plan":
            falso = TransporteFalso({("GET", "act_SIMULADA"): {"currency": "USD"}})
            cli = Cliente("act_SIMULADA", "PAGINA_SIMULADA", falso)
            errores = validar_plan(plan)
            try:
                t = topes(ficha)
            except SinTope as e:
                errores.append(str(e))
                t = None
            print("Topes: %s" % (t if t else "FALTAN"))
            print("Plan: %s" % ("completo" if not errores else "incompleto"))
            for e in errores:
                print("  - " + e)
            if t and not errores:
                crear_todo(plan, cli, ficha)
                for ll in falso.llamadas:
                    print("  %s %s %s" % (ll["metodo"], ll["ruta"].replace("act_SIMULADA", "act_…"),
                                          {k: v for k, v in ll["params"].items() if k in ("name", "status", "daily_budget", "spend_cap")}))
            print("Estado de acceso: " + ("listo" if all(estado_claves()[n] for n in OBLIGATORIAS) else "espera acceso"))
            return 0 if not errores else 1
        if a.cmd != "insights" and not a.ej:
            raise ErrorMeta("--ej registro.json es obligatorio para escribir en Meta (regla 4).")
        cli = _cliente_real(a.ej)
        if a.cmd == "crear":
            ids = crear_todo(plan, cli, ficha)
            print(json.dumps(ids, ensure_ascii=False, indent=1))
        elif a.cmd == "insights":
            filas = filas_csv(cli.insights(a.desde, a.hasta))
            escribir_csv(filas, a.csv)
            print("filas: %d → %s" % (len(filas), a.csv))
        elif a.cmd == "estado":
            cli.cambiar_estado(a.objeto, a.a, ok=a.ok, ficha=ficha, campana_id=plan["campana"].get("id"))
            print("%s → %s" % (a.objeto, a.a))
        elif a.cmd == "vigilar":
            print(json.dumps(vigilar(plan, cli, ficha), ensure_ascii=False))
        return 0
    except (SinAcceso, SinTope, SinOK) as e:
        print(str(e))
        return 3
    except ErrorMeta as e:
        print("ERROR: %s" % e)
        return 2


if __name__ == "__main__":
    sys.exit(main())
