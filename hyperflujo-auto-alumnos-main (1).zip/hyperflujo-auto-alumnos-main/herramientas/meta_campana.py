#!/usr/bin/env python3
"""meta_campana.py — etapa «campaña en pausa» con el esquema REAL del conector meta-ads (TAREA 037 parte B).

Decide el código, ejecuta el worker (CLAUDE.md regla 3):

  1. preparar(of)  [director, sin modelo]. Compuertas que fallan cerrado:
       D103  validar_anuncios vigente para el copy.json actual;
       D105  campana.presupuesto completo en la ficha (diario, días, autorizado_por, autorizacion_ref);
       techo la autorización `autorizacion_ref` existe en datos/autorizaciones.local.json, es «gasto_meta», está vigente,
             la firma quien firma la ficha y tiene `techo_usd` ≥ spend_cap (una autorización sin techo no vale);
       cuenta datos/cuentas.local.json: cuenta numérica, píxel y página; límite de gasto de la CUENTA fijado a mano por el
             dueño (D101, el conector no lo lee ni lo escribe) y que cubre la suma de los spend_cap de la cuenta → si falta,
             BloqueoHumano (bloqueada_humano con la acción exacta);
       D90   una campaña por cuenta (Matías, cash-trap-cbo-oro/SKILL.md:84-88) salvo autorización «campanas_compartidas»;
       topes globales cargados (datos/topes.local.json) y diario ≤ tope diario global.
     Salida: ofertas/OF-NNN/campana/llamadas.json con la lista ORDENADA de llamadas MCP y sus argumentos exactos
     (todo en pausa: el conector crea en PAUSED o en borrador; nunca ads_activate_entity) y la EJ con registro.py.
  2. El worker (skills/meta-campana-cashtrap) repite `siguiente` (registra la solicitud gratuita y la marca «enviando»)
     → UNA llamada al conector → `respuesta` (guardar_id_externo + externo.local.json) o `rechazo`. Después hace las
     lecturas de `relecturas` y las guarda en ofertas/OF-NNN/campana/relectura/<clave>.json.
  3. verificar_campana_en_pausa(of)  [director]: por artefacto (relectura), nunca por el texto del worker.

Esquema real (cargado del conector el 2026-10-22; nombres de parámetros, sin IDs):
  ads_create_campaign   ad_account_id (sin «act_»), campaign_name, objective=OUTCOME_SALES, buying_type=AUCTION,
                        campaign_daily_budget y campaign_spend_cap EN CENTAVOS (enteros), campaign_bid_strategy,
                        special_ad_categories (texto JSON "[]"). Sin parámetro de status: crea en PAUSED (o DRAFT).
  ads_create_ad_set     ad_account_id, campaign_id, ad_set_name, billing_event=IMPRESSIONS,
                        optimization_goal=OFFSITE_CONVERSIONS, destination_type=WEBSITE, promoted_object (texto JSON
                        {pixel_id, custom_event_type=PURCHASE}), targeting (texto JSON). Bajo CBO sin presupuesto propio.
  ads_creative_upload_media  ad_account_id, upload_source=URL, media_type=VIDEO, media_url, name → video_id.
  ads_create_creative   ad_account_id, page_id, name, link_url, message, headline, description,
                        call_to_action_type=LEARN_MORE (D100), image_url | video_id + image_url (miniatura) | cards,
                        self_ai_disclosure (OPT_IN/OPT_OUT: lo declara el dueño, nunca se infiere).
  ads_create_ad         ad_account_id, ad_set_id, ad_name, creative (texto JSON {"creative_id": …}). Sin status.
  ads_get_ad_entities   ad_account_id, level, object_ids, fields, object_state (live|draft). Lee montos como
                        {value, unit} en USD de texto (pruebas/fixtures/formato_real/meta_conector_campanas.json).
  ads_get_creatives     ad_account_id, creative_ids, fields (call_to_action_type, link_url…).
  Comunes: advertiser_job, client_conversation_id (20 caracteres, uno por preparación), hide_ui.
Solo biblioteca estándar. Sin red: este módulo nunca llama al conector.
"""
import argparse
import json
import math
import os
import re
import secrets
import string
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import autorizaciones as AU  # noqa: E402
import registro as R  # noqa: E402
import rutas  # noqa: E402
import topes as T  # noqa: E402
import validar_anuncios  # noqa: E402

CTA = "LEARN_MORE"                 # Hyperflujo D100
CTA_C3 = "SEE_DETAILS"             # Matías, 2026-10-22: C1/C2 «Más información», C3 «Ver detalles»; nunca «Comprar»


def cta_de(nivel):
    return CTA_C3 if str(nivel or "").upper() == "C3" else CTA
NIVELES = ("C1", "C2", "C3")       # 3/3/3 de Matías (cash-trap-cbo-oro)
ACTIVOS_POR_NIVEL = 3
RESERVAS_POR_NIVEL = 2             # 6 RES- (operador-meta-ads/SKILL.md:37-41, citado en reglas_operacion.json)
JOB = "create_and_launch_new_ads"
MOTIVO_GRATUITA = "creación en pausa, sin gasto (el conector crea en PAUSED o en borrador; activar es otra etapa)"
PREFIJO = "mcp__meta-ads__"
CREACION = ("ads_create_campaign", "ads_create_ad_set", "ads_creative_upload_media", "ads_create_creative", "ads_create_ad")
NO_ACTIVOS = {"PAUSED", "DRAFT", "CAMPAIGN_PAUSED", "ADSET_PAUSED", "IN_PROCESS", "PENDING_REVIEW", "PREAPPROVED"}
REGIONES = {"América del Norte": "north_america", "América Central": "central_america", "América del Sur": "south_america",
            "Caribe": "caribbean", "Europa": "europe", "Asia": "asia", "África": "africa", "Oceanía": "oceania"}
CLAVES_ID = {"ads_create_campaign": ("campaign_id", "id"), "ads_create_ad_set": ("ad_set_id", "adset_id", "id"),
             "ads_creative_upload_media": ("video_id", "id"), "ads_create_creative": ("creative_id", "id"),
             "ads_create_ad": ("ad_id", "id")}
GUARDAR = {"ads_create_campaign": "campana", "ads_create_ad_set": "conjunto", "ads_creative_upload_media": "medios",
           "ads_create_creative": "creativos", "ads_create_ad": "anuncios"}


class ErrorPlan(ValueError):
    """Falta un dato o la estructura no es la de Matías: no se arma nada (espera, se informa)."""


class ErrorTopes(RuntimeError):
    """Tope o autorización insuficiente: no se arma nada (espera, se informa)."""


class BloqueoHumano(RuntimeError):
    """Hace falta un paso humano (p. ej. el límite de gasto de la cuenta, D101): bloqueada_humano."""


class EnvioIncierto(RuntimeError):
    """Una llamada quedó «enviando» sin ID: bloquea solo este producto hasta conciliar por ID (regla 7)."""


# ------------------------------------------------------------------ rutas del producto
def _dir(of):
    return rutas.dir_oferta(of) / "campana"


def ruta_llamadas(of):
    return _dir(of) / "llamadas.json"


def ruta_relectura(of, clave):
    return _dir(of) / "relectura" / ("%s.json" % clave)


def ruta_verificacion(of):
    return _dir(of) / "verificacion.json"


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v > 0


def _centavos(usd):
    return int(round(usd * 100))


def _id_meta(v, que):
    s = str(v or "").strip()
    s = s[4:] if s.startswith("act_") else s
    if not re.fullmatch(r"\d+", s):
        raise BloqueoHumano("datos/cuentas.local.json: %s sin ID numérico (está «%s»): completarlo con /onboarding" % (que, v))
    return s


# ------------------------------------------------------------------ estado de la campaña de un producto
def estado_campana(of):
    """«ninguna» | «en_creacion» | «creada». Importada (sin llamadas.json) con campaña en externo = creada."""
    ext = (rutas.externo(of).get("meta") or {})
    p = ruta_llamadas(of)
    if p.exists():
        datos = rutas.leer_json(p)
        if any(x["estado"] != "hecha" for x in datos["llamadas"]):
            return "en_creacion"
        v = rutas.leer_json(ruta_verificacion(of), defecto={})
        return "creada" if v.get("ok") and v.get("sha_llamadas") == _sha_llamadas(datos) else "en_creacion"
    return "creada" if ext.get("campana") else "ninguna"


def campana_registrada(of):
    """Compuerta del orquestador: True = ya hay campaña completa y verificada (o importada) → se activa; False → crearla."""
    return estado_campana(of) == "creada"


# ------------------------------------------------------------------ compuertas
def _autorizacion(ref, of, fecha, spend_cap, firmante):
    try:
        datos = rutas.cargar_dato("autorizaciones")
    except rutas.FaltaDato as e:
        raise ErrorTopes(str(e))
    for a in datos.get("autorizaciones", []):
        if a.get("id") != ref:
            continue
        if a.get("alcance") != "gasto_meta" or not AU._valida(a, of, fecha):
            raise ErrorTopes("la autorización %s no es «gasto_meta» vigente para %s" % (ref, of))
        if a.get("firmante") != firmante:
            raise ErrorTopes("la autorización %s la firma «%s», no «%s» (autorizado_por de la ficha): igualdad exacta" %
                             (ref, a.get("firmante"), firmante))
        techo = a.get("techo_usd")
        if not _num(techo):
            raise ErrorTopes("la autorización %s no tiene techo_usd: una autorización sin techo no vale (CLAUDE.md regla 4)" % ref)
        if spend_cap > techo:
            raise ErrorTopes("spend_cap USD %s > techo de la autorización %s (USD %s)" % (spend_cap, ref, techo))
        return a
    raise ErrorTopes("autorizacion_ref «%s» no está en datos/autorizaciones.local.json" % ref)


def _cuenta(campana):
    try:
        datos = rutas.cargar_dato("cuentas")
    except rutas.FaltaDato as e:
        raise BloqueoHumano(str(e))
    cuentas = ((datos.get("meta") or {}).get("cuentas") or [])
    ref = campana.get("cuenta_ref")
    if ref:
        elegidas = [c for c in cuentas if c.get("ref") == ref]
    else:
        elegidas = cuentas if len(cuentas) == 1 else []
    if len(elegidas) != 1:
        raise ErrorPlan("la ficha no elige cuenta (campana.cuenta_ref) y hay %d en datos/cuentas.local.json" % len(cuentas))
    c = elegidas[0]
    pagina = campana.get("pagina_ref") or (datos.get("meta") or {}).get("pagina_defecto") or (c.get("paginas") or [None])[0]
    return c, {"cuenta": _id_meta(c.get("id"), "la cuenta publicitaria"), "pixel": _id_meta(c.get("pixel"), "el píxel"),
               "pagina": _id_meta(pagina, "la página"), "ref": c.get("ref"), "moneda": c.get("moneda")}


def _campanas_de_la_cuenta(cuenta_id, of):
    """Otros productos con campaña en la misma cuenta → [(of, spend_cap_usd o None)]."""
    out = []
    for d in sorted(rutas.ruta("ofertas").glob("OF-*")):
        if d.name == of or not rutas.RE_OF.match(d.name):
            continue
        m = (rutas.leer_json(d / "externo.local.json", defecto={}) or {}).get("meta") or {}
        if not m.get("campana") or str(m.get("cuenta") or "").replace("act_", "") != cuenta_id:
            continue
        # TAREA 040 (Director_H1): una campaña archivada o borrada en Meta no se puede editar ni gastar → no cuenta para el
        # límite de la cuenta ni para campanas_max. El estado lo escribe la relectura del conector en externo.meta.estado.
        if str(m.get("estado") or m.get("effective_status") or "").upper() in ("ARCHIVED", "DELETED"):
            continue
        pr = ((rutas.leer_json(d / "oferta.json", defecto={}) or {}).get("campana") or {}).get("presupuesto") or {}
        cap = pr["diario"] * pr["dias"] if _num(pr.get("diario")) and _num(pr.get("dias")) else None
        out.append((d.name, cap))
    return out


def _limite_cuenta(c, cuenta_id, of, spend_cap, compartidas):
    """D101: el límite de gasto de la cuenta lo fija el dueño a mano; el repo exige que esté declarado y que cubra."""
    otras = _campanas_de_la_cuenta(cuenta_id, of)
    maximo = c.get("campanas_max") or 1
    if len(otras) + 1 > maximo and not compartidas:
        raise ErrorPlan("la cuenta %s ya tiene campaña de %s; una campaña por cuenta (Matías, cash-trap-cbo-oro/SKILL.md:84-88) "
                        "salvo autorización «campanas_compartidas» (D90)" % (c.get("ref"), ", ".join(o for o, _ in otras)))
    lim = c.get("limite_gasto") or {}
    usd, quien = lim.get("usd"), str(lim.get("fijado_por") or "")
    if not _num(usd) or not quien or quien.startswith("<") or not lim.get("fecha"):
        raise BloqueoHumano("D101: fijar a mano el límite de gasto de la cuenta %s en el Administrador de anuncios "
                            "(Configuración de pagos → Límite de gasto de la cuenta) por al menos USD %s y declararlo en "
                            "datos/cuentas.local.json → meta.cuentas[].limite_gasto {usd, fijado_por, fecha}" %
                            (c.get("ref"), spend_cap + sum(x or 0 for _, x in otras)))
    if any(x is None for _, x in otras):
        raise ErrorTopes("no se conoce el spend_cap de otra campaña de la cuenta: falla cerrado")
    total = spend_cap + sum(x for _, x in otras)
    if total > usd:
        raise BloqueoHumano("D101: el límite de la cuenta %s (USD %s) no cubre los spend_cap de sus campañas (USD %s): "
                            "subirlo a mano y declararlo en datos/cuentas.local.json" % (c.get("ref"), usd, total))
    return {"usd": usd, "total_campanas": total, "fijado_por": quien, "fecha": lim.get("fecha")}


# ------------------------------------------------------------------ plan de Matías (plan_campana.py --estructura cash_trap_333)
def _plan(of, campana):
    if campana.get("plan"):
        p = rutas.dir_oferta(of) / campana["plan"]
    else:
        cands = sorted(_dir(of).glob("v*/plan_campana.json"))
        p = cands[-1] if cands else None
    if not p or not Path(p).exists():
        raise ErrorPlan("falta campana/<versión>/plan_campana.json (plan_campana.py --estructura cash_trap_333)")
    plan = rutas.leer_json(p)
    if plan.get("estructura") != "cash_trap_333":
        raise ErrorPlan("el plan no es cash_trap_333 (1 CBO → 1 Advantage+ → 9 anuncios 3/3/3 + 6 RES-)")
    return plan, Path(p)


def validar_estructura(anuncios):
    err = []
    act = [a for a in anuncios if not a.get("reserva")]
    res = [a for a in anuncios if a.get("reserva")]
    for n in NIVELES:
        if sum(1 for a in act if a.get("nivel") == n) != ACTIVOS_POR_NIVEL:
            err.append("nivel %s sin %d anuncios activos" % (n, ACTIVOS_POR_NIVEL))
        if sum(1 for a in res if a.get("nivel") == n) != RESERVAS_POR_NIVEL:
            err.append("nivel %s sin %d reservas RES-" % (n, RESERVAS_POR_NIVEL))
    for a in anuncios:
        nombre = a.get("anuncio_id") or ""
        if bool(a.get("reserva")) != nombre.startswith("RES-"):
            err.append("%s: las reservas y solo ellas llevan RES-" % nombre)
        if (a.get("cta") or CTA) not in (CTA, CTA_C3, "Más información", "Ver detalles"):
            err.append("%s: CTA %s; solo Más información o Ver detalles, nunca Comprar (D100, Matías 2026-10-22)" % (nombre, a.get("cta")))
        u = a.get("url_con_utm") or ""
        q = parse_qs(urlparse(u).query)
        if not u.startswith("https://") or "PENDIENTE" in u or q.get("utm_content") != [a.get("utm_content")]:
            err.append("%s: URL sin https o sin utm_content=%s" % (nombre, a.get("utm_content")))
        for k in ("texto_primario", "titulo"):
            if not a.get(k) or "PENDIENTE" in str(a.get(k)):
                err.append("%s: falta %s" % (nombre, k))
    return err


def _segmentacion(ficha):
    seg = dict(((ficha.get("campana") or {}).get("segmentacion") or {}))
    mercado = (ficha.get("mercado") or {}).get("id") or rutas.cargar_dato("config", defecto={}).get("mercado_defecto")
    m = ((rutas.cargar_dato("mercados", local=False).get(mercado or "") or {}).get("meta") or {})
    regiones = seg.get("regiones", m.get("regiones")) or []
    paises = seg.get("paises", m.get("paises_extra")) or []
    excluir = seg.get("excluir", m.get("excluir")) or []
    locales = seg.get("locales", m.get("locales"))
    if not (regiones or paises):
        raise ErrorPlan("sin regiones ni países para el mercado «%s» (datos/mercados.json o campana.segmentacion)" % mercado)
    if any(r not in REGIONES for r in regiones):
        raise ErrorPlan("región sin clave de Meta: %s" % [r for r in regiones if r not in REGIONES])
    if not isinstance(locales, list) or not locales or not all(isinstance(x, int) for x in locales):
        raise ErrorPlan("[PENDIENTE: claves numéricas de idioma de Meta para «%s» (F37)] en campana.segmentacion.locales o "
                        "datos/mercados.json → meta.locales; sin claves confirmadas no se crea" % mercado)
    geo = {}
    if regiones:
        geo["country_groups"] = [REGIONES[r] for r in regiones]
    if paises:
        geo["countries"] = list(paises)
    t = {"geo_locations": geo, "locales": locales}
    if excluir:
        t["excluded_geo_locations"] = {"countries": list(excluir)}
    return t, set(seg.get("locales_aceptados", m.get("locales_aceptados")) or [])


def _url_medio(base, archivo):
    if not archivo:
        return None
    if str(archivo).startswith("https://"):
        return archivo
    return base.rstrip("/") + "/" + os.path.basename(str(archivo))


def _director_vigente(of):
    """Matías, 2026-10-30: ningún anuncio se carga sin el aprobado del Director de Videos (`director_videos.py`). → (bool, motivo)."""
    import director_videos
    return director_videos.verificar_todos(str(rutas.dir_oferta(of) / "anuncios"))


# ------------------------------------------------------------------ preparar
def preparar(of, *, fecha=None, topes=None):
    """Arma (o reutiliza) llamadas.json. Lanza ErrorPlan / ErrorTopes (espera) o BloqueoHumano. Devuelve el dict."""
    fecha = fecha or rutas.hoy()
    p = ruta_llamadas(of)
    ext = rutas.externo(of).get("meta") or {}
    if ext.get("campana") and not p.exists():
        raise ErrorPlan("%s ya tiene campaña registrada: no se crea otra (conciliar por ID)" % of)
    ok, mot = validar_anuncios.validacion_vigente(of)
    if not ok:
        raise ErrorPlan("D103: " + mot)
    ok, mot = _director_vigente(of)
    if not ok:
        raise ErrorPlan(mot)
    ficha = rutas.ficha(of)
    campana = ficha.get("campana") or {}
    pr = campana.get("presupuesto") or {}
    if T.tope_ficha(ficha, "meta") is None or not pr.get("autorizacion_ref"):
        raise ErrorTopes("D105: la ficha de %s no tiene campana.presupuesto completo (diario, días, autorizado_por, autorizacion_ref)" % of)
    diario, dias = pr["diario"], pr["dias"]
    spend_cap = round(diario * dias, 2)
    topes = T.cargar() if topes is None else T.validar(topes)
    if diario > topes["tope_diario_global_usd"]:
        raise ErrorTopes("diario USD %s > tope diario global USD %s" % (diario, topes["tope_diario_global_usd"]))
    aut = _autorizacion(pr["autorizacion_ref"], of, fecha, spend_cap, pr.get("autorizado_por"))
    c, ids = _cuenta(campana)
    try:   # Matías 2026-10-25/27: el conjunto optimiza con el píxel del producto y su mercado (si falta y hay token, se crea)
        import pixel as PX
        import pixel_nuevo
        mercado = (ficha.get("mercado") or {}).get("id")
        pixel_nuevo.antes_de_armar(of, mercado, campana.get("cuenta_ref"))
        ids["pixel"] = _id_meta(PX.del_producto(of, mercado, campana.get("cuenta_ref")), "el píxel")
    except Exception:
        pass   # sin fila propia: queda el de la cuenta, como antes
    if (ids.get("moneda") or "USD") != "USD":
        raise ErrorPlan("la cuenta no es en USD: los topes del repo son en USD")
    compartidas = "campanas_compartidas" in AU.vigentes(of, fecha)
    limite = _limite_cuenta(c, ids["cuenta"], of, spend_cap, compartidas)
    if p.exists():   # compuertas releídas en cada corrida; las llamadas ya armadas se reutilizan (idempotente, una sola EJ)
        return rutas.leer_json(p)
    ia = campana.get("self_ai_disclosure")
    plan, ruta_plan = _plan(of, campana)
    anuncios = plan.get("anuncios") or []
    err = validar_estructura(anuncios)
    nombre = (plan.get("campana") or {}).get("nombre") or ""
    if not nombre or "PENDIENTE" in nombre:
        err.append("nombre de campaña sin fecha (regenerar el plan con --fecha)")
    base = ((rutas.externo(of).get("medios") or {}).get("base_url") or "")
    if not base.startswith("https://"):
        err.append("sin URL pública de medios (externo.local.json → medios.base_url): el conector solo toma URLs públicas")
    for a in anuncios:
        if (a.get("self_ai_disclosure") or ia) not in ("OPT_IN", "OPT_OUT"):
            err.append("%s: [PENDIENTE: declaración de IA del dueño (campana.self_ai_disclosure OPT_IN/OPT_OUT); no se infiere]"
                       % a.get("anuncio_id"))
            break
    if err:
        raise ErrorPlan("; ".join(err))
    targeting, aceptados = _segmentacion(ficha)
    comunes = {"ad_account_id": ids["cuenta"], "advertiser_job": JOB,
               "client_conversation_id": "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(20))}
    llamadas = [_llamada("campana", "ads_create_campaign", dict(
        comunes, campaign_name=nombre, objective="OUTCOME_SALES", buying_type="AUCTION",
        campaign_daily_budget=_centavos(diario), campaign_spend_cap=_centavos(spend_cap),
        campaign_bid_strategy="LOWEST_COST_WITHOUT_CAP", special_ad_categories="[]", hide_ui=True))]
    conjunto = (plan.get("conjunto") or {}).get("nombre") or nombre + "_ADV"
    llamadas.append(_llamada("conjunto", "ads_create_ad_set", dict(
        comunes, campaign_id="{{campana}}", ad_set_name=conjunto, billing_event="IMPRESSIONS",
        optimization_goal="OFFSITE_CONVERSIONS", destination_type="WEBSITE",
        promoted_object=json.dumps({"pixel_id": ids["pixel"], "custom_event_type": "PURCHASE"}),
        targeting=json.dumps(targeting, ensure_ascii=False), hide_ui=True)))
    for a in anuncios:
        n = a["anuncio_id"]
        arch = a.get("archivos") or {}
        cre = dict(comunes, page_id=ids["pagina"], name=n, link_url=a["url_con_utm"], message=a["texto_primario"],
                   headline=a["titulo"], call_to_action_type=cta_de(a.get("nivel")), self_ai_disclosure=a.get("self_ai_disclosure") or ia)   # sin hide_ui: no está en el esquema
        if a.get("descripcion"):
            cre["description"] = a["descripcion"]
        videos = [v for v in arch.values() if str(v or "").lower().endswith((".mp4", ".mov"))]
        if a.get("laminas"):
            cre["cards"] = [{"image_url": _url_medio(base, l["archivo"]), "link": a["url_con_utm"],
                             **({"headline": l["titulo"]} if l.get("titulo") else {}),
                             **({"description": l["descripcion"]} if l.get("descripcion") else {})} for l in a["laminas"]]
        elif videos:
            mini = a.get("miniatura") or arch.get("miniatura")
            if not mini:
                raise ErrorPlan("%s: video sin miniatura (el conector exige image_url de portada)" % n)
            llamadas.append(_llamada("medio:%s" % n, "ads_creative_upload_media", dict(
                comunes, upload_source="URL", media_type="VIDEO", media_url=_url_medio(base, videos[0]), name=n)))
            cre.update(video_id="{{medio:%s}}" % n, image_url=_url_medio(base, mini))
        else:
            imagenes = [v for v in arch.values() if v]
            if not imagenes:
                raise ErrorPlan("%s sin archivo de imagen" % n)
            cre["image_url"] = _url_medio(base, imagenes[0])
        llamadas.append(_llamada("creativo:%s" % n, "ads_create_creative", cre))
        llamadas.append(_llamada("anuncio:%s" % n, "ads_create_ad", dict(
            comunes, ad_set_id="{{conjunto}}", ad_name=n, creative=json.dumps({"creative_id": "{{creativo:%s}}" % n}), hide_ui=True)))
    for i, x in enumerate(llamadas, 1):
        x["n"] = i
    ej = _crear_ejecucion(of, ficha)
    datos = {"of": of, "generado_en": rutas.ahora().isoformat(timespec="seconds"), "regla": "TAREA 037 B; D91, D98–D101, D103, D105",
             "plan": os.path.relpath(ruta_plan, rutas.RAIZ).replace("\\", "/"), "ej": ej["ej"], "registro": ej["registro"],
             "cuenta_ref": ids["ref"], "diario_usd": diario, "dias": dias, "spend_cap_usd": spend_cap,
             "autorizacion": aut["id"], "techo_usd": aut["techo_usd"], "limite_cuenta": limite,
             "locales": targeting["locales"], "locales_aceptados": sorted(aceptados),
             "campana_nombre": nombre, "anuncios": [{"nombre": a["anuncio_id"], "nivel": a["nivel"], "reserva": bool(a.get("reserva")),
                                                      "utm_content": a["utm_content"]} for a in anuncios],
             "llamadas": llamadas}
    rutas.escribir_json(p, datos)
    rutas.guardar_externo(of, meta={"cuenta": ids["cuenta"]})
    return datos


def _llamada(clave, herramienta, args):
    return {"n": None, "clave": clave, "herramienta": PREFIJO + herramienta, "args": args, "estado": "pendiente",
            "id": None, "sid": None, "intentos": 0, "error": None}


def _crear_ejecucion(of, ficha):
    carpeta = rutas.dir_oferta(of) / "ejecuciones"
    n = max([int(m.group(1)) for d in carpeta.glob("EJ-*") for m in [re.fullmatch(r"EJ-(\d+)", d.name)] if m] + [0]) + 1
    ej = "EJ-%03d" % n
    ruta = carpeta / ej / "registro.json"
    rutas.escribir_json(carpeta / ej / "entradas" / "oferta.json", ficha)
    R.crear_ejecucion(str(ruta), of, ej, "campana_meta", "worker meta-campana-cashtrap (director: meta_campana.preparar)",
                      receta="recetas/campana/RECETA.md", ficha="entradas/oferta.json")
    return {"ej": ej, "registro": os.path.relpath(ruta, rutas.RAIZ).replace("\\", "/")}


def _sha_llamadas(datos):
    import hashlib
    return hashlib.sha256(json.dumps(datos["llamadas"], sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


# ------------------------------------------------------------------ ejecución paso a paso (la hace el worker)
def _cargar(of):
    p = ruta_llamadas(of)
    if not p.exists():
        raise ErrorPlan("sin llamadas.json: lo arma el director con meta_campana.preparar")
    return rutas.leer_json(p)


def _ids(datos):
    return {x["clave"]: x["id"] for x in datos["llamadas"] if x.get("id")}


def resolver(args, ids):
    texto = json.dumps(args, ensure_ascii=False)
    for k in re.findall(r"\{\{([^}]+)\}\}", texto):
        if k not in ids:
            raise ErrorPlan("la llamada depende de «%s», que todavía no tiene ID" % k)
        texto = texto.replace("{{%s}}" % k, ids[k])
    return json.loads(texto)


def maximos_pendientes(of):
    """Para los tickets del plan del día: cuántas llamadas faltan por herramienta (max_llamadas acotado)."""
    out = {}
    for x in _cargar(of)["llamadas"]:
        if x["estado"] != "hecha":
            out[x["herramienta"]] = out.get(x["herramienta"], 0) + 1
    return out


def siguiente(of):
    """Próxima llamada con los IDs resueltos; la registra (gratuita) y la marca «enviando» ANTES de devolverla.
    → {"fin": True} | {"fin": False, "clave", "herramienta", "args"}. EnvioIncierto si hay una «enviando» sin ID."""
    datos = _cargar(of)
    reg = str(rutas.RAIZ / datos["registro"])
    enviando = [x for x in datos["llamadas"] if x["estado"] == "enviando"]
    if enviando:
        raise EnvioIncierto("«%s» quedó enviando sin ID: conciliar por ID en el panel del proveedor (regla 7) antes de seguir"
                            % enviando[0]["clave"])
    pend = [x for x in datos["llamadas"] if x["estado"] in ("pendiente", "rechazada")]
    if not pend:
        return {"fin": True, "llamadas": len(datos["llamadas"])}
    x = pend[0]
    args = resolver(x["args"], _ids(datos))
    sid = R.agregar_solicitud(reg, "api", "meta", clave=x["clave"], estimado=0, gratuita=True, motivo_gratuita=MOTIVO_GRATUITA,
                              parametros={"herramienta": x["herramienta"], "params": args})
    R.marcar_enviando(reg, sid)   # si lanza, no se devuelve la llamada: no se envía
    x.update(estado="enviando", sid=sid, intentos=x["intentos"] + 1)
    rutas.escribir_json(ruta_llamadas(of), datos)
    return {"fin": False, "n": x["n"], "de": len(datos["llamadas"]), "clave": x["clave"], "herramienta": x["herramienta"], "args": args}


def extraer_id(herramienta, respuesta):
    """ID de la respuesta del conector (dict o texto JSON), buscando las claves propias de cada herramienta."""
    if isinstance(respuesta, str):
        try:
            respuesta = json.loads(respuesta)
        except ValueError:
            return None
    corto = herramienta.replace(PREFIJO, "")
    for clave in CLAVES_ID.get(corto, ("id",)):
        encontrado = _buscar(respuesta, clave)
        if encontrado:
            return encontrado
    return None


def _buscar(x, clave):
    if isinstance(x, dict):
        v = x.get(clave)
        if isinstance(v, (str, int)) and not isinstance(v, bool) and re.fullmatch(r"\d+", str(v)):
            return str(v)
        for w in x.values():
            r = _buscar(w, clave)
            if r:
                return r
    elif isinstance(x, list):
        for w in x:
            r = _buscar(w, clave)
            if r:
                return r
    elif isinstance(x, str) and x.strip().startswith(("{", "[")):
        try:
            return _buscar(json.loads(x), clave)
        except ValueError:
            return None
    return None


def _status(x):
    for k in ("status", "effective_status", "configured_status"):
        v = _buscar_txt(x, k)
        if v:
            return v
    return None


def _buscar_txt(x, clave):
    if isinstance(x, dict):
        if isinstance(x.get(clave), str):
            return x[clave]
        for w in x.values():
            r = _buscar_txt(w, clave)
            if r:
                return r
    elif isinstance(x, list):
        for w in x:
            r = _buscar_txt(w, clave)
            if r:
                return r
    return None


def respuesta(of, clave, *, resp=None, id_externo=None):
    """Guarda el ID apenas se recibe (registro + externo.local.json). Una respuesta ACTIVE es un error grave."""
    datos = _cargar(of)
    x = next((y for y in datos["llamadas"] if y["clave"] == clave), None)
    if x is None or x["estado"] != "enviando":
        raise ErrorPlan("«%s» no está enviando" % clave)
    st = str(_status(resp) or "").upper() if resp is not None else ""
    id_externo = id_externo or extraer_id(x["herramienta"], resp)
    if not id_externo:
        raise ErrorPlan("la respuesta no trae ID de %s: si el conector rechazó, usar «rechazo»; si no se sabe, es envío incierto"
                        % x["herramienta"])
    R.guardar_id_externo(str(rutas.RAIZ / datos["registro"]), x["sid"], id_externo)
    x.update(estado="hecha", id=id_externo, status=st or None)
    rutas.escribir_json(ruta_llamadas(of), datos)
    corto = x["herramienta"].replace(PREFIJO, "")
    destino = GUARDAR[corto]
    if destino in ("campana", "conjunto"):
        rutas.guardar_externo(of, meta={destino: id_externo})
    else:
        nombre = clave.split(":", 1)[1]
        actual = (rutas.externo(of).get("meta") or {}).get(destino) or {}
        rutas.guardar_externo(of, meta={destino: {**actual, nombre: id_externo}})
    if st == "ACTIVE":
        raise ErrorPlan("«%s» volvió ACTIVE: nada se activa en esta etapa; pausar y avisar" % clave)
    return {"clave": clave, "id": id_externo, "status": st or None}


def rechazo(of, clave, error):
    datos = _cargar(of)
    x = next((y for y in datos["llamadas"] if y["clave"] == clave), None)
    if x is None or x["estado"] != "enviando":
        raise ErrorPlan("«%s» no está enviando" % clave)
    R.marcar_rechazada(str(rutas.RAIZ / datos["registro"]), x["sid"], error)
    x.update(estado="rechazada", error=str(error)[:500], sid=None)
    rutas.escribir_json(ruta_llamadas(of), datos)
    return {"clave": clave, "estado": "rechazada"}


def relecturas(of):
    """Lecturas gratuitas que el worker hace al final y guarda en campana/relectura/<clave>.json."""
    datos = _cargar(of)
    ids = _ids(datos)
    cuenta = datos["llamadas"][0]["args"]["ad_account_id"]
    anuncios = [ids["anuncio:%s" % a["nombre"]] for a in datos["anuncios"] if "anuncio:%s" % a["nombre"] in ids]
    creativos = [ids["creativo:%s" % a["nombre"]] for a in datos["anuncios"] if "creativo:%s" % a["nombre"] in ids]
    base = {"ad_account_id": cuenta, "advertiser_job": JOB, "client_conversation_id": datos["llamadas"][0]["args"]["client_conversation_id"]}
    lect = [
        ("campana", "ads_get_ad_entities", dict(base, level="campaign", object_ids=[ids.get("campana")],
                                                fields=["id", "name", "status", "effective_status", "daily_budget", "spend_cap"])),
        ("conjunto", "ads_get_ad_entities", dict(base, level="adset", object_ids=[ids.get("conjunto")],
                                                 fields=["id", "name", "status", "effective_status", "targeting", "optimization_goal",
                                                         "promoted_object"])),
        ("anuncios", "ads_get_ad_entities", dict(base, level="ad", object_ids=anuncios,
                                                 fields=["id", "name", "status", "effective_status", "creative_id"])),
        ("creativos", "ads_get_creatives", dict(base, creative_ids=creativos,
                                                fields=["id", "name", "status", "call_to_action_type", "link_url", "child_attachments"]))]
    return [{"clave": k, "herramienta": PREFIJO + h, "args": a, "archivo": os.path.relpath(ruta_relectura(of, k), rutas.RAIZ).replace("\\", "/"),
             "nota": "si object_state=live no devuelve el objeto (conector en modo borrador), repetir con object_state=draft y guardar esa"}
            for k, h, a in lect]


# ------------------------------------------------------------------ verificación por artefacto
def _entidades(resp):
    """Lista de objetos de una lectura guardada: ad_entities (texto JSON o lista), ad_drafts, data o lista suelta."""
    if isinstance(resp, str):
        resp = json.loads(resp)
    if isinstance(resp, list):
        return resp
    for k in ("ad_entities", "ad_drafts", "ad_creatives", "creatives", "data", "result"):   # 037 D: ads_get_creatives devuelve «ad_creatives»
        v = resp.get(k)
        if isinstance(v, str):
            v = json.loads(v)
        if isinstance(v, list):
            return v
        if isinstance(v, dict):
            return _entidades(v)
    return []


def _ident(e):
    return str(e.get("id") or e.get("ad_object_id") or "")


def _usd(v, fuente):
    """Monto releído → USD. Conector: {value, unit:"USD"} o texto en USD; Graph: centavos en texto (F37)."""
    if isinstance(v, dict):
        if (v.get("unit") or "USD") != "USD":
            return None
        v = v.get("value")
    try:
        x = float(str(v))
    except (TypeError, ValueError):
        return None
    return x / 100 if fuente == "graph" else x


def verificar_campana_en_pausa(of):
    """(ok, motivo) leyendo SOLO artefactos: llamadas.json completo y las relecturas guardadas. Escribe verificacion.json."""
    try:
        datos = _cargar(of)
    except ErrorPlan as e:
        return False, str(e)
    errores = []
    pend = [x["clave"] for x in datos["llamadas"] if x["estado"] != "hecha"]
    if pend:
        errores.append("faltan %d llamada(s) por crear (%s…)" % (len(pend), pend[0]))
    ids = _ids(datos)
    lect = {}
    for k in ("campana", "conjunto", "anuncios", "creativos"):
        p = ruta_relectura(of, k)
        if not p.exists():
            errores.append("falta la relectura «%s» (campana/relectura/%s.json)" % (k, k))
            continue
        try:
            crudo = rutas.leer_json(p)
            lect[k] = (_entidades(crudo), crudo.get("_fuente") if isinstance(crudo, dict) else None)
        except (ValueError, AttributeError) as e:
            errores.append("relectura «%s» ilegible: %s" % (k, e))
    if not errores:
        errores += _comparar(datos, ids, lect)
    ok = not errores
    rutas.escribir_json(ruta_verificacion(of), {"ok": ok, "errores": errores, "fecha": rutas.ahora().isoformat(timespec="seconds"),
                                                "sha_llamadas": _sha_llamadas(datos), "regla": "CLAUDE.md regla 7 (verificar por artefacto)"})
    return ok, ("campaña, conjunto y %d anuncios en pausa, releídos" % len(datos["anuncios"]) if ok else "; ".join(errores[:4]))


def _comparar(datos, ids, lect):
    err = []
    def activo(e):
        return any(str(e.get(k) or "").upper() == "ACTIVE" for k in ("status", "effective_status", "configured_status"))
    camp = [e for e in lect["campana"][0] if _ident(e) == ids.get("campana")]
    if len(camp) != 1:
        err.append("la relectura no trae la campaña creada")
    else:
        c, fuente = camp[0], lect["campana"][1]
        if activo(c):
            err.append("la campaña está ACTIVE: nada se activa en esta etapa")
        if str(c.get("status") or "").upper() not in NO_ACTIVOS:
            err.append("status de campaña desconocido: %s" % c.get("status"))
        d, s = _usd(c.get("daily_budget"), fuente), _usd(c.get("spend_cap"), fuente)
        if d is None or abs(d - datos["diario_usd"]) > 0.005:
            err.append("daily_budget releído %s ≠ diario de la ficha USD %s" % (c.get("daily_budget"), datos["diario_usd"]))
        if s is None or abs(s - datos["spend_cap_usd"]) > 0.005:
            err.append("spend_cap releído %s ≠ USD %s (diario × días)" % (c.get("spend_cap"), datos["spend_cap_usd"]))
    cj = [e for e in lect["conjunto"][0] if _ident(e) == ids.get("conjunto")]
    if len(cj) != 1:
        err.append("la relectura no trae el conjunto creado")
    else:
        if activo(cj[0]):
            err.append("el conjunto está ACTIVE")
        t = cj[0].get("targeting")
        t = json.loads(t) if isinstance(t, str) else (t or {})
        leidos = set(t.get("locales") or [])
        pedidos = set(datos["locales"]) | set(datos.get("locales_aceptados") or [])
        if not leidos or not leidos <= pedidos:
            err.append("F37: locales releídos %s ≠ pedidos %s: corregir y releer; no se activa" % (sorted(leidos), datos["locales"]))
    por_id = {_ident(e): e for e in lect["anuncios"][0]}
    esperados = {a["nombre"]: ids.get("anuncio:%s" % a["nombre"]) for a in datos["anuncios"]}
    faltan = [n for n, i in esperados.items() if not i or i not in por_id]
    if faltan:
        err.append("anuncios sin relectura: %d (%s…)" % (len(faltan), faltan[0]))
    if any(activo(por_id[i]) for i in esperados.values() if i in por_id):
        err.append("hay anuncios ACTIVE")
    activos = [a for a in datos["anuncios"] if not a["reserva"]]
    if len(activos) != 9 or len(datos["anuncios"]) - len(activos) != 6:
        err.append("estructura distinta de 9 + 6 RES-")
    cre = {_ident(e): e for e in lect["creativos"][0]}
    for a in datos["anuncios"]:
        e = cre.get(ids.get("creativo:%s" % a["nombre"]) or "")
        if e is None:
            err.append("creativo de %s sin relectura" % a["nombre"])
            continue
        cta = e.get("call_to_action_type") or ((e.get("call_to_action") or {}).get("type") if isinstance(e.get("call_to_action"), dict) else None)
        if cta != cta_de(a.get("nivel")):
            err.append("%s: CTA releído %s (LEARN_MORE en C1/C2, SEE_DETAILS en C3: D100, Matías 2026-10-22)" % (a["nombre"], cta))
        link = e.get("link_url") or next((c.get("link") for c in (e.get("child_attachments") or []) if isinstance(c, dict)), None)
        q = parse_qs(urlparse(str(link or "")).query)
        if q.get("utm_content") != [a["utm_content"]] or q.get("utm_campaign") != [datos["campana_nombre"]]:
            err.append("%s: link releído sin utm_content/utm_campaign correctos" % a["nombre"])
    return err


# ------------------------------------------------------------------ CLI (contrato PLAN §0.4: la última línea es JSON)
def main(argv=None):
    ap = argparse.ArgumentParser(description="Campaña Cash Trap en pausa por el conector meta-ads (esquema real). Sin red.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for c in ("preparar", "siguiente", "relecturas", "verificar", "estado"):
        sub.add_parser(c).add_argument("--of", required=True)
    s = sub.add_parser("respuesta")
    s.add_argument("--of", required=True)
    s.add_argument("--clave", required=True)
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--archivo", help="respuesta del conector guardada en ofertas/OF-NNN/campana/respuestas/")
    g.add_argument("--id")
    s = sub.add_parser("rechazo")
    s.add_argument("--of", required=True)
    s.add_argument("--clave", required=True)
    s.add_argument("--error", required=True)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "preparar":
            d = preparar(a.of)
            r = {"ok": True, "codigo": 0, "motivo": "%d llamadas, todo en pausa" % len(d["llamadas"]),
                 "artefactos": [os.path.relpath(ruta_llamadas(a.of), rutas.RAIZ).replace("\\", "/")]}
        elif a.cmd == "siguiente":
            r = {"ok": True, "codigo": 0, **siguiente(a.of)}
        elif a.cmd == "respuesta":
            resp = rutas.leer_json(a.archivo) if a.archivo else None
            r = {"ok": True, "codigo": 0, **respuesta(a.of, a.clave, resp=resp, id_externo=a.id)}
        elif a.cmd == "rechazo":
            r = {"ok": True, "codigo": 0, **rechazo(a.of, a.clave, a.error)}
        elif a.cmd == "relecturas":
            r = {"ok": True, "codigo": 0, "lecturas": relecturas(a.of)}
        elif a.cmd == "verificar":
            ok, mot = verificar_campana_en_pausa(a.of)
            r = {"ok": ok, "codigo": 0 if ok else 2, "motivo": mot}
        else:
            r = {"ok": True, "codigo": 0, "estado": estado_campana(a.of)}
    except EnvioIncierto as e:
        r = {"ok": False, "codigo": 5, "motivo": str(e)}
    except BloqueoHumano as e:
        r = {"ok": False, "codigo": 3, "motivo": str(e)}
    except (ErrorPlan, ErrorTopes, T.TopesFaltantes, R.ErrorRegistro, rutas.FaltaDato) as e:
        r = {"ok": False, "codigo": 2, "motivo": "%s: %s" % (type(e).__name__, e)}
    print(json.dumps(r, ensure_ascii=False))
    return r["codigo"]


if __name__ == "__main__":
    sys.exit(main())
