#!/usr/bin/env python3
"""meta_lector.py — lectura real de Meta: insights por anuncio y día + effective_status (TAREA 036 parte B).

    python herramientas/meta_lector.py --of OF-001 --desde 2026-10-20 --hasta 2026-10-21
    python herramientas/meta_lector.py --of OF-001 --archivo estado/lecturas/meta_OF-001_2026-10-21.json

Dos fuentes, misma salida normalizada:
  * Graph API con el token del usuario del sistema (META_SYSTEM_USER_TOKEN o META_ACCESS_TOKEN en .env): el vigía lee
    sin modelo (ARQUITECTURA §8.4). GET <campaña>/insights (level=ad, time_increment=1) y GET <campaña>/ads
    (effective_status, ad_review_feedback). Montos de Graph: spend en USD como texto; presupuestos en centavos.
  * Conector oficial meta-ads (OAuth): solo existe dentro de una sesión de Claude, así que un worker llama
    mcp__meta-ads__ads_get_ad_entities y guarda la respuesta tal cual en estado/lecturas/; este módulo la parsea.
    Formato fijado con respuestas reales grabadas (pruebas/fixtures/formato_real/): amount_spent = {value: "0.93",
    unit: "USD"}, daily_budget y spend_cap en USD (no centavos), métricas null cuando no hay dato.
Reglas: una lectura que falla devuelve None (nulo ≠ 0). Un gasto ausente en una fila es None, nunca 0. Las compras del
píxel son solo una señal; el ROAS se decide con netos de Hotmart. Nunca se imprime el token.
Solo biblioteca estándar.
"""
import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

RECHAZOS = ("DISAPPROVED", "WITH_ISSUES")
EN_REVISION = ("PENDING_REVIEW", "IN_PROCESS")
TIPOS_COMPRA_GRAPH = ("offsite_conversion.fb_pixel_purchase", "purchase", "omni_purchase")
CAMPOS_INSIGHTS = "ad_id,ad_name,adset_id,campaign_id,spend,impressions,inline_link_clicks,actions,date_start,date_stop"
CAMPOS_ANUNCIOS = "id,name,status,effective_status,ad_review_feedback,adset_id,campaign_id"


class LecturaFallida(RuntimeError):
    pass


# ------------------------------------------------------------------ números
def _num(v):
    """'0.93' | 0.93 | {'value': '0.93', 'unit': 'USD'} → 0.93; None/'' → None. Nunca inventa un 0."""
    if isinstance(v, dict):
        v = v.get("value")
    if v is None or v == "" or isinstance(v, bool):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _entero(v):
    n = _num(v)
    return None if n is None else int(round(n))


def _accion(acciones, tipos=TIPOS_COMPRA_GRAPH):
    """Primer tipo de compra presente (sin sumar variantes: evita contar dos veces la misma compra). Sin lista = None."""
    if acciones is None:
        return None
    for t in tipos:
        for a in acciones:
            if a.get("action_type") == t:
                return _entero(a.get("value"))
    return 0


# ------------------------------------------------------------------ parsers
def _lista(respuesta, clave="ad_entities"):
    if isinstance(respuesta, list):
        return respuesta
    if isinstance(respuesta, dict):
        v = respuesta.get(clave, respuesta.get("data"))
        if isinstance(v, str):
            v = json.loads(v)
        if isinstance(v, list):
            return v
    raise LecturaFallida("respuesta de Meta sin lista de entidades")


def parse_conector(respuesta):
    """Respuesta de ads_get_ad_entities (nivel anuncio o campaña) → filas normalizadas."""
    filas = []
    for x in _lista(respuesta):
        filas.append({"fecha": x.get("date_start"), "id": x.get("id"), "nombre": x.get("name"),
                      "campana_id": x.get("campaign_id"), "conjunto_id": x.get("adset_id"),
                      "gasto": _num(x.get("amount_spent")), "impresiones": _entero(x.get("impressions")),
                      "clics": _entero(x.get("link_click")), "compras_pixel": _entero(x.get("omni_purchase")),
                      "effective_status": x.get("effective_status"), "status": x.get("status"),
                      "diario": _num(x.get("daily_budget")), "spend_cap": _num(x.get("spend_cap")), "fuente": "conector"})
    return filas


def parse_graph(insights, anuncios=None):
    """Insights de Graph (level=ad, time_increment=1) + lista de anuncios (effective_status) → filas normalizadas."""
    estados = {a.get("id"): a for a in (anuncios or [])}
    filas = []
    for x in _lista(insights):
        a = estados.get(x.get("ad_id"), {})
        filas.append({"fecha": x.get("date_start"), "id": x.get("ad_id"), "nombre": x.get("ad_name"),
                      "campana_id": x.get("campaign_id"), "conjunto_id": x.get("adset_id"),
                      "gasto": _num(x.get("spend")), "impresiones": _entero(x.get("impressions")),
                      "clics": _entero(x.get("inline_link_clicks")), "compras_pixel": _accion(x.get("actions")),
                      "effective_status": a.get("effective_status"), "status": a.get("status"),
                      "revision": a.get("ad_review_feedback"), "fuente": "graph"})
    vistos = {f["id"] for f in filas}
    for a in anuncios or []:   # anuncios sin entrega en el rango: no tienen fila de insights pero sí estado
        if a.get("id") not in vistos:
            filas.append({"fecha": None, "id": a.get("id"), "nombre": a.get("name"), "gasto": None,
                          "effective_status": a.get("effective_status"), "status": a.get("status"),
                          "revision": a.get("ad_review_feedback"), "fuente": "graph"})
    return filas


def resumir(filas):
    """Gasto por día (None si alguna fila del día no trae gasto), anuncios rechazados y en revisión, estados por anuncio."""
    por_dia = {}
    for f in filas:
        if f.get("fecha") is None:
            continue
        g = f.get("gasto")
        if f["fecha"] not in por_dia:
            por_dia[f["fecha"]] = 0.0
        por_dia[f["fecha"]] = None if (g is None or por_dia[f["fecha"]] is None) else round(por_dia[f["fecha"]] + g, 2)
    estados = {}
    for f in filas:
        if f.get("id") and f.get("effective_status"):
            estados[f["id"]] = f["effective_status"]
    return {"gasto_por_dia": por_dia,
            "rechazados": sorted(i for i, s in estados.items() if s in RECHAZOS),
            "en_revision": sorted(i for i, s in estados.items() if s in EN_REVISION),
            "estados": estados, "filas": filas}


# ------------------------------------------------------------------ lectores
class LectorGraph:
    """Graph API con token del usuario del sistema (rol EMPLEADO). `transporte(metodo, ruta, params)` es inyectable."""

    def __init__(self, transporte):
        self.t = transporte

    def _todas(self, ruta, params):
        datos, r = [], self.t("GET", ruta, params)
        while True:
            datos += r.get("data", [])
            sig = (r.get("paging") or {}).get("next")
            if not sig:
                return datos
            r = self.t("GET", sig, None)

    def leer(self, campana_id, desde, hasta):
        ins = self._todas("%s/insights" % campana_id, {"level": "ad", "time_increment": 1, "fields": CAMPOS_INSIGHTS,
                                                       "time_range": json.dumps({"since": desde, "until": hasta}), "limit": 500})
        ads = self._todas("%s/ads" % campana_id, {"fields": CAMPOS_ANUNCIOS, "limit": 500})
        return parse_graph({"data": ins}, ads)


class LectorArchivo:
    """Respuesta del conector guardada por un worker (estado/lecturas/…json)."""

    def __init__(self, ruta):
        self.ruta = ruta

    def leer(self, campana_id=None, desde=None, hasta=None):
        filas = parse_conector(json.loads(Path(self.ruta).read_text(encoding="utf-8")))
        return [f for f in filas if (campana_id is None or f.get("campana_id") in (campana_id, None))
                and (desde is None or f.get("fecha") is None or desde <= f["fecha"] <= (hasta or f["fecha"]))]


def token_disponible():
    try:
        import claves
        return any(claves.estado().get(n) for n in ("META_SYSTEM_USER_TOKEN", "META_ACCESS_TOKEN")) or \
            bool(os.environ.get("META_SYSTEM_USER_TOKEN"))
    except Exception:
        return False


def lector_por_defecto(of, fecha=None):
    """Graph si hay token; si no, la última lectura del conector guardada por un worker hoy; si no, None."""
    if token_disponible():
        import claves
        import meta_ads
        try:
            token = os.environ.get("META_SYSTEM_USER_TOKEN") or claves.clave("META_SYSTEM_USER_TOKEN")
        except Exception:
            token = claves.clave("META_ACCESS_TOKEN")
        return LectorGraph(meta_ads.TransporteHTTP(token))
    p = rutas.ruta("estado", "lecturas", "meta_%s_%s.json" % (of, fecha or rutas.hoy()))
    return LectorArchivo(p) if p.exists() else None


def campana_de(of):
    return ((rutas.externo(of).get("meta") or {}).get("campana")) or None


def leer(of, desde, hasta, lector=None):
    """Resumen normalizado o None si no se pudo leer (nulo ≠ 0)."""
    lector = lector or lector_por_defecto(of, hasta)
    camp = campana_de(of)
    if lector is None or camp is None:
        return None
    try:
        return resumir(lector.leer(camp, desde, hasta))
    except Exception:
        return None


def gasto_hoy(of, lector=None, fecha=None):
    fecha = fecha or rutas.hoy()
    r = leer(of, fecha, fecha, lector)
    if r is None:
        return None
    return r["gasto_por_dia"].get(fecha, 0.0 if r["filas"] else None)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Lee insights por anuncio/día y effective_status de la campaña de un producto.")
    ap.add_argument("--of", required=True)
    ap.add_argument("--desde")
    ap.add_argument("--hasta")
    ap.add_argument("--archivo", help="respuesta del conector guardada por un worker")
    a = ap.parse_args()
    hoy = rutas.hoy()
    lec = LectorArchivo(a.archivo) if a.archivo else None
    r = leer(rutas.validar_of(a.of), a.desde or hoy, a.hasta or hoy, lec)
    if r is None:
        print(json.dumps({"ok": False, "codigo": 3, "motivo": "lectura no disponible (sin token, sin lectura del conector o sin campaña en externo.local.json)",
                          "artefactos": []}, ensure_ascii=False))
        sys.exit(3)
    print("gasto por día:", r["gasto_por_dia"], "| rechazados:", len(r["rechazados"]), "| en revisión:", len(r["en_revision"]))
    print(json.dumps({"ok": True, "codigo": 0, "motivo": "lectura ok", "artefactos": []}))
