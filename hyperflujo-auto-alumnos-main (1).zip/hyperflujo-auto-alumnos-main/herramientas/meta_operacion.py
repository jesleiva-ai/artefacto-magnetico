#!/usr/bin/env python3
"""meta_operacion.py — insights diarios → diagnóstico → acciones (reemplazo, escalado, baja). Hyperflujo, TAREA 035.

Reglas codificadas (fuente entre paréntesis):
  * Corte (datos/reglas_operacion.json → corte; por defecto «matias», 2026-10-26): ≥48 h sin ninguna venta → baja; con
    ventas, ≥168 h (5 días sin tocar + 48 h) con netos < gasto → baja. Con HYPERFLUJO_CORTE=d92: 24/48 h (Hyperflujo D92).
    Ventas o netos desconocidos (None) ≠ 0: resultado «sin_datos», no se decide.
  * Escalado: ROAS ≥ 2 → +30 % del diario solo si cabe en el tope; 48 h entre subidas; un tipo de cambio por día.
    [PENDIENTE: cita exacta en el repo de Matías (cash-trap-cbo-oro/SKILL.md) — umbrales parametrizables en REGLAS].
  * Reemplazo (solo con ROAS de campaña < 2): anuncio que gastó ≥ precio sin compra, o con costo por venta mayor al
    precio (Matías, 2026-10-25) → pausar y activar una reserva RES-
    del mismo nivel, C1 incluido; nunca menos de 9 activos ni 3/3/3 roto; sin reserva → no se apaga y se pide reserva.
  * 3 días sin otro cambio de anuncios tras un reemplazo.
Las acciones son propuestas (dict); las ejecuta el orquestador por la puerta. Consumo cero aquí.
"""
from datetime import datetime, timedelta

REGLAS = {"roas_escala": 2.0, "subida_pct": 30, "horas_entre_subidas": 48, "dias_tras_cambio_anuncios": 3,
          "horas_sin_tocar_inicial": 48, "roas_reemplazo_menor_que": 2.0,
          "horas_d92_sin_venta": 24, "horas_d92_negativo": 48,
          "horas_max_sin_lectura": 24, "freno_rechazos_7d": 3, "horas_d106_ventana": 6}   # D106: vigía horario tras el día 1   # los dos últimos: Hyperflujo provisional [PENDIENTE: dueño]


def _horas(desde, ahora):
    return (ahora - desde).total_seconds() / 3600


def evaluar_d92(activada_en, ahora, ventas, netos, gasto, reglas=None):
    R = reglas or REGLAS   # datos/reglas_operacion.json → corte (modo «matias» por defecto en esta copia, 2026-10-26)
    if activada_en is None:
        return {"resultado": "sin_datos", "regla": "D92", "motivo": "sin hora de activación"}
    h = _horas(activada_en, ahora)
    if ventas is None or netos is None or gasto is None:
        return {"resultado": "sin_datos", "regla": "D92", "horas": round(h, 1), "motivo": "ventas/netos/gasto desconocidos (null ≠ 0)"}
    if h >= R["horas_d92_sin_venta"] and ventas == 0:
        return {"resultado": "retirar", "regla": "D92b", "horas": round(h, 1), "motivo": "%.0f h sin ventas" % h}
    if h >= R["horas_d92_negativo"] and netos < gasto:
        return {"resultado": "retirar", "regla": "D92a", "horas": round(h, 1), "motivo": "netos %.2f < gasto %.2f a las %.0f h" % (netos, gasto, h)}
    return {"resultado": "sigue", "regla": "D92", "horas": round(h, 1)}


def diagnosticar(insights_anuncios, precio):
    """insights_anuncios: [{nombre, id, nivel, gasto, compras, reserva, c1, estado}] → {perdedores, ganadores}."""
    perd, gan = [], []
    for a in insights_anuncios:
        if a.get("reserva") or a.get("estado") != "ACTIVE" or a.get("gasto") is None or a.get("compras") is None:
            continue
        if a["compras"] == 0 and a["gasto"] >= precio:
            perd.append(a)
        elif a["compras"] > 0 and precio and a["gasto"] / a["compras"] > precio:
            perd.append(dict(a, motivo="costo por venta mayor al precio"))   # Matías, 2026-10-25
        elif a["compras"] > 0:
            gan.append(a)
    return {"perdedores": perd, "ganadores": gan}


def reglas_de_json(raiz=None):
    """Lee escalado/ventanas/reemplazo de datos/reglas_operacion.json (revisión 035 h. 5 y 15); si falta, REGLAS."""
    import json
    import os
    from pathlib import Path
    r = dict(REGLAS)
    base = Path(raiz or os.environ.get("HYPERFLUJO_RAIZ") or Path(__file__).resolve().parents[1])
    try:
        j = json.loads((base / "datos" / "reglas_operacion.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return r
    v, e, rp, c, ps = (j.get(k) or {} for k in ("ventanas", "escalado", "reemplazo", "corte", "pausa_seguridad"))
    modo = os.environ.get("HYPERFLUJO_CORTE") or c.get("modo")   # «matias» por defecto (2026-10-26); «d92» = Hyperflujo
    if modo != c.get("modo") and isinstance((j.get("alternativas_corte") or {}).get(modo), dict):
        alt = j["alternativas_corte"][modo]
        c = dict(c, **{k: alt[k] for k in ("horas_sin_venta", "horas_negativo") if k in alt})
        if "d106_ventana_horas" in alt:
            c["d106"] = dict(c.get("d106") or {}, ventana_horas=alt["d106_ventana_horas"])
    r.update({k: x for k, x in {
        "roas_escala": e.get("roas_min"), "subida_pct": (e.get("incremento") or 0) * 100 or None,
        "horas_entre_subidas": v.get("horas_entre_subidas"), "dias_tras_cambio_anuncios": v.get("dias_espera_tras_cambio"),
        "horas_sin_tocar_inicial": v.get("horas_sin_tocar_inicial"),
        "roas_reemplazo_menor_que": rp.get("solo_si_roas_campana_menor_que"),
        "horas_d92_sin_venta": c.get("horas_sin_venta"), "horas_d92_negativo": c.get("horas_negativo"),
        "horas_max_sin_lectura": ps.get("horas_max_sin_lectura"), "freno_rechazos_7d": ps.get("freno_rechazos_7d"),
        "horas_d106_ventana": (c.get("d106") or {}).get("ventana_horas"),
    }.items() if x is not None})
    return r


def decidir(ctx, ahora=None, reglas=None):
    """ctx: {activada_en (= primera entrega), ventas, netos, gasto, diario, tope_diario_max, precio, anuncios:[...],
    ultima_subida, ultimo_cambio_anuncios, cambios_hoy:[tipos]} → lista de 0 o 1 acción.

    Orden (revisión 035 h. 15, Matías cash-trap-cbo-oro/SKILL.md): D92 primero (Hyperflujo, máxima) → 48 h completas
    sin tocar (:94) → esperas tras cambios (48 h tras subir, 3 días tras cambiar anuncios; :110-112) → ROAS de campaña
    con netos de Hotmart: ≥ 2 escala y NO se toca ningún anuncio (:118-120, el «arquero»); < 2 reemplaza perdedores
    con una reserva del mismo nivel, C1 incluido (:122-127)."""
    R = dict(REGLAS, **(reglas or {}))
    ahora = ahora or datetime.now().astimezone()
    d92 = evaluar_d92(ctx.get("activada_en"), ahora, ctx.get("ventas"), ctx.get("netos"), ctx.get("gasto"), R)
    if d92["resultado"] == "retirar":
        return [{"tipo": "meta_pausar", "regla": d92["regla"], "motivo": d92["motivo"], "parametros": {"objeto": "meta.campana"}}]
    if d92["resultado"] == "sin_datos":
        return [{"tipo": "ninguna", "regla": "D92", "motivo": d92["motivo"], "parametros": {}}]
    if _horas(ctx["activada_en"], ahora) < R["horas_sin_tocar_inicial"]:
        return [{"tipo": "ninguna", "regla": "48h_sin_tocar", "motivo": "ventana inicial de %d h sin tocar (Matías)" % R["horas_sin_tocar_inicial"], "parametros": {}}]
    if ctx.get("cambios_hoy"):
        return [{"tipo": "ninguna", "regla": "un_cambio_por_dia", "motivo": "ya hubo cambio hoy", "parametros": {}}]
    us, uc = ctx.get("ultima_subida"), ctx.get("ultimo_cambio_anuncios")
    if us is not None and _horas(us, ahora) < R["horas_entre_subidas"]:
        return [{"tipo": "ninguna", "regla": "48h_tras_subida", "motivo": "subida reciente: no se toca nada", "parametros": {}}]
    if uc is not None and (ahora - uc) < timedelta(days=R["dias_tras_cambio_anuncios"]):
        return [{"tipo": "ninguna", "regla": "3d_tras_cambio", "motivo": "cambio de anuncios reciente: no se toca nada", "parametros": {}}]
    gasto, netos = ctx.get("gasto"), ctx.get("netos")
    if not gasto:
        return [{"tipo": "ninguna", "regla": "sin_gasto", "motivo": "sin gasto no hay ROAS", "parametros": {}}]
    roas = netos / gasto
    if roas >= R["roas_escala"]:
        nuevo = round(ctx["diario"] * (1 + R["subida_pct"] / 100.0), 2) if ctx.get("diario") else None
        tope = ctx.get("tope_diario_max")
        if nuevo is None or tope is None or nuevo > tope:
            return [{"tipo": "ninguna", "regla": "escala_sin_tope", "motivo": "ROAS %.2f pero +%d%% no cabe en el tope (%s)" % (roas, R["subida_pct"], tope), "parametros": {}}]
        return [{"tipo": "meta_presupuesto", "regla": "escala_roas", "motivo": "ROAS %.2f ≥ %.1f (netos Hotmart / gasto)" % (roas, R["roas_escala"]),
                 "parametros": {"nuevo_diario": nuevo}}]
    if roas >= R["roas_reemplazo_menor_que"]:
        return [{"tipo": "ninguna", "regla": "sin_cambio", "motivo": "ROAS %.2f: no se reemplaza" % roas, "parametros": {}}]
    anuncios = ctx.get("anuncios") or []
    diag = diagnosticar(anuncios, ctx.get("precio") or 0)
    for p in diag["perdedores"]:   # C1 incluido: se repone con otro C1 (Matías :122-127)
        reserva = next((r for r in anuncios if r.get("reserva") and r.get("nivel") == p.get("nivel") and r.get("estado") != "ACTIVE"), None)
        if reserva is None:
            return [{"tipo": "pedir_reserva", "regla": "reponer_mismo_nivel", "motivo": "sin reserva del nivel %s: no se apaga %s" % (p.get("nivel"), p["nombre"]), "parametros": {"nivel": p.get("nivel")}}]
        return [{"tipo": "meta_pausar_anuncio+meta_activar_anuncio", "regla": "reponer_mismo_nivel",
                 "motivo": "ROAS %.2f < %.1f y %s gastó %.2f ≥ precio sin compra" % (roas, R["roas_reemplazo_menor_que"], p["nombre"], p["gasto"]),
                 "parametros": {"pausar": p["id"], "activar": reserva["id"], "nivel": p.get("nivel")}}]
    return [{"tipo": "ninguna", "regla": "sin_cambio", "motivo": "nada que hacer", "parametros": {}}]


def resumen(ctx, acciones):
    a = acciones[0] if acciones else {"tipo": "ninguna"}
    return ["Gasto: %s" % ctx.get("gasto"), "Ventas: %s" % ctx.get("ventas"), "Netos: %s" % ctx.get("netos"),
            "Acción: %s" % a["tipo"], "Regla: %s" % a.get("regla"), "Motivo: %s" % a.get("motivo")]
