#!/usr/bin/env python3
"""meta_pausa.py — pausa real de campaña o conjunto en Meta, con relectura y registro (TAREA 036 parte B; D60).

    python herramientas/meta_pausa.py --of OF-001 --motivo "landing caída en dos sondas" [--objeto campana|conjunto]

Python determinista, sin worker (revisión 035 h. 2): Graph API con el token del usuario del sistema
(META_SYSTEM_USER_TOKEN o META_ACCESS_TOKEN). Solo escribe status=PAUSED; nunca ACTIVE ni presupuesto.
Orden (regla 6): registro.agregar_solicitud (gratuita: pausar no cobra) → marcar_enviando → una sola POST →
guardar_id_externo → relectura GET status,effective_status. El estado del producto cambia solo si la relectura dice
PAUSED (lo hace el director o el vigía con el resultado). Sin token: no hay pausa sin modelo → bloqueo humano con la
acción exacta («pausar a mano») y aviso en el informe. Cada intento queda en estado/pausas.jsonl.
Pausar está permitido aun con el freno del dueño (solo pausas) y sin autorización escrita (D60).
Solo biblioteca estándar.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

MOTIVO_GRATUITA = "Marketing API: pausar un objeto no cobra; reduce el gasto (D60)."


def _log(fila):
    p = rutas.ruta("estado", "pausas.jsonl")
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(fila, ensure_ascii=False) + "\n")


def _fila_log(fila, r):
    """El motivo de la pausa (fila) no se pisa con el resultado de la llamada (r)."""
    return {**fila, **{k: v for k, v in r.items() if k not in ("motivo", "registro")}, "resultado": r.get("motivo")}


def ej_operacion(of, fecha=None):
    """Registro de la operación del día del producto: ofertas/OF-NNN/ejecuciones/EJ-OP-AAAAMMDD/registro.json."""
    import registro
    fecha = (fecha or rutas.hoy()).replace("-", "")
    ruta = rutas.dir_oferta(of) / "ejecuciones" / ("EJ-OP-%s" % fecha) / "registro.json"
    if not ruta.exists():
        registro.crear_ejecucion(str(ruta), of, "EJ-OP-%s" % fecha, "operacion", "director/vigia (sin modelo)")
    return str(ruta)


def transporte_por_defecto():
    try:
        import claves
        import meta_ads
        token = os.environ.get("META_SYSTEM_USER_TOKEN")
        if not token:
            est = claves.estado()
            nombre = "META_SYSTEM_USER_TOKEN" if est.get("META_SYSTEM_USER_TOKEN") else "META_ACCESS_TOKEN" if est.get("META_ACCESS_TOKEN") else None
            token = claves.clave(nombre) if nombre else None
        return meta_ads.TransporteHTTP(token) if token else None
    except Exception:
        return None


def pausar(of, motivo, *, objeto="campana", transporte=None, registrar=True, actor="director"):
    """Devuelve {"ok", "estado_meta", "codigo", "motivo", ...} en la forma que espera orquestador._resultado_ok."""
    fila = {"hora": rutas.ahora().isoformat(timespec="seconds"), "of": of, "objeto": objeto, "motivo": motivo, "actor": actor}
    obj_id = ((rutas.externo(of).get("meta") or {}).get(objeto))
    if not obj_id:
        r = {"ok": False, "codigo": 3, "humano": True, "consumo": 0, "motivo": "sin ID de %s en externo.local.json" % objeto,
             "accion_humana": "pausar a mano en el Administrador de anuncios y cargar el ID en ofertas/%s/externo.local.json" % of}
        _log(_fila_log(fila, r))
        return r
    t = transporte or transporte_por_defecto()
    if t is None:
        r = {"ok": False, "codigo": 3, "humano": True, "consumo": 0, "motivo": "sin token de Meta para pausar sin modelo",
             "accion_humana": "pausar a mano la campaña de %s (motivo: %s) o cargar META_SYSTEM_USER_TOKEN en .env" % (of, motivo)}
        _log(_fila_log(fila, r))
        return r
    import registro
    try:   # revisión 036 h. 4: si ya está en pausa (p. ej. un intento anterior que se cortó) no se vuelve a escribir
        previo = t("GET", obj_id, {"fields": "status,effective_status"})
    except Exception:
        previo = {}
    if previo.get("status") == "PAUSED":
        r = {"ok": True, "codigo": 0, "consumo": 0, "estado_meta": "PAUSED", "effective_status": previo.get("effective_status"),
             "motivo": "ya estaba en pausa (relectura previa); no se escribió nada"}
        _log(_fila_log(fila, r))
        return r
    ej = sid = None
    if registrar:
        try:
            ej = ej_operacion(of)
            sid = registro.agregar_solicitud(ej, "api", "meta", clave="pausa:%s:%s" % (objeto, fila["hora"]), estimado=0,
                                             gratuita=True, motivo_gratuita=MOTIVO_GRATUITA,
                                             parametros={"objeto": objeto, "status": "PAUSED", "motivo": motivo})
            registro.marcar_enviando(ej, sid)
        except registro.ErrorRegistro as e:   # envío incierto u otro bloqueo: pausar es idempotente y baja el gasto
            fila["registro"] = "sin registro (%s): la pausa se envía igual" % type(e).__name__
            registrar, ej, sid = False, None, None
    try:
        t("POST", obj_id, {"status": "PAUSED"})
    except Exception as e:
        if registrar:
            registro.marcar_rechazada(ej, sid, str(e)[:300])
        r = {"ok": False, "codigo": 1, "consumo": 0, "motivo": "Meta rechazó la pausa: %s" % str(e)[:200]}
        _log(_fila_log(fila, r))
        return r
    if registrar:
        registro.guardar_id_externo(ej, sid, str(obj_id))
    try:
        leido = t("GET", obj_id, {"fields": "status,effective_status"})
        estado_meta = leido.get("status")
    except Exception as e:
        estado_meta = None
        leido = {"error": type(e).__name__}
    ok = estado_meta == "PAUSED"
    if registrar:
        registro.cambiar_estado(ej, "completada" if ok else "fallida", solicitud_id=sid,
                                error=None if ok else "relectura sin PAUSED: %s" % estado_meta)
    r = {"ok": ok, "codigo": 0 if ok else 2, "consumo": 0, "estado_meta": estado_meta,
         "effective_status": leido.get("effective_status"),
         "motivo": "pausa confirmada por relectura" if ok else "la relectura no confirma PAUSED (%s)" % estado_meta,
         "registro": os.path.relpath(ej, rutas.RAIZ).replace("\\", "/") if ej else None}
    _log(_fila_log(fila, r))
    return r


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Pausa la campaña (o el conjunto) de un producto en Meta y relee el estado.")
    ap.add_argument("--of", required=True)
    ap.add_argument("--motivo", required=True)
    ap.add_argument("--objeto", choices=("campana", "conjunto"), default="campana")
    a = ap.parse_args()
    r = pausar(rutas.validar_of(a.of), a.motivo, objeto=a.objeto, actor="manual")
    print(json.dumps({"ok": r["ok"], "codigo": r["codigo"], "motivo": r["motivo"], "artefactos": [r["registro"]] if r.get("registro") else []},
                     ensure_ascii=False))
    sys.exit(r["codigo"])
