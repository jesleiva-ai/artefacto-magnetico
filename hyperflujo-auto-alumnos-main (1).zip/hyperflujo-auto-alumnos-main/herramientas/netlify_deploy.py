#!/usr/bin/env python3
"""Publicación de la landing externa en Netlify por API (TAREA 032 act. 11, D72). Solo stdlib.
Origen: hyperflujo/herramientas/netlify_deploy.py (copia SIN ADAPTAR — [PENDIENTE: importa `claves` (C2); dueño del archivo según el plan: C4; adaptar a rutas.py y la puerta]). No se importa en la suite.

    python herramientas/netlify_deploy.py estado
    python herramientas/netlify_deploy.py borrador <carpeta canales/hotmart> --ej <registro.json> [--nombre tejer-dos-agujas]
    python herramientas/netlify_deploy.py publicar <carpeta canales/hotmart> --ej <registro.json> --ok "<cita del OK del dueño>" [--nombre …]

- Token: NETLIFY_AUTH_TOKEN en .env (token personal del dueño); claves.py dice definida/no definida y nada
  más. El token nunca se imprime ni se registra.
- Sitio: se busca por nombre en la cuenta; si no existe se crea (POST /api/v1/sites). Gratis en el plan Free.
- borrador: deploy de BORRADOR (draft: no toca la URL pública; Netlify da una URL única de vista previa) por el método de
  resúmenes SHA-1 (POST /sites/{id}/deploys {files, draft: true} + PUT de los archivos que pida). Para revisar en el PARAR.
- publicar: deploy de PRODUCCIÓN con el sitio en zip (POST /sites/{id}/deploys, application/zip). Es el PARAR de
  publicar: exige --ok con la cita del OK escrito «publicar» del dueño y que sitio/estado.json diga publicable=true.
- Cada deploy = solicitud gratuita en el registro (regla 5/6): agregar_solicitud → marcar_enviando → un POST →
  guardar_id_externo(deploy id) → esperar «ready». Si la subida se corta: envio_incierto; conciliar listando los deploys
  del sitio (GET /sites/{id}/deploys) antes de repetir.
- Salida: URL en config_sitio.json (url_borrador / url_landing), ficha_hotmart.json (netlify) y, al publicar,
  oferta.json → url_destino.
"""
import argparse
import hashlib
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import claves as _claves  # noqa: E402
import registro as _registro  # noqa: E402

API = "https://api.netlify.com/api/v1"
NOMBRE_DEFECTO = "tejer-dos-agujas"
MOTIVO = "Netlify plan Free: crear sitios y desplegar un sitio estático no cobra (D72)."


class ErrorNetlify(Exception):
    pass


class SinOK(ErrorNetlify):
    pass


# ---------------------------------------------------------------- transporte
class TransporteHTTP:
    def __init__(self, token, timeout=300):
        self._token = token
        self.timeout = timeout

    def __call__(self, metodo, ruta, cuerpo=None, tipo="application/json"):
        url = ruta if ruta.startswith("http") else API + ruta
        datos = json.dumps(cuerpo).encode() if isinstance(cuerpo, (dict, list)) else cuerpo
        req = urllib.request.Request(url, data=datos, method=metodo,
                                     headers={"Authorization": "Bearer " + self._token, "Content-Type": tipo,
                                              "User-Agent": "hyperflujo-netlify-deploy"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                texto = r.read().decode("utf-8")
                return json.loads(texto) if texto.strip() else {}
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read().decode("utf-8")).get("message")
            except Exception:
                msg = None
            raise ErrorNetlify("Netlify rechazó %s %s: HTTP %s %s" % (metodo, ruta.split("?")[0], e.code, msg or "")) from None


class TransporteFalso:
    """Para tests: sitios y deploys en memoria; un deploy pasa a «ready» en la segunda consulta."""

    def __init__(self, sitios=None):
        self.llamadas = []
        self.sitios = list(sitios or [])
        self.deploys = {}
        self._n = 0

    def __call__(self, metodo, ruta, cuerpo=None, tipo="application/json"):
        self.llamadas.append({"metodo": metodo, "ruta": ruta, "tipo": tipo,
                              "bytes": len(cuerpo) if isinstance(cuerpo, (bytes, bytearray)) else None,
                              "json": cuerpo if isinstance(cuerpo, dict) else None})
        ruta_sin = ruta.split("?")[0]
        if metodo == "GET" and ruta_sin == "/sites":
            nombre = urllib.parse.parse_qs(urllib.parse.urlparse(ruta).query).get("name", [None])[0]
            return [s for s in self.sitios if not nombre or s["name"] == nombre]
        if metodo == "POST" and ruta_sin == "/sites":
            self._n += 1
            s = {"id": "sitio-%d" % self._n, "name": cuerpo["name"], "ssl_url": "https://%s.netlify.app" % cuerpo["name"]}
            self.sitios.append(s)
            return s
        if metodo == "POST" and ruta_sin.endswith("/deploys"):
            self._n += 1
            did = "dep%04d" % self._n
            sitio = ruta_sin.split("/")[2]
            nombre = next(s["name"] for s in self.sitios if s["id"] == sitio)
            borrador = isinstance(cuerpo, dict) and cuerpo.get("draft")
            d = {"id": did, "site_id": sitio, "state": "uploading" if borrador else "processing", "consultas": 0,
                 "deploy_ssl_url": "https://%s--%s.netlify.app" % (did, nombre),
                 "ssl_url": "https://%s.netlify.app" % nombre, "draft": bool(borrador),
                 "required": list((cuerpo or {}).get("files", {}).values())[:2] if borrador else []}
            self.deploys[did] = d
            return {k: v for k, v in d.items() if k != "consultas"}
        if metodo == "PUT" and "/files/" in ruta_sin:
            d = self.deploys[ruta_sin.split("/")[2]]
            d["state"] = "processing"
            return {"id": "archivo"}
        if metodo == "GET" and ruta_sin.startswith("/deploys/"):
            d = self.deploys[ruta_sin.split("/")[2]]
            d["consultas"] += 1
            if d["consultas"] >= 2:
                d["state"] = "ready"
            return {k: v for k, v in d.items() if k != "consultas"}
        if metodo == "GET" and ruta_sin.endswith("/deploys"):
            return [{k: v for k, v in d.items() if k != "consultas"} for d in self.deploys.values()]
        raise ErrorNetlify("transporte falso: %s %s no simulado" % (metodo, ruta))


# ---------------------------------------------------------------- sitio y archivos
def archivos(carpeta):
    out = {}
    for base, _, nombres in os.walk(carpeta):
        for n in sorted(nombres):
            ruta = os.path.join(base, n)
            rel = "/" + os.path.relpath(ruta, carpeta).replace("\\", "/")
            if rel == "/estado.json":
                continue          # metadato local, no se publica
            out[rel] = ruta
    return dict(sorted(out.items()))


def sha1(ruta):
    h = hashlib.sha1()
    with open(ruta, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def zip_en_memoria(mapa):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, ruta in mapa.items():
            z.write(ruta, rel.lstrip("/"))
    return buf.getvalue()


def huella(mapa):
    h = hashlib.sha256()
    for rel, ruta in mapa.items():
        h.update(rel.encode() + b"\0" + sha1(ruta).encode())
    return h.hexdigest()[:12]


def sitio(t, nombre):
    encontrados = [s for s in t("GET", "/sites?name=%s&filter=all" % urllib.parse.quote(nombre)) if s.get("name") == nombre]
    if encontrados:
        return encontrados[0], False
    return t("POST", "/sites", {"name": nombre}), True


def esperar(t, deploy_id, timeout=300, pausa=3, dormir=time.sleep):
    fin = time.time() + timeout
    while True:
        d = t("GET", "/deploys/%s" % deploy_id)
        if d.get("state") == "ready":
            return d
        if d.get("state") == "error":
            raise ErrorNetlify("El deploy %s terminó en error: %s" % (deploy_id, d.get("error_message")))
        if time.time() > fin:
            raise ErrorNetlify("El deploy %s no llegó a «ready» en %d s (estado %s)." % (deploy_id, timeout, d.get("state")))
        dormir(pausa)


def sin_testimonios(mapa):
    """D119: lista de archivos del sitio que traen un bloque de testimonios o una carpeta img/testimonios/
    (vacía = se puede desplegar). Testimonios fuera del sistema: nunca se despliegan."""
    import guardia_landing
    malos = [rel for rel in mapa if "/testimonios/" in rel]
    for rel, ruta in mapa.items():
        if rel.endswith(".html"):
            with open(ruta, encoding="utf-8", errors="replace") as f:
                if guardia_landing.tiene_bloque(f.read()):
                    malos.append(rel)
    return malos


def legales_de_relleno(mapa):
    """F65: [«archivo: problema»] por cada HTML del sitio (no solo index) con relleno legal o de prueba."""
    import legales
    out = []
    for rel, ruta in mapa.items():
        if rel.endswith(".html"):
            with open(ruta, encoding="utf-8", errors="replace") as f:
                out += ["%s: %s" % (rel, p) for p in legales.problemas(f.read())]
    return out


def revisar_antes_de_desplegar(mapa, of=None):
    """Toda subida (landing, retiro, corrección, medios con HTML) pasa por acá: D119, F63 y F65. Falla cerrado."""
    con_bloque = sin_testimonios(mapa)
    if con_bloque:
        raise ErrorNetlify("D119: testimonios fuera del sistema y el sitio trae un bloque de testimonios en %s; no se despliega"
                           % ", ".join(con_bloque[:5]))
    mal_pixel = pixel_ajeno(mapa, of)
    if mal_pixel:
        raise ErrorNetlify("F63: el píxel del sitio no es el del producto en su mercado (%s); no se despliega" % "; ".join(mal_pixel[:5]))
    relleno = legales_de_relleno(mapa)
    if relleno:
        raise ErrorNetlify("F65: el sitio trae relleno (%s); no se despliega" % "; ".join(relleno[:5]))


def pixel_ajeno(mapa, of=None):
    """F63: [«archivo: problema»] si algún HTML trae un píxel que no es el del producto en su mercado (Matías, 2026-10-25;
    sin fila en meta.pixeles, el de la cuenta) o un relleno. Si algún HTML trae píxel y no se puede saber cuál va, eso
    también es un problema (falla cerrado)."""
    import pixel as PX
    htmls = {}
    for rel, ruta in mapa.items():
        if rel.endswith(".html"):
            with open(ruta, encoding="utf-8", errors="replace") as f:
                htmls[rel] = f.read()
    if not any(PX.ids_en_html(t) for t in htmls.values()):
        return []
    try:
        import rutas
        ficha = (rutas.leer_json(rutas.ruta_ficha(of), defecto={}) or {}) if of else {}
        propio = PX.del_producto(of, (ficha.get("mercado") or {}).get("id"), (ficha.get("campana") or {}).get("cuenta_ref"))
    except PX.SinPixel as e:
        return ["%s (el sitio trae píxel)" % e]
    return ["%s: %s" % (rel, p) for rel, t in htmls.items() for p in PX.problemas(t, propio)]


# ---------------------------------------------------------------- operación
def _of_de(carpeta):
    m = re.search(r"(?:^|[\\/])(OF-\d{3,})(?:[\\/]|$)", os.path.abspath(carpeta))
    return m.group(1) if m else None


def releer_publicado(of, url, retiro=False):
    """E3: relectura del sitio publicado entero después de cada deploy de producción (compuerta_sitio)."""
    import compuerta_sitio
    return compuerta_sitio.exigir(of, "deploy", url=url, retiro=retiro, exigir_campana=False)


def ok_vigente(of, ok):
    """F66: el --ok de producción cita por id una autorización «publicar» vigente para ese producto (no un texto
    copiado de otro deploy). → (bool, motivo)."""
    import autorizaciones as AU
    ids = set(re.findall(r"\bAUT-[A-Za-z0-9-]+", ok or ""))
    if not ids:
        return False, "el --ok no cita ninguna autorización (AUT-…)"
    try:
        datos = json.load(open(os.path.join(AU._raiz(), "datos", "autorizaciones.local.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return False, "no se lee datos/autorizaciones.local.json"
    import rutas
    hoy = rutas.hoy()
    buenas = [a["id"] for a in datos.get("autorizaciones", []) if a.get("id") in ids and a.get("alcance") == "publicar"
              and AU._valida(a, of, hoy)]
    return (True, "autorización %s" % ", ".join(buenas)) if buenas else (
        False, "ninguna de %s es una autorización «publicar» vigente para %s" % (", ".join(sorted(ids)), of))


def aprobado_profesor(sitio_dir):
    """Matías, 2026-10-27: ninguna landing sale sin el aprobado vigente del Profesor (`profesor_web.py`). → (bool, motivo)."""
    import profesor_web
    return profesor_web.verificar(sitio_dir)


def desplegar(carpeta_canal, ej, t, modo, nombre=NOMBRE_DEFECTO, ok=None, dormir=time.sleep, sitio_dir=None, anotar=True,
              releer=releer_publicado, autorizado=ok_vigente, profesor=aprobado_profesor):
    if modo not in ("borrador", "publicar"):
        raise ErrorNetlify("modo: borrador | publicar")
    exigir_profesor = sitio_dir is None   # el retiro publica sus propias páginas legales, no una landing
    sitio_dir = sitio_dir or os.path.join(carpeta_canal, "sitio")
    estado = json.load(open(os.path.join(sitio_dir, "estado.json"), encoding="utf-8"))
    if modo == "publicar":
        if not (ok and ok.strip()):
            raise SinOK("Publicar es el PARAR: exige --ok con la cita del OK escrito «publicar» del dueño.")
        if not estado.get("publicable") or estado.get("prueba"):
            raise ErrorNetlify("sitio/estado.json no está publicable: faltan %s" % "; ".join(estado.get("faltan", [])))
        of_ok = _of_de(carpeta_canal)
        if of_ok and not estado.get("retiro"):
            import compuerta_sitio
            pend = compuerta_sitio.pendientes_medios(of_ok)
            if pend:
                raise ErrorNetlify("pendientes de medios: " + compuerta_sitio.mensaje_pendientes_medios(pend))
        if of_ok:
            vale, motivo_ok = autorizado(of_ok, ok)
            if not vale:
                raise SinOK("F66: %s; el OK de producción cita una autorización «publicar» vigente por id" % motivo_ok)
        if exigir_profesor:
            aprobada, motivo_prof = profesor(sitio_dir)
            if not aprobada:
                raise ErrorNetlify("Profesor: %s. No se publica (skills/profesor-web)" % motivo_prof)
    mapa = archivos(sitio_dir)
    if "/index.html" not in mapa:
        raise ErrorNetlify("sitio/ sin index.html: correr construir_sitio.py")
    revisar_antes_de_desplegar(mapa, _of_de(carpeta_canal))
    s, creado = sitio(t, nombre)
    clave = "netlify:%s:%s:%s" % (nombre, modo, huella(mapa))
    sid = _registro.agregar_solicitud(ej, "api", "netlify", clave=clave, estimado=0, gratuita=True, motivo_gratuita=MOTIVO,
                                      parametros={"sitio": nombre, "site_id": s["id"], "modo": modo, "archivos": len(mapa),
                                                  "ok": ok, "sitio_creado": creado})
    _registro.marcar_enviando(ej, sid)
    rodeo = False
    try:
        if modo == "publicar":
            d = t("POST", "/sites/%s/deploys" % s["id"], zip_en_memoria(mapa), "application/zip")
        else:
            resumen = {rel: sha1(ruta) for rel, ruta in mapa.items()}
            d = t("POST", "/sites/%s/deploys" % s["id"], {"files": resumen, "draft": True})
    except ErrorNetlify as e:
        if modo != "publicar" or "HTTP 403" not in str(e):
            _registro.marcar_rechazada(ej, sid, str(e))
            raise
        # TAREA 040 (F58): Netlify rechazó con 403 el deploy directo de producción y sí aceptó borradores. Camino alterno:
        # borrador por resúmenes (POST draft: true + PUT de lo pedido) y después promoverlo con /restore.
        resumen = {rel: sha1(ruta) for rel, ruta in mapa.items()}
        try:
            d = t("POST", "/sites/%s/deploys" % s["id"], {"files": resumen, "draft": True})
        except ErrorNetlify as e2:
            _registro.marcar_rechazada(ej, sid, "%s; rodeo borrador: %s" % (e, e2))
            raise
        rodeo = True
    _registro.guardar_id_externo(ej, sid, d["id"])           # apenas llega (regla 6)
    if modo == "borrador" or rodeo:
        pedidos = set(d.get("required") or [])
        for rel, ruta in mapa.items():
            if sha1(ruta) in pedidos:
                with open(ruta, "rb") as f:
                    t("PUT", "/deploys/%s/files%s" % (d["id"], urllib.parse.quote(rel)), f.read(), "application/octet-stream")
    final = esperar(t, d["id"], dormir=dormir)
    if rodeo:   # el borrador listo pasa a ser el deploy publicado del sitio
        t("POST", "/sites/%s/deploys/%s/restore" % (s["id"], d["id"]), {})
    _registro.cambiar_estado(ej, "completada", solicitud_id=sid)
    url = final.get("deploy_ssl_url") if modo == "borrador" else (final.get("ssl_url") or s.get("ssl_url"))
    of = _of_de(carpeta_canal)
    if modo == "publicar" and of:   # E3: vale lo publicado releído, no lo subido; si falla, vuelve al deploy anterior
        rl = releer(of, url, retiro=bool(estado.get("retiro")))
        if not rl.get("ok"):
            previo = (s.get("published_deploy") or {}).get("id")
            if previo and previo != d["id"]:
                t("POST", "/sites/%s/deploys/%s/restore" % (s["id"], previo), {})
            raise ErrorNetlify("E3: el sitio publicado no pasa la compuerta (%s); %s" % (
                "; ".join((rl.get("problemas") or [])[:4]),
                "se volvió al deploy anterior %s" % previo if previo and previo != d["id"] else "no había deploy anterior: queda en línea, retirarlo"))
    if anotar:
        escribir(carpeta_canal, modo, url, s, final, ej)
    return {"modo": modo, "url": url, "deploy_id": d["id"], "site_id": s["id"], "sitio_creado": creado, "solicitud": sid,
            "rodeo_borrador_restore": rodeo}


LEGALES_PUBLICADOS = ("impressum", "datenschutz", "aviso-legal", "privacidad", "condiciones", "cookies")
TEXTO_RETIRO = {"de": ("Nicht mehr verfügbar", "Dieses Produkt ist nicht mehr verfügbar."),
                "es": ("No disponible", "Este producto ya no está disponible."),
                "en": ("No longer available", "This product is no longer available."),
                "pt": ("Indisponível", "Este produto não está mais disponível.")}


def _leer_publico(url):   # lectura-gratuita: GET de una página pública del propio sitio
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hyperflujo-netlify-deploy"}), timeout=30) as r:
            return r.read().decode("utf-8", errors="replace") if r.status == 200 else None
    except urllib.error.HTTPError:
        return None


def retiro(carpeta_canal, ej, t, nombre, ok, idioma="de", leer=_leer_publico, dormir=time.sleep, releer=releer_publicado,
           autorizado=ok_vigente):
    """F65: retira un producto de la venta sin bajar los legales. Los legales se toman de lo PUBLICADO (no de la copia
    local, que pudo pisarse) y pasan por el mismo validador; el sitio de retiro es «no disponible» + esos legales."""
    import shutil
    if not (ok and ok.strip()):
        raise SinOK("Retirar exige --ok con la cita del OK escrito.")
    encontrados = [x for x in t("GET", "/sites?name=%s&filter=all" % urllib.parse.quote(nombre)) if x.get("name") == nombre]
    if not encontrados:
        raise ErrorNetlify("no existe el sitio %s: nada que retirar" % nombre)
    base = (encontrados[0].get("ssl_url") or encontrados[0].get("url") or "").rstrip("/")
    if not base:
        raise ErrorNetlify("el sitio %s no informa su URL" % nombre)
    legales_html = {}
    for nombre_legal in LEGALES_PUBLICADOS:
        html = leer("%s/%s" % (base, nombre_legal)) or leer("%s/%s.html" % (base, nombre_legal))
        if html:
            legales_html[nombre_legal] = html
    if not legales_html:
        raise ErrorNetlify("el sitio publicado no tiene legales (%s): no se arma un retiro sin ellos" % ", ".join(LEGALES_PUBLICADOS))
    titulo, frase = TEXTO_RETIRO.get(idioma, TEXTO_RETIRO["en"])
    dir_retiro = os.path.join(carpeta_canal, "retiro", "sitio")
    shutil.rmtree(dir_retiro, ignore_errors=True)
    os.makedirs(dir_retiro)
    enlaces = " · ".join('<a href="/%s">%s</a>' % (n, n.replace("-", " ").capitalize()) for n in legales_html)
    with open(os.path.join(dir_retiro, "index.html"), "w", encoding="utf-8", newline="\n") as f:
        f.write('<!doctype html><html lang="%s"><head><meta charset="utf-8"><meta name="viewport" '
                'content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>%s</title></head>'
                '<body style="font-family:system-ui,sans-serif;max-width:40rem;margin:4rem auto;padding:0 1rem">'
                '<p>%s</p><footer style="margin-top:3rem;font-size:.9rem">%s</footer></body></html>\n' % (idioma, titulo, frase, enlaces))
    for n, html in legales_html.items():
        with open(os.path.join(dir_retiro, "%s.html" % n), "w", encoding="utf-8", newline="\n") as f:
            f.write(html)
    with open(os.path.join(dir_retiro, "estado.json"), "w", encoding="utf-8") as f:
        json.dump({"publicable": True, "faltan": [], "retiro": True, "legales_de": base}, f)
    r = desplegar(carpeta_canal, ej, t, "publicar", nombre=nombre, ok=ok, dormir=dormir, sitio_dir=dir_retiro, anotar=False,
                  releer=releer, autorizado=autorizado)
    r.update(retiro=True, legales=sorted(legales_html))
    return r


def desplegar_medios(carpeta, ej, t, nombre, ok, dormir=time.sleep):
    """Publica una carpeta de medios tal cual (producción, zip) en su propio sitio: los creativos de los anuncios necesitan
    URL públicas para que el conector meta-ads los baje (D91; Matías los «publicó un rato en la web»). Exige OK."""
    if not (ok and ok.strip()):
        raise SinOK("Publicar medios exige --ok con la cita del OK escrito.")
    mapa = {k: v for k, v in archivos(carpeta).items() if not k.endswith((".json", ".md"))}
    if not mapa:
        raise ErrorNetlify("carpeta de medios vacía: %s" % carpeta)
    revisar_antes_de_desplegar(mapa)
    s, creado = sitio(t, nombre)
    clave = "netlify:%s:medios:%s" % (nombre, huella(mapa))
    sid = _registro.agregar_solicitud(ej, "api", "netlify", clave=clave, estimado=0, gratuita=True, motivo_gratuita=MOTIVO,
                                      parametros={"sitio": nombre, "site_id": s["id"], "modo": "medios", "archivos": len(mapa),
                                                  "ok": ok, "sitio_creado": creado})
    _registro.marcar_enviando(ej, sid)
    try:
        d = t("POST", "/sites/%s/deploys" % s["id"], zip_en_memoria(mapa), "application/zip")
    except ErrorNetlify as e:
        _registro.marcar_rechazada(ej, sid, str(e))
        raise
    _registro.guardar_id_externo(ej, sid, d["id"])
    final = esperar(t, d["id"], dormir=dormir)
    _registro.cambiar_estado(ej, "completada", solicitud_id=sid)
    base = (final.get("ssl_url") or s.get("ssl_url")).rstrip("/")
    return {"modo": "medios", "url": base, "deploy_id": d["id"], "site_id": s["id"], "sitio_creado": creado, "solicitud": sid,
            "archivos": {k: base + k for k in mapa}}


def ancho_de_banda(t, tope_gb=100.0):
    """Solo lectura: consumo de ancho de banda del equipo en el período (GET /accounts/{slug}/bandwidth).
    Netlify no informa el incluido en el plan Free (included = null): se usa tope_gb (Free = 100 GB/mes)."""
    cuentas = t("GET", "/accounts")
    slug = cuentas[0]["slug"]
    b = t("GET", "/accounts/%s/bandwidth" % slug)
    tope = b.get("included") or int(tope_gb * 1024 ** 3)
    usado = int(b.get("used") or 0)
    return {"cuenta": slug, "plan": cuentas[0].get("type_name"), "usado_bytes": usado, "tope_bytes": tope,
            "tope_fuente": "Netlify" if b.get("included") else "supuesto %.0f GB (plan Free)" % tope_gb,
            "porcentaje": round(100.0 * usado / tope, 2), "alerta": usado > 0.7 * tope,
            "periodo": [b.get("period_start_date"), b.get("period_end_date")], "leido": b.get("last_updated_at")}


def _json(ruta):
    return json.load(open(ruta, encoding="utf-8"))


def _guardar(ruta, d):
    with open(ruta, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")


def escribir(carpeta_canal, modo, url, s, deploy, ej):
    fecha = datetime.now().astimezone().isoformat(timespec="seconds")
    pc = os.path.join(carpeta_canal, "config_sitio.json")
    c = _json(pc)
    c["url_borrador" if modo == "borrador" else "url_landing"] = url
    _guardar(pc, c)
    pf = os.path.join(carpeta_canal, "ficha_hotmart.json")
    f = _json(pf)
    f.setdefault("netlify", {})
    f["netlify"].update({"site_id": s["id"], "nombre": s.get("name"), modo: {"url": url, "deploy_id": deploy["id"], "fecha": fecha,
                                                                          "ejecucion": os.path.relpath(ej).replace("\\", "/")}})
    if modo == "publicar":
        f["producto"]["pagina_de_ventas"]["valor"] = url
    _guardar(pf, f)
    if modo == "publicar":
        po = os.path.join(os.path.dirname(os.path.dirname(carpeta_canal)), "oferta.json")
        o = _json(po)
        o["url_destino"] = url
        _guardar(po, o)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Landing externa en Netlify por API (TAREA 032, D72).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("estado")
    for n in ("borrador", "publicar"):
        p = sub.add_parser(n)
        p.add_argument("carpeta")
        p.add_argument("--ej", required=True)
        p.add_argument("--nombre", default=NOMBRE_DEFECTO)
        if n == "publicar":
            p.add_argument("--ok", required=True)
    p = sub.add_parser("retiro", help="producto fuera de venta: página «no disponible» + los legales YA publicados (F65)")
    p.add_argument("carpeta")
    p.add_argument("--ej", required=True)
    p.add_argument("--nombre", required=True)
    p.add_argument("--ok", required=True)
    p.add_argument("--idioma", default="de", choices=sorted(TEXTO_RETIRO))
    p = sub.add_parser("ancho", help="solo lectura: ancho de banda usado del equipo y alerta al 70 %")
    p.add_argument("--tope-gb", type=float, default=100.0)
    p = sub.add_parser("medios", help="publica una carpeta de medios tal cual en su propio sitio")
    p.add_argument("carpeta")
    p.add_argument("--ej", required=True)
    p.add_argument("--nombre", required=True)
    p.add_argument("--ok", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "estado":
        print("NETLIFY_AUTH_TOKEN %s" % ("definida" if _claves.estado().get("NETLIFY_AUTH_TOKEN") else "no definida"))
        return 0
    try:
        t = TransporteHTTP(_claves.clave("NETLIFY_AUTH_TOKEN"))
        if a.cmd == "ancho":
            print(json.dumps(ancho_de_banda(t, a.tope_gb), ensure_ascii=False))
            return 0
        if a.cmd == "medios":
            r = desplegar_medios(os.path.abspath(a.carpeta), a.ej, t, a.nombre, a.ok)
        elif a.cmd == "retiro":
            r = retiro(os.path.abspath(a.carpeta), a.ej, t, a.nombre, a.ok, idioma=a.idioma)
        else:
            r = desplegar(os.path.abspath(a.carpeta), a.ej, t, a.cmd, a.nombre, getattr(a, "ok", None))
        print(json.dumps(r, ensure_ascii=False))
        return 0
    except _claves.ErrorClave as e:
        print("Espera token: %s" % e)
        return 3
    except SinOK as e:
        print(str(e))
        return 3
    except (ErrorNetlify, _registro.ErrorRegistro) as e:
        print("ERROR: %s" % e)
        return 2


if __name__ == "__main__":
    sys.exit(main())
