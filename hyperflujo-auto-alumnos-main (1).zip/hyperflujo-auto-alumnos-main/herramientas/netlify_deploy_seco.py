"""netlify_deploy_seco.py — envoltorio en seco de netlify_deploy.py (copia del taller). Hyperflujo, TAREA 035.
publicar(carpeta, sitio, transporte): exige index.html y un transporte inyectado (TransporteNetlifyFalso en pruebas).
[PENDIENTE: cablear netlify_deploy.py del taller (usa NETLIFY_AUTH_TOKEN de .env) al orquestador con la puerta.]"""
from pathlib import Path


def publicar(carpeta, sitio, transporte):
    carpeta = Path(carpeta)
    if not (carpeta / "index.html").is_file():
        raise FileNotFoundError("falta index.html en %s" % carpeta)
    return transporte.desplegar(carpeta, sitio)
