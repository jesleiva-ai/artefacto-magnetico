#!/usr/bin/env python3
"""nombre_coherente.py — etapa «nombre coherente» (F18, D83, D86): mide 5 opciones de marca y título y propone una.

    python herramientas/nombre_coherente.py medir --of OF-NNN --opciones opciones.json [--pais ALL]
    python herramientas/nombre_coherente.py validar --of OF-NNN

opciones.json: [{"marca": "...", "titulo": "...", "slug": "..."}, ...] (5), en el idioma y la región del mercado.
Por opción mide, gratis y sin sesión:
  * choque con anunciantes: búsqueda de FRASE EXACTA de la marca en la Biblioteca pública (cazar_biblioteca.mjs) →
    anuncios activos y anunciantes distintos que la usan (lo que cuenta es lo leído, nunca el declarado);
  * subdominio: GET a https://<slug>.netlify.app (404 = libre; otra respuesta = ocupado; sin red = [PENDIENTE]);
  * reglas: sin marcas de terceros (p. ej. las de Microsoft para un producto de ofimática), sin palabras de
    categorías restringidas de Meta (Ramiro, cerebro-kit/claude/skills/meta-ads/SKILL.md, «Nombres»), sin el
    nombre de la referencia ni su traducción literal, sin anglicismos.
Elige la mejor (sin choque > subdominio libre > más corta) y deja las otras 4 para el veto del dueño. Escribe
ofertas/OF-NNN/nombre.json. No elige si ninguna pasa: «[PENDIENTE: nombre]». Consumo: cero. Solo biblioteca estándar.
"""
import argparse
import json
import os
import re
import sys
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cazar  # noqa: E402
import rutas  # noqa: E402

MARCAS_TERCEROS = ["microsoft", "office", "word", "excel", "powerpoint", "outlook", "windows", "google", "canva",
                   "notion", "apple", "hotmart", "meta", "facebook", "instagram", "ninja", "thermomix"]
RESTRINGIDAS = ["credito", "prestamo", "hipoteca", "vivienda", "empleo garantizado", "trabajo garantizado", "dinero rapido",
                "inversion", "cripto", "adelgazar", "cura", "curar", "salud", "politica", "elecciones"]
ANGLICISMOS = ["easy", "pro", "master", "hack", "skills", "office", "tips", "kit"]


def _norm(s):
    t = unicodedata.normalize("NFKD", str(s or "").lower())
    return "".join(c for c in t if not unicodedata.combining(c))


def reglas(opcion, prohibidos=()):
    """Motivos por los que una opción no vale (lista vacía = pasa)."""
    malos = []
    texto = _norm(opcion.get("marca", "") + " " + opcion.get("titulo", ""))
    for w in MARCAS_TERCEROS:
        if re.search(r"(?<!\w)%s(?!\w)" % re.escape(w), texto):
            malos.append("marca de terceros: %s" % w)
    for w in RESTRINGIDAS:
        if re.search(r"(?<!\w)%s" % re.escape(w), texto):
            malos.append("palabra de categoría restringida: %s" % w)
    for w in ANGLICISMOS:
        if re.search(r"(?<!\w)%s(?!\w)" % re.escape(w), _norm(opcion.get("marca", ""))):
            malos.append("anglicismo en la marca: %s" % w)
    for p in prohibidos:
        if _norm(p) and _norm(p) in texto:
            malos.append("nombre de la referencia o su traducción: %s" % p)
    return malos


def sonda_subdominio(slug, abrir=urllib.request.urlopen, timeout=15):
    url = "https://%s.netlify.app/" % slug
    try:
        with abrir(urllib.request.Request(url, method="GET", headers={"User-Agent": "hyperflujo-nombre/1"}), timeout=timeout) as r:
            return {"url": url, "http": r.status, "libre": False}
    except urllib.error.HTTPError as e:
        return {"url": url, "http": e.code, "libre": e.code == 404}
    except Exception as e:   # sin red o DNS: no se sabe
        return {"url": url, "http": None, "libre": None, "motivo": "%s: %s" % (type(e).__name__, str(e)[:80])}


def choque(escaneo):
    an = [a for a in escaneo.get("anuncios", []) if a.get("activo")]
    return {"anuncios_activos": len(an), "anunciantes": len({a.get("pagina_id") for a in an}),
            "declarados": escaneo.get("declarados"), "parcial_motivo": escaneo.get("parcial_motivo")}


def medir(of, opciones, pais="ALL", prohibidos=(), ejecutar=None, abrir=None):
    d = rutas.ruta("ofertas", of, "entradas", "nombre")
    out = []
    for o in opciones:
        f = d / ("n_%s.json" % cazar._slug(o["marca"]))
        r = {"ok": True}
        if not f.exists():
            r = cazar.leer(["--busqueda", o["marca"], "--pais", pais, "--exacta", "--scrolls", "1"], f, ejecutar=ejecutar)
        esc = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
        x = dict(o, reglas=reglas(o, prohibidos), biblioteca=choque(esc) if esc else {"error": r.get("motivo")},
                 subdominio=sonda_subdominio(o["slug"], **({"abrir": abrir} if abrir else {})))
        out.append(x)
    return out


def elegir(medidas):
    def clave(x):
        b = x.get("biblioteca") or {}
        return (bool(x["reglas"]), b.get("anunciantes") is None, b.get("anunciantes") or 0,
                x["subdominio"].get("libre") is not True, len(x["marca"]))
    validas = [x for x in medidas if not x["reglas"] and (x.get("biblioteca") or {}).get("anunciantes") == 0]
    orden = sorted(medidas, key=clave)
    return (orden[0] if validas else None), orden


def main(argv=None):
    ap = argparse.ArgumentParser(description="Nombre coherente (F18/D83): mide 5 opciones y propone una.")
    ap.add_argument("orden", choices=("medir", "validar"))
    ap.add_argument("--of", required=True)
    ap.add_argument("--opciones")
    ap.add_argument("--pais", default="ALL")
    ap.add_argument("--prohibidos", default="", help="nombres de la referencia y su traducción, separados por comas")
    a = ap.parse_args(argv)
    destino = rutas.ruta("ofertas", a.of, "nombre.json")
    if a.orden == "validar":
        d = json.loads(destino.read_text(encoding="utf-8")) if destino.exists() else {}
        ok = bool(d.get("elegido")) and not d["elegido"].get("reglas")
        print(json.dumps({"ok": ok, "codigo": 0 if ok else 1, "motivo": "nombre elegido sin choques" if ok else "sin nombre válido"}))
        return 0 if ok else 1
    opciones = json.loads(Path(a.opciones).read_text(encoding="utf-8"))
    medidas = medir(a.of, opciones, a.pais, [p for p in a.prohibidos.split(",") if p.strip()])
    elegido, orden = elegir(medidas)
    doc = {"of": a.of, "medido_en": rutas.ahora().isoformat(timespec="seconds"), "pais_busqueda": a.pais,
           "metodo": "frase exacta de la marca en la Biblioteca pública (anónima) + GET al subdominio de Netlify + reglas F18/D83",
           "opciones": orden, "elegido": elegido,
           "motivo": ("sin anunciantes con esa frase, reglas en verde%s" % (
               ", subdominio libre" if elegido and elegido["subdominio"].get("libre") else ", subdominio [PENDIENTE]")) if elegido
           else "[PENDIENTE: nombre] ninguna opción pasó sin choque", "estado": "propuesta para veto del dueño"}
    rutas.escribir_json(destino, doc)
    print(json.dumps({"ok": bool(elegido), "codigo": 0 if elegido else 1,
                      "elegido": elegido and {"marca": elegido["marca"], "titulo": elegido["titulo"]}}, ensure_ascii=False))
    return 0 if elegido else 1


if __name__ == "__main__":
    sys.exit(main())
