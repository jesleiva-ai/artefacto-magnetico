"""Onboarding en seco: verifica cuentas y datos locales sin pasar secretos por el chat.

Origen: Hyperflujo (D-n) [PENDIENTE: número]; inspirado en hyperflujo/operacion/ (entorno verificado).
- Lee solo NOMBRES de variables de .env.ejemplo y reporta en .env "disponible / no disponible" (regla 9).
- Revisa datos/<nombre>.local.json; con --crear-locales copia el .ejemplo si falta (nunca sobrescribe).
- Marca como pendiente todo valor que siga con marcador [..] o null.
- Verificación en vivo: solo con un `transporte` inyectado (consumo cero por defecto).
Última línea de stdout: JSON {"ok","codigo","motivo","artefactos"}.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import rutas  # noqa: E402

DATOS = ["topes", "cuentas", "dueno", "autorizaciones", "config"]


def nombres_env(p):
    if not p.exists():
        return []
    out = []
    for linea in p.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if linea and not linea.startswith("#") and "=" in linea:
            out.append(linea.split("=", 1)[0].strip())
    return out


def env_disponibles(nombres, p):
    vals = {}
    if p.exists():
        for linea in p.read_text(encoding="utf-8").splitlines():
            if "=" in linea and not linea.strip().startswith("#"):
                k, v = linea.split("=", 1)
                vals[k.strip()] = bool(v.strip().strip('"').strip("'"))
    return {n: ("disponible" if vals.get(n) else "no disponible") for n in nombres}


def pendientes(obj, prefijo=""):
    res = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if str(k).startswith("_"):
                continue
            res += pendientes(v, f"{prefijo}{k}.")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            res += pendientes(v, f"{prefijo}{i}.")
    elif obj is None or (isinstance(obj, str) and obj.startswith("[")):
        res.append(prefijo.rstrip("."))
    return res


def revisar_datos(crear):
    informe, creados = {}, []
    for n in DATOS:
        local = rutas.ruta("datos", f"{n}.local.json")
        ejemplo = rutas.ruta("datos", f"{n}.ejemplo.json")
        if not local.exists() and crear and ejemplo.exists():
            shutil.copyfile(ejemplo, local)
            creados.append(f"datos/{n}.local.json")
        if not local.exists():
            informe[n] = {"estado": "falta", "accion": f"copiar datos/{n}.ejemplo.json a datos/{n}.local.json y completarlo"}
            continue
        try:
            pend = pendientes(rutas.leer_json(local))
        except Exception as e:  # JSON roto
            informe[n] = {"estado": "invalido", "motivo": type(e).__name__}
            continue
        informe[n] = {"estado": "completo" if not pend else "pendiente", "campos_pendientes": pend[:20]}
    return informe, creados


def verificar_en_vivo(cuentas, transporte=None):
    if transporte is None:
        return {"estado": "omitido", "motivo": "consumo cero: sin transporte inyectado"}
    return {k: transporte(k, v) for k, v in (cuentas or {}).items() if not str(k).startswith("_")}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Onboarding en seco: cuentas, .env y datos locales (sin mostrar secretos).")
    ap.add_argument("--crear-locales", action="store_true", help="copia datos/*.ejemplo.json a *.local.json si faltan")
    a = ap.parse_args(argv)
    env = env_disponibles(nombres_env(rutas.ruta(".env.ejemplo")), rutas.ruta(".env"))
    datos, creados = revisar_datos(a.crear_locales)
    cuentas = rutas.leer_json(rutas.ruta("datos", "cuentas.local.json"), defecto=None)
    vivo = verificar_en_vivo(cuentas)
    print(json.dumps({"env": env, "datos": datos, "en_vivo": vivo}, ensure_ascii=False, indent=2))
    faltan = [n for n, d in datos.items() if d["estado"] != "completo"]
    ok = not faltan and all(v == "disponible" for v in env.values())
    motivo = "todo configurado" if ok else "pendiente: " + ", ".join(faltan + [k for k, v in env.items() if v != "disponible"])
    print(json.dumps({"ok": ok, "codigo": 0 if ok else 3, "motivo": motivo, "artefactos": creados}, ensure_ascii=False))
    return 0 if ok else 3


if __name__ == "__main__":
    sys.exit(main())
