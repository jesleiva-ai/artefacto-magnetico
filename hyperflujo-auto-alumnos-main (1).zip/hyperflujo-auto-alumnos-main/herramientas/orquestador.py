#!/usr/bin/env python3
"""orquestador.py — corrida diaria del núcleo (Hyperflujo, TAREA 035; corregido tras la revisión adversarial 035).

Para cada producto de estado.py decide UNA acción y qué worker la ejecuta. No llama a ningún proveedor: los workers se
lanzan a través de un `lanzador` inyectable. Hoy el único lanzador es `lanzador_simulado`.

Vía real (TAREA 036): `director.py` construye el lanzador con `lanzar_worker.py` (claude -p con entorno acotado,
--max-budget-usd y timeout duro) y las herramientas sin modelo (lectores, pausa). Esta CLI con --simular sigue
disponible solo con un archivo de estado temporal; sin --simular delega en director.py.

Reglas (revisión 035):
  * Ciclo (TAREA 037 A): por_cazar →(cazar, verificado con cazar.verificar_cazada)→ candidato →(el dueño confirma en
    estado/decisiones.jsonl; si veta la caza entera, recazar)→ producir.
  * Ciclo: candidato → producido → en_revision → hotmart_enviado → lista_para_activar → activo (h. 4). Se pasa a
    lista_para_activar solo si la lectura del worker confirma Hotmart aprobado y HTTP 200 en landing y checkout.
    TAREA 037 B: en lista_para_activar, sin campaña registrada (compuerta «campana») → crear_campana (gasto_meta, D103)
    → campana_en_pausa solo con la relectura verificada → activar. Al activar se repite la compuerta D103 y el
    director vuelve a sondear Hotmart, landing y checkout en esa misma corrida. D119: sin compuerta de testimonios.
  * Activar exige autorización vigente «activar_campana», cupo en datos/topes.local.json (h. 8), freno apagado (h. 10)
    y relectura de Meta = ACTIVE. Producir exige cupo de nuevos por día. Sin topes: falla cerrado.
  * activo/escalando: D92 (Hyperflujo, máxima) y después meta_operacion.decidir (Matías: 48 h, ROAS >= 2 con netos de
    Hotmart, reemplazo solo con ROAS < 2) (h. 5 y 15). El reloj arranca con la primera lectura con gasto > 0 (h. 10).
  * Lectura caída: sin lectura completa durante `horas_max_sin_lectura` → pausa técnica (h. 3). Nunca se decide con nulos.
  * Bajar/pausar: el estado cambia solo si el worker devuelve la relectura `estado_meta == "PAUSED"` (h. 2).
  * Fallos: try/except por producto, bajas primero, fallos acumulados entre días, códigos 5/6/8 → bloqueada_humano (h. 11).
"""
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import estado as E  # noqa: E402
import meta_operacion  # noqa: E402  (D92 y decidir)
import topes as T  # noqa: E402

# estado → (acción, worker, estado destino si el worker verifica OK)
ACCIONES = {
    "por_cazar": ("cazar", "worker-cazar", "candidato"),   # TAREA 037 A: caza en la Biblioteca pública, verificada por artefacto
    "candidato": ("producir", "worker-produccion", "producido"),
    "producido": ("revisar", "worker-revision", "en_revision"),
    "en_revision": ("publicar", "worker-publicacion", "hotmart_enviado"),
    "hotmart_enviado": ("verificar", "worker-verificacion", "lista_para_activar"),
    "lista_para_activar": ("activar", "director-activar", "activo"),   # sin campaña registrada → crear_campana (037 B)
    "campana_en_pausa": ("activar", "director-activar", "activo"),     # TAREA 037 B: creada y releída en PAUSED
}
REQUIERE_AUTORIZACION = {"publicar": "publicar", "activar": "activar_campana", "escalar": "escalar",
                         "crear_campana": "gasto_meta"}   # el hook exige gasto_meta para ads_create_* (037 B)
CODIGOS_HUMANOS = {   # hotmart_alta.mjs: 5 sesión vencida, 6 captcha, 8 sin OK
    5: "Sesión de Hotmart vencida: iniciar sesión en el Chrome del robot (perfil en operacion/sesiones/) y esperar la próxima corrida.",
    6: "Captcha o verificación en Hotmart: resolverlo a mano en el Chrome del robot.",
    8: "Falta el OK escrito para publicar: cargar la autorización vigente en datos/autorizaciones.local.json.",
}
# Techo de un día de Meta cuando la lectura vino nula: Meta puede gastar hasta un 75 % más que el diario en un día
# (promedio semanal acotado). [PENDIENTE: cita de la documentación oficial de Meta; igual que pausa_seguridad].
TECHO_DIARIO_META = 1.75
PRIORIDAD = {"en_baja": 0, "activo": 0, "escalando": 0, "rechazo_meta": 1, "pausada_tecnica": 1}


def cargar_reglas(raiz=None):
    return meta_operacion.reglas_de_json(raiz)


def _dt(x, ref=None):
    if x is None:
        return None
    try:
        d = datetime.fromisoformat(x) if isinstance(x, str) else x
    except ValueError:
        return None
    if d.tzinfo is None and ref is not None and ref.tzinfo is not None:
        d = d.replace(tzinfo=ref.tzinfo)
    return d


def activada_en(producto):
    """Hora de la activación (lista_para_activar → activo) según el historial; None si nunca se activó."""
    for h in reversed(producto.get("historial", [])):
        if h.get("a") == "activo" and h.get("de") == "lista_para_activar":
            return _dt(h.get("hora"))
    return None


def _ahora():
    try:
        import rutas
        return rutas.ahora()
    except Exception:
        return datetime.now().astimezone()


def _base(producto):
    return {"of": producto["of"], "estado": producto["estado"], "worker": None, "destino": None}


def decidir(producto, reglas=None, autorizaciones=(), ahora=None, contexto=None):
    """Devuelve {"of","estado","accion","worker","destino","motivo"}; no modifica nada.

    contexto: {"topes": dict|None, "error_topes": str|None, "activos": int, "diarios_activos": float,
               "nuevos_hoy": int, "freno": str|None}."""
    R = dict(meta_operacion.REGLAS, **(reglas or {}))
    ctx = contexto or {}
    ahora = ahora or _ahora()
    base = _base(producto)
    st = producto["estado"]
    if st == "retirado":
        return {**base, "accion": "nada", "motivo": "retirado"}
    if st == "bloqueada_humano":
        b = producto.get("bloqueo") or {}
        return {**base, "accion": "esperar", "bloqueo": True,
                "motivo": "BLOQUEADA: %s | acción humana: %s" % (b.get("motivo", "?"), b.get("accion_humana", "[PENDIENTE]"))}
    if st == "fallida":
        return {**base, "accion": "esperar", "bloqueo": True, "motivo": "fallida: revisar el historial y retirar o reiniciar"}
    if st in ACCIONES:
        accion, worker, destino = ACCIONES[st]
        comp = (ctx.get("compuertas") or {})
        if st == "candidato" and comp.get("candidato"):   # TAREA 037 A: el dueño confirma o veta el candidato de la caza
            e_c, m_c = comp["candidato"](producto)
            if e_c == "esperando":
                return {**base, "accion": "esperar", "motivo": m_c}
            if e_c == "vetado":
                return {**base, "accion": "recazar", "destino": "por_cazar", "motivo": m_c}   # transición interna
        if st in ("lista_para_activar", "campana_en_pausa") and comp.get("anuncios"):   # D103: validar_anuncios antes de la campaña
            ok_a, m_a = comp["anuncios"](producto)
            if not ok_a:
                return {**base, "accion": "esperar", "motivo": "D103: " + m_a}
        if st == "lista_para_activar" and comp.get("campana") and not comp["campana"](producto):
            # TAREA 037 B: sin campaña completa y releída → se crea en pausa (nunca se activa en esta etapa)
            accion, worker, destino = "crear_campana", "worker-campana", "campana_en_pausa"
        aut = REQUIERE_AUTORIZACION.get(accion)
        if aut and aut not in autorizaciones:
            return {**base, "accion": "esperar", "motivo": f"falta autorización escrita vigente «{aut}»"}
        if accion in ("producir", "activar", "crear_campana"):
            if ctx.get("topes") is None:
                return {**base, "accion": "esperar",
                        "motivo": "[PENDIENTE: topes] %s" % (ctx.get("error_topes") or "sin topes: falla cerrado")}
            if accion == "producir":
                ok, mot = T.cupo_producir(ctx["topes"], ctx.get("nuevos_hoy", 0))
            elif accion == "crear_campana":   # crear en pausa no gasta: los topes de la campaña los controla meta_campana
                ok, mot = (False, "freno de activaciones: %s" % ctx["freno"]) if ctx.get("freno") else (True, "ok")
            else:
                if ctx.get("freno"):
                    return {**base, "accion": "esperar", "motivo": "freno de activaciones: %s" % ctx["freno"]}
                diario = (producto.get("campana") or {}).get("diario")
                ok, mot = T.cupo_activar(ctx["topes"], ctx.get("activos", 0), ctx.get("diarios_activos", 0), diario)
                if ok:   # TAREA 036 parte C: tope mensual global (Meta del mes + libro de gasto)
                    ok, mot = T.cupo_mensual(ctx["topes"], ctx.get("gasto_mes", 0), diario)
            if not ok:
                return {**base, "accion": "esperar", "motivo": "sin cupo: " + mot}
        return {**base, "accion": accion, "worker": worker, "destino": destino, "motivo": "siguiente etapa"}
    if st == "en_baja":   # solo se llega con la pausa ya confirmada por relectura
        return {**base, "accion": "retirar", "destino": "retirado",
                "motivo": "campaña pausada y confirmada por relectura: se da por muerto (D92)"}
    if st == "pausada_tecnica":
        return {**base, "accion": "esperar", "bloqueo": True,
                "motivo": "pausa técnica por lectura caída: revisar las credenciales de lectura; reactivar exige autorización «reactivar»"}
    if st == "rechazo_meta":
        return {**base, "accion": "reponer", "worker": "worker-reponer-rechazo", "destino": "lista_para_activar",
                "motivo": "anuncios rechazados por Meta: reponer desde RES- y volver a revisión de activación"}
    # activo / escalando
    tot = E.acumulado(producto)
    act = activada_en(producto)
    act = _dt(act, ahora) if act else None
    entrega = _dt(producto.get("primera_entrega_en"), ahora)
    if tot["rechazados"] and entrega is None:
        return {**base, "accion": "marcar_rechazo", "destino": "rechazo_meta", "bloqueo": True,
                "motivo": "%d anuncio(s) rechazado(s) por Meta sin entrega: el reloj de D92 no arranca" % tot["rechazados"]}
    ultima = _dt(producto.get("ultima_lectura_en"), ahora)
    ref = max([x for x in (act, ultima) if x is not None], default=None)
    limite = timedelta(hours=R["horas_max_sin_lectura"])
    nulos = any(v is None for v in (tot["gasto"], tot["ventas"], tot["ingresos"]))
    if ref is not None and (ahora - ref) >= limite and (ultima is None or (ahora - ultima) >= limite or nulos):
        return {**base, "accion": "pausa_tecnica", "worker": "director-pausar", "destino": "pausada_tecnica",
                "motivo": "%s h o más sin lectura completa de gasto/ventas/netos: pausa preventiva (nulo ≠ 0)" % R["horas_max_sin_lectura"]}
    camp = producto.get("campana") or {}
    tope_max = camp.get("diario_max")
    if ctx.get("topes") is not None and tope_max is not None:
        libre = ctx["topes"]["tope_diario_global_usd"] - (ctx.get("diarios_activos", 0) - (camp.get("diario") or 0))
        tope_max = min(tope_max, libre)
    hoy = ahora.date().isoformat()
    mctx = {"activada_en": entrega, "ventas": tot["ventas"], "netos": tot["ingresos"], "gasto": tot["gasto"],
            "diario": camp.get("diario"), "tope_diario_max": tope_max, "precio": camp.get("precio"),
            "anuncios": producto.get("anuncios") or [], "ultima_subida": _dt(producto.get("ultima_subida"), ahora),
            "ultimo_cambio_anuncios": _dt(producto.get("ultimo_cambio_anuncios"), ahora),
            "cambios_hoy": producto.get("cambios_hoy") if producto.get("cambios_hoy_fecha") == hoy else None}
    if entrega is None:
        return {**base, "accion": "esperar", "motivo": "sin primera entrega (gasto > 0) leída: el reloj de D92 no arrancó"}
    a = meta_operacion.decidir(mctx, ahora=ahora, reglas=R)[0]
    t = a["tipo"]
    if t == "meta_pausar":
        return {**base, "accion": "bajar", "worker": "director-pausar", "destino": "en_baja",
                "motivo": "%s: %s" % (a["regla"], a["motivo"]), "regla": a["regla"]}
    if t == "meta_presupuesto":
        if "escalar" not in autorizaciones:
            return {**base, "accion": "esperar", "motivo": "ROAS para escalar, pero falta autorización escrita vigente «escalar»"}
        if ctx.get("topes") is not None:
            ok, mot = T.cupo_mensual(ctx["topes"], ctx.get("gasto_mes", 0), a["parametros"].get("nuevo_diario"))
            if not ok:
                return {**base, "accion": "esperar", "motivo": "ROAS para escalar, pero " + mot}
        return {**base, "accion": "escalar", "worker": "worker-escalar", "destino": "escalando" if st == "activo" else None,
                "motivo": a["motivo"], "regla": a["regla"], "parametros": a["parametros"], "marca": "ultima_subida"}
    if t.startswith("meta_pausar_anuncio"):
        return {**base, "accion": "reemplazar", "worker": "worker-reemplazo", "destino": None, "motivo": a["motivo"],
                "regla": a["regla"], "parametros": a["parametros"], "marca": "ultimo_cambio_anuncios"}
    if t == "pedir_reserva":
        return {**base, "accion": "esperar", "motivo": a["motivo"]}
    if a["regla"] == "D92":   # sin_datos
        return {**base, "accion": "esperar", "motivo": "D92 sin datos: " + a["motivo"]}
    return {**base, "accion": "mantener", "motivo": "%s: %s" % (a["regla"], a["motivo"])}


def lanzador_simulado(decision):
    """Doble del worker para pruebas y ensayo: verifica OK, devuelve las relecturas que exige cada acción, consumo 0."""
    r = {"ok": True, "simulado": True, "consumo": 0}
    if decision["accion"] in ("bajar", "pausa_tecnica"):
        r["estado_meta"] = "PAUSED"
    if decision["accion"] == "activar":
        r["estado_meta"] = "ACTIVE"
    if decision["accion"] == "verificar":
        r.update(hotmart_aprobado=True, landing_http=200, checkout_http=200)
    if decision["accion"] == "crear_campana":
        r["campana_en_pausa"] = True
    if decision["accion"] == "cazar":
        r["cazada"] = True
    return r


def _resultado_ok(d, r):
    """La transición exige la relectura propia de cada acción (h. 2 y 4)."""
    if not r.get("ok"):
        return False, r.get("motivo") or "el worker devolvió ok=false"
    if d["accion"] in ("bajar", "pausa_tecnica") and r.get("estado_meta") != "PAUSED":
        return False, "pausa no confirmada por relectura de Meta (estado_meta=%s)" % r.get("estado_meta")
    if d["accion"] == "activar" and r.get("estado_meta") != "ACTIVE":
        return False, "activación no confirmada por relectura de Meta"
    if d["accion"] == "cazar" and r.get("cazada") is not True:   # 037 A: vale cazar.verificar_cazada, no el texto del worker
        return False, r.get("motivo") or "caza no verificada por artefacto (cazar.verificar_cazada)"
    if d["accion"] == "crear_campana" and r.get("campana_en_pausa") is not True:   # 037 B: verificada por relectura
        return False, r.get("motivo") or "campaña en pausa no verificada por relectura (meta_campana.verificar_campana_en_pausa)"
    return True, ""


def _contexto(prods, topes, error_topes, fecha, reglas, ahora):
    activos = [p for p in prods if p["estado"] in E.ACTIVOS]
    nuevos_hoy = sum(1 for p in prods if any(h.get("de") == "candidato" and h.get("a") == "producido" and
                                             not (h.get("datos") or {}).get("importado") and   # 037 D: la importación no produce
                                             str(h.get("hora", "")).startswith(fecha) for h in p.get("historial", [])))
    desde = (ahora - timedelta(days=7)).date().isoformat()
    rech = sum((m.get("rechazados") or 0) for p in prods for f, m in p.get("mediciones", {}).items() if f >= desde)
    freno = None
    if rech >= reglas.get("freno_rechazos_7d", meta_operacion.REGLAS["freno_rechazos_7d"]):
        freno = "%d anuncios rechazados por Meta en 7 días" % rech
    mes = fecha[:8] + "01"
    gasto_mes = 0.0
    for p in prods:   # un día con gasto nulo cuenta como su techo (diario × 1,75), nunca como 0; sin diario = nulo
        techo = ((p.get("campana") or {}).get("diario") or 0) * TECHO_DIARIO_META or None
        for f, m in p.get("mediciones", {}).items():
            if mes <= f <= fecha:
                g = m.get("gasto") if m.get("gasto") is not None else techo
                gasto_mes = None if (gasto_mes is None or g is None) else gasto_mes + g
    try:
        libro = T.gastado(desde=mes, hasta=fecha, en_usd=True)
    except T.TopesFaltantes:
        libro = None
    gasto_mes = None if (gasto_mes is None or libro is None) else round(gasto_mes + libro, 2)
    return {"topes": topes, "error_topes": error_topes, "activos": len(activos), "gasto_mes": gasto_mes,
            "diarios_activos": sum((p.get("campana") or {}).get("diario") or 0 for p in activos),
            "nuevos_hoy": nuevos_hoy, "freno": freno}


def corrida_diaria(fecha, archivo=None, reglas=None, autorizaciones=(), lanzador=None, max_intentos=2, topes=None,
                   umbrales=None, modo="principal", paralelo_max=1, compuertas=None, solo=None, excluir=()):
    """autorizaciones: iterable de alcances o función oferta → set (autorizaciones.vigentes).
    modo: «principal» (todo) o «pulso» (avanza lo que está en curso, no abre productos nuevos: no hay «producir»).
    paralelo_max: workers simultáneos (1 = en serie). En paralelo se decide todo primero, con reservas de cupo para que
    dos activaciones no pasen el mismo tope, se lanzan los workers acotados y después se aplica en serie.
    umbrales: ignorado (compatibilidad; la clave «umbrales» no existe en reglas_operacion.json, revisión 035 h. 5)."""
    lanzador = lanzador or lanzador_simulado
    reglas = cargar_reglas() if reglas is None else reglas
    error_topes = None
    try:
        topes = T.cargar() if topes is None else T.validar(topes)
    except T.TopesFaltantes as e:
        topes, error_topes = None, str(e)
    ahora = _ahora()
    resultados, pendientes = [], []
    reserva = {"activos": 0, "diarios": 0.0, "nuevos": 0}
    orden = sorted(E.productos(archivo=archivo), key=lambda p: PRIORIDAD.get(p["estado"], 2))   # bajas primero
    if solo:   # TAREA 037 D: corrida supervisada de un solo producto (los demás no se tocan; cuentan para topes y cupos)
        orden = [p for p in orden if p["of"] == solo]
    orden = [p for p in orden if p["of"] not in (excluir or ())]   # TAREA 041: «no_operar», los opera otra persona
    for p0 in orden:
        p = E.obtener(p0["of"], archivo)
        try:
            auts = autorizaciones(p["of"]) if callable(autorizaciones) else autorizaciones
            ctx = _contexto(E.productos(archivo=archivo), topes, error_topes, fecha, reglas, ahora)
            ctx["compuertas"] = compuertas or {}
            if paralelo_max > 1:
                ctx.update(activos=ctx["activos"] + reserva["activos"], diarios_activos=ctx["diarios_activos"] + reserva["diarios"],
                           nuevos_hoy=ctx["nuevos_hoy"] + reserva["nuevos"])
            d = decidir(p, reglas, auts, ahora=ahora, contexto=ctx)
            if modo == "pulso" and d["accion"] == "producir":
                d.update(accion="esperar", worker=None, destino=None, motivo="pulso: no abre productos nuevos")
            if d["worker"] and paralelo_max > 1:
                if d["accion"] == "activar":
                    reserva["activos"] += 1
                    reserva["diarios"] += (p.get("campana") or {}).get("diario") or 0
                if d["accion"] == "producir":
                    reserva["nuevos"] += 1
                pendientes.append((p, d))
                continue
            if d["worker"]:
                _aplicar(p, d, _lanzar_seguro(lanzador, d), ahora, max_intentos, archivo)
            elif d.get("destino"):   # transiciones internas sin efecto externo (retirar tras pausa confirmada, marcar rechazo)
                E.transicionar(p["of"], d["destino"], f"{d['accion']}: {d['motivo']}", archivo=archivo)
        except Exception as e:   # error propio con este producto: se anota y se sigue con el resto
            d = {**_base(p), "accion": "fallo", "motivo": "error del orquestador: %s: %s" % (type(e).__name__, e),
                 "resultado": {"ok": False}, "bloqueo": True}
        resultados.append(d)
    if pendientes:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=paralelo_max) as pool:
            salidas = list(pool.map(lambda pd: _lanzar_seguro(lanzador, pd[1]), pendientes))
        for (p, d), r in zip(pendientes, salidas):
            try:
                _aplicar(E.obtener(p["of"], archivo), d, r, ahora, max_intentos, archivo)
            except Exception as e:
                d.update(accion="fallo", motivo="error del orquestador: %s: %s" % (type(e).__name__, e), bloqueo=True)
            resultados.append(d)
    return resultados


def _lanzar_seguro(lanzador, d):
    try:
        return lanzador(d) or {}
    except Exception as e:   # el fallo de un worker no corta la corrida (h. 11)
        return {"ok": False, "motivo": "%s: %s" % (type(e).__name__, e)}


def _aplicar(p, d, r, ahora, max_intentos, archivo):
    """Aplica el resultado de un worker o de una herramienta: la transición exige la relectura propia de cada acción."""
    d["resultado"] = r
    if r.get("espera"):   # tope, autorización o freno: no es un fallo, se reevalúa en la próxima corrida
        d.update(accion="esperar", motivo=r.get("motivo") or "en espera")
        return
    if r.get("transicion"):   # la herramienta pide otro destino que el de la etapa
        E.transicionar(p["of"], r["transicion"], "%s: %s" % (d["accion"], r.get("motivo")), archivo=archivo,
                       datos=r.get("datos"))
        d.update(accion=r.get("accion_final") or d["accion"], motivo=r.get("motivo") or d["motivo"], destino=r["transicion"])
        return
    ok, motivo = _resultado_ok(d, r)
    if d["accion"] == "verificar" and ok and not (r.get("hotmart_aprobado") is True and
                                                   r.get("landing_http") == 200 and r.get("checkout_http") == 200):
        d.update(accion="esperar", motivo=r.get("motivo_espera") or "esperando aprobación de Hotmart o landing/checkout sin HTTP 200 "
                 "(hotmart_aprobado=%s, landing=%s, checkout=%s)" % (r.get("hotmart_aprobado"), r.get("landing_http"), r.get("checkout_http")))
    elif ok:
        E.reiniciar_fallos(p["of"], d["accion"], archivo=archivo)
        if d.get("marca"):
            E.marcar(p["of"], d["marca"], ahora.isoformat(timespec="seconds"), archivo=archivo)
            E.marcar(p["of"], "cambios_hoy", [d["accion"]], archivo=archivo)
            E.marcar(p["of"], "cambios_hoy_fecha", ahora.date().isoformat(), archivo=archivo)
        if d["destino"]:
            E.transicionar(p["of"], d["destino"], f"{d['accion']} ({d['worker']}): {d['motivo']}", archivo=archivo)
        if d["accion"] == "bajar" and d.get("regla") == "D92b":   # D106: sin ninguna venta → la corrida lanza otro producto
            E.marcar(p["of"], "reemplazo_pendiente", True, archivo=archivo)
    else:
        _registrar_fallo(p, d, r, motivo, max_intentos, archivo)


def _registrar_fallo(p, d, r, motivo, max_intentos, archivo):
    codigo = r.get("codigo")
    n = E.registrar_fallo(p["of"], d["accion"], motivo, codigo=codigo, archivo=archivo)
    d["motivo"] = "falló «%s» (%d/%d): %s" % (d["accion"], n, max_intentos, motivo)
    if codigo in CODIGOS_HUMANOS or r.get("humano"):
        humana = r.get("accion_humana") or CODIGOS_HUMANOS.get(codigo) or "revisar el log del worker"
        E.transicionar(p["of"], "bloqueada_humano", motivo, archivo=archivo,
                       datos={"codigo": codigo, "accion_humana": humana, "etapa": d["accion"]})
        d.update(accion="bloqueado", bloqueo=True, motivo="BLOQUEADA (código %s): %s" % (codigo, humana))
    elif n >= max_intentos:
        operando = p["estado"] in E.ACTIVOS + ("rechazo_meta", "pausada_tecnica")
        humana = ("pausar a mano en el Administrador de anuncios y confirmar" if operando
                  else "revisar el log del worker y reiniciar o retirar el producto")
        destino = "bloqueada_humano" if operando else "fallida"
        E.transicionar(p["of"], destino, motivo, archivo=archivo,
                       datos={"codigo": codigo, "accion_humana": humana, "etapa": d["accion"], "fallos": n})
        d.update(accion="bloqueado", bloqueo=True, motivo="%s tras %d fallos en «%s»: %s" % (destino, n, d["accion"], humana))


if __name__ == "__main__":
    import argparse
    from datetime import date
    ap = argparse.ArgumentParser(description="Corrida diaria. Sin --simular delega en director.py (vía real, TAREA 036).")
    ap.add_argument("--simular", action="store_true", help="lanzador simulado; exige --estado temporal")
    ap.add_argument("--estado", help="con --simular: archivo de estado TEMPORAL; nunca estado/productos.json")
    a, resto = ap.parse_known_args()
    if not a.simular:
        import director
        sys.exit(director.main(resto + (["--estado", a.estado] if a.estado else [])))
    if not a.estado:
        sys.exit("--simular exige --estado <archivo temporal>")
    if Path(a.estado).resolve() == Path(E.archivo_defecto()).resolve():
        sys.exit("--simular sobre el estado real está prohibido: el estado quedaría mintiendo (revisión 035 h. 1)")
    for r in corrida_diaria(date.today().isoformat(), archivo=a.estado):
        print(r["of"], r["estado"], "→", r["accion"], r.get("worker") or "", "|", r["motivo"])
