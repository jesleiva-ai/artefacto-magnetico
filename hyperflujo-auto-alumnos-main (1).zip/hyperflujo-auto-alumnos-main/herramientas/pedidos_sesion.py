#!/usr/bin/env python3
"""pedidos_sesion.py — la sesión de Claude Code como lanzador de workers (TAREA 041 Parte 1 A: /lanzar y /operar).

Con `director.py --via sesion` el director no abre `claude -p`: deja un PEDIDO de worker y la sesión interactiva (el
director humano-asistido del prompt inicial) lo corre como subagente. Decide igual el código: el pedido sale de
orquestador.decidir, los tickets del plan del día los emite el director, y la corrida siguiente verifica la salida
del worker por artefacto (lanzar_worker.verificar_artefactos, regla 7) antes de cambiar el estado.

    estado/pedidos/<OF>_<accion>.json         pedido: of, accion, modelo, intentos, tickets, vence_en, estado
    estado/pedidos/<OF>_<accion>.prompt.md    lo que lee el subagente: prompt de la etapa + skill + dónde dejar la salida
    ofertas/<OF>/pedidos/<OF>_<accion>.salida.json   lo escribe el worker (JSON de plantillas/esquemas/worker_salida.json)
    estado/sesion_worker.json                 producto del worker en curso: el hook guardian_gasto lo usa cuando no hay
                                              HYPERFLUJO_OF (los subagentes comparten el entorno de la sesión)

Ciclo: recoger() devuelve el resultado si el worker dejó su salida; si no, crear() deja (o mantiene) el pedido y
devuelve «espera». Un pedido vencido sin salida se reintenta una vez; el segundo vencido = fallo (CLAUDE.md regla 14).
Solo biblioteca estándar.
"""
import json
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

INTENTOS = 2


def id_pedido(of, accion):
    return "%s_%s" % (rutas.validar_of(of), accion)


def ruta_pedido(pid, ext=".json"):
    return rutas.ruta("estado", "pedidos", pid + ext)


def ruta_salida(of, pid):
    return rutas.ruta("ofertas", of, "pedidos", pid + ".salida.json")


def _rel(p):
    return os.path.relpath(p, rutas.RAIZ).replace("\\", "/")


def _vencido(pedido, ahora=None):
    try:
        return (ahora or rutas.ahora()) > datetime.fromisoformat(pedido["vence_en"])
    except (KeyError, ValueError, TypeError):
        return True


def _modelo(config, accion):
    import etapas
    rol = etapas.ETAPAS.get(accion, {}).get("rol")
    m = ((config or {}).get("modelos") or {}).get(rol) or {"produce": "opus", "revisa": "sonnet", "mecanico": "haiku"}.get(rol, "sonnet")
    return "sonnet" if m == "fable" else m   # Ramiro, TAREA 041: Fable no se usa para workers


def _prompt(decision, pid, fecha):
    import etapas
    import lanzar_worker as LW
    d = etapas.definicion(decision["accion"])
    skill = rutas.ruta(d["skill"]) if d.get("skill") else None
    salida = _rel(ruta_salida(decision["of"], pid))
    allowed, disallowed = etapas.herramientas_worker(decision["accion"])
    partes = []
    real = os.path.normcase(os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")))
    if os.path.normcase(os.path.realpath(str(rutas.RAIZ))) != real:   # corrida en seco sobre una copia (HYPERFLUJO_RAIZ)
        raiz = str(rutas.RAIZ)
        partes.append("# RAÍZ DE ESTA CORRIDA (en seco): %s\n\nTodas las rutas relativas de este pedido (ofertas/, estado/, "
                      "datos/…) son relativas a esa carpeta: escribí y leé ahí con rutas absolutas. Cada comando python o "
                      "node de herramientas/ se corre con la variable puesta: en PowerShell `$env:HYPERFLUJO_RAIZ='%s'; "
                      "python herramientas/…`, en bash `HYPERFLUJO_RAIZ='%s' python herramientas/…`. No escribas nada en "
                      "%s. Nada se publica ni se gasta en esta corrida: si un paso lo necesita, anotalo en `pendientes` "
                      "y terminá." % (raiz, raiz, raiz, real))
    partes.append(LW.armar_prompt(decision, fecha))
    if skill and skill.exists():
        partes.append("---\n# Skill de la etapa (%s)\n\n%s" % (d["skill"], skill.read_text(encoding="utf-8")))
    partes.append("---\n# Cómo entregar (worker de la sesión)\n\n"
                  "- Sos un subagente de la sesión del director: hacés SOLO la etapa «%s» del producto %s.\n"
                  "- Herramientas de esta etapa: %s. Prohibidas: %s.\n"
                  "- No corras director.py, vigia.py, programar.py ni lanzar_worker.py, y no edites estado/.\n"
                  "- Al terminar escribí tu JSON final (esquema plantillas/esquemas/worker_salida.json, con cada artefacto "
                  "y su sha256) en `%s`, y devolvé ese mismo JSON como respuesta final. Sin ese archivo, la etapa no cuenta."
                  % (decision["accion"], decision["of"], ", ".join(allowed), ", ".join(disallowed), salida))
    return "\n\n".join(partes)


def recoger(decision):
    """→ resultado al estilo lanzar_worker.lanzar (con «tickets_pedido») si el worker dejó su salida; si no, None."""
    import lanzar_worker as LW
    pid = id_pedido(decision["of"], decision["accion"])
    p = ruta_pedido(pid)
    pedido = rutas.leer_json(p, defecto=None)
    s = ruta_salida(decision["of"], pid)
    if not pedido or pedido.get("estado") != "pendiente" or not s.exists():
        return None
    base = {"of": decision["of"], "accion": decision["accion"], "inicio": pedido.get("creado_en"), "via": "sesion",
            "consumo": 0, "costo_nominal_usd": None, "log": _rel(s), "tickets_pedido": pedido.get("tickets") or []}
    try:
        salida = json.loads(s.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        salida = None
    faltan = [k for k in LW.esquema_salida()["required"] if k not in (salida or {})] if isinstance(salida, dict) else ["todo"]
    if faltan:
        r = {**base, "ok": False, "codigo": 2, "salida": None, "motivo": "salida del worker ilegible o incompleta: faltan %s" % ", ".join(faltan)}
    elif salida.get("of") != decision["of"]:
        r = {**base, "ok": False, "codigo": 2, "salida": salida, "motivo": "la salida es de otro producto (%s)" % salida.get("of")}
    else:
        problemas = LW.verificar_artefactos(salida)
        if problemas:
            r = {**base, "ok": False, "codigo": 2, "salida": salida, "motivo": "verificación por artefacto fallida: " + "; ".join(problemas[:5])}
        elif salida.get("resultado") != "ok":
            r = {**base, "ok": False, "codigo": 2, "salida": salida,
                 "motivo": "el worker devolvió «%s»: %s" % (salida.get("resultado"), "; ".join(salida.get("pendientes", [])[:3]))}
        else:
            r = {**base, "ok": True, "codigo": 0, "salida": salida, "motivo": "worker de la sesión ok con artefactos verificados"}
    pedido.update(estado="entregado", entregado_en=rutas.ahora().isoformat(timespec="seconds"), ok=r["ok"])
    rutas.escribir_json(p, pedido)
    s.replace(s.with_name("%s.%s.salida.json" % (pid, rutas.ahora().strftime("%Y%m%dT%H%M%S"))))   # la próxima vuelta pide de nuevo
    _soltar(decision["of"])
    LW.registrar_trabajo({k: v for k, v in {**r, "fin": rutas.ahora().isoformat(timespec="seconds")}.items()
                          if k not in ("salida", "tickets_pedido")})
    return r


def crear(decision, *, config=None, fecha=None, minutos=60, emitir=None):
    """Deja el pedido (o mantiene el vigente) y devuelve «espera». emitir() emite los tickets: solo se llama al crear."""
    pid = id_pedido(decision["of"], decision["accion"])
    p = ruta_pedido(pid)
    previo = rutas.leer_json(p, defecto=None)
    ahora = rutas.ahora()
    if previo and previo.get("estado") == "pendiente" and not _vencido(previo, ahora):
        return {"ok": False, "espera": True, "consumo": 0, "pedido": pid,
                "motivo": "pedido de worker para la sesión en curso: %s (modelo %s)" % (pid, previo.get("modelo"))}
    intentos = (previo.get("intentos", 0) if previo and previo.get("estado") == "pendiente" else 0) + 1
    if intentos > INTENTOS:
        previo.update(estado="vencido")
        rutas.escribir_json(p, previo)
        _soltar(decision["of"])
        return {"ok": False, "codigo": 1, "consumo": 0, "pedido": pid,
                "motivo": "el worker de la sesión no entregó en %d intentos (%s): sin un tercero a ciegas" % (INTENTOS, pid)}
    tickets = emitir() if emitir else []
    pedido = {"id": pid, "of": decision["of"], "accion": decision["accion"], "motivo": decision.get("motivo"),
              "modelo": _modelo(config, decision["accion"]), "intentos": intentos, "tickets": tickets, "estado": "pendiente",
              "creado_en": ahora.isoformat(timespec="seconds"),
              "vence_en": (ahora + timedelta(minutes=minutos)).isoformat(timespec="seconds"),
              "prompt": _rel(ruta_pedido(pid, ".prompt.md")), "salida": _rel(ruta_salida(decision["of"], pid))}
    ruta_pedido(pid, ".prompt.md").parent.mkdir(parents=True, exist_ok=True)
    ruta_pedido(pid, ".prompt.md").write_text(_prompt(decision, pid, fecha), encoding="utf-8")
    ruta_salida(decision["of"], pid).parent.mkdir(parents=True, exist_ok=True)
    rutas.escribir_json(p, pedido)
    rutas.escribir_json(rutas.ruta("estado", "sesion_worker.json"),
                        {"of": decision["of"], "accion": decision["accion"], "pedido": pid, "vence_en": pedido["vence_en"]})
    return {"ok": False, "espera": True, "consumo": 0, "pedido": pid, "tickets": tickets,
            "motivo": "pedido de worker para la sesión: %s (modelo %s)" % (pid, pedido["modelo"])}


def cerrar(decision, motivo):
    """El director avanzó sin recoger la salida (p. ej. la caza ya verificada por artefacto): el pedido pendiente se
    cierra para que /lanzar no lo vuelva a correr. Devuelve True si había uno."""
    pid = id_pedido(decision["of"], decision["accion"])
    p = ruta_pedido(pid)
    pedido = rutas.leer_json(p, defecto=None)
    if not pedido or pedido.get("estado") != "pendiente":
        return False
    pedido.update(estado="cerrado", cerrado_en=rutas.ahora().isoformat(timespec="seconds"), motivo_cierre=motivo)
    rutas.escribir_json(p, pedido)
    s = ruta_salida(decision["of"], pid)
    if s.exists():
        s.replace(s.with_name("%s.%s.salida.json" % (pid, rutas.ahora().strftime("%Y%m%dT%H%M%S"))))
    _soltar(decision["of"])
    return True


def _soltar(of):
    p = rutas.ruta("estado", "sesion_worker.json")
    actual = rutas.leer_json(p, defecto=None)
    if actual and actual.get("of") == of:
        p.unlink()


def pendientes():
    """Pedidos que esperan a la sesión: [{id, of, accion, modelo, prompt, salida, vence_en}]."""
    d = rutas.ruta("estado", "pedidos")
    out = []
    for p in sorted(d.glob("OF-*.json")) if d.exists() else []:
        x = rutas.leer_json(p, defecto={}) or {}
        if x.get("estado") == "pendiente":
            out.append({k: x.get(k) for k in ("id", "of", "accion", "modelo", "prompt", "salida", "vence_en")})
    return out


def of_en_curso(ahora=None, raiz=None):
    """Para el hook: producto del worker de la sesión si hay uno vigente; si no, None."""
    base = rutas.ruta("estado", "sesion_worker.json") if raiz is None else os.path.join(str(raiz), "estado", "sesion_worker.json")
    try:
        with open(base, encoding="utf-8") as f:
            x = json.load(f)
    except (OSError, ValueError):
        return None
    try:
        if (ahora or rutas.ahora()) > datetime.fromisoformat(x["vence_en"]):
            return None
    except (KeyError, ValueError, TypeError):
        return None
    of = x.get("of")
    return of if isinstance(of, str) and rutas.RE_OF.match(of) else None
