#!/usr/bin/env python3
"""piel_landing.py — una piel propia por marca, modelada de la página ganadora (Ramiro D104; TAREA 036 D2).

    python herramientas/piel_landing.py extraer --of OF-001 --html ofertas/OF-001/referencia/pagina.html
    python herramientas/piel_landing.py generar --of OF-001
    python herramientas/piel_landing.py verificar

D104 (textual de Ramiro): «modelamos la página entera y de ahí hacemos nuestra personalización, meterle impronta propia;
no copiar literalmente la página, pero sí la usamos de plantilla; es como si tuviéramos plantillas nuevas para cada
producto». Causa: OF-001 y OF-005 salieron con la misma piel porque había una sola plantilla.
  * «modelar» (extraer): de la página ganadora se toman solo ESTRUCTURA y LOOK como tokens abstractos — paleta, familias
    tipográficas, radios, sombras, ritmo de bloques y tipo de hero — en ofertas/<OF>/referencia/look.json. Nunca texto,
    imágenes, CSS ni HTML de la referencia (regla 1: la referencia aporta estructura, nunca hechos).
  * «landing» (generar): plantillas/landing/<marca>/ con piel.css (variables CSS), piel.json y estructura.json. La
    impronta de la marca es determinista (semilla = marca): gira el tono de la paleta 25–74°, elige otra familia de la
    misma categoría y ajusta radios; así nunca queda igual a la referencia ni a otra marca.
  * Una piel por marca; dos marcas nunca comparten firma (verificar_unicas). Mismo nombre de marca = misma piel.
Solo biblioteca estándar.
"""
import argparse
import colorsys
import hashlib
import json
import os
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

FAMILIAS = {   # alternativas libres (Google Fonts) por categoría; la impronta elige una distinta de la referencia
    "serif": ["Lora", "Merriweather", "Libre Baskerville", "Source Serif 4", "Crimson Pro", "Bitter"],
    "sans": ["Inter", "Nunito Sans", "Work Sans", "Manrope", "Figtree", "DM Sans", "Rubik"],
    "display": ["Fraunces", "Playfair Display", "Archivo Black", "Bricolage Grotesque", "Space Grotesk"],
}
SERIF = re.compile(r"serif|georgia|times|garamond|lora|merriweather|baskerville|playfair|crimson|bitter|fraunces", re.IGNORECASE)
DISPLAY = re.compile(r"display|black|bebas|oswald|anton|grotesk|poppins", re.IGNORECASE)
RE_HEX = re.compile(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b")
RE_RGB = re.compile(r"rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})")
RE_FUENTE = re.compile(r"font-family\s*:\s*([^;}\"]+)", re.IGNORECASE)
RE_GFONT = re.compile(r"fonts\.googleapis\.com/css2?\?family=([^&\"':]+)", re.IGNORECASE)
RE_RADIO = re.compile(r"border-radius\s*:\s*(\d+(?:\.\d+)?)px", re.IGNORECASE)


# TAREA 037: las páginas con Tailwind v4 (p. ej. las hechas con Lovable) devuelven los colores en oklch(); sin convertirlos
# la paleta salía vacía. Se pasan a sRGB con OKLab (Björn Ottosson). Lo transparente no cuenta como color.
RE_OKLCH = re.compile(r"oklch\(\s*([\d.]+)(%?)\s+([\d.]+)\s+([\d.]+)(?:deg)?\s*(?:/\s*([\d.]+)(%?))?\s*\)", re.IGNORECASE)
RE_TRANSPARENTE = re.compile(r"rgba\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*0(?:\.0+)?\s*\)|\btransparent\b", re.IGNORECASE)


def oklch_a_hex(l, c, h):
    import math
    a, b = c * math.cos(math.radians(h)), c * math.sin(math.radians(h))
    l3 = (l + 0.3963377774 * a + 0.2158037573 * b) ** 3
    m3 = (l - 0.1055613458 * a - 0.0638541728 * b) ** 3
    s3 = (l - 0.0894841775 * a - 1.2914855480 * b) ** 3
    lin = (4.0767416621 * l3 - 3.3077115913 * m3 + 0.2309699292 * s3,
           -1.2684380046 * l3 + 2.6097574011 * m3 - 0.3413193965 * s3,
           -0.0041960863 * l3 - 0.7034186147 * m3 + 1.7076147010 * s3)

    def gamma(x):
        x = min(1.0, max(0.0, x))
        return 12.92 * x if x <= 0.0031308 else 1.055 * x ** (1 / 2.4) - 0.055
    return "#%02x%02x%02x" % tuple(int(round(gamma(x) * 255)) for x in lin)


def _oklch(estilos):
    out = []
    for l, pct, c, h, alfa, _apct in RE_OKLCH.findall(estilos):
        if alfa and float(alfa) == 0:
            continue
        out.append(oklch_a_hex(float(l) / (100 if pct else 1), float(c), float(h)))
    return out


def slug(texto):
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-") or "sin-marca"


def _hex(h):
    h = h.lower()
    return "#" + "".join(c * 2 for c in h) if len(h) == 3 else "#" + h


def _es_neutro(hx):
    r, g, b = (int(hx[i:i + 2], 16) / 255 for i in (1, 3, 5))
    _h, l, s = colorsys.rgb_to_hls(r, g, b)
    return s < 0.12 or l > 0.95 or l < 0.06


def extraer_look(html):
    """Tokens de estructura y look de la página de referencia. No guarda texto ni recursos de la referencia."""
    estilos = " ".join(re.findall(r"<style[^>]*>(.*?)</style>", html, re.IGNORECASE | re.DOTALL)) + " " + \
        " ".join(re.findall(r'style="([^"]*)"', html, re.IGNORECASE))
    estilos = RE_TRANSPARENTE.sub(" ", estilos)   # TAREA 037: un fondo transparente no es un color de la paleta
    colores = Counter(_hex(m) for m in RE_HEX.findall(estilos))
    colores.update("#%02x%02x%02x" % tuple(min(255, int(x)) for x in m) for m in RE_RGB.findall(estilos))
    colores.update(_oklch(estilos))
    acentos = [c for c, _ in colores.most_common() if not _es_neutro(c)][:4]
    neutros = [c for c, _ in colores.most_common() if _es_neutro(c)][:3]
    fuentes = Counter(f.split(",")[0].strip().strip("'\"") for f in RE_FUENTE.findall(estilos))
    fuentes.update(f.replace("+", " ") for f in RE_GFONT.findall(html))
    radios = sorted(float(x) for x in RE_RADIO.findall(estilos) if float(x) > 0)   # 0 = sin redondeo: no define el estilo
    cuerpo = re.search(r"<body[^>]*>(.*)</body>", html, re.IGNORECASE | re.DOTALL)
    cuerpo = cuerpo.group(1) if cuerpo else html
    primer = cuerpo[:max(2000, len(cuerpo) // 5)]
    hero = "video" if re.search(r"<video|youtube\.com/embed|player\.vimeo", primer, re.IGNORECASE) else \
        "imagen" if re.search(r"<img", primer, re.IGNORECASE) else "texto"
    bloques = re.findall(r"<(section|header|footer|form|details|blockquote|ul)\b", cuerpo, re.IGNORECASE)
    return {"paleta": {"acentos": acentos, "neutros": neutros},
            "fuentes": [f for f, _ in fuentes.most_common(3) if f],
            "radio_px": radios[len(radios) // 2] if radios else 8.0,
            "sombras": bool(re.search(r"box-shadow", estilos, re.IGNORECASE)),
            "hero": hero, "ritmo": [b.lower() for b in bloques][:40], "bloques": len(bloques),
            "referencia_sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
            "_regla": "D104: solo estructura y look (tokens). Nada de texto, imágenes, CSS ni HTML de la referencia."}


def _girar(hx, grados, dl=0.0):
    r, g, b = (int(hx[i:i + 2], 16) / 255 for i in (1, 3, 5))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    r, g, b = colorsys.hls_to_rgb((h + grados / 360.0) % 1.0, min(0.9, max(0.1, l + dl)), s)
    return "#%02x%02x%02x" % tuple(int(round(x * 255)) for x in (r, g, b))


def _categoria(fuente):
    return "serif" if SERIF.search(fuente or "") else "display" if DISPLAY.search(fuente or "") else "sans"


def impronta(look, marca):
    """Transformación determinista por marca: paleta girada, familias propias, radio ajustado."""
    semilla = int(hashlib.sha256(slug(marca).encode()).hexdigest(), 16)
    giro = 25 + semilla % 50
    acentos = look["paleta"]["acentos"] or ["#3b6ea5"]
    paleta = [_girar(c, giro, (((semilla >> (8 * i)) % 7) - 3) / 100.0) for i, c in enumerate(acentos[:3])]
    while len(paleta) < 3:
        paleta.append(_girar(paleta[-1], 120))
    ref = look.get("fuentes") or ["sans-serif"]
    elegir = lambda cat, k: [f for f in FAMILIAS[cat] if f.lower() not in {x.lower() for x in ref}][(semilla >> k) % (len(FAMILIAS[cat]) - 1)]
    titulos = elegir(_categoria(ref[0]) if _categoria(ref[0]) != "sans" else "display", 3)
    texto = elegir("serif" if _categoria(ref[-1]) == "serif" else "sans", 11)
    radio = max(0.0, float(look.get("radio_px", 8)) + ((semilla >> 17) % 7) - 3)
    return {"giro_tono": giro, "paleta": paleta, "titulos": titulos, "texto": texto, "radio_px": radio,
            "sombras": look.get("sombras", True), "neutros": look["paleta"]["neutros"][:2] or ["#ffffff", "#1d1d1f"]}


def css(imp):
    fondo, tinta = (imp["neutros"] + ["#ffffff", "#1d1d1f"])[:2]
    return (":root {\n"
            "  --c-primario: %s;\n  --c-secundario: %s;\n  --c-acento: %s;\n  --c-fondo: %s;\n  --c-tinta: %s;\n"
            "  --f-titulos: '%s', serif;\n  --f-texto: '%s', sans-serif;\n  --radio: %gpx;\n  --sombra: %s;\n}\n"
            "body{font-family:var(--f-texto);background:var(--c-fondo);color:var(--c-tinta)}\n"
            "h1,h2,h3{font-family:var(--f-titulos);color:var(--c-primario)}\n"
            ".cta{background:var(--c-acento);border-radius:var(--radio);box-shadow:var(--sombra)}\n"
            "section{border-radius:var(--radio)}\n") % (
        imp["paleta"][0], imp["paleta"][1], imp["paleta"][2], fondo, tinta, imp["titulos"], imp["texto"], imp["radio_px"],
        "0 6px 18px rgba(0,0,0,.12)" if imp["sombras"] else "none")


def firma(texto_css):
    vars_ = sorted(re.findall(r"--[\w-]+:\s*[^;]+;", texto_css))
    return hashlib.sha256("\n".join(vars_).encode("utf-8")).hexdigest()


def dir_piel(marca):
    return rutas.ruta("plantillas", "landing", slug(marca))


def generar_piel(of, look, marca):
    """plantillas/landing/<marca>/ (piel.css, piel.json, estructura.json). Si la marca ya tiene piel, la reutiliza."""
    d = dir_piel(marca)
    if (d / "piel.json").exists():
        previa = rutas.leer_json(d / "piel.json")
        if previa.get("marca") != marca:
            raise ValueError("la carpeta %s ya es de la marca «%s»" % (d.name, previa.get("marca")))
        return d
    imp = impronta(look, marca)
    texto = css(imp)
    d.mkdir(parents=True, exist_ok=True)
    (d / "piel.css").write_text(texto, encoding="utf-8")
    rutas.escribir_json(d / "piel.json", {"marca": marca, "of_origen": of, "firma": firma(texto), "impronta": imp,
                                          "look_referencia": {k: look[k] for k in ("paleta", "fuentes", "radio_px", "hero", "bloques")},
                                          "regla": "D104: una piel por marca; modelada de la referencia, nunca copiada"})
    rutas.escribir_json(d / "estructura.json", {"hero": look["hero"], "ritmo": look["ritmo"],
                                                "_uso": "orden y tipo de bloques de la referencia; el texto sale de la ficha (regla 1)"})
    return d


def verificar_unicas(raiz_plantillas=None):
    """Problemas: dos marcas con la misma firma de piel, o una piel igual a su referencia (sin impronta)."""
    base = Path(raiz_plantillas or rutas.ruta("plantillas", "landing"))
    firmas, problemas = {}, []
    for pj in sorted(base.glob("*/piel.json")):
        d = json.loads(pj.read_text(encoding="utf-8"))
        f = firma((pj.parent / "piel.css").read_text(encoding="utf-8"))
        if f != d.get("firma"):
            problemas.append("%s: piel.css cambió sin regenerar piel.json" % pj.parent.name)
        if f in firmas and firmas[f] != d.get("marca"):
            problemas.append("%s y %s comparten piel (D104: una piel por marca)" % (firmas[f], d.get("marca")))
        firmas[f] = d.get("marca")
        ref = set((d.get("look_referencia") or {}).get("paleta", {}).get("acentos", []))
        if ref and ref & set(d.get("impronta", {}).get("paleta", [])):
            problemas.append("%s: la paleta repite colores de la referencia (falta impronta)" % d.get("marca"))
    return problemas


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Piel de landing por marca (D104): extraer look, generar piel, verificar.")
    ap.add_argument("orden", choices=("extraer", "generar", "verificar"))
    ap.add_argument("--of")
    ap.add_argument("--html")
    a = ap.parse_args()
    if a.orden == "verificar":
        pr = verificar_unicas()
        for x in pr:
            print("-", x)
        print(json.dumps({"ok": not pr, "codigo": 0 if not pr else 2, "motivo": "%d problema(s)" % len(pr), "artefactos": []}, ensure_ascii=False))
        sys.exit(0 if not pr else 2)
    of = rutas.validar_of(a.of)
    destino = rutas.dir_oferta(of) / "referencia" / "look.json"
    if a.orden == "extraer":
        look = extraer_look(Path(a.html).read_text(encoding="utf-8", errors="replace"))
        rutas.escribir_json(destino, look)
        print(json.dumps({"ok": True, "codigo": 0, "motivo": "look extraído", "artefactos": [str(destino.relative_to(rutas.RAIZ))]}, ensure_ascii=False))
    else:
        marca = (rutas.ficha(of).get("marca") or {}).get("nombre")
        if not marca or "PENDIENTE" in marca:
            print(json.dumps({"ok": False, "codigo": 2, "motivo": "la ficha no tiene marca.nombre", "artefactos": []}, ensure_ascii=False))
            sys.exit(2)
        look = rutas.leer_json(destino)
        if "paleta" not in look and isinstance(look.get("look"), dict):   # TAREA 037 D: look.json del modelado (capturar_referencia) trae
            look = dict(look["look"])                                    # los tokens bajo «look»
        d = generar_piel(of, look, marca)
        print(json.dumps({"ok": True, "codigo": 0, "motivo": "piel de «%s»" % marca, "artefactos": [str(d.relative_to(rutas.RAIZ))]}, ensure_ascii=False))
