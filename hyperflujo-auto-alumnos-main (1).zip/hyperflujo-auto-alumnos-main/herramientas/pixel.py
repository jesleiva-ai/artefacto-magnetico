#!/usr/bin/env python3
"""pixel.py — el píxel de Meta de una landing sale de la cuenta, nunca de un marcador (F63, TAREA 041 Parte 1 E).

F63: la landing de OF-007 salió con `var PIXEL='1234567'` porque el armador tomaba el id de externo.local.json y solo
miraba que tuviera 6 dígitos. Ahora:
  * de_cuenta(ref=None) → el píxel de datos/cuentas.local.json (la cuenta elegida por `ref` o la única que hay).
  * ids_en_html(texto)  → los ids de píxel que trae un HTML (fbq('init', …), PIXEL='…', pixel_id, tr?id=…).
  * problemas(texto, pixel) → lista vacía si todo id del HTML es el de la cuenta; si no, qué está mal. Un HTML sin
    píxel no es problema acá (el aviso de cookies puede cargarlo después); un id distinto o un relleno, sí.
Lo usan kit/sitio.py al armar y netlify_deploy.py antes de cada deploy (falla cerrado). Solo biblioteca estándar.

Matías, 2026-10-25: «Es un píxel nuevo para cada país o para cada idioma». Cada producto lleva su píxel y cada mercado
(país o idioma) de ese producto, el suyo: datos/cuentas.local.json → meta.pixeles = [{oferta, mercado, pixel}].
  * del_producto(oferta, mercado, ref) → el píxel de ese producto en ese mercado; si no hay fila, el de la cuenta.
  * repetidos() → [problema] si un mismo píxel figura para dos productos o dos mercados (no se reusa).
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

PATRONES = (re.compile(r"""fbq\(\s*['"]init['"]\s*,\s*['"]?(\d+)"""),
            re.compile(r"""\bPIXEL(?:_ID)?\s*[=:]\s*['"](\d*)['"]"""),
            re.compile(r"""\bpixel_id['"]?\s*[=:]\s*['"]?(\d+)"""),
            re.compile(r"""facebook\.com/tr\?id=(\d+)"""),
            re.compile(r"""\b(?:var|let|const)\s+\w*(?:id|pixel)\w*\s*=\s*['"](\d{6,})['"]""", re.IGNORECASE))   # OF-006: fbq('init', id)
RELLENOS = re.compile(r"^(1234567\d*|0+|9+|12345\d*)$")


class SinPixel(RuntimeError):
    pass


def de_cuenta(ref=None):
    """Píxel de la cuenta publicitaria (datos/cuentas.local.json). Lanza SinPixel si no se puede saber cuál."""
    try:
        cuentas = (rutas.cargar_dato("cuentas").get("meta") or {}).get("cuentas") or []
    except rutas.FaltaDato as e:
        raise SinPixel(str(e))
    elegidas = [c for c in cuentas if c.get("ref") == ref] if ref else cuentas
    if len(elegidas) != 1:
        raise SinPixel("no se puede elegir el píxel: %d cuentas en datos/cuentas.local.json%s" %
                       (len(elegidas), " con ref %s" % ref if ref else " y la ficha no dice cuál (campana.cuenta_ref)"))
    p = str(elegidas[0].get("pixel") or "")
    if not re.fullmatch(r"\d{6,}", p) or RELLENOS.match(p):
        raise SinPixel("el píxel de la cuenta en datos/cuentas.local.json falta o es un relleno")
    return p


def _pixeles():
    try:
        return (rutas.cargar_dato("cuentas").get("meta") or {}).get("pixeles") or []
    except rutas.FaltaDato:
        return []


def del_producto(oferta=None, mercado=None, ref=None):
    """Píxel del producto en su mercado (meta.pixeles, Matías 2026-10-25); sin fila, el de la cuenta (F63)."""
    filas = [f for f in _pixeles() if f.get("oferta") == oferta and f.get("mercado") == mercado] if oferta else []
    if len(filas) > 1:
        raise SinPixel("dos píxeles para %s en %s en datos/cuentas.local.json → meta.pixeles" % (oferta, mercado))
    if filas:
        p = str(filas[0].get("pixel") or "")
        if not re.fullmatch(r"\d{6,}", p) or RELLENOS.match(p):
            raise SinPixel("el píxel de %s en %s falta o es un relleno" % (oferta, mercado))
        return p
    return de_cuenta(ref)


def repetidos():
    """[problema] si un píxel se reusa entre productos o mercados (cada producto y cada país/idioma, el suyo)."""
    vistos, out = {}, []
    for f in _pixeles():
        clave, p = (f.get("oferta"), f.get("mercado")), str(f.get("pixel") or "")
        if p in vistos and vistos[p] != clave:
            out.append("el píxel %s se usa en %s/%s y en %s/%s: cada producto y cada mercado lleva el suyo" % ((p,) + vistos[p] + clave))
        vistos.setdefault(p, clave)
    return out


def ids_en_html(texto):
    return sorted({m.group(1) for pat in PATRONES for m in pat.finditer(texto or "")})


def problemas(texto, pixel):
    out = []
    for i in ids_en_html(texto):
        if i == "":
            out.append("PIXEL vacío")
        elif RELLENOS.match(i):
            out.append("píxel de relleno %s" % i)
        elif i != pixel:
            out.append("píxel %s distinto del de la cuenta" % i)
    return out
