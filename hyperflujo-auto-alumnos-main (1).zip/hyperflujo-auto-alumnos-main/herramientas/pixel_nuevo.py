#!/usr/bin/env python3
"""pixel_nuevo.py — el agente crea solo el píxel de cada producto y mercado; nunca se lo pide al alumno (Matías, 2026-10-27).

Matías, 2026-10-25: «Es un píxel nuevo para cada país o para cada idioma». Hasta ahora el motor solo BUSCABA el píxel
(ads_get_datasets) y, si no había fila en meta.pixeles, usaba el de la cuenta: el alumno quedaba trabado o reusaba el
mismo píxel en todo. Matías, 2026-10-27: «quiero que lo haga automáticamente para mis alumnos… y los deje de molestar».

    python herramientas/pixel_nuevo.py asegurar --oferta OF-NNN --mercado de-DE [--nombre "Die Berater-Methode DE"] [--cuenta-ref CUENTA-1]
    python herramientas/pixel_nuevo.py anotar   --oferta OF-NNN --mercado de-DE --pixel <id>

`asegurar` hace, en orden, lo primero que se pueda:
  1. Si ya hay fila en datos/cuentas.local.json → meta.pixeles para ese producto y mercado: la devuelve.
  2. Si hay token de Meta en .env (META_ACCESS_TOKEN o META_SYSTEM_USER_TOKEN): crea el píxel por la Graph API
     (POST act_<cuenta>/adspixels), que queda conectado a esa cuenta publicitaria, y lo anota.
  3. Si no hay token: imprime `"via": "navegador"` con los pasos que el AGENTE hace en Chrome (sesión del dueño) o en el
     navegador integrado, y el comando `anotar` para cerrar. Sale con código 2. El agente no le pide nada al alumno.
Siempre imprime JSON, nunca el token. Solo biblioteca estándar.
"""
import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402
import pixel as PX  # noqa: E402

VERSION_API = "v23.0"
TOKENS = ("META_ACCESS_TOKEN", "META_SYSTEM_USER_TOKEN")

PASOS_NAVEGADOR = [
    "Abrí https://business.facebook.com/settings con la sesión del dueño (Chrome) y elegí el portafolio que tiene la cuenta publicitaria %(cuenta)s.",
    "Orígenes de datos → Conjuntos de datos y píxeles → «Agregar» → nombre «%(nombre)s» → «Crear».",
    "En ese conjunto de datos: «Activos conectados» → «Conectar activos» → marcá la cuenta publicitaria %(cuenta)s → «Añadir». Si Meta pide un código por mail o confirmar, avisale al dueño en una línea y esperá.",
    "Copiá el identificador numérico del conjunto de datos (está debajo del nombre) y anotalo con el comando de «despues».",
]


class ErrorPixelNuevo(RuntimeError):
    pass


def _cuentas():
    try:
        return rutas.cargar_dato("cuentas")
    except rutas.FaltaDato:
        return {}


def _cuenta(ref=None):
    """La cuenta publicitaria elegida por `ref` o la única de datos/cuentas.local.json; si no, META_AD_ACCOUNT_ID."""
    cuentas = ((_cuentas().get("meta") or {}).get("cuentas")) or []
    elegidas = [c for c in cuentas if c.get("ref") == ref] if ref else cuentas
    if len(elegidas) == 1 and re.fullmatch(r"act_\d+", str(elegidas[0].get("id") or "")):
        return elegidas[0]["id"]
    import claves
    try:
        v = claves.clave("META_AD_ACCOUNT_ID")
    except claves.ErrorClave:
        v = ""
    v = v if v.startswith("act_") else ("act_" + v if v else "")
    if re.fullmatch(r"act_\d+", v):
        return v
    raise ErrorPixelNuevo("no se sabe en qué cuenta publicitaria crear el píxel: falta en datos/cuentas.local.json "
                          "(o hay varias y la ficha no dice campana.cuenta_ref) y no hay META_AD_ACCOUNT_ID")


def _token():
    import claves
    for n in TOKENS:
        try:
            return claves.clave(n)
        except claves.ErrorClave:
            continue
    return None


def ya_anotado(oferta, mercado):
    filas = [f for f in ((_cuentas().get("meta") or {}).get("pixeles") or [])
             if f.get("oferta") == oferta and f.get("mercado") == mercado]
    return str(filas[0].get("pixel")) if filas else None


def anotar(oferta, mercado, pixel_id, nombre=None, origen=None):
    """Escribe {oferta, mercado, pixel} en datos/cuentas.local.json → meta.pixeles. Falla si es un relleno o se reusa."""
    rutas.validar_of(oferta)
    p = str(pixel_id or "").strip()
    if not re.fullmatch(r"\d{6,}", p) or PX.RELLENOS.match(p):
        raise ErrorPixelNuevo("«%s» no es un identificador de píxel válido" % p)
    datos = _cuentas()
    meta = datos.setdefault("meta", {})
    filas = meta.setdefault("pixeles", [])
    for f in filas:
        if str(f.get("pixel")) == p and (f.get("oferta"), f.get("mercado")) != (oferta, mercado):
            raise ErrorPixelNuevo("el píxel %s ya es de %s/%s: cada producto y cada mercado lleva el suyo"
                                  % (p, f.get("oferta"), f.get("mercado")))
    filas[:] = [f for f in filas if (f.get("oferta"), f.get("mercado")) != (oferta, mercado)]
    fila = {"oferta": oferta, "mercado": mercado, "pixel": p}
    if nombre:
        fila["nombre"] = nombre
    if origen:
        fila["origen"] = origen
    filas.append(fila)
    rutas.escribir_json(rutas.ruta("datos", "cuentas.local.json"), datos)
    return fila


def _post_graph(ruta_api, params, timeout=60):
    """POST a la Graph API. Devuelve el JSON; el mensaje de error nunca incluye el token."""
    cuerpo = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request("https://graph.facebook.com/%s/%s" % (VERSION_API, ruta_api), data=cuerpo, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msj = (json.loads(e.read().decode("utf-8")).get("error") or {}).get("message") or str(e)
        except Exception:
            msj = str(e)
        raise ErrorPixelNuevo("Meta respondió %s: %s" % (e.code, msj))
    except urllib.error.URLError as e:
        raise ErrorPixelNuevo("sin conexión con Meta: %s" % e.reason)


def nombre_por_defecto(oferta, mercado):
    try:
        f = rutas.ficha(oferta)
    except Exception:
        f = {}
    base = f.get("nombre") or f.get("titulo") or oferta
    return "%s %s" % (base, str(mercado).split("-")[-1].upper())


def asegurar(oferta, mercado, nombre=None, cuenta_ref=None, post=_post_graph):
    """Devuelve {"ok", "pixel", "via"}; con "via": "navegador" trae los pasos y el comando para anotar."""
    rutas.validar_of(oferta)
    if not mercado:
        raise ErrorPixelNuevo("falta el mercado (país o idioma) del producto")
    previo = ya_anotado(oferta, mercado)
    if previo:
        return {"ok": True, "pixel": previo, "via": "ya_estaba"}
    nombre = nombre or nombre_por_defecto(oferta, mercado)
    cuenta = _cuenta(cuenta_ref)
    token = _token()
    if token:
        r = post("%s/adspixels" % cuenta, {"name": nombre, "access_token": token})
        nuevo = str(r.get("id") or "")
        anotar(oferta, mercado, nuevo, nombre=nombre, origen="api")
        return {"ok": True, "pixel": nuevo, "via": "api", "nombre": nombre, "cuenta": cuenta}
    datos = {"cuenta": cuenta, "nombre": nombre}
    return {"ok": False, "via": "navegador", "nombre": nombre, "cuenta": cuenta,
            "pasos": [p % datos for p in PASOS_NAVEGADOR],
            "despues": "python herramientas/pixel_nuevo.py anotar --oferta %s --mercado %s --pixel <id>" % (oferta, mercado),
            "nota": "Lo hace el agente, no el alumno. Después cargá el mismo píxel en Hotmart (productos de ese mercado), "
                    "en Utmify y en el conjunto como Compra (recetas/metodo-consultor/RECETA.md §8)."}


def antes_de_armar(oferta, mercado, cuenta_ref=None, post=_post_graph):
    """Lo llaman los armadores de la landing: si falta el píxel de este producto y mercado y hay token, lo crea.
    Nunca corta el armado: sin token o sin red devuelve el aviso, y el armador sigue con pixel.del_producto."""
    if not oferta or not mercado:
        return None
    try:
        return asegurar(oferta, mercado, cuenta_ref=cuenta_ref, post=post)
    except Exception as e:   # sin red, cuenta ambigua, Meta rechazó: el armado sigue y la compuerta avisa
        return {"ok": False, "error": str(e)}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("asegurar")
    a.add_argument("--oferta", required=True)
    a.add_argument("--mercado", required=True)
    a.add_argument("--nombre")
    a.add_argument("--cuenta-ref")
    n = sub.add_parser("anotar")
    n.add_argument("--oferta", required=True)
    n.add_argument("--mercado", required=True)
    n.add_argument("--pixel", required=True)
    n.add_argument("--nombre")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "asegurar":
            r = asegurar(args.oferta, args.mercado, args.nombre, args.cuenta_ref)
        else:
            r = {"ok": True, "fila": anotar(args.oferta, args.mercado, args.pixel, nombre=args.nombre, origen="navegador")}
    except (ErrorPixelNuevo, rutas.FaltaDato, ValueError) as e:
        print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
        return 1
    print(json.dumps(r, ensure_ascii=False, indent=2))
    return 0 if r.get("ok") else 2


if __name__ == "__main__":
    sys.exit(main())
