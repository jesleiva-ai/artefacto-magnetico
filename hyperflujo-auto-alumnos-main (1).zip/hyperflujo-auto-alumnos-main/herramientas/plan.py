#!/usr/bin/env python3
"""plan.py — plan del día: las únicas escrituras externas que valen hoy (CLAUDE.md regla 5; TAREA 036, D99).

El director, justo antes de lanzar un worker que necesita una herramienta de gasto, emite un ticket por herramienta en
estado/planes/AAAA-MM-DD.json (estado «en_curso», ticket_en, vence_en = timeout de la etapa, max_llamadas) con la
autorización que lo cubre; el hook guardian_gasto.py solo deja pasar esa herramienta, para ese producto, dentro del
ticket. Al volver el worker, el director cierra sus tickets («ejecutada» o «rechazada»). Con D99 las herramientas de
gasto están en `allow` de settings.json: el plan del día y los topes en código reemplazan la tarjeta de aprobación.
Solo biblioteca estándar. Los workers no pueden editar estado/planes/ (deny en settings.json).
"""
import json
import os
import sys
from datetime import timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

# acción del director → [(herramienta o patrón, máximo de llamadas, tipo del plan, alcance de la autorización)]
TICKETS = {
    # Revisión 036 h. 3: «publicar» (Hotmart) ya no recibe tickets de creación en Meta. TAREA 037 B: la creación en pausa
    # es la etapa propia «crear_campana» (después de Hotmart aprobado, D103 y D105). Solo creación: nunca
    # ads_activate_entity ni ads_update_entity. Los máximos son techos; el director los acota a las llamadas que faltan
    # (meta_campana.maximos_pendientes) con `maximos=`.
    "crear_campana": [("mcp__meta-ads__ads_create_campaign", 1, "meta_crear_campana", "gasto_meta"),
                      ("mcp__meta-ads__ads_create_ad_set", 1, "meta_crear_conjunto", "gasto_meta"),
                      ("mcp__meta-ads__ads_creative_upload_media", 15, "meta_subir_medio", "gasto_meta"),
                      ("mcp__meta-ads__ads_create_creative", 15, "meta_crear_creativo", "gasto_meta"),
                      ("mcp__meta-ads__ads_create_ad", 15, "meta_crear_anuncio", "gasto_meta")],
    "activar": [("mcp__meta-ads__ads_activate_entity", 3, "meta_activar", "activar_campana")],
    "escalar": [("mcp__meta-ads__ads_update_entity", 1, "meta_presupuesto", "escalar")],
    "reemplazar": [("mcp__meta-ads__ads_update_entity", 2, "meta_pausar_anuncio", "gasto_meta")],
    "reponer": [("mcp__meta-ads__ads_update_entity", 4, "meta_activar_anuncio", "gasto_meta")],
    # Imágenes y voces (Ramiro vía Director_H1, 2026-10-28). Los máximos son techos de llamadas: medios.emitir los acota
    # al cupo en créditos o USD que queda en los techos firmados (datos/topes.local.json → medios) y la ficha.
    "medios": [("mcp__higgsfield__generate_*", 40, "medios_lote", "gasto_medios"),
               ("mcp__higgsfield__upscale_*", 10, "medios_mejora", "gasto_medios"),
               ("mcp__elevenlabs__*", 20, "medios_voz", "gasto_medios")],
}
# Etapas cuyo worker genera imágenes o voces: el director les emite también los tickets «medios» (medios.emitir) y
# etapas.definicion les suma esas herramientas.
ETAPAS_CON_MEDIOS = ("producir",)


def _archivo(fecha):
    return rutas.ruta("estado", "planes", "%s.json" % fecha)


def cargar(fecha):
    p = _archivo(fecha)
    if not p.exists():
        return {"fecha": fecha, "generado_por": "director", "generado_en": rutas.ahora().isoformat(timespec="seconds"), "acciones": []}
    return json.loads(p.read_text(encoding="utf-8"))


def emitir(of, accion, *, fecha=None, minutos=60, regla=None, maximos=None, detalles=None):
    """Tickets en_curso para las herramientas de gasto de la acción. Devuelve los ids (vacío si la acción no gasta).
    maximos: {herramienta: n} acota max_llamadas (nunca lo sube por encima de TICKETS); n = 0 no emite ese ticket.
    detalles: {herramienta: {campo: valor}} completa el ticket (medios: estimado, unidad, tope_ref…).
    «medios» sin maximos pasa siempre por medios.emitir: nunca hay ticket de medios fuera de los techos firmados."""
    if accion == "medios" and maximos is None:
        import medios
        return medios.emitir(of, fecha=fecha, minutos=minutos, regla=regla)["tickets"]
    fecha = fecha or rutas.hoy()
    ahora = rutas.ahora()
    plan = cargar(fecha)
    ids = []
    for herramienta, maximo, tipo, alcance in TICKETS.get(accion, []):
        if maximos is not None:
            maximo = min(maximo, int(maximos.get(herramienta, 0)))
            if maximo <= 0:
                continue
        n = len(plan["acciones"]) + 1
        aid = "A-%s-%04d" % (fecha.replace("-", ""), n)
        plan["acciones"].append({
            "id": aid, "of": of, "tipo": tipo, "herramienta": herramienta, "comando": None, "objeto": "meta.campana",
            "parametros": {}, "clave": "%s:%s:%s:%d" % (accion, of, fecha, n), "gratuita": True, "estimado": 0, "unidad": "USD",
            "max_llamadas": maximo, "tope_ref": "datos/topes.local.json", "autorizacion_ref": alcance,
            "regla": regla or "D99 (plan del día)", "ej": None, "worker": accion, "estado": "en_curso", "llamadas_usadas": 0,
            "ticket_en": ahora.isoformat(timespec="seconds"),
            "vence_en": (ahora + timedelta(minutes=minutos)).isoformat(timespec="seconds")})
        plan["acciones"][-1].update((detalles or {}).get(herramienta) or {})
        ids.append(aid)
    if ids:
        rutas.escribir_json(_archivo(fecha), plan)
    return ids


def cerrar(ids, *, ok, fecha=None):
    if not ids:
        return
    fecha = fecha or rutas.hoy()
    plan = cargar(fecha)
    for a in plan["acciones"]:
        if a["id"] in ids and a["estado"] == "en_curso":
            a["estado"] = "ejecutada" if ok else "rechazada"
    rutas.escribir_json(_archivo(fecha), plan)


def main(argv=None):
    """Vía sesión (TAREA 041): la sesión de Claude Code que hace de director emite o cierra tickets con este comando,
    nunca escribiendo estado/planes/ a mano. Un worker no lo puede correr (guardian_gasto: solo el director).
        python herramientas/plan.py emitir --of OF-NNN --accion medios [--minutos 60] [--sesion]
        python herramientas/plan.py cerrar --ids A-AAAAMMDD-0001 [...] [--rechazada]
    --sesion marca el producto como pedido vigente de la sesión (estado/sesion_worker.json), para que el guardián sepa
    de qué producto son las llamadas MCP que no lo dicen (Higgsfield, ElevenLabs). Última línea: JSON del contrato."""
    import argparse
    ap = argparse.ArgumentParser(description="Tickets del plan del día (solo el director o la sesión que lo hace).")
    sub = ap.add_subparsers(dest="orden", required=True)
    e = sub.add_parser("emitir")
    e.add_argument("--of", required=True)
    e.add_argument("--accion", required=True, choices=sorted(TICKETS))
    e.add_argument("--minutos", type=int, default=60)
    e.add_argument("--regla")
    e.add_argument("--sesion", action="store_true")
    c = sub.add_parser("cerrar")
    c.add_argument("--ids", nargs="+", required=True)
    c.add_argument("--rechazada", action="store_true")
    a = ap.parse_args(argv)
    if a.orden == "cerrar":
        cerrar(a.ids, ok=not a.rechazada)
        print(json.dumps({"ok": True, "codigo": 0, "motivo": "tickets cerrados", "artefactos": ["estado/planes/%s.json" % rutas.hoy()]},
                         ensure_ascii=False))
        return 0
    if not rutas.RE_OF.match(a.of):
        print(json.dumps({"ok": False, "codigo": 2, "motivo": "producto inválido: %s" % a.of, "artefactos": []}, ensure_ascii=False))
        return 2
    regla = a.regla or "vía sesión: plan.py emitir --accion %s" % a.accion
    if a.accion == "medios":
        import medios
        r = medios.emitir(a.of, minutos=a.minutos, regla=regla)
        ids, extra = r["tickets"], {"cupos": r["cupos"], "avisos": r["avisos"], "modo": r.get("modo")}
        motivo = r["motivo"]
    else:   # las acciones de Meta llevan además sus compuertas en el director: acá solo el ticket con su techo de llamadas
        ids, extra = emitir(a.of, a.accion, minutos=a.minutos, regla=regla), {}
        motivo = "%d ticket(s) %s" % (len(ids), a.accion)
    artefactos = ["estado/planes/%s.json" % rutas.hoy()] if ids else []
    if ids and a.sesion:
        ahora = rutas.ahora()
        rutas.escribir_json(rutas.ruta("estado", "sesion_worker.json"),
                            {"of": a.of, "accion": a.accion, "pedido": "plan.py emitir",
                             "vence_en": (ahora + timedelta(minutes=a.minutos)).isoformat(timespec="seconds")})
        artefactos.append("estado/sesion_worker.json")
    print(json.dumps(dict({"ok": bool(ids), "codigo": 0 if ids else 3, "motivo": motivo, "artefactos": artefactos,
                           "tickets": ids}, **extra), ensure_ascii=False))
    return 0 if ids else 3


if __name__ == "__main__":
    sys.exit(main())
