#!/usr/bin/env python3
"""Kit de carga manual en Meta para una oferta (TAREA 022B, punto 8; receta recetas/campana/RECETA.md).
Origen: hyperflujo/herramientas/plan_campana.py (copia SIN ADAPTAR — [PENDIENTE: menciona Sellora y responsables fijos (líneas 223 y 249); adaptar a datos/dueno.local.json]). No se importa en la suite.

    python herramientas/plan_campana.py OF-001 [--version v001] [--fecha AAAA-MM-DD] [--sintetico] [--estructura abo|cash_trap_333]

--estructura cash_trap_333 (P9, TAREA 034B-2): 1 CBO, 1 conjunto Advantage+, 9 anuncios 3 C1 + 3 C2 + 3 C3 (campo `nivel` de copy.json)
y hasta 2 de reserva por nivel (`reserva: true`, nombre `RES-…`), todo en pausa; ventana y escala de Cash Trap (§10.2) con las reglas
de Matías marcadas [REGLA DEL DUEÑO]. Sin --estructura sale la ABO de siempre.

Escribe ofertas/<OF>/campana/<version>/:
  plan_campana.json / plan_campana.md   estructura ABO normal (Manual §2.1, L92–112): 1 conjunto = 1 anuncio
  GUIA_CARGA.md                         pasos en Ads Manager y cómo exportar resultados
  creativos/                            copias de los anuncios renombradas por anuncio_id + hoja de contacto
                                        (medios fuera de git; creativos/manifiesto.json con SHA-256)
  exportaciones/                        destino de los CSV reales: <fecha>.csv
  sintetico/ (--sintetico)              circuito en seco: CSV sintético → importar_csv → diagnostico
  diagnostico_sintetico.md              formato §15 que Matías va a contrastar (SINTÉTICO, no son resultados)

No decide: presupuesto diario total, fecha de inicio y confirmación de la estructura quedan [PENDIENTE: dueños].
Textos: solo los de anuncios/imagen/copy.json, cuyas afirmaciones citan la ficha (D8); se rechaza el kit si un
texto trae tachado, garantía sin evidencia aprobada, testimonios, cupos o urgencia. No llama a Meta ni a Sellora.
"""
import argparse
import datetime
import hashlib
import io
import json
import os
import re
import shutil
import sys
from contextlib import redirect_stdout
from urllib.parse import urlencode

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

PEND_DUENOS = "[PENDIENTE: dueños]"
CTA = "Más información"   # Hyperflujo D100: nunca «Comprar»; LEARN_MORE en el conector
MANUAL_ABO = "Manual §2.1 ABO normal, L92–112"
REGLAS_ABO = {
    "estructura": "1 conjunto = 1 anuncio (L98)",
    "presupuesto_referencia": "mínimo aproximado USD 10/día por conjunto para productos de USD 10–25 (L99)",
    "duracion": "48–72 horas (L100); día 3 solo con 1–2 ventas o señales (L101)",
    "evento": "Compra (L102)",
    "audiencia": "abierta / Advantage (L103)",
    "ubicaciones": "preferencia por móvil, Facebook + Instagram (L104)",
    "analisis": "CTR, CPM, conversión de la web y ventas (L105)",
    "nuevos_testeos": "cada 3–6 días aprox., no todos los días (L106)",
}
PROHIBIDO = [(r"\b34\b|tachad|antes\s+\$?\d", "precio de lista / tachado (EV-001)"),
             (r"testimoni|opiniones|estrellas|★", "testimonios"),
             (r"cupos|últimos|ultimos|solo hoy|sólo hoy|termina hoy|quedan \d", "urgencia o escasez"),
             (r"\d+\s*%", "porcentaje sin evidencia")]


PEND_FECHA = "[PENDIENTE: fecha]"

# --- Estructura 3/3/3 por nivel de conciencia (P9, TAREA 034B-2) ---------------------------------------------------
# Criterio de Matías, no del Manual (L464 dice 5–7 anuncios): CT = analisis/matias/repo/skills/cash-trap-cbo-oro/SKILL.md,
# OP = skills/operador-meta-ads/SKILL.md (contraste en analisis/matias/CONTRASTE_PROCESO_MATIAS_2026-10-21.md §4 y §6).
ESTRUCTURAS = ("abo", "cash_trap_333")
DUENO = "[REGLA DEL DUEÑO]"
MANUAL_CT = "Manual §10 Cash Trap: estructura §10.1 (L464), tiempo y decisiones §10.2 (L472–480), anuncios §10.3 (L486–488)"
NIVELES = {"C1": "no sabe que tiene el problema: emoción, sin tecnicismos",
           "C2": "sabe que tiene el problema y no sabe resolverlo: enseñar, demostrar",
           "C3": "sabe cómo resolverlo y elige con quién: oferta, objeciones, producto por dentro (precio de lanzamiento solo contra el "
                 "regular tachado y con su fecha de fin, D93/EV-001; sin descuento ni garantía sin evidencia aprobada: D8)"}
FORMATOS_333 = ("4x5", "1x1", "9x16", "16x9", "carrusel", "reel")
POR_NIVEL, RESERVA_POR_NIVEL = 3, 2
# (momento, Manual con su línea, Matías con su línea o None si coincide / no dice)
VENTANA_CT = [
    ("Primeras 48 h", "dejar correr 48 h sin decisiones (L472); subir presupuesto a medianoche (L477)",
     None, "coincide: no tocar; prender a medianoche (CT:94)"),
    ("Primera revisión", "revisar el día 3 (L473); si vende, dejarla llegar al día 5 antes de intervenir (L474)",
     "a las 48 h: sin ventas se apaga; ROAS < 2 corre hasta el día 5; ROAS ≥ 2 se sube 30 % (CT:108)", None),
    ("Escala", "desde el día 5–6 si sigue vendiendo (L475); ROAS > 2: +30–40 % y hasta 50 %; si no, ~20 % cada 2–3 días (L476)",
     "escala desde las 48 h con ROAS ≥ 2 (+30 %) (CT:108). Hyperflujo no decide con el ROAS del píxel: cruza con las ventas", None),
    ("Una intervención por vez", "no subir presupuesto y reemplazar anuncios en la misma intervención (L478)", None, "—"),
    ("Espera después de un cambio", "2–3 días tras reemplazar creativos (L479); tirón de oreja y 2–3 días si se rompe (L480)",
     "3 días después de cualquier cambio (CT:112)", None),
    ("Anuncios individuales", "reemplazar los que gastan y no venden o venden caro, sin umbral (L486); los que no gastan pueden quedar (L488)",
     "se apaga el que gastó ≥ el precio del producto sin venta (CT:122); con ROAS ≥ 2 no se toca ninguno (CT:118); el reemplazo es "
     "del mismo nivel, siempre 3/3/3, desde la reserva `RES-` (CT:124-127; OP:39-41); los C1 no se sacan aunque no vendan (CT:78)", None),
    ("Cantidad de anuncios", "mínimo 5, máximo 7 (L464)", "9 = 3 C1 + 3 C2 + 3 C3 (CT:18) + 2 de reserva por nivel en pausa (OP:39-41)", None),
    ("Presupuesto de arranque", "el Manual no fija cifra (§10.4, L497, [NO DEFINIDO])",
     "USD 50 o 75 por día (CT:35); referencia, no autorizado", None),
]



def _duenos_que_aceptan():
    """Revisión 035 h. 21: quién puede aceptar sale de datos/dueno.local.json («puede_aceptar»), no de nombres fijos.
    Sin archivo: nadie acepta (falla cerrado)."""
    import json as _json
    from pathlib import Path as _P
    raiz = _P(os.environ.get("HYPERFLUJO_RAIZ") or _P(__file__).resolve().parents[1])
    try:
        d = _json.loads((raiz / "datos" / "dueno.local.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ()
    return tuple(d.get("puede_aceptar") or ())

def _slug(t):
    return "_".join(_norm(t))


def validar_333(copy):
    """Estructura de copy.json para la 3/3/3 (antes de tocar disco). Devuelve las piezas (activas y de reserva) con nivel,
    ángulo y formato; lanza ErrorPlan con TODOS los problemas encontrados."""
    errores, piezas = [], []
    for i, a in enumerate(copy.get("anuncios") or []):
        quien = "anuncio %s" % (a.get("id") or "#%d" % (i + 1))
        nivel, ang, fmt = a.get("nivel"), _slug(a.get("angulo") or ""), a.get("formato")
        if nivel not in NIVELES:
            errores.append("%s: `nivel` falta o no es C1|C2|C3 (%r)" % (quien, nivel))
        if not ang:
            errores.append("%s: falta `angulo` (nombre corto)" % quien)
        if fmt not in FORMATOS_333:
            errores.append("%s: `formato` falta o no es %s (%r)" % (quien, "|".join(FORMATOS_333), fmt))
        if not a.get("id"):
            errores.append("%s: falta `id`" % quien)
        piezas.append(dict(a, _nivel=nivel, _ang=ang, _fmt=fmt, _reserva=a.get("reserva") is True))
    if errores:
        raise ErrorPlan("copy.json no sirve para la 3/3/3: %s" % "; ".join(errores))
    for n in NIVELES:
        act = [p for p in piezas if p["_nivel"] == n and not p["_reserva"]]
        res = [p for p in piezas if p["_nivel"] == n and p["_reserva"]]
        if not act:
            errores.append("falta el nivel %s (0 de %d anuncios activos)" % (n, POR_NIVEL))
        elif len(act) != POR_NIVEL:
            errores.append("nivel %s con %d anuncios activos (%s): tienen que ser exactamente %d"
                           % (n, len(act), ", ".join(p["id"] for p in act), POR_NIVEL))
        if len(res) > RESERVA_POR_NIVEL:
            errores.append("nivel %s con %d de reserva: como mucho %d" % (n, len(res), RESERVA_POR_NIVEL))
        vistos = {}
        for p in act + res:                    # activos y reserva: al activarse una reserva su nombre no puede chocar
            k = (p["_ang"], p["_fmt"])
            if k in vistos:
                errores.append("nivel %s: %s y %s repiten ángulo+formato (%s, %s)" % (n, vistos[k], p["id"], p["_ang"], p["_fmt"]))
            vistos.setdefault(k, p["id"])
    if errores:
        raise ErrorPlan("copy.json no cumple la 3/3/3 (P9): %s" % "; ".join(errores))
    return piezas


def tope_meta(ficha):
    """Tope escrito de gasto en Meta (oferta.json → campana.presupuesto, el mismo bloque que lee meta_ads.py) o None."""
    import math
    p = (ficha.get("campana") or {}).get("presupuesto") or {}
    d = p.get("diario")
    if isinstance(d, (int, float)) and not isinstance(d, bool) and math.isfinite(d) and d > 0 \
            and p.get("autorizado_por") and p.get("autorizacion_ref"):
        return p
    return None


def _anuncios_333(piezas, oid_c, idioma, conjunto, url, corpus, copiar, utm, base, version_copy, archivo_copy="copy.json"):
    """Anuncios de la 3/3/3 con D8 (respaldo), D24 para reels y nombres por nivel. Devuelve (anuncios, excluidos, textos)."""
    import verificar_reel as VR
    anuncios, excluidos, textos = [], [], []
    for p in piezas:
        final = "%s-%s-%s-%s-%s" % (oid_c, idioma, p["_nivel"], p["_ang"], p["_fmt"])
        nombre = ("RES-" if p["_reserva"] else "") + final
        afs = list(p.get("afirmaciones") or []) + [x for l in p.get("laminas") or [] for x in l.get("afirmaciones") or []]
        sin = [x["texto"] for x in afs if not respaldo(x, corpus)]
        if sin or not p.get("afirmaciones"):
            excluidos.append({"pieza": "anuncio %s" % nombre, "nivel": p["_nivel"], "reserva": p["_reserva"],
                              "motivo": "afirmación sin respaldo en la ficha ni en la landing aceptada (D8): %s"
                              % ("; ".join(sin) or "sin afirmaciones declaradas en copy.json"),
                              "que_hacer": "corregir el texto o agregar el dato a la ficha con su evidencia, y que Matías lo apruebe"})
            continue
        arch, laminas, info = {}, [], ""
        if p["_fmt"] == "reel":
            props = os.path.join(base, p.get("props") or "")
            if not p.get("props") or not os.path.isfile(props):
                excluidos.append({"pieza": "anuncio %s" % nombre, "nivel": p["_nivel"], "reserva": p["_reserva"],
                                  "motivo": "reel sin `props` (final/props.json) para verificar D24", "que_hacer": "declarar `props` en copy.json"})
                continue
            f24, inf = VR.regla_d24(json.load(open(props, encoding="utf-8")))
            if f24:
                excluidos.append({"pieza": "anuncio %s" % nombre, "nivel": p["_nivel"], "reserva": p["_reserva"],
                                  "motivo": "no cumple D24: %s" % "; ".join(f24),
                                  "que_hacer": "rehacer el reel con más cobertura de clips antes de sumarlo"})
                continue
            mp4 = p.get("archivo") or os.path.relpath(os.path.join(os.path.dirname(props), "reel.mp4"), base)
            arch["9x16"] = copiar(mp4, "%s_9x16.mp4" % nombre)
            info = " · %d clips, %.0f %% video (D24)" % (inf["clips_video"], inf["cobertura_video"] * 100)
        elif p["_fmt"] == "carrusel":
            for l in p.get("laminas") or []:
                laminas.append({"lamina": l["id"], "archivo": copiar(l.get("archivo") or os.path.join("anuncios", "imagen", "%s.png" % l["id"]),
                                                                     "%s_%s.png" % (nombre, l["id"])),
                                "titulo": l.get("titular"), "descripcion": l.get("descripcion")})
                textos += [(nombre + " " + l["id"], l.get("titular")), (nombre + " " + l["id"] + " descripción", l.get("descripcion"))]
        else:
            arch[p["_fmt"]] = copiar(p.get("archivo") or os.path.join("anuncios", "imagen", "%s-%s.png" % (p["id"], p["_fmt"])),
                                     "%s_%s.png" % (nombre, p["_fmt"]))
        a = {"anuncio_id": nombre, "utm_content": final, "conjunto": conjunto, "nivel": p["_nivel"], "angulo": p.get("angulo"),
             "formato": p["_fmt"], "reserva": p["_reserva"],
             "estado_inicial": ("pausa · reserva: se activa en lugar de uno del mismo nivel y se le quita `RES-`" if p["_reserva"]
                                else "pausa · se activa al lanzar"),
             "archivos": arch, "texto_primario": p.get("copy_primario"), "titulo": p.get("titular"), "descripcion": p.get("descripcion"),
             "cta": CTA, "url_destino": url, "url_con_utm": utm(final),
             "origen_textos": "anuncios/imagen/%s %s (%s)%s · %s" % (archivo_copy, version_copy, p["id"], info, "; ".join(
                 "%s ← %s" % (x["texto"], x["origen"]) for x in p.get("afirmaciones", [])))}
        if laminas:
            a["laminas"] = laminas
        anuncios.append(a)
        textos += [(nombre + " texto", p.get("copy_primario")), (nombre + " título", p.get("titular")), (nombre + " descripción", p.get("descripcion"))]
    return anuncios, excluidos, textos


class ErrorPlan(Exception):
    pass


def _sha(ruta):
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _aceptacion_anuncios(base):
    """Última ejecución de anuncios de imagen y su revisión humana (la prueba automática no cuenta)."""
    import glob
    ultima = None
    for p in sorted(glob.glob(os.path.join(base, "ejecuciones", "*", "registro.json"))):
        reg = json.load(open(p, encoding="utf-8"))
        if reg.get("modulo", "").startswith("anuncios"):
            ultima = reg
    if not ultima:
        return {"estado": "sin registro", "ejecucion": None}
    r = ultima.get("revision") or {}
    ok = r.get("estado") == "aceptar" and r.get("responsable") in _duenos_que_aceptan()
    return {"estado": "aceptados" if ok else "pendiente de aceptación (hoja de contacto)", "ejecucion": ultima["ejecucion_id"],
            "responsable": r.get("responsable"), "fecha": r.get("fecha")}


FICHA_CAMPO = re.compile(r"\b(AF-\d{3}|EV-\d{3}|producto\.\w+|precio\.\w+|condiciones_comerciales\.\w+|promesa|problema|publico|limites|marca\.\w+)\b")


def _norm(t):
    import unicodedata
    t = "".join(c for c in unicodedata.normalize("NFD", str(t).lower()) if unicodedata.category(c) != "Mn")
    return re.findall(r"[a-z0-9]+", t)


def corpus_aprobado(base, ficha):
    """Texto aprobado contra el que se contrasta cada afirmación (Sonnet 022, punto 15): la ficha y la landing
    aceptada por un dueño (ejecución de landing con revisión «aceptar» de un dueño listado en datos/dueno.local.json)."""
    import glob
    partes = [json.dumps(ficha, ensure_ascii=False)]
    pr = ficha.get("precio") or {}
    if pr.get("moneda") and pr.get("venta") is not None:     # TAREA 025 (12): el precio de la ficha como frase («USD 17»)
        partes.append("%s %s / %s %s" % (pr["moneda"], pr["venta"], pr["venta"], pr["moneda"]))
    fuentes = ["oferta.json"]
    for p in sorted(glob.glob(os.path.join(base, "ejecuciones", "*", "registro.json"))):
        reg = json.load(open(p, encoding="utf-8"))
        rv = reg.get("revision") or {}
        if reg.get("modulo") == "landing" and rv.get("estado") == "aceptar" and str(rv.get("responsable") or "") in _duenos_que_aceptan():
            for a in reg.get("archivos", []):
                if a["ruta"].endswith("contenido.json"):
                    ruta = os.path.normpath(os.path.join(os.path.dirname(p), a["ruta"]))
                    if os.path.isfile(ruta):
                        partes.append(open(ruta, encoding="utf-8").read())
                        fuentes.append(os.path.relpath(ruta, base).replace(os.sep, "/"))
    return " ".join(_norm(" ".join(partes))), fuentes


VACIAS = {"de", "del", "la", "las", "el", "los", "y", "e", "o", "u", "a", "en", "con", "por", "para", "un", "una", "uno",
          "su", "sus", "al", "que", "se", "es"}


def respaldo(afirmacion, corpus):
    """El texto se contrasta SIEMPRE con la ficha y la landing aceptada (TAREA 024, 12); `origen` es solo una pista.

    Cada parte (separada por ; o /) se respalda si (a) ≥ 80 % de sus palabras de 4+ letras están en el corpus y tiene una
    frase de 3 palabras del corpus, o (b) el origen cita un campo de la ficha y TODAS sus palabras no vacías (números
    incluidos) están en el corpus; en las dos ramas, TODO token con cifras tiene que estar en el corpus junto a una palabra vecina (TAREA 025, 12):
    así un dato condensado («PDF, USD 17») pasa, y una cifra o promesa ajena
    («garantía de 90 días, 10.000 alumnas») no, cite lo que cite. Si no, es texto nuevo de oferta (D8) y no entra.
    """
    palabras = set(corpus.split())
    m = FICHA_CAMPO.search(afirmacion.get("origen") or "")
    for parte in re.split(r"[;/]", afirmacion.get("texto") or ""):
        w = _norm(parte)
        contenido = [x for x in w if len(x) >= 4]
        tri = any(" ".join(w[i:i + 3]) in corpus for i in range(len(w) - 2))
        a = tri and contenido and sum(x in palabras for x in contenido) / len(contenido) >= 0.8
        llenas = [x for x in w if x not in VACIAS]
        b = m and llenas and all(x in palabras for x in llenas)
        # TAREA 025 (12): toda cifra tiene que estar en el corpus junto a una palabra vecina («15 patrones», «usd 17»):
        # que el número aparezca suelto en algún campo de la ficha no alcanza («90 días»).
        cifras_ok = all(any(" ".join(par) in corpus for par in ((w[i - 1], x) if i else (), (x, w[i + 1]) if i + 1 < len(w) else ()) if par)
                        for i, x in enumerate(w) if any(ch.isdigit() for ch in x))
        if not ((a or b) and cifras_ok):
            return None
    pista = " · origen declarado %s" % m.group(1) if m else ""
    return "texto en la ficha o la landing aceptada%s" % pista


def _revisar_textos(textos, ficha):
    ev = {e.get("id"): e for e in ficha.get("evidencias") or []}
    gar_ok = all((ev.get(i) or {}).get("estado_revision") == "aprobada"
                 for a in ficha.get("afirmaciones") or [] if a.get("tipo") == "garantia" for i in a.get("evidencia") or [])
    reglas = PROHIBIDO + ([] if gar_ok else [(r"garant|reembols", "garantía sin EV-003 aprobada")])
    # TAREA 028 (revisión Sonnet de la 027, 9): un material/bono que declara `evidencia` no se ofrece mientras esa
    # evidencia no tenga fuente (archivo o URL): p. ej. la tabla de hilos de OF-003 antes de cotejarla (regla 2).
    for mat in (ficha.get("producto") or {}).get("materiales_incluidos") or []:
        e = ev.get(mat.get("evidencia")) if isinstance(mat, dict) and mat.get("evidencia") else None
        if isinstance(mat, dict) and mat.get("evidencia") and not (e and (e.get("archivo_o_url") or e.get("url_fuente"))):
            nombre = re.sub(r"^bono:\s*", "", mat.get("nombre") or "", flags=re.I).strip()
            if nombre:
                reglas = reglas + [(re.escape(nombre), "«%s» sin fuente (%s): no se ofrece" % (nombre, mat["evidencia"]))]
    fallas = []
    for quien, t in textos:
        for pat, motivo in reglas:
            if re.search(pat, t or "", re.I):
                fallas.append("%s: %s («%s»)" % (quien, motivo, (t or "")[:60]))
    return fallas


def generar(oid, version="v001", fecha=None, carpeta_ofertas=None, sintetico=False, sobrescribir=False, estructura="abo"):
    if not re.fullmatch(r"v\d{3}", version):
        raise ErrorPlan("version debe ser vNNN")
    if estructura not in ESTRUCTURAS:
        raise ErrorPlan("estructura desconocida %r: %s" % (estructura, " | ".join(ESTRUCTURAS)))
    if fecha is not None:
        datetime.date.fromisoformat(fecha)
    base = os.path.join(carpeta_ofertas or os.path.join(RAIZ, "ofertas"), oid)
    ficha = json.load(open(os.path.join(base, "oferta.json"), encoding="utf-8"))
    dir_img = os.path.join(base, "anuncios", "imagen")
    copy_p = os.path.join(dir_img, "copy.json")
    # OF-001 v004 (D91): la 3/3/3 lee anuncios/imagen/copy_333.json si existe (piezas con nivel/ángulo/formato/archivo); copy.json
    # queda como el de la ABO (piezas × formatos + carrusel) que usan los planes v001–v003 y test_plan_campana.py.
    if estructura == "cash_trap_333" and os.path.isfile(os.path.join(dir_img, "copy_333.json")):
        copy_p = os.path.join(dir_img, "copy_333.json")
    if not os.path.isfile(copy_p):
        raise ErrorPlan("falta anuncios/imagen/copy.json: producir los anuncios primero")
    copy = json.load(open(copy_p, encoding="utf-8"))
    copy.setdefault("_archivo", os.path.basename(copy_p))
    piezas333 = validar_333(copy) if estructura == "cash_trap_333" else None   # P9: se rechaza antes de escribir nada
    # TAREA 034: además de Sellora, una landing propia con checkout externo (Hotmart): destino.externo, mismos campos
    destino = ficha.get("destino") or {}
    # El canal vivo manda: si hay landing externa (Hotmart, TAREA 032/034) se usa antes que el piloto de Sellora.
    s = destino.get("externo") or destino.get("sellora") or {}
    url = s.get("url_landing_publica")
    if not url:
        raise ErrorPlan("la ficha no tiene destino.sellora ni destino.externo con url_landing_publica (HS-006): publicar primero")
    salida = os.path.join(base, "campana", version)
    if os.path.exists(os.path.join(salida, "plan_campana.json")):
        if not sobrescribir:
            raise ErrorPlan("ya existe %s: otra versión (--version v00N, p. ej. con --fecha) o --sobrescribir" % salida)
        anterior = salida + ".anterior"                # TAREA 025: si el plan nuevo falla, la versión previa vuelve
        shutil.rmtree(anterior, ignore_errors=True)
        os.rename(salida, anterior)

    def descartar():
        shutil.rmtree(salida, ignore_errors=True)
        if os.path.isdir(salida + ".anterior"):
            os.rename(salida + ".anterior", salida)

    idioma = copy.get("idioma") or (ficha.get("mercado") or {}).get("idioma") or "es"
    oid_c = oid.replace("-", "")
    # TAREA 024 (13): sin --fecha el nombre lleva un marcador que no pasa por válido (antes era el literal AAAA-MM-DD)
    campana = "%s_%s_%s_%s" % (oid, idioma, "CT333" if piezas333 else "ABO", fecha or PEND_FECHA)
    os.makedirs(os.path.join(salida, "creativos"), exist_ok=True)
    os.makedirs(os.path.join(salida, "exportaciones"), exist_ok=True)

    def utm(anuncio_id):
        return url + ("&" if "?" in url else "?") + urlencode({"utm_source": "meta", "utm_medium": "paid",
                                                               "utm_campaign": campana, "utm_content": anuncio_id})

    anuncios, textos, medios = [], [], []

    def copiar(origen_rel, destino_nombre):
        o = os.path.join(base, origen_rel)
        if not os.path.isfile(o):
            return None
        d = os.path.join(salida, "creativos", destino_nombre)
        shutil.copy2(o, d)
        medios.append({"archivo": "creativos/" + destino_nombre, "origen": origen_rel.replace(os.sep, "/"),
                       "bytes": os.path.getsize(d), "sha256": _sha(d)})
        return "creativos/" + destino_nombre

    corpus, fuentes_aprobadas = corpus_aprobado(base, ficha)
    if piezas333 is not None:
        plan = _plan_333(oid, version, fecha, idioma, campana, ficha, copy, piezas333, base, url, s, corpus, fuentes_aprobadas,
                         copiar, utm, descartar)
        return _escribir(salida, plan, medios, sintetico)
    excluidos = []
    for a in copy.get("anuncios", []):
        aid = "%s-%s-%s" % (oid_c, idioma, a["id"])
        sin = [x["texto"] for x in a.get("afirmaciones", []) if not respaldo(x, corpus)]
        if sin or not a.get("afirmaciones"):
            excluidos.append({"pieza": "anuncio %s" % aid, "motivo": "afirmación sin respaldo en la ficha ni en la landing aceptada (D8): %s"
                              % ("; ".join(sin) or "sin afirmaciones declaradas en copy.json"),
                              "que_hacer": "corregir el texto o agregar el dato a la ficha con su evidencia, y que Matías lo apruebe"})
            continue
        arch = {f: copiar(os.path.join("anuncios", "imagen", "%s-%s.png" % (a["id"], f)), "%s_%s.png" % (aid, f))
                for f in ("4x5", "9x16", "1x1")}
        anuncios.append({"anuncio_id": aid, "conjunto": "%s_%s" % (campana, aid), "formato": "imagen",
                         "angulo": a.get("angulo"), "archivos": arch,
                         "ubicaciones": "4x5 en feed; 9x16 en historias y reels; 1x1 de respaldo",
                         "texto_primario": a.get("copy_primario"), "titulo": a.get("titular"),
                         "descripcion": a.get("descripcion"), "cta": CTA, "url_destino": url, "url_con_utm": utm(aid),
                         "origen_textos": "anuncios/imagen/copy.json %s · %s" % (copy.get("version"), "; ".join(
                             "%s ← %s" % (x["texto"], x["origen"]) for x in a.get("afirmaciones", [])))})
        textos += [(aid + " texto", a.get("copy_primario")), (aid + " título", a.get("titular")), (aid + " descripción", a.get("descripcion"))]
    car = copy.get("carrusel")
    sin_car = [x["texto"] for l in (car or {}).get("laminas", []) for x in l.get("afirmaciones", []) if not respaldo(x, corpus)]
    if car and sin_car:
        excluidos.append({"pieza": "carrusel", "motivo": "afirmación sin respaldo (D8): %s" % "; ".join(sin_car),
                          "que_hacer": "corregir la lámina o agregar el dato a la ficha"})
        car = None
    if car:
        aid = "%s-%s-CAR" % (oid_c, idioma)
        laminas = []
        for l in car.get("laminas", []):
            laminas.append({"lamina": l["id"], "archivo": copiar(os.path.join("anuncios", "imagen", "%s.png" % l["id"]), "%s_%s.png" % (aid, l["id"])),
                            "titulo": l.get("titular"), "descripcion": l.get("descripcion")})
            textos += [(aid + " " + l["id"], l.get("titular")), (aid + " " + l["id"] + " descripción", l.get("descripcion"))]
        anuncios.append({"anuncio_id": aid, "conjunto": "%s_%s" % (campana, aid), "formato": "carrusel 1x1",
                         "angulo": "carrusel (%s)" % car.get("angulo"), "laminas": laminas,
                         "texto_primario": car.get("copy_primario"), "cta": CTA, "url_destino": url, "url_con_utm": utm(aid),
                         "origen_textos": "anuncios/imagen/copy.json %s (carrusel)" % copy.get("version")})
        textos.append((aid + " texto", car.get("copy_primario")))
    copiar(os.path.join("anuncios", "imagen", "hoja_contacto.png"), "hoja_contacto.png")

    fallas = _revisar_textos(textos, ficha)
    if fallas:
        descartar()
        raise ErrorPlan("textos fuera de la ficha (D8): %s" % "; ".join(fallas))
    if not anuncios:
        descartar()
        raise ErrorPlan("ningún anuncio tiene respaldo en la ficha ni en la landing aceptada (D8): %s"
                        % "; ".join(x["pieza"] for x in excluidos))

    import verificar_reel as VR
    import glob
    reels = sorted(glob.glob(os.path.join(base, "ejecuciones", "*", "resultados", "*", "final", "props.json")))
    if reels:
        p = reels[-1]
        f24, info = VR.regla_d24(json.load(open(p, encoding="utf-8")))
        rel = os.path.relpath(p, base).replace(os.sep, "/")
        ej_reel = rel.split("/resultados")[0].split("/")[-1]
        mp4 = os.path.join(os.path.dirname(p), "reel.mp4")
        base_txt = next((x for x in anuncios if x.get("titulo")), None) or next(iter(anuncios), None)
        if f24:
            excluidos.append({"pieza": "reel (%s)" % ej_reel, "motivo": "no cumple D24: %s" % "; ".join(f24),
                              "que_hacer": "rehacer el reel con más cobertura de clips antes de sumarlo"})
        elif not os.path.isfile(mp4) or base_txt is None:
            excluidos.append({"pieza": "reel (%s)" % ej_reel, "motivo": "cumple D24 pero falta el mp4 o un anuncio respaldado del que tomar el texto",
                              "que_hacer": "renderizar el reel o corregir los textos"})
        else:                                     # TAREA 023C: el reel entra si cumple D24; texto = el del primer anuncio respaldado
            aid = "%s-%s-REEL" % (oid_c, idioma)
            anuncios.append({"anuncio_id": aid, "conjunto": "%s_%s" % (campana, aid), "formato": "video 9:16",
                             "angulo": "reel (%s, %d clips, %.0f %% video)" % (ej_reel, info["clips_video"], info["cobertura_video"] * 100),
                             "archivos": {"9x16": copiar(os.path.relpath(mp4, base), "%s_9x16.mp4" % aid)},
                             "ubicaciones": "reels e historias", "texto_primario": base_txt["texto_primario"], "titulo": base_txt["titulo"],
                             "descripcion": base_txt["descripcion"], "cta": CTA, "url_destino": url, "url_con_utm": utm(aid),
                             "origen_textos": "mismos textos que %s (respaldados); video verificado con D24" % base_txt["anuncio_id"]})

    acept = _aceptacion_anuncios(base)
    n = len(anuncios)
    pend = [{"que": "Presupuesto diario total", "quien": "dueños", "nota": "referencia del manual: USD 10/día × %d conjuntos = USD %d/día (no autorizado)" % (n, 10 * n)},
            {"que": "Fecha de inicio", "quien": "dueños", "nota": "con la fecha se regenera el plan (--fecha) para fijar nombres y utm_campaign"},
            {"que": "Confirmar la estructura ABO 1-1 y el CTA «%s»" % CTA, "quien": "dueños", "nota": MANUAL_ABO},
            {"que": "Aceptación de los anuncios", "quien": "Matías", "nota": "%s (%s)" % (acept["estado"], acept.get("ejecucion"))}]
    if s.get("entorno") != "live":
        pend.append({"que": "URL de destino LIVE", "quien": "dueño",
                     "nota": "la URL actual es del piloto en modo TEST (checkout de prueba): no cargar la campaña hasta que "
                             "`listo_para_live.py %s` diga LISTO y Sellora devuelva la URL live" % oid})
    if s.get("pixel") != "configurado":
        pend.append({"que": "Píxel de Meta en Sellora", "quien": "Matías (ID) / Sellora", "nota": "sin píxel, Meta no ve las compras (evento Compra)"})

    plan = {"oferta_id": oid, "version": version, "generado": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "por": "herramientas/plan_campana.py", "idioma": idioma, "fuente_estructura": MANUAL_ABO, "reglas_abo": REGLAS_ABO,
            "campana": {"nombre": campana, "tipo": "ABO normal", "objetivo": "Ventas", "evento": "Compra",
                        "fecha_inicio": fecha or PEND_DUENOS, "presupuesto_diario_total": PEND_DUENOS,
                        "presupuesto_por_conjunto": PEND_DUENOS + " (referencia §2.1: USD 10/día)",
                        "duracion": "48–72 h (§2.1)", "audiencia": "abierta / Advantage", "estructura_confirmada": PEND_DUENOS},
            "destino": {"url_landing_publica": url, "entorno": s.get("entorno"), "fuente": s.get("fuente"),
                        "utm": "utm_source=meta&utm_medium=paid&utm_campaign=<campaña>&utm_content=<anuncio_id>"},
            "aceptacion_anuncios": acept, "textos_aprobados": fuentes_aprobadas, "anuncios": anuncios, "excluidos": excluidos, "pendientes": pend,
            "exportacion": {"nivel": "anuncio", "desglose": "Día", "ventana": "una sola configuración de atribución",
                            "sin_desgloses": True, "destino": "campana/%s/exportaciones/<AAAA-MM-DD>.csv" % version,
                            "columnas": _columnas_export()}}
    return _escribir(salida, plan, medios, sintetico)


def _escribir(salida, plan, medios, sintetico):
    json.dump(plan, open(os.path.join(salida, "plan_campana.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump({"medios_fuera_de_git": True, "archivos": medios},
              open(os.path.join(salida, "creativos", "manifiesto.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(os.path.join(salida, "plan_campana.md"), "w", encoding="utf-8", newline="\n").write(plan_md(plan))
    open(os.path.join(salida, "GUIA_CARGA.md"), "w", encoding="utf-8", newline="\n").write(guia_md(plan))
    open(os.path.join(salida, "exportaciones", "LEEME.md"), "w", encoding="utf-8", newline="\n").write(
        "Exportaciones reales de Ads Manager: `<AAAA-MM-DD>.csv` (ver GUIA_CARGA.md, parte 2). No editar a mano.\n")
    res = {"carpeta": salida, "plan": plan}
    if sintetico:
        res["diagnostico_sintetico"] = circuito_sintetico(salida, plan)
    anterior = salida + ".anterior"
    if os.path.isdir(anterior):                       # TAREA 025: lo que el plan no genera (p. ej. diagnostico_sintetico_v2.md) se conserva
        for raiz, _, archivos in os.walk(anterior):
            for n in archivos:
                rel = os.path.relpath(os.path.join(raiz, n), anterior)
                if not os.path.exists(os.path.join(salida, rel)):
                    os.makedirs(os.path.dirname(os.path.join(salida, rel)), exist_ok=True)
                    shutil.copy2(os.path.join(raiz, n), os.path.join(salida, rel))
    shutil.rmtree(anterior, ignore_errors=True)
    return res


def _plan_333(oid, version, fecha, idioma, campana, ficha, copy, piezas, base, url, s, corpus, fuentes_aprobadas, copiar, utm, descartar):
    """Plan de la estructura 3/3/3 (P9): 1 CBO, 1 conjunto Advantage+, 9 anuncios C1/C2/C3 + reserva `RES-`, todo en pausa."""
    conjunto = "%s_ADV" % campana
    anuncios, excluidos, textos = _anuncios_333(piezas, oid.replace("-", ""), idioma, conjunto, url, corpus, copiar, utm, base,
                                                copy.get("version"), copy.get("_archivo", "copy.json"))
    if copy.get("carrusel"):
        excluidos.append({"pieza": "carrusel de copy.json (formato ABO)", "motivo": "en la 3/3/3 un carrusel es un anuncio con `nivel`, "
                          "`angulo` y `formato: carrusel`", "que_hacer": "declararlo dentro de `anuncios` si va"})
    copiar(os.path.join("anuncios", "imagen", copy.get("hoja_contacto") or "hoja_contacto.png"), "hoja_contacto.png")
    fallas = _revisar_textos(textos, ficha)
    if fallas:
        descartar()
        raise ErrorPlan("textos fuera de la ficha (D8): %s" % "; ".join(fallas))
    caidos = [x for x in excluidos if x.get("nivel") and not x.get("reserva")]
    if caidos:
        descartar()
        raise ErrorPlan("la 3/3/3 queda incompleta: %s. Corregir la pieza o reemplazarla por una reserva del mismo nivel "
                        "(quitar `reserva`)" % "; ".join("%s (%s): %s" % (x["pieza"], x["nivel"], x["motivo"]) for x in caidos))
    activos = [a for a in anuncios if not a["reserva"]]
    acept = _aceptacion_anuncios(base)
    tope = tope_meta(ficha)
    mercado = ficha.get("mercado") or {}
    paises = (tope or {}).get("paises") or mercado.get("pais") or PEND_DUENOS
    # D91: segmentación de Matías declarada en el kit (copy_333.json → segmentacion) manda sobre los países del tope (D68)
    seg = copy.get("segmentacion") or {}
    idiomas = seg.get("idiomas") or idioma
    if seg.get("paises"):
        if (tope or {}).get("paises") and tope["paises"] != seg["paises"]:
            aviso_seg = {"que": "Países del tope en la ficha", "quien": "dueño / director",
                         "nota": "oferta.json → campana.presupuesto.paises = %s (D68) no coincide con la segmentación del kit (%s): "
                                 "actualizar la ficha antes de cargar con meta_ads.py" % (", ".join(tope["paises"]), seg.get("fuente") or "copy_333.json")}
        else:
            aviso_seg = None
        paises = seg["paises"]
    else:
        aviso_seg = None
    if tope:
        pres = "USD %s/día × %s días = USD %s (tope escrito: %s; %s)" % (tope["diario"], tope.get("dias", "?"), tope.get("total", "?"),
                                                                       tope["autorizado_por"], tope["autorizacion_ref"])
    else:
        pres = PEND_DUENOS
    pend = []
    if not tope:
        pend.append({"que": "Presupuesto diario de la campaña (CBO)", "quien": "dueños",
                     "nota": "el Manual no fija cifra (§10.4, L497); %s USD 50 o 75/día (CT:35), no autorizado. Va en oferta.json → "
                             "campana.presupuesto (diario, días, autorizado_por, autorizacion_ref)" % DUENO})
    pend += [{"que": "Fecha de inicio", "quien": "dueños", "nota": "con la fecha se regenera el plan (--fecha) para fijar nombres y utm_campaign"},
             {"que": "Confirmar la estructura 3/3/3 (9 anuncios) frente a 5–7 del Manual (L464) y el CTA «%s»" % CTA, "quien": "Matías",
              "nota": "es criterio de Matías (CT:18), no del Manual (P9)"},
             {"que": "Aceptación de los anuncios", "quien": "Matías", "nota": "%s (%s)" % (acept["estado"], acept.get("ejecucion"))}]
    if aviso_seg:
        pend.append(aviso_seg)
    faltan = [a["anuncio_id"] for a in anuncios if not [v for v in a["archivos"].values() if v] and
              not [l for l in a.get("laminas", []) if l["archivo"]]]
    if faltan:
        pend.append({"que": "Archivos de los anuncios", "quien": "worker", "nota": "sin archivo en anuncios/: %s" % ", ".join(faltan)})
    if s.get("entorno") != "live":
        pend.append({"que": "URL de destino LIVE", "quien": "dueño",
                     "nota": "la URL actual es del piloto en modo TEST (checkout de prueba): no cargar la campaña hasta que "
                             "`listo_para_live.py %s` diga LISTO y Sellora devuelva la URL live" % oid})
    if s.get("pixel") != "configurado":
        pend.append({"que": "Píxel de Meta en Sellora", "quien": "Matías (ID) / Sellora", "nota": "sin píxel, Meta no ve las compras (evento Compra)"})
    return {"oferta_id": oid, "version": version, "generado": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "por": "herramientas/plan_campana.py --estructura cash_trap_333", "idioma": idioma, "estructura": "cash_trap_333",
            "fuente_estructura": MANUAL_CT + "; 3/3/3 y reserva: %s (P9)" % DUENO,
            "niveles": NIVELES,
            "ventana_y_escala": [{"momento": m, "manual": man, "dueno": ("%s %s" % (DUENO, d)) if d else None, "nota": n}
                                 for m, man, d, n in VENTANA_CT],
            "campana": {"nombre": campana, "tipo": "CBO (Cash Trap 3/3/3)", "objetivo": "Ventas", "evento": "Compra",
                        "fecha_inicio": fecha or PEND_DUENOS, "presupuesto_diario_total": pres,
                        "presupuesto_por_conjunto": "no aplica: CBO, el presupuesto va en la campaña",
                        "duracion": "48 h sin decisiones (L472); revisión el día 3 (L473) · %s a las 48 h (CT:108)" % DUENO,
                        "audiencia": "Advantage+ / abierta", "estructura_confirmada": PEND_DUENOS},
            "conjunto": {"nombre": conjunto, "audiencia": "Advantage+ / abierta (L103, §10.1)", "paises": paises, "idioma": idiomas,
                         "evento": "Compra", "anuncios_activos": len(activos), "reserva": len(anuncios) - len(activos)},
            "destino": {"url_landing_publica": url, "entorno": s.get("entorno"), "fuente": s.get("fuente"),
                        "utm": "utm_source=meta&utm_medium=paid&utm_campaign=<campaña>&utm_content=<anuncio sin RES->"},
            "aceptacion_anuncios": acept, "textos_aprobados": fuentes_aprobadas, "anuncios": anuncios, "excluidos": excluidos,
            "pendientes": pend,
            "exportacion": {"nivel": "anuncio", "desglose": "Día", "ventana": "una sola configuración de atribución",
                            "sin_desgloses": True, "destino": "campana/%s/exportaciones/<AAAA-MM-DD>.csv" % version,
                            "columnas": _columnas_export()}}


def plan_md_333(p):
    c, cj = p["campana"], p["conjunto"]
    L = ["# Plan de campaña %s · %s · Cash Trap 3/3/3" % (p["oferta_id"], p["version"]), ""] + ([aviso_fecha(p), ""] if aviso_fecha(p) else []) + [
         "> Generado por `herramientas/plan_campana.py --estructura cash_trap_333` desde la ficha. **Nada se cargó en Meta.** "
         "Lo marcado %s lo deciden los dueños. Lo marcado %s es criterio de Matías y no del Manual (P9)." % (PEND_DUENOS, DUENO), "",
         "## Campaña (%s)" % p["fuente_estructura"], "", "| Campo | Valor |", "|---|---|"]
    L += ["| %s | %s |" % kv for kv in (("Nombre", c["nombre"]), ("Tipo", c["tipo"]), ("Objetivo / evento", "%s / %s" % (c["objetivo"], c["evento"])),
                                        ("Fecha de inicio", c["fecha_inicio"]), ("Presupuesto diario (campaña)", c["presupuesto_diario_total"]),
                                        ("Duración", c["duracion"]), ("Estructura confirmada", c["estructura_confirmada"]),
                                        ("Conjunto", "%s · %s · países: %s · idioma %s" % (cj["nombre"], cj["audiencia"], cj["paises"], cj["idioma"])),
                                        ("Anuncios", "%d activos (en pausa hasta lanzar) + %d de reserva en pausa (`RES-`)" % (cj["anuncios_activos"], cj["reserva"])),
                                        ("Destino", "%s (entorno %s; %s)" % (p["destino"]["url_landing_publica"], p["destino"]["entorno"], p["destino"]["fuente"])))]
    L += ["", "## Niveles de conciencia", ""] + ["- **%s**: %s" % kv for kv in p["niveles"].items()]
    L += ["", "## Ventana y escala (Manual §10.2, L472–480) y reglas de Matías", "",
          "Mientras Matías no decida cuál manda, el plan muestra las dos lecturas. CT = `skills/cash-trap-cbo-oro/SKILL.md`, "
          "OP = `skills/operador-meta-ads/SKILL.md` (repo de Matías; contraste §4).", "",
          "| Momento | Manual | Matías |", "|---|---|---|"]
    L += ["| %s | %s | %s |" % (v["momento"], v["manual"], v["dueno"] or v["nota"]) for v in p["ventana_y_escala"]]
    L += ["", "## Anuncios (1 conjunto: %s)" % cj["nombre"], "",
          "| Nivel | Anuncio (= nombre en Meta) | utm_content | Ángulo | Formato | Estado inicial | Archivos |", "|---|---|---|---|---|---|---|"]
    for a in sorted(p["anuncios"], key=lambda x: (x["reserva"], x["nivel"])):
        arch = ", ".join(v for v in (a.get("archivos") or {}).values() if v) or ", ".join(l["archivo"] or "—" for l in a.get("laminas", [])) or "—"
        L.append("| %s | %s | %s | %s | %s | %s | %s |" % (a["nivel"], a["anuncio_id"], a["utm_content"], a.get("angulo") or "—", a["formato"],
                                                         a["estado_inicial"], arch))
    for a in p["anuncios"]:
        L += ["", "### %s · %s · %s" % (a["anuncio_id"], a["nivel"], a.get("angulo") or ""), "", "- **Texto primario:** " + (a.get("texto_primario") or "—")]
        if a.get("titulo"):
            L += ["- **Título:** " + a["titulo"], "- **Descripción:** " + (a.get("descripcion") or "—")]
        for l in a.get("laminas", []):
            L.append("- **Lámina %s:** %s · %s" % (l["lamina"], l["titulo"], l["descripcion"]))
        L += ["- **URL con UTM:** `%s`" % a["url_con_utm"], "- Origen de los textos: " + a["origen_textos"]]
    L += ["", "## No entra en este plan", ""] + (["- **%s**: %s → %s" % (x["pieza"], x["motivo"], x["que_hacer"]) for x in p["excluidos"]] or ["- nada"])
    L += ["", "## Pendiente antes de cargar", ""] + ["- [ ] **%s** (%s): %s" % (x["que"], x["quien"], x["nota"]) for x in p["pendientes"]]
    return "\n".join(L) + "\n"


def guia_md_333(p):
    c, cj = p["campana"], p["conjunto"]
    act = next(a for a in p["anuncios"] if not a["reserva"])
    return "\n".join([
        "# Cargar la campaña %s (Cash Trap 3/3/3) en Ads Manager" % c["nombre"], ""] + ([aviso_fecha(p), ""] if aviso_fecha(p) else []) + [
        "Para el dueño. Sin capturas de Meta: se verifica en el primer uso. Antes de empezar, todo lo de «Pendiente antes de "
        "cargar» en `plan_campana.md` tiene que estar resuelto. **Todo se crea en pausa.**", "",
        "## 1. Cargar", "",
        "1. Ads Manager → **Crear** → objetivo **Ventas**. Nombre de la campaña: `%s`." % c["nombre"],
        "2. **Activá** el presupuesto de campaña (Advantage+ campaign budget, CBO): diario = %s." % c["presupuesto_diario_total"],
        "3. Un solo conjunto: `%s`. Conversión en el **sitio web**, píxel de la tienda, evento **Compra**. Audiencia Advantage+; "
        "países: %s; idioma %s." % (cj["nombre"], cj["paises"], cj["idioma"]),
        "4. %d anuncios (3 C1 + 3 C2 + 3 C3): nombre = la columna «Anuncio» de `plan_campana.md` (p. ej. `%s`), archivos de `creativos/` "
        "con ese nombre. Textos **tal cual** del plan; botón **%s**; URL = la «URL con UTM» de ese anuncio." % (cj["anuncios_activos"], act["anuncio_id"], CTA),
        "5. %d de reserva con su nombre `RES-…`, igual que el paso 4, y quedan **en pausa**. Al reemplazar un anuncio, se activa una reserva "
        "**del mismo nivel** y se le quita `RES-` del nombre: su URL ya lleva el `utm_content` sin `RES-`." % cj["reserva"],
        "6. Revisá la vista previa de cada anuncio. Encendé campaña, conjunto y los %d anuncios a la **medianoche** (L477; CT:94). "
        "Anotá en `plan_campana.md` la fecha y hora de lanzamiento." % cj["anuncios_activos"],
        "7. 48 h sin tocar (L472). La revisión sigue la tabla «Ventana y escala» del plan.", ""] + _exportar_md(p))


def _columnas_export():
    m = json.load(open(os.path.join(RAIZ, "campanas", "mapeo.json"), encoding="utf-8"))["idiomas"]["es"]["columnas"]
    orden = ["cuenta", "campana", "conjunto", "anuncio", "anuncio_id", "fecha", "moneda", "atribucion", "gasto", "impresiones",
             "alcance", "clics_enlace", "landing_page_views", "reproducciones_3s", "checkouts", "compras", "ingresos",
             "inicio_informe", "fin_informe"]
    return [{"campo": k, "columna_ads_manager": m[k][0]} for k in orden]


def aviso_fecha(p):
    """TAREA 024 (13): sin fecha, el nombre de campaña y la utm_campaign no son válidos todavía."""
    return ("> **Sin fecha de inicio:** el nombre de campaña y `utm_campaign` llevan `%s`. No cargar así: cuando los dueños "
            "fijen la fecha, regenerar con `--fecha AAAA-MM-DD --sobrescribir`." % PEND_FECHA) if PEND_FECHA in p["campana"]["nombre"] else None


def plan_md(p):
    if p.get("estructura") == "cash_trap_333":
        return plan_md_333(p)
    c = p["campana"]
    L = ["# Plan de campaña %s · %s" % (p["oferta_id"], p["version"]), ""] + ([aviso_fecha(p), ""] if aviso_fecha(p) else []) + [
         "> Generado por `herramientas/plan_campana.py` desde la ficha. **Nada se cargó en Meta.** Lo marcado %s lo deciden los dueños." % PEND_DUENOS, "",
         "## Campaña (%s)" % p["fuente_estructura"], "", "| Campo | Valor |", "|---|---|"]
    L += ["| %s | %s |" % (k, v) for k, v in (("Nombre", c["nombre"]), ("Tipo", c["tipo"]), ("Objetivo / evento", "%s / %s" % (c["objetivo"], c["evento"])),
                                              ("Fecha de inicio", c["fecha_inicio"]), ("Presupuesto diario total", c["presupuesto_diario_total"]),
                                              ("Presupuesto por conjunto", c["presupuesto_por_conjunto"]), ("Duración", c["duracion"]),
                                              ("Audiencia", c["audiencia"]), ("Estructura confirmada", c["estructura_confirmada"]),
                                              ("Destino", "%s (entorno %s; %s)" % (p["destino"]["url_landing_publica"], p["destino"]["entorno"], p["destino"]["fuente"])))]
    L += ["", "Reglas del manual: " + "; ".join("%s: %s" % kv for kv in p["reglas_abo"].items()), "",
          "## Conjuntos y anuncios (1 conjunto = 1 anuncio)", "",
          "| Conjunto | Anuncio | Formato | Título | CTA | Archivos |", "|---|---|---|---|---|---|"]
    for a in p["anuncios"]:
        arch = ", ".join(v for v in (a.get("archivos") or {}).values() if v) or ", ".join(l["archivo"] or "—" for l in a.get("laminas", []))
        L.append("| %s | %s | %s | %s | %s | %s |" % (a["conjunto"], a["anuncio_id"], a["formato"], a.get("titulo") or "—", a["cta"], arch))
    for a in p["anuncios"]:
        L += ["", "### %s · %s" % (a["anuncio_id"], a.get("angulo") or ""), "", "- **Texto primario:** " + (a.get("texto_primario") or "—")]
        if a.get("titulo"):
            L += ["- **Título:** " + a["titulo"], "- **Descripción:** " + (a.get("descripcion") or "—")]
        for l in a.get("laminas", []):
            L.append("- **Lámina %s:** %s · %s" % (l["lamina"], l["titulo"], l["descripcion"]))
        L += ["- **URL con UTM:** `%s`" % a["url_con_utm"], "- Origen de los textos: " + a["origen_textos"]]
    L += ["", "## No entra en este plan", ""] + (["- **%s**: %s → %s" % (x["pieza"], x["motivo"], x["que_hacer"]) for x in p["excluidos"]] or ["- nada"])
    L += ["", "## Pendiente antes de cargar", ""] + ["- [ ] **%s** (%s): %s" % (x["que"], x["quien"], x["nota"]) for x in p["pendientes"]]
    return "\n".join(L) + "\n"


def guia_md(p):
    if p.get("estructura") == "cash_trap_333":
        return guia_md_333(p)
    c, n = p["campana"], len(p["anuncios"])
    return "\n".join([
        "# Cargar la campaña %s en Ads Manager" % c["nombre"], ""] + ([aviso_fecha(p), ""] if aviso_fecha(p) else []) + [
        "Para el dueño. Sin capturas de Meta: se verifica en el primer uso y se corrige esta guía. Antes de empezar, "
        "todo lo de «Pendiente antes de cargar» en `plan_campana.md` tiene que estar resuelto.", "",
        "## 1. Cargar", "",
        "1. Ads Manager → **Crear** → objetivo **Ventas**. Nombre de la campaña: `%s`." % c["nombre"],
        "2. Dejá **desactivado** el presupuesto de campaña (Advantage+ campaign budget): es ABO, el presupuesto va en cada conjunto.",
        "3. Primer conjunto: nombre = la columna «Conjunto» de `plan_campana.md`. Conversión en el **sitio web**, píxel de la tienda, evento **Compra**.",
        "4. Presupuesto diario del conjunto = el que fijaron los dueños; fecha de inicio = la del plan.",
        "5. Audiencia abierta / Advantage; ubicaciones Advantage+ (móvil, Facebook e Instagram).",
        "6. Anuncio: nombre = `anuncio_id` (p. ej. `%s`). Subí los archivos de `creativos/` con ese nombre: 4x5 para feed, 9x16 para historias y reels." % p["anuncios"][0]["anuncio_id"],
        "7. Pegá texto primario, título y descripción **tal cual** del plan (no reescribir). Botón: **%s**." % CTA,
        "8. URL del sitio web: la «URL con UTM» de ese anuncio (copiar entera).",
        "9. Repetí 3–8 para los %d conjuntos (en Ads Manager: duplicar el conjunto y cambiar nombre, archivos, textos y URL)." % n,
        "10. Revisá la vista previa de cada anuncio y publicá. Anotá en `plan_campana.md` la fecha y hora de lanzamiento.", ""]
        + _exportar_md(p))


def _exportar_md(p):
    c = p["campana"]
    cols = ", ".join(x["columna_ads_manager"] for x in p["exportacion"]["columnas"])
    return [
        "## 2. Exportar resultados (para el diagnóstico)", "",
        "1. Ads Manager → pestaña **Anuncios** → filtrá la campaña.",
        "2. **Desglose → Por tiempo → Día**. Ningún otro desglose (ni edad, ni país, ni ubicación).",
        "3. Una sola configuración de atribución para todo el período (la que use la cuenta; no la cambies entre exportaciones).",
        "4. Columnas (personalizar, en este orden): %s." % cols,
        "5. **Exportar → .csv** sin filas de totales. Guardalo como `%s` con la fecha del día en que exportás." % p["exportacion"]["destino"],
        "6. Pasalo al importador: `python herramientas/importar_csv.py <csv> --salida campanas/<fecha>_%s`." % c["nombre"], ""]


def circuito_sintetico(salida, plan):
    """CSV sintético con los anuncio_id del plan → importar_csv → diagnostico. Nada afirma resultados reales."""
    import importar_csv as I
    import diagnostico as DG
    d = os.path.join(salida, "sintetico")
    os.makedirs(d, exist_ok=True)
    ct = plan.get("estructura") == "cash_trap_333"
    cols = [x["columna_ads_manager"] for x in plan["exportacion"]["columnas"]]
    camp = plan["campana"]["nombre"]
    dias = ["2026-10-12", "2026-10-13", "2026-10-14"]
    # gasto, impresiones, alcance, clics, lpv, 3s, checkouts, compras, ingresos (inventados, por anuncio y día)
    base = [(9.8, 1900, 1500, 30, 22, 610, 2, 1, 17), (10.0, 2100, 1700, 24, 15, 540, 1, 0, 0),
            (9.6, 1750, 1400, 19, 12, 480, 0, 0, 0), (10.1, 2300, 1800, 35, 27, 0, 3, 1, 17)]
    filas = []
    for i, a in enumerate(x for x in plan["anuncios"] if not x.get("reserva")):    # la reserva (333) está en pausa: no gasta
        for j, dia in enumerate(dias):
            g, imp, alc, cl, lpv, r3, ch, co, ing = base[i % len(base)]
            f = 1 + 0.05 * j
            vals = {"cuenta": "Cuenta de prueba (sintética)", "campana": camp, "conjunto": a["conjunto"], "anuncio": a["anuncio_id"],
                    "anuncio_id": "9%011d" % (i + 1), "fecha": dia, "moneda": "USD", "atribucion": "7 días tras hacer clic o 1 día tras ver",
                    "gasto": ("%.2f" % (g * f)).replace(".", ","), "impresiones": int(imp * f), "alcance": int(alc * f),
                    "clics_enlace": int(cl * f), "landing_page_views": int(lpv * f), "reproducciones_3s": int(r3 * f) if r3 else "",
                    "checkouts": ch, "compras": co if j != 1 else 0, "ingresos": ("%d" % ing if j != 1 else "0"),
                    "inicio_informe": dias[0], "fin_informe": dias[-1]}
            filas.append([str(vals[x["campo"]]) for x in plan["exportacion"]["columnas"]])
    csv_p = os.path.join(d, "exportacion_sintetica.csv")
    import csv
    with open(csv_p, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        w.writerows(filas)
    err, norm = I.importar(csv_p, d, None, True)
    if not err.get("aceptado"):
        raise ErrorPlan("el CSV sintético no pasó el importador: %s" % err.get("errores"))
    json.dump({"sintetico": True, "_nota": "Contexto inventado para el circuito en seco (TAREA 022B). No es una campaña real.",
               "estructura": "Cash Trap" if ct else "ABO", "lanzamiento": dias[0] + "T00:00", "corte": dias[-1] + "T23:59",
               "presupuesto_dia": "[PENDIENTE: dueños]", "cambios_recientes": [], "historial": "campaña nueva (sintética)",
               "objetivo": "evergreen (Cash Trap 3/3/3, §10)" if ct else "testear (ABO normal, §2.1)", "economia": {"precio": 17, "cpa_maximo": None,
                                                                    "nota": "costos y comisiones no aportados"}},
              open(os.path.join(d, "contexto.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    buf = io.StringIO()
    with redirect_stdout(buf):
        DG.main(["diagnostico.py", d])
    md = ("# Diagnóstico SINTÉTICO · %s\n\n> **Datos inventados** para probar el circuito exportar → importar → diagnosticar. "
          "No son resultados de campaña ni de ventas. Formato de la plantilla §15 (L691–732) que Matías va a contrastar.\n\n" % camp) + buf.getvalue() + "\n"
    # ventas (Sellora ventas.v1.1) cruzadas por utm_content = anuncio_id y día; fixture sintético v1.1 (TAREA 026)
    import importar_ventas as IV
    ventas = IV.leer(os.path.join(RAIZ, "herramientas", "pruebas", "ventas", "ventas_v1_1_sintetico.json"))
    cruce = IV.cruzar(ventas, json.load(open(os.path.join(d, "normalizado.json"), encoding="utf-8")))
    json.dump(dict(cruce, sintetico=True), open(os.path.join(d, "cruce_ventas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    md += "\n" + IV.md(cruce, sintetico=True)
    ruta = os.path.join(salida, "diagnostico_sintetico.md")
    open(ruta, "w", encoding="utf-8", newline="\n").write(md)
    return ruta


def main(argv=None, carpeta_ofertas=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("oferta")
    ap.add_argument("--version", default="v001")
    ap.add_argument("--fecha")
    ap.add_argument("--sintetico", action="store_true")
    ap.add_argument("--sobrescribir", action="store_true", help="rehace la versión indicada (borra la carpeta del plan)")
    ap.add_argument("--estructura", choices=ESTRUCTURAS, default="abo",
                    help="abo (por defecto, §2.1) o cash_trap_333 (1 CBO, 1 conjunto, 3 C1 + 3 C2 + 3 C3 + reserva RES-; P9)")
    a = ap.parse_args(argv)
    try:
        r = generar(a.oferta, a.version, a.fecha, carpeta_ofertas, a.sintetico, a.sobrescribir, estructura=a.estructura)
    except (ErrorPlan, ValueError, OSError) as e:
        print("ERROR %s" % e)
        return 1
    p = r["plan"]
    print("Kit: %s · campaña %s · %d anuncios · %d pendientes · %d excluidos" % (r["carpeta"], p["campana"]["nombre"], len(p["anuncios"]),
                                                                              len(p["pendientes"]), len(p["excluidos"])))
    if aviso_fecha(p):
        print("AVISO: sin --fecha; utm_campaign lleva %s (no cargar así)" % PEND_FECHA)
    if r.get("diagnostico_sintetico"):
        print("Diagnóstico sintético: %s" % r["diagnostico_sintetico"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
