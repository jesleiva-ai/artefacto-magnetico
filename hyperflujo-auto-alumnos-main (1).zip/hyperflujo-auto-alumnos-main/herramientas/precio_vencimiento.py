#!/usr/bin/env python3
"""precio_vencimiento.py — vencimiento de la oferta de lanzamiento (Hyperflujo D77/D78; TAREA 036 parte D).

    python herramientas/precio_vencimiento.py revisar --of OF-001
    python herramientas/precio_vencimiento.py aplicar --of OF-001     # solo con autorización «desactivar_oferta_al_vencer»

D78: la oferta de lanzamiento dura 30 días o más desde la aprobación de Hotmart (o precio.fin_lanzamiento de la ficha,
si es posterior). Hotmart no tiene fecha de fin: la vence el sistema. Al vencer, y solo con la autorización escrita
«desactivar_oferta_al_vencer» vigente:
  1. la landing cambia: el bloque <!-- PRECIO:INICIO -->…<!-- PRECIO:FIN --> pasa a «Precio regular USD {lista}» y los
     enlaces al checkout de la oferta (?off=) pasan al checkout del precio base;
  2. se planifica la acción hotmart_desactivar_oferta para el robot (`hotmart_alta.mjs --flujo desactivar_oferta`).
     [PENDIENTE: selectores de desactivar_oferta sin verificar en el panel real → bloqueo humano «desactivar a mano»];
  3. cuenta como el cambio de anuncios del día (I-0f) para las ventanas de Matías.
Aviso 3 días antes. Nunca se extiende una fecha ya publicada ni se muestra una fecha de fin (revisión 035 h. 12).
Solo biblioteca estándar.
"""
import argparse
import html
import json
import os
import sys
import urllib.parse
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

DIAS_MIN = 30
DIAS_AVISO = 3
INICIO, FIN = "<!-- PRECIO:INICIO -->", "<!-- PRECIO:FIN -->"


def aprobado_en(producto):
    """Fecha en que el producto pasó hotmart_enviado → lista_para_activar (aprobación leída), o None."""
    for h in producto.get("historial", []):
        if h.get("de") == "hotmart_enviado" and h.get("a") == "lista_para_activar":
            return str(h.get("hora", ""))[:10] or None
    return None


def fin_lanzamiento(producto, ficha):
    ap = aprobado_en(producto)
    minimo = (date.fromisoformat(ap) + timedelta(days=DIAS_MIN)).isoformat() if ap else None
    declarado = ((ficha or {}).get("precio") or {}).get("fin_lanzamiento")
    if declarado and minimo:
        return max(declarado, minimo)   # nunca antes de aprobación + 30 días
    return minimo


def revisar(producto, ficha, hoy):
    if producto.get("oferta_vencida_en"):
        return {"estado": "ya_aplicado", "fin": producto.get("fin_lanzamiento")}
    fin = fin_lanzamiento(producto, ficha)
    if not fin:
        return {"estado": "sin_fecha", "fin": None}
    dias = (date.fromisoformat(fin) - date.fromisoformat(hoy)).days
    if dias <= 0:
        return {"estado": "vencido", "fin": fin, "dias_restantes": dias}
    if dias <= DIAS_AVISO:
        return {"estado": "aviso", "fin": fin, "dias_restantes": dias}
    return {"estado": "vigente", "fin": fin, "dias_restantes": dias}


def checkout_base(url):
    """Quita el parámetro off= (oferta de lanzamiento) y deja el checkout del precio base."""
    p = urllib.parse.urlsplit(url)
    q = [(k, v) for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=True) if k.lower() != "off"]
    return urllib.parse.urlunsplit((p.scheme, p.netloc, p.path, urllib.parse.urlencode(q), p.fragment))


def cambiar_landing(of, ficha, checkout_oferta):
    """Bloque de precio → precio regular; enlaces ?off= → checkout base. Devuelve la ruta o None si no hay landing."""
    landing = rutas.dir_oferta(of) / "landing" / "index.html"
    if not landing.exists():
        return None
    precio = (ficha or {}).get("precio") or {}
    lista, moneda = precio.get("lista"), precio.get("moneda") or "USD"
    if not isinstance(lista, (int, float)) or isinstance(lista, bool) or lista <= 0:
        raise ValueError("la ficha no tiene precio.lista: no se puede pasar a precio regular (falla cerrado)")
    texto = landing.read_text(encoding="utf-8")
    textos = ((rutas.cargar_dato("mercados", local=False, defecto={}) or {}).get((ficha.get("mercado") or {}).get("id") or "es-LATAM") or {}).get("textos_precio") or {}
    nuevo = '<p class="precio-regular">%s %s %s</p>' % (html.escape(textos.get("regular", "Precio regular")), html.escape(moneda),
                                                        ("%.2f" % lista).rstrip("0").rstrip("."))
    if INICIO in texto and FIN in texto:
        texto = texto[:texto.index(INICIO) + len(INICIO)] + nuevo + texto[texto.index(FIN):]
    if checkout_oferta:
        texto = texto.replace(checkout_oferta, checkout_base(checkout_oferta))
        texto = texto.replace(html.escape(checkout_oferta), html.escape(checkout_base(checkout_oferta)))
    landing.write_text(texto, encoding="utf-8")
    return landing


def aplicar(of, producto, ficha, *, autorizado, archivo=None):
    """→ {"ok", "landing", "accion_robot", "motivo"}. Sin autorización no cambia nada."""
    import estado as E
    if not autorizado:
        return {"ok": False, "espera": True, "motivo": "oferta de lanzamiento vencida: falta la autorización «desactivar_oferta_al_vencer»"}
    checkout = ((rutas.externo(of).get("hotmart") or {}).get("principal") or {}).get("checkout_url")
    landing = cambiar_landing(of, ficha, checkout)
    ahora = rutas.ahora().isoformat(timespec="seconds")
    E.marcar(of, "oferta_vencida_en", ahora, archivo=archivo)
    E.marcar(of, "ultimo_cambio_anuncios", ahora, archivo=archivo)          # cuenta como el cambio del día (I-0f)
    E.marcar(of, "cambios_hoy", ["fin_lanzamiento"], archivo=archivo)
    E.marcar(of, "cambios_hoy_fecha", ahora[:10], archivo=archivo)
    return {"ok": True, "landing": str(landing) if landing else None,
            "accion_robot": {"tipo": "hotmart_desactivar_oferta", "comando": "node herramientas/hotmart_alta.mjs --flujo desactivar_oferta --modo real",
                             "of": of, "estado": "[PENDIENTE: selectores de desactivar_oferta sin verificar; desactivar a mano en Hotmart]"},
            "motivo": "oferta vencida: landing a precio regular; desactivación de la oferta en Hotmart pendiente"}


if __name__ == "__main__":
    import estado as E
    ap = argparse.ArgumentParser(description="Vencimiento D78 de la oferta de lanzamiento.")
    ap.add_argument("orden", choices=("revisar", "aplicar"))
    ap.add_argument("--of", required=True)
    ap.add_argument("--estado")
    a = ap.parse_args()
    of = rutas.validar_of(a.of)
    prod, fich = E.obtener(of, a.estado), rutas.leer_json(rutas.ruta_ficha(of), defecto={})
    r = revisar(prod, fich, rutas.hoy())
    if a.orden == "aplicar" and r["estado"] == "vencido":
        import autorizaciones
        r = aplicar(of, prod, fich, autorizado="desactivar_oferta_al_vencer" in autorizaciones.vigentes(of, rutas.hoy()), archivo=a.estado)
    print(json.dumps({"ok": True, "codigo": 0, "motivo": json.dumps(r, ensure_ascii=False)[:400], "artefactos": []}, ensure_ascii=False))
