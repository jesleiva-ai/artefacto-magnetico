"""Preferencias del dueño: cómo quiere usar su hyperflujo (Ramiro, 2026-10-29: «que cada uno lo modifique a su gusto y le
quede persistente en cada chat nuevo, carpeta nueva o entorno nuevo»).

Se guardan en ~/.hyperflujo/preferencias.md, fuera del repo: la actualización diaria (actualizar.py) no las toca y valen
para cualquier chat o carpeta de esa computadora. Para llevarlas a otra computadora se copia la carpeta ~/.hyperflujo/.

Las lee:
- cada sesión de Claude Code al abrir (hook SessionStart de .claude/settings.json, con --hook);
- cada worker del director (lanzar_worker.armar_prompt las suma al prompt de la etapa).

    python herramientas/preferencias.py ver
    python herramientas/preferencias.py agregar "Uso el sistema en modo semiautomático: me muestra antes de publicar"
    python herramientas/preferencias.py quitar 3
    python herramientas/preferencias.py --hook
Última línea: JSON del contrato (salvo --hook, que imprime el texto para Claude).
"""
import argparse
import datetime as dt
import json
import os
import re
import sys
from pathlib import Path

ENCABEZADO = ("# Preferencias del dueño\n\nCómo quiere usar su hyperflujo. Mandan sobre las recetas, las skills y los valores "
              "por defecto del método. Una por línea; se agregan y se quitan con `herramientas/preferencias.py`.\n\n")
RE_ITEM = re.compile(r"^- (?:\[(\d{4}-\d{2}-\d{2})\] )?(.+)$")


def archivo():
    base = os.environ.get("HYPERFLUJO_PREFS") or str(Path.home() / ".hyperflujo")
    return Path(base) / "preferencias.md"


def leer():
    """Lista de {fecha, texto}, en orden. Sin archivo: lista vacía."""
    try:
        lineas = archivo().read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in lineas:
        m = RE_ITEM.match(ln.strip())
        if m:
            out.append({"fecha": m.group(1), "texto": m.group(2).strip()})
    return out


def _escribir(items):
    p = archivo()
    p.parent.mkdir(parents=True, exist_ok=True)
    cuerpo = "".join("- %s%s\n" % ("[%s] " % i["fecha"] if i.get("fecha") else "", i["texto"]) for i in items)
    p.write_text(ENCABEZADO + cuerpo, encoding="utf-8")


def agregar(texto, hoy=None):
    texto = " ".join((texto or "").split())
    if not texto:
        raise ValueError("preferencia vacía")
    items = leer()
    if any(i["texto"].lower() == texto.lower() for i in items):
        return items
    items.append({"fecha": hoy or dt.date.today().isoformat(), "texto": texto})
    _escribir(items)
    return items


def quitar(numero):
    items = leer()
    if not 1 <= numero <= len(items):
        raise ValueError("no hay preferencia número %d (hay %d)" % (numero, len(items)))
    quitada = items.pop(numero - 1)
    _escribir(items)
    return quitada, items


def bloque():
    """Texto para el prompt de un worker o el inicio de una sesión; vacío si no hay preferencias."""
    items = leer()
    if not items:
        return ""
    return ("## Preferencias del dueño (mandan sobre la receta, la skill y los valores por defecto)\n"
            + "".join("%d. %s\n" % (n, i["texto"]) for n, i in enumerate(items, 1)))


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Preferencias persistentes del dueño (~/.hyperflujo/preferencias.md).")
    ap.add_argument("--hook", action="store_true", help="imprime las preferencias para el inicio de una sesión de Claude Code")
    sub = ap.add_subparsers(dest="orden")
    sub.add_parser("ver")
    a_ag = sub.add_parser("agregar")
    a_ag.add_argument("texto", nargs="+")
    a_qu = sub.add_parser("quitar")
    a_qu.add_argument("numero", type=int)
    a = ap.parse_args(argv)
    if a.hook:
        b = bloque()
        if b:
            print(b + "Aplicalas en todo lo que hagas en esta sesión. Si la persona pide otra, guardala con "
                      "`python herramientas/preferencias.py agregar \"…\"`.")
        return 0
    try:
        if a.orden == "agregar":
            items = agregar(" ".join(a.texto))
            r = {"ok": True, "codigo": 0, "motivo": "preferencia guardada (%d en total)" % len(items)}
        elif a.orden == "quitar":
            quitada, items = quitar(a.numero)
            r = {"ok": True, "codigo": 0, "motivo": "quitada: %s" % quitada["texto"]}
        else:
            items = leer()
            r = {"ok": True, "codigo": 0, "motivo": "%d preferencias" % len(items)}
    except ValueError as e:
        print(json.dumps({"ok": False, "codigo": 2, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
        return 2
    r.update(preferencias=["%d. %s" % (n, i["texto"]) for n, i in enumerate(items, 1)], artefactos=[str(archivo())])
    print(json.dumps(r, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
