#!/usr/bin/env python3
# Copiado del taller hyperflujo/herramientas/ y generalizado para hyperflujo-auto (TAREA 035, módulo núcleo).
"""Presupuesto por oferta (TAREA 015; rediseñado en TAREA 016 según la revisión de Codex de 014 [P1]).

La ficha (`ofertas/<OF>/oferta.json`) lleva:
    "presupuesto": {"autorizado": 6.0, "unidad": "USD", "max_por_solicitud": 0.5,
                    "autorizado_por": "...", "fecha": "...", "version": 2,
                    "excepciones": [{"proveedor": "heygen", "monto": 4.5, "motivo": "...", "autorizado_por": "...",
                                     "fecha": "...", "clave": null}]}

Cálculo por (ejecución, proveedor) — el registro guarda el real por proveedor y ejecución, no por solicitud:
  * Cada solicitud paga (no gratuita) del proveedor está en una de estas categorías según su estado persistido:
      en_vuelo   planificada, enviando, enviada, en_proceso, completada, envio_incierto → RESERVA (su estimado)
      consumida  descargada                                                         → la reserva se libera y
                                                                                      pasa a consumo estimado
      retenida   fallida con ID externo (pudo cobrarse)                             → conserva su estimado
      liberada   fallida sin ID externo (el proveedor rechazó: no hubo creación)    → 0
    Como la categoría sale del estado persistido de cada solicitud, la reserva sobrevive a un reinicio y una
    solicitud cuenta una sola vez (nunca a la vez como reserva y como consumo).
  * real (conciliado) se guarda aparte del estimado. Si hay real, cubre las solicitudes de `real_cubre`; las
    posteriores cuentan por su estimado. usado(EJ, prov) = real + estimados no cubiertos, o Σ estimados si no hay real.
  * Unidades propias → USD con datos/tarifas.json: cada conversión necesita usd_por_unidad, fecha y fuente.
    Conversión ausente o incompleta → bloqueo (no se envía nada).
  * Sobreconsumo conocido → bloqueo de toda solicitud nueva de la oferta hasta que un dueño lo revise:
    un real conciliado mayor que el tope de su ejecución, o lo usado de la oferta mayor que lo autorizado.
  * Solicitud > max_por_solicitud → necesita excepción escrita (proveedor, monto ≥ estimado, motivo, autorizado_por).
  * Ficha sin presupuesto.autorizado → ninguna solicitud paga.
  * Proveedor con tope GLOBAL en tarifas.json (TAREA 030: anthropic, `fuera_del_presupuesto_usd` + `tope_mensual_usd` +
    `max_por_llamada_usd`): no descuenta del presupuesto de la oferta; rige el tope de la ejecución, el máximo por llamada
    y el tope mensual sumando todas las ofertas (uso_mensual / verificar_global).
Lo invoca registro.py en agregar_solicitud y marcar_enviando: así lo cumplen TODOS los adaptadores (Higgsfield, KIE,
ElevenLabs, HeyGen) antes de enviar. Solo lee JSON: no modifica registros.

    python herramientas/presupuesto.py OF-001
"""
import glob
import json
import os
import sys
for _f in (sys.stdout, sys.stderr):  # consola cp1252 de Windows (F41)
    try:
        _f.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

RAIZ = os.environ.get("HYPERFLUJO_RAIZ") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # generalizado (Hyperflujo, TAREA 035)
TARIFAS = os.path.join(RAIZ, "datos", "tarifas.json")
EN_VUELO = ("planificada", "enviando", "enviada", "en_proceso", "completada", "envio_incierto")


class PresupuestoInsuficiente(Exception):
    pass


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def cargar_tarifas(ruta=None):
    ruta = ruta or os.environ.get("HYPERFLUJO_TARIFAS") or TARIFAS
    with open(ruta, encoding="utf-8") as f:
        t = json.load(f)
    # TAREA 037 D: datos/tarifas.local.json (fuera de git) sobrescribe proveedor por proveedor, como dice tarifas.json
    local = os.path.join(os.path.dirname(ruta), "tarifas.local.json")
    if os.path.abspath(ruta) == os.path.abspath(TARIFAS) and os.path.exists(local):
        with open(local, encoding="utf-8") as f:
            t.setdefault("proveedores", {}).update((json.load(f).get("proveedores") or {}))
    return t


def a_usd(proveedor, unidad, monto, tarifas):
    if monto is None:
        return None
    if (unidad or "").upper() == "USD":
        return float(monto)
    t = (tarifas.get("proveedores") or {}).get(proveedor) or {}
    if t.get("unidad") != unidad or not _num(t.get("usd_por_unidad")) or t["usd_por_unidad"] <= 0:
        raise PresupuestoInsuficiente("Sin conversión a USD para %s en '%s' (datos/tarifas.json): no se envía." % (proveedor, unidad))
    if not t.get("fecha") or not t.get("fuente"):
        raise PresupuestoInsuficiente("La conversión de %s en tarifas.json no tiene fecha y fuente: no se envía." % proveedor)
    return float(monto) * t["usd_por_unidad"]


def _unidad(u):
    """«créditos», «creditos», «credito» → «credito» (para comparar unidades sin depender del plural o la tilde)."""
    u = (u or "").strip().lower().replace("é", "e")
    return u[:-1] if u.endswith("s") and u != "usd" else u


def plan_propio(proveedor, tarifas):
    """Tarifa de un proveedor cuyo consumo va en unidades de un plan ya pago (D41: higgsfield_plan): se controla solo con
    el tope de la ejecución en esa unidad y su USD es informativo (no descuenta del presupuesto USD de la oferta)."""
    t = (tarifas.get("proveedores") or {}).get(proveedor) or {}
    return t if t.get("fuera_del_presupuesto_usd") else None


def dir_oferta_de(ruta_registro):
    """ofertas/<OF>/ejecuciones/EJ-NNN/registro.json → ofertas/<OF> (o None si el registro no vive en una oferta)."""
    ej = os.path.dirname(os.path.abspath(ruta_registro))
    ejecs = os.path.dirname(ej)
    if os.path.basename(ejecs) != "ejecuciones":
        return None
    base = os.path.dirname(ejecs)
    return base if os.path.isfile(os.path.join(base, "oferta.json")) else None


def categoria(s):
    if s.get("estado") == "descargada":
        return "consumida"
    if s.get("estado") == "fallida":
        return "retenida" if s.get("id_externo") else "liberada"
    return "en_vuelo"


def desglose(reg, proveedor):
    """Real y estimado por separado para (ejecución, proveedor), en la unidad del registro."""
    c = (reg.get("consumo") or {}).get(proveedor) or {}
    sols = [s for s in reg.get("solicitudes", []) if s.get("proveedor") == proveedor and not s.get("gratuita")]
    cat = {"en_vuelo": 0.0, "consumida": 0.0, "retenida": 0.0, "liberada": 0.0}
    for s in sols:
        if _num(s.get("estimado")):
            cat[categoria(s)] += s["estimado"]
    real = c.get("real") if c.get("estado") == "conciliado" and _num(c.get("real")) else None
    if real is not None:
        cubre = c.get("real_cubre")
        cubre = set(x.get("solicitud_id") for x in sols) if cubre is None else set(cubre)   # registros previos a 015
        no_cubierto = sum(s["estimado"] for s in sols if s.get("solicitud_id") not in cubre and categoria(s) != "liberada"
                          and _num(s.get("estimado")))
        usado = real + no_cubierto
    else:
        no_cubierto = None
        usado = cat["en_vuelo"] + cat["consumida"] + cat["retenida"]
    tope = c.get("tope_autorizado")
    return {"unidad": c.get("unidad"), "tope": tope, "reserva_en_vuelo": cat["en_vuelo"], "consumido_estimado": cat["consumida"],
            "retenido": cat["retenida"], "liberado": cat["liberada"], "real": real, "estimado_no_cubierto": no_cubierto,
            "usado": usado, "sobreconsumo": bool(real is not None and _num(tope) and real > tope + 1e-9)}


def uso(dir_oferta, tarifas=None, reemplazo=None):
    """Uso en USD de todas las ejecuciones. `reemplazo` = (ruta_registro, reg en memoria) del registro que se modifica."""
    tarifas = tarifas or cargar_tarifas()
    filas, total = [], 0.0
    rutas = sorted(glob.glob(os.path.join(dir_oferta, "ejecuciones", "EJ-*", "registro.json")))
    rep_ruta = os.path.abspath(reemplazo[0]) if reemplazo else None
    if rep_ruta and rep_ruta not in [os.path.abspath(r) for r in rutas]:
        rutas.append(rep_ruta)
    for ruta in rutas:
        if rep_ruta and os.path.abspath(ruta) == rep_ruta:
            reg = reemplazo[1]
        else:
            with open(ruta, encoding="utf-8") as f:
                reg = json.load(f)
        for prov in (reg.get("consumo") or {}):
            d = desglose(reg, prov)
            pp = plan_propio(prov, tarifas)
            if pp:                                   # D41: USD informativo, fuera del total de la oferta
                inf = d["usado"] * pp["usd_por_unidad"] if d["usado"] and _num(pp.get("usd_por_unidad")) else None
                filas.append(dict(d, ejecucion=reg.get("ejecucion_id"), proveedor=prov, usd=0.0,
                                  usd_informativo=round(inf, 4) if inf is not None else None,
                                  fuente="real" if d["real"] is not None else "estimado"))
                continue
            usd = a_usd(prov, d["unidad"], d["usado"], tarifas) if d["usado"] else 0.0
            filas.append(dict(d, ejecucion=reg.get("ejecucion_id"), proveedor=prov, usd=round(usd, 4),
                              fuente="real" if d["real"] is not None else "estimado"))
            total += usd
    return {"usado_usd": round(total, 4), "detalle": filas}


def _ficha(dir_oferta):
    with open(os.path.join(dir_oferta, "oferta.json"), encoding="utf-8") as f:
        return json.load(f)


def estado(dir_oferta, tarifas=None):
    p = _ficha(dir_oferta).get("presupuesto") or {}
    u = uso(dir_oferta, tarifas)
    aut = p.get("autorizado")
    sobre = [d for d in u["detalle"] if d["sobreconsumo"]]
    return {"autorizado": aut, "unidad": p.get("unidad"), "max_por_solicitud": p.get("max_por_solicitud"),
            "usado_usd": u["usado_usd"], "restante_usd": round(aut - u["usado_usd"], 4) if _num(aut) else None,
            "sobreconsumo": [{"ejecucion": d["ejecucion"], "proveedor": d["proveedor"], "real": d["real"], "tope": d["tope"]} for d in sobre]
                            + ([{"oferta": True, "usado_usd": u["usado_usd"], "autorizado": aut}] if _num(aut) and u["usado_usd"] > aut + 1e-9 else []),
            "excepciones": p.get("excepciones", []), "detalle": u["detalle"]}


def mes_de(reg):
    return str(reg.get("creada_en") or "")[:7]


def uso_mensual(carpeta_ofertas, proveedor, mes, reemplazo=None):
    """Uso de un proveedor con tope GLOBAL (TAREA 030: anthropic) en un mes calendario, sumando TODAS las ofertas.
    Cada ejecución cuenta en el mes de su creada_en; por ejecución: real conciliado + estimados no cubiertos, o la
    suma de estimados en vuelo/consumidos/retenidos (desglose). `reemplazo` = (ruta, reg en memoria)."""
    rutas = sorted(glob.glob(os.path.join(carpeta_ofertas, "*", "ejecuciones", "EJ-*", "registro.json")))
    rep = os.path.abspath(reemplazo[0]) if reemplazo else None
    if rep and rep not in [os.path.abspath(r) for r in rutas]:
        rutas.append(rep)
    total, filas = 0.0, []
    for ruta in rutas:
        if rep and os.path.abspath(ruta) == rep:
            reg = reemplazo[1]
        else:
            try:
                with open(ruta, encoding="utf-8") as f:
                    reg = json.load(f)
            except (OSError, ValueError):
                continue
        if mes_de(reg) != mes or proveedor not in (reg.get("consumo") or {}):
            continue
        d = desglose(reg, proveedor)
        if d["usado"]:
            total += d["usado"]
            filas.append({"oferta": reg.get("oferta_id"), "ejecucion": reg.get("ejecucion_id"), "usado": round(d["usado"], 6),
                          "fuente": "real" if d["real"] is not None else "estimado"})
    return {"mes": mes, "usado": round(total, 6), "detalle": filas}


def verificar_global(ruta_registro, reg, proveedor, estimado, pp, tarifas=None, excluir_sid=None):
    """Máximo por llamada y tope mensual global del proveedor (tarifas.json: max_por_llamada_usd, tope_mensual_usd)."""
    est_usd = float(estimado) * float(pp.get("usd_por_unidad") or 1)
    maximo = pp.get("max_por_llamada_usd")
    if _num(maximo) and est_usd > maximo + 1e-9:
        raise PresupuestoInsuficiente("%s: estimado USD %.4f supera el máximo por llamada (USD %s, %s): no se envía."
                                      % (proveedor, est_usd, maximo, pp.get("autorizacion") or "tarifas.json"))
    tope = pp.get("tope_mensual_usd")
    if not _num(tope):
        return {"global": True, "solicitud_usd": round(est_usd, 6)}
    if excluir_sid:
        reg = dict(reg, solicitudes=[x for x in reg.get("solicitudes", []) if x.get("solicitud_id") != excluir_sid])
    base = dir_oferta_de(ruta_registro)
    mes = mes_de(reg)
    u = uso_mensual(os.path.dirname(base), proveedor, mes, reemplazo=(ruta_registro, reg))
    if u["usado"] + est_usd > tope + 1e-9:
        raise PresupuestoInsuficiente("Tope mensual de %s (%s): usado USD %.4f en %s + esta llamada USD %.4f supera USD %s: no se envía."
                                      % (proveedor, pp.get("autorizacion") or "tarifas.json", u["usado"], mes, est_usd, tope))
    return {"global": True, "mes": mes, "usado_mes_usd": u["usado"], "solicitud_usd": round(est_usd, 6), "tope_mensual_usd": tope}


def verificar(ruta_registro, reg, proveedor, estimado, unidad, clave=None, tarifas=None, excluir_sid=None):
    """Lanza PresupuestoInsuficiente si la nueva solicitud no entra. La solicitud se suma aparte: si ya está en `reg`
    (re-comprobación en marcar_enviando), pasar su ID en `excluir_sid`."""
    base = dir_oferta_de(ruta_registro)
    if base is None:
        return None          # registro fuera de una oferta (pruebas): solo rige el tope de la ejecución
    tarifas = tarifas or cargar_tarifas()
    pp = plan_propio(proveedor, tarifas)
    if pp:
        if _unidad(unidad) != _unidad(pp.get("unidad")):
            raise PresupuestoInsuficiente("%s se mide en '%s' y el tope de la ejecución está en '%s': no se envía."
                                          % (proveedor, pp.get("unidad"), unidad))
        if not pp.get("fecha") or not pp.get("fuente"):
            raise PresupuestoInsuficiente("La tarifa de %s en tarifas.json no tiene fecha y fuente: no se envía." % proveedor)
        if _num(pp.get("tope_mensual_usd")) or _num(pp.get("max_por_llamada_usd")):
            return verificar_global(ruta_registro, reg, proveedor, estimado, pp, tarifas, excluir_sid)
        return {"plan_propio": True, "unidad": pp["unidad"], "solicitud": estimado}   # solo rige el tope de la EJ (D41)
    p = _ficha(base).get("presupuesto") or {}
    aut = p.get("autorizado")
    if not _num(aut) or aut <= 0 or (p.get("unidad") or "").upper() != "USD" or not p.get("autorizado_por"):
        raise PresupuestoInsuficiente("La ficha de %s no tiene presupuesto.autorizado (> 0, USD, con autorizado_por): "
                                      "ninguna solicitud paga." % os.path.basename(base))
    est_usd = a_usd(proveedor, unidad, estimado, tarifas)
    maximo = p.get("max_por_solicitud")
    if _num(maximo) and est_usd > maximo + 1e-9:
        ok = [e for e in p.get("excepciones", []) if e.get("proveedor") == proveedor and e.get("autorizado_por")
              and e.get("motivo") and _num(e.get("monto")) and e["monto"] + 1e-9 >= est_usd
              and (not e.get("clave") or e.get("clave") == clave)]
        if not ok:
            raise PresupuestoInsuficiente("%s: USD %.4f supera el máximo por solicitud (USD %s) y no hay excepción escrita "
                                          "para %s%s." % (proveedor, est_usd, maximo, proveedor, " / " + clave if clave else ""))
    if excluir_sid:
        reg = dict(reg, solicitudes=[x for x in reg.get("solicitudes", []) if x.get("solicitud_id") != excluir_sid])
    u = uso(base, tarifas, reemplazo=(ruta_registro, reg))
    sobre = [d for d in u["detalle"] if d["sobreconsumo"]]
    if sobre:
        raise PresupuestoInsuficiente("Sobreconsumo conocido en %s (real mayor que el tope de su ejecución): bloqueado hasta que "
                                      "un dueño lo revise." % ", ".join("%s/%s" % (d["ejecucion"], d["proveedor"]) for d in sobre))
    if u["usado_usd"] > aut + 1e-9:
        raise PresupuestoInsuficiente("Sobreconsumo conocido en %s: usado USD %.4f > autorizado USD %s." % (os.path.basename(base), u["usado_usd"], aut))
    if u["usado_usd"] + est_usd > aut + 1e-9:
        raise PresupuestoInsuficiente("Presupuesto de %s: usado USD %.4f + esta solicitud USD %.4f supera lo autorizado USD %s."
                                      % (os.path.basename(base), u["usado_usd"], est_usd, aut))
    return {"usado_usd": u["usado_usd"], "solicitud_usd": round(est_usd, 4), "autorizado": aut}


def main(a):
    if len(a) != 2:
        print(__doc__)
        return 2
    e = estado(os.path.join(RAIZ, "ofertas", a[1]))
    print("%s · autorizado %s %s · usado USD %.4f · restante %s · máx. por solicitud %s · excepciones %d · sobreconsumo %s" % (
        a[1], e["autorizado"], e["unidad"], e["usado_usd"], e["restante_usd"], e["max_por_solicitud"], len(e["excepciones"]),
        e["sobreconsumo"] or "no"))
    for d in e["detalle"]:
        print("  %-7s %-11s usado %s %s → USD %s (%s) · reserva en vuelo %s · consumido est. %s · retenido %s · liberado %s · real %s" % (
            d["ejecucion"], d["proveedor"], round(d["usado"], 4), d["unidad"], d["usd"], d["fuente"], d["reserva_en_vuelo"],
            d["consumido_estimado"], d["retenido"], d["liberado"], d["real"]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
