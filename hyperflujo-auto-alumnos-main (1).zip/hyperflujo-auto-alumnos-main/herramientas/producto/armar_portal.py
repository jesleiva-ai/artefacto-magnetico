#!/usr/bin/env python3
"""armar_portal.py — portal del comprador, PDF de acceso por pieza y medios públicos para Meta (TAREA 037 D, OF-006).

    python herramientas/producto/armar_portal.py --of OF-006            # arma ofertas/OF-006/portal/dist/ y producto/acceso/
    python herramientas/producto/armar_portal.py --of OF-006 --sin-pdf  # sin regenerar los PDF de acceso

Diseño (D94/F36 del taller: portal con GET anónimo 200): sitio <slug>-portal.netlify.app con
  /m/<token>/<pieza>/index.html   página de descarga de cada producto (PDF + ZIP de editables); <token> aleatorio,
                                  guardado solo en ofertas/<OF>/externo.local.json (fuera de git); la raíz no lista nada.
  /medios/<archivo>.png           creativos de los anuncios (URL pública que pide el conector de Meta).
Cada pieza de Hotmart entrega un PDF de acceso de una hoja con su enlace (producto/acceso/<pieza>.pdf).
Solo biblioteca estándar (+ node para el PDF de acceso).
"""
import argparse
import hashlib
import html
import json
import os
import secrets
import shutil
import subprocess
import sys
import zipfile

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, "..", ".."))
sys.path.insert(0, os.path.join(RAIZ, "herramientas"))
import rutas  # noqa: E402

PIEZAS = [  # (id, carpeta relativa a producto/, nombre visible, PDFs dentro de la carpeta)
    ("principal", "principal", None, [("guia1", "principal/guia1/guia1.pdf", "Guía 1 · Documentos de texto"),
                                      ("guia2", "principal/guia2/guia2.pdf", "Guía 2 · Hojas de cálculo"),
                                      ("guia3", "principal/guia3/guia3.pdf", "Guía 3 · Presentaciones")]),
    ("bump1", "escalera/bump1", None, [("bump1", "escalera/bump1/bump1.pdf", "Guía de uso de las plantillas")]),
    ("bump2", "escalera/bump2", None, [("bump2", "escalera/bump2/bump2.pdf", "Guía de uso de las hojas")]),
    ("bump3", "escalera/bump3", None, [("bump3", "escalera/bump3/bump3.pdf", "Chuleta de atajos (para imprimir)")]),
    ("upsell", "escalera/upsell", None, [("upsell", "escalera/upsell/upsell.pdf", "Casos prácticos resueltos")]),
    ("downsell1", "escalera/downsell1", None, [("downsell1", "escalera/downsell1/downsell1.pdf", "Fórmulas y funciones")]),
    ("downsell2", "escalera/downsell2", None, [("downsell2", "escalera/downsell2/downsell2.pdf", "Guía de diseño de presentaciones")]),
]
CSS = """:root{--p:#17132a;--s:#635e78;--a:#e15b00;--g:#f3f2f7}*{box-sizing:border-box}body{margin:0;font-family:Manrope,'Segoe UI',Arial,sans-serif;color:#1d1b26;background:#fff}
.cab{background:var(--p);color:#fff;padding:28px 20px}.cab b{color:var(--a);letter-spacing:.08em;text-transform:uppercase;font-size:13px}.cab h1{font-family:'Playfair Display',Georgia,serif;margin:.3em 0 0;font-size:28px}
main{max-width:760px;margin:0 auto;padding:24px 18px}.it{display:flex;justify-content:space-between;align-items:center;gap:12px;border:1px solid #d9d6e3;border-radius:16px;padding:14px 16px;margin:12px 0}
.it a{background:var(--a);color:#fff;text-decoration:none;font-weight:800;border-radius:999px;padding:10px 18px;white-space:nowrap}.it small{color:var(--s)}p.n{color:var(--s);font-size:14px}
footer{max-width:760px;margin:30px auto;padding:0 18px;color:var(--s);font-size:12px}"""


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def pagina(titulo, items, nota):
    filas = "".join('<div class="it"><div><strong>%s</strong><br><small>%s</small></div><a href="%s" download>Descargar</a></div>'
                    % (html.escape(t), html.escape(d), html.escape(u)) for t, d, u in items)
    return ("<!doctype html><html lang=\"es-ES\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<meta name=\"robots\" content=\"noindex,nofollow\"><title>%s · Paso a Clic</title><style>%s</style></head><body>"
            "<div class=\"cab\"><b>Paso a Clic</b><h1>%s</h1></div><main><p>Aquí tienes tu material. Descárgalo y guárdalo en tu ordenador: "
            "los PDF se leen en cualquier dispositivo y los archivos editables se abren con Microsoft Word, Excel y PowerPoint o con LibreOffice (gratis).</p>"
            "%s<p class=\"n\">%s</p><p class=\"n\">¿Algún problema con la descarga? Escribe a %s.</p></main>"
            "<footer>Microsoft, Word, Excel y PowerPoint son marcas de Microsoft Corporation. Paso a Clic no está afiliado ni patrocinado por Microsoft. "
            "LibreOffice es una marca de The Document Foundation.</footer></body></html>"
            % (html.escape(titulo), CSS, html.escape(titulo), filas, html.escape(nota), html.escape(SOPORTE)))


def acceso_html(titulo, url):
    css = os.path.relpath(os.path.join(AQUI, "guia.css"), DIR_ACCESO).replace("\\", "/")
    return ("<!doctype html><html lang=\"es-ES\"><head><meta charset=\"utf-8\"><title>Acceso · %s</title>"
            "<link rel=\"stylesheet\" href=\"%s\"></head><body><section class=\"portada\" id=\"portada\">"
            "<div class=\"marca-txt\">Paso a Clic</div><div><h1>%s</h1><p class=\"sub\">Tu acceso a todo el material</p>"
            "<p class=\"sub\" style=\"margin-top:14mm\">1. Abre este enlace en tu navegador (también desde el móvil):</p>"
            "<p style=\"position:relative;z-index:1;font-size:13pt;word-break:break-all;background:#fff;color:#17132a;padding:4mm 5mm;border-radius:4mm\">"
            "<a href=\"%s\" style=\"color:#17132a\">%s</a></p>"
            "<p class=\"sub\">2. Pulsa «Descargar» en cada archivo y guárdalos en tu ordenador.</p>"
            "<p class=\"sub\">3. Empieza por el primer capítulo y haz los ejercicios a tu ritmo.</p></div>"
            "<div class=\"pie\">Soporte: %s · Garantía de %s días desde la compra.</div><div class=\"deco\"></div><div class=\"deco2\"></div></section></body></html>"
            % (html.escape(titulo), css, html.escape(titulo), html.escape(url), html.escape(url), html.escape(SOPORTE), GARANTIA))


def main(argv=None):
    global SOPORTE, DIR_ACCESO, GARANTIA
    ap = argparse.ArgumentParser()
    ap.add_argument("--of", required=True)
    ap.add_argument("--sin-pdf", action="store_true")
    a = ap.parse_args(argv)
    of = rutas.validar_of(a.of)
    base = rutas.dir_oferta(of)
    ficha = rutas.ficha(of)
    SOPORTE = (rutas.cargar_dato("cuentas").get("hotmart") or {}).get("correo_soporte") or "[PENDIENTE: correo de soporte]"
    GARANTIA = int((ficha.get("condiciones_comerciales") or {})["garantia_dias"])   # la ficha manda (037 D: 15 días UE)
    slug = ficha["marca"]["dominio"].split(".")[0]
    sitio = slug + "-portal"
    ext = rutas.externo(of)
    portal = ext.get("portal") or {}
    token = portal.get("token") or secrets.token_urlsafe(9).replace("-", "x").replace("_", "y")
    url_base = "https://%s.netlify.app/m/%s/" % (sitio, token)
    rutas.guardar_externo(of, portal={"sitio": sitio, "token": token, "url_base": url_base})
    rutas.guardar_externo(of, medios={"base_url": "https://%s.netlify.app/medios/" % sitio})
    dist = base / "portal" / "dist"
    if dist.exists():
        shutil.rmtree(dist)
    (dist / "medios").mkdir(parents=True)
    (dist / "index.html").write_text("<!doctype html><html lang=\"es-ES\"><head><meta charset=\"utf-8\"><meta name=\"robots\" content=\"noindex\">"
                                     "<title>Paso a Clic</title></head><body style=\"font-family:Arial;padding:40px\"><h1>Paso a Clic</h1>"
                                     "<p>Para acceder a tu material usa el enlace del PDF de acceso que recibiste al comprar.</p></body></html>", encoding="utf-8")
    # TAREA 037 D: Meta baja las imágenes de /medios/ respetando robots.txt; las páginas con token siguen fuera de buscadores
    (dist / "robots.txt").write_text("User-agent: *\nAllow: /medios/\nDisallow: /m/\n", encoding="utf-8")
    nombres = {"principal": ficha["escalera"]["principal"]["nombre"]}
    for x in ficha["escalera"]["bumps"] + [ficha["escalera"]["upsell"]] + ficha["escalera"]["downsells"]:
        nombres[x["id"]] = x["nombre"]
    DIR_ACCESO = str(base / "producto" / "acceso")
    os.makedirs(DIR_ACCESO, exist_ok=True)
    manifiesto = {"of": of, "sitio": sitio, "piezas": {}}
    for pid, carpeta, _, pdfs in PIEZAS:
        destino = dist / "m" / token / pid
        destino.mkdir(parents=True)
        items = []
        for _, rel, etiqueta in pdfs:
            src = base / "producto" / rel
            shutil.copy2(src, destino / os.path.basename(rel))
            items.append((etiqueta, "PDF · %.1f MB" % (os.path.getsize(src) / 1e6), os.path.basename(rel)))
        arch = base / "producto" / carpeta / "archivos"
        if pid == "principal":
            arch_list = [(g, base / "producto" / "principal" / g / "archivos") for g in ("guia1", "guia2", "guia3")]
        else:
            arch_list = [(pid, arch)] if arch.is_dir() else []
        archivos_zip = []
        for etiqueta, carpeta_a in arch_list:
            archivos_zip += [(etiqueta, carpeta_a / f) for f in sorted(os.listdir(carpeta_a)) if f.lower().endswith((".docx", ".xlsx", ".pptx"))]
        if archivos_zip:
            nombre_zip = "archivos-editables-%s.zip" % pid
            with zipfile.ZipFile(destino / nombre_zip, "w", zipfile.ZIP_DEFLATED) as z:
                for etiqueta, f in archivos_zip:
                    z.write(f, ("%s/%s" % (etiqueta, f.name)) if pid == "principal" else f.name)
            items.append(("Archivos editables (%d)" % len(archivos_zip), "ZIP · .docx / .xlsx / .pptx", nombre_zip))
        titulo = nombres[pid]
        (destino / "index.html").write_text(pagina(titulo, items, "Las ilustraciones son esquemas: los menús pueden variar según el programa y su versión."), encoding="utf-8")
        url = url_base + pid + "/"
        manifiesto["piezas"][pid] = {"titulo": titulo, "url": url, "archivos": [i[2] for i in items],
                                     "sha256": {i[2]: sha(destino / i[2]) for i in items}}
        if not a.sin_pdf:
            h = os.path.join(DIR_ACCESO, "acceso-%s.html" % pid)
            open(h, "w", encoding="utf-8").write(acceso_html(titulo, url))
            pdf = os.path.join(DIR_ACCESO, "acceso-%s.pdf" % pid)
            r = subprocess.run(["node", os.path.join(AQUI, "pdf_guia.mjs"), h, pdf, "--pie", "Paso a Clic · Acceso",
                                "--capturas", "portada", "--dir-capturas", os.path.join(DIR_ACCESO, "capturas", pid)],
                               capture_output=True, text=True, cwd=RAIZ)
            if r.returncode != 0:
                raise SystemExit("PDF de acceso de %s: %s" % (pid, r.stdout + r.stderr))
            manifiesto["piezas"][pid]["acceso_pdf"] = {"archivo": os.path.relpath(pdf, base).replace("\\", "/"), "sha256": sha(pdf)}
    # medios públicos para Meta: creativos de los anuncios
    cre = base / "anuncios" / "creativos"
    if cre.is_dir():
        for f in sorted(cre.glob("*.png")):
            shutil.copy2(f, dist / "medios" / f.name)
    rutas.escribir_json(base / "portal" / "manifiesto.local.json", manifiesto)
    tam = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(dist) for f in fs)
    print(json.dumps({"ok": True, "sitio": sitio, "piezas": list(manifiesto["piezas"]), "mb": round(tam / 1e6, 1),
                      "medios": len(list((dist / "medios").glob("*.png")))}, ensure_ascii=False))


if __name__ == "__main__":
    main()
