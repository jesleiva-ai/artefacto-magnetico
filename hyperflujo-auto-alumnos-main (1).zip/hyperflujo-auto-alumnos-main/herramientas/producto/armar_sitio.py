#!/usr/bin/env python3
"""armar_sitio.py — arma los sitios que se despliegan en Netlify a partir de las fuentes versionadas (TAREA 037 D, OF-006).

    python herramientas/producto/armar_sitio.py --of OF-006

  landing: ofertas/<OF>/landing/ → ofertas/<OF>/canales/hotmart/sitio/   (marcadores {{…}} reemplazados)
  portal:  ofertas/<OF>/portal/dist/ → ofertas/<OF>/canales/portal/sitio/
Cada sitio/estado.json dice si es publicable y qué falta (marcadores o [PENDIENTE …] sin resolver): netlify_deploy.py
«publicar» se niega con publicable=false; el borrador se puede desplegar igual para revisión (los enlaces de compra sin
checkout apuntan a #checkout-pendiente). Los valores salen de externo.local.json, cuentas.local.json y dueno.local.json
(fuera de git); las carpetas canales/ también están fuera de git. Solo biblioteca estándar.
"""
import argparse
import json
import os
import re
import shutil
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, ".."))
import rutas  # noqa: E402
import guardia_landing  # noqa: E402  (D119: ninguna landing lleva bloque de testimonios)

NO_PUBLICAR = {"capturas", "variables.json"}


def valores(of):
    ext = rutas.externo(of)
    cuentas = rutas.cargar_dato("cuentas")
    dueno = rutas.cargar_dato("dueno")
    legal = dueno.get("legal_es") or {}
    hot = ext.get("hotmart") or {}
    def chk(pieza):
        return ((hot.get(pieza) or {}).get("checkout_url")) or None
    cuenta = ((cuentas.get("meta") or {}).get("cuentas") or [{}])[0]
    pixel_id = cuenta.get("pixel")
    try:   # Matías 2026-10-25/27: píxel propio por producto y mercado; si falta y hay token, se crea solo
        import pixel as PX
        import pixel_nuevo
        fic = rutas.ficha(of)
        mercado, ref = (fic.get("mercado") or {}).get("id"), (fic.get("campana") or {}).get("cuenta_ref")
        pixel_nuevo.antes_de_armar(of, mercado, ref)
        pixel_id = PX.del_producto(of, mercado, ref)
    except Exception:
        pass   # sin ficha o sin píxel: queda el de la cuenta y la compuerta del sitio avisa
    return {"CHECKOUT_URL": chk("principal"), "CHECKOUT_UPSELL": chk("upsell"), "CHECKOUT_DOWNSELL1": chk("downsell1"),
            "CHECKOUT_DOWNSELL2": chk("downsell2"), "PIXEL_ID": pixel_id,
            "LEGAL_TITULAR": legal.get("titular"), "LEGAL_NIF": legal.get("nif"), "LEGAL_DOMICILIO": legal.get("domicilio"),
            "LEGAL_CORREO": legal.get("correo_contacto") or (cuentas.get("hotmart") or {}).get("correo_soporte")}


def armar_landing(of):
    base = rutas.dir_oferta(of)
    src, dst = base / "landing", base / "canales" / "hotmart" / "sitio"
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True)
    v = valores(of)
    faltan = set()
    quitados = []
    for raiz, dirs, archivos in os.walk(src):
        dirs[:] = [d for d in dirs if d not in NO_PUBLICAR and d != guardia_landing.CARPETA]
        for n in archivos:
            if n in NO_PUBLICAR:
                continue
            o = os.path.join(raiz, n)
            d = os.path.join(dst, os.path.relpath(o, src))
            os.makedirs(os.path.dirname(d), exist_ok=True)
            if n.endswith((".html", ".js", ".css")):
                t = open(o, encoding="utf-8").read()
                def rep(m):
                    k = m.group(1)
                    if v.get(k):
                        return v[k]
                    faltan.add(k)
                    return "#checkout-pendiente" if k.startswith("CHECKOUT") else "[PENDIENTE: %s]" % k
                t = re.sub(r"\{\{([A-Z0-9_]+)\}\}", rep, t)
                if n.endswith(".html"):   # D119: nunca un bloque de testimonios (la fuente de OF-006 lo conserva, D118)
                    t, k = guardia_landing.quitar_bloque(t)
                    if k:
                        quitados.append("%s: %d" % (n, k))
                for p in re.findall(r"\[PENDIENTE[^\]]*\]", t):
                    faltan.add("%s: %s" % (n, p))
                open(d, "w", encoding="utf-8", newline="\n").write(t)
            else:
                shutil.copy2(o, d)
    estado = {"publicable": not faltan, "prueba": False, "faltan": sorted(faltan),
              "nota": "borrador para el PARAR «publicar OF-006»; publicar exige publicable=true y el OK escrito"}
    if quitados:
        estado["testimonios_quitados"] = quitados   # D119: se informa qué se sacó
    rutas.escribir_json(dst / "estado.json", estado)
    return estado


def armar_portal(of):
    base = rutas.dir_oferta(of)
    src, dst = base / "portal" / "dist", base / "canales" / "portal" / "sitio"
    if not src.exists():
        raise SystemExit("falta portal/dist: correr armar_portal.py primero")
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    estado = {"publicable": True, "prueba": False, "faltan": [], "nota": "portal del comprador + /medios/ para Meta"}
    rutas.escribir_json(dst / "estado.json", estado)
    return estado


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--of", required=True)
    a = ap.parse_args()
    of = rutas.validar_of(a.of)
    print(json.dumps({"landing": armar_landing(of), "portal": armar_portal(of)}, ensure_ascii=False, indent=1))
