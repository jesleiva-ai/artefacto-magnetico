// checkout_captura.mjs — captura anónima del checkout de Hotmart «como un comprador de España» (TAREA 037 D, OF-006).
//
//   node herramientas/producto/checkout_captura.mjs "<url de checkout>" <carpeta_salida>
//
// Chromium de Playwright SIN sesión (nunca el perfil del dueño), locale es-ES, zona Europe/Madrid, ventana móvil y de
// escritorio. No escribe nada en el formulario ni pulsa «Comprar»: solo abre, espera, guarda captura y los textos visibles
// (medios de pago, precio, impuestos) en checkout.json. Solo lectura.
import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const [url, salida] = process.argv.slice(2);
if (!url || !salida) { console.error('Uso: node checkout_captura.mjs <url> <carpeta>'); process.exit(2); }
mkdirSync(salida, { recursive: true });
let b; for (const o of [{}, { channel: 'chrome' }, { channel: 'msedge' }]) { try { b = await chromium.launch(o); break; } catch { /* siguiente */ } }
const out = { url, fecha: new Date().toISOString(), vistas: [] };
try {
  for (const [nombre, vp] of [['movil', { width: 390, height: 844 }], ['escritorio', { width: 1366, height: 900 }]]) {
    const ctx = await b.newContext({ locale: 'es-ES', timezoneId: 'Europe/Madrid', viewport: vp, extraHTTPHeaders: { 'Accept-Language': 'es-ES,es;q=0.9' } });
    const p = await ctx.newPage();
    const r = await p.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch((e) => ({ status: () => 'error: ' + e.message }));
    await p.waitForTimeout(9000);
    const texto = await p.innerText('body').catch(() => '');
    const lineas = [...new Set(texto.split('\n').map((t) => t.trim()).filter((t) => t && t.length < 90))];
    await p.screenshot({ path: join(salida, `checkout_${nombre}.png`), fullPage: true });
    out.vistas.push({ nombre, http: typeof r?.status === 'function' ? r.status() : null, url_final: p.url(),
      pago: lineas.filter((t) => /tarjeta|card|paypal|google pay|apple pay|bizum|sepa|ideal|klarna|transferencia|multibanco/i.test(t)).slice(0, 20),
      precio: lineas.filter((t) => /€|eur|iva|impuest|tax/i.test(t)).slice(0, 20), muestra: lineas.slice(0, 60) });
    await ctx.close();
  }
} finally { await b.close(); }
writeFileSync(join(salida, 'checkout.json'), JSON.stringify(out, null, 1) + '\n');
console.log(JSON.stringify(out.vistas.map((v) => ({ nombre: v.nombre, http: v.http, url_final: v.url_final, pago: v.pago, precio: v.precio }))));
