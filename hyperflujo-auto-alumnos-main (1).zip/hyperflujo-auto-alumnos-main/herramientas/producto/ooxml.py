#!/usr/bin/env python3
"""ooxml.py — plantillas editables .docx / .xlsx / .pptx con la biblioteca estándar (TAREA 037 D, OF-006 «Paso a Clic»).

Sin python-docx/openpyxl/python-pptx (no instalados y sin permiso para descargar): se escribe el Office Open XML mínimo
que abren Microsoft Word/Excel/PowerPoint y LibreOffice. `verificar(ruta)` comprueba que cada parte sea XML válido, que
todas tengan tipo en [Content_Types].xml y que toda relación apunte a una parte existente.

    from ooxml import Docx, Xlsx, Pptx
    d = Docx("Carta formal"); d.titulo("Carta formal"); d.p("Texto", b=True); d.vinetas(["a", "b"]); d.tabla([[...]]); d.guardar("x.docx")
    x = Xlsx(); h = x.hoja("Presupuesto"); h.celda("A1", "Concepto", "enc"); h.celda("B2", 45.2, "eur"); h.formula("B5", "SUM(B2:B4)", "eur_neg")
    p = Pptx(); s = p.diapositiva(); s.texto(1, 1, 10, 1.2, "Título", tam=36, b=True); p.guardar("x.pptx")

Fórmulas de Excel: se guardan en la sintaxis interna (inglés y coma: SUM, IF, VLOOKUP, COUNTIF); Excel y LibreOffice en
español las muestran traducidas (SUMA, SI, BUSCARV, CONTAR.SI; punto y coma). El libro pide recálculo al abrir.
Solo biblioteca estándar.
"""
import re
import zipfile
from datetime import datetime, timezone
from xml.dom import minidom
from xml.sax.saxutils import escape

AUTOR = "Paso a Clic"
_NS_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
_R_DOC = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _x(s):
    return escape(str(s), {'"': "&quot;"})


def _core(titulo):
    ahora = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            '<dc:title>%s</dc:title><dc:creator>%s</dc:creator><cp:lastModifiedBy>%s</cp:lastModifiedBy>'
            '<dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created>'
            '<dcterms:modified xsi:type="dcterms:W3CDTF">%s</dcterms:modified></cp:coreProperties>'
            % (_x(titulo), AUTOR, AUTOR, ahora, ahora))


def _app(app):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
            'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>%s</Application></Properties>' % app)


def _rels(items):
    """items: [(Id, Type corto o URL, Target)]."""
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="%s">' % _NS_REL]
    for rid, tipo, destino in items:
        if not tipo.startswith("http"):
            tipo = _R_DOC + "/" + tipo
        out.append('<Relationship Id="%s" Type="%s" Target="%s"/>' % (rid, tipo, destino))
    out.append("</Relationships>")
    return "".join(out)


_RAIZ_RELS = lambda principal: _rels([  # noqa: E731
    ("rId1", "officeDocument", principal),
    ("rId2", "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml"),
    ("rId3", "extended-properties", "docProps/app.xml")])


def _tipos(overrides):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
           '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
           '<Default Extension="xml" ContentType="application/xml"/>'
           '<Default Extension="png" ContentType="image/png"/>'
           '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
           '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>']
    for parte, tipo in overrides:
        out.append('<Override PartName="%s" ContentType="%s"/>' % (parte, tipo))
    out.append("</Types>")
    return "".join(out)


def _zip(ruta, partes):
    with zipfile.ZipFile(ruta, "w", zipfile.ZIP_DEFLATED) as z:
        # [Content_Types].xml primero (algunos lectores lo esperan así)
        z.writestr("[Content_Types].xml", partes.pop("[Content_Types].xml"))
        for nombre, contenido in partes.items():
            z.writestr(nombre, contenido if isinstance(contenido, bytes) else contenido.encode("utf-8"))
    return ruta


# =============================================================================== DOCX
_W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="%s"' % _R_DOC


class Docx:
    """Documento de procesador de textos: títulos, párrafos con formato, viñetas, numeración, tablas y saltos."""

    def __init__(self, titulo="Documento", fuente="Calibri", tam=11, color_titulos="17132A", horizontal=False):
        self.titulo_doc, self.fuente, self.tam, self.color = titulo, fuente, tam, color_titulos
        self.horizontal = horizontal
        self.cuerpo = []
        self.nums = []   # cada lista numerada reinicia en 1 (un w:num propio)

    # --- texto
    @staticmethod
    def _run(texto, b=False, i=False, u=False, tam=None, color=None, resaltado=None, fuente=None):
        rpr = ""
        if fuente:
            rpr += '<w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>' % (fuente, fuente, fuente)
        if b:
            rpr += "<w:b/>"
        if i:
            rpr += "<w:i/>"
        if color:
            rpr += '<w:color w:val="%s"/>' % color
        if tam:
            rpr += '<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (int(tam * 2), int(tam * 2))
        if resaltado:
            rpr += '<w:highlight w:val="%s"/>' % resaltado
        if u:   # orden del esquema CT_RPr: … color, sz, szCs, highlight, u …
            rpr += '<w:u w:val="single"/>'
        partes = str(texto).split("\n")
        out = []
        for k, t in enumerate(partes):
            if k:
                out.append("<w:br/>")
            out.append('<w:t xml:space="preserve">%s</w:t>' % _x(t))
        return "<w:r>%s%s</w:r>" % ("<w:rPr>%s</w:rPr>" % rpr if rpr else "", "".join(out))

    def _parrafo(self, runs_xml, estilo=None, alin=None, antes=None, despues=None, num=None, sangria=None, borde_inf=False, sombreado=None):
        ppr = ""
        if estilo:
            ppr += '<w:pStyle w:val="%s"/>' % estilo
        if num is not None:
            ppr += '<w:numPr><w:ilvl w:val="0"/><w:numId w:val="%d"/></w:numPr>' % num
        if borde_inf:
            ppr += '<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="4" w:color="E15B00"/></w:pBdr>'
        if sombreado:
            ppr += '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % sombreado
        if antes is not None or despues is not None:
            ppr += '<w:spacing%s%s/>' % (' w:before="%d"' % (antes * 20) if antes is not None else "",
                                          ' w:after="%d"' % (despues * 20) if despues is not None else "")
        if sangria:
            ppr += '<w:ind w:left="%d"/>' % int(sangria * 567)
        if alin:
            ppr += '<w:jc w:val="%s"/>' % {"centro": "center", "derecha": "right", "justificado": "both", "izquierda": "left"}.get(alin, alin)
        self.cuerpo.append("<w:p>%s%s</w:p>" % ("<w:pPr>%s</w:pPr>" % ppr if ppr else "", runs_xml))

    def titulo(self, texto):
        self._parrafo(self._run(texto), "Title")

    def h1(self, texto):
        self._parrafo(self._run(texto), "Heading1")

    def h2(self, texto):
        self._parrafo(self._run(texto), "Heading2")

    def p(self, texto="", alin=None, antes=None, despues=None, sangria=None, borde_inf=False, sombreado=None, **fmt):
        self._parrafo(self._run(texto, **fmt) if texto != "" else "", None, alin, antes, despues, sangria=sangria,
                      borde_inf=borde_inf, sombreado=sombreado)

    def p_mixto(self, trozos, alin=None, antes=None, despues=None):
        """trozos: [("texto", {"b": True}), "texto plano", ...]"""
        runs = "".join(self._run(t) if isinstance(t, str) else self._run(t[0], **t[1]) for t in trozos)
        self._parrafo(runs, None, alin, antes, despues)

    def campo(self, etiqueta, valor="[escribe aquí]"):
        """Línea «Etiqueta: [valor]» con el valor resaltado para completar."""
        self._parrafo(self._run(etiqueta + ": ", b=True) + self._run(valor, color="635E78", resaltado="yellow"))

    def vinetas(self, items):
        for t in items:
            self._parrafo(self._run(t) if isinstance(t, str) else "".join(self._run(x) if isinstance(x, str) else self._run(x[0], **x[1]) for x in t),
                          "ListParagraph", num=1)

    def numerada(self, items):
        self.nums.append(len(self.nums) + 2)
        n = self.nums[-1]
        for t in items:
            self._parrafo(self._run(t), "ListParagraph", num=n)

    def tabla(self, filas, encabezado=True, anchos=None, color_enc="17132A"):
        """filas: lista de listas de texto. anchos en cm (opcional)."""
        ncol = max(len(f) for f in filas)
        total = 9638 if not self.horizontal else 14570
        anchos_tw = [int(a * 567) for a in anchos] if anchos else [total // ncol] * ncol
        xml = ['<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="%d" w:type="dxa"/>'
               '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'
               % sum(anchos_tw), "<w:tblGrid>%s</w:tblGrid>" % "".join('<w:gridCol w:w="%d"/>' % a for a in anchos_tw)]
        for k, fila in enumerate(filas):
            enc = encabezado and k == 0
            xml.append("<w:tr>%s" % ('<w:trPr><w:tblHeader/></w:trPr>' if enc else ""))
            for j in range(ncol):
                t = fila[j] if j < len(fila) else ""
                tcpr = '<w:tcW w:w="%d" w:type="dxa"/>' % anchos_tw[j]
                if enc:
                    tcpr += '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % color_enc
                run = self._run(t, b=enc, color="FFFFFF" if enc else None)
                xml.append('<w:tc><w:tcPr>%s</w:tcPr><w:p><w:pPr><w:spacing w:before="40" w:after="40"/></w:pPr>%s</w:p></w:tc>' % (tcpr, run))
            xml.append("</w:tr>")
        xml.append("</w:tbl>")
        self.cuerpo.append("".join(xml))
        self.p("")

    def salto(self):
        self.cuerpo.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')

    # --- partes
    def _documento(self):
        if self.horizontal:
            sect = '<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr>'
        else:
            sect = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr>'
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document %s><w:body>%s%s</w:body></w:document>'
                % (_W, "".join(self.cuerpo), sect))

    def _estilos(self):
        f, c = self.fuente, self.color
        def est(sid, nombre, ppr="", rpr="", basado="Normal", sig="Normal"):
            return ('<w:style w:type="paragraph" w:styleId="%s"><w:name w:val="%s"/><w:basedOn w:val="%s"/><w:next w:val="%s"/>'
                    '<w:qFormat/><w:pPr>%s</w:pPr><w:rPr>%s</w:rPr></w:style>' % (sid, nombre, basado, sig, ppr, rpr))
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles %s>'
                '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"/>'
                '<w:sz w:val="%d"/><w:szCs w:val="%d"/><w:lang w:val="es-ES" w:eastAsia="es-ES" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>'
                '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
                '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
                % (_W, f, f, f, f, self.tam * 2, self.tam * 2)
                + est("Title", "Title", '<w:spacing w:after="240"/>', '<w:b/><w:color w:val="%s"/><w:sz w:val="48"/><w:szCs w:val="48"/>' % c)
                + est("Heading1", "heading 1", '<w:keepNext/><w:spacing w:before="360" w:after="120"/><w:outlineLvl w:val="0"/>',
                      '<w:b/><w:color w:val="%s"/><w:sz w:val="32"/><w:szCs w:val="32"/>' % c)
                + est("Heading2", "heading 2", '<w:keepNext/><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="1"/>',
                      '<w:b/><w:color w:val="E15B00"/><w:sz w:val="26"/><w:szCs w:val="26"/>')
                + est("ListParagraph", "List Paragraph", '<w:spacing w:after="60"/><w:ind w:left="720"/><w:contextualSpacing/>')
                + '<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/><w:semiHidden/></w:style>'
                '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:semiHidden/>'
                '<w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/>'
                '<w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>'
                '<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/>'
                '<w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:tblPr><w:tblBorders>'
                + "".join('<w:%s w:val="single" w:sz="4" w:space="0" w:color="BFBCCC"/>' % b for b in ("top", "left", "bottom", "right", "insideH", "insideV"))
                + '</w:tblBorders></w:tblPr></w:style></w:styles>')

    def _numeracion(self):
        vin = ('<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/>'
               '<w:numFmt w:val="bullet"/><w:lvlText w:val="•"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr>'
               '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/></w:rPr></w:lvl></w:abstractNum>')
        dec = ('<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/>'
               '<w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr></w:lvl></w:abstractNum>')
        nums = '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>'
        for n in self.nums:
            nums += ('<w:num w:numId="%d"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>' % n)
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering %s>%s%s%s</w:numbering>' % (_W, vin, dec, nums)

    def guardar(self, ruta):
        base = "application/vnd.openxmlformats-officedocument.wordprocessingml."
        partes = {
            "[Content_Types].xml": _tipos([("/word/document.xml", base + "document.main+xml"), ("/word/styles.xml", base + "styles+xml"),
                                           ("/word/numbering.xml", base + "numbering+xml")]),
            "_rels/.rels": _RAIZ_RELS("word/document.xml"),
            "word/_rels/document.xml.rels": _rels([("rId1", "styles", "styles.xml"), ("rId2", "numbering", "numbering.xml")]),
            "word/document.xml": self._documento(), "word/styles.xml": self._estilos(), "word/numbering.xml": self._numeracion(),
            "docProps/core.xml": _core(self.titulo_doc), "docProps/app.xml": _app("Paso a Clic (plantilla)"),
        }
        return _zip(ruta, partes)


# =============================================================================== XLSX
def col_num(letras):
    n = 0
    for ch in letras:
        n = n * 26 + (ord(ch.upper()) - 64)
    return n


def col_letras(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _ref(ref):
    m = re.fullmatch(r"([A-Za-z]+)(\d+)", ref)
    if not m:
        raise ValueError("referencia inválida: %s" % ref)
    return m.group(1).upper(), int(m.group(2))


# Estilos de celda disponibles (índice en cellXfs).
ESTILOS_X = ["normal", "enc", "neg", "eur", "eur_neg", "pct", "fecha", "titulo", "entrada", "entrada_eur", "nota", "entero", "eur_total", "hora", "entrada_fecha", "decimal"]


class Hoja:
    def __init__(self, nombre):
        self.nombre = nombre[:31]
        self.celdas = {}      # (fila, col) -> (tipo, valor, estilo)
        self.anchos = {}
        self.combinadas = []
        self.inmovilizar = None
        self.validaciones = []   # (rango, lista)

    def celda(self, ref, valor, estilo="normal"):
        c, f = _ref(ref)
        if isinstance(valor, bool):
            raise ValueError("sin booleanos")
        tipo = "n" if isinstance(valor, (int, float)) else "s"
        self.celdas[(f, col_num(c))] = (tipo, valor, estilo)
        return self

    def formula(self, ref, expr, estilo="normal"):
        c, f = _ref(ref)
        self.celdas[(f, col_num(c))] = ("f", expr.lstrip("="), estilo)
        return self

    def fila(self, ref_inicio, valores, estilo="normal"):
        """Escribe valores hacia la derecha desde ref_inicio. Un valor que empieza con '=' es fórmula."""
        c, f = _ref(ref_inicio)
        n = col_num(c)
        for k, v in enumerate(valores):
            if v is None:
                continue
            ref = "%s%d" % (col_letras(n + k), f)
            est = estilo[k] if isinstance(estilo, (list, tuple)) else estilo
            if isinstance(v, str) and v.startswith("="):
                self.formula(ref, v, est)
            else:
                self.celda(ref, v, est)
        return self

    def ancho(self, col, ancho):
        self.anchos[col_num(col)] = ancho
        return self

    def combinar(self, rango):
        self.combinadas.append(rango)
        return self

    def fijar(self, ref):
        self.inmovilizar = ref
        return self

    def lista(self, rango, opciones):
        """Validación de datos: desplegable con opciones fijas."""
        self.validaciones.append((rango, opciones))
        return self

    def xml(self):
        out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="%s">' % _R_DOC]
        if self.inmovilizar:
            c, f = _ref(self.inmovilizar)
            xs, ys = col_num(c) - 1, f - 1
            pane = '<pane%s%s topLeftCell="%s" activePane="%s" state="frozen"/>' % (
                ' xSplit="%d"' % xs if xs else "", ' ySplit="%d"' % ys if ys else "", self.inmovilizar,
                "bottomRight" if xs and ys else ("bottomLeft" if ys else "topRight"))
            out.append('<sheetViews><sheetView workbookViewId="0">%s</sheetView></sheetViews>' % pane)
        else:
            out.append('<sheetViews><sheetView workbookViewId="0"/></sheetViews>')
        out.append('<sheetFormatPr defaultRowHeight="15"/>')
        if self.anchos:
            out.append("<cols>%s</cols>" % "".join('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (k, k, w)
                                                     for k, w in sorted(self.anchos.items())))
        out.append("<sheetData>")
        filas = {}
        for (f, c), v in self.celdas.items():
            filas.setdefault(f, []).append((c, v))
        for f in sorted(filas):
            out.append('<row r="%d">' % f)
            for c, (tipo, valor, estilo) in sorted(filas[f]):
                ref = "%s%d" % (col_letras(c), f)
                s = ESTILOS_X.index(estilo)
                if tipo == "n":
                    out.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, s, repr(valor) if isinstance(valor, float) else valor))
                elif tipo == "f":
                    out.append('<c r="%s" s="%d"><f>%s</f></c>' % (ref, s, _x(valor)))
                else:
                    out.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, s, _x(valor)))
            out.append("</row>")
        out.append("</sheetData>")
        if self.combinadas:
            out.append('<mergeCells count="%d">%s</mergeCells>' % (len(self.combinadas), "".join('<mergeCell ref="%s"/>' % r for r in self.combinadas)))
        if self.validaciones:
            out.append('<dataValidations count="%d">' % len(self.validaciones))
            for rango, ops in self.validaciones:
                out.append('<dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1" sqref="%s">'
                           '<formula1>"%s"</formula1></dataValidation>' % (rango, _x(",".join(ops))))
            out.append("</dataValidations>")
        out.append('<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>'
                   '<pageSetup paperSize="9" orientation="portrait"/></worksheet>')
        return "".join(out)


class Xlsx:
    def __init__(self, titulo="Libro"):
        self.titulo = titulo
        self.hojas = []

    def hoja(self, nombre):
        h = Hoja(nombre)
        self.hojas.append(h)
        return h

    @staticmethod
    def _estilos():
        numfmts = ('<numFmts count="4"><numFmt numFmtId="164" formatCode="#,##0.00\\ &quot;€&quot;"/>'
                   '<numFmt numFmtId="165" formatCode="dd/mm/yyyy"/><numFmt numFmtId="166" formatCode="hh:mm"/>'
                   '<numFmt numFmtId="167" formatCode="#,##0.00"/></numFmts>')
        fonts = ('<fonts count="5"><font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>'
                 '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font>'
                 '<font><b/><sz val="11"/><color rgb="FF17132A"/><name val="Calibri"/><family val="2"/></font>'
                 '<font><b/><sz val="16"/><color rgb="FF17132A"/><name val="Calibri"/><family val="2"/></font>'
                 '<font><i/><sz val="10"/><color rgb="FF635E78"/><name val="Calibri"/><family val="2"/></font></fonts>')
        fills = ('<fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
                 '<fill><patternFill patternType="solid"><fgColor rgb="FF17132A"/><bgColor indexed="64"/></patternFill></fill>'
                 '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF6D6"/><bgColor indexed="64"/></patternFill></fill>'
                 '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF1E6"/><bgColor indexed="64"/></patternFill></fill></fills>')
        borders = ('<borders count="3"><border><left/><right/><top/><bottom/><diagonal/></border>'
                   '<border><left style="thin"><color rgb="FFD9D6E3"/></left><right style="thin"><color rgb="FFD9D6E3"/></right>'
                   '<top style="thin"><color rgb="FFD9D6E3"/></top><bottom style="thin"><color rgb="FFD9D6E3"/></bottom><diagonal/></border>'
                   '<border><left/><right/><top style="thin"><color rgb="FF17132A"/></top><bottom style="double"><color rgb="FF17132A"/></bottom><diagonal/></border></borders>')
        def xf(num=0, font=0, fill=0, border=1, alin=None):
            a = ' applyNumberFormat="1"' if num else ""
            a += ' applyFont="1"' if font else ""
            a += ' applyFill="1"' if fill else ""
            a += ' applyBorder="1"' if border else ""
            al = ""
            if alin:
                a += ' applyAlignment="1"'
                al = '<alignment %s/>' % alin
            return '<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0"%s>%s</xf>' % (num, font, fill, border, a, al)
        xfs = [xf(), xf(font=1, fill=2, alin='horizontal="center" vertical="center" wrapText="1"'), xf(font=2), xf(num=164),
               xf(num=164, font=2), xf(num=9), xf(num=165), xf(font=3, border=0), xf(fill=3), xf(num=164, fill=3), xf(font=4, border=0, alin='wrapText="1" vertical="top"'),
               xf(num=1), xf(num=164, font=2, fill=4, border=2), xf(num=166), xf(num=165, fill=3), xf(num=167)]
        assert len(xfs) == len(ESTILOS_X)
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">%s%s%s%s'
                '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                '<cellXfs count="%d">%s</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                '<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>'
                % (numfmts, fonts, fills, borders, len(xfs), "".join(xfs)))

    @staticmethod
    def _tema():
        return _TEMA % "Paso a Clic"

    def guardar(self, ruta):
        if not self.hojas:
            raise ValueError("libro sin hojas")
        base = "application/vnd.openxmlformats-officedocument.spreadsheetml."
        ov = [("/xl/workbook.xml", base + "sheet.main+xml"), ("/xl/styles.xml", base + "styles+xml"),
              ("/xl/theme/theme1.xml", "application/vnd.openxmlformats-officedocument.theme+xml")]
        rels = []
        hojas_xml = []
        partes = {}
        for k, h in enumerate(self.hojas, 1):
            ov.append(("/xl/worksheets/sheet%d.xml" % k, base + "worksheet+xml"))
            rels.append(("rId%d" % k, "worksheet", "worksheets/sheet%d.xml" % k))
            hojas_xml.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_x(h.nombre), k, k))
            partes["xl/worksheets/sheet%d.xml" % k] = h.xml()
        n = len(self.hojas)
        rels += [("rId%d" % (n + 1), "styles", "styles.xml"), ("rId%d" % (n + 2), "theme", "theme/theme1.xml")]
        libro = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="%s">'
                 '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="16000" windowHeight="9000"/></bookViews>'
                 '<sheets>%s</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>' % (_R_DOC, "".join(hojas_xml)))
        partes.update({"[Content_Types].xml": _tipos(ov), "_rels/.rels": _RAIZ_RELS("xl/workbook.xml"),
                       "xl/workbook.xml": libro, "xl/_rels/workbook.xml.rels": _rels(rels), "xl/styles.xml": self._estilos(),
                       "xl/theme/theme1.xml": self._tema(),
                       "docProps/core.xml": _core(self.titulo), "docProps/app.xml": _app("Paso a Clic (plantilla)")})
        return _zip(ruta, partes)


# =============================================================================== PPTX
_P = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="%s" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"' % _R_DOC)
EMU = 914400 / 2.54   # EMU por cm
_TEMA = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
         '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="%s"><a:themeElements>'
         '<a:clrScheme name="Paso a Clic"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>'
         '<a:dk2><a:srgbClr val="17132A"/></a:dk2><a:lt2><a:srgbClr val="F3F2F7"/></a:lt2><a:accent1><a:srgbClr val="E15B00"/></a:accent1>'
         '<a:accent2><a:srgbClr val="2A5BD7"/></a:accent2><a:accent3><a:srgbClr val="1F8A4C"/></a:accent3><a:accent4><a:srgbClr val="635E78"/></a:accent4>'
         '<a:accent5><a:srgbClr val="F2A900"/></a:accent5><a:accent6><a:srgbClr val="C62828"/></a:accent6><a:hlink><a:srgbClr val="2A5BD7"/></a:hlink>'
         '<a:folHlink><a:srgbClr val="635E78"/></a:folHlink></a:clrScheme>'
         '<a:fontScheme name="Paso a Clic"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>'
         '<a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>'
         '<a:fmtScheme name="Paso a Clic"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
         '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>'
         '<a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
         '<a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>'
         '<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>'
         '<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
         '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements>'
         '<a:objectDefaults/><a:extraClrSchemeLst/></a:theme>')


class Diapositiva:
    def __init__(self, fondo=None):
        self.formas = []
        self.fondo = fondo
        self._id = 2

    def _sig(self):
        self._id += 1
        return self._id

    def rect(self, x, y, w, h, relleno="E15B00", redondeado=False, linea=None):
        """Rectángulo en cm."""
        geo = "roundRect" if redondeado else "rect"
        ln = '<a:ln w="12700"><a:solidFill><a:srgbClr val="%s"/></a:solidFill></a:ln>' % linea if linea else "<a:ln><a:noFill/></a:ln>"
        fill = '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>' % relleno if relleno else "<a:noFill/>"
        i = self._sig()
        self.formas.append('<p:sp><p:nvSpPr><p:cNvPr id="%d" name="Forma %d"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr>'
                           '<a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="%s"><a:avLst/></a:prstGeom>%s%s</p:spPr>'
                           '<p:txBody><a:bodyPr rtlCol="0" anchor="ctr"/><a:lstStyle/><a:p><a:endParaRPr lang="es-ES"/></a:p></p:txBody></p:sp>'
                           % (i, i, x * EMU, y * EMU, w * EMU, h * EMU, geo, fill, ln))
        return self

    def texto(self, x, y, w, h, contenido, tam=18, b=False, color="17132A", alin="l", vinetas=False, fuente=None, relleno=None, anclaje="t"):
        """Cuadro de texto editable en cm. contenido: str (\\n = párrafo nuevo) o lista de párrafos."""
        parrafos = contenido if isinstance(contenido, list) else str(contenido).split("\n")
        ps = []
        for t in parrafos:
            rpr = '<a:rPr lang="es-ES" sz="%d"%s dirty="0"><a:solidFill><a:srgbClr val="%s"/></a:solidFill>%s</a:rPr>' % (
                int(tam * 100), ' b="1"' if b else "", color, '<a:latin typeface="%s"/>' % fuente if fuente else "")
            ppr = '<a:pPr marL="285750" indent="-285750" algn="%s"><a:buFont typeface="Arial"/><a:buChar char="•"/></a:pPr>' % alin if vinetas \
                else '<a:pPr algn="%s"/>' % alin
            ps.append('<a:p>%s<a:r>%s<a:t>%s</a:t></a:r></a:p>' % (ppr, rpr, _x(t)))
        fill = '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>' % relleno if relleno else "<a:noFill/>"
        i = self._sig()
        self.formas.append('<p:sp><p:nvSpPr><p:cNvPr id="%d" name="Texto %d"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr>'
                           '<a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>%s</p:spPr>'
                           '<p:txBody><a:bodyPr wrap="square" rtlCol="0" anchor="%s"><a:normAutofit/></a:bodyPr><a:lstStyle/>%s</p:txBody></p:sp>'
                           % (i, i, x * EMU, y * EMU, w * EMU, h * EMU, fill, anclaje, "".join(ps)))
        return self

    def xml(self):
        bg = ('<p:bg><p:bgPr><a:solidFill><a:srgbClr val="%s"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>' % self.fondo) if self.fondo else ""
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld %s><p:cSld>%s<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/>'
                '<p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/>'
                '<a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>%s</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
                % (_P, bg, "".join(self.formas)))


def _xfrm_entero(xml):
    """EMU tienen que ser enteros."""
    return re.sub(r'(x|y|cx|cy)="(\d+)\.\d+"', r'\1="\2"', xml)


class Pptx:
    """Presentación 16:9 (33,867 × 19,05 cm) con diapositivas en blanco y cuadros de texto editables."""
    ANCHO, ALTO = 33.867, 19.05

    def __init__(self, titulo="Presentación"):
        self.titulo = titulo
        self.diapos = []

    def diapositiva(self, fondo=None):
        d = Diapositiva(fondo)
        self.diapos.append(d)
        return d

    def guardar(self, ruta):
        if not self.diapos:
            raise ValueError("presentación sin diapositivas")
        base = "application/vnd.openxmlformats-officedocument.presentationml."
        ov = [("/ppt/presentation.xml", base + "presentation.main+xml"), ("/ppt/slideMasters/slideMaster1.xml", base + "slideMaster+xml"),
              ("/ppt/slideLayouts/slideLayout1.xml", base + "slideLayout+xml"), ("/ppt/theme/theme1.xml", "application/vnd.openxmlformats-officedocument.theme+xml"),
              ("/ppt/presProps.xml", base + "presProps+xml"), ("/ppt/viewProps.xml", base + "viewProps+xml"), ("/ppt/tableStyles.xml", base + "tableStyles+xml")]
        partes = {}
        rels = [("rId1", "slideMaster", "slideMasters/slideMaster1.xml")]
        ids = []
        for k, d in enumerate(self.diapos, 1):
            ov.append(("/ppt/slides/slide%d.xml" % k, base + "slide+xml"))
            rels.append(("rId%d" % (k + 1), "slide", "slides/slide%d.xml" % k))
            ids.append('<p:sldId id="%d" r:id="rId%d"/>' % (255 + k, k + 1))
            partes["ppt/slides/slide%d.xml" % k] = _xfrm_entero(d.xml())
            partes["ppt/slides/_rels/slide%d.xml.rels" % k] = _rels([("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml")])
        n = len(self.diapos) + 1
        rels += [("rId%d" % (n + 1), "theme", "theme/theme1.xml"), ("rId%d" % (n + 2), "presProps", "presProps.xml"),
                 ("rId%d" % (n + 3), "viewProps", "viewProps.xml"), ("rId%d" % (n + 4), "tableStyles", "tableStyles.xml")]
        pres = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation %s saveSubsetFonts="1">'
                '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>%s</p:sldIdLst>'
                '<p:sldSz cx="12192000" cy="6858000"/><p:notesSz cx="6858000" cy="9144000"/>'
                '<p:defaultTextStyle><a:defPPr><a:defRPr lang="es-ES"/></a:defPPr></p:defaultTextStyle></p:presentation>' % (_P, "".join(ids)))
        arbol = ('<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/>'
                 '<a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree>')
        lvl = '<a:lvl1pPr><a:defRPr sz="%d"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/></a:defRPr></a:lvl1pPr>'
        maestro = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster %s><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>%s</p:cSld>'
                   '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" '
                   'accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
                   '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
                   '<p:txStyles><p:titleStyle>%s</p:titleStyle><p:bodyStyle>%s</p:bodyStyle><p:otherStyle>%s</p:otherStyle></p:txStyles></p:sldMaster>'
                   % (_P, arbol, lvl % 4400, lvl % 2400, lvl % 1800))
        diseno = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout %s type="blank" preserve="1"><p:cSld name="En blanco">%s</p:cSld>'
                  '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>' % (_P, arbol))
        partes.update({
            "[Content_Types].xml": _tipos(ov), "_rels/.rels": _RAIZ_RELS("ppt/presentation.xml"),
            "ppt/presentation.xml": pres, "ppt/_rels/presentation.xml.rels": _rels(rels),
            "ppt/slideMasters/slideMaster1.xml": maestro,
            "ppt/slideMasters/_rels/slideMaster1.xml.rels": _rels([("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"), ("rId2", "theme", "../theme/theme1.xml")]),
            "ppt/slideLayouts/slideLayout1.xml": diseno,
            "ppt/slideLayouts/_rels/slideLayout1.xml.rels": _rels([("rId1", "slideMaster", "../slideMasters/slideMaster1.xml")]),
            "ppt/theme/theme1.xml": _TEMA % "Paso a Clic",
            "ppt/presProps.xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentationPr %s/>' % _P,
            "ppt/viewProps.xml": ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:viewPr %s><p:normalViewPr><p:restoredLeft sz="15620"/>'
                                  '<p:restoredTop sz="94660"/></p:normalViewPr><p:gridSpacing cx="72008" cy="72008"/></p:viewPr>' % _P),
            "ppt/tableStyles.xml": ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:tblStyleLst '
                                    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>'),
            "docProps/core.xml": _core(self.titulo), "docProps/app.xml": _app("Paso a Clic (plantilla)")})
        return _zip(ruta, partes)


# =============================================================================== verificación
def verificar(ruta):
    """Lista de problemas (vacía = ok): XML válido, tipos declarados y relaciones con destino existente."""
    import posixpath
    problemas = []
    with zipfile.ZipFile(ruta) as z:
        nombres = set(z.namelist())
        if "[Content_Types].xml" not in nombres:
            return ["falta [Content_Types].xml"]
        for n in nombres:
            if n.endswith((".xml", ".rels")):
                try:
                    minidom.parseString(z.read(n))
                except Exception as e:
                    problemas.append("%s: XML inválido (%s)" % (n, e))
        tipos = minidom.parseString(z.read("[Content_Types].xml"))
        overrides = {o.getAttribute("PartName").lstrip("/") for o in tipos.getElementsByTagName("Override")}
        defaults = {d.getAttribute("Extension") for d in tipos.getElementsByTagName("Default")}
        for n in nombres:
            if n == "[Content_Types].xml":
                continue
            if n not in overrides and n.rsplit(".", 1)[-1] not in defaults:
                problemas.append("%s sin tipo de contenido" % n)
        for o in overrides:
            if o not in nombres:
                problemas.append("Override de una parte que no existe: %s" % o)
        for n in nombres:
            if not n.endswith(".rels"):
                continue
            carpeta = posixpath.dirname(posixpath.dirname(n))
            for r in minidom.parseString(z.read(n)).getElementsByTagName("Relationship"):
                if r.getAttribute("TargetMode") == "External":
                    continue
                destino = posixpath.normpath(posixpath.join(carpeta, r.getAttribute("Target")))
                if destino not in nombres:
                    problemas.append("%s → %s no existe" % (n, destino))
    return problemas


if __name__ == "__main__":
    import sys
    malos = 0
    for r in sys.argv[1:]:
        pr = verificar(r)
        malos += bool(pr)
        print(("OK  " if not pr else "MAL ") + r + ("" if not pr else "\n    " + "\n    ".join(pr)))
    sys.exit(1 if malos else 0)
