// pdf_guia.mjs — HTML de una guía → PDF A4 con pie de página numerado (TAREA 037 D, OF-006 «Paso a Clic»).
//
//   node herramientas/producto/pdf_guia.mjs <guia.html> <salida.pdf> [--pie "Paso a Clic · Guía 1"] [--capturas id1,id2] [--dir-capturas <carpeta>]
//
// Falla (exit 1, sin PDF) si: una imagen no carga, algún elemento se sale del ancho de la página, quedan marcas
// [PENDIENTE o «Imagen pendiente» (F33). Escribe <salida>.json con hojas, sha256 y avisos. --capturas: PNG de los
// elementos con esos id (muestras para la landing y los anuncios), a 2x.
import { chromium } from 'playwright';
import { readFileSync, writeFileSync, mkdirSync, existsSync, unlinkSync } from 'node:fs';
import { resolve, dirname, join, basename, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const a = process.argv.slice(2);
if (a.length < 2) { console.error('Uso: node pdf_guia.mjs <guia.html> <salida.pdf> [--pie texto] [--capturas id1,id2] [--dir-capturas carpeta]'); process.exit(2); }
const html = resolve(a[0]); const pdf = resolve(a[1]);
const opt = (k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : null; };
const pie = opt('--pie') || '';
const capturas = (opt('--capturas') || '').split(',').filter(Boolean);
const dirCap = resolve(opt('--dir-capturas') || join(dirname(pdf), 'capturas'));

async function lanzar() {
  for (const o of [{}, { channel: 'chrome' }, { channel: 'msedge' }]) { try { return await chromium.launch(o); } catch (e) { /* siguiente */ } }
  throw new Error('No se pudo abrir ningún navegador');
}
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
const b = await lanzar();
const errores = []; const avisos = []; let info = {};
try {
  const p = await b.newPage({ viewport: { width: 794, height: 1123 }, deviceScaleFactor: 2 });
  await p.goto(pathToFileURL(html).href, { waitUntil: 'networkidle', timeout: 60000 }).catch(async () => { avisos.push('networkidle no llegó (fuentes web): se sigue con load'); });
  await p.emulateMedia({ media: 'print' });
  await p.evaluate(() => document.fonts && document.fonts.ready);
  info = await p.evaluate(() => {
    const ancho = document.documentElement.clientWidth;
    const fuera = [];
    for (const el of document.querySelectorAll('body *')) {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.right > ancho + 2 && !el.closest('.portada')) fuera.push((el.className || el.tagName) + ' → ' + Math.round(r.right) + 'px');
      if (fuera.length > 10) break;
    }
    const texto = document.body.innerText;
    return {
      titulo: document.title,
      fuera,
      imgRotas: [...document.images].filter(i => !i.complete || i.naturalWidth === 0).map(i => i.getAttribute('src')),
      pendientes: (texto.match(/\[PENDIENTE[^\]]*\]|Imagen pendiente/gi) || []).slice(0, 10),
      palabras: texto.split(/\s+/).filter(Boolean).length,
      figuras: document.querySelectorAll('figure.ilus').length,
      ejercicios: document.querySelectorAll('.ejercicio').length,
      soluciones: document.querySelectorAll('.solucion').length,
    };
  });
  for (const r of info.imgRotas) errores.push('Imagen que no carga: ' + r);
  for (const f of info.fuera) errores.push('Se sale del ancho: ' + f);
  for (const t of info.pendientes) errores.push('Marca pendiente en el texto: ' + t);
  if (!errores.length) {
    mkdirSync(dirname(pdf), { recursive: true });
    await p.pdf({
      path: pdf, format: 'A4', printBackground: true, preferCSSPageSize: true,
      displayHeaderFooter: true, headerTemplate: '<span></span>',
      footerTemplate: `<div style="width:100%;font-size:7.5pt;color:#635e78;font-family:Arial,sans-serif;padding:0 16mm;display:flex;justify-content:space-between"><span>${esc(pie)}</span><span class="pageNumber"></span></div>`,
    });
    const crudo = readFileSync(pdf);
    info.hojas = (crudo.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;
    info.sha256 = createHash('sha256').update(crudo).digest('hex');
    info.bytes = crudo.length;
    if (!info.hojas) { errores.push('El PDF salió sin hojas'); unlinkSync(pdf); }
  }
  if (!errores.length && capturas.length) {
    await p.emulateMedia({ media: 'screen' });
    mkdirSync(dirCap, { recursive: true });
    info.capturas = [];
    for (const id of capturas) {
      const el = await p.$('#' + id);
      if (!el) { avisos.push('sin elemento #' + id); continue; }
      const dest = join(dirCap, id + '.png');
      await el.screenshot({ path: dest });
      info.capturas.push(relative(process.cwd(), dest).split('\\').join('/'));
    }
  }
} finally { await b.close(); }
info.archivo = basename(pdf); info.fecha = new Date().toISOString(); info.errores = errores; info.avisos = avisos;
info.imagenes_pendientes = (info.pendientes || []).length;
writeFileSync(pdf.replace(/\.pdf$/i, '') + '.verificacion.json', JSON.stringify(info, null, 2) + '\n');
if (errores.length) { console.log('NO SE GENERA EL PDF:'); errores.forEach(e => console.log('  - ' + e)); process.exit(1); }
console.log(JSON.stringify({ ok: true, archivo: pdf, hojas: info.hojas, palabras: info.palabras, figuras: info.figuras, ejercicios: info.ejercicios, avisos }));
