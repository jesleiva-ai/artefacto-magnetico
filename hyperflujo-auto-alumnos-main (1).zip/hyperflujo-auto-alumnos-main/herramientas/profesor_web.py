"""profesor_web.py — el boletín del Profesor (subagente `.claude/agents/profesor-web.md`). Sin aprobado, la web no se publica.

Matías, 2026-10-27: «quiero un subagente… súper exigente, serio, como el profesor de historia del año 1950, de 75 años…
exigente con el desarrollo de las web como lo quiero yo». La vara está en `skills/profesor-web/SKILL.md`; las webs modelo,
en `conocimiento/matias/webs_modelo/`. Solo stdlib.

    python herramientas/profesor_web.py sellar --sitio <carpeta sitio> --nota 9.3 --veredicto aprobado \
        --materias '{"primera_pantalla": 9, ...}' --boletin <boletin.md> [--aplazos '["…"]']
    python herramientas/profesor_web.py verificar --sitio <carpeta sitio>

- `sellar` escribe `boletin_profesor.json` al lado de la carpeta del sitio (afuera, para que no se publique) con la
  huella de todo el HTML, CSS y JS del sitio. El aprobado se rechaza si no alcanza la vara: promedio 9 o más, ninguna
  materia por debajo de 8, las 10 materias calificadas y ningún aplazo automático.
- `verificar` dice si hay un aprobado vigente: si alguien tocó la página después del aprobado, la huella cambia y vuelve
  al profesor. `netlify_deploy.py publicar` lo exige (falla cerrado).
"""
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime

MATERIAS = (
    "primera_pantalla",      # barra, marca, etiqueta, título con verbo y números, foto que vende, precio a la vista
    "imagenes",              # hiperrealistas del nicho, mockups del pack y de cada bono, sin texto deformado
    "paleta_y_letra",        # una paleta del mundo del nicho, dos fuentes elegidas, fondo cálido, contraste
    "movimiento",            # aparecer al bajar, botones que laten y brillan, imágenes que flotan, título vivo
    "oferta_y_precio",       # caja de precio temprana, tachado real, reloj a fecha real, barra fija con precio
    "persuasion",            # dolores, beneficios, para quién, comparación, galería, cierre emocional
    "bonos",                 # un mockup por bono, qué es, valor y «incluido», resumen «todo junto»
    "confianza",             # garantía 7 días, pago con Hotmart, FAQ desplegable, aviso de IA y de Meta, sin inventos
    "celular",               # 390 px sin corrimiento lateral, letra legible, botones grandes, barra de una línea
    "tecnica",               # data-usd, checkoutMode=10, píxel del producto, UTMs, Clarity, imágenes livianas
)
NOTA_MINIMA = 9.0
MATERIA_MINIMA = 8.0
NOMBRE = "boletin_profesor.json"
EXTENSIONES = (".html", ".css", ".js")


class ErrorProfesor(Exception):
    pass


def ruta_boletin(sitio):
    return os.path.join(os.path.dirname(os.path.abspath(sitio)), NOMBRE)


def huella(sitio):
    """sha256 de todos los .html, .css y .js del sitio (ruta relativa + contenido), en orden."""
    h = hashlib.sha256()
    rutas = []
    for base, _, nombres in os.walk(sitio):
        for n in nombres:
            if n.lower().endswith(EXTENSIONES):
                rutas.append(os.path.join(base, n))
    if not rutas:
        raise ErrorProfesor("la carpeta %s no tiene HTML: no hay nada que corregir" % sitio)
    for r in sorted(rutas, key=lambda x: os.path.relpath(x, sitio).replace("\\", "/")):
        h.update(os.path.relpath(r, sitio).replace("\\", "/").encode("utf-8"))
        with open(r, "rb") as f:
            h.update(f.read())
    return h.hexdigest()


def faltas_para_aprobar(nota, materias, aplazos):
    """[por qué no alcanza la vara] (vacío = alcanza)."""
    faltas = []
    if nota < NOTA_MINIMA:
        faltas.append("promedio %.1f: el aprobado empieza en %.0f" % (nota, NOTA_MINIMA))
    sin_nota = [m for m in MATERIAS if m not in materias]
    if sin_nota:
        faltas.append("materias sin calificar: %s" % ", ".join(sin_nota))
    bajas = ["%s (%s)" % (m, v) for m, v in materias.items() if m in MATERIAS and float(v) < MATERIA_MINIMA]
    if bajas:
        faltas.append("materias por debajo de %.0f: %s" % (MATERIA_MINIMA, ", ".join(bajas)))
    if aplazos:
        faltas.append("aplazos automáticos: %s" % "; ".join(aplazos))
    return faltas


def sellar(sitio, nota, veredicto, materias, boletin, aplazos=(), ahora=None):
    if veredicto not in ("aprobado", "desaprobado"):
        raise ErrorProfesor("veredicto: aprobado | desaprobado")
    if not os.path.isfile(boletin):
        raise ErrorProfesor("falta el boletín escrito (%s): el profesor siempre deja sus correcciones por escrito" % boletin)
    materias = {k: float(v) for k, v in (materias or {}).items()}
    nota = float(nota)
    if veredicto == "aprobado":
        faltas = faltas_para_aprobar(nota, materias, list(aplazos))
        if faltas:
            raise ErrorProfesor("no se puede sellar aprobado: " + " | ".join(faltas))
    anterior = leer(sitio) or {}
    datos = {
        "veredicto": veredicto,
        "nota": nota,
        "materias": materias,
        "aplazos": list(aplazos),
        "boletin": os.path.abspath(boletin),
        "huella": huella(sitio),
        "vuelta": int(anterior.get("vuelta", 0)) + 1,
        "fecha": (ahora or datetime.now()).isoformat(timespec="seconds"),
    }
    destino = ruta_boletin(sitio)
    tmp = destino + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, destino)
    return datos


def leer(sitio):
    try:
        with open(ruta_boletin(sitio), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def verificar(sitio):
    """→ (bool, motivo). Aprobado vigente = veredicto aprobado, vara cumplida y la misma huella que hoy."""
    b = leer(sitio)
    if not b:
        return False, "el Profesor no corrigió esta página (no hay %s)" % NOMBRE
    if b.get("veredicto") != "aprobado":
        return False, "el Profesor la desaprobó con %s (vuelta %s): corregir y volver a presentarla" % (b.get("nota"), b.get("vuelta"))
    faltas = faltas_para_aprobar(float(b.get("nota", 0)), b.get("materias") or {}, b.get("aplazos") or [])
    if faltas:
        return False, "el boletín no alcanza la vara: " + " | ".join(faltas)
    if b.get("huella") != huella(sitio):
        return False, "la página cambió después del aprobado: vuelve al Profesor"
    return True, "aprobada por el Profesor con %s (vuelta %s)" % (b.get("nota"), b.get("vuelta"))


def exigir(sitio):
    ok, motivo = verificar(sitio)
    if not ok:
        raise ErrorProfesor(motivo)
    return motivo


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sellar")
    s.add_argument("--sitio", required=True)
    s.add_argument("--nota", required=True, type=float)
    s.add_argument("--veredicto", required=True)
    s.add_argument("--materias", required=True, help="JSON {materia: nota}")
    s.add_argument("--boletin", required=True)
    s.add_argument("--aplazos", default="[]", help="JSON [texto]")
    v = sub.add_parser("verificar")
    v.add_argument("--sitio", required=True)
    a = p.parse_args(argv)
    try:
        if a.cmd == "sellar":
            d = sellar(a.sitio, a.nota, a.veredicto, json.loads(a.materias), a.boletin, json.loads(a.aplazos))
            print(json.dumps({"ok": True, "veredicto": d["veredicto"], "nota": d["nota"], "vuelta": d["vuelta"]}, ensure_ascii=False))
            return 0
        ok, motivo = verificar(a.sitio)
        print(json.dumps({"ok": ok, "motivo": motivo}, ensure_ascii=False))
        return 0 if ok else 2
    except (ErrorProfesor, ValueError) as e:
        print(json.dumps({"ok": False, "motivo": str(e)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())
