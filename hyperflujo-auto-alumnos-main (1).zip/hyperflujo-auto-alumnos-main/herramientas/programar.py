#!/usr/bin/env python3
"""programar.py — tareas programadas del sistema operativo para la corrida diaria (TAREA 036 parte A).

    python herramientas/programar.py mostrar            # imprime lo que registraría (no toca nada)
    python herramientas/programar.py instalar --confirmar
    python herramientas/programar.py quitar --confirmar
    python herramientas/programar.py estado

Tres tareas, con las horas de datos/config.local.json → horarios (por defecto 00:07, 12:07 y :37 de cada hora):
  principal  director.py --modo principal       pulso  director.py --modo pulso       vigia  vigia.py
Windows: Programador de tareas con XML (solo con sesión iniciada porque el robot de Hotmart necesita escritorio;
WakeToRun y StartWhenAvailable para que una corrida perdida corra al volver; revisión 035 h. 20).
macOS: launchd (~/Library/LaunchAgents). Linux: crontab del usuario.
`instalar` se niega sin --confirmar y si `verificar_entorno.py` no dejó estado/entorno_ok.json (parte C).
Solo biblioteca estándar; nunca ejecuta nada en las pruebas (el ejecutor es inyectable).
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from xml.sax.saxutils import escape

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

PREFIJO = "hyperflujo-auto"
ETIQUETA_MAC = "com.hyperflujo.auto"


def horarios(config=None):
    config = (rutas.cargar_dato("config", defecto={}) or {}) if config is None else config
    h = config.get("horarios") or {}
    return {"principal": h.get("principal", "00:07"), "pulso": h.get("pulso", "12:07"), "vigia_minuto": int(h.get("vigia_minuto", 37)),
            "latido_minuto": int(h.get("latido_minuto", 7))}


def tareas(python=None, raiz=None, config=None):
    """Lista de tareas: nombre, argumentos y cuándo (diaria HH:MM u horaria :MM)."""
    python = python or sys.executable
    raiz = Path(raiz or rutas.RAIZ)
    h = horarios(config)
    herr = raiz / "herramientas"
    return [
        {"nombre": "principal", "args": [python, str(herr / "director.py"), "--modo", "principal"], "diaria": h["principal"]},
        {"nombre": "pulso", "args": [python, str(herr / "director.py"), "--modo", "pulso"], "diaria": h["pulso"]},
        {"nombre": "vigia", "args": [python, str(herr / "vigia.py")], "horaria": h["vigia_minuto"]},
        # F67: chequeo independiente de que el vigía corre (avisa si vigia_ultimo.json tiene más de 90 min)
        {"nombre": "latido", "args": [python, str(herr / "latido.py")], "horaria": h["latido_minuto"]},
    ]


def xml_windows(t, raiz):
    """XML del Programador de tareas (esquema 1.2). InteractiveToken = solo con sesión iniciada."""
    if "diaria" in t:
        hh, mm = t["diaria"].split(":")
        disparador = ("<CalendarTrigger><StartBoundary>2026-01-01T%s:%s:00</StartBoundary><Enabled>true</Enabled>"
                      "<ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger>" % (hh, mm))
    else:
        disparador = ("<CalendarTrigger><StartBoundary>2026-01-01T00:%02d:00</StartBoundary><Enabled>true</Enabled>"
                      "<Repetition><Interval>PT1H</Interval><Duration>P1D</Duration></Repetition>"
                      "<ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger>" % t["horaria"])
    argumentos = " ".join('"%s"' % a if " " in a else a for a in t["args"][1:])
    return ('<?xml version="1.0" encoding="UTF-16"?>\n'
            '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">'
            "<RegistrationInfo><Description>%s %s</Description></RegistrationInfo>"
            "<Triggers>%s</Triggers>"
            "<Principals><Principal id=\"Author\"><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>"
            "<Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><StartWhenAvailable>true</StartWhenAvailable>"
            "<WakeToRun>true</WakeToRun><ExecutionTimeLimit>PT6H</ExecutionTimeLimit><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>"
            "<StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><Enabled>true</Enabled></Settings>"
            "<Actions Context=\"Author\"><Exec><Command>%s</Command><Arguments>%s</Arguments><WorkingDirectory>%s</WorkingDirectory></Exec></Actions>"
            "</Task>\n") % (PREFIJO, t["nombre"], disparador, escape(t["args"][0]), escape(argumentos), escape(str(raiz)))


def plist_mac(t, raiz):
    if "diaria" in t:
        hh, mm = t["diaria"].split(":")
        cuando = "<key>StartCalendarInterval</key><dict><key>Hour</key><integer>%d</integer><key>Minute</key><integer>%d</integer></dict>" % (int(hh), int(mm))
    else:
        cuando = "<key>StartCalendarInterval</key><dict><key>Minute</key><integer>%d</integer></dict>" % t["horaria"]
    args = "".join("<string>%s</string>" % escape(a) for a in t["args"])
    log = escape(str(Path(raiz) / "operacion" / "logs" / ("%s.log" % t["nombre"])))
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
            '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>'
            "<key>Label</key><string>%s.%s</string><key>ProgramArguments</key><array>%s</array>"
            "<key>WorkingDirectory</key><string>%s</string>%s"
            "<key>StandardOutPath</key><string>%s</string><key>StandardErrorPath</key><string>%s</string>"
            "</dict></plist>\n") % (ETIQUETA_MAC, t["nombre"], args, escape(str(raiz)), cuando, log, log)


def linea_cron(t, raiz):
    if "diaria" in t:
        hh, mm = t["diaria"].split(":")
        cuando = "%d %d * * *" % (int(mm), int(hh))
    else:
        cuando = "%d * * * *" % t["horaria"]
    comando = " ".join("'%s'" % a for a in t["args"])
    return "%s cd '%s' && %s >> operacion/logs/%s.log 2>&1  # %s:%s" % (cuando, raiz, comando, t["nombre"], PREFIJO, t["nombre"])


def plan(sistema=None, python=None, raiz=None, config=None, solo=None):
    """Qué se registraría: lista de {nombre, archivo?, contenido?, comando}. No toca nada.
    solo: nombres de tareas a incluir (TAREA 040: `--solo vigia`); None = las tres."""
    sistema = sistema or sys.platform
    raiz = Path(raiz or rutas.RAIZ)
    salida = []
    for t in tareas(python, raiz, config):
        if solo and t["nombre"] not in solo:
            continue
        if sistema.startswith("win"):
            archivo = raiz / "operacion" / "tareas" / ("%s.xml" % t["nombre"])
            salida.append({"nombre": t["nombre"], "archivo": archivo, "contenido": xml_windows(t, raiz),
                           "comando": ["schtasks", "/Create", "/TN", "%s\\%s" % (PREFIJO, t["nombre"]), "/XML", str(archivo), "/F"],
                           "quitar": ["schtasks", "/Delete", "/TN", "%s\\%s" % (PREFIJO, t["nombre"]), "/F"],
                           "estado": ["schtasks", "/Query", "/TN", "%s\\%s" % (PREFIJO, t["nombre"])]})
        elif sistema == "darwin":
            archivo = Path.home() / "Library" / "LaunchAgents" / ("%s.%s.plist" % (ETIQUETA_MAC, t["nombre"]))
            salida.append({"nombre": t["nombre"], "archivo": archivo, "contenido": plist_mac(t, raiz),
                           "comando": ["launchctl", "load", "-w", str(archivo)],
                           "quitar": ["launchctl", "unload", "-w", str(archivo)],
                           "estado": ["launchctl", "list", "%s.%s" % (ETIQUETA_MAC, t["nombre"])]})
        else:
            salida.append({"nombre": t["nombre"], "linea_cron": linea_cron(t, raiz)})
    return salida


def _crontab_nuevo(actual, lineas, quitar=False):
    conservadas = [l for l in actual.splitlines() if "# %s:" % PREFIJO not in l]
    return "\n".join(conservadas + ([] if quitar else lineas)) + "\n"


def instalar(sistema=None, ejecutar=subprocess.run, confirmar=False, raiz=None, config=None, python=None, solo=None):
    raiz = Path(raiz or rutas.RAIZ)
    if not confirmar:
        return {"ok": False, "codigo": 2, "motivo": "instalar exige --confirmar (registra tareas reales en el sistema)"}
    if not (raiz / "estado" / "entorno_ok.json").exists():
        return {"ok": False, "codigo": 2, "motivo": "falta estado/entorno_ok.json: correr python herramientas/verificar_entorno.py hasta verde"}
    sistema = sistema or sys.platform
    pasos = plan(sistema, python, raiz, config, solo=solo)
    if sistema.startswith("win") or sistema == "darwin":
        for p in pasos:
            p["archivo"].parent.mkdir(parents=True, exist_ok=True)
            p["archivo"].write_text(p["contenido"], encoding="utf-16" if sistema.startswith("win") else "utf-8")
            r = ejecutar(p["comando"], capture_output=True, text=True)
            if r.returncode != 0:
                return {"ok": False, "codigo": 1, "motivo": "falló registrar %s: %s" % (p["nombre"], (r.stderr or r.stdout or "").strip()[:200])}
    else:
        actual = ejecutar(["crontab", "-l"], capture_output=True, text=True)
        nuevo = _crontab_nuevo(actual.stdout if actual.returncode == 0 else "", [p["linea_cron"] for p in pasos])
        r = ejecutar(["crontab", "-"], input=nuevo, capture_output=True, text=True)
        if r.returncode != 0:
            return {"ok": False, "codigo": 1, "motivo": "falló crontab: %s" % (r.stderr or "").strip()[:200]}
    return {"ok": True, "codigo": 0, "motivo": "%d tareas registradas" % len(pasos)}


def quitar(sistema=None, ejecutar=subprocess.run, confirmar=False, raiz=None, config=None):
    if not confirmar:
        return {"ok": False, "codigo": 2, "motivo": "quitar exige --confirmar"}
    sistema = sistema or sys.platform
    pasos = plan(sistema, None, raiz, config)
    if sistema.startswith("win") or sistema == "darwin":
        for p in pasos:
            ejecutar(p["quitar"], capture_output=True, text=True)
    else:
        actual = ejecutar(["crontab", "-l"], capture_output=True, text=True)
        ejecutar(["crontab", "-"], input=_crontab_nuevo(actual.stdout if actual.returncode == 0 else "", [], quitar=True),
                 capture_output=True, text=True)
    return {"ok": True, "codigo": 0, "motivo": "tareas quitadas"}


def estado(sistema=None, ejecutar=subprocess.run, raiz=None, config=None):
    sistema = sistema or sys.platform
    pasos = plan(sistema, None, raiz, config)
    if sistema.startswith("win") or sistema == "darwin":
        res = {p["nombre"]: ("registrada" if ejecutar(p["estado"], capture_output=True, text=True).returncode == 0 else "no registrada")
               for p in pasos}
    else:
        actual = ejecutar(["crontab", "-l"], capture_output=True, text=True).stdout or ""
        res = {p["nombre"]: ("registrada" if "# %s:%s" % (PREFIJO, p["nombre"]) in actual else "no registrada") for p in pasos}
    return {"ok": all(v == "registrada" for v in res.values()), "codigo": 0, "motivo": json.dumps(res, ensure_ascii=False)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Tareas programadas de hyperflujo-auto (Windows/macOS/Linux).")
    ap.add_argument("orden", choices=("mostrar", "instalar", "quitar", "estado"))
    ap.add_argument("--confirmar", action="store_true")
    ap.add_argument("--solo", action="append", choices=("principal", "pulso", "vigia", "latido"),
                    help="registrar solo esta tarea (repetible), p. ej. --solo vigia")
    a = ap.parse_args()
    if a.orden == "mostrar":
        for p in plan(solo=a.solo):
            print("## %s" % p["nombre"])
            print(" ".join(p.get("comando") or []) or p.get("linea_cron"))
        r = {"ok": True, "codigo": 0, "motivo": "solo se mostró; nada registrado"}
    elif a.orden == "instalar":
        r = instalar(confirmar=a.confirmar, solo=a.solo)
    elif a.orden == "quitar":
        r = quitar(confirmar=a.confirmar)
    else:
        r = estado()
    print(json.dumps(dict(r, artefactos=[]), ensure_ascii=False))
    sys.exit(r["codigo"])
