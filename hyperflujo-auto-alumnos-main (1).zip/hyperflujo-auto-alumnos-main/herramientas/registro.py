#!/usr/bin/env python3
# Copiado del taller hyperflujo/herramientas/ y generalizado para hyperflujo-auto (TAREA 035, módulo núcleo).
"""Registro mínimo por ejecución: ofertas/<id>/ejecuciones/<ej>/registro.json.

Implementa el esquema de "Registro mínimo para la primera landing" del documento
base. Reglas que hace cumplir:

  * Un solo escritor por registro. Cada cambio se guarda con escritura atómica
    (temporal en la misma carpeta + os.replace).
  * Antes de una solicitud paga debe existir un tope autorizado (> 0, con unidad y
    autorizacion_ref) y lo reservado + el estimado de la solicitud no debe superarlo.
  * Toda solicitud tiene clave de operación; no se duplica una operación vigente.
    Regenerar exige version_salida nueva y deja deriva_de.
  * Justo antes de emitir la creación se persiste el estado "enviando"; si esa
    escritura falla, la función lanza excepción y NO se debe enviar.
  * El ID externo se guarda apenas se recibe, antes de consultar o descargar.
  * Al abrir el registro, toda solicitud API en "enviando"/"enviada" sin ID externo
    pasa a "envio_incierto" y bloquea nuevas creaciones hasta conciliar.
  * Consumo real desconocido = None con estado "pendiente_conciliacion"; nunca 0.

Uso como módulo:
    import registro as R
    R.crear_ejecucion(ruta, "OF-001", "EJ-001", "landing", operador="<operador>", ...)
    R.registrar_consumo(ruta, "kie", tope_autorizado=4, unidad="USD", autorizacion_ref="TAREA_00X")
    sid = R.agregar_solicitud(ruta, "api", "kie", clave="hero", estimado=0.5, modelo="...")
    R.marcar_enviando(ruta, sid)      # si lanza, no enviar
    ... enviar ...
    R.guardar_id_externo(ruta, sid, task_id)

Uso por consola:
    python herramientas/registro.py abrir <registro.json>   # reconcilia y muestra resumen
Solo biblioteca estándar.
"""
import datetime
import json
import math
import os
import re
import sys
import tempfile

SCHEMA_VERSION = "1"

# Estado de la ejecución (sección "Registro mínimo").
ESTADOS_EJECUCION = (
    "preparada", "en_trabajo", "en_revision", "aprobada",
    "requiere_correccion", "fallida", "envio_incierto",
)

# Estado de cada solicitud ante el proveedor (separado de la revisión humana).
ESTADOS_SOLICITUD = (
    "planificada", "enviando", "enviada", "en_proceso",
    "completada", "descargada", "fallida", "envio_incierto",
)

ESTADOS_REVISION = ("pendiente", "aceptar", "corregir")
FUNCIONES_ARCHIVO = ("fuente", "medio", "exportacion")
VIAS = ("manual", "api")

# Estados de solicitud que todavía pueden producir o ya produjeron un resultado.
ESTADOS_VIGENTES = ("planificada", "enviando", "enviada", "en_proceso", "completada", "descargada")

# Transiciones permitidas de solicitud.
TRANSICIONES = {
    "planificada": ("enviando", "fallida"),
    "enviando": ("enviada", "fallida", "envio_incierto"),
    "enviada": ("en_proceso", "completada", "fallida", "envio_incierto"),
    "en_proceso": ("completada", "fallida"),
    "completada": ("descargada", "fallida"),
    "descargada": (),
    "fallida": (),
    # Solo sale por conciliación explícita con el proveedor (requiere nota).
    "envio_incierto": ("enviada", "en_proceso", "completada", "fallida"),
}


class ErrorRegistro(Exception):
    """Registro inválido o operación no permitida."""


class TopeInsuficiente(ErrorRegistro):
    """Tope ausente, inválido o insuficiente: no se registra ni se envía la solicitud."""


class PresupuestoInsuficiente(TopeInsuficiente):
    """La solicitud no entra en el presupuesto de la oferta (presupuesto.py, TAREA 015)."""


class BloqueoEnvioIncierto(ErrorRegistro):
    """Hay una solicitud en envío incierto: conciliar antes de crear otra."""


def ahora():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


# ---------------------------------------------------------------- persistencia

def _no_finitos(valor, ruta="$"):
    """Rutas de todos los floats NaN/±inf dentro de valor."""
    if isinstance(valor, float) and not math.isfinite(valor):
        return [ruta]
    if isinstance(valor, dict):
        return [r for k, v in valor.items() for r in _no_finitos(v, "%s.%s" % (ruta, k))]
    if isinstance(valor, list):
        return [r for i, v in enumerate(valor) for r in _no_finitos(v, "%s[%d]" % (ruta, i))]
    return []


def _rechazar_constante(nombre):
    raise ValueError("valor no finito %s" % nombre)


def _guardar(ruta, reg):
    """Escritura atómica: temporal en la misma carpeta y reemplazo.

    Rechaza NaN/±inf en cualquier campo antes de tocar el disco.
    """
    malos = _no_finitos(reg)
    if malos:
        raise ErrorRegistro("Valores no finitos en %s: no se escribe el registro." % ", ".join(malos))
    reg["actualizada_en"] = ahora()
    carpeta = os.path.dirname(os.path.abspath(ruta))
    fd, tmp = tempfile.mkstemp(prefix=".registro-", suffix=".tmp", dir=carpeta)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(reg, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, ruta)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _leer(ruta):
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            reg = json.load(f, parse_constant=_rechazar_constante)
    except ValueError as e:
        raise ErrorRegistro("registro.json inválido (%s): detener y recuperar el estado antes de seguir." % e)
    if not isinstance(reg, dict) or reg.get("schema_version") != SCHEMA_VERSION:
        raise ErrorRegistro("registro.json con esquema desconocido: detener y revisar.")
    return reg


_ERROR_REAPERTURA = "Envío sin ID externo registrado al reabrir"


def _reconciliar(reg):
    """Solicitudes API enviando/enviada sin ID externo -> envio_incierto. Devuelve si cambió algo."""
    cambio = False
    for s in reg["solicitudes"]:
        if s["via"] == "api" and s["estado"] in ("enviando", "enviada") and not s.get("id_externo"):
            s["estado"] = "envio_incierto"
            s["actualizada_en"] = ahora()
            s["ultimo_error"] = _ERROR_REAPERTURA + ": conciliar con el proveedor."
            cambio = True
    if any(s["estado"] == "envio_incierto" for s in reg["solicitudes"]):
        if reg["estado"] != "envio_incierto":
            reg["estado"] = "envio_incierto"
            reg["ultimo_error"] = "Hay solicitudes en envío incierto."
            cambio = True
    return cambio


def leer(ruta):
    """Lee y valida el registro SIN reconciliar ni escribir (lecturas del servicio y del MCP; TAREA 016)."""
    return _leer(ruta)


def abrir(ruta):
    """Lee, valida y reconcilia el registro. Persiste si la reconciliación cambió algo."""
    reg = _leer(ruta)
    if _reconciliar(reg):
        _guardar(ruta, reg)
    return reg


def _modificar(ruta, fn):
    reg = abrir(ruta)
    resultado = fn(reg)
    _guardar(ruta, reg)
    return resultado


def _bloquear_si_incierto(reg):
    inciertas = [s["solicitud_id"] for s in reg["solicitudes"] if s["estado"] == "envio_incierto"]
    if inciertas:
        raise BloqueoEnvioIncierto(
            "Solicitudes en envío incierto: %s. Conciliar con el proveedor antes de crear otra." % ", ".join(inciertas))


def _solicitud(reg, solicitud_id):
    for s in reg["solicitudes"]:
        if s["solicitud_id"] == solicitud_id:
            return s
    raise ErrorRegistro("No existe la solicitud %s." % solicitud_id)


# ---------------------------------------------------------------- API pública

def crear_ejecucion(ruta, oferta_id, ejecucion_id, modulo, operador, version_salida="v001",
                    deriva_de=None, version_oferta=None, receta=None, version_receta=None,
                    ficha=None, brief=None, medios=None):
    """Crea registro.json. Falla si ya existe (cada versión nueva es otra ejecución)."""
    if os.path.exists(ruta):
        raise ErrorRegistro("Ya existe %s: una corrección crea otra ejecución con deriva_de." % ruta)
    os.makedirs(os.path.dirname(os.path.abspath(ruta)), exist_ok=True)
    t = ahora()
    reg = {
        "schema_version": SCHEMA_VERSION,
        "ejecucion_id": ejecucion_id,
        "oferta_id": oferta_id,
        "modulo": modulo,
        "version_salida": version_salida,
        "deriva_de": deriva_de,
        "creada_en": t,
        "actualizada_en": t,
        "operador": operador,
        "entradas": {
            "version_oferta": version_oferta,
            "receta": receta,
            "version_receta": version_receta,
            "ficha": ficha,          # ruta relativa a la copia de la ficha usada
            "brief": brief,          # ruta relativa a la copia del brief usado
            "medios": list(medios or []),
        },
        "estado": "preparada",
        "solicitudes": [],
        "consumo": {},              # proveedor -> {tope_autorizado, autorizacion_ref, unidad, estimado, reservado, real, estado}
        "archivos": [],
        "tiempo_humano_min": 0,
        "tiempo_espera_min": 0,
        "tiempo_agente_min": 0,     # trabajo activo del agente (worker), separado del humano
        "revision": {"estado": "pendiente", "responsable": None, "fecha": None, "nota": None},
        "ultimo_error": None,
    }
    _guardar(ruta, reg)
    return reg


def _es_numero(v):
    """Solo int/float finitos: rechaza bool, NaN, ±inf, strings y None."""
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _num_version(v):
    """'v002' -> 2. Lanza si no tiene número."""
    digitos = re.findall(r"\d+", str(v or ""))
    if not digitos:
        raise ErrorRegistro("version_salida sin número: %r" % (v,))
    return int(digitos[-1])


def _reservado(reg, proveedor, excluir=None):
    """Costo previsto ya comprometido con un proveedor en esta ejecución.

    Cuenta toda solicitud no fallida y también las fallidas con ID externo
    (pudieron cobrarse). Si el consumo real conocido es mayor, usa ese.
    """
    total = 0.0
    for s in reg["solicitudes"]:
        if s["proveedor"] != proveedor or s["solicitud_id"] == excluir:
            continue
        if s["estado"] == "fallida" and not s.get("id_externo"):
            continue
        if _es_numero(s.get("estimado")):
            total += s["estimado"]
    real = (reg["consumo"].get(proveedor) or {}).get("real")
    return max(total, real) if _es_numero(real) else total


def _verificar_presupuesto(ruta, reg, proveedor, estimado, clave=None, excluir=None):
    """Además del tope de la ejecución, la solicitud debe entrar en el presupuesto de la oferta (si el registro
    vive en ofertas/<OF>/ejecuciones/). Sin presupuesto en la ficha, ninguna solicitud paga."""
    import presupuesto as P
    try:
        return P.verificar(ruta, reg, proveedor, estimado, reg["consumo"][proveedor]["unidad"], clave=clave, excluir_sid=excluir)
    except P.PresupuestoInsuficiente as e:
        raise PresupuestoInsuficiente(str(e))


def _verificar_tope(reg, proveedor, estimado, excluir=None):
    """Lanza TopeInsuficiente si el tope no existe, no es válido o no alcanza."""
    c = reg["consumo"].get(proveedor)
    if not c:
        raise TopeInsuficiente("Sin tope autorizado para %s." % proveedor)
    tope = c.get("tope_autorizado")
    if not _es_numero(tope) or tope <= 0:
        raise TopeInsuficiente("Tope de %s inválido (%r): debe ser un número mayor que 0." % (proveedor, tope))
    if not c.get("unidad"):
        raise TopeInsuficiente("Tope de %s sin unidad (USD, créditos...)." % proveedor)
    if not c.get("autorizacion_ref"):
        raise TopeInsuficiente("Tope de %s sin autorizacion_ref." % proveedor)
    if not _es_numero(estimado) or estimado <= 0:
        raise TopeInsuficiente(
            "Costo estimado inválido o desconocido (%r): una solicitud paga necesita estimado > 0 finito. "
            "Con el costo desconocido la solicitud no se registra ni se envía; si es realmente gratuita, "
            "usar gratuita=True con motivo_gratuita." % (estimado,))
    reservado = _reservado(reg, proveedor, excluir)
    if reservado + estimado > tope + 1e-9:
        raise TopeInsuficiente("%s: reservado %s + estimado %s = %s supera el tope %s %s."
                               % (proveedor, reservado, estimado, reservado + estimado, tope, c["unidad"]))
    return reservado


PROMPT_MAX = 4000                         # TAREA 025 (13): más largo → se guarda su sha256 y la ruta del texto
SIN_ADAPTADOR = ("higgsfield_plan",)      # envíos por MCP: sin adaptador que guarde la llamada, parametros y prompt obligatorios


def _prompt_guardado(prompt, prompt_ruta=None):
    import hashlib
    if prompt is None:
        return None
    if len(prompt) <= PROMPT_MAX:
        return {"texto": prompt}
    if not prompt_ruta:
        raise ErrorRegistro("prompt de %d caracteres: pasar prompt_ruta (archivo con el texto literal)." % len(prompt))
    return {"sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(), "ruta": prompt_ruta, "caracteres": len(prompt)}


def agregar_solicitud(ruta, via, proveedor, *, clave, estimado, modelo=None, parametros=None,
                      regeneracion=False, version_salida=None, gratuita=False, motivo_gratuita=None,
                      prompt=None, prompt_ruta=None, deriva_de_externa=None):
    """Registra una solicitud en 'planificada' y devuelve su ID local.

    - clave: identidad de la operación (p. ej. "hero"). Obligatoria.
    - estimado: costo previsto en la unidad del tope, número finito > 0 (D7).
    - gratuita=True: operación sin costo comprobado; exige motivo_gratuita, no
      reserva contra el tope ni lo exige, y estimado debe ser 0 o None.
    Rechaza (sin escribir nada):
    - TopeInsuficiente: tope ausente, <= 0, sin unidad o sin autorización, o si
      lo reservado + estimado supera el tope.
    - ErrorRegistro: misma clave con una solicitud vigente (planificada, enviando,
      enviada, en_proceso, completada, descargada).
    regeneracion=True crea una versión nueva explícita: exige version_salida mayor
    que la última de esa clave y escribe deriva_de con la solicitud anterior.
    deriva_de_externa={"solicitud": "EJ-004/SOL-002", "version_salida": "v001"}: regeneración de una clave cuya versión
    anterior está en OTRA ejecución de la oferta (TAREA 028, revisión Sonnet de la 027): exige regeneracion=True y
    version_salida mayor que la externa. Una clave con sufijo de versión («-b», «_v2»…) sin regeneracion se rechaza:
    la versión va en version_salida, no en el nombre.
    """
    if not regeneracion and isinstance(clave, str) and re.search(r"[-_](v\d+|[b-z])$", clave):
        raise ErrorRegistro("La clave '%s' parece una versión nueva por el nombre: usar la misma clave con "
                            "regeneracion=True y version_salida nueva (regla 6)." % clave)
    if not regeneracion and not gratuita and isinstance(clave, str):
        # TAREA 029 (revisión Sonnet de la 028, 9): la misma clave ya descargada en OTRA ejecución de la oferta es una
        # regeneración: tiene que venir marcada desde el principio (no corregida después).
        dir_ej = os.path.dirname(os.path.dirname(os.path.abspath(ruta)))
        for otra in sorted(os.listdir(dir_ej)) if os.path.basename(dir_ej) == "ejecuciones" else []:
            r_otra = os.path.join(dir_ej, otra, "registro.json")
            if os.path.abspath(r_otra) == os.path.abspath(ruta) or not os.path.isfile(r_otra):
                continue
            with open(r_otra, encoding="utf-8") as f:
                previa = [s for s in json.load(f).get("solicitudes", []) if s.get("clave") == clave and s.get("estado") == "descargada"]
            if previa:
                raise ErrorRegistro("La clave '%s' ya se descargó en %s (%s): pedirla otra vez es una regeneración "
                                    "(regeneracion=True, version_salida nueva, deriva_de_externa)." % (clave, otra, previa[-1]["solicitud_id"]))
    if deriva_de_externa is not None and (not regeneracion or not isinstance(deriva_de_externa, dict)
                                          or not deriva_de_externa.get("solicitud") or not deriva_de_externa.get("version_salida")):
        raise ErrorRegistro("deriva_de_externa exige regeneracion=True y {solicitud, version_salida}.")
    if via not in VIAS:
        raise ErrorRegistro("via debe ser una de %s" % (VIAS,))
    if proveedor in SIN_ADAPTADOR and not gratuita and (not parametros or prompt is None):
        raise ErrorRegistro("%s: toda solicitud paga guarda parametros (modelo, duración, formato) y el prompt literal "
                            "(TAREA 025, 13)." % proveedor)
    prompt_g = _prompt_guardado(prompt, prompt_ruta)
    if not isinstance(clave, str) or not clave.strip():
        raise ErrorRegistro("clave obligatoria: identifica la operación para no duplicarla.")
    if gratuita is not True and gratuita is not False:
        raise ErrorRegistro("gratuita debe ser True o False.")
    if gratuita:
        if not isinstance(motivo_gratuita, str) or not motivo_gratuita.strip():
            raise ErrorRegistro("gratuita=True exige motivo_gratuita (qué se comprobó para saber que no cobra).")
        if estimado not in (None, 0) or isinstance(estimado, bool):
            raise ErrorRegistro("Una solicitud gratuita no lleva estimado (0 o None).")
        estimado = 0
    elif motivo_gratuita is not None:
        raise ErrorRegistro("motivo_gratuita solo va con gratuita=True.")

    def fn(reg):
        _bloquear_si_incierto(reg)
        previas = [s for s in reg["solicitudes"] if s.get("clave") == clave]
        deriva_de = None
        if regeneracion:
            if not previas and not deriva_de_externa:
                raise ErrorRegistro("regeneracion=True sin solicitud previa con clave '%s'." % clave)
            if version_salida is None:
                raise ErrorRegistro("La regeneración exige version_salida nueva.")
            ultima = max([_num_version(p["version_salida"]) for p in previas]
                         + ([_num_version(deriva_de_externa["version_salida"])] if deriva_de_externa else []))
            if _num_version(version_salida) <= ultima:
                raise ErrorRegistro("La regeneración exige version_salida mayor que v%03d (recibido %s)."
                                    % (ultima, version_salida))
            version = version_salida
            deriva_de = previas[-1]["solicitud_id"] if previas else deriva_de_externa["solicitud"]
        else:
            vigentes = [p["solicitud_id"] for p in previas if p["estado"] in ESTADOS_VIGENTES]
            if vigentes:
                raise ErrorRegistro("La operación '%s' ya tiene solicitud vigente o resultado (%s). "
                                    "Para otra versión usar regeneracion=True con version_salida nueva."
                                    % (clave, ", ".join(vigentes)))
            version = previas[-1]["version_salida"] if previas else reg["version_salida"]
            if version_salida is not None and version_salida != version:
                raise ErrorRegistro("Cambiar version_salida exige regeneracion=True.")
        reservado = None if gratuita else _verificar_tope(reg, proveedor, estimado)
        if not gratuita:
            _verificar_presupuesto(ruta, reg, proveedor, estimado, clave=clave)
        mismas = [p for p in previas if p["version_salida"] == version]
        sid = "SOL-%03d" % (len(reg["solicitudes"]) + 1)
        t = ahora()
        reg["solicitudes"].append({
            "solicitud_id": sid,
            "clave": clave,
            "version_salida": version,
            "deriva_de": deriva_de,
            "via": via,
            "proveedor": proveedor,
            "modelo": modelo,
            "parametros": dict(parametros or {}, **({"prompt": prompt_g} if prompt_g else {})),
            "estimado": estimado,
            "gratuita": gratuita,
            "motivo_gratuita": motivo_gratuita,
            "intento": len(mismas) + 1,
            "estado": "planificada",
            "id_externo": None,
            "creada_en": t,
            "enviada_en": None,
            "actualizada_en": t,
            "ultimo_error": None,
            "comprobacion": None,   # vía manual sin ID visible: canal y comprobación realizada
        })
        if not gratuita:
            reg["consumo"][proveedor]["reservado"] = reservado + estimado
        if reg["estado"] == "preparada":
            reg["estado"] = "en_trabajo"
        return sid

    return _modificar(ruta, fn)


def marcar_enviando(ruta, solicitud_id):
    """Persiste 'enviando' justo antes de emitir la creación. Si lanza, NO enviar.

    Vuelve a comprobar el tope (pudo cambiar desde que se planificó).
    """
    def fn(reg):
        _bloquear_si_incierto(reg)
        s = _solicitud(reg, solicitud_id)
        if s["estado"] != "planificada":
            raise ErrorRegistro("%s está '%s'; solo una solicitud planificada puede enviarse." % (solicitud_id, s["estado"]))
        if not s.get("gratuita"):
            _verificar_tope(reg, s["proveedor"], s.get("estimado"), excluir=solicitud_id)
            _verificar_presupuesto(ruta, reg, s["proveedor"], s.get("estimado"), clave=s.get("clave"), excluir=solicitud_id)
        s["estado"] = "enviando"
        s["enviada_en"] = s["actualizada_en"] = ahora()
    _modificar(ruta, fn)


def guardar_id_externo(ruta, solicitud_id, id_externo):
    """Guarda el task_id apenas se recibe (antes de consultar o descargar)."""
    if not id_externo:
        raise ErrorRegistro("id_externo vacío.")

    def fn(reg):
        s = _solicitud(reg, solicitud_id)
        if s.get("id_externo") and s["id_externo"] != id_externo:
            raise ErrorRegistro("%s ya tiene ID externo %s." % (solicitud_id, s["id_externo"]))
        s["id_externo"] = id_externo
        if s["estado"] in ("enviando", "envio_incierto"):
            s["estado"] = "enviada"
        if (s.get("ultimo_error") or "").startswith(_ERROR_REAPERTURA):
            s["ultimo_error"] = None       # el ID prueba el envío: no queda «incierto» residual
        s["actualizada_en"] = ahora()
        _limpiar_incierto(reg)
    _modificar(ruta, fn)


def marcar_rechazada(ruta, solicitud_id, error):
    """El proveedor RESPONDIÓ rechazando la creación (p. ej. HTTP 4xx): 'enviando' -> 'fallida'.

    Se usa en el mismo proceso que envió, con la respuesta en mano. Por eso lee el registro
    sin la reconciliación de reapertura (que convertiría 'enviando' en 'envio_incierto').
    """
    if not error:
        raise ErrorRegistro("marcar_rechazada exige el error recibido del proveedor.")
    reg = _leer(ruta)
    s = _solicitud(reg, solicitud_id)
    if s["estado"] != "enviando" or s.get("id_externo"):
        raise ErrorRegistro("%s no está 'enviando' sin ID externo; no se puede marcar como rechazada." % solicitud_id)
    s["estado"] = "fallida"
    s["ultimo_error"] = reg["ultimo_error"] = error
    s["actualizada_en"] = ahora()
    _limpiar_incierto(reg)
    _guardar(ruta, reg)


def _limpiar_incierto(reg):
    if reg["estado"] == "envio_incierto" and not any(x["estado"] == "envio_incierto" for x in reg["solicitudes"]):
        reg["estado"] = "en_trabajo"
        reg["ultimo_error"] = None


def cambiar_estado(ruta, nuevo, solicitud_id=None, error=None, nota=None):
    """Cambia el estado de una solicitud (si se pasa solicitud_id) o de la ejecución.

    Salir de 'envio_incierto' exige nota de conciliación con el proveedor.
    """
    def fn(reg):
        t = ahora()
        if solicitud_id is None:
            if nuevo not in ESTADOS_EJECUCION:
                raise ErrorRegistro("Estado de ejecución inválido: %s" % nuevo)
            hay_incierta = any(s["estado"] == "envio_incierto" for s in reg["solicitudes"])
            if hay_incierta and nuevo not in ("envio_incierto", "fallida"):
                raise BloqueoEnvioIncierto("Conciliar las solicitudes inciertas antes de cambiar el estado de la ejecución.")
            reg["estado"] = nuevo
            if error:
                reg["ultimo_error"] = error
            return
        if nuevo not in ESTADOS_SOLICITUD:
            raise ErrorRegistro("Estado de solicitud inválido: %s" % nuevo)
        s = _solicitud(reg, solicitud_id)
        if nuevo not in TRANSICIONES[s["estado"]]:
            raise ErrorRegistro("Transición no permitida %s -> %s." % (s["estado"], nuevo))
        if s["estado"] == "envio_incierto" and not nota:
            raise ErrorRegistro("Salir de envío incierto requiere nota de conciliación (qué se verificó en el proveedor).")
        s["estado"] = nuevo
        s["actualizada_en"] = t
        if error:
            s["ultimo_error"] = error
            reg["ultimo_error"] = error
        if nota:
            s["comprobacion"] = nota
        if nuevo == "envio_incierto":
            reg["estado"] = "envio_incierto"
        _limpiar_incierto(reg)
    _modificar(ruta, fn)


def registrar_consumo(ruta, proveedor, tope_autorizado=None, autorizacion_ref=None,
                      estimado=None, real=None, unidad=None, nota=None, quien=None):
    """Actualiza el consumo de un proveedor. Solo pisa los campos que se pasan.

    real=None significa desconocido: queda 'pendiente_conciliacion' (nunca 0 inventado).
    nota/quien: conciliación manual desde el panel del proveedor (TAREA 024, H8); quedan en `conciliaciones`.
    """
    for nombre, v in (("tope_autorizado", tope_autorizado), ("estimado", estimado), ("real", real)):
        if v is not None and not _es_numero(v):
            raise ErrorRegistro("%s debe ser un número finito (recibido %r)." % (nombre, v))

    def fn(reg):
        c = reg["consumo"].setdefault(proveedor, {
            "tope_autorizado": None, "autorizacion_ref": None, "estimado": None,
            "reservado": 0, "real": None, "unidad": None, "estado": "pendiente_conciliacion",
        })
        if tope_autorizado is not None:
            if autorizacion_ref is None and c.get("autorizacion_ref") is None:
                raise ErrorRegistro("Un tope autorizado requiere autorizacion_ref (brief o mensaje que lo autoriza).")
            c["tope_autorizado"] = tope_autorizado
        for k, v in (("autorizacion_ref", autorizacion_ref), ("estimado", estimado), ("unidad", unidad)):
            if v is not None:
                c[k] = v
        if nota:
            c.setdefault("conciliaciones", []).append({"en": ahora(), "quien": quien, "real": real, "nota": nota})
        if real is not None:
            c["real"] = real
            c["estado"] = "conciliado"
            # qué solicitudes cubre este real (presupuesto por oferta: las posteriores cuentan por su estimado)
            c["real_cubre"] = [s["solicitud_id"] for s in reg["solicitudes"]
                               if s.get("proveedor") == proveedor and not s.get("gratuita")]
        elif c.get("real") is None:
            c["estado"] = "pendiente_conciliacion"
        if c.get("tope_autorizado") is not None:
            for val in (c.get("estimado"), c.get("real")):
                if val is not None and val > c["tope_autorizado"]:
                    reg["ultimo_error"] = "Consumo de %s supera el tope autorizado." % proveedor
    _modificar(ruta, fn)


def registrar_revision(ruta, estado, responsable, nota=None, automatica=False):
    """Revisión humana (pendiente / aceptar / corregir). Separada del estado del proveedor.

    automatica=True (recorridos de prueba, TAREA 022): queda solo en el historial, marcada como automática;
    no cambia la revisión vigente ni el estado. Una prueba nunca aprueba en nombre de una persona.
    """
    if estado not in ESTADOS_REVISION:
        raise ErrorRegistro("Revisión inválida: %s" % estado)

    def fn(reg):
        if automatica:
            reg.setdefault("historial_revision", []).append(
                {"estado": estado, "responsable": responsable, "fecha": ahora(), "nota": nota, "automatica": True})
            return
        reg["revision"] = {"estado": estado, "responsable": responsable, "fecha": ahora(), "nota": nota}
        reg.setdefault("historial_revision", []).append(dict(reg["revision"]))   # quién decidió qué y cuándo (TAREA 015)
        if reg["estado"] != "envio_incierto":
            reg["estado"] = {"aceptar": "aprobada", "corregir": "requiere_correccion"}.get(estado, reg["estado"])
    _modificar(ruta, fn)


def agregar_archivo(ruta, ruta_archivo, funcion, version):
    """Registra un resultado: ruta relativa, función (fuente/medio/exportacion) y versión."""
    if funcion not in FUNCIONES_ARCHIVO:
        raise ErrorRegistro("funcion debe ser una de %s" % (FUNCIONES_ARCHIVO,))

    def fn(reg):
        reg["archivos"].append({"ruta": ruta_archivo, "funcion": funcion, "version": version})
    _modificar(ruta, fn)


CAMPOS_ENTRADAS = ("version_oferta", "receta", "version_receta", "ficha", "brief", "medios")


def _anotar_correccion(reg, motivo, detalle):
    if not isinstance(motivo, str) or not motivo.strip():
        raise ErrorRegistro("Una corrección del registro exige motivo (p. ej. la revisión que la pide).")
    reg.setdefault("correcciones", []).append({"fecha": ahora(), "motivo": motivo, "detalle": detalle})


def completar_parametros(ruta, solicitud_id, parametros, motivo, prompt=None, prompt_ruta=None):
    """Completa a posteriori los parametros (y el prompt) de una solicitud que los dejó vacíos, con constancia en
    'correcciones' (TAREA 025, 13). No pisa parametros que ya existan."""
    prompt_g = _prompt_guardado(prompt, prompt_ruta)

    def fn(reg):
        s = _solicitud(reg, solicitud_id)
        if s.get("parametros"):
            raise ErrorRegistro("%s ya tiene parametros: no se pisan." % solicitud_id)
        s["parametros"] = dict(parametros, **({"prompt": prompt_g} if prompt_g else {}))
        _anotar_correccion(reg, motivo, {"solicitud": solicitud_id, "parametros": "completados a posteriori"})
    _modificar(ruta, fn)


def corregir_regeneracion(ruta, solicitud_id, deriva_de, version_salida, motivo, deriva_de_ejecucion=None):
    """Marca a posteriori una solicitud que fue una regeneración (TAREA 028): deriva_de («EJ-004/SOL-002») y
    version_salida nueva, con constancia en 'correcciones'. No toca estado, IDs ni consumo."""
    if not motivo:
        raise ErrorRegistro("corregir_regeneracion exige motivo")

    def fn(reg):
        s = _solicitud(reg, solicitud_id)
        cambios = {"solicitud": solicitud_id, "deriva_de": {"antes": s.get("deriva_de"), "despues": deriva_de},
                   "version_salida": {"antes": s.get("version_salida"), "despues": version_salida}}
        s["deriva_de"], s["version_salida"] = deriva_de, version_salida
        if deriva_de_ejecucion and reg.get("deriva_de") != deriva_de_ejecucion:
            cambios["ejecucion_deriva_de"] = {"antes": reg.get("deriva_de"), "despues": deriva_de_ejecucion}
            reg["deriva_de"] = deriva_de_ejecucion
        _anotar_correccion(reg, motivo, cambios)
    _modificar(ruta, fn)


def corregir_entradas(ruta, motivo, **campos):
    """Corrige metadatos de 'entradas' dejando constancia (valor anterior y nuevo) en 'correcciones'."""
    desconocidos = set(campos) - set(CAMPOS_ENTRADAS)
    if desconocidos:
        raise ErrorRegistro("Campos de entradas desconocidos: %s" % ", ".join(sorted(desconocidos)))

    def fn(reg):
        cambios = {k: {"antes": reg["entradas"].get(k), "despues": v} for k, v in campos.items()}
        reg["entradas"].update(campos)
        _anotar_correccion(reg, motivo, {"entradas": cambios})
    _modificar(ruta, fn)


def reubicar_archivos(ruta, mapeo, motivo):
    """Cambia rutas de archivos[] (antes -> después) dejando constancia. Todas deben existir en el registro."""
    def fn(reg):
        actuales = {a["ruta"] for a in reg["archivos"]}
        faltan = [k for k in mapeo if k not in actuales]
        if faltan:
            raise ErrorRegistro("No están en archivos[]: %s" % ", ".join(faltan))
        for a in reg["archivos"]:
            if a["ruta"] in mapeo:
                a["ruta"] = mapeo[a["ruta"]]
        _anotar_correccion(reg, motivo, {"archivos": mapeo})
    _modificar(ruta, fn)


def registrar_tiempo(ruta, humano_min=0, espera_min=0, agente_min=0):
    """Suma minutos de trabajo humano activo, de espera y del agente, medidos por separado."""
    for nombre, v in (("humano_min", humano_min), ("espera_min", espera_min), ("agente_min", agente_min)):
        if not _es_numero(v) or v < 0:
            raise ErrorRegistro("%s debe ser un número finito >= 0." % nombre)

    def fn(reg):
        reg["tiempo_humano_min"] += humano_min
        reg["tiempo_espera_min"] += espera_min
        reg["tiempo_agente_min"] = reg.get("tiempo_agente_min", 0) + agente_min
    _modificar(ruta, fn)


def pendientes(carpeta_oferta):
    """Lo pendiente de conciliar en una oferta (TAREA 022A). Solo lee: no reconcilia, no escribe, no consulta proveedores.

    Devuelve {"conciliar": [...], "abiertas": [...]}:
      - conciliar: consumo por ejecución y proveedor con real desconocido (null) y algo reservado;
      - abiertas: ejecuciones que quedaron en 'en_trabajo' o 'envio_incierto'.
    """
    import glob
    conciliar, abiertas = [], []
    for ruta in sorted(glob.glob(os.path.join(carpeta_oferta, "ejecuciones", "*", "registro.json"))):
        reg = leer(ruta)
        for prov, c in sorted(reg["consumo"].items()):
            if c.get("real") is None and (c.get("reservado") or 0) > 0:
                conciliar.append({"ejecucion_id": reg["ejecucion_id"], "modulo": reg["modulo"], "proveedor": prov,
                                  "reservado": c.get("reservado"), "unidad": c.get("unidad"), "real": None,
                                  "estado": c.get("estado"), "estado_ejecucion": reg["estado"],
                                  "ids_externos": [s.get("id_externo") for s in reg["solicitudes"]
                                                   if s.get("proveedor") == prov and s.get("id_externo")]})
        if reg["estado"] in ("en_trabajo", "envio_incierto"):
            abiertas.append({"ejecucion_id": reg["ejecucion_id"], "modulo": reg["modulo"], "estado": reg["estado"]})
    return {"oferta": os.path.basename(os.path.normpath(carpeta_oferta)), "conciliar": conciliar, "abiertas": abiertas}


# ---------------------------------------------------------------- consola

def _main(argv):
    if len(argv) == 3 and argv[1] == "pendientes":
        try:
            p = pendientes(argv[2])
        except (ErrorRegistro, OSError) as e:
            print("ERROR: %s" % e)
            return 1
        print("%s · pendiente de conciliar: %d · ejecuciones abiertas: %d" % (p["oferta"], len(p["conciliar"]), len(p["abiertas"])))
        for x in p["conciliar"]:
            print("  %s %s: reservado=%s %s real=null (%s; ejecución %s; %d IDs externos)" % (
                x["ejecucion_id"], x["proveedor"], round(x["reservado"], 4), x["unidad"] or "", x["estado"],
                x["estado_ejecucion"], len(x["ids_externos"])))
        for x in p["abiertas"]:
            print("  abierta %s %s: %s" % (x["ejecucion_id"], x["modulo"], x["estado"]))
        return 1 if p["conciliar"] or p["abiertas"] else 0
    if len(argv) != 3 or argv[1] != "abrir":
        print("Uso: python herramientas/registro.py abrir <registro.json>\n"
              "     python herramientas/registro.py pendientes <ofertas/OF-NNN>")
        return 2
    try:
        reg = abrir(argv[2])
    except (ErrorRegistro, OSError) as e:
        print("ERROR: %s" % e)
        return 1
    print("%s / %s  modulo=%s  estado=%s  revision=%s" % (
        reg["oferta_id"], reg["ejecucion_id"], reg["modulo"], reg["estado"], reg["revision"]["estado"]))
    for s in reg["solicitudes"]:
        print("  %s %s %s intento=%s estado=%s id_externo=%s" % (
            s["solicitud_id"], s["via"], s["proveedor"], s["intento"], s["estado"], s["id_externo"]))
    for p, c in reg["consumo"].items():
        print("  consumo %s: tope=%s estimado=%s real=%s %s (%s)" % (
            p, c["tope_autorizado"], c["estimado"], c["real"], c["unidad"] or "", c["estado"]))
    return 1 if reg["estado"] == "envio_incierto" else 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
