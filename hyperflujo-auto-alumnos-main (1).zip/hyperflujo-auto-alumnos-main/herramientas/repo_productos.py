#!/usr/bin/env python3
"""repo_productos.py — sube el producto al repo común de productos (D119; antes D89/D96, TAREA 036 D).

    python herramientas/repo_productos.py publicar --of OF-001     # sube productos/OF-001/ (entrega + LEEME.md) y hace push

D119 (Ramiro, 2026-10-23): «testimonios fuera del sistema: quitá el código». Al repo de productos solo se sube el
producto: no se piden, no se recogen ni se validan reviews, testimonios ni perfiles de probadores, y nada del ciclo
espera por ellos. El director corre `publicar` apenas el producto está listo.
Reglas:
  * Nuestros commits los firma el autor «hyperflujo-auto».
  * URL del repo: REPO_PRODUCTOS_URL (.env o entorno); clon de trabajo en operacion/repo_productos/ (fuera de git).
Solo biblioteca estándar + el ejecutable git.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

AUTOR = "hyperflujo-auto"
CORREO = "robot@hyperflujo.invalid"


class SinRepo(RuntimeError):
    pass


def url_repo():
    u = os.environ.get("REPO_PRODUCTOS_URL")
    if not u:
        try:
            import claves
            u = claves.clave("REPO_PRODUCTOS_URL") if claves.estado().get("REPO_PRODUCTOS_URL") else None
        except Exception:
            u = None
    return u


def dir_trabajo():
    return rutas.ruta("operacion", "repo_productos")


def git(*args, cwd=None, entrada=None, binario=False):
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    r = subprocess.run(["git", *args], cwd=str(cwd) if cwd else None, capture_output=True, input=entrada, env=env,
                       text=not binario, timeout=300)
    if r.returncode != 0:
        err = r.stderr if not binario else r.stderr.decode("utf-8", "replace")
        raise RuntimeError("git %s: %s" % (args[0], (err or "").strip()[:300]))
    return r.stdout


def abrir(url=None, carpeta=None):
    """Clon de trabajo (lo crea si falta). Sin URL configurada: SinRepo (se informa, no se inventa)."""
    carpeta = Path(carpeta or dir_trabajo())
    if (carpeta / ".git").exists():
        return carpeta
    url = url or url_repo()
    if not url:
        raise SinRepo("falta REPO_PRODUCTOS_URL (.env): sin repo de productos no se sube el producto")
    carpeta.parent.mkdir(parents=True, exist_ok=True)
    git("clone", url, str(carpeta))
    return carpeta


def _estado():
    return rutas.leer_json(rutas.ruta("estado", "repo_productos.json"), defecto={})


def _guardar_estado(e):
    rutas.escribir_json(rutas.ruta("estado", "repo_productos.json"), e)


def _commit(carpeta, mensaje):
    git("-c", "user.name=%s" % AUTOR, "-c", "user.email=%s" % CORREO, "commit", "-q", "-m", mensaje, cwd=carpeta)


def publicar(of, *, url=None, carpeta=None, archivos=None):
    """Sube productos/<OF>/ (entrega y LEEME.md), hace commit y push. Devuelve {commit, carpeta, publicado_en}."""
    rutas.validar_of(of)
    carpeta = abrir(url, carpeta)
    git("pull", "-q", "--ff-only", "origin", "main", cwd=carpeta)
    destino = carpeta / "productos" / of
    (destino / "entrega").mkdir(parents=True, exist_ok=True)
    origen = rutas.dir_oferta(of) / "producto" / "entrega"
    for f in (archivos if archivos is not None else (sorted(origen.glob("*")) if origen.exists() else [])):
        f = Path(f)
        if f.is_file():
            shutil.copy2(f, destino / "entrega" / f.name)
    ficha = rutas.leer_json(rutas.ruta_ficha(of), defecto={})
    leeme = rutas.ruta("plantillas", "repo_productos", "LEEME.md").read_text(encoding="utf-8")
    leeme = leeme.replace("{of}", of).replace("{titulo}", str((ficha.get("producto") or {}).get("nombre") or of))
    (destino / "LEEME.md").write_text(leeme, encoding="utf-8")
    git("add", "--", "productos/%s" % of, cwd=carpeta)
    if git("status", "--porcelain", cwd=carpeta).strip():
        _commit(carpeta, "productos: %s" % of)
    git("push", "-q", "origin", "HEAD:main", cwd=carpeta)
    commit = git("rev-parse", "HEAD", cwd=carpeta).strip()
    e = _estado()
    e.setdefault("publicados", {})[of] = {"commit": commit, "publicado_en": rutas.ahora().isoformat(timespec="seconds")}
    _guardar_estado(e)
    rutas.guardar_externo(of, repo_productos={"commit": commit, "carpeta": "productos/%s" % of})
    return {"commit": commit, "carpeta": "productos/%s" % of, "publicado_en": e["publicados"][of]["publicado_en"]}


def publicado_en(of):
    return ((_estado().get("publicados") or {}).get(of) or {}).get("publicado_en")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Sube el producto al repo común de productos (D119: solo el producto).")
    ap.add_argument("orden", choices=("publicar",))
    ap.add_argument("--of", required=True)
    a = ap.parse_args()
    try:
        r = publicar(rutas.validar_of(a.of))
        print(json.dumps({"ok": True, "codigo": 0, "motivo": json.dumps(r, ensure_ascii=False)[:500], "artefactos": []}, ensure_ascii=False))
    except SinRepo as e:
        print(json.dumps({"ok": False, "codigo": 3, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
        sys.exit(3)
    except RuntimeError as e:
        print(json.dumps({"ok": False, "codigo": 1, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
        sys.exit(1)
