#!/usr/bin/env python3
r"""ruta_claude.py — encuentra el ejecutable de Claude Code en Windows, macOS o Linux (TAREA 036 parte A).

    python herramientas/ruta_claude.py            # imprime la ruta y la versión (gratis: --version no llama a la API)

Orden de búsqueda (lo explícito gana a lo implícito; desvío consciente de ARQUITECTURA §4.1, que ponía PATH primero:
una variable que el dueño fijó a mano no puede quedar tapada por otro `claude` que aparezca en PATH):
  1. HYPERFLUJO_CLAUDE_EXE o datos/config.local.json → "claude_exe";
  2. `claude` en PATH;
  3. la CLI empaquetada con la app de escritorio, versión más alta:
       Windows  %LOCALAPPDATA%\Claude-Data\<id>\claude-code\<versión>\<hash>\claude.exe  (verificado en 2.1.304)
       macOS    ~/Library/Application Support/Claude-Data/<id>/claude-code/<versión>/**/claude  [PENDIENTE: confirmar en una Mac]
       Linux    ~/.config/Claude-Data/<id>/claude-code/<versión>/**/claude                     [PENDIENTE: confirmar]
  4. instalaciones de usuario: ~/.local/bin/claude, ~/.claude/local/claude, %USERPROFILE%\.local\bin\claude.exe.
Nunca descarga ni instala nada. Solo biblioteca estándar.
"""
import glob
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _version_tupla(texto):
    return tuple(int(x) for x in re.findall(r"\d+", texto)[:4]) or (0,)


def _config_exe():
    try:
        import rutas
        return (rutas.cargar_dato("config", defecto={}) or {}).get("claude_exe")
    except Exception:
        return None


def candidatos_app(sistema=None, entorno=None, casa=None):
    """Rutas de la CLI empaquetada con la app, de la versión más alta a la más baja."""
    sistema = sistema or sys.platform
    entorno = os.environ if entorno is None else entorno
    casa = Path(casa or Path.home())
    if sistema.startswith("win"):
        base = entorno.get("LOCALAPPDATA") or str(casa / "AppData" / "Local")
        patron, nombre = os.path.join(base, "Claude-Data", "*", "claude-code", "*"), "claude.exe"
    elif sistema == "darwin":
        patron, nombre = str(casa / "Library" / "Application Support" / "Claude-Data" / "*" / "claude-code" / "*"), "claude"
    else:
        patron, nombre = str(casa / ".config" / "Claude-Data" / "*" / "claude-code" / "*"), "claude"
    versiones = sorted(glob.glob(patron), key=lambda p: _version_tupla(os.path.basename(p)), reverse=True)
    salida = []
    for v in versiones:
        directos = [os.path.join(v, nombre)] + sorted(glob.glob(os.path.join(v, "*", nombre)))
        salida += [p for p in directos if os.path.isfile(p)]
    return salida


def resolver(entorno=None, sistema=None, casa=None, quien=shutil.which, config_exe=None):
    """Ruta absoluta del ejecutable, o None si no hay ninguno (el director lo informa como bloqueo humano)."""
    entorno = os.environ if entorno is None else entorno
    sistema = sistema or sys.platform
    casa = Path(casa or Path.home())
    explicito = entorno.get("HYPERFLUJO_CLAUDE_EXE") or (config_exe if config_exe is not None else _config_exe())
    if explicito:
        return str(Path(explicito)) if os.path.isfile(explicito) else None   # explícito y roto = None, no se adivina otro
    en_path = quien("claude")
    if en_path:
        return en_path
    app = candidatos_app(sistema, entorno, casa)
    if app:
        return app[0]
    nombre = "claude.exe" if sistema.startswith("win") else "claude"
    for p in (casa / ".local" / "bin" / nombre, casa / ".claude" / "local" / nombre):
        if p.is_file():
            return str(p)
    return None


def version(exe, ejecutar=subprocess.run):
    """`<exe> --version` (no llama a la API). None si no responde."""
    try:
        r = ejecutar([exe, "--version"], capture_output=True, text=True, timeout=30)
    except Exception:
        return None
    if r.returncode != 0:
        return None
    return (r.stdout or "").strip() or None


if __name__ == "__main__":
    import argparse
    argparse.ArgumentParser(description="Encuentra el ejecutable de Claude Code (no instala nada).").parse_args()
    exe = resolver()
    v = version(exe) if exe else None
    print("claude: %s" % ("disponible" if exe else "no disponible"))
    print("versión: %s" % (v or "desconocida"))
    print(json.dumps({"ok": bool(exe and v), "codigo": 0 if exe and v else 3,
                      "motivo": "CLI encontrada" if exe and v else "no se encontró la CLI de Claude Code: instalarla o fijar HYPERFLUJO_CLAUDE_EXE",
                      "artefactos": []}, ensure_ascii=False))
    sys.exit(0 if exe and v else 3)
