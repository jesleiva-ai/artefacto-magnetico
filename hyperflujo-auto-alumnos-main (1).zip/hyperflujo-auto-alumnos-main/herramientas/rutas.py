#!/usr/bin/env python3
"""rutas.py — base común de hyperflujo-auto (rutas, lectura y escritura de JSON, fecha del dueño).

Todo módulo del repo resuelve rutas, lee datos del dueño y escribe JSON a través de este archivo, para que nada
dependa de la PC de nadie (Hyperflujo, TAREA 035 §3.1) y para que dos constructores no inventen dos formas de lo mismo.

    from rutas import RAIZ, ruta, leer_json, escribir_json, cargar_dato, ficha, externo, guardar_externo, hoy, ahora

Reglas:
  * Rutas siempre relativas a la raíz del repo (RAIZ). Se puede mover con HYPERFLUJO_RAIZ (lo usan las pruebas y el
    ensayo en seco para trabajar sobre una copia temporal).
  * Escritura atómica: temporal en la misma carpeta + os.replace (como registro.py del taller).
  * Datos del dueño: datos/<nombre>.local.json (fuera de git). Si falta, FaltaDato con la instrucción exacta;
    nunca se inventa un valor por defecto para topes, dueños, autorizaciones ni cuentas.
  * IDs reales de un producto (códigos de Hotmart, IDs de Meta, sitios de Netlify): ofertas/OF-NNN/externo.local.json
    (fuera de git). La ficha (oferta.json) solo lleva marcadores.
  * Fecha y hora en la zona del dueño (datos/config.local.json → "zona", o HYPERFLUJO_ZONA). Windows no trae la base de
    zonas: sin el paquete tzdata se usan desfasajes fijos para zonas sin horario de verano y, si no, se pide instalar
    tzdata en vez de adivinar. Criterio tomado de Ramiro, cerebro-kit/herramientas/hoy.py.
Solo biblioteca estándar.
"""
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

for _flujo in (sys.stdout, sys.stderr):      # Windows: la consola cp1252 revienta con «→» (F41)
    try:
        _flujo.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

RAIZ = Path(os.environ.get("HYPERFLUJO_RAIZ") or Path(__file__).resolve().parents[1])
RE_OF = re.compile(r"^OF-\d{3,}$")
_FALTA = object()

# Zonas sin horario de verano: su desfasaje fijo es exacto todo el año (Ramiro, hoy.py).
ZONAS_FIJAS = {
    "UTC": 0,
    "America/Argentina/Buenos_Aires": -3, "America/Buenos_Aires": -3, "America/Montevideo": -3,
    "America/Argentina/Cordoba": -3, "America/Cordoba": -3,   # TAREA 037 D: zona real de la cuenta «Yoga facial» (sin tzdata en Windows)
    "America/Sao_Paulo": -3, "America/Bogota": -5, "America/Lima": -5, "America/Mexico_City": -6,
    "America/Guayaquil": -5, "America/Caracas": -4, "America/La_Paz": -4,
}


class FaltaDato(Exception):
    """Falta un archivo de datos del dueño o un campo obligatorio: el ciclo no inventa, se detiene y lo informa."""


def ruta(*partes):
    """Ruta absoluta dentro del repo: ruta("estado", "planes") → RAIZ/estado/planes."""
    return RAIZ.joinpath(*partes)


def leer_json(p, defecto=_FALTA):
    p = Path(p)
    if not p.exists():
        if defecto is _FALTA:
            raise FileNotFoundError(str(p))
        return defecto
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def escribir_json(p, datos):
    """Escritura atómica (temporal + os.replace). Crea la carpeta si falta. Devuelve la ruta."""
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp_", suffix=".json", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, p)
    except BaseException:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    return p


def cargar_dato(nombre, local=True, defecto=_FALTA):
    """datos/<nombre>.local.json (local=True: decisiones del dueño, fuera de git) o datos/<nombre>.json (versionado).

    Sin el archivo: FaltaDato con la instrucción (copiar el .ejemplo y completarlo), salvo que se pase defecto."""
    archivo = ruta("datos", "%s.local.json" % nombre if local else "%s.json" % nombre)
    if not archivo.exists():
        if defecto is not _FALTA:
            return defecto
        if local:
            raise FaltaDato("Falta datos/%s.local.json: copiar datos/%s.ejemplo.json y completarlo (ver docs/ONBOARDING.md)."
                            % (nombre, nombre))
        raise FaltaDato("Falta datos/%s.json (archivo versionado del repo)." % nombre)
    return leer_json(archivo)


def validar_of(of):
    if not isinstance(of, str) or not RE_OF.match(of):
        raise ValueError("Identificador de oferta inválido: %r (esperado OF-NNN)" % (of,))
    return of


def dir_oferta(of):
    return ruta("ofertas", validar_of(of))


def ruta_ficha(of):
    return dir_oferta(of) / "oferta.json"


def ficha(of):
    """La ficha vigente (autoridad del contenido, regla 1)."""
    return leer_json(ruta_ficha(of))


def externo(of):
    """IDs reales del producto (fuera de git). {} si todavía no hay ninguno."""
    return leer_json(dir_oferta(of) / "externo.local.json", defecto={})


def guardar_externo(of, **campos):
    """Mezcla campos en ofertas/OF-NNN/externo.local.json (claves de primer nivel; los dicts se mezclan un nivel)."""
    actual = externo(of)
    for k, v in campos.items():
        if isinstance(v, dict) and isinstance(actual.get(k), dict):
            actual[k] = {**actual[k], **v}
        else:
            actual[k] = v
    return escribir_json(dir_oferta(of) / "externo.local.json", actual)


def zona_horaria(nombre=None):
    """tzinfo de la zona del dueño. Orden: argumento → HYPERFLUJO_ZONA → datos/config.local.json "zona" → UTC."""
    if not nombre:
        nombre = os.environ.get("HYPERFLUJO_ZONA")
    if not nombre:
        try:
            nombre = (cargar_dato("config", defecto={}) or {}).get("zona")
        except (OSError, ValueError):
            nombre = None
    nombre = nombre or "UTC"
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(nombre)
    except Exception:
        if nombre in ZONAS_FIJAS:
            return timezone(timedelta(hours=ZONAS_FIJAS[nombre]))
        raise FaltaDato("Esta máquina no conoce la zona «%s»: instalar la base de zonas (python -m pip install tzdata) "
                        "o usar una zona sin horario de verano." % nombre)


def ahora(zona=None):
    """datetime con zona. HYPERFLUJO_AHORA=ISO fija el reloj (ensayo en seco y pruebas)."""
    fijo = os.environ.get("HYPERFLUJO_AHORA")
    tz = zona_horaria(zona)
    if fijo:
        d = datetime.fromisoformat(fijo)
        return d if d.tzinfo else d.replace(tzinfo=tz)
    return datetime.now(tz)


def hoy(zona=None):
    """Fecha de hoy (AAAA-MM-DD) en la zona del dueño."""
    return ahora(zona).date().isoformat()


if __name__ == "__main__":
    print("RAIZ=%s  hoy=%s  zona=%s" % (RAIZ, hoy(), zona_horaria()))
