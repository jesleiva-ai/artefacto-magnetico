#!/usr/bin/env python3
"""topes.py — topes globales del dueño (datos/topes.local.json). Falla cerrado. Hyperflujo, revisión 035 h. 8.

cargar(raiz=None) -> dict | lanza TopesFaltantes si el archivo falta, no se lee o tiene null en un tope obligatorio.
cupo_activar(topes, activos, diarios_activos, diario_nuevo) -> (bool, motivo)
cupo_producir(topes, nuevos_hoy) -> (bool, motivo)
Solo biblioteca estándar. Sin red.
"""
import json
import os
from pathlib import Path

OBLIGATORIOS = ("tope_diario_global_usd", "tope_mensual_global_usd", "max_productos_activos", "max_nuevos_por_dia")


class TopesFaltantes(RuntimeError):
    pass


def _raiz(raiz=None):
    return Path(raiz or os.environ.get("HYPERFLUJO_RAIZ") or Path(__file__).resolve().parents[1])


def validar(t):
    if not isinstance(t, dict):
        raise TopesFaltantes("topes ilegibles")
    for k in OBLIGATORIOS:
        v = t.get(k)
        if v is None or isinstance(v, bool) or not isinstance(v, (int, float)) or v < 0:
            raise TopesFaltantes(f"tope «{k}» nulo o inválido: falla cerrado (no se produce ni se activa)")
    return t


def cargar(raiz=None):
    p = _raiz(raiz) / "datos" / "topes.local.json"
    try:
        t = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise TopesFaltantes(f"falta o no se lee datos/topes.local.json ({type(e).__name__}): falla cerrado")
    return validar(t)


def cupo_producir(topes, nuevos_hoy):
    if nuevos_hoy >= topes["max_nuevos_por_dia"]:
        return False, f"tope max_nuevos_por_dia={topes['max_nuevos_por_dia']} alcanzado"
    return True, "ok"


def cupo_activar(topes, activos, diarios_activos, diario_nuevo):
    if activos >= topes["max_productos_activos"]:
        return False, f"tope max_productos_activos={topes['max_productos_activos']} alcanzado ({activos} activos)"
    if diario_nuevo is None:
        return False, "diario de la campaña desconocido: falla cerrado"
    if (diarios_activos or 0) + diario_nuevo > topes["tope_diario_global_usd"]:
        return False, (f"suma de diarios {diarios_activos or 0} + {diario_nuevo} > tope_diario_global_usd="
                       f"{topes['tope_diario_global_usd']}")
    return True, "ok"


# ------------------------------------------------------------------ TAREA 036 parte C: mensual, por proveedor y por producto
# Libro de gasto append-only: estado/libro_gasto.jsonl, una línea por gasto confirmado o reservado
# {"en", "fecha", "proveedor", "monto", "unidad", "usd", "of", "ref"}. Ilegible = falla cerrado.
import math  # noqa: E402

PROVEEDORES = ("meta", "higgsfield", "elevenlabs", "anthropic", "kie", "heygen")


def _libro(raiz=None):
    return _raiz(raiz) / "estado" / "libro_gasto.jsonl"


def a_usd(proveedor, monto, raiz=None):
    """Convierte la unidad propia del proveedor a USD con datos/tarifas.json. Sin tarifa = None (no se gasta)."""
    try:
        t = json.loads((_raiz(raiz) / "datos" / "tarifas.json").read_text(encoding="utf-8"))["proveedores"].get(proveedor) or {}
        loc = _raiz(raiz) / "datos" / "tarifas.local.json"   # TAREA 037 D: la tarifa local del dueño manda
        if loc.exists():
            t = (json.loads(loc.read_text(encoding="utf-8")).get("proveedores") or {}).get(proveedor) or t
    except (OSError, ValueError, KeyError):
        return None
    f = t.get("usd_por_unidad")
    if not isinstance(f, (int, float)) or isinstance(f, bool) or monto is None:
        return None
    return round(monto * f, 4)


def registrar_gasto(proveedor, monto, unidad, *, of=None, ref=None, fecha=None, raiz=None):
    """Agrega una línea al libro (lo usan la puerta y los lectores al conciliar). Devuelve la fila."""
    import datetime as _dt
    fila = {"en": _dt.datetime.now().astimezone().isoformat(timespec="seconds"), "fecha": fecha or _dt.date.today().isoformat(),
            "proveedor": proveedor, "monto": monto, "unidad": unidad, "usd": a_usd(proveedor, monto, raiz), "of": of, "ref": ref}
    p = _libro(raiz)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(fila, ensure_ascii=False) + "\n")
    return fila


def gastado(*, proveedor=None, of=None, desde=None, hasta=None, en_usd=False, raiz=None):
    """Suma del libro con filtros (fechas AAAA-MM-DD inclusive). Libro ilegible → TopesFaltantes. Un usd nulo → None."""
    p = _libro(raiz)
    if not p.exists():
        return 0.0
    try:
        filas = [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
    except (OSError, ValueError) as e:
        raise TopesFaltantes("libro de gasto ilegible (%s): falla cerrado" % type(e).__name__)
    total = 0.0
    for f in filas:
        if (proveedor and f.get("proveedor") != proveedor) or (of and f.get("of") != of):
            continue
        if (desde and f.get("fecha", "") < desde) or (hasta and f.get("fecha", "") > hasta):
            continue
        v = f.get("usd") if en_usd else f.get("monto")
        if v is None:
            return None
        total += v
    return round(total, 4)


def tope_ficha(ficha, proveedor):
    """D105: tope por producto escrito en la ficha → presupuesto.por_proveedor.<proveedor>.tope_autorizado (+ unidad,
    autorizado_por, autorizacion_ref). Meta: campana.presupuesto (diario × días). None si no está completo."""
    if proveedor == "meta":
        pr = ((ficha or {}).get("campana") or {}).get("presupuesto") or {}
        d, n = pr.get("diario"), pr.get("dias")
        ok = all(isinstance(x, (int, float)) and not isinstance(x, bool) and x > 0 for x in (d, n)) and pr.get("autorizado_por")
        return {"tope": d * n, "unidad": "USD"} if ok else None
    t = (((ficha or {}).get("presupuesto") or {}).get("por_proveedor") or {}).get(proveedor) or {}
    v = t.get("tope_autorizado")
    if not isinstance(v, (int, float)) or isinstance(v, bool) or v <= 0 or not t.get("unidad") or not t.get("autorizado_por"):
        return None
    return {"tope": v, "unidad": t["unidad"], "autorizacion_ref": t.get("autorizacion_ref")}


def cabe(proveedor, estimado, *, fecha, topes, of=None, ficha=None, diarios_meta=None, gasto_meta_mes=None, raiz=None):
    """¿Entra `estimado` (unidad del proveedor) en los cuatro cercos de código? Devuelve (bool, motivo). Falla cerrado.
    1) ficha del producto (D105); 2) tope diario del proveedor; 3) tope diario global (diarios de Meta + gastos del día);
    4) tope mensual global (libro del mes + gasto de Meta del mes). Nulo o desconocido en cualquiera = no cabe."""
    try:
        return _cabe(proveedor, estimado, fecha=fecha, topes=topes, of=of, ficha=ficha, diarios_meta=diarios_meta,
                     gasto_meta_mes=gasto_meta_mes, raiz=raiz)
    except TopesFaltantes as e:   # libro ilegible u otro faltante: no cabe
        return False, str(e)


def _cabe(proveedor, estimado, *, fecha, topes, of, ficha, diarios_meta, gasto_meta_mes, raiz):
    if not isinstance(estimado, (int, float)) or isinstance(estimado, bool) or not math.isfinite(estimado) or estimado <= 0:
        return False, "estimado inválido (tiene que ser > 0 y finito; costo desconocido = no se envía)"
    try:
        validar(topes)
    except TopesFaltantes as e:
        return False, str(e)
    if of is not None:
        tf = tope_ficha(ficha, proveedor)
        if tf is None:
            return False, "D105: la ficha de %s no tiene tope escrito para %s" % (of, proveedor)
        usado = gastado(proveedor=proveedor, of=of, raiz=raiz)
        if usado is None or usado + estimado > tf["tope"]:
            return False, "D105: %s + %s > tope de la ficha %s %s" % (usado, estimado, tf["tope"], tf["unidad"])
    tp = ((topes.get("por_proveedor_dia") or {}).get(proveedor) or {}).get("tope")
    if proveedor != "meta":
        if not isinstance(tp, (int, float)) or isinstance(tp, bool):
            return False, "sin tope diario para %s en datos/topes.local.json (null = no se gasta)" % proveedor
        hoy = gastado(proveedor=proveedor, desde=fecha, hasta=fecha, raiz=raiz)
        if hoy is None or hoy + estimado > tp:
            return False, "tope diario de %s: %s + %s > %s" % (proveedor, hoy, estimado, tp)
    usd = estimado if proveedor == "meta" else a_usd(proveedor, estimado, raiz)
    if usd is None:
        return False, "sin tarifa USD para %s en datos/tarifas.json: no se puede controlar el tope global" % proveedor
    hoy_usd = gastado(desde=fecha, hasta=fecha, en_usd=True, raiz=raiz)
    if hoy_usd is None or diarios_meta is None:
        return False, "gasto del día desconocido (nulo ≠ 0): falla cerrado"
    if diarios_meta + hoy_usd + usd > topes["tope_diario_global_usd"]:
        return False, "tope diario global: %s (Meta) + %s + %s > %s" % (diarios_meta, hoy_usd, usd, topes["tope_diario_global_usd"])
    mes = gastado(desde=fecha[:8] + "01", hasta=fecha, en_usd=True, raiz=raiz)
    if mes is None or gasto_meta_mes is None:
        return False, "gasto del mes desconocido (nulo ≠ 0): falla cerrado"
    if mes + gasto_meta_mes + usd > topes["tope_mensual_global_usd"]:
        return False, "tope mensual global: %s + %s (Meta) + %s > %s" % (mes, gasto_meta_mes, usd, topes["tope_mensual_global_usd"])
    return True, "ok"


def cupo_mensual(topes, gasto_mes, diario_nuevo=0):
    """Antes de activar o escalar: el gasto del mes (Meta + libro) más un día del diario nuevo entra en el mensual."""
    if gasto_mes is None:
        return False, "gasto del mes desconocido (nulo ≠ 0): no se activa ni se escala"
    if gasto_mes + (diario_nuevo or 0) > topes["tope_mensual_global_usd"]:
        return False, "tope_mensual_global_usd=%s alcanzado (mes: %s)" % (topes["tope_mensual_global_usd"], gasto_mes)
    return True, "ok"
