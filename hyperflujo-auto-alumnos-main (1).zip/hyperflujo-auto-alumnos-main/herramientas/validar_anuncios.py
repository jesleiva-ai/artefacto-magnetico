#!/usr/bin/env python3
"""validar_anuncios.py — control D8 y de compliance de los anuncios antes de crearlos o activarlos (revisión 035 h. 13).

errores(anuncio) -> lista de problemas. Revisa el texto (titulo, texto, descripcion) y la declaración obligatoria de lo
que va incrustado en la imagen o el video (`incrustado`, string; vacío = "" explícito). Busca urgencia, estrellas,
tachado, precios «antes», antes/después y atributos personales. nicho_permitido(nicho) usa una lista cerrada.
Solo biblioteca estándar. No reemplaza la revisión de Meta: la anticipa.
"""
import re

PATRONES = [
    (r"[★⭐✩✪]|\b\d([.,]\d)?\s*/\s*5\b|\bestrellas?\b", "estrellas o calificaciones"),
    (r"[̶]|\btachad|\bantes\s+(usd|\$|u\$s)|\bprecio regular\b", "precio tachado o «antes»"),
    (r"[úu]ltimas?\s+(horas|unidades|plazas|cupos)|\bsolo\s+hoy\b|\bquedan\s+\d+|\bcuenta regresiva\b|\btermina en\b|\bexpira\b",
     "urgencia o escasez (D8)"),
    (r"\bantes\s+y\s+despu[eé]s\b|\bbefore\s+and\s+after\b", "antes y después"),
    (r"\b(t[uú]|usted)\s+(eres|est[aá]s|tienes)\s+(gord|obes|deprimid|endeudad|enferm|diab[eé]tic)", "atributos personales (políticas de Meta)"),
    (r"\bgarantizad[oa]s?\s+(ganar|ingres)|\bganar?\s+\$?\d+.*\b(d[ií]a|semana|mes)\b", "promesa de ingresos"),
]
# Lista cerrada de nichos permitidos (por defecto excluye salud, finanzas, empleo, vivienda, crédito y temas sociales).
NICHOS_PERMITIDOS = {"manualidades", "cocina", "jardineria", "hogar", "mascotas", "idiomas", "musica", "fotografia",
                     "organizacion", "juegos", "lectura", "arte", "costura", "carpinteria"}


def errores(a):
    out = []
    if "incrustado" not in a:
        out.append("%s: falta la declaración «incrustado» (texto que va en la imagen o el video)" % a.get("nombre"))
    texto = " ".join(str(a.get(k) or "") for k in ("titulo", "texto", "descripcion", "incrustado")).lower()
    for patron, motivo in PATRONES:
        if re.search(patron, texto, re.IGNORECASE):
            out.append("%s: %s" % (a.get("nombre"), motivo))
    return out


def nicho_permitido(nicho):
    return (nicho or "").strip().lower() in NICHOS_PERMITIDOS


# ------------------------------------------------------------------ D103 (Ramiro 2026-10-22): etapa obligatoria
# Revisión con los criterios de Matías ANTES de cargar anuncios (F39): entre «anuncios» y «campaña». El director no deja
# pasar un producto a activar si ofertas/<OF>/anuncios/validacion.json no está en verde para el copy.json vigente.
import hashlib  # noqa: E402
import json  # noqa: E402
import os  # noqa: E402
import sys  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _copy(of):
    import rutas
    return rutas.dir_oferta(of) / "anuncios" / "copy.json"


def validar_archivo(of):
    """Valida ofertas/<OF>/anuncios/copy.json (lista «anuncios») y deja validacion.json con su sha256."""
    import rutas
    p = _copy(of)
    if not p.exists():
        return {"ok": False, "errores": ["falta ofertas/%s/anuncios/copy.json" % of]}
    crudo = p.read_bytes()
    datos = json.loads(crudo.decode("utf-8"))
    anuncios = datos.get("anuncios", datos if isinstance(datos, list) else [])
    errs = [e for a in anuncios for e in errores(a)]
    if not anuncios:
        errs.append("copy.json sin anuncios")
    if datos.get("nicho") is not None and not nicho_permitido(datos.get("nicho")):
        errs.append("nicho fuera de la lista cerrada: %s" % datos.get("nicho"))
    r = {"ok": not errs, "errores": errs, "sha256": hashlib.sha256(crudo).hexdigest(), "anuncios": len(anuncios),
         "fecha": rutas.ahora().isoformat(timespec="seconds"), "regla": "D103 (validar antes de cargar anuncios; F39)"}
    rutas.escribir_json(p.parent / "validacion.json", r)
    return r


def validacion_vigente(of):
    """(ok, motivo): validacion.json en verde y para el copy.json actual (un cambio posterior la invalida)."""
    import rutas
    p, v = _copy(of), rutas.dir_oferta(of) / "anuncios" / "validacion.json"
    if not p.exists() or not v.exists():
        return False, "sin validar_anuncios para %s (etapa obligatoria antes de la campaña)" % of
    val = rutas.leer_json(v)
    if val.get("sha256") != hashlib.sha256(p.read_bytes()).hexdigest():
        return False, "copy.json cambió después de validarse: correr validar_anuncios de nuevo"
    if not val.get("ok"):
        return False, "validar_anuncios con errores: " + "; ".join(val.get("errores", [])[:3])
    return True, "anuncios validados"


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Valida los anuncios de un producto (D8, compliance, D103).")
    ap.add_argument("--of", required=True)
    a = ap.parse_args()
    r = validar_archivo(a.of)
    for e in r["errores"]:
        print("-", e)
    print(json.dumps({"ok": r["ok"], "codigo": 0 if r["ok"] else 2, "motivo": "%d error(es)" % len(r["errores"]),
                      "artefactos": ["ofertas/%s/anuncios/validacion.json" % a.of]}, ensure_ascii=False))
    sys.exit(0 if r["ok"] else 2)
