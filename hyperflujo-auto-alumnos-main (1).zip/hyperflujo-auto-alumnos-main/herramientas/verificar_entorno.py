#!/usr/bin/env python3
"""verificar_entorno.py — ¿esta PC puede correr hyperflujo-auto sin humanos? (TAREA 036 parte C; ARQUITECTURA §13 paso 1).

    python herramientas/verificar_entorno.py [--orquestacion]

Comprueba sin rutas fijas ni valores: Python ≥ 3.10, Node ≥ 20 y npm, Playwright instalado en la versión exacta del
package.json y lockfile presente, git, Chrome (CHROME_PATH o ubicaciones estándar de Windows/macOS/Linux), la CLI de
Claude (ruta_claude.py, `--version` no gasta), .env y qué claves están definidas (nunca sus valores), los datos del
dueño (datos/*.local.json), el tope por worker, el hook guardian_gasto registrado y el deny de escrituras que gastan.
Imprime solo «disponible / no disponible». Si todo lo obligatorio está, escribe estado/entorno_ok.json (lo exige
`programar.py instalar`). Solo biblioteca estándar.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rutas  # noqa: E402

DATOS_DUENO = ("config", "topes", "dueno", "autorizaciones", "cuentas")
CLAVES_OBLIGATORIAS = ()   # ninguna: la vigilancia sin modelo es opcional y se informa (ARQUITECTURA §8.4)
CLAVES_OPCIONALES = ("META_SYSTEM_USER_TOKEN", "META_ACCESS_TOKEN", "HOTMART_BASIC", "HOTMART_CLIENT_ID", "HOTMART_CLIENT_SECRET", "NETLIFY_AUTH_TOKEN", "REPO_PRODUCTOS_URL",
                     "ELEVENLABS_API_KEY", "HF_API_KEY_ID", "ANTHROPIC_API_KEY")
DENY_MINIMO = ("mcp__Hotmart__hotmart_sale_refund", "mcp__hotmart__hotmart_sale_refund", "mcp__claude-in-chrome__*",
               "mcp__computer-use__*")   # D99: las herramientas de gasto ya no van en deny; las cuida el hook (estrenado abajo)
EVENTO_PRUEBA = {"tool_name": "mcp__meta-ads__ads_create_campaign", "tool_input": {"name": "prueba del guardián"}}


def _version(cmd, ejecutar):
    try:
        r = ejecutar(cmd, capture_output=True, text=True, timeout=30)
        return (r.stdout or r.stderr or "").strip() if r.returncode == 0 else None
    except Exception:
        return None


def _tupla(texto):
    return tuple(int(x) for x in re.findall(r"\d+", texto or "")[:3]) or (0,)


def chrome(entorno=None, sistema=None, existe=os.path.isfile):
    entorno = os.environ if entorno is None else entorno
    sistema = sistema or sys.platform
    if entorno.get("CHROME_PATH"):
        return entorno["CHROME_PATH"] if existe(entorno["CHROME_PATH"]) else None
    if sistema.startswith("win"):
        c = [os.path.join(entorno.get(v, ""), "Google", "Chrome", "Application", "chrome.exe")
             for v in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA") if entorno.get(v)]
    elif sistema == "darwin":
        c = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    else:
        c = [shutil.which(n) or "" for n in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser")]
    return next((x for x in c if x and existe(x)), None)


def revisar(raiz=None, ejecutar=subprocess.run, entorno=None, sistema=None, orquestacion=False):
    """→ lista de (nombre, disponible: bool, obligatorio: bool, nota)."""
    raiz = Path(raiz or rutas.RAIZ)
    entorno = os.environ if entorno is None else entorno
    res = [("python >= 3.10", sys.version_info >= (3, 10), True, "%d.%d" % sys.version_info[:2])]
    node = _version(["node", "--version"], ejecutar)
    res.append(("node >= 20", node is not None and _tupla(node) >= (20,), True, node or ""))
    res.append(("npm", _version(["npm.cmd" if (sistema or sys.platform).startswith("win") else "npm", "--version"], ejecutar) is not None, True, ""))
    try:
        pedido = json.loads((raiz / "package.json").read_text(encoding="utf-8"))["devDependencies"]["playwright"]
    except (OSError, ValueError, KeyError):
        pedido = None
    try:
        instalado = json.loads((raiz / "node_modules" / "playwright" / "package.json").read_text(encoding="utf-8"))["version"]
    except (OSError, ValueError, KeyError):
        instalado = None
    res.append(("playwright %s instalado (npm ci)" % pedido, instalado is not None and instalado == pedido, True, instalado or ""))
    res.append(("package-lock.json", (raiz / "package-lock.json").exists(), True, ""))
    res.append(("git", _version(["git", "--version"], ejecutar) is not None, True, ""))
    res.append(("Chrome (robot de Hotmart)", chrome(entorno, sistema) is not None, True, ""))
    import ruta_claude
    exe = ruta_claude.resolver(entorno=entorno, sistema=sistema)
    res.append(("CLI de Claude Code", bool(exe and ruta_claude.version(exe, ejecutar)), True, ""))
    res.append((".env", (raiz / ".env").exists(), False, "las claves de vigilancia sin modelo son opcionales"))
    try:
        import claves
        est = claves.estado(str(raiz / ".env"))
    except Exception:
        est = {}
    for n in CLAVES_OPCIONALES:
        res.append(("clave %s" % n, bool(est.get(n) or entorno.get(n)), n in CLAVES_OBLIGATORIAS, ""))
    for d in DATOS_DUENO:
        res.append(("datos/%s.local.json" % d, (raiz / "datos" / ("%s.local.json" % d)).exists(), True, ""))
    try:
        conf = json.loads((raiz / "datos" / "config.local.json").read_text(encoding="utf-8"))
        tope = (conf.get("workers") or {}).get("max_budget_usd_por_worker")
    except (OSError, ValueError):
        tope = None
    res.append(("workers.max_budget_usd_por_worker", isinstance(tope, (int, float)) and not isinstance(tope, bool) and tope > 0, True, ""))
    try:
        s = json.loads((raiz / ".claude" / "settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        s = {}
    hooks = json.dumps(s.get("hooks") or {})
    res.append(("hook guardian_gasto registrado", "guardian_gasto.py" in hooks and (raiz / "herramientas" / "hooks" / "guardian_gasto.py").exists(), False, "opcional: modo sin restricciones (2026-10-27)"))
    deny = set((s.get("permissions") or {}).get("deny") or [])
    res.append(("deny de reembolsos y conectores del usuario", all(d in deny for d in DENY_MINIMO), False, "opcional: modo sin restricciones (2026-10-27)"))
    hook = raiz / "herramientas" / "hooks" / "guardian_gasto.py"
    try:   # «se estrenan rompiéndolos» (Ramiro): un gasto sin ticket tiene que salir negado (código 2)
        r = ejecutar([sys.executable, str(hook)], input=json.dumps(EVENTO_PRUEBA), capture_output=True, text=True, timeout=60,
                     env=dict(entorno, HYPERFLUJO_RAIZ=str(raiz), HYPERFLUJO_OF="OF-000"))
        estrenado = r.returncode == 2
    except Exception:
        estrenado = False
    res.append(("guardián estrenado (niega un gasto sin ticket)", estrenado, False, "opcional: modo sin restricciones (2026-10-27)"))
    if orquestacion:
        res.append(("vía B (tareas locales de la app)", (Path.home() / ".claude" / "scheduled-tasks").exists(), False, ""))
    try:   # 25/10: informativo (programar.py instalar exige este entorno en verde antes de registrar la tarea)
        import detectar
        v = detectar.vigia_item(ejecutar, sistema)
        res.append(("vigía corriendo (tarea habilitada, última corrida < 2 h)", v["estado"] == "disponible", False, v.get("nota", "")))
    except Exception as e:
        res.append(("vigía corriendo (tarea habilitada, última corrida < 2 h)", False, False, type(e).__name__))
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Verifica el entorno de hyperflujo-auto (solo disponible / no disponible).")
    ap.add_argument("--orquestacion", action="store_true")
    a = ap.parse_args()
    res = revisar(orquestacion=a.orquestacion)
    for nombre, ok, oblig, _nota in res:
        print("%-45s %s%s" % (nombre, "disponible" if ok else "no disponible", "" if ok or not oblig else "  (obligatorio)"))
    faltan = [n for n, ok, oblig, _ in res if oblig and not ok]
    if not faltan:
        rutas.escribir_json(rutas.ruta("estado", "entorno_ok.json"), {"hora": rutas.ahora().isoformat(timespec="seconds")})
    print(json.dumps({"ok": not faltan, "codigo": 0 if not faltan else 2,
                      "motivo": "entorno completo" if not faltan else "faltan: " + ", ".join(faltan),
                      "artefactos": ["estado/entorno_ok.json"] if not faltan else []}, ensure_ascii=False))
    sys.exit(0 if not faltan else 2)
