#!/usr/bin/env python3
"""vigia.py — decisión horaria de pausa técnica (revisión adversarial 035 h. 2). Solo biblioteca estándar.

vigilar(campana, sondear, leer_gasto_hoy, dormir=time.sleep, separacion_s=300, factor=1.10) -> dict
  * Landing y checkout: dos lecturas separadas por `separacion_s` (5 min, reglas_operacion.json pausa_seguridad);
    si las dos fallan (≠ 200) → pausa técnica. Una sola caída no pausa.
  * Gasto de hoy contra lo autorizado: gasto > diario × factor → pausa técnica. Gasto desconocido = nulo: se informa
    y lo resuelve la pausa por lectura caída del orquestador (nunca se lee como 0).
Transportes inyectables (pruebas con dobles).

tick() (TAREA 036 parte B) — la pasada horaria real (minuto :37, programar.py), sin modelo:
  1. por cada producto activo: gasto de hoy (meta_lector), sonda doble de landing y checkout, `vigilar`;
  2. si corresponde pausa técnica: meta_pausa.pausar (Graph, solo PAUSED, relectura) → pausada_tecnica; si no se
     puede pausar sin modelo → bloqueada_humano con «pausar a mano» (nunca queda gastando en silencio);
  3. registra la medición de hoy (gasto, ventas y netos de Hotmart; lo que falle queda nulo).
Nunca activa ni sube gasto. CLI: python herramientas/vigia.py [--simular]  (--simular: sin red, solo informa)
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _sonda_doble(sondear, url, dormir, separacion_s):
    if not url:
        return False, "sin URL"
    s1 = seguro(sondear, url)
    if s1 == 200:
        return True, "200"
    dormir(separacion_s)
    s2 = seguro(sondear, url)
    return s2 == 200, "%s/%s" % (s1, s2)


def seguro(f, *a):
    try:
        return f(*a)
    except Exception as e:  # noqa: BLE001  (una sonda que lanza cuenta como caída)
        return type(e).__name__


def vigilar(campana, sondear, leer_gasto_hoy, dormir=time.sleep, separacion_s=300, factor=1.10):
    motivos = []
    notas_url = []
    for nombre in ("landing", "checkout"):
        url = campana.get(nombre + "_url")
        if not url:   # F60: sin URL registrada no se puede sondear; es dato faltante, nunca «caída» (no pausa)
            notas_url.append("%s sin URL registrada: no se sondea" % nombre)
            continue
        ok, det = _sonda_doble(sondear, url, dormir, separacion_s)
        if not ok:
            motivos.append("%s caída en dos lecturas (%s)" % (nombre, det))
    gasto = seguro(leer_gasto_hoy)
    diario = campana.get("diario")
    if isinstance(gasto, (int, float)) and not isinstance(gasto, bool):
        if diario is None or gasto > diario * factor:
            motivos.append("gasto de hoy %.2f > diario autorizado %s × %.2f" % (gasto, diario, factor))
        nota_gasto = None
    else:
        nota_gasto = "gasto de hoy desconocido (nulo, no 0)"
    if notas_url:
        nota_gasto = "; ".join(notas_url + ([nota_gasto] if nota_gasto else []))
    if motivos:
        return {"accion": "pausa_tecnica", "motivo": "; ".join(motivos), "nota": nota_gasto}
    return {"accion": "ok", "motivo": "landing, checkout y gasto dentro de lo autorizado", "nota": nota_gasto}


def _d106(producto, ahora):
    """Motivo si corresponde la baja D106/D92b (≥ 24 h desde la primera entrega y 0 ventas leídas), o None.
    Ventas desconocidas (nulo) nunca dan baja: eso lo resuelve la pausa técnica por lectura caída."""
    import estado as E
    import meta_operacion
    from datetime import datetime
    R = meta_operacion.reglas_de_json()
    if producto.get("sin_bajas_automaticas"):   # TAREA 040: el dueño decide las bajas de este producto (D92/D106/D107 no aplican)
        return None
    if not R.get("horas_d106_ventana") or not producto.get("primera_entrega_en"):
        return None
    desde = datetime.fromisoformat(producto["primera_entrega_en"])
    if desde.tzinfo is None:
        desde = desde.replace(tzinfo=ahora.tzinfo)
    horas = (ahora - desde).total_seconds() / 3600
    ventas = E.acumulado(producto)["ventas"]
    if horas >= R["horas_d92_sin_venta"] and ventas == 0:
        return "%.0f h desde la primera entrega sin ninguna venta (ventana de %g h tras el primer día)" % (horas, R["horas_d106_ventana"])
    return None


def sonda_http(url, timeout=15):
    """GET anónimo; devuelve el código final (sigue redirecciones) o el nombre de la excepción."""
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "hyperflujo-vigia"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:   # lectura-gratuita
            return r.status
    except urllib.error.HTTPError as e:
        return e.code


def tick(archivo=None, *, lector_meta=None, lector_hotmart=None, sondear=None, dormir=time.sleep, separacion_s=None,
         transporte_meta=None, solo_lectura=False, solo=None):
    """solo_lectura: lee y decide de verdad pero no pausa (informa «habría pausado») — para el primer ensayo real.
    solo: conjunto de OF a revisar (TAREA 040: `--solo OF-007`); None = todos los activos."""
    import director
    import estado as E
    import hotmart_lector
    import meta_lector
    import meta_pausa
    import rutas
    sondear = sondear or sonda_http
    if separacion_s is None:
        ps = (rutas.cargar_dato("reglas_operacion", local=False, defecto={}) or {}).get("pausa_seguridad") or {}
        separacion_s = 60 * float(ps.get("sonda_separacion_min", 5))
    factor = float(((rutas.cargar_dato("reglas_operacion", local=False, defecto={}) or {}).get("pausa_seguridad") or {}).get("factor_exceso_diario", 1.1))
    hoy = rutas.hoy()
    salida = {"hora": rutas.ahora().isoformat(timespec="seconds"), "productos": {}}
    for p in E.productos(archivo=archivo):
        if solo and p["of"] not in solo:
            continue
        if p["estado"] == "bloqueada_humano" and (p.get("bloqueo") or {}).get("etapa") == "vigia":
            try:   # revisión 036 h. 4: la pausa que no se confirmó se reintenta en cada pasada
                if solo_lectura:
                    salida["productos"][p["of"]] = {"accion": "habria_reintentado_pausa", "motivo": "SOLO LECTURA"}
                    continue
                r = meta_pausa.pausar(p["of"], "vigía: reintento de pausa no confirmada", transporte=transporte_meta, actor="vigia")
                if r.get("ok") and r.get("estado_meta") == "PAUSED":
                    d106 = "D106" in str((p.get("bloqueo") or {}).get("motivo", ""))
                    E.transicionar(p["of"], "en_baja" if d106 else "pausada_tecnica", "vigía: pausa confirmada en el reintento", archivo=archivo)
                    if d106:
                        E.marcar(p["of"], "reemplazo_pendiente", True, archivo=archivo)
                salida["productos"][p["of"]] = {"accion": "reintento_pausa", "motivo": r.get("motivo")}
            except Exception as e:
                salida["productos"][p["of"]] = {"accion": "error", "motivo": "%s: %s" % (type(e).__name__, str(e)[:200])}
            continue
        if p["estado"] not in E.ACTIVOS:
            continue
        try:
            _revisar(p, archivo, salida, hoy, lector_meta, lector_hotmart, sondear, dormir, separacion_s, factor, transporte_meta,
                     solo_lectura)
        except Exception as e:   # un producto roto no deja sin revisar a los demás
            salida["productos"][p["of"]] = {"accion": "error", "motivo": "%s: %s" % (type(e).__name__, str(e)[:200])}
    # una pasada en solo lectura no es «la última corrida del vigía»: no pisa la marca que vigila detectar.py
    rutas.escribir_json(rutas.ruta("estado", "vigia_ultimo_solo_lectura.json" if solo_lectura else "vigia_ultimo.json"), salida)
    return salida


def _revisar(p, archivo, salida, hoy, lector_meta, lector_hotmart, sondear, dormir, separacion_s, factor, transporte_meta,
             solo_lectura=False):
    import director
    import estado as E
    import hotmart_lector
    import meta_lector
    import meta_pausa
    import rutas
    of = p["of"]
    if True:   # (cuerpo original de la pasada por producto)
        landing, checkout = director.urls_de(of)
        m = meta_lector.leer(of, hoy, hoy, lector_meta)
        gasto = None if m is None else m["gasto_por_dia"].get(hoy, 0.0 if m["filas"] else None)
        v = hotmart_lector.ventas(of, hoy, hoy, lector_hotmart)
        dia = None if v is None else v["por_dia"].get(hoy, {"compras": 0, "netos": 0.0})
        E.registrar_medicion(of, hoy, gasto=gasto, ventas=None if dia is None else dia["compras"],
                             ingresos=None if dia is None else dia["netos"],
                             rechazados=None if m is None else len(m["rechazados"]), archivo=archivo)
        d106 = _d106(E.obtener(of, archivo), rutas.ahora())
        if d106 and solo_lectura:
            salida["productos"][of] = {"accion": "habria_pausado_d106", "motivo": "SOLO LECTURA: " + d106, "gasto_hoy": gasto}
            return
        if d106:   # D106: tras el primer día sin ninguna venta → pausa ya (no espera a la corrida diaria) y reemplazo
            r = meta_pausa.pausar(of, "vigía D106/D92b: " + d106, transporte=transporte_meta, actor="vigia")
            fila = {"accion": "baja_d106", "motivo": d106, "gasto_hoy": gasto, "pausa": {k: r.get(k) for k in ("ok", "estado_meta", "motivo")}}
            if r.get("ok") and r.get("estado_meta") == "PAUSED":
                E.transicionar(of, "en_baja", "vigía D106: %s (pausa confirmada por relectura)" % d106, archivo=archivo)
                E.marcar(of, "reemplazo_pendiente", True, archivo=archivo)
            else:
                E.transicionar(of, "bloqueada_humano", "vigía D106: %s; la pausa sin modelo falló: %s" % (d106, r.get("motivo")),
                               archivo=archivo, datos={"codigo": r.get("codigo"), "etapa": "vigia",
                                                       "accion_humana": r.get("accion_humana") or "pausar a mano la campaña de %s" % of})
            salida["productos"][of] = fila
            return
        campana = {"landing_url": landing, "checkout_url": checkout, "diario": (p.get("campana") or {}).get("diario")}
        dec = vigilar(campana, sondear, lambda: gasto, dormir=dormir, separacion_s=separacion_s, factor=factor)
        fila = {"accion": dec["accion"], "motivo": dec["motivo"], "gasto_hoy": gasto, "nota": dec.get("nota")}
        if dec["accion"] == "pausa_tecnica" and solo_lectura:
            fila["accion"] = "habria_pausado"
            dec = {"accion": "solo_lectura"}
        if dec["accion"] == "pausa_tecnica":
            r = meta_pausa.pausar(of, "vigía: " + dec["motivo"], transporte=transporte_meta, actor="vigia")
            fila["pausa"] = {k: r.get(k) for k in ("ok", "estado_meta", "motivo")}
            if r.get("ok") and r.get("estado_meta") == "PAUSED":
                E.transicionar(of, "pausada_tecnica", "vigía: %s (pausa confirmada por relectura)" % dec["motivo"], archivo=archivo)
            else:
                E.transicionar(of, "bloqueada_humano", "vigía: %s; la pausa sin modelo falló: %s" % (dec["motivo"], r.get("motivo")),
                               archivo=archivo, datos={"codigo": r.get("codigo"), "etapa": "vigia",
                                                       "accion_humana": r.get("accion_humana") or "pausar a mano la campaña de %s" % of})
        salida["productos"][of] = fila


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Pasada horaria del vigía (sin modelo): gasto, landing/checkout, pausa.")
    ap.add_argument("--simular", action="store_true", help="no lee ni pausa afuera: sondas y lectores nulos")
    ap.add_argument("--estado", help="archivo de estado (por defecto estado/productos.json)")
    ap.add_argument("--solo", action="append", help="revisar solo esta oferta (repetible), p. ej. --solo OF-007")
    ap.add_argument("--solo-lectura", action="store_true",
                    help="lee Meta y Hotmart de verdad y decide, pero no pausa ni cambia el estado real (trabaja sobre una copia)")
    a = ap.parse_args()
    if a.solo_lectura:
        import shutil
        import tempfile
        import estado as _E
        origen = Path(a.estado or _E.archivo_defecto())
        copia = Path(tempfile.mkdtemp(prefix="hf_vigia_lectura_")) / "productos.json"
        if origen.exists():
            shutil.copy2(origen, copia)
        a.estado = str(copia)
    import director
    try:
        director.tomar_cerrojo("vigia")
    except director.Ocupado as e:
        print(json.dumps({"ok": False, "codigo": 6, "motivo": str(e), "artefactos": []}, ensure_ascii=False))
        sys.exit(6)
    try:
        if a.simular:
            class _Nulo:
                def _no(self, *x):
                    raise RuntimeError("simulado: sin lectura afuera")
                leer = productos = ventas = _no
            r = tick(a.estado, lector_meta=_Nulo(), lector_hotmart=_Nulo(), sondear=lambda u: 200, dormir=lambda s: None,
                     transporte_meta=lambda *x, **k: {"status": "PAUSED"})
        else:
            r = tick(a.estado, solo_lectura=a.solo_lectura, solo=set(a.solo) if a.solo else None)
    finally:
        director.soltar_cerrojo("vigia")
    for of, f in r["productos"].items():
        print(of, f["accion"], "|", f["motivo"])
    print(json.dumps({"ok": True, "codigo": 0, "motivo": "vigía: %d productos activos revisados" % len(r["productos"]),
                      "artefactos": ["estado/vigia_ultimo.json"]}, ensure_ascii=False))
