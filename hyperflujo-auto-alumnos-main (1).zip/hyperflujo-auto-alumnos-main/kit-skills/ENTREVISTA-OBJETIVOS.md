# ENTREVISTA DE OBJETIVOS — el paso que hace tuyo el cerebro

> Para Claude: este archivo es una instrucción tuya, no un formulario para que
> el dueño de este cerebro complete solo. **Conducí la entrevista vos, en el chat.**

Hasta acá el cerebro sabe cómo se trabajan los productos digitales low-ticket.
Lo que no sabe es **qué está tratando de lograr el dueño**. Sin eso te va a dar
respuestas correctas para el negocio de otro y equivocadas para el suyo.

Mientras esta entrevista no se haga, `CLAUDE.md` tiene `(pendiente)` en el
perfil, en los proyectos y en las metas. Ese es el hueco que venís a llenar.

## Cómo conducirla

**De a un bloque por vez.** Preguntá los puntos de un bloque, esperá la
respuesta, repreguntá lo que quedó impreciso, y recién ahí pasá al siguiente.
Un cuestionario de 25 preguntas de golpe se contesta corto y en general; una
conversación de a tramos trae los números y los nombres reales.

**Repreguntá cuando la respuesta no sea verificable.** "Quiero facturar más" no
sirve; "quiero pasar de 3 a 15 ventas por día en la tienda de recetas antes de
diciembre" sí. Si dice algo vago, pedí el número, la fecha o el nombre propio.

**No inventes nada.** Lo que no diga, no se escribe. Un campo vacío es mejor
que un campo supuesto: el cerebro después lo va a citar como si fuera cierto.

**Si dice que no sabe, eso también es un dato.** "No sé mi ticket promedio" te
dice que el primer proyecto es medir, no escalar. Anotalo así.

---

## Bloque 1 — Quién es y desde dónde arranca

1. ¿Hace cuánto vendés productos digitales y qué vendiste hasta hoy?
2. ¿Trabajás solo o con alguien? Si hay equipo o socio, ¿quién hace qué?
3. ¿Cuántas horas por semana le podés poner de verdad a esto?
4. ¿En qué país estás y en qué moneda cobrás? (define impuestos, pasarelas y
   con qué números se comparan las métricas del vault)

## Bloque 2 — Sus productos hoy

5. ¿Qué productos digitales tenés vendiendo ahora mismo? Para cada uno: nombre,
   nicho, idioma y país al que le vendés.
6. Para cada uno, los números que tenga: ventas por día o facturación por mes,
   ticket promedio, conversión de la landing, ROAS. Si no los tiene, decilo así.
7. ¿Cuál está funcionando y cuál está trabado? Y la pregunta que importa:
   **¿qué creés que lo traba — la oferta, el creativo o el funnel?**
8. ¿Tenés order bump, upsells o downsell montados, o el producto se vende solo?

## Bloque 3 — Dónde está montado todo

Esto define qué herramientas del cerebro le sirven y cuáles no.

9. ¿Dónde están las tiendas: Impultienda, Shopify, otra cosa? ¿Cuántas y con
   qué cuenta de cada plataforma? (no le pidas la contraseña — solo el mapa)
10. ¿Tiene dominio propio en cada una, o está usando el subdominio de la
    plataforma?
11. ¿Qué pasarela de cobro usa en cada una y qué métodos de pago locales tiene
    prendidos por país?
12. ¿Tiene el píxel de Meta conectado y el dominio verificado? ¿Tiene Clarity o
    algún grabador de sesión?
13. ¿Dónde entrega el producto — Drive, la propia plataforma, mail? ¿El post-compra
    está armado o el comprador paga y no recibe nada más?

## Bloque 4 — Publicidad

14. ¿Está corriendo anuncios hoy? ¿En Meta, en otro lado, o nada?
15. ¿Cuántas cuentas publicitarias tiene, con qué portafolio comercial y qué
    fanpage/Instagram usa para firmar los anuncios?
16. ¿Cuánto invierte por día hoy y cuánto está dispuesto a invertir por día
    para testear una oferta nueva?
17. ¿Cómo produce los creativos hoy —él, un editor, IA— y cuántos por semana?
18. ¿Qué es lo que más le duele de la parte de anuncios? (creativos que no
    rinden, no saber cuándo cortar, no poder escalar, cuentas restringidas)

## Bloque 5 — Lo que quiere que el cerebro haga

19. De todo lo que hace hoy a mano, ¿qué le gustaría que hiciera el cerebro?
20. ¿Quiere que Claude **opere** las plataformas por él (crear campañas, cargar
    creativos, editar la tienda) o prefiere que le prepare todo y él aprieta el
    último botón? (Esto define cuánto se automatiza y cuánto se le pregunta.)
21. ¿Hay algo que **NUNCA** quiera que se toque o ejecute sin preguntarle?
    (por defecto, la casa nunca prende una campaña ni mueve un presupuesto sin
    orden explícita — confirmalo con él y anotalo)
22. ¿Prefiere que decidas y avances, o que le consultes antes?

## Bloque 6 — Sus metas

23. Meta de facturación a 3 meses y a 6 meses. Con número.
24. ¿Cuántos productos/mercados quiere tener corriendo en 6 meses?
25. Si en 6 meses todo salió bien, ¿qué es lo que cambió en su vida? Decilo en
    una frase suya, no en una tuya.
26. ¿Hay alguna otra unidad de negocio o fuente de ingreso además de esto? Para
    cada una: en qué etapa está, cuánto tiempo se lleva, y si en 6 meses quiere
    crecerla, sostenerla o soltarla. Si hay tensión entre ellas —tiempo, plata,
    foco—, que la diga: es la que va a aparecer cada vez que haya que decidir.
27. ¿Hay algo de lo que **no** quiera que se guarde nada en este cerebro?

---

## Qué escribís con las respuestas

Cuando tengas los 6 bloques —y recién ahí, no antes:

1. **`~/cerebro/CLAUDE.md`** → completá la sección `## Perfil`: reemplazá las
   tres líneas marcadas `(pendiente)` por quién es el dueño, sus proyectos
   activos reales y sus metas a 3-6 meses. Borrá el comentario HTML que quedó ahí.

2. **`~/cerebro/05-proyectos/<nombre>/`** → una carpeta por proyecto activo, con
   `overview.md` (meta verificable, contexto, hechos durables, estado actual) y
   `tareas.md`. Un proyecto sin meta verificable no es un proyecto: es un deseo,
   y va a HOT.md.

3. **`~/cerebro/HOT.md`** → máximo 40 líneas, con una sección `## Hilos abiertos`
   (el hook de recordatorios la lee y se la canta al abrir cada sesión).

4. **Una nota por cada criterio propio que haya dicho** en la entrevista, con
   `source: "<su nombre>, sesión YYYY-MM-DD"`. Esto es lo que empieza a diferenciar su
   cerebro del que heredó: acá arranca lo propio.

5. **Una nota con el mapa de sus plataformas** (bloque 3), sin credenciales:
   qué tienda vive dónde, con qué cuenta, qué dominio y qué pasarela. Es la que
   más vas a releer.

6. Guardá todo con **`/orden`** y verificá que quedó commiteado:
   `git -C ~/cerebro log -1`.

## Y avisale de esto

Si algo de lo que dijo **contradice** una nota heredada, no pises la nota vieja:
escribí la suya al lado, anotá la contradicción en las dos y decíselo en una
línea. Dos criterios distintos sobre el mismo tema es información, no un error
— pero un vault que se contradice sin avisar es una trampa para el que lo lea
en tres meses.

Y decile una cosa más, porque es la que hace que el sistema sirva: **el cerebro
solo sabe lo que se le cuenta.** Cada vez que decida algo del negocio, que lo
diga en el chat y cierre con `/orden`. En dos meses, la mitad de lo que le
conteste Claude va a ser criterio propio suyo.
