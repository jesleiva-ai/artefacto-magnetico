# LEEME-PRIMERO — para Claude

Sos Claude Code y acabas de recibir este paquete. Es la ARQUITECTURA de un segundo
cerebro para vender productos digitales low-ticket, entregada por la academia a uno
de sus alumnos. Lee esto entero antes de tocar nada.

## Que es y que no es
- Es: un vault de markdown con su constitucion (CLAUDE.md), plantillas,
  11 comandos, 39 skills de negocio, las herramientas que esas skills usan y los
  guardianes que evitan errores caros (secretos pegados en el chat, gastos sin
  confirmar, afirmaciones sin verificar).
- Trae dos bloques de conocimiento comun, anonimizados:
  · la Fabrica de creativos (68 notas, indice 03-mocs/moc-fabrica-de-creativos.md):
    como se disenan, producen con IA, testean y escalan creativos de Meta. Antes de
    escribir un guion, se lee ese indice.
  · Landings y ofertas (29 notas y 8 lecciones, indice 03-mocs/moc-landings-y-ofertas.md):
    oferta, precio, landing y postcompra. Son las notas que citan las skills.
- No es: el conocimiento del dueno. No viaja ningun dato, cuenta, dominio ni
  alumno de la academia. El resto del contenido lo pone el dueno, trabajando.

## De donde viene este paquete
Viene dentro del Hyperflujo de la academia, en la carpeta `kit-skills/`. Se instala y se
actualiza solo con /actualizar del Hyperflujo: no hay que clonar nada aparte.

## El orden (no se saltea ningun paso; cada uno tiene su criterio de terminado)
1. Requisitos: Python 3 y git. En Windows NO uses `python3`: suele ser un acceso
   directo de la Microsoft Store que no ejecuta nada; ahi el comando es `py -3`.
   Si falta alguno, guia al dueno
   para instalarlo y espera a que te avise.
     Mac:      xcode-select --install   (trae los dos)
     Windows:  winget install -e --id Python.Python.3.12
               winget install -e --id Git.Git
               (despues hay que cerrar y volver a abrir VS Code)
   TERMINADO: `python3 --version` (Windows: `py -3 --version`) y `git --version` responden.
2. Instalar: parado en esta carpeta, `python3 instalar.py` (Windows: `py -3 instalar.py`).
   Lee el veredicto. [error] = no sigas, resolve lo que lista. [ok] u [ok con avisos] = segui.
   TERMINADO: existe la carpeta cerebro en el HOME del dueno con CLAUDE.md adentro.
3. Git con nombre: si `git config --global user.name` esta vacio, pedile al dueno su
   nombre y mail y configuralos. Sin eso /orden no puede guardar.
4. Pedile al dueno que CIERRE este chat y abra VS Code en la carpeta cerebro
   (Archivo -> Abrir carpeta). Las reglas y los guardianes se cargan al abrir la
   sesion, nunca en caliente. El resto se hace en el chat nuevo.

## En el chat nuevo (el mensaje 2 del instructivo lo dispara)
5. Probar que GUARDA antes que cualquier otra cosa: el dueno cuenta algo real,
   /orden, y `git -C ~/cerebro log -1` muestra un commit nuevo. Si no aparece:
   `python3 ~/herramientas/diagnostico-cerebro.py` (Windows: `py -3 ...`) y resolve lo que liste.
6. La ENTREVISTA DE OBJETIVOS (ENTREVISTA-OBJETIVOS.md), conducida por vos, de a un
   bloque por vez. Con eso se completa el Perfil de CLAUDE.md.
7. Traer el contexto que ya existe: el dueno le pide a la app de Claude (o a ChatGPT)
   todo lo que sabe de el y te lo pega. Guardalo crudo en 00-inbox/ y destilalo en
   notas con source: "exportado de la app, FECHA".
8. Obsidian: el dueno abre la carpeta cerebro como boveda (Abrir carpeta como boveda,
   NUNCA "crear nueva boveda").

## Si te pegan un link de claude.ai
Es una pagina privada de otra cuenta: no la vas a poder abrir y no es un problema a
resolver. No la reintentes, no uses curl ni WebFetch contra ella. Todo lo que esa
pagina tiene esta en esta carpeta.
