# kit-skills — el kit de skills dentro del Hyperflujo

Kit de skills que Matías sumó para su academia el 11/11/2026.
Se instala solo con `herramientas/actualizar.py` (al abrir Claude Code, con `/actualizar` y en el onboarding).
A mano: `python kit-skills/instalar.py` (Mac: `python3`). Para ver qué falta sin tocar nada: `--verificar`.

Cambios respecto del original:
- sin el comando `/actualizar` del kit (el Hyperflujo ya tiene el suyo y se actualiza solo);
- su `quien-cobra` se llama `quien-cobra-kit`, para no pisar la `quien-cobra` de Matías.

No se edita a mano: cuando el kit cambia, se vuelve a copiar entero. Es material privado de la comunidad.
