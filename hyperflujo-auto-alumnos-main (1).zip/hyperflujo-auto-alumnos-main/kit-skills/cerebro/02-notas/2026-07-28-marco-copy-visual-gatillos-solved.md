---
type: nota
created: 2026-07-28
tags: [ofertas, meta-ads]
source: "análisis de una landing pública"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["La estrategia brasilera", "Marco de copy y gatillos del molde Solved", "Doctrina Solved para replicar ofertas"]
---

# LA ESTRATEGIA BRASILERA — marco replicable de copy, visuales y gatillos (molde Solved)

## Punto clave
El molde «X Solved(TM)» vende **identidad profesional y tiempo, nunca plata**:
nombre en participio de resultado, cada entregable con nombre propio y (TM),
dolores bautizados como escenas, garantía que repite la promesa y un backend que
se presenta como «completar la compra», no como venta nueva. El AOV se sube con
el backend, no con el front.

DENOMINACIÓN (fijada el 2026-07-28): esto se llama **la estrategia brasilera** —
el operador más visible del registro la aprendió de un mentor brasilero; no es el
origen, es el mejor ejecutor visible. Toda referencia futura a este molde usa
este nombre.

PARA QUÉ SIRVE: cuando se pida "replicá algo de este estilo" o "6 variaciones de
esta oferta", este es el marco de partida. HIPÓTESIS DERIVADAS DE GANADORES
REALES, no teoría de libro. Fuentes: una compra real desglosada (nutritionsolved,
front + backend), 64 títulos de ads del operador líder, un censo de 155 landings
hecho por un tercero (voz ajena, patrones sacados sobre sus datos) y una base
propia de anuncios analizados cuadro a cuadro.

## 1. DOCTRINA DE NAMING (el activo más replicable)
- **El nombre ES la promesa cumplida**: participio de resultado, nunca
  gerundio de esfuerzo. "[Práctica] Solved(TM)" / "[Práctica] Resuelta(TM)"
  / "Sistema [Dolor] SIN IMPROVISAR" (la negación del dolor en el nombre).
  Contraejemplo implícito: "Curso de nutrición" (proceso, no resultado).
- **Todo entregable lleva nombre propio + (TM)**: bonos ("Key Consultation
  Questions Guide(TM)", "Follow-Up Mini System(TM)"), upsells
  ("Ready-to-Use Meal Plans + Recipes System(TM)"). El (TM) convierte PDFs
  genéricos en activos propietarios percibidos. En el censo, el molde (TM)
  firma a las 18 tiendas de la familia A.
- **Jerarquía de sufijos**: front = System/Toolkit; upsells = System/Pack
  (pares del front → pueden anclarse MÁS CAROS); bonos = Guide/Mini System
  (subordinados → refuerzan al front sin canibalizarlo).
- **Números de completitud en el nombre o subtítulo**: 6 Volumes, 360+
  Pages, +40 plans, +300 recipes, 150 protocolos, 900+ recetas, 365
  (número mágico de "año completo": "[X] Ready System 365", "365 coaching",
  "365 actividades" — patrón transversal del registro entero).
- Familias de naming del censo (155 landings): (1) RESULTADO DECLARADO
  "X Solved/Resuelta(TM)"; (2) SISTEMA/MÉTODO + dominio + adjetivo
  aspiracional ("Sistema [Oficio] RENTABLE(TM)", "Método [Disciplina]
  PROFESIONAL(TM)", "[Disciplina] PRO System"); (3) BIBLIOTECA/MEGAPACK/KIT +
  dominio ("La Biblioteca Definitiva de [Hobby]", "Kit Profesional del
  [Oficio]"); (4) franquicia numerada "X Ready: System 365" (el mismo molde
  re-deportado a varios deportes y disciplinas).

## 2. LÉXICO SOLVED (las palabras que se repiten en todo el corpus)
- Verbos de alivio: organize, solve, stop (improvising / guessing /
  searching / starting from zero), reclaim, walk in prepared.
- Sustantivos de sistema: system, structure, volume, template,
  ready-to-use, client-ready, flow, step.
- El tiempo como moneda: "a full year in just 5 minutes", "in minutes",
  "after hours", "hours left planning".
- Identidad profesional: professional, premium, prepared, practice. LA
  PROMESA NUNCA ES PLATA: es verse profesional y recuperar tiempo. (En
  oficios/hobby sí aparece monetización — carpintería, imprimibles — pero en
  práctica profesional el gatillo es ORGULLO.)
- Negaciones de fricción: no subscription, one-time payment, lifetime,
  instant download, nothing to design, works with free Canva.

## 3. FÓRMULAS DE COPY POR BLOQUE (front)
1. **Hero** = [resultado total: "a Full Year of X"] + [ventana mínima: "In
   Just 5 Minutes"] + [prueba de pares que ya cruzaron: "+500
   nutritionists have already stopped improvising"].
2. **CTA** = primera persona + nombre del producto: "I WANT NUTRITION
   SOLVED(TM)" / "SÍ, QUIERO..." (mecánica universal, también en guiones).
3. **Dolores = ESCENAS BAUTIZADAS**: "The Blank Plan Panic", "The
   After-Hours Trap", "The Scattered Folder Problem", "The Client
   Explanation Gap", "The Follow-Up Chaos". Fórmula: The + [contexto] +
   [Panic/Trap/Problem/Gap/Chaos]. Nombrar el dolor lo vuelve DIAGNÓSTICO:
   "¿te reconocés en estas escenas?" → el lector se autodiagnostica y la
   oferta pasa a ser el tratamiento.
4. **BEFORE / WITH en espejo** (5 ✕ vs 5 ✓), cerrando SIEMPRE con la capa
   identitaria: "your practice does not look professional" → "prepared,
   premium, professional".
5. **Bonos**: [Nombre propio(TM)] + [beneficio de 1 línea] + [precio
   unitario tachado $10-15] + FREE + [total $59]. Regla de diseño de
   bonos: cada bono ataca una MICROTAREA distinta del flujo del avatar
   (preguntas / errores / casos / metas / seguimiento) — el conjunto hace
   ver al sistema COMPLETO. Nunca 5 variaciones de lo mismo.
6. **Precio**: stack con ✓ + ancla de valor apilado (4-5×) + razón del
   descuento ("launch price") + "pay in your local currency".
7. **Garantía NOMBRADA que repite la promesa**: "RECLAIM YOUR TIME OR
   YOUR MONEY BACK" — no "garantía de devolución".
8. **Testimonios**: uno por sub-rol del avatar, citando el MECANISMO ("I
   open the system, choose what I need, and prepare much faster").

## 4. FÓRMULAS DE COPY DEL BACKEND (la parte nueva del arsenal)
1. **Continuidad, no venta nueva**: "You've just purchased X. Now
   complete it with..." — el upsell es TERMINAR la compra ya hecha.
2. **Encabezados de estado logístico**: "WELCOME — read this while WE
   SEND YOUR PURCHASE" → "FINAL UPGRADE" → "FINAL STEP" → "LAST CHANCE".
   La urgencia se disfraza de proceso de entrega ("before your final
   access is sent"), no de contador comercial.
3. **Pitch de upsell (idéntico en los 3)**: contexto de lo comprado →
   qué agrega con números (+40, +300, +25) → checklist ✅ de 4-6 →
   remate staccato de 3 líneas cortas ("Explain faster. Support your
   clients better. Make your service feel more complete.") → 🔥
   imperativo suave.
4. **Downsell**: "You just skipped X, but this is your final chance...
   with a special one-time discount" + checklist "Same... Same...
   Same..." — subraya que NO pierde nada del entregable, solo paga menos.
5. **Cierre de flujo**: página done con TODO descargable + link copiable
   + respaldo por email → soporte cero, gratificación inmediata.

## 5. MAPA DE GATILLOS MENTALES (por qué funciona)
- IDENTIDAD PROFESIONAL (el central): de improvisador → profesional
  premium. Orgullo, no avaricia.
- ETIQUETA/DIAGNÓSTICO: dolores bautizados → autodiagnóstico.
- COMPLETITUD: volúmenes numerados + "complete your professional system"
  en el backend + número 365. La incompletitud incomoda; el sistema
  "cierra".
- COMPROMISO/CONSISTENCIA: ya compraste → completá lo tuyo (backend).
- ANCLAJE MULTINIVEL: ancla del front (valor apilado 4-5×) + upsells
  anclados POR ENCIMA del front + escalera descendente 18.7→14.8→9.9→5.9
  (cada "no" recibe una oferta más fácil).
- AVERSIÓN A LA PÉRDIDA: downsells "last chance / final offer".
- PRIVILEGIO DE COMPRADOR: descuentos 78-90% solo post-compra.
- PRUEBA SOCIAL DE PARES con número específico (+500 nutritionists — el
  ROL, no "clientes").
- AUTORIDAD POR ESPECIFICIDAD: 360+ páginas, 33 imágenes, formatos.
- RIESGO CERO RE-ENCUADRADO: la garantía repite la promesa.
- FRICCIÓN CERO: instant/lifetime/no-subscription/Canva gratis.

## 6. VISUALES (lo verificable hoy)
De las capturas de la compra real (backend) + preview del front:
- **Mockup CAJA 3D + spreads impresos abanicados + tablet**: el PDF
  tangibilizado como paquete físico (= patrón visual 4 de la base
  propia). Badge esquinero con el número (+40, +25, +6) en cada mockup.
- **Barra de progreso con íconos de REGALO** que se tildan en verde a
  medida que avanza el flujo — checkout gamificado.
- **Jerarquía de botones**: "Pay Now • [precio]" azul sólido vs "No,
  thanks" gris fantasma — el default visual es comprar.
- Checklists ✅ verdes; una sola columna sin distracciones; banda ROSA
  para "Offer Reserved For: [timer]".
- Paleta del funnel comprado: blanco clínico + verde salud + azul acción.
- La prueba visual del front es el INTERIOR del producto (spreads de
  planes/visuales reales, no stock).
- Del censo (dato duro): el molde A usa EXACTAMENTE 33 imágenes por
  landing — disciplina de assets, no acumulación. Timer y popup de
  regalo al salir vienen de la PLATAFORMA (no copiarlos como "decisión").
- Cruce con la base propia: SIN CARAS, manos + producto; subtítulos
  quemados; tangibilización — los 6 invariantes de
  [[patrones-visuales-y-titulares-ganadores]] aplican intactos.

## 7. TITULARES DE ADS DEL OPERADOR (64 activos, 2026-07-28)
- Fórmula: [emoji inicial] + [imperativo de proceso o resultado-tiempo].
  Dos familias: TIEMPO ("Plan Your Season in 5 Minutes", "Ahorra horas
  cada semana como nutri") y CAOS→SISTEMA ("Your Next Session, Already
  Organized", "Deja de improvisar tus sesiones") + autoridad ("The
  Complete X Coaching System").
- ESPEJO BILINGÜE EXACTO: "Stop Improvising Your Sessions" = "Deja de
  improvisar tus sesiones". Los ganadores se TRADUCEN, no se reinventan
  por mercado.
- Cadencia: tandas nuevas casi diarias durante tres semanas. Duplicados
  "A | A" y ×4 = asset feed/DCO.
- Escuela: BENEFICIO-led (sin descuento en titular), no la escuela
  oferta-led. Coherente: avatar profesional.

## 8. PRICING DEL ECOSISTEMA (censo + compra real)
- Banda universal del front: US$7-27. Modas: $17 y $27. Ningún front
  visible arriba de $27.
- Escalones típicos: $7 (entrada de compra sin pensar) / $9-15 (ES y nichos
  blandos) / $17 (sistemas EN) / $24.99-27 (molde A EN, tope).
- El AOV NO se sube con el front: se sube con el backend (+163% techo,
  +70% real en la compra desglosada). Front barato compra clientes; el
  backend paga el CPA.
- Anclas: front 4-5× valor apilado; upsells anclados > front; bonos $10-17
  c/u sumando $59 (nutrition) o 5×$17 (otra oferta de imprimibles).

## 9. PENDIENTE
Falta la pasada cuadro a cuadro de los creativos del operador: la Biblioteca de
Anuncios no renderiza sin sesión iniciada en el navegador. Muestra propuesta: 4
nutrition EN + 3 ES (nutri/kine/psico) + 2 pádel + 2 running + los formatos
imagen que aparezcan.
