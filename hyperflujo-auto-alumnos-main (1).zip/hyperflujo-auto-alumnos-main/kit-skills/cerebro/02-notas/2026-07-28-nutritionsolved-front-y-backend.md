---
type: nota
created: 2026-07-28
tags: [ofertas, productos-digitales]
source: "análisis de una landing pública"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Rayo-X: nutritionsolved (front + backend)", "La estrategia brasilera en accion"]
---

# Rayo-X — nutritionsolved: FRONT + BACKEND completo (2026-07-28)

El ejemplo madre de **la estrategia brasilera** (así se la conoce: un molde de
fábrica multi-nicho que viene de mentores brasileros). Es la referencia con más
verdad de campo del registro: se COMPRÓ de verdad y se desglosó el backend paso a
paso (capturas de los 5 pasos post-compra + página final + entrega). Operador: un
anunciante de productos para profesionales con varias tiendas, formado en Brasil.
Estructura ganadora y la más escalada de ese operador.
Fuentes: captura de la landing, capturas del post-compra de la compra real,
Biblioteca de Anuncios (64 anuncios activos ese día) y un censo de terceros de
~155 tiendas de la misma plataforma (voz ajena, foto ruidosa).

## Punto clave
Dos máquinas en serie: un FRONT "[Práctica] Solved(TM)" a US$27 que vende un
sistema-de-volúmenes para profesionales, y un BACKEND de 3 upsells one-click
con 2 downsells que puede sumar hasta +US$43 (techo AOV ~US$70, +163%).
En la compra real se aceptó solo el primer upsell y el ticket igual subió +70%
(US$26,6 → US$45,3). El molde corre idéntico en 11 tiendas x 2 idiomas del mismo
operador (fábrica confirmada por censo: 33 imágenes exactas por tienda).

## FRONT — estructura sección por sección (captura 2026-07-28)
1. Barra trust: "Instant Download · No Subscription · Lifetime Access".
2. Hero: "Organize a Full Year of Nutrition Sessions In Just 5 Minutes" +
   prueba (+500 nutritionists "stopped improvising") + CTA en primera
   persona "I WANT NUTRITION SOLVED(TM)" + badges (100% PDF · 6 Volumes · 5
   Bonuses · Educational Visuals · 7-Day Guarantee).
3. Stats: 6 volúmenes / 5 bonos / 360+ páginas / US$27 launch price.
4. Transformación identitaria: "From overwhelmed nutritionist to organized
   professional" + tabla BEFORE (5 ✕) vs WITH (5 ✓).
5. ESCENAS ESPEJO BAUTIZADAS con nombre propio: "The Blank Plan Panic",
   "The After-Hours Trap", "The Scattered Folder Problem", "The Client
   Explanation Gap", "The Follow-Up Chaos" — el dolor con marca registrada.
6. Inventario por VOLÚMENES numerados (V1 Consultation Foundations → V6
   Professional Practice), una promesa por volumen.
7. Preview visual de entregables (visuals: plato saludable, porciones,
   índice glucémico, etiquetas...).
8. 5 bonos valorizados UNO A UNO ($10/$12/$15/$10/$12 = US$59 "included
   free today") — escuela grilla-de-bonos.
9. Bloque precio: stack con ✓ + ancla US$129 → US$27 (4,8x) + "Pay in your
   local currency".
10. Garantía NOMBRADA: "RECLAIM YOUR TIME OR YOUR MONEY BACK" (7 días).
11. 3 testimonios por sub-rol (private practice / clinical / independent) +
    4,9/5 +500.
12. Bloque "About/misión" (1 párrafo, tono empatía profesional).
13. FAQ (5) + cierre con precio + popup de compra reciente ("Emily R. —
    London, 2 minutes ago").
Del censo de terceros: el timer y el popup de regalo al salir vienen DE LA
PLATAFORMA de la tienda (los ~155 sitios los tienen) — no leerlos como decisión
de copy del vendedor.

## BACKEND — la cascada post-compra (capturas de la compra real)
Contexto técnico: pago ya autorizado → cada paso es UN CLICK ("Pay Now"),
sin re-ingresar tarjeta. Barra de progreso gamificada con regalos arriba.
Retención: "Do not close this page or go back, as you risk being charged
twice" + "Offer Reserved For: 09:36" (timer ~10 min).
- U1 "Ready-to-Use Meal Plans + Recipes System(TM)" — → ~US$18,7 (79% OFF,
  cobrado en moneda local). Ángulo: MÁS CONTENIDO listo ("you get complete plans
  — not just the structure"). Encabezado: "WELCOME — READ THIS WHILE WE
  SEND YOUR PURCHASE". Copy de continuidad: "You've just purchased X. Now
  complete it with...". [ACEPTADO en la compra real]
- U2 "Essential Editable Nutrition Templates(TM)" — → ~US$14,8 (78%).
  Ángulo: ORGANIZAR EL WORKFLOW interno. "FINAL UPGRADE — ORGANIZE YOUR
  PRACTICE FROM THE INSIDE".
- DS2 (si salta U2): MISMO producto → ~US$9,9 (86%). "LAST CHANCE — DON'T
  LEAVE YOUR WORKFLOW DISORGANIZED... You just skipped X, but this is your
  final chance".
- U3 "Client Education Visuals Pack" — → ~US$9,9 (83%). Ángulo: MATERIAL
  PARA ENTREGAR al paciente. "FINAL STEP — COMPLETE YOUR PROFESSIONAL
  SYSTEM".
- DS3 (si salta U3): MISMO → ~US$5,9 (90%). "LAST CHANCE — DON'T MISS...".
- DONE: multi-descarga inmediata de TODO (producto + 5 bonos + upsell),
  botón "Copiar enlace de descarga", respaldo por email — soporte cero.
Lógica de la cascada: los 3 upsells completan TRES DIMENSIONES DISTINTAS
del mismo trabajo (más contenido / flujo interno / entrega al cliente).
No es "más de lo mismo": es el sistema completándose. Naming (TM) en todo.

## Estrategia de pricing (análisis completo)
- Front US$27 con ancla interna $129 (valor apilado del stack, 4,8x) + 5
  bonos $59. Precio "launch" como justificación del descuento.
- Upsells anclados MÁS CAROS QUE EL FRONT (US$58-87 tachados): el
  comprador percibe acceso privilegiado post-compra, no un "extra barato".
- Escalera DESCENDENTE de precios en el backend: 18,7 → 14,8 → 9,9 →
  9,9 → 5,9. Fricción decreciente: cada "no" recibe una oferta más fácil.
- Downsell = mismo producto con 7-10 puntos más de descuento, sin cambiar
  el entregable.
- AOV: front 26,6 → techo 70 (+163%). Caso real (tomó 1 de 3): 45,3
  (+70%). El backend es donde se paga el CPA que el front solo no banca.
- Moneda localizada en el cobro, con precio ancla en USD.
- Discrepancia anotada: el censo de terceros lista nutritionsolved a US$10 —
  la compra real dice US$27 front. La compra manda (el censo es foto ruidosa).

## Ads del operador (Biblioteca de Anuncios, 2026-07-28, 64 activos, USD)
- FÁBRICA MULTI-NICHO: Nutrition/Padel/Running/Boxing/Psychology/
  Kinesiology "Solved" (EN) + Nutrición/Kinesiología/Psicología/
  Estimulación Temprana "Resuelta" (ES; por ejemplo kinesiologiaresuelta).
  11 tiendas, mismo archivo maestro.
- Titulares BENEFICIO-led con emoji INICIAL + imperativo de proceso:
  "Stop Improvising Your Sessions" = "Deja de improvisar tus sesiones" —
  ESPEJO BILINGÜE EXACTO: traducen ganadores, no inventan por mercado.
- Dos familias de ángulo: TIEMPO ("Plan Your Season in 5 Minutes", "Ahorra
  horas cada semana como nutri") y CAOS→SISTEMA ("Your Next Session,
  Already Organized", "Toda tu práctica organizada en un solo lugar") +
  autoridad ("The Complete X Coaching System").
- Cadencia de fábrica: tandas nuevas el 9, 10, 13, 14, 20, 21, 23, 24, 25,
  27 y 28 de julio — shipping casi diario.
- Títulos duplicados "A | A" y "A x4" = asset feed / DCO con variantes.
- Pendiente: pasada cuadro a cuadro de los creativos.

## ENTREGA DEL PRODUCTO (capturada 2026-07-28 — replicable)
- La entrega es UNA PÁGINA DE DESCARGAS PERMANENTE con link UUID
  (`/descargas/<uuid>`): sin login, sin cuenta, sin plataforma de cursos, sin
  app. "Guarda este enlace para acceder a tus productos cuando quieras."
- Los 7 PDFs juntos (producto + 5 bonos + el upsell comprado), cada uno
  con botón Descargar individual.
- Los títulos de los bonos en la entrega RE-VENDEN: nombre propio (TM)
  completo con beneficio adentro ("Common Mistakes That Disorganize a
  Nutrition Treatment(TM)") — hasta la entrega refuerza el valor.
- Respaldo triple visto en el flujo: página done con multi-descarga +
  botón copiar enlace + email. Soporte CERO.
- Trade-off aceptado: el link es compartible (pirateable) — para PDFs de
  $27 la fricción de un login cuesta más que la piratería. Coherencia
  total con "instant download / lifetime access / no subscription".
- La página `/descargas/` la genera la plataforma de la tienda: es replicable
  tal cual.

## Avatar y promesa
Profesional de práctica (nutricionista) EN/US, ahogado en preparación
manual, quiere verse premium ante clientes. Promesa: un año de sesiones
organizado en 5 minutos. Mecanismo: sistema de 6 volúmenes + visuals.

## Qué robar (estructura) vs qué mejorar (criterio propio)
Robar: TODO el backend (la máquina de AOV: 3 dimensiones + downsells +
one-click + done multi-descarga); bautizar los dolores con nombre propio;
inventario por volúmenes numerados; garantía nombrada; anclar upsells por
encima del front; naming (TM). Mejorar: el "risk being charged twice" es
retención gris que Meta puede castigar — la retención se hace con la barra de
progreso y el timer, sin amenaza; validar cada nicho nuevo con regla de 3 antes
de clonar el molde; el front es sobrio en urgencia (solo launch price) — el
backend concentra la presión: respetar esa repartición.
