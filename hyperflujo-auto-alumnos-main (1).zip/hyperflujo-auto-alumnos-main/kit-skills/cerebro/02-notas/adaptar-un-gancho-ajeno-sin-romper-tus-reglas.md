---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un gancho ajeno que rompe una regla tuya no se descarta: se conserva la tensión y se cambia la superficie"]
---

# Un gancho ajeno que rompe una regla tuya no se descarta: se conserva la tensión y se cambia la superficie

## Punto clave
Un gancho ajeno que rompe una regla tuya no se descarta: se conserva la tensión y se cambia la superficie. Tensión sí, superficie no.

## La regla
Los ganchos que escalan en otros mercados suelen chocar con las reglas de tu marca (precio en la voz, testimonios en
primera persona, promesas de resultado en días, comparar contra la competencia por nombre). Se separan dos capas:
- **La tensión psicológica** (la objeción de frente, el antes y el después, la ventana que se cierra, la sorpresa).
  Esa se conserva.
- **La superficie** que choca con la regla. Esa se cambia.

## Ejemplos (productos inventados)
| Gancho ajeno | Regla que rompe | Cómo queda |
|---|---|---|
| «50 % termina hoy» | Sin precio ni descuento en la voz; sin urgencia ficticia | «¿El pan casero necesita 12 horas? Casi seguro que no»: mito desarmado con una muestra real del contenido |
| Una clienta contando en primera persona | Sin testimonios inventados | Narrador que le habla al comprador: «Todo el que quiera hornear los domingos tendría que ver esto» |
| «La app X te hace perder plata; esta no» | No comparar con la competencia por nombre | El contraste es contra el **hábito**, no contra una marca: «anotar gastos sueltos en el celular contra una planilla que te ordena el mes» |
| «Hablá inglés fluido en 7 días» | No prometer resultados en días | «Lo que tenés que saber decir antes de subirte al avión» |

## Por qué
La tensión es lo que frena el scroll y mueve a la acción; la superficie es intercambiable. Descartar el gancho entero
tira lo que funcionaba en el mercado.

## Cómo aplicarlo
1. Antes de escribir sobre un gancho ajeno, pasalo por una tabla de tres columnas: gancho · regla que rompe · versión
   tuya.
2. Chequeo automático del texto final: buscar las palabras prohibidas de tu marca (precio, descuento, garantía si no
   la tenés, plazos de resultado, nombres de la competencia, primera persona de cliente) y que el cierre diga lo que tiene que decir (por ejemplo «acceso
   inmediato»).
3. Nunca compares contra un competidor con nombre: compará contra el hábito o el intento fallido que tu producto
   reemplaza.

## Error típico
Traducir el gancho literal. Lo que viaja es la tensión, no las palabras.

Relacionadas: [[el-gancho-se-elige-por-el-mecanismo-que-activa]] · [[reglas-de-copy-y-lo-que-meta-rechaza]]
