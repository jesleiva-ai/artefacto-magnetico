---
type: nota
created: 2026-07-28
tags: [ofertas, meta-ads]
source: "referencia de tercero — espionaje de los anuncios activos de un anunciante de recetarios, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Los angulos ocupados se leen en los anuncios", "Foros dicen lo que dicen, anuncios dicen lo que compran"]
---

# Qué ángulos están ocupados no se deduce de la landing: se lee en los anuncios

## Punto clave
**Los foros y las reseñas dicen lo que la gente dice; los anuncios ganadores
dicen lo que la gente compra. No son la misma lista.** En la investigación de un
recetario de air fryer se clasificaron dos ángulos como libres mirando solo la
landing, y los dos estaban ocupados: uno era el ganador corriendo hacía 3,5
meses. Además apareció un dolor —**limpieza**— que no existía en ninguna fuente
de voz de mercado y que el líder venía explotando hacía dos meses.

## Detalle
- La landing dice **qué vende la oferta**. Los anuncios dicen **qué compra el
  mercado**. Sin la segunda capa, la tabla de ángulos sale mal a la mitad.
- Nadie escribe en un foro "odio limpiar la cesta de la freidora", pero lo paga.
  El dolor que no se verbaliza solo aparece en lo que el mercado premia con
  dinero.
- Los **días activos** de cada anuncio funcionan como fecha de ocupación: un
  ángulo con 3,5 meses está probado y defendido; uno de esta semana es un test.
- Lo que el copy del ganador responde también es dato: si gasta líneas en "sin
  suscripciones, sin historias raras, descarga directa", esas **son** las
  objeciones de fricción del nicho, aunque ningún cliente las escriba en
  ninguna parte.
- Un mecanismo puede estar **semi-ocupado**: el ganador del recetario ya decía
  "temperaturas y tiempos exactos", pero como bullet suelto, sin nombre y sin
  explicar por qué lo gratis falla. Ahí el hueco no es descubrirlo: es
  apropiárselo.
- Lo que está **en test esta semana** anticipa hacia dónde migra el nicho (en
  recetas: de variedad a síntoma). Se vigila, no se sigue: dos tests no le ganan
  a un ganador de meses.

## Aplicación
En toda investigación de mercado, después de las fuentes de voz y **antes** de
clasificar ángulos como libres u ocupados, mirar los anuncios activos del
operador y de la categoría. Incorporado como paso 2b obligatorio de la skill
`/investigar-mercado`.
