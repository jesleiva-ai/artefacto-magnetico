---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Auditor de robots: los robots también son hipótesis"]
---

# Auditor de robots: los robots también son hipótesis

## Punto clave
Auditor de robots: los robots también son hipótesis. Los robots tomaban muchas decisiones por día y **nadie medía si acertaban.** Cada regla ("subí el tope si…", "cortá si…") es una hipótesis. El auditor las juzga con lo que pasó después y frena sola la que viene errando.

Los robots tomaban muchas decisiones por día y **nadie medía si acertaban.** Cada regla ("subí el tope si…", "cortá si…") es una hipótesis. El auditor las juzga con lo que pasó después y frena sola la que viene errando.

## Qué juzga y cómo

**Corre:** cada hora. **Solo lectura, cero llamadas a Meta.** Usa:
- las fotos que deja el robot de escala cada 30 min (gasto y cobrado acumulados por campaña);
- las fotos de los salvavidas;
- las decisiones de cada robot (subas, bajas, frenos, techos, picos, duplicaciones, palancas del guardia, disparos del salvavidas).

**Una decisión se juzga así:**
- **Suba acertada** ⇔ el ROAS cobrado de las **3 h siguientes** llega a la meta del mercado.
- **Corte acertado** ⇔ el ROAS cobrado de las **3 h anteriores** estaba bajo la meta. (¿Cortó lo que venía mal?)
- Una suba que en las 3 h siguientes no movió un gasto mínimo queda **"sin efecto"** (no movió plata). Un corte sin gasto antes queda **"sin muestra"**. Ninguna cuenta para el %.

**El serial se calcula bien:** entre dos fotos se suman los incrementos; si el acumulado baja, la cuenta cambió de día y se toma desde cero.

## Decisiones independientes (el error que tuvimos)

La primera medición daba unos números lindos de "cortes aciertan 72-94 %, subas 25-38 %". Estaban **inflados**: muchas decisiones en la misma campaña y la misma ventana de 3 h miden **las mismas ventas**. de cada cuatro decisiones juzgadas, solo una era independiente.

Ahora cuenta **una decisión por campaña, regla y ventana**, con un mínimo de 4 para opinar.

## Cuándo una regla pasa a "a revisar"

Para cada combinación **robot · regla · mercado**, con 7 días:

- **Subas:** "a revisar" si acierta menos del 60 % con ≥ 4 decisiones **y** además deja un ROAS por debajo del equilibrio estimado (1,2); o si con ≥ 3 decisiones y gasto relevante dio ROAS < 1. Si acierta poco pero deja ROAS sobre el equilibrio, es **"rentable"**: no llega a la meta pero deja plata, no se frena.
- **Cortes:** "a revisar" si acierta menos del 60 %, o si con ≥ 3 decisiones y gasto relevante cortaba algo que venía **por encima** de la meta.
- **"Confiable"** con muestra suficiente; **"poca muestra"** si no.

## El freno automático (aprendizaje)

Antes de ejecutar una decisión, cada robot le pregunta a un módulo chico:

- **Suba** de una regla "a revisar" en ese mercado → **no se ejecuta**.
- **Corte** de una regla "a revisar" → solo se ejecuta si las últimas 3 h de esa campaña vienen **de verdad** bajo la meta. Sin datos, se ejecuta como siempre.
- Lo frenado queda anotado como **sombra** y el auditor la juzga igual: si la decisión frenada habría acertado o dejado plata, la regla **se rehabilita sola**.
- Como los errores viejos salen de la ventana de 7 días, ninguna regla queda frenada para siempre.

**Lo que nunca frena:** el freno de mano, el disparo del salvavidas, techos, arranques, resets y el freno de CPA. Son reglas de seguridad o decisiones del dueño.

**Falla abierto:** si no hay resumen, si el resumen tiene más de 36 h, o si el aprendizaje está apagado en la configuración, el robot hace lo de siempre. Un auditor roto **no puede** paralizar la escala.

## Ajustes manuales con vencimiento

Encima del freno automático hay una herramienta para que el operador (humano o IA con autonomía) ponga un **frenar** o **liberar** a una regla en un mercado:

- con motivo obligatorio;
- con **vencimiento** de 1 a 7 días (nada queda puesto para siempre);
- anotado en una bitácora;
- y un comando `medir` que compara el ROAS y el resultado del mercado antes y después de cada ajuste.

No puede tocar reglas de seguridad, ni escalas por dentro, ni topes o presupuestos directamente.

## Lo que midió

- Los **cortes** de los robots aciertan bastante; las **subas** pierden en la mayoría de los mercados. El freno de mano acertó ~75 %; los cortes del guardia, casi todos; sus subas, ninguna en la primera semana.
- La regla "de la tarde" corta muy bien en un mercado y muy mal en otros dos: **la misma regla no sirve igual en todos los mercados**, por eso el estado es por mercado.
- **"Sin efecto" domina:** la mayoría de las subas de tope no mueven ni un gasto mínimo en 3 h. Señal de que en esas horas lo que frena no es la regla sino el tope o el mercado.

## La autonomía que habilita

Con el auditor midiendo, el dueño dio autonomía para corregir los robots (subas, cortes, frenos, topes) **sin pedir permiso**, con tres condiciones: anotar cada cambio con su motivo, medir después si sirvió, y revertirlo si no. La autonomía **no** reemplaza las reglas duras (no tocar escalas por dentro, techo fijo, modo del negocio).

**Pendiente honesto:** el umbral de equilibrio de 1,2 es una estimación; se va a recalibrar cuando esté medida la ganancia neta con comisiones. Y una revisión diaria automática por IA del auditor quedó sin instalar porque requería un agente con permisos amplios: no se buscó la vuelta.

Esqueleto del módulo: esqueletos/auditor_y_freno_de_reglas.py (`~/herramientas/esqueletos-robots/auditor_y_freno_de_reglas.py`).
