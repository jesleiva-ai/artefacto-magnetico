---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cada modelo de video tiene su trampa conocida: revisá la hoja de cuadros de TODA toma, porque ~1 de cada 8 sale mal"]
---

# Cada modelo de video tiene su trampa conocida: revisá la hoja de cuadros de TODA toma, porque ~1 de cada 8 sale mal

## Punto clave
Cada modelo de video tiene su trampa conocida: revisá la hoja de cuadros de TODA toma, porque ~1 de cada 8 sale mal. Veo, Kling, Wan, MiniMax, modelos que hablan, modelos de imagen.

## La regla
Ninguna toma generada entra al montaje sin mirar su hoja de cuadros (o una tira de 6-12 cuadros). Lo que delata a la
IA se ve en un cuadro, no en la miniatura.

## Trampas medidas, por modelo
**Veo 3.1 (Fast y Quality)**
- Bloquea por «seguridad de contenido» escenas con jeringas, objetos peligrosos en manos, espuma roja, personajes en un
  horno, ciertas escenas con personas reales en primer plano. Si una herramienta reusa la imagen de inicio guardada,
  **borrá también la imagen** antes de regenerar: cambiar solo el prompt del video no alcanza.
- Mete **franjas negras** dentro del 9:16 y a veces **subtítulos o papeles con texto**: OCR sobre la mitad baja y
  recorte automático.
- Con imagen de referencia del personaje, lo deja posando (~30 % menos de movimiento).
- Copia la luz de la foto de referencia en todas las escenas (un retrato de estudio da un UGC «de estudio»).
- La pantalla de un dispositivo con texto se deforma después de ~5 s.
- En una prueba barata imagen → video, «saltó» y teletransportó a las personas: no sirvió.

**Kling**
- Objetos que van marcha atrás, cuerpos que cambian de forma con mucho movimiento, «magia» que tapa caras, cámara que
  gira al final. Arreglo: cámara fija, dirección explícita, «never in front of faces», o recortar antes de que se
  deforme.
- Pedirle «una persona usando una guía» inventa una portada con un nombre ajeno. Nunca le pidas el producto.
- No muestra rayos ni un imán levantando objetos (para eso rindieron otros modelos).
- Algunas plataformas piden declinar un preset recomendado para que la tarea no rebote.

**Wan 2.6**
- Acepta imagen + audio y hace el playback (desfase medido 0-20 ms), pero deforma el plano después de ~3,5 s
  (aparecen otras personas). Acotá la duración por toma.
- Acepta audio desde una URL pública de descarga directa.

**MiniMax H3**
- En tomas de 8 s con frase corta habla ~5 s y después queda mirando.
- Toma el prompt al pie de la letra: una regla general («solo humanos o robots») aparece en todas las escenas. Nombrá
  solo lo que va en esa toma + «do not add other characters».
- Una descripción fija del personaje solo entra si la toma lo nombra: con «he/she» cambia de cara. Nombralo siempre.
- Colores que se van (un logo verde salió rosado): describí el material («drawn purely with glowing emerald
  lines of light, flat neon»). Un recoloreo con ffmpeg arregla sin regenerar.
- Monitores de bolsa o tableros traen números falsos: «blank screen», «only lines, no digits».

**Modelos que hablan (Seedance, Omni, Veo con diálogo)**
- Un clip habló palabras que no existen, incluido el nombre del producto: 45 % de coincidencia con el guion. El modelo
  decide más que el prompt: probá la frase con el nombre del producto en 2-3 modelos con un clip de 5 s.
- Regalan 1-1,6 s de silencio antes de la primera palabra: recortalo.
- A veces repiten la última frase o agregan una palabra al final: transcribir y recortar.
- Pasarle la voz correcta como referencia de audio no funcionó: la ignora.

**Modelos de imagen**
- Meten personajes de películas conocidas, logos, carteles en inglés. Pedí diseños originales y «no text, no logos».
- Un filtro de seguridad frenó un prompt que describía rasgos físicos sensibles de una persona: describí el personaje por ropa, luz y acción.

## Cómo aplicarlo
Hoja de cuadros por toma → anotar defecto → regenerar solo esa toma. Llevá un registro de trampas por modelo y leelo
antes de cada tanda.

Relacionadas: [[herramientas-y-para-que-sirve-cada-una]] · [[prompts-de-imagen-decir-que-va-no-que-no]] · [[qa-automatico-de-piezas-con-ia]]
