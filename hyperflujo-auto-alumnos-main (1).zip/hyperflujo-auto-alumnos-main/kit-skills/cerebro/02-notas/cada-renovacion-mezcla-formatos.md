---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cada renovación de creativos mezcla muchos formatos: un porcentaje de lo que ya gana y el resto, formatos nuevos"]
---

# Cada renovación de creativos mezcla muchos formatos: un porcentaje de lo que ya gana y el resto, formatos nuevos

## Punto clave
Cada renovación de creativos mezcla muchos formatos: un porcentaje de lo que ya gana y el resto, formatos nuevos. Mismo ángulo en 3 formatos por conjunto; catálogo de formatos.

## La regla
Cuando se renuevan creativos no alcanza con tres variantes del mismo montaje. **En cada conjunto de testeo, los 3
anuncios son el MISMO ángulo en 3 formatos distintos.** Si el conjunto itera o traduce un ganador, 1 de los 3 conserva
el formato del ganador y los otros 2 van en formatos nuevos. No se repiten combinaciones en el día, y se priorizan
los formatos que ese mercado no probó en los últimos 3 días.

## El catálogo de formatos (cada anuncio lleva su código en el registro)
| Código | Qué es |
|---|---|
| VOZ+BROLL | Voz en off sobre tomas literales, subtítulo palabra a palabra (el formato por defecto) |
| UGC | Persona a cámara, grabada con celular (real o generada, ver [[estilo-ugc]]) |
| PODCAST | Dos personas conversando en un set de podcast; uno pregunta lo que pregunta el comprador |
| APP | Grabación real del producto o de la app de entrega dentro de un celular, con voz en off |
| VENTA | Venta directa: qué incluye, cuántos bonos, «lo que cuesta una salida al cine» (sin cifra) |
| SPLIT | Pantalla dividida: el problema arriba, la solución abajo, o reacción + contenido |
| REACCION | Alguien reacciona a un contenido o a un comentario |
| LISTA | «3 señales», «5 errores», top 3 |
| POV | «POV: vas a… y…» en primera persona visual |
| DEMO | La transformación o el resultado pasando en cámara |
| CALLE | Pregunta en la calle, entrevista corta |
| ESTATICO | Imagen fija 4:5 / 9:16 (ver [[los-estaticos-que-ganan]]) |
| SIN VOZ | Texto grande + música sobre la demostración; de los formatos más longevos y se traduce sin locutar |

## Por qué
- Los ganadores se cansan (un mercado lo hizo en un mes, otro al siguiente) y casi todo lo testeado tenía el mismo
  formato de voz en off con tomas: cuando el ganador caía, no había relevo de otro tipo.
- Los que más escalan en la Biblioteca de Anuncios corren **un sistema**, no un ganador: un esqueleto con cientos de
  aperturas, una misma imagen en 16 composiciones a la vez, el mismo guion en cinco idiomas el mismo día, y estáticos
  que pesan entre un 12 % y un 35 % del inventario. Una marca que solo hace video deja ese inventario sin probar.
- Una prueba de tres formatos nuevos lado a lado (UGC, review de la app, venta directa): el de la app dio el mejor
  ROAS con muestra chica; el UGC con IA, cero. Sin probarlos juntos no se sabe.

## Cómo aplicarlo
- Planificá la tanda como una grilla ángulo × formato, no como una lista de videos.
- En el análisis semanal medí también **por formato**, no solo por ángulo.
- Cada pieza que querés medir sola va en su propio conjunto: en un conjunto con varias, Meta le da casi todo el gasto
  a una y las demás quedan sin dato.

## Error típico
Llamar «diversidad» a cambiar la música o el color. Para Meta es el mismo anuncio. La diversidad real es de formato
y de ángulo.

Relacionadas: [[receta-medida-heroe-traducido-y-muestra-real]] · [[los-anuncios-no-se-fatigan-mueren-sin-arrancar]]
