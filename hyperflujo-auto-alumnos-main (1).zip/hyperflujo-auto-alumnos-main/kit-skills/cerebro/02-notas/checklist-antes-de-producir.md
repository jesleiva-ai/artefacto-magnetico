---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Todo guion pasa dieciséis preguntas antes de gastar un crédito: corregir texto es gratis, regenerar no"]
---

# Todo guion pasa dieciséis preguntas antes de gastar un crédito: corregir texto es gratis, regenerar no

## Punto clave
Todo guion pasa dieciséis preguntas antes de gastar un crédito: corregir texto es gratis, regenerar no. Las 16 preguntas antes de gastar un crédito.

## La regla
El checklist se corre sobre cada guion **antes de locutar o generar tomas**, y se anota el resultado en el plan de
la tanda. Un guion que falla tres o más preguntas se reescribe entero.

## Las preguntas
**Gancho (0-3 s)**
1. ¿El cuadro 0 muestra algo imposible de predecir y que no es el producto?
2. ¿La primera frase tiene un número, una hora, un nombre o una pregunta sin contestar?
3. ¿El texto del gancho se lee entero en 3 s (una idea, letra grande)?

**Cuerpo**
4. ¿El espectador se reconoce antes del segundo 8 (síntoma, escena o identidad)?
5. ¿Hay un culpable externo o una causa reencuadrada?
6. ¿El producto llega con un mecanismo o un dato que explica por qué esta vez funciona?
7. ¿Hay prueba: demostración, número de clientes, autoridad o muestra real?
8. ¿Habla una persona (narrador, experto, cliente real) y no «la marca»?

**Cierre**
9. ¿La oferta tiene un regalo o una cantidad (bonos, recetas, días) y el riesgo está resuelto (garantía si la hay,
   acceso inmediato)?
10. ¿El CTA es imperativo y nombra el producto o el botón («Tocá el botón y empezá hoy»)?

**Verdad y reglas**
11. ¿Cada dato, receta, técnica o cifra que nombra el guion **está en el entregable**? Se busca en el texto del PDF o
    del curso antes de grabar. Si no está, se cambia el gancho o se suma el contenido (bono) antes de prender.
12. ¿Pasa las reglas de la marca (lo que no se dice nunca, el registro, el dialecto del país)?

**Imagen y producto**
13. ¿Donde se presenta el producto se ven los mockups y las muestras **reales**, nunca un producto dibujado por la IA?
14. ¿Cada cifra impresa en la imagen está cotejada con la landing de ese idioma **antes** de generar?
15. Si la pieza la genera una IA de imagen, ¿el prompt fija el texto palabra por palabra y dice qué va en cada hueco
    (en vez de solo prohibir)?

**Precio**
16. ¿El anuncio está **sin precio en todos lados**: imagen, placas, cierre, subtítulos, voz, texto principal, título y
    descripción? Control: OCR de la pieza + lectura del copy buscando símbolos de moneda y la palabra «precio».

## Por qué (lo que ya costó)
- Un lote de estáticos salió con «70 % OFF» y un rango de datos escrito de memoria; la landing decía otra cosa.
- Con el prompt automático de un clonador de anuncios, **7 de 8 imágenes** salieron con precio inventado, «envío
  gratis» en un producto digital o productos que no existen.
- Una tanda entera prometía una receta que el PDF no traía: se descubrió horas después, al guionar los videos.
  Se resolvió con un bono nuevo antes de prender.

## Cómo aplicarlo
- Que lo corra la máquina: un script lee el guion y marca lo automático (números, palabras prohibidas, moneda), y un
  agente contesta el resto por escrito.
- Las preguntas 11 y 14 se contestan **abriendo la fuente**, no de memoria.

Relacionadas: [[el-creativo-escalado-tiene-seis-bloques]] · [[reglas-de-copy-y-lo-que-meta-rechaza]] ·
[[el-producto-en-pantalla-es-siempre-el-real]]
