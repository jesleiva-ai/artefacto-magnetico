---
type: nota
created: 2026-07-25
tags: [ofertas, meta-ads]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Clarity + embudo de Meta: dónde se fuga el tráfico"]
---

# El punto de fuga se encuentra con Clarity + las métricas de embudo, no adivinando

## Punto clave
Sistema de diagnóstico: Microsoft Clarity instalado desde el día 1 en toda landing; cuando la conversión no acompaña, exportar el CSV de Clarity y pasárselo al proyecto de Claude para que identifique los puntos de fuga. En paralelo, las métricas de embudo de Meta (clic → agregar carrito → iniciar pago → compra) dicen EN QUÉ ESCALÓN se cae la gente.

## Detalle
- Lectura del embudo: llega tráfico pero no agrega al carrito → Meta cumplió, el problema es la landing. Agrega carrito pero muere en el pago (caso en vivo: 116 carritos → 56 pagos iniciados → 15 compras) → punto de fuga en el checkout (revisar pasarela; ese día era una pantalla en blanco de Mercado Pago vía anuncio — "no es normal, contactá soporte").
- El precio rara vez es el culpable si ya hicieron clic: "si la persona hizo clic, ya vio el precio."
- Toda iteración post-diagnóstico respeta 48h mínimas sin tocar la campaña — y una variable a la vez.

## Aplicación
Conversión baja → 1) embudo de Meta para ubicar el escalón; 2) Clarity (CSV a Claude) para el detalle del comportamiento; 3) iterar UNA variable y esperar 48-72h. Nunca "siento que es la landing": el dato existe.
