---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El copy y el video pueden cargar ángulos distintos, y eso convierte la tanda en una grilla"]
---

# El copy y el video pueden cargar ángulos distintos, y eso convierte la tanda en una grilla

## Punto clave
El copy y el video pueden cargar ángulos distintos, y eso convierte la tanda en una grilla. La grilla copy × video y cuatro arquetipos de guion.

## La regla
El **copy** del anuncio carga el ángulo específico; el **video** carga el beneficio general. Un video sirve para varios
copys y un copy para varios videos: la tanda deja de ser «un ángulo = una producción».

## Por qué (lo medido)
En los 4 ganadores de un mercado (decenas de anuncios corridos, cuatro videos únicos sobre el umbral), el guion
hablado nunca decía lo que decía el copy. Ejemplo reconstruido sobre un producto inventado (curso de cocina):
| Copy | Voz |
|---|---|
| «Elegir mal el corte arruina toda la preparación» | «¿Te gustaría cocinar como en un restaurante, en tu casa?» |
| «Semanas probando y sigue sin sabor: el problema son las especias» | «¿Es difícil? Respuesta honesta: no, si…» |

Los ángulos que ya ganaron **en el copy** pero nunca se dijeron en voz son **guiones listos** para la próxima tanda.

## Los cuatro arquetipos de guion que ganaron en ese mercado
1. **Creencia limitante** (el de más volumen): pregunta-deseo, confesión, «hasta que descubrí…», prueba social, CTA.
2. **Objeción frontal** (mejor CTR): pregunta que nombra el miedo, «respuesta honesta:», reencuadre («no es riesgoso
   SI…»), el proceso enumerado. Cierra sin CTA hablado.
3. **Defecto señalado** (mejor ROAS y mejor tasa de gancho): abre marcando un defecto visible con un círculo rojo, lo
   diagnostica, nombra el mecanismo y cierra contra el método de prueba y error. Es el más lento (~130 palabras por
   minuto contra ~160) y necesita metraje **del defecto**: con una toma impecable, el círculo apunta a algo perfecto y
   la contradicción se ve en el segundo 1.
4. **Deseo + testimonio** (mejor retención): filtro de audiencia («si te gusta X, prestá atención»), creencia rota,
   contenido concreto, CTA directo.

Constantes de los cuatro: ningún saludo, cero caras en el primer cuadro (el primer cuadro es el tema en acción),
subtítulo de una palabra en mayúscula, el mockup sostenido en la mano sobre la escena real entre el 42 % y el 56 % de
la pieza, 23-29 s salvo el didáctico.

## Cómo aplicarlo
1. Transcribí el **audio** de los ganadores (nunca el OCR de los subtítulos: inventa palabras) y leé el copy aparte.
2. Listá los ángulos que aparecen solo en el copy: son guiones.
3. Escribí ángulos nuevos **dentro** de cada arquetipo, ponderando por lo que midió mejor.

Relacionadas: [[el-gancho-se-testea-con-el-cuerpo-fijo]] · [[reglas-de-copy-y-lo-que-meta-rechaza]]
