---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cuándo un creativo gana y cuándo se apaga"]
---

# Cuándo un creativo gana y cuándo se apaga

## Punto clave
Cuándo un creativo gana y cuándo se apaga. Cortes y coronación en múltiplos de P y de T, decididos con lo cobrado, no con el píxel.

## Un solo archivo de criterio para todos los robots

Llegamos a tener tres reglas distintas de "ganador" en tres robots distintos. Ahora hay **un archivo único de criterio** (un JSON) que leen el robot de testeo, el que pasa ganadores a la escala y el gerente. Un número se cambia ahí y en ningún otro lado. Si mañana querés ser más exigente, tocás una línea y todos los robots cambian juntos.

## Las reglas, en relativo

Con P = presupuesto diario de testeo y T = ticket:

| Decisión | Regla | Por qué |
|---|---|---|
| Apagar | **3 P gastados sin ninguna venta** | Le diste tres días de su presupuesto; no hay señal. |
| Apagar antes | **2 P sin ventas y sin un solo inicio de pago** | Si nadie llegó ni al checkout, no hay qué esperar. |
| Apagar | **CPA histórico > ~0,8 T** | Está vendiendo cerca del equilibrio; no aporta. |
| Apagar | **CPA de los últimos 5 días > ~1,1 T** | Se cayó, aunque la historia sea buena (ver protección abajo). |
| Prometedor | **2 ventas a CPA < ~0,65 T → presupuesto a 2 P** | Darle más muestra a lo que asoma. |
| Ganador | **5 ventas cobradas con CPA < ~0,65 T** | Pasa a la escala de su mercado. |
| Protegido | **≥ 5 ventas y CPA histórico < ~0,65 T → no se apaga por un mal tramo** | Si estaba apagado, se vuelve a prender. |

La protección salió de un error caro: los ganadores del testeo se apagaban por un mal tramo de cinco días aunque su historia fuera buena, y nos quedamos sin relevo. Ver [[errores-pagados-en-testeo-y-escala|errores pagados]].

## Ventas cobradas, no compras del píxel

El píxel contaba **cada extra del poscompra como otra compra**. Al medirlo, el píxel decía un 21 % más de compras que las órdenes reales. Con eso, conjuntos que el píxel daba por buenos en realidad perdían plata.

Regla: todos los robots cuentan **ventas cobradas = órdenes principales aprobadas, una por comprador**, atribuidas al anuncio por su UTM (id del anuncio en la URL; en nuestro caso cubre más del 95 % de las ventas). Los extras suman ingreso, no compras. El píxel queda solo como respaldo si la plataforma de la tienda no responde.

Para que esto funcione, **todo anuncio sale con UTMs que incluyan el id del anuncio** desde el primer día. Sin eso no hay forma de atribuir lo cobrado.

## El corte de la tarde

Un robot que juzga una vez por día deja pasar de largo: un conjunto de P gasta hasta ~1,7 P en un día, así que el que estaba al borde del corte a la noche llegaba al día siguiente con casi 5 P quemados. Solución: una **poda extra a media tarde** con la misma regla. Dos juicios por día, mismo criterio.

## La unidad mínima que se apaga es el conjunto

**Nunca** se pausan anuncios sueltos dentro de un conjunto, en ninguna campaña. En testeo, si el conjunto no sirve, se apaga el conjunto entero. En escala, ni eso (ver [[reglas-duras-de-la-escala|reglas duras]]).

## Un ganador no se mide por su nombre

Para saber si algo ya ganó, ya corre o ya se tradujo, se compara la **pieza real** (id del video o hash de la imagen), no el nombre del anuncio. Los nombres mienten: una copia se llama igual que el original, y un "GANADOR" en el nombre no prueba nada.

## Lo que todavía no adoptamos (y por qué)

De métodos de colegas tomamos ideas sueltas, pero no adoptamos "apagar al primer tramo chico" ni "100 creativos por semana": chocaban con lo que medimos en nuestras cuentas. La regla para adoptar algo ajeno: **¿trae resultados reales o solo una escalera calculada?** Lo medido en tus campañas gana sobre un método sin datos.
