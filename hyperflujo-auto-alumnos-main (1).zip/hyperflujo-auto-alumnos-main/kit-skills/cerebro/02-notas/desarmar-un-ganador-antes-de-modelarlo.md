---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Antes de modelar un ganador, se desarma: audio transcrito, cuadros mirados, copy leído aparte y la escala probada"]
---

# Antes de modelar un ganador, se desarma: audio transcrito, cuadros mirados, copy leído aparte y la escala probada

## Punto clave
Antes de modelar un ganador, se desarma: audio transcrito, cuadros mirados, copy leído aparte y la escala probada. El método para modelar sin inventar.

## La regla
Ningún ángulo se inventa: sale de la investigación, de la voz del cliente o de los anuncios que hoy escalan. Y ningún
ganador (propio o ajeno) se modela sin desarmarlo con método.

## El método
1. **Encontrar los que escalan de verdad**: en la Biblioteca de Anuncios de Meta, por página y por texto (no por
   categoría), dos ejes a la vez: **días activos** y **cantidad de anuncios prendidos**. La API cuenta activos que ya
   no circulan: la escala se confirma en la Biblioteca web. La tarjeta de la Biblioteca agrupa por texto, no por
   archivo: abrí las fichas y deduplicá por video.
2. **Bajar el video** (de la vista previa del anuncio si es propio; los videos de página no siempre se bajan por API).
3. **Transcribir el audio** con tiempos de palabra (ElevenLabs Scribe o Whisper grande). El OCR de subtítulos no sirve
   como guion.
4. **Hoja de contactos** (1 cuadro por segundo, con el segundo estampado) para ver plano 0, cuándo entra el producto,
   cortes, caras, texto en pantalla, material ajeno.
5. **Leer el copy aparte** del guion (ver [[copy-y-video-cargan-angulos-distintos]]).
6. **Medir**: duración, palabras por minuto, LUFS, cuántos planos, en qué fracción entra el producto.
7. **Escribir el desarme** en una ficha: bloques, sesgos por bloque, mecanismo del gancho, invariantes, qué se modela y
   qué no se toca por tus reglas.
8. **Anotar la apuesta** antes de producir la versión propia: qué esperás que gane y por qué.

## Qué buscar en ganadores propios
- Duplicados del mismo archivo con distinto ID: si se duplicó, ganó (el operador lo reusó).
- Medí por **video real** (agrupando duplicados por miniatura), no por anuncio: un video puede estar repartido en
  decenas de anuncios.
- Mirá qué parte del gasto cuelga de una sola pieza.

## Error típico
Describir de memoria «cómo era» el ganador. La memoria inventa; el archivo no.

Relacionadas: [[el-creativo-es-la-palanca-y-la-calidad-no-se-negocia]] · [[portar-un-ganador-a-otro-idioma]]
