---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El creativo es la palanca del negocio, y un producto bueno no vende con creativos malos"]
---

# El creativo es la palanca del negocio, y un producto bueno no vende con creativos malos

## Punto clave
El creativo es la palanca del negocio, y un producto bueno no vende con creativos malos. El creativo es la palanca; ganan deseo y miedo, mueren las características.

## La regla
Con la oferta sana y una landing que convierte sin fricción, **lo que mueve el número es el creativo**. Un producto
puede ser muy bueno y no vender porque los anuncios son flojos. Cada lanzamiento sale con creativos **muy buenos,
variados y distintos entre sí**, y la máquina aprende en cada tanda.

El estándar que se le pide a cada pieza: que **capte, desarrolle y venda adentro del mismo anuncio**. Cuando alguien
hace clic ya tiene que entender la oferta, reconocerse en el dolor, ver el valor y querer comprar. Si para entender
qué se vende hay que entrar a la landing, la pieza es un anuncio de tráfico, no de venta.

## Por qué (lo medido)
- En una tanda de ~40 anuncios testeados murieron sin ventas casi todos los que **describían el producto**
  («la planilla de 12 pestañas», «el método de las tres fermentaciones», «posturas paso a paso»). Ganaron los que
  nombraban un **deseo o un miedo** del comprador: plata, «el pan que sale como el de panadería», «con lo que ya
  tenés en casa», «cuándo NO regar» (miedo a hacerlo mal, resuelto). Los ganadores dieron ROAS 5 a 8; los de
  característica, 0.
- Cuando un mercado se cayó con la misma landing, la tienda convertía igual que en su pico: lo que había subido era
  el costo de traer al comprador porque su único ganador estaba quemado. La landing no era la causa.

## Cómo aplicarlo
1. **Diagnóstico en orden**: oferta → tasa de conversión de la landing → recién ahí creativos. Con la conversión
   validada, el CPA se mueve con creativos.
2. **Tres referencias juntas** antes de cada tanda:
   - lo que le funciona a la competencia **hoy** (anunciantes con muchos anuncios activos y muchos días corriendo en
     ese nicho e idioma, en la Biblioteca de Anuncios de Meta o en un espía tipo GetHookd). Se modela la estructura,
     nunca se copia;
   - la vara de producción propia (ver [[el-creativo-escalado-tiene-seis-bloques]] y los estilos);
   - lo que ya ganó en tus cuentas, con su ROAS, anotado en un registro.
3. **«Patear más veces al arco, y con criterio»**: volumen y calidad, las dos cosas. Una tanda de 5 piezas trae
   **5 conceptos distintos y al menos 3 formatos distintos**: uno modelado sobre un ganador de la competencia, un
   arco propio ya ganador trasladado, uno de plata o «con lo que ya tenés» si el nicho lo admite, y uno sacado
   textual de la voz del cliente.
4. Después de cada corte (qué vive, qué muere), anotar **qué ganó, qué murió y por qué**. Sin registro no hay
   aprendizaje.

## El estándar de producción (lo que se pide a cada pieza)
Storytelling con sentido, gancho fuerte, retención, CTA claro; look cinematográfico, «súper producido», valor
percibido alto; voz con ritmo; subtítulos sincronizados que resaltan cada palabra al decirla; **lo que se ve coincide
con lo que dice la voz**; guiones intrigantes que tocan dolores y remarcan beneficios.

## Error típico
- Ángulos de característica («incluye 12 módulos», «formato práctico»). Describen cómo es el producto; nadie compra
  eso en frío.
- Culpar a la landing cuando cae un mercado. Primero comparar **la misma tienda contra su propio pico**, no contra
  otra tienda con otro tráfico.
- Producir «correcto». Una tanda prolija y sin gancho es plata quemada igual.

Relacionadas: [[los-ganadores-repiten-cinco-movimientos]] · [[receta-medida-heroe-traducido-y-muestra-real]] ·
[[cada-renovacion-mezcla-formatos]]
