---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un creativo escalado sigue seis bloques en el mismo orden: lo que cambia es cuánto dura cada uno"]
---

# Un creativo escalado sigue seis bloques en el mismo orden: lo que cambia es cuánto dura cada uno

## Punto clave
Un creativo escalado sigue seis bloques en el mismo orden: lo que cambia es cuánto dura cada uno. Frenar, reconocerse, culpable, mecanismo, prueba, oferta; y los cinco arcos ganadores.

## La regla
Esqueleto por defecto para un video de 25-60 s:
**frenar → reconocerse → culpable externo → mecanismo → prueba → oferta sin riesgo.**

| Bloque | Tiempo en ~30 s | Qué pasa | Ejemplo (producto inventado: guía de huerta en balcón) |
|---|---|---|---|
| 1 Freno | 0-3 s | Imagen imposible de predecir + frase con número o pregunta | Una albahaca marchita sobre un plato rebalsado: «¿Por qué se te muere la planta aunque la riegues todos los días?» |
| 2 Espejo | 3-8 s | El espectador se reconoce (síntoma, escena, identidad) | «Comprás la planta, la ponés al sol, la regás… y a la semana está amarilla.» |
| 3 Culpable | 8-12 s | Lo que falló o la causa reencuadrada: no es tu culpa | «No es mala mano. Es que nadie te explicó el drenaje.» |
| 4 Mecanismo | 12-18 s | Por qué esto es distinto, con nombre o dato | «Las raíces respiran: con el agua estancada se ahogan.» |
| 5 Prueba | 18-24 s | Demostración, el producto real por dentro, número | Los pasos reales de la guía, tal cual están en el producto |
| 6 Oferta | 24-30 s | Cantidad o regalo + riesgo resuelto + CTA que nombra el producto | «30 plantas paso a paso, acceso inmediato. Tocá el botón y empezá hoy.» |

## Por qué (lo medido)
Sale de transcribir ~45 creativos escalados de cuatro verticales y de desarmar los ganadores propios (piezas de
13 a 93 s, media ~43 s, 112-231 palabras por minuto; los más largos hablan más rápido). Ninguno saluda ni se
presenta: la primera frase es pregunta o afirmación-choque.

## Variantes que también escalan
- **Sin voz, 12-46 s**: bloques 1, 2 y 6 en texto grande sobre la demostración. Se traduce sin locutar.
- **Largo con historia, 2-6 min**: dolor crónico o fundador. La historia estira los bloques 2 a 5.
- **El video frena y el copy vende**: el texto del anuncio largo (más de 1.000 caracteres) hace de advertorial.
- **Ráfaga de muestras**: tres o más ítems reales del contenido del producto en ráfaga, sin pitch casi hasta el final
  («tres trucos de fermentación que parecen magia»). Funciona cuando **la muestra es el producto**.

## Los cinco arcos que ganaron en las cuentas propias (trasladables a cualquier nicho)
1. **Brecha / contraste injusto**: «mientras vos X, otros ya Y». Finanzas: «Mientras vos pagás comisiones, otros
   invierten desde el celular con lo mismo.» Convierte la compra en elegir el lado correcto.
2. **Dos imágenes que contrastan** (el más eficiente): «Una hora mirando recetas y no hiciste ninguna. Diez minutos
   con esto y tenés el pan en el horno.»
3. **Ráfaga de muestras reales** del contenido.
4. **Culpa en primera persona del que compra** («yo sentía culpa cada vez que…»), solo si es un narrador honesto,
   nunca un testimonio inventado.
5. **Absolución explícita**: la culpa no es tuya, es del entorno, y el entorno se compra.

Invariantes de los cinco: un número grande, el mecanismo con nombre, la fricción resuelta antes de que la pregunten
(«acceso inmediato»), CTA imperativo y el producto real a la vista.

## Error típico
- Abrir saludando, presentando la marca o con el producto terminado.
- Poner la garantía o la oferta al principio: van al final.
- Acortar un guion «quitando la escena»: se corta lo repetido y lo que ya se ve en pantalla, nunca la escena ni lo
  que siente el cliente.

Relacionadas: [[el-gancho-se-elige-por-el-mecanismo-que-activa]] · [[checklist-antes-de-producir]]
