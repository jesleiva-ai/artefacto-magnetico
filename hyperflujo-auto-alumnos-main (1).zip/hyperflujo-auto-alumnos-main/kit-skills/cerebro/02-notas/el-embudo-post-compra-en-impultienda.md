---
type: nota
created: 2026-08-28
tags: [productos-digitales, ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Embudo post compra de la tienda", "El mapa de nodos del post-compra", "Cómo se configura el post-compra"]
---

# El post-compra de la plataforma de la tienda: cómo se configura, medido nodo por nodo

> Todo lo de acá está verificado operando el panel de la plataforma de la tienda (en
> el kit, Impultienda): se crearon funnels reales en una tienda de prueba y se abrió
> el editor de nodos y cada widget uno por uno, salvo lo marcado. Una versión anterior
> salía de las clases de la plataforma y tenía tres datos que la medición corrigió.

## Punto clave
No es un árbol de profundidad fija: es un **grafo libre**. Cada nodo tiene dos
salidas —acepto y rechazo— y cada salida se puede conectar a cualquier otro nodo
existente. Y el disparador es **match exacto de carrito**, así que un funnel cubre
una sola combinación: si querés cubrir varias, se crea un funnel por cada una.

Lo estratégico —qué poner adentro— está en [[las-seis-ofertas-del-post-compra]].

## Lo que la medición CORRIGIÓ de la versión anterior
1. **El interruptor no se llama "disponible en el post compra" ni decide bump vs
   upsell.** Se llama **"Disponible solo en post-compra"** y su texto real es:
   *"si está activado, este upsell no aparece en la tienda como producto agregable
   al carrito. Solo se puede ofrecer en un funnel post-compra"*. Es **exclusión**,
   no un conmutador: activado lo saca del carrito; apagado queda disponible como
   order bump.
2. **La ruta ya no es "Marketing → app Sales Post Compra"**: es
   `/dashboard/<slug>/marketing/post-compra`.
3. **No hay tope de "4 productos hacia abajo".** No existe límite de profundidad:
   toda salida se puede reconectar a cualquier nodo, y la que quede libre cae en la
   Página de Agradecimiento.

## Los tres pasos del editor
**Triggers → Upsells → Página de Agradecimiento.**

### 1 · Triggers — match exacto
Textual del panel: *"el funnel dispara si el carrito contiene **exactamente** los
productos que elijas (ni más, ni menos). Así nunca le ofrecés a alguien un upsell
que ya compró"*. Elegís el producto principal y tildás qué upsells venían ya en el
carrito; todo destildado cubre al que compró sólo el front.

### 2 · Upsells — el mapa de nodos
Dos modos de creación, **excluyentes**:
- **"Disparar siempre"** — un único funnel para toda venta, armado con los upsells
  marcados como "solo post-compra".
- **Por producto + combinación de carrito** — marcás combinaciones y **cada una se
  crea como un funnel separado**, con ese carrito exacto como disparador.

**La ley del modo automático, medida:** arma **2 ofertas por cada upsell que el
comprador todavía NO tiene**. Con 3 upsells libres → 6 nodos; con 2 libres → 4; con
1 libre → 2. Es decir, **un par upsell + downsell por producto disponible**. Con 3
upsells ofrece 7 combinaciones (2³−1).

**La escalera de descuentos que pone solo:**

| Nodo | Descuento | Rol |
|---|---|---|
| UpSell 1 · 2 · 3 | 15 % · 20 % · 25 % | Primera pasada, producto por producto |
| DownSell 1 · 2 · 3 | 40 % · 45 % · 50 % | El **mismo** producto, tras el rechazo |

**Cada nodo trae:** producto, tag, % de descuento, tipo, **reserva en minutos**
(default 10), botón *Editar oferta* y **métricas propias en vivo** — visitas,
ingresos, **$/visita** y % de conversión. Los funnels **se crean en PAUSADO**; la
lista tiene *Activar todos*, *Pausar todos* y *Eliminar todos*.

### 3 · Página de Agradecimiento
Título, mensaje con token `{email}`, texto del botón, y tres interruptores: resumen
de compra con los upsells aceptados, aviso de bandeja de entrada, y links.

- **El botón principal SIEMPRE redirige al inicio de la tienda.** No se cambia.
- **Pero "links a redes sociales" acepta cualquier URL**: son dos campos de texto
  libre, Nombre y URL con placeholder `https://...`. **Ésa es la única puerta para
  llevar al comprador a un canal propio** (grupo de WhatsApp, comunidad), porque los
  correos de la plataforma no se tocan (ver abajo).

## El editor de cada oferta
Widgets en tres bloques: **encabezado de orden** (número de orden y confirmación de
pago), **funnel-wide** (barra de progreso) y **offer-level** (texto, timer, y el
acordeón Upsell con producto, descuento, badge, imagen, botones, detalles, resumen
de precio y layout).

- **Aparición retrasada y desaparición programada en CADA widget.** Textual:
  *"el bloque aparece recién pasado este tiempo… sirve para mostrar primero un video
  y revelar el resto —incluido el botón de compra— más abajo"*. Es el mecanismo de
  VSL con botón revelado, dentro del post-compra. Hay un botón **"Probar delay"**.
- **Cinco tokens vivos**: `{first-name}`, `{discount}`, `{price}` (en la moneda del
  comprador), `{compare}` (tachado, vacío si no hay descuento) y `{timer}`.
  Funcionan en heading, body, detalles y textos de botón. **Ojo: el editor de
  downsell de salida sólo tiene dos** (`{discount}` y `{timer}`).
- **Catálogo de "Agregar widget"**: Texto, Imagen, **Bloque de código / Video**,
  **HTML personalizado**, Carrusel infinito, Espacio, Divisor.
- **Producto a ofrecer**: cualquier cosa de la tienda — el combo principal completo,
  el main, **cada bono por separado** o cada upsell.
- **Descuento**: % Off o $ Off, comparando contra **precio de tienda** o **precio
  original**; los auto-generados usan precio de tienda *"para garantizar que el
  downsell sea más barato que la oferta principal"*.
- **Badge**: lista cerrada (Bestseller, Más vendido, Recomendado, Lo más popular,
  Oferta limitada) en cuatro apariencias.
- **Botones**: texto del Aceptar, del Rechazar, y color del Aceptar (default
  `#1D79B8`).
- **Resumen de precio**: subtotal, descuento y total, **traducidos solos al idioma
  de la tienda**.
- **Carrusel del combo**: se llena solo con el mockup del principal y los bonos; el
  bono sin mockup sale como card con su título.

## Analytics
`/marketing/post-compra/analytics`: revenue total, vistas, aceptadas, conversión,
revenue diario y **top ofertas por revenue**. Más las métricas por nodo del mapa.

## Los topes reales del plan
**El plan más alto trae 3 upsells y 5 bonos POR TIENDA**, con un tope de tiendas.
Hay addons baratos por upsell extra, por pack de bonos y por tienda extra.

> La letra chica que conviene: el upsell extra *"se suma al límite de TODAS TUS
> TIENDAS Y EMBUDOS a la vez (precio único, no se multiplica)"*. Con un addon chico
> por mes, varias tiendas pasan de 3 a 8 upsells.

Esto choca con lo que se dice en las clases de la plataforma (*"pueden poner 5,
pueden poner 8"*): con el plan pelado son 3.

## Lo que NO se puede tocar
- **Los correos al comprador son intocables.** Hay dos —entrega al confirmarse el
  pago, y recuperación de carrito con descuento— y **no se editan**: salen desde los
  dominios de la plataforma, que no deja que la reputación de sus dominios dependa
  de lo que escriba cada usuario. No hay control de retraso ni de monto del
  descuento en el panel.
- **Pero la base es tuya**: se exporta en CSV/XLSX con mail, nombre, apellido y
  teléfono, y también los carritos abandonados. Todo el email marketing y el
  WhatsApp post-compra se hace **afuera**, con esa exportación.
- **El pago recurrente no apareció en el panel** (la plataforma dice que existe —
  sin confirmar). Las **mini apps** son proyecto, no producto.

## Order bump y captura de datos (Configuraciones)
- **"Upsells en el checkout"**: *"tus upsells aparecen como tarjetas Agregar dentro
  del checkout, al lado del resumen"*, con orden configurable y opción de ocultar la
  descripción. Ése es el order bump.
- **Campos del formulario**: email siempre obligatorio; teléfono (**+44 % de calidad
  de coincidencia en Meta**), nombre y apellido (+25 % cada uno). Conviene activar
  los tres, así el CSV sale completo.

## La entrega por link externo (y el falso positivo que genera)
El diálogo de cada producto tiene **"Link de descarga externa"**: *"si lo completás,
se usará este link en lugar del PDF subido"*. Es la vía para entregar, por ejemplo,
por **carpeta de Drive**, y el panel entonces marca el producto **"LINK EXTERNO"** y
**"Listo"**, con botones Abrir / Editar / Quitar link.

> **Trampa de lectura, ya pagada.** Un producto sin PDF y sin contenido generado
> muestra *"Para publicar este ebook generá el contenido con IA o subí un PDF"* y el
> cartel *"N ebooks pendientes de generar"*. **Eso NO significa que no se entregue
> nada**: puede estar entregando por link externo. Antes de declarar que una tienda
> no tiene qué entregar, mirá si dice LINK EXTERNO / Listo, no el cartel.

**Consecuencia estratégica:** si la entrega es por Drive o por PDF propio, ese
archivo es una superficie post-compra que la plataforma no controla y vos sí — el
lugar natural para los links a comunidad, WhatsApp o la siguiente oferta, que la
página de gracias sólo permite en un lugar y los correos no permiten en ninguno.

## El motor montado y apagado
En la primera revisión (2026-09-02), **ninguna de las tiendas propias tenía un solo
funnel post-compra**: todas las ventas al precio del front, sin un upsell tomado, y
usando menos upsells y bonos de los que el plan permitía. El error más común no es
configurarlo mal: es no prenderlo.

## Otras superficies del panel
- **Downsell de salida** (`/marketing/downsell`): editor propio con **modal de
  salida** + página de oferta. Banner superior con cuatro tipos: barra de escasez,
  cantidad restante, **viewers en vivo** (*"fluctúa simulando prueba social"*,
  textual) y ambos juntos (*"máxima presión"*). **Son simulados por la plataforma**
  — atención con las tiendas que venden en la UE.
- **Carritos abandonados**: tabla con motivo, repesca manual *"Enviar descuento"* y
  exportación.
- **Ventas realizadas**: sobre cada orden hay **Editar** y **Reenviar email a esta
  dirección** (resuelve el "no me llegó" sin salir del panel), más métricas de
  entrega (porcentaje entregado y de apertura).
- **Páginas**: landings extra con ruta propia (`/promo`), para variantes y señuelos.
- **Quiz** (`/marketing/quiz`): embudo interactivo con pantallas, captura de email y
  resultado por puntaje, con pestaña de Leads.


## Lo que se aprendió operándolo de verdad (2026-09-09)
Reescribiendo los nodos de varias tiendas propias en distintos idiomas:

- **No hace falta el panel.** Todo esto se escribe por la API REST que usa el propio
  panel, y se relee para verificar. El canvas del
  mapa, el botón Eliminar que no responde y el editor que carga vacío dejan de ser
  un problema.
- **`post_purchase_only` saca el producto del checkout y NO ocupa cupo de upsells.**
  Medido: con un upsell marcado como solo post-compra, el panel sigue diciendo
  `Agregar upsell (3/3)` y los tres visibles son otros. Así el mismo producto vive
  solo detrás del pago sin gastar una plaza del plan.
- **`offer_widget_order` decide dónde va el precio.** Con `upsell_product` último,
  el bloque de precio y botones queda al final de la página.
- **El aspecto de la página se cambia entero desde el widget de HTML.**
- **El botón suma el precio solo**: el `cta_accept_label` no debe traer `{price}` o
  el comprador ve el importe dos veces.
- **El storefront cachea**: un producto o un precio recién tocado no aparece en el
  checkout público hasta romper la caché con `?nc=<timestamp>`.

## Trampas del panel ya pagadas
- **El `<slug>` de la URL no elige la tienda** en `/personalizacion/*`: sirve la
  tienda ACTIVA. `/configuracion`, `/markets` y `/ventas/*` sí respetan el slug.
- **"Agregar bono" no está roto: está en el tope del plan.** El botón dice
  "Agregar bono (5/5)" y al lado hay "Usar más bonos", que es el addon. La versión
  anterior de esta nota lo listaba como control roto.


---

## Lo medido montando el OTO 1 (2026-09-09)

Cinco funnels reales, uno por tienda, cargados de punta a punta. Esto es lo que la
primera pasada no podía saber, porque miraba el editor sin llenarlo.

### La trampa que hay que conocer antes de tocar «Automático»

**El funnel automático escribe los textos EN ESPAÑOL, en cualquier tienda.** Una
tienda en otro idioma salió con *«⚠️ ¡ESPERA! TU PEDIDO NO ESTÁ COMPLETO…»* adentro.
Activar un funnel automático sin editar cada widget le sirve al comprador de
cualquier otro idioma una página en español. **No es un default
neutro: es un default en otro idioma.**

Y arma **6 nodos** —dos por cada upsell que el comprador no tiene—, no el par que
uno diseñó. Los que sobran hay que borrarlos a mano.

### El nodo de entrada no siempre es el que querés, y no se borra: se le cambia el producto

El orden de los nodos lo elige la plataforma y **varía por tienda**: en cuatro de
las cinco tiendas el `UpSell 1` salió con un upsell; en la quinta, con otro distinto.

Borrar el nodo de entrada es la salida obvia y la peligrosa. La buena: **abrir su
widget `Producto` y cambiar el producto en el select** (lista todos: principal,
bonos y upsells). El nodo sigue siendo la entrada del funnel y ofrece otra cosa.

> **Consecuencia para borrar los sobrantes: guiarse por el TAG, no por el nombre.**
> Después de cambiarle el producto al nodo 1, en una tienda quedaron cuatro nodos
> con el mismo nombre de producto. Se quedan `Tag: UpSell 1` y `Tag: DownSell 1`.

### El campo de minutos es GLOBAL del funnel

`Offer timer (minutes)` **no es del nodo**: ponerlo en 3 en el downsell le bajó el
contador al upsell también, y la tarjeta del funnel pasó a decir «Reserva: 3 min».
Se configura una vez y vale para todo el funnel.

### Los campos reales de cada widget

| Widget | Qué tiene adentro |
|---|---|
| Texto | `Heading` + `Body text` (dos `contenteditable`), padding arriba/abajo |
| Timer | minutos (global), color (Pink/Red/Yellow/Green/Blue/Purple/Gray) y el rótulo, que acepta `{timer}` |
| Descuento | número + `% Off / $ Off` + «Mostrar precio tachado» |
| Badge | lista **cerrada**: Bestseller · Más vendido · Recomendado · Lo más popular · Oferta limitada, en cuatro apariencias |
| Imagen | un campo de URL (vacío = usa el mockup del producto) y un tamaño en % |
| Botones | texto del Aceptar, texto del Rechazar y color del Aceptar (viene `#1D79B8`, azul) |
| Producto | select con todos los productos de la tienda |
| Resumen de precio | sólo los delays |

Todos, además, con **aparición retrasada** y **desaparición programada**.

### Cómo se carga sin que se pierda

El editor es una lista de widgets; **abrir uno reemplaza la lista por su panel**, y
para volver se clickea el título del panel («Editar texto», «Editar timer»…).

Lo que persiste, medido: **`execCommand('insertText')` con el campo enfocado**, el
botón **Guardar** de arriba (dispara un `PATCH` a `post_purchase_funnels`), y
**releer recargando**: un guardado no se da por hecho hasta verlo releído.

- **El copy largo va en un widget `HTML personalizado`**, que trae un `textarea` y
  acepta el bloque entero con estilos inline. Es la vía limpia para el cuerpo
  persuasivo: un widget en vez de cinco de texto, y con el formato bajo control.
- El menú «Agregar widget» ofrece: Texto · Imagen · Bloque de código/Video · HTML
  personalizado · Carrusel infinito · Espacio · Divisor.
- **El botón «Eliminar» del panel de una oferta no responde a la automatización**:
  el clic entra, no pasa nada, no hay error ni llamada de red. Los nodos sobrantes
  los tiene que borrar una persona.

### La herramienta

Conviene tener un script propio que cargue un nodo entero —timer, descuento, badge,
botones y el HTML del copy— en una pasada y en cualquier idioma (con un modo para
el nodo de rechazo), leyendo los textos de cada idioma de un archivo aparte.

### Y el límite que sigue en pie

El funnel dispara por **match exacto de carrito**, así que este OTO sólo lo ve
quien compró **únicamente el producto principal**. En una de las tiendas medidas,
**~36 % de los compradores ya se llevaba un upsell en el checkout y no lo veía**.
Para ellos hacen falta los funnels por combinación — uno por cada carrito posible.
