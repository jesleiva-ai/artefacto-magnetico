---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El estilo y el tratamiento del video los decide qué vende el producto, no el gusto"]
---

# El estilo y el tratamiento del video los decide qué vende el producto, no el gusto

## Punto clave
El estilo y el tratamiento del video los decide qué vende el producto, no el gusto. Subtítulo, duración y cara según qué vende el producto.

## La regla
Antes de elegir estilo, subtítulo y duración, clasificá **qué vende** tu producto:

| Si vende… | Subtítulo | Duración típica | ¿Cara? | Estilos que encajan |
|---|---|---|---|---|
| Emoción o alivio | grande, centrado, mayúscula, resalta una palabra | ~25 s | no | viral macro, personaje 3D que habla, musical |
| Volumen, catálogo | chico, abajo, en caja, para no tapar | ~37 s | no | voz + b-roll con muestras en ráfaga, grabación de pantalla con el contador de contenido visible |
| Oficio, método | voz en off + subtítulos | ~35 s (hasta ~55) | sí | UGC, 3D explicador, demo real |
| Un mecanismo o un villano | palabra por palabra | 35-45 s | no | claymation, 3D explicador |
| Un rato de calma | quemado desde el segundo 0 | 44-75 s | no | sin voz, texto + música |

La lógica: si el producto se explica con palabras, el texto es el contenido y va protagonista; si se demuestra con
imágenes, el texto se corre para no taparlo.

## Elegir por material disponible
- **Hay material real filmable** (el producto en uso, la pantalla, el oficio): empezá por ahí. En las cuentas propias, el
  material **mixto** (tomas reales del producto + tomas generadas) dio ROAS ~2,0 contra 1,2-1,3 de lo generado puro.
  En la cuenta de un operador de la comunidad, lo filmado propio rindió casi el doble que lo generado con IA, aunque la
  IA tuvo muy poco presupuesto para concluir.
- **No hay material**: IA. Si un video hecho con IA vende, se filma (o se rehace con tomas reales) la versión que lo
  replica.
- **Hay una persona creíble que habla**: UGC.
- **Hay un mecanismo que conviene personificar**: claymation (cálido) o 3D explicador (didáctico).

## Lo que vale para todos (observado en ~130 videos ajenos que escalan)
- Nadie abre con la cara ni con el producto: cuadro 0 = textura en movimiento (manos, material), y cerca del segundo
  1 entra el sujeto y la primera palabra.
- El producto llega tarde, apoyado en la escena, no como mockup flotando.
- Locución sin huecos: más de la mitad no tiene un solo silencio. Música ~12 dB por debajo de la voz.
- Cambio de marcha en el cierre: subtítulos pequeños todo el video y, en el cierre, texto gigante de color.
- Tasa de acierto realista: 1 de cada ~15 creativos producidos vende. Por eso el volumen.

## Error típico
Elegir el estilo que está de moda para un producto que no lo pide (un musical para un método técnico).

Relacionadas: [[estilo-viral-macro-con-personaje]] · [[estilo-ugc]] · [[cada-renovacion-mezcla-formatos]]
