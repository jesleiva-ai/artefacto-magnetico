---
type: nota
created: 2026-08-06
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Vídeo, PDF o app: el formato no es el valor", "Yo vendo un PDF a un PDF"]
---

# El formato del entregable no es el valor percibido: un PDF le gana a ofertas con vídeo y con app

## Punto clave
Un alumno trajo el bloqueo textual: ve ofertas con vídeos tutoriales y con mini
apps, y siente que no puede competir. La respuesta fue mostrar la propia mesa:
**"yo estoy vendiendo un PDF. Literalmente un PDF. Y afuera se está vendiendo con
un VSL de 40 dólares. Es comunicación, nada más."** Y el principio debajo: *"a la
gente no le interesa la herramienta en sí, le interesa la transformación que vos le
vas a generar con tu solución"*.

## El costo de producción que no paga nadie
*"Tenés que ver cuánto de valor percibido realmente hay en que tenga vídeos o no.
Si podés comunicar bien el valor de otra manera… comunicá la solución, más que si
es un vídeo o un PDF."* La advertencia concreta es sobre el costo: **"te vas a
meter a hacer una producción de Hollywood"** por una diferencia que el comprador
no está pagando. Lo que sí mueve valor percibido es la landing y la oferta.

## El costo de oportunidad, que es el argumento decisivo
Sobre meterse a construir una app para diferenciarse, la secuencia fue: *"sabés el
tiempo que te va a llevar aprender a desarrollar esa aplicación. Vas a invertir una
semana en aprender a hacerlo para después no saber si la oferta está validada.
**Es más importante validar la oferta**; una vez que tenés el negocio en
funcionamiento, después le agregás los colores que quieras, post-compra, cientos
de cosas."*

La tecnología no es una decisión de producto: es una decisión de **orden**. Va
después de la validación, nunca antes: primero se valida vendiendo, después se crea.

## Cómo se relaciona con lo que ya está guardado
- Es la aplicación operativa de [[producto-vs-oferta-transformacion]]: aquella
  nota dice cómo escribirlo, ésta dice **qué no construir**.
- Coherente con lo medido en upsells, donde lo que vende es el título y el mockup,
  no el contenido ([[upsell-treinta-caracteres-y-mockup]]).

## Aplicación
Cuando aparezca la pregunta "¿le pongo vídeos / una app / más formato?": la
respuesta por defecto es no, y el trabajo se va a la comunicación (landing, copy,
promesa). Si después de validar el mercado pide formato, se produce entonces —
con la oferta ya facturando y con plazo declarado, no antes.
