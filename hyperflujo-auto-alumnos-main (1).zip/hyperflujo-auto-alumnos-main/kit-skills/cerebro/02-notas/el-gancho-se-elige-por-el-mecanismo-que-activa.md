---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El gancho se elige por lo que tiene que sentir el espectador, y después se busca la fórmula"]
---

# El gancho se elige por lo que tiene que sentir el espectador, y después se busca la fórmula

## Punto clave
El gancho se elige por lo que tiene que sentir el espectador, y después se busca la fórmula. ~27 fórmulas de gancho por mecanismo, con ejemplos.

## La regla
Primero se decide el **mecanismo** (curiosidad, alivio de culpa, identidad, prueba, autodiagnóstico, escena,
enemigo, oferta) y después la fórmula. En cada tanda, los ganchos se reparten entre **al menos tres mecanismos
distintos**. Todo gancho escrito va con un gancho visual literal ([[lo-que-se-ve-es-lo-que-dice-la-voz]]).

## Por qué
Es una biblioteca destilada de ~35 ganchos que hoy escalan en cuatro verticales (barrido propio). Los ejemplos de
abajo están reescritos sobre productos inventados; la estructura es la del anuncio real.

## Las fórmulas, por mecanismo
**Curiosidad / causa inesperada**
1. «[Causa inesperada] es la razón por la que [síntoma hiperespecífico].» → «El vapor es la razón por la que tu pan
   casero sale chato.»
2. «¿Y si te dijera que [algo placentero] sirve para [X]?» → «¿Y si te dijera que dormir la siesta te ordena las
   finanzas?» (solo si el producto lo sostiene).
3. «¿[Mito] como en las películas? Casi seguro que no.» → «¿Los carpinteros miden dos veces? Los buenos miden una.»
4. Paradoja: «[Producto] es lo más molesto que vas a tener. Te va a encantar.»

**Reencuadre sin culpa** (el primer ángulo a probar en un producto nuevo)
5. «[Problema] no es tu culpa. [Cosa cotidiana] está diseñada para [sabotearte].»
6. «El problema no son tus [soluciones]… es [causa oculta].» → «El problema no es tu sustrato, es el drenaje.»
7. «Resulta que no era [vago/torpe].»

**Identidad y autoselección**
8. «La [solución] para quienes tienen [rasgo que da vergüenza].» → «Inglés para los que se traban en el aeropuerto.»
9. «Tengo [edad] y llevaba [tiempo] con [problema].» (solo con una persona real o un narrador declarado).
10. «Todo [el que tiene el problema] que quiera [resultado] tendría que ver esto.» → «Todo el que quiera hornear los
    domingos tendría que ver esto.»

**Prueba y resultado**
11. «[Problema] me robó [tiempo]. Lo arreglé en [tiempo corto].»
12. «Dame [N] segundos y te enseño [resultado].» (y el video dura N).
13. «No te explico nada: te lo muestro y decidís vos.»
14. «¿Podés creer que [número grande] personas [hacen algo raro]?»

**Autodiagnóstico**
15. «[N] señales de que [tenés X].» → «3 señales de que tu masa madre está lista.»
16. «Si notás [síntoma] últimamente, escuchá esto.»

**Escena y conversación**
17. Respuesta a un comentario: «¿Pensás que es una estafa porque es solo una planilla?»
18. «POV: vas a [lugar] y…» + la trabazón. → «POV: pedís un café en Londres y te responden algo que no entendés.»
19. «Si ya compraste [producto], perdón… acá es donde mentí.»
20. Confesión escandalosa + «dejame explicar» (historia larga).

**Enemigo**
21. «Tu [institución] no quiere que sepas esto.» (cuidado: en salud y finanzas Meta lo castiga).
22. «Es de lo peor que vi… pero antes de juzgar, mirá tu propio [lugar].»

**Identidad del comprador**
23. «Me compré [producto] para [uso puntual] y terminé usándolo para todo.» → «Me bajé la planilla para el viaje y
    terminé ordenando todo el año.»
24. «Tengo [credencial] y [producto] me enseñó tres cosas que no sabía» (autoridad humillada).
25. Una pregunta suelta y rara como gancho, sin presentación.

**Oferta** (sin cifra de precio)
26. «Este va a ser tu nuevo [X] favorito, y el primero lo probás gratis.»
27. «[Resultado] en una semana» + el plan día por día.

## El gancho de tres capas
El gancho que más rinde se escribe en tres capas que dicen lo mismo a la vez: **la imagen** (cuadro 0), **el texto en
pantalla** (una idea, letra grande, se lee en 3 s) y **la primera frase de la voz** (con número, hora, nombre o
pregunta sin responder). La voz entra en el cuadro 0, no al segundo.

## Error típico
- Diez ganchos del mismo mecanismo en una tanda. Meta los trata como el mismo anuncio y el test no enseña nada.
- Abrir un bucle («ni se te ocurra hacer esto…») que el video nunca cierra: es clickbait y baja el puntaje de calidad.
  Todo bucle abierto se cierra adentro de la misma pieza.
- Copiar un gancho ajeno que rompe una regla de tu marca. No se descarta: se conserva la **tensión** y se cambia la
  **superficie** (ver [[adaptar-un-gancho-ajeno-sin-romper-tus-reglas]]).

Relacionadas: [[sesgos-en-orden-atencion-identificacion-creencia-accion]] · [[un-ganador-cansado-se-revive-con-su-post]]
