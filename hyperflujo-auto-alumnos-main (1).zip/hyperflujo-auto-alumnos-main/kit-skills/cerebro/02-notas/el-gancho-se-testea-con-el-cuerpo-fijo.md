---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["En un creativo fresco, el gancho se testea con el cuerpo fijo, y el primer ángulo a probar es la absolución"]
---

# En un creativo fresco, el gancho se testea con el cuerpo fijo, y el primer ángulo a probar es la absolución

## Punto clave
En un creativo fresco, el gancho se testea con el cuerpo fijo, y el primer ángulo a probar es la absolución. Variantes de gancho en cuerpo fresco; la absolución primero.

## La regla
Cuando un cuerpo de guion ya vendió, las variantes reescriben **solo los primeros 5-9 s**. Cuerpo y cierre no se
tocan. El gancho nuevo queda dentro de ±15 % de palabras del viejo, o se desarma el montaje. En un producto nuevo, el
primer ángulo a probar es **absolución + mecanismo como secuencia**.

## Por qué
- Medido por un operador de la comunidad en una cuenta de recetas: los 4 anuncios con mejor ROAS compartían el cuerpo
  palabra por palabra; solo cambiaba el gancho, y la diferencia iba de ROAS 2,25 a 6,32. El mejor era absolución pura.
- Observado en terceros: anunciantes que corren 4 ganchos distintos que terminan con las mismas tres líneas y la misma
  placa final. Testean el gancho, no el video.
- La segunda mitad del movimiento: el mecanismo como **secuencia de 3-4 verbos**. No se vende información (hay gratis),
  se vende **orden**.

## El límite (lo que se midió en las cuentas propias)
Testear ganchos con cuerpo fijo funciona para **encontrar** el mejor gancho de un cuerpo fresco. **No revive a un
ganador cansado**: ahí las variaciones cosméticas dieron cero ([[un-ganador-cansado-se-revive-con-su-post]]).

## Ejemplo (curso de huerta en balcón, inventado)
«No es que tengas mala mano con las plantas. Nadie te dijo el orden: sustrato, riego, luz, poda. Esa es toda la
diferencia.»

## Cómo aplicarlo
- Si la voz es una sola pista de TTS, cambiar el gancho obliga a regenerar el audio y re-imponer los subtítulos. Mejor
  locutar el gancho como pista aparte desde el principio.
- Un cuerpo de copy fijo deja correr varios ángulos con una sola landing.

Relacionadas: [[el-gancho-se-elige-por-el-mecanismo-que-activa]] · [[copy-y-video-cargan-angulos-distintos]]
