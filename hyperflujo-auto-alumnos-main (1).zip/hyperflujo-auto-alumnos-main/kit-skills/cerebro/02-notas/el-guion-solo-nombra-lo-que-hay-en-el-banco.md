---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El guion solo puede nombrar cosas que existen en el banco de tomas: la palabra se cambia, la imagen no se fuerza"]
---

# El guion solo puede nombrar cosas que existen en el banco de tomas: la palabra se cambia, la imagen no se fuerza

## Punto clave
El guion solo puede nombrar cosas que existen en el banco de tomas: la palabra se cambia, la imagen no se fuerza. Catalogar antes de escribir; bancos gratis; medir el clip.

## La regla
**Primero se cataloga el banco, después se escribe el guion eligiendo los sustantivos de esa lista.** Si una frase
nombra algo sin metraje, se reescribe la frase y se vuelve a locutar (centavos) en vez de poner un plano que no
corresponde.

## Por qué
Tres guiones escritos antes de catalogar nombraban tres cosas de las que no había ninguna toma. La imagen no acompañaba
a la voz justo en los momentos más concretos del anuncio, que son los que enganchan. Se cambiaron las tres frases por
otras con metraje y uno de los creativos hasta cambió de nombre porque su gancho era la toma que faltaba.

## Cómo conseguir el b-roll literal, en orden
1. **Banco propio** catalogado (hoja de contactos con un cuadro por clip; 84 clips entran en tres hojas).
2. **Bancos gratis**: Pexels (el que más verticales tiene; filtro `orientation=portrait`), Mixkit y Pixabay para lo que
   falte (casi todo horizontal: se recorta a 9:16). En una tanda, 16 ganchos y 26 variantes salieron de bancos gratis
   sin gastar un crédito.
3. **Generar** recién entonces, con el modelo barato que muestre bien esa cosa
   ([[herramientas-y-para-que-sirve-cada-una]]).

## Antes de aceptar un clip, medirlo
- **Movimiento** (diferencia media entre cuadros; casi cero es una foto).
- **Brillo sostenido** de los primeros 3 s (un clip oscuro no sirve de gancho; se puede levantar con
  `eq=brightness=0.10:gamma=1.35`).
- **Abrir la hoja de contactos**: la búsqueda «horno» devolvió un juguete; «maceta», un dibujo animado.
- **OCR en 5 puntos del clip**: texto, marcas o rótulos ajenos lo sacan.

## Cómo catalogar
Cada clip con etiquetas por palabra **en todos los idiomas que vendés** (raíces de la palabra), así el montador lo
llama solo cuando la voz la dice en cualquier idioma. Ojo con los falsos amigos entre idiomas (una misma palabra que es
un animal en un idioma y otra cosa en otro). Varias tomas por etiqueta (`masa`, `masa2`, `masa3`) para que no se
repitan.

Relacionadas: [[molde-de-tanda-guion-voz-planes-montaje]]
