---
type: nota
created: 2026-09-02
tags: [productos-digitales, ofertas]
source: "referencia de tercero — clase del fundador de una plataforma de tiendas en una mentoría, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["El post-compra no se copia", "Benchmarks del post-compra", "El post-pago como escudo"]
---

# Todo lo que vive detrás del pago es invisible para el que te espía

> Los benchmarks de esta nota salen del panel interno de una plataforma de tiendas
> y los dio su fundador en una clase: son su palabra, no una medición propia. La
> única medición propia está marcada al final.

## Punto clave
El argumento más original de la clase no es sobre ticket promedio: es sobre
**defensa competitiva**. La landing la ve cualquiera con la Biblioteca de Anuncios;
el embudo post-compra sólo lo ve quien ya te compró.

> *"Si lo lanzan con anuncio te lo copian. Ahora, si lo ponen en un post-pago, la
> gente tiene que comprar toda la oferta para poder verte el post-compra. Por lo
> menos se va a dejar 200 dólares."*

Consecuencia operativa: **el post-compra es el único lugar del negocio donde se
puede poner la mejor oferta sin regalársela a la competencia.** Al revés de la
intuición, que empuja a poner lo mejor en la landing para que convierta.

Esto invierte el costo de espiar: el que quiera copiar el backend tiene que pagar
la oferta completa, y aun así sólo ve la rama que le tocó.

## Los benchmarks que dio
| Métrica | Número | Qué significa |
|---|---|---|
| Conversión del post-compra | **arriba de 10%** | El piso. *"Si están arriba de un 10%, van a tener un buen número"* |
| Techo visto | **45%** | *"De cada 100 personas, 45 se llevan el post-pago"*. Avisa: **no apuntar ahí**, *"te va a frustrar"* |
| Ticket promedio de TODA la plataforma | **USD 45** | *"La gente que está usando [la plataforma] puede bancarse un CPA de 45 dólares"* |
| Sólo de backend | **USD 11.000 a 15.000/mes** | Gente con el CPA igual al precio del front, rentable **sólo** por el post-compra (dicho por él, no verificado) |

## Por qué esto cambia la vara
[[upsells-unit-economics]] fija el objetivo en **AOV arriba de USD 30 y bancar un
CPA de hasta 19**. El fundador de la plataforma pone el promedio en **45**. No se
contradicen —el 30 es la ambición propia, el 45 es el promedio de todos los que ya
tienen backend armado— pero **si el promedio del mercado es 45 y vos pagás 19, el
que paga 40 te gana la puja**. Es el mismo razonamiento de
[[primero-el-ticket-promedio-despues-la-escala]] con el número actualizado.

Y su versión de por qué esto no es opcional:
> *"Si crece la competencia, crece la gente, aumenta el CPA, el CPM… acá el que se
> diferencia es el que hace el post-compra."*

## El criterio de calidad, que es lo que más repitió
> *"Hay gente que hace 1.000, 2.000, 3.000 dólares con el post-compra, pero lo hacen
> así nomás: te ponen la IA, le tocan el botón generar. Si vos lo generás, lo
> personalizás… si le ponés amor, vas a vender muchísimo más."*

Lo ancla en algo que no es motivacional: **el comprador se sofisticó**. *"No es lo
mismo comprar en 2020 que comprar ahora. Si vos lo armás así nomás, se va a notar."*

## Cómo se ejecuta
- Qué ofrecer: [[las-seis-ofertas-del-post-compra]].
- Dónde se configura y cuáles son los topes reales:
  [[el-embudo-post-compra-en-impultienda]].

## El techo declarado en mentoría (2026-09-02), arriba del promedio de 45
En una llamada de mentoría posterior se subió la vara respecto del ticket promedio
de la plataforma, con dos afirmaciones distintas que conviene no fusionar:

1. **El objetivo de base**: *"podés llevar tu ticket promedio a 100 dólares de
   base. Esto está validado."* Es más del doble del promedio de USD 45 de toda la
   plataforma. No es contradicción: 45 es el promedio de todos los que ya tienen
   backend; 100 es lo que se dice que se puede armar con los nodos bien hechos.
2. **El caso que rompe la intuición del precio**: un front de **USD 27** con un
   producto de post-compra de **USD 97** *"que se vende 3 veces más de lo que vale
   tu producto principal"*. El post-compra **no está limitado por el precio del
   front**.

El mecanismo que dieron para explicarlo es el que importa y es verificable:
*"la persona ya cargó los datos de su tarjeta — un clic y se debita
automáticamente — y está en su proceso de consumo más alto"*. Cero fricción de pago
+ pico de intención. No es que el producto valga más: es que el momento vale más.

> **Sin medir en cuentas propias.** El ticket promedio propio contra estos 100 no
> está calculado. Es un número declarado, no una medición.

## La primera medición PROPIA (2026-09-12): ~8%, contra el 10% que él da como piso
Tres días de un OTO 1 + downsell corriendo en cinco tiendas propias, contados sobre
las órdenes por API:

- Las ventas de post-compra dieron **~8% de las compras del front** en las cinco
  tiendas juntas, con mucha dispersión entre ellas (la mejor tienda concentró más
  de la mitad de esas ventas; las más flojas, una sola cada una).

O sea: **la primera pasada quedó apenas abajo de su piso**, con un solo par de
nodos y sin los funnels por combinación de carrito (el que se lleva un upsell en el
checkout todavía no ve ninguna pantalla). El número es propio y medido, no
declarado.

**Matiz importante para no sobreleer esto**: en el medio se bajó el precio del
upsell ofrecido a menos de la mitad, así que el 8% no corresponde a una sola oferta
estable.
