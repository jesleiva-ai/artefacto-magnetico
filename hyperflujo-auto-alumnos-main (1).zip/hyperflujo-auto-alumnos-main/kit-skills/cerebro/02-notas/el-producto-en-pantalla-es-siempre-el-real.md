---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El producto que se presenta es siempre el real: la IA nunca dibuja el producto"]
---

# El producto que se presenta es siempre el real: la IA nunca dibuja el producto

## Punto clave
El producto que se presenta es siempre el real: la IA nunca dibuja el producto. Zona verde y producto real; lo prometido está en el entregable.

## La regla
Toda toma o imagen donde aparece el producto muestra **los mockups y las muestras reales** del entregable, en el idioma
de esa tienda. La IA genera escenas, manos, ambientes y b-roll; **el producto se pega encima desde el material real**.
Y lo que el creativo promete tiene que estar en el producto.

## Por qué (lo que ya pasó)
- Una tanda entera se rechazó en revisión porque «los mockups que aparecen no son los míos»: el banco tenía tomas donde
  la IA había inventado productos genéricos con portadas que no existen. Un producto que no es el tuyo es otra promesa, y
  el dueño lo nota de un vistazo.
- Al pedirle a un modelo de video «una persona usando una guía», inventó una portada con un nombre ajeno.
- Un mockup de hero decía «VIDEO PASO A PASO» en la portada cuando el producto es un PDF sin un solo video. Nadie lo vio
  en tres revisiones porque las imágenes se auditaban como estética, no como **un renglón de copy que promete algo**.
- Un gancho fuerte nombraba una receta que el PDF no traía. Se resolvió sumando un bono antes de prender.

## Cómo aplicarlo
- **Zona verde**: pedile a la IA la escena con la pantalla del dispositivo, el recuadro de foto o el espacio del
  producto en verde croma (#00FF00) liso. Un script detecta cada zona, calcula su cuadrilátero, pega el material real
  con perspectiva y **solo pinta donde había verde** (los dedos que tapan la pantalla quedan por delante). Falla cerrada
  si sobra verde o no aparece la cantidad de zonas esperada.
- En video: tomas reales del producto (grabación de pantalla, el PDF abierto en un celular, el mockup animado con un
  zoom lento hecho con ffmpeg: gratis y con el texto exacto). Los modelos de video **deforman el texto de una pantalla
  después de ~5 s**: usá solo los primeros 2 s o reemplazá por el zoom.
- **Por dentro con diseño**: si mostrás el producto por dentro, que tenga fotos, infografías y recuadros. Una pantalla de
  texto corrido en un creativo no pasa el QA ([[mockups-nivel-agencia]]).
- Cada mockup se lee como copy: ¿promete un formato, una cantidad o un bono que el entregable no tiene?
- Cada gancho que nombra una receta, dato o técnica se busca en el texto del entregable antes de prender.

## Error típico
Usar tomas del banco que «parecen» el producto. Si el comprador no reconoce lo que recibe, pide reembolso.

Relacionadas: [[lo-que-se-ve-es-lo-que-dice-la-voz]] · [[los-estaticos-que-ganan]] · [[mockups-nivel-agencia]]
