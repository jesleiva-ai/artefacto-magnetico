---
type: nota
created: 2026-08-12
tags: [ofertas]
source: "referencia de tercero — medición de 5 ofertas públicas de IA para una profesión técnica y de 2 softwares de ese rubro, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Elegir la paleta de un nicho", "De dónde sale el tono", "Qué se hereda al re-nichar una oferta"]
---

# El tono de una paleta sale de medir el nicho y el escritorio del avatar, no de una tabla

## Punto clave
[[la-paleta-se-mide-no-se-elige]] enseña a **construir** bien una paleta —familias
de tono, saturación, neutros—, pero no de dónde sale el tono cuando el nicho es
nuevo. Sale de medir **dos cosas distintas**: qué usan las ofertas que ya venden
ahí, y qué mira el avatar las ocho horas del día. Con eso el color deja de ser
gusto y pasa a ser una decisión de diferenciación.

## Lo que disparó esto
Se entregó una landing para una profesión en navy + dorado, calcada de la de
otra profesión, cuando el pedido había sido dos veces «con la paleta pensada para
este nicho». No fue criterio propio: **una tabla genérica de «paletas por nicho» lo
prescribía**, generalizando desde una sola oferta a todas las profesiones. Al medir el nicho contable de
verdad, la tabla se cayó entera.

## El procedimiento, sobre dos ejes

**Eje 1 — qué usa el nicho.** La herramienta de paleta (`paleta.py`) sobre 4-6
ofertas que estén vendiendo (las trae `/espia-ofertas`). Se anota fondo
dominante, acento, familias y el veredicto diseñada/acumulación.

**Eje 2 — qué mira el avatar todo el día.** El software o entorno de su oficio.
Es el eje que nadie mira y el que más decide: ese color **es su definición de
trabajo**, y por eso no le llama la atención.

**Y recién ahí se elige**, buscando el acento lejos de lo dominante — idealmente
en su complementario.

## La medición de contadores, como ejemplo del método
| Quién | Fondo | Acento | Veredicto |
|---|---|---|---|
| Oferta A · 27d×12 | blanco ~19% | azul `#2B4DD0` | acumulación |
| Oferta B · 11d×24 | navy 36% | ámbar `#E8A544` (78% sat) | acumulación |
| Oferta C (IT) · 23d×8 | blanco 65% | azul `#3171C8` | **diseñada** |
| Oferta D | verde 26% | lima `#D3FE6C` | acumulación |
| Oferta E · 9d×202 | negro 44% | terracota `#C17C62` (43% sat) | **diseñada** |
| **Software contable líder** (uso diario) | **azul 98,9%** | — | diseñada |
| **Otro software contable** (uso diario) | blanco | violeta | diseñada |

(«27d×12» = días activos × anuncios prendidos.)

Conclusión: el azul es el default del rubro —3 de 5 ofertas más el software
líder—, así que **ponerse azul es volverse invisible dentro del propio nicho**.
Y las dos paletas que miden «diseñada» traen el acento con saturación baja (43%),
mientras la de ámbar al 78% mide «acumulación»: confirma la compuerta de ≤60% de
[[la-paleta-se-mide-no-se-elige]] con evidencia nueva.

## El eje emocional decide el FONDO, antes que el color
La pregunta no es qué vende el profesional: es **qué compra**.
- **Autoridad** (abogado, escribano): gana por cómo lo perciben → fondo oscuro,
  serif, penumbra, dorado.
- **Precisión y control** (contador, perito, auditor): su miedo no es parecer
  poco importante, es que un número esté mal → **fondo claro**, alto contraste,
  sans. Su mundo visual no es la biblioteca: es la hoja con las cuentas claras.
- **Alivio** (salud, crianza): claro y aireado.

Dos oficios con el mismo ticket y la misma estructura de oferta piden fondos
opuestos por esto, no por estética.

## Qué se hereda y qué NO al re-nichar una oferta
Vale para toda la fábrica «IA para [profesión]», que es un molde repetible:

**Se hereda** — la estructura (E4 para IA-para-profesión), la composición del
mockup, el método de prompts (bloque maestro + prompts cortos), la arquitectura
de oferta y el framework de copy.

**No se hereda** — la **paleta**, la **iconografía** (la balanza del abogado es
la calculadora del contador) y el **eje emocional**, que es el que arrastra al
fondo, la tipografía y hasta si la página es clara u oscura.

Heredar la paleta es heredar el código cultural de otro oficio. El dorado no es
«prestigio profesional» en abstracto: es toga, balanza y biblioteca. En un
escritorio de cierres mensuales no significa nada.

## Aplicación
Antes de maquetar cualquier oferta nueva: correr los dos ejes y dejar la
medición escrita al lado de la propuesta, para que quien decide elija mirando.
La compuerta ya está puesta en `/maqueta-landing`, que dejó de tener tabla de
paletas y ahora exige la medición.

## Relacionadas
[[la-paleta-se-mide-no-se-elige]] · [[medir-la-landing-antes-de-replicarla]] ·
[[patrones-visuales-y-titulares-ganadores]]
