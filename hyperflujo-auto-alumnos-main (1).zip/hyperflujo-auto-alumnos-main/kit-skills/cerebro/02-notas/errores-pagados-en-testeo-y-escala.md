---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Errores pagados"]
---

# Errores pagados

## Punto clave
La lista de lo que nos costó plata, con la regla que dejó cada uno.

Cada fila costó plata, ventas o días. La última columna es la regla que quedó. Los errores de los robots en sí (candados, cron, conectores) están más detallados en [[robots-que-fallan-seguros|robots / fallar seguro]].

## Testeo

| Qué pasó | Costo | Regla que quedó |
|---|---|---|
| Los ganadores del testeo se apagaban por un mal tramo de 5 días aunque su historia fuera buena. | Mercados sin relevo cuando los ganadores de la escala se cansaron. | Ganador con ≥ 5 ventas y CPA histórico bajo el objetivo **no se apaga** por un tramo malo; si se apagó, se prende. |
| El píxel contaba cada extra del poscompra como compra (+21 %). | Conjuntos que el robot daba por buenos perdían plata. | Todo se decide con **ventas cobradas**, una por comprador. |
| El robot juzgaba una vez por día. | Conjuntos que llegaban a ~5 P quemados antes del corte. | **Dos podas por día** con la misma regla. |
| Muchísimos conjuntos se cargaron en pausa y nunca se prendieron. | Muchos creativos frescos sin probar, pagados en IA. | **Cola diaria** de 5 por mercado; todo lo cargado entra a la cola. |
| Se prendieron 13 conjuntos el mismo día en un mercado. | Testeo caro y sin lectura clara. | Ritmo constante, 5 por día. |
| Se propuso sacar de la producción a los mercados que no arrancaban. | (Frenado a tiempo.) | Mínimo 2 conjuntos nuevos por día en todo mercado. Sin creativos nuevos, el mercado se muere. |
| Ante una mala racha se propuso producir menos. | (Frenado a tiempo.) | Mismo volumen, mejores ángulos: 2/3 iteración o traducción, 1/3 ángulo nuevo con evidencia. |
| Testeos por país como campañas sueltas, creados por distintas sesiones. | Presupuesto fragmentado; demasiadas campañas en un mismo mercado. | Máximo 3 campañas por mercado; los países van como conjuntos. |
| Un país grande metido en la segmentación de un idioma que no es el suyo. | Dos semanas de gasto sin ventas. | Conjuntos **nuevos** sin los países que pierden; no editar los vivos. |
| Se prendieron conjuntos antes de pasar la auditoría de idioma. | Errores de país y filtro en anuncios activos. | Crear en pausa → auditoría en 0 errores → prender. |

## Creativos y fatiga

| Qué pasó | Costo | Regla que quedó |
|---|---|---|
| Un solo ganador por mercado durante 6-8 semanas, sin reemplazo. | La ganancia diaria a cero en diez días. | Alarma de cansancio diaria + fatiga anticipada + relevo listo antes. |
| 15 variaciones cosméticas de un ganador cansado. | Cero ventas. | Meta agrupa lo que se parece: el relevo es un ángulo nuevo o el post original. |
| Resubir el mismo video con metadata limpia. | Casi sin entrega. | Metadata es higiene, no palanca. |
| El héroe duplicado en seis campañas. | Fatiga acelerada en un mercado grande. | El héroe va en un solo lugar. |
| Se apagó el motor de un mercado grande por una sospecha no probada. | El mercado murió. | Un motor rentable no se apaga sin reemplazo **ya ganando**. |
| Ganadores que no se traducían a otros mercados. | Solo el 4 % de las traducciones posibles hechas. | Matriz ganador × mercado y cupo fijo diario de traducciones. |
| Se sacó un ganador porque tenía texto en otro idioma dentro del video. | Ventas reales perdidas un día. | Texto escrito en pantalla en otro idioma es aviso, no error; lo que bloquea es voz, copy, link, país y filtro. |

## Escala

| Qué pasó | Costo | Regla que quedó |
|---|---|---|
| Los robots apagaban anuncios y conjuntos dentro de las escalas. | Se rompían estrategias que vendían, en todos los mercados. | Las escalas no se tocan por dentro. |
| Tope de arranque "alto" con presupuesto grande. | Una noche entera de escala a ROAS ~1. | El tope de arranque es el CPA que vas a pagar: arranca bajo y busca. |
| Presupuesto enorme con topes bajos. | Las escalas gastaron ~5 % de lo disponible. | La canilla: el tope abre, el presupuesto no. |
| Arranque del día en un presupuesto altísimo. | Una escala con ROAS < 1 que el robot no podía recortar a tiempo. | Arranque escalonado según historia; piso bajo. |
| El robot bajó una escala de madrugada con poca muestra, antes de su pico. | El mercado se quedó sin presupuesto en su mejor franja. | Sin muestra no se baja; piso en el pico. |
| Saltos de presupuesto ×30 en una noche. | Aprendizaje reiniciado. | ×4 chico, ×2 grande, una subida por hora. |
| Topes subidos a mano en la franja floja de un mercado. | ROAS 0,3-0,6 en la hora y media siguiente. | Subidas antes del pico; toda subida queda a prueba y vuelve sola si sale cara. |
| Escalar de golpe mercados chicos. | La conversión de la tienda cayó a la mitad. | Crecer de a poco con ROAS; volver al gasto donde ganaba. |
| Modo ofensivo con creativos cansados. | Tres días de ganancia en baja hasta pérdida. | Modo ganancia; volver al ofensivo con 3 días ≥ 1,4 y ganadores nuevos. |
| "Un ganador por conjunto" en la escala. | Una escala que no entregó y otra a ROAS 0,3. | CBO con varios ganadores y topes por escalón. |
| Una escala gastó casi el doble de lo que cobró en el día. | Nadie la frenó hasta el día siguiente. | Freno de mano automático. |
| Una cuenta quedó en pago necesario varias horas en plena escala. | Horas de venta perdidas en el pico. | Vigía de pagos cada 15 min + salvavidas que se dispara solo. |

## Medición

| Qué pasó | Costo | Regla que quedó |
|---|---|---|
| Mirar el día suelto y no la tendencia. | Diez días de caída sin que nadie lo marcara. | Termómetro: 3 días contra el mejor tramo. |
| Una cuenta faltaba en la lista del tablero. | Un ROAS inflado que llevó a decidir mal. | Lo que falta entra como cero: cotejar la lista de cuentas. |
| Comparar husos distintos. | Tablero en cero sobre gasto real; ROAS falsos de madrugada. | Cada cuenta en su huso; rangos de fechas explícitos. |
| Culpar a la landing comparando tiendas distintas. | Casi se rehace una landing que convertía igual que en su pico. | Comparar la tienda contra su propio pico. |
| Una regla sacada de la curva de un solo día. | Se achicó todo un día bueno. | Una curva de un día es hipótesis; se confirma con 3. |
