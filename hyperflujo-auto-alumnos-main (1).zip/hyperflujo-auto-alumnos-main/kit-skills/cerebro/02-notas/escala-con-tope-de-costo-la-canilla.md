---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Escalar con tope de costo: la canilla"]
---

# Escalar con tope de costo: la canilla

## Punto clave
Con puja de tope, el presupuesto no empuja el gasto: lo abre el tope. Cómo buscarlo cada madrugada.

## La regla fija

> **El tope de costo es lo que abre la canilla; el presupuesto no.**

Con puja de tope (cost cap), el presupuesto es solo un techo. Un domingo les dimos a las escalas presupuestos enormes y gastaron alrededor del 5 %. Los topes estaban bajos y Meta no encontraba a quién venderle a ese precio. Subir el presupuesto no compró ni una venta más.

Al revés también: una escala con topes abiertos y presupuesto bajo tampoco gasta. **Tope y presupuesto tienen que abrir juntos** en el horario en que el mercado compra.

## El tope de arranque ES el CPA que vas a pagar

La lección más cara de la escala: una noche arrancamos los topes "altos" (CPA de 7 días + un margen) y con presupuesto grande Meta **usó el tope entero**. Las escalas gastaron en el pico, pero a ROAS ~1. Si el tope arranca en X, asumí que vas a pagar X por venta.

Por eso el tope arranca **bajo** cada madrugada y sube buscando precio.

## La escalera de topes (cómo se busca el precio cada día)

Un robot corre cada media hora sobre las escalas con tope:

1. **Reset diario** antes del pico del mercado: cada conjunto vuelve a un tope bajo, escalonado (los conjuntos de una misma escala arrancan en escalones distintos para buscar en varios precios a la vez).
2. **Memoria:** si ayer gastó bien con buen ROAS, arranca donde terminó ayer menos un poco. El punto donde la canilla se abrió se guarda y al día siguiente arranca ahí.
3. **BUSCA:** si en la última media hora la campaña gastó menos que el umbral, el tope sube un escalón chico.
4. **Canilla abierta:** cuando la campaña **en total** (sumando todos sus conjuntos, porque en una CBO Meta puede dárselo todo a uno) gasta el umbral por media hora **y llegan ventas**, el tope queda **un escalón por encima** de ese punto.
5. **IMPRIME:** desde ahí se trabaja fino: baja un escalón si sale caro; sube uno si se frena dos medias horas seguidas y no viene mal.
6. **Hora de fin:** pasada la franja buena del mercado, no sube más; solo baja si está caro.
7. **No baja de madrugada temprano:** Meta atribuye tarde; en las primeras horas "caro" suele ser atribución atrasada.

## Toda subida queda a prueba

Una subida de tope que salía cara solo se notaba en el promedio del día, horas tarde. Regla: después de cada subida sobre una campaña que ya vende, se mira lo que pasa **desde la subida**:

- Si con un gasto mínimo desde la subida las ventas cobradas salen por encima de la línea de freno (cerca del punto de equilibrio), o no hay ninguna → el tope vuelve al último valor probado y no se vuelve a pasar por 3 horas.
- Con 2 ventas por debajo de la línea, la subida queda confirmada.
- Sin datos de lo cobrado, el freno no actúa (no decide a ciegas).

## El presupuesto sube por escalones, no por saltos

- **Saltos enormes reinician el aprendizaje** de la campaña. Pasar de un día al siguiente de 1x a 30x es "una guasada". Escalones razonables: ×4 cuando el presupuesto es chico, ×2 cuando ya es grande, **una sola subida por hora**.
- **Arranque según cómo viene:** el presupuesto con que arranca el día depende del ROAS y las ventas de ayer y de los últimos 3 días (mejor historia → arranque más alto). Nunca arrancar el día con un presupuesto altísimo: no llegás nunca a recortarlo si se cae.
- **Sube con la mitad gastada:** si gastó la mitad del presupuesto con buen ROAS, se duplica sin esperar la hora ("nunca puede tener gastada la mitad").
- **Sin muestra no se baja:** la baja normal exige un gasto mínimo (una fracción del arranque del día). Un mercado que en su pico arrancó bien no se ahoga por dos horas flojas antes de su mejor franja.
- **Corte duro:** ROAS del día muy bajo con gasto suficiente → directo al piso, sin esperar la hora. Excepción: lo que viene vendiendo a CPA bueno.

## Pico a fondo, pero solo en el pico y solo a los que ganan

Abrir la canilla todo el día a todos no funciona. Lo que sí: **en el pico horario de cada mercado**, abrir tope y presupuesto a las escalas cuyo ROAS de los últimos 3 días está por encima de la meta, y volverlas a su base cuando termina el pico. El volumen sale de los que ganan, no de abrir todo.

Para un mercado que vende en una franja corta, la subida tiene que entrar **antes** de esa franja. Lo medimos tres noches seguidas: una suba de presupuesto que entra después del pico llega tarde y gasta sin ventas.

## Más gasto no es más ganancia si el freno es laxo

Un día un mercado venía a ROAS 1,9 a media mañana; al abrirle presupuesto a la tarde terminó en ~1,26 con más del doble de gasto. Con frenos laxos, los robots estaban hechos para ROAS ~1,3. Corregimos bajando el freno y el techo del tope.

El equilibrio que encontramos: **ROAS y ganancia antes que volumen.** Pero tampoco conformarse: "gastaron poco y rindieron mejor" no es motivo para no volver a gastar más. Un mercado con buen ROAS se empuja, y se frena solo si el ROAS cae de verdad, con muestra.

## Dónde mirar si una escala no gasta

1. ¿El tope está por debajo de lo que Meta necesita? (lo más común)
2. ¿El presupuesto quedó en el piso por un reset que no corrió?
3. ¿La cuenta está frenada por un pago?
4. ¿El robot corrió? (ver [[robots-que-fallan-seguros|fallar seguro]])
