---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo 3D explicador: un corto animado en cuatro capítulos que muestra el mecanismo por dentro"]
---

# Estilo 3D explicador: un corto animado en cuatro capítulos que muestra el mecanismo por dentro

## Punto clave
Estilo 3D explicador: un corto animado en cuatro capítulos que muestra el mecanismo por dentro. Corto animado en cuatro capítulos con el mecanismo por dentro.

## Qué es
Animación 3D tipo cortometraje de estudio, en **cuatro capítulos**: situación → producto → **mecanismo interno** →
resultado. Las tomas del mecanismo van en «modo frame» (cambio de estado entre un cuadro inicial y uno final). Música
fija del estilo, ~1,12x. Sirve para productos cuyo valor es **entender por qué pasa algo**.

## Ejemplo (producto inventado: guía «Huerta en el Balcón»)
1. Situación: albahaca marchita sobre un plato rebalsado + «¿Por qué se muere tu planta aunque la riegues?» (gancho
   visual y verbal desde el cuadro 0).
2. Producto: la guía en el celular (mockup real como cuadro, solo los primeros ~2 s del clip).
3. Mecanismo, en una cadena continua: raíces que respiran → poros llenos de agua → raíces que se pudren.
4. Resultado: maceta con drenaje y planta sana; CTA sobre un zoom lento del mockup.

## La técnica que hizo que funcione
El primer par inicio/fin del mecanismo salió **como infografía en inglés** (carteles, flechas) y con el cuadro final
distinto del inicial (otra planta, otro corte). Se abortó antes de gastar en video y se cambió el método:
- el cuadro inicial con «A still frame from a 3D animated short film, not a diagram» + «pure visual scene, absolutely no
  words»;
- **cada cuadro final como edición del inicial** (pasándolo como imagen de referencia), y el final de una toma como
  inicio de la siguiente. Los tres clips se leen como una sola animación continua.

## Trampas
- Los modelos de video **deforman una pantalla con texto después de ~5 s** (texto inventado o pantalla en blanco). Para
  el CTA, un zoom lento con ffmpeg sobre el mockup: gratis y con el texto exacto.
- Revisá la física de la toma: un agujero de drenaje salió en el costado y no en la base. Se entiende, pero se nota.
- Si el beat dura más que dos tomas, la tercera repite: sumá un b-roll extra por caso en vez de repetir.
- Cumplimiento: «puedes tener albahaca» y no «tienes albahaca» (resultado implícito garantizado).

Relacionadas: [[estilo-claymation]] · [[estilo-viral-macro-con-personaje]]
