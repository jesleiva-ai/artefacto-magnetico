---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo cine: la trama con personajes fijos entretiene pero no explica; lo que funciona es voz en off simple sobre escenas dinámicas"]
---

# Estilo cine: la trama con personajes fijos entretiene pero no explica; lo que funciona es voz en off simple sobre escenas dinámicas

## Punto clave
Estilo cine: la trama con personajes fijos entretiene pero no explica; lo que funciona es voz en off simple sobre escenas dinámicas. Trama vs. voz en off simple sobre escenas dinámicas.

## Qué es
Dos variantes de video «nivel cine» hechas con IA:
1. **Miniserie con diálogo**: escenas con conflicto y giro, personajes que hablan con voz y labios nativos del modelo
   (Veo 3.1 genera video, voz y labios juntos), cortos de un minuto que cierran.
2. **Explicador simple**: **voz en off** que explica algo complejo como para que lo entienda cualquiera, con ejemplos
   cotidianos, personajes distintos en cada video y escenas dinámicas semirrealistas (estética de cinemática de
   videojuego, dos tomas por frase de ~2,3 s), cierre con logo.

## Por qué (lo que se aprendió)
- La primera tanda de miniserie (una serie con elenco fijo y trama) se devolvió con «no se entiende nada»: la
  trama entretiene, pero el espectador no sale sabiendo qué se vende.
- La corrección fue la variante 2: voz en off, ejemplos de todos los días, personajes que cambian. Esa versión, en
  estilo semirrealista dinámico, se aprobó como «excelente» y se pidió una serie.
- Narrar sobre imágenes fijas o con un lip-sync que no acompaña la boca se percibe como «presentación», no como cine.
- Con la imagen de referencia del personaje, Veo lo deja **posando** (~30 % menos de movimiento); sin ella hay más
  acción y menos continuidad de cara.

## Receta (explicador simple)
guion → tomas mudas (Veo 3.1 Fast o MiniMax H3) → **una sola pista de voz entera** (ElevenLabs v3, estabilidad .5,
similitud .8, estilo .5, tempo parejo ~1,1) → montaje con dos tomas por frase, un destello de color cada dos cortes,
el sonido ambiente del modelo bajo la música → cierre con logo y un golpe musical.

## Trampas
- **Los modelos toman el prompt al pie de la letra**: «los personajes son solo humanos o robots» metió robots en todas
  las escenas. Nombrá solo lo que va en esa toma + «do not add other characters».
- Un objeto descrito ambiguo sale otra cosa («tank» dibujó un tanque de guerra: pedí «water reservoir cylinder»).
- Monitores, tableros y carteles en escena **traen números y letras falsas**: pedí «blank screen» o «only lines, no
  digits» y pasá OCR por el cuadro entero.
- El sonido nativo del modelo puede traer voces en otro idioma: transcribilo antes de mezclarlo.
- Etiquetas de estilo en inglés dentro del texto de la voz («[epic trailer narrator]») arrastran el acento a otro país.
  Voces del país del público y sin etiquetas en inglés.
- Un spot de cierre recortado a la fuerza para entrar en 15 s (silencios cortados, tempo variable) sonó «muy IA». El
  relato con tempo parejo no.
- La música no corta cuando entra el cierre: una sola canción corre hasta el logo.

Relacionadas: [[estilo-personaje-3d-que-habla]] · [[voz-ritmo-y-locucion]] · [[hoja-de-personaje-y-consistencia]]
