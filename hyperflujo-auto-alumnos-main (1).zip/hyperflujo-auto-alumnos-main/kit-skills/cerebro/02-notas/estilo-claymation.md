---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo claymation: stop-motion de plastilina que personifica al villano y cuenta el problema con calidez"]
---

# Estilo claymation: stop-motion de plastilina que personifica al villano y cuenta el problema con calidez

## Punto clave
Estilo claymation: stop-motion de plastilina que personifica al villano y cuenta el problema con calidez. Plastilina que personifica al villano.

## Qué es
Stop-motion de plastilina generado (una imagen por toma + video), voz en off que manda el ritmo, planos de ≤ 3 s con
b-roll sobre la palabra, subtítulo palabra por palabra, un golpe de sonido en cada corte, ~1,15x. Sirve cuando hay un
**mecanismo o un villano que conviene personificar**. Es más cálido y artesanal que el 3D explicador. Los clips **no
tienen idioma**: traducir es otra voz y otro montaje.

## Ejemplo (producto inventado: planilla de finanzas «Mes en Verde»)
- Gancho visual + verbal en el segundo 0: hormigas de plastilina cargando monedas + texto «Gastos hormiga: el dinero
  que **no ves** irse» + voz «Estas hormiguitas se llevan el dinero del mes…».
- Giro en la línea 5: «Hasta que los escribís» → un foco de luz atrapa a las hormigas.
- Una balanza de plastilina donde la pila crece y el platillo baja (el mecanismo, visual).
- Producto desde el segundo ~25: dos mockups (laptop y celular) + «Tocá el botón y descargala hoy».

## Receta
- Un **Character Bible** (descripción fija del personaje) repetido palabra por palabra en cada prompt.
- Voz ElevenLabs latinoamericana neutra a ~1,05; música propia por registro (Suno; pizzicato + marimba para «curioso»).
- 9 líneas de voz, ~18 planos, ~37 s. Alrededor de 10 clips de Veo Fast en total con regeneraciones.

## Trampas medidas
- **Mockups con cifras**: el primero mostraba «Ahorro del mes» e «Ingresos» con montos: se lee como promesa
  financiera. Se regeneró con montos como barras grises.
- **Formas que parecen logos**: un rectángulo rojo con un triángulo blanco se leía como el logo de una plataforma de
  video. Cambiado por otro objeto.
- **La voz nombraba dos marcas de software** de planillas: cambiado a «una planilla digital».
- Veo «cargó» mal un objeto en modo frame (la balanza terminó vacía): se rehizo solo el video con el movimiento
  descrito paso a paso. El clip crudo traía un salto de escena a los ~4 s que el montaje no usa.
- Cumplimiento: el problema se cuenta en tercera persona («casi nadie las ve»), nunca «¿llegás justo a fin de mes?».

Relacionadas: [[estilo-3d-explicador]] · [[el-estilo-lo-decide-que-vende-el-producto]]
