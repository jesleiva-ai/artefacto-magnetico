---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo musical: una canción pegadiza con letra propia que nombra el producto, y la voz cantando desde el medio segundo"]
---

# Estilo musical: una canción pegadiza con letra propia que nombra el producto, y la voz cantando desde el medio segundo

## Punto clave
Estilo musical: una canción pegadiza con letra propia que nombra el producto, y la voz cantando desde el medio segundo. Canción con letra propia, voz cantada desde el medio segundo.

## Qué es
Una canción corta (30-40 s) con **letra escrita para esa pieza** que cuenta el ángulo y canta el nombre del producto;
una persona cantando a cámara en los primeros segundos, en **multicámara** (3-4 ángulos de la misma persona, corte
cada ~1,1 s sobre las palabras, zoom de golpe y un flash al arrancar); después b-roll literal por verso con karaoke.
El producto entra **cuando se canta su nombre**.

## Las reglas que salieron de las correcciones
1. **Cada pieza con su propia letra y su propio ángulo.** Tres piezas con la misma letra son un solo anuncio.
2. **Alguien cantando a cámara en el arranque**, no solo b-roll.
3. **La voz cantada entra en el primer medio segundo**: se recorta la intro de la canción. Un arranque instrumental
   de 3 s es un arranque perdido.
4. Arranque **explosivo**: varios ángulos, cortes rápidos.

## Ejemplo (producto inventado: «Inglés para Viajar»)
Letra con el estribillo «Maleta lista… inglés para viajar», tomas por verso (aeropuerto, hotel, restaurante, compras,
emergencias, que son las secciones reales del producto), CTA cantado sobre el mockup. 36 s, 21 planos, la voz a los
0,3 s, el producto a los ~16 s.

## Receta
1. Letra → **Suno** (V6, letra en el prompt, duración ~40 s): cada envío trae 2 temas; pedí 2 estilos y elegí entre 4.
2. **Elegir el tema** transcribiendo cada uno (ElevenLabs Scribe): la letra más fiel, el estribillo que llega antes, el
   largo correcto. Cerca de la mitad de los temas cantan mal el nombre del producto: se descartan.
3. Tiempos por palabra de la letra alineada (Suno los da) → montaje con un plano por palabra clave y karaoke.
4. Persona cantando: foto (GPT Image 2) → ángulos extra con Nano Banana Pro usando la foto como referencia → recorte del
   audio de la canción → **Wan 2.6** con imagen + audio hace el playback. Desfase medido: 0-20 ms.
5. B-roll con Veo 3.1 Fast.
Costo de una pieza: alrededor de 17 clips de Veo Fast (el playback de Wan es lo más caro).

## Trampas
- Una versión nueva de Wan **no acepta imagen y audio juntos**: quedate con la que sí.
- Wan deforma el plano después de ~3,5 s (aparecen otras personas): revisá cada ángulo y acotá su duración.
- Veo a veces mete franjas negras dentro del 9:16: recortalas en el montaje.
- El transcriptor del QA entiende mal la voz cantada sobre música y marca «ritmo bajo»: es falso positivo; el control de
  la letra se hace con Scribe sobre el final.
- Picos de audio: un limitador (pico final −1,5 dB) evita el aviso.
- Continuidad: las tomas de texto → video hacen a alguien parecido, no idéntico; para la misma cara en todo el video,
  imagen → video desde la foto (más caro).

Relacionadas: [[musica-de-los-creativos]] · [[cada-renovacion-mezcla-formatos]]
