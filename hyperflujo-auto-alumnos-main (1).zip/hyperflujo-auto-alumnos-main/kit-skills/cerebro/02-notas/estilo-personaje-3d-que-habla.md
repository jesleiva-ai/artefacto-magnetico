---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo personaje 3D que habla: el tema mismo es un personaje amenazado que habla en primera persona"]
---

# Estilo personaje 3D que habla: el tema mismo es un personaje amenazado que habla en primera persona

## Punto clave
Estilo personaje 3D que habla: el tema mismo es un personaje amenazado que habla en primera persona. El tema es un personaje amenazado que habla.

## Qué es
Un personaje 3D estilo animación de estudio que **es** el problema o el tema (la masa madre, la moneda que se escapa, la
planta sedienta), metido en una escena hiperrealista, **amenazado desde el primer cuadro**, hablando en primera
persona con doblaje exagerado. 4-5 casos con **la misma frase molde**, 30-48 s, subtítulo de a una palabra.

## Por qué
Es el molde de una cuenta viral de referencia (cientos de miles de seguidores, 3 reels por día). Lo que rinde y lo que
no, medido sobre ~200 reels de esa cuenta:
- Rinden: la **súplica invertida** («por favor no me dejes en la heladera…»), el giro cómico, la corrección de una
  creencia, el villano, la ternura.
- Rinden poco: **objetos neutros que dan consejos desde afuera**. El personaje tiene que estar en juego.
- Lo morboso se lleva restricción de edad y pierde alcance.

## Ejemplo (producto inventado: guía de finanzas personales)
Una moneda 3D atrapada en un frasco de «gastos hormiga»: «Me estás perdiendo y ni te enterás. Cada café, cada
suscripción que no usás…» → otra moneda: «A mí me mandaste a una app que abriste una vez…» → «Anotanos. Así sí nos
quedamos.» → mockup real + CTA.

## Receta
- Imagen del personaje en escena (Nano Banana Pro o GPT Image 2) → voz por línea (ElevenLabs v3, controlada con Scribe
  ≥ 0,8 de coincidencia) → **lip-sync con Wan 2.6** pasándole la imagen y el audio por URL pública → montaje con
  subtítulo de a una palabra y un cierre hablado sobre el producto real.
- Cada paso guarda su resultado para retomar sin volver a pagar.

## Trampas
- El personaje se parece a uno de película: pedí diseños originales y revisalo.
- Wan mueve la boca peor que Veo en diálogos largos: si la boca no acompaña, Veo con voz nativa (ver [[estilo-cine-y-explicador-simple]]).
- Un personaje por toma hablando; con dos, el modelo confunde quién habla.

Relacionadas: [[estilo-viral-macro-con-personaje]] · [[hoja-de-personaje-y-consistencia]]
