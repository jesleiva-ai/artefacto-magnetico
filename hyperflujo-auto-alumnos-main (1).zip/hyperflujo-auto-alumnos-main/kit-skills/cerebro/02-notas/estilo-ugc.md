---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo UGC: una persona a cámara que parece grabada con celular, con insertos de b-roll sobre la palabra"]
---

# Estilo UGC: una persona a cámara que parece grabada con celular, con insertos de b-roll sobre la palabra

## Punto clave
Estilo UGC: una persona a cámara que parece grabada con celular, con insertos de b-roll sobre la palabra. Persona a cámara, review de la app, podcast, venta directa.

## Qué es
Una persona habla a cámara (lip-sync) en 4-6 escenas de ≤ 8 s cosidas, con insertos de b-roll **justo sobre la palabra
que ilustran**, subtítulo palabra por palabra, música baja (~−20 dB) y el clip acelerado ~1,18x. Variantes del mismo
formato: **review de la app** (la pantalla real del producto en un celular, con voz en off), **podcast** (dos personas,
una pregunta lo que pregunta el comprador) y **venta directa** (qué incluye, cuántos bonos, comparación sin cifra).

## Por qué (lo medido)
- En una prueba lado a lado, la **review de la app** (grabación real) dio el mejor ROAS de los formatos nuevos con
  muestra chica; el **UGC de presentadora hecha con IA** dio cero en su primera prueba. Lo que delata a un UGC con IA
  se puede corregir (ver [[ugc-con-ia-sin-que-se-note]] en producción), pero arrancá por lo real si lo tenés.
- En la cuenta de un operador de la comunidad, los videos con material filmado de verdad rindieron mejor que los
  hechos con IA, que casi no tuvieron presupuesto: la IA está **sin probar**, no descartada.

## Ejemplo (producto inventado: curso de planillas en 7 días)
- Gancho: en el cuadro 0 levanta **3 dedos** y la caption dice «Hay… 3» (la voz arranca en el cuadro 0): «Hay 3 cosas
  que te piden en casi cualquier entrevista de oficina.»
- Escenas 2-5: cada «cosa» con su inserto (una pantalla de planilla genérica hecha a mano, sin la cinta de colores ni
  la interfaz de una marca conocida).
- Cierre: mockup real + «Tocá el botón y empezá hoy».

## Receta de producción
1. Retrato de la persona **como selfie de celular** (no de estudio) → cuadro inicial por escena.
2. Escenas habladas con Veo 3.1 Fast (o Gemini Omni) con el diálogo exacto. Cada escena se transcribe y se recorta: a
   veces el modelo repite la última frase o agrega una palabra.
3. Una sola voz para todas las escenas con speech-to-speech de ElevenLabs.
4. Montaje: cortes de silencio con zoom alternado, b-roll real del producto como tarjetas encima de la persona,
   mockup animado en el tercio inferior con la cara a la vista.

## Trampas
- **El gesto tiene que coincidir con la palabra**: dijo «3» con 4 dedos → se regeneró el cuadro describiendo el gesto
  dedo por dedo (revisado **antes** de pagar el video). Cuando dice «la segunda» con un dedo, un b-roll encima lo tapa.
- Whisper devuelve «tres» y el subtítulo esperaba «3»: el alineador normaliza números en letras a cifra.
- Un b-roll generado traía la interfaz típica de un software conocido y a la persona con otra ropa: se descartó.
- Diferencias de cara y pelo entre escenas sin imagen de referencia: el corte las absorbe, pero con imagen de
  referencia salen iguales.
- Una medición automática de labios contra la voz no dio un pico claro ni en los clips buenos: el lip-sync se valida
  **mirando la boca**, cuadro por cuadro en las uniones.

Relacionadas: [[testimonios-y-personas-en-pantalla]] · [[cada-renovacion-mezcla-formatos]]
