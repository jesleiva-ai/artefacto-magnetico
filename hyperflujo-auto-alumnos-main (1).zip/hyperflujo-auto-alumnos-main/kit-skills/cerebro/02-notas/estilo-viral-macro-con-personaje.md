---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estilo viral: foto macro hiperreal con personajes animados adentro, psicología inversa y bucles abiertos"]
---

# Estilo viral: foto macro hiperreal con personajes animados adentro, psicología inversa y bucles abiertos

## Punto clave
Estilo viral: foto macro hiperreal con personajes animados adentro, psicología inversa y bucles abiertos. Macro hiperreal + personajes, psicología inversa, bucles.

## Qué es
Una foto macro hiperrealista del tema (la masa fermentando, el sustrato húmedo, una gota de aceite en la sartén) con
**personajitos 3D estilo animación de estudio viviendo adentro**, y **la transformación pasando en cámara**. Todo
exagerado. Guion de psicología inversa: «Ni se te ocurra X… a menos que quieras Y», con **3 casos por pieza**,
23-40 s.

## Por qué (lo medido)
- En una tanda orgánica de siete reels de este molde, **uno solo explotó**: muchas veces las vistas de los otros seis
  de su tanda, con compartidos y guardados muy por encima de lo normal. El resto de la tanda quedó en el rango normal. Lo que
  lo separó fue **el tema**, no la producción: una transformación que el espectador no puede predecir y que pasa
  frente a cámara (pensalo como la masa madre que fermenta y se llena de burbujas sola: el «¿cómo puede ser?»).
- El mismo estilo, repetido con otros temas de transformación visible, volvió a pasar 30 veces la mediana de la cuenta. Las animaciones 3D
  planas de temas parecidos quedaron muy por debajo: no todo lo animado despega.
- **Las vistas no son ventas.** Llevarlo a anuncio está en prueba; no hay ventas medidas todavía con este estilo.

## La estructura (de una cuenta viral de referencia)
gancho → caso 1 → **bucle abierto** («Pero eso no es nada.») → caso 2 → bucle («Y el último es el más loco:») → caso 3
→ llamado a la acción. **El bucle es la pieza que retiene.** Se publicaron algunos sin bucles a propósito para
comparar.

## Ejemplo (producto inventado: guía digital de pan de masa madre)
1. «Ni se te ocurra mezclar harina y agua y dejarla en un frasco…» → la masa se llena de burbujas con personajes que
   inflan globos (levaduras y bacterias del ambiente que sueltan gas).
2. «Pero eso no es nada: estirá la masa contra la luz…» → membrana translúcida (la prueba de la ventana: el gluten
   atrapa el gas).
3. «Y el último es el más loco: vapor en el horno…» → el pan crece frente a cámara (el vapor retrasa la corteza).
Cierre sobre el mockup real: «Tocá el botón y descargala hoy.» Todo dato es verdadero y está en el producto.

## Receta de producción
- Imagen de inicio (y de fin, en las tomas de transformación) con GPT Image 2 o Nano Banana Pro; video con Veo 3.1
  Fast en «modo frame» (primer y último cuadro) para la transformación, o imagen → video simple para el b-roll.
- Voz de narrador (ElevenLabs, velocidad ~1,05-1,08), subtítulo de a una palabra, música fija del estilo.
- Costo de una pieza: alrededor de 7 clips de Veo Fast en total (ver índice de costos en producción).

## Trampas
- El modelo de imagen mete **personajes de películas existentes** (peces, robots, emociones con cara). Pedí diseños
  originales y prohibí explícitamente lo que se parezca («no fire characters, no water drop characters» si el caso es un
  horno) y revisá los fotogramas.
- Carteles y etiquetas en inglés dentro de la escena: sumá al sufijo de estilo «absolutely no signs, no labels, no
  packaging with words» y reemplazá la bolsa con texto por un objeto sin texto (un bol de harina).
- Veo bloquea por «seguridad de contenido» ciertas escenas (personajes dentro de un horno, jeringas, espuma roja, manos
  con objetos peligrosos). Si bloquea, cambiar el prompt no alcanza: hay que **regenerar también la imagen** de inicio.
- Una cara de susto o llanto sostenida dos planos lee como imagen negativa. La emoción del personaje acompaña la
  transformación (entusiasmo cuando crece).
- Para pasarlo a anuncio: no regales el caso completo, 30 s o menos, cerrá con el producto real, sin precio.

Relacionadas: [[estilo-personaje-3d-que-habla]] · [[reels-organicos]]
