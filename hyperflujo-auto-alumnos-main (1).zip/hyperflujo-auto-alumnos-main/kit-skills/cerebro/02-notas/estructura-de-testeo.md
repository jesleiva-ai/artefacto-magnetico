---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Estructura de testeo"]
---

# Estructura de testeo

## Punto clave
Un testeo fijo por mercado que nunca se apaga, conjuntos 1-1-3, cola diaria de 5 por mercado.

## La campaña de testeo de cada mercado no se apaga nunca

Cada mercado (un idioma, o un país grande) tiene **una** campaña de testeo ABO fija. Ahí entran todos los días conjuntos nuevos a presupuesto P. Lo que se apaga son los **conjuntos** que no venden; la campaña, jamás.

- Un ROAS bajo de la campaña de testeo entera no la condena: es normal, porque prueba piezas nuevas todo el tiempo. Nosotros apagamos una vez una campaña de testeo "porque sobraba" y hubo que prenderla de vuelta ese mismo día.
- Sin creativos nuevos un mercado se muere. Lo vimos dos veces en mercados grandes: un solo ganador quemado durante semanas y sin reemplazo.

## Máximo tres campañas por mercado

Llegamos a tener demasiadas campañas en un mismo mercado (testeos por país creados por sesiones distintas): presupuesto fragmentado y aprendizaje repartido. La regla que quedó:

1. **Un testeo general ABO.** Todo lo nuevo entra ahí como conjunto, también un país o una diáspora (un conjunto con ese país en la segmentación).
2. **Una escala** (CBO con tope de costo).
3. **Un tercer lugar** solo donde ya existe algo que funciona.

Nunca se crea "TESTEO <PAÍS>" como campaña aparte. Cuando un país gana mucho de verdad puede tener su testeo y su escala, pero se decide con datos de varios días, no por entusiasmo.

**Medido:** en dos mercados que veníamos perdiendo, pasar de muchas campañas a dos (un testeo + una escala) trajo con casi la misma plata un 60 % más de ventas en uno y más del doble en el otro, con el CPA bajando cerca de un tercio.

## Conjuntos 1-1-3 (o 1-1-1, según el negocio)

- **1-1-3:** un conjunto, tres anuncios del **mismo ángulo en tres formatos distintos** (por ejemplo, voz en off con tomas, UGC y estático). Al menos dos de los tres en video. Conviene cuando el volumen da para probar formatos.
- **1-1-1:** un conjunto, un solo anuncio con una sola pieza. Sirve con poco volumen, para saber si cada pieza por sí sola trae ventas.

Las dos funcionan; lo que no funciona es cambiar de una a otra sin motivo. Cada vez que alguien "ordenó" pasando de 1-1-3 a 1-1-1 en lo que ya corría, hubo que restaurarlo. Si querés probar otra estructura, armá conjuntos nuevos al lado; lo que corre queda igual.

## La cola diaria: 5 conjuntos por mercado por día

Encontramos muchísimos conjuntos cargados en pausa que **nunca se prendieron**: piezas frescas que se produjeron, se cargaron y quedaron olvidadas. De ahí salió la cola:

- Todo creativo nuevo se carga en **pausa** y entra al final de la cola de su mercado.
- Un robot prende los **5 siguientes de cada mercado por día**, a presupuesto P, a la medianoche.
- Antes de prender, copia la segmentación y el filtro de idioma del conjunto de testeo vivo más reciente (los viejos no excluían países que hoy van por otra campaña), relee que siga pausado y sin gasto, y verifica releyendo.
- Cuenta como "nunca corrió" todo lo que gastó menos de una fracción mínima de P.
- La fábrica de creativos deja de producir para un mercado que ya tiene 10 o más conjuntos esperando. Producir de más es tirar plata en IA.

**Por qué 5 y no 13:** un día prendimos 13 conjuntos juntos en un mercado. Meta reparte el aprendizaje, el testeo se encarece y no sabés qué pieza aportó qué. Ritmo constante > ráfagas.

## Mínimo dos por día, aunque el mercado venga flojo

Cuando un mercado no arranca, la tentación es sacarlo de la producción. La regla es al revés: **mínimo 2 conjuntos nuevos por día** en todos los mercados. Recortar = menos conjuntos o menos días, nunca cero.

## Mismo volumen, mejores ángulos

Cuando la tasa de ganadores baja (nos pasó de ~3 % a 0 % en una semana), la salida **no** es producir menos sino producir mejor con la misma cantidad. La receta que quedó:

- **2 de cada 3 conjuntos** iteran o traducen algo que ya vendió.
- **1 de cada 3** prueba un ángulo nuevo **con evidencia** (algo que funciona afuera: competencia, redes, investigación). Nunca un ángulo inventado.
- **Control del gancho antes de cargar:** movimiento o pregunta en el primer segundo, voz nativa, subtítulos.
- Cada pieza lleva una etiqueta de origen (traducción / iteración / ángulo nuevo / formato) para medir qué fuente da ganadores.

**Medido:** en diez días, sobre una muestra grande de conjuntos, solo ~1,3 % salió ganador. **7 de cada 10 ganadores** venían de iterar o traducir algo que ya vendía. Un mercado testeó decenas de conjuntos de ángulos nuevos sin ningún ganador.

## Diversidad de formatos

Casi todo lo que testeábamos tenía el mismo formato (voz en off sobre tomas) y los ganadores se cansaban igual. Desde entonces, cada renovación mezcla formatos: UGC, podcast, reseña de app, venta directa, pantalla partida, reacción, lista, POV, experimento, calle, estático. En un conjunto que itera un ganador, uno de los tres anuncios conserva el formato del ganador y los otros dos prueban formatos nuevos. Se rota para no repetir combinaciones en el día.

**Medido sobre un histórico grande de anuncios:** la estructura del ganador histórico traducida exacta dejó más de la mitad de la ganancia; los estáticos con una pregunta fuerte tuvieron el mejor CPA; los UGC hechos con IA, las variaciones cosméticas y las resubidas idénticas no vendieron.

## Checklist del conjunto que nace

- Un idioma de punta a punta: voz, copy, link a la tienda de ese idioma, países y **filtro de idioma (locale)** siempre puesto.
- Región amplia + filtro de idioma, no solo el país (el país recorta alcance; lo que define a quién le sale es el idioma).
- Facebook **e** Instagram del mismo idioma; nunca la cuenta de Instagram de otro idioma.
- Ubicaciones automáticas en lo nuevo (la red de audiencia se lleva poco gasto y vende igual o mejor; no la apagues en lo que corre).
- Sin precio en el anuncio, sin urgencia falsa, sin nombrar otras plataformas en el copy.
- Se crea en **pausa** → auditoría de idioma en 0 errores → recién ahí se prende.
