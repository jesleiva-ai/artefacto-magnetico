---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Fábrica nocturna y carga automática"]
---

# Fábrica nocturna y carga automática

## Punto clave
De noche se produce sin tocar Meta y de tarde se carga en pausa. Antes de cargar pasan tres compuertas que frenan solas: QA de creativos, semaforo de la tienda y auditoria de idioma.

## De noche se produce, de tarde se carga

Una madrugada Meta frenó la API durante horas. Al contar las llamadas: la fábrica de creativos había hecho muchísimas (subidas de video en trozos y consultas de estado), justo en el pico de los mercados, compitiendo con los robots de escala. La escalera de topes hizo menos de la mitad de sus vueltas.

Desde entonces, dos etapas separadas:

| Etapa | Cuándo | Qué hace | Meta |
|---|---|---|---|
| **Producción** | de noche | Guiona, genera, monta y audita las piezas de cada mercado | **Prohibido** (una variable de entorno hace que el cliente de la API corte) |
| **Carga** | a la tarde | Crea creativos, conjuntos y anuncios; numera; actualiza registros | Sí, con ritmo global limitado y pocas cargas en paralelo |

La regla general: **el cupo de la API en el pico del mercado es de los robots que deciden.** Todo lo pesado va fuera del pico.

## La producción

- Un orquestador lanza un agente de IA por mercado, varios en paralelo, con un límite de tiempo por mercado.
- **El encargo** de cada mercado lo arma el servidor: receta medida, relevos de la alarma de cansancio, traducciones pendientes, órdenes y plan del jurado, formatos a rotar, cuántos conjuntos le tocan. La máquina que produce lo trae, adapta rutas y produce.
- **No arranca mercados nuevos** después de una hora límite y **corta** a la hora fija. Los mercados que quedaron afuera por el corte **arrancan primero** la noche siguiente, y el aviso del corte nombra al que estaba por arrancar.
- **Stock:** no produce para un mercado con 10 o más conjuntos en cola.
- **Disco:** antes de producir borra los restos de render de noches anteriores (quedaban decenas de GB por noche y el disco se llenó en una semana). Con poco disco, menos mercados en paralelo y un aviso.
- **Aprendizajes:** cada agente agrega lo que aprende a un archivo común del protocolo (la memoria del agente es por carpeta del día y no pasa sola a la tanda siguiente).
- Al terminar, devuelve al servidor los registros y los aprendizajes, y llama al jurado previo.

## Las compuertas antes de cargar

1. **QA de creativos** (sale con error si hay algo rojo): formato y duración; cuadros negros y tramos congelados; audio (volumen integrado, pico, % de silencio, tono de la voz fuera de rango); la voz transcripta **sin forzar idioma** tiene que dar el idioma de la tienda; palabras por segundo; similitud con el guion; OCR en varios cuadros buscando precio o texto en otro alfabeto. Deja una **hoja de contacto** por pieza que se mira (manos, caras, texto deformado grande, logos ajenos, producto distinto del real). Con 0 rojos y hojas bien, se carga sin pasar por el dueño.
2. **Semáforo de la tienda** (sale con error): imágenes de la landing que responden, sin texto colado de otro idioma, título y descripción en el idioma, **precio del checkout publicado** visto desde el país principal, funnel de poscompra activo, link de entrega que responde, píxel presente. Un mercado en rojo **no recibe tanda**. "Una lista no frena nada; un programa que devuelve 1, sí."
3. **Auditoría de idioma del anuncio:** copy, dominio, países, filtro de idioma y OCR del video. Errores de link, copy o precio bloquean.

## La carga

- Lo producido queda en un archivo de carga por mercado. La carga lo lee y crea todo **en pausa** (con el anuncio activo adentro), para que la cola de testeo lo prenda en orden.
- **Creativos por el conector oficial de Meta, conjuntos y anuncios por script.** La app propia de los robots está en modo desarrollo y Meta no le deja crear creativos sobre publicaciones; para **leer** el molde, el script anda perfecto. Patrón: **leer con el script, escribir con el conector.**
- Para que un creativo sea comparable con los anteriores, se le pasa el **mismo spec de mejoras automáticas del molde** (todas apagadas como en el molde). Sin eso Meta las prende y el creativo no es comparable.
- Lo que el conector no copia del molde (recortes por ubicación, parámetros de URL) se repone a mano: los UTMs van como query string en el link, con el id del anuncio.
- **Numeración TEST N:** se relee el máximo de la campaña **justo antes** de crear (no al empezar la tanda). Dos sesiones cargando a la vez leyeron el mismo máximo y duplicaron ocho números.
- Después de crear el primero, se mira la **vista previa** en Instagram antes de repetir.
- Al terminar, cada archivo de la carpeta de nuevos se **renombra** con su número y se **mueve** a la carpeta de subidos: lo que queda en "nuevos" es, por definición, lo que falta subir.

## Cola de traducciones

Un robot arma cada mañana la matriz **ganador × mercado** (ganador = criterio único) y marca qué traducción falta. La fábrica tiene un cupo fijo de **2 traducciones por mercado por día**, en el mismo formato de conjunto. Una traducción cuenta como hecha solo si existe el conjunto en el mercado destino.

## Selector de cuentas de IA

Los robots con IA no llaman al modelo directo: pasan por un **selector** que, antes de correr, mide el cupo de cada cuenta y saltea las que pasan un umbral. Si una corta por límite, la marca agotada unas horas, reintenta con la siguiente con una nota de "retomá sin duplicar" y avisa. Cada robot tiene su orden de cuentas preferido. El token general sin conectores nunca va primero en robots que necesitan el conector de Meta.

## Cómo saber si la fábrica produjo de verdad

**Un robot se verifica por lo que produjo, nunca por su "[fin]".**
- Dos noches seguidas la tanda no produjo **nada** y escribía "[fin]" con el resumen normal. Causa: un texto con un signo de pesos dentro de un prompt en bash, con `set -u`, se leyó como variable y tiró cada mercado. Ahora, si ningún mercado deja su registro, avisa y sale con error.
- Tres días la carga no subió casi nada porque **el conector cambió de nombre** (mayúsculas distintas) y la lista de herramientas permitidas tenía el nombre viejo. Un agente sin supervisión no puede pedir permiso: simplemente no hace nada. Ver [[robots-que-fallan-seguros|fallar seguro]].
- Revisá también que entren conjuntos nuevos por mercado cada día, no solo que la tanda haya corrido.
