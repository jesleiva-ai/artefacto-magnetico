---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Fatiga y relevo"]
---

# Fatiga y relevo

## Punto clave
Los ganadores se cansan sin avisar; el relevo es un ángulo nuevo, no una variación cosmética.

## El llamado de atención

En diez días la ganancia diaria pasó de su mejor nivel a cero, de a poco. Nadie lo marcó porque cada día suelto "no decía nada". Al abrirlo:

- La pérdida se concentraba en cuatro mercados.
- Sus ganadores del mes anterior se habían cansado: el CPA pasó de ~0,6 T a ~1,3 T.
- El robot que saca anuncios caros los fue retirando, y **con tope de costo un creativo cansado deja de gastar**: no solo perdés margen, perdés volumen.
- Un mercado que crecía no compensaba.

**Lección:** el negocio depende de pocos ganadores por mercado. Si no hay relevo listo **antes** de que se cansen, la ganancia se va sin un día malo que lo delate.

## Cómo se detecta (la alarma de cansancio)

Un robot, cada mañana antes del informe, compara anuncio por anuncio los **últimos 3 días cerrados contra los 7 anteriores**, solo en ganadores (≥ 5 compras y gasto mínimo en la base):

- **CANSADO:** CPA de 3 días ≥ 1,5 × el de base (o cero compras habiendo gastado un CPA de base), **y** al menos una señal de desgaste: frecuencia +25 %, CTR −25 % o CPM +25 %.
- **CANSÁNDOSE:** CPA ≥ 1,25 × el de base con alguna señal de desgaste, o dos señales de desgaste con el CPA todavía bien.

No toca Meta. Escribe la lista de **relevos** que la fábrica de creativos produce **primero** en su próxima tanda.

## Fatiga anticipada (antes de que se note en el CPA)

Tres alarmas que agregamos después del golpe:

- Más del **60 % del gasto** de un mercado va a anuncios de **más de 21 días**.
- Menos de **2 ganadores frescos** (hasta 14 días, 3+ compras en 7 días) por mercado.
- El CTR de 3 días cae por debajo del **70 % del CTR inicial** del anuncio.

Y una regla adoptada de un colega: **cuando un anuncio se lleva más del 80 % del gasto** de su campaña, ya hay que estar fabricando su relevo.

## Qué es un relevo (y qué no)

**No sirve:**
- **Variaciones cosméticas.** Cambiamos gancho, voz, música, color y zoom de un ganador cansado en 15 versiones: cero compras, CTR a la mitad. Meta agrupa por lo que se **ve y se oye** (similitud creativa); si se parece, lo trata como el mismo anuncio cansado.
- **Resubir el mismo video con la metadata limpia.** Diez copias idénticas: una compra y casi sin entrega. Borrar metadata es higiene, no una palanca.

**Sí sirve, en este orden:**
1. **Reusar la publicación original** (el mismo post, con su prueba social acumulada) en la escala. Medido: ROAS 1,82 contra 1,38 de la copia nueva, con CPM 43 % más barato.
2. **Un ángulo nuevo**: un ganador vivo de **otro mercado** traducido, o un cuerpo de guion distinto. El cambio tiene que ser visual y grande.
3. Iterar el ganador **con un cambio grande**, y si una versión gana, las siguientes parten de su combinación.

## Todo ganador se traduce a todos los mercados

Cuando lo medimos, de todas las traducciones posibles (ganador × mercado) solo estaba hecho el 4 %. Nadie sabía a dónde había llegado cada ganador. Ahora:

- Un robot arma la **matriz ganador × mercado** cada día y marca qué falta.
- La fábrica tiene un **cupo fijo de 2 traducciones por mercado por día**, además de su tanda.
- Una traducción cuenta como hecha solo si existe el conjunto en el mercado destino.

Por qué importa: un robot de traducciones falló en silencio unos días (ver [[robots-que-fallan-seguros|fallar seguro]]) y dos ganadores con ROAS 4,5 y 5 no llegaron a ningún otro mercado.

**Mercado nuevo:** su primera tanda lleva siempre el ganador histórico traducido **exacto** (el mismo video, no una recreación), además de las piezas nuevas.

## El tren entre mercados

Un ganador que gana en **dos** mercados pasa a ser estándar: se traduce a todos con prioridad y entra a las escalas. Lo que gana en uno solo puede ser suerte del mercado; lo que gana en dos ya es un patrón.
