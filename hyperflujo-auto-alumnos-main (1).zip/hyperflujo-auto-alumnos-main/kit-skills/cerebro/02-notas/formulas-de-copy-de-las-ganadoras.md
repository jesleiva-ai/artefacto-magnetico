---
type: nota
created: 2026-07-28
tags: [ofertas]
source: "referencia de tercero — copy textual de 13 landings públicas ganadoras (~19.000 palabras), referencia principal kinesiologiaresuelta, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Las 16 formulas de copy", "Gatillos mentales de las landings ganadoras"]
---

# Las 16 fórmulas de copy, con la frecuencia que dice si son ley del mercado o firma de un molde

## Punto clave
Sobre el copy textual de las 13 referencias aparecen 16 fórmulas repetidas. Lo
que las hace usables no es la lista: es **en cuántas de las 13 aparece cada una**.
Las que están en 8-10 son ley del mercado y se copian sin pensar. Las que están en
3 o menos son **la firma del molde de infoproducto** — y ahí está el diferencial.

## Las que son ley (6+ de 13)
1. **Tríada de fricción antes del titular** (8/13): *Descarga inmediata · Sin
   suscripción · Acceso de por vida*. Vuelve 4 veces reformulada, nunca idéntica.
2. **Subtítulo condicional** que enumera 4 micro-dolores con qué/cómo/cuál, y
   cierra con *"dejar de X y empezar a Y"* — pivote de identidad, no de función.
3. **Antes/Con, 5 y 5, sin mencionar features** (9/13). La quinta ✓ sube a capa
   identitaria: *"más eficiente, más premium y mucho menos caótica"*.
4. **Volúmenes con el arco natural del oficio** (7/13): evaluar → planificar →
   biblioteca → progresar → protocolos → seguir. Cada línea abre con un verbo
   imperativo distinto.
5. **El precio mata dos objeciones en una línea** (8/13): *"Pago único · Paga en
   tu moneda local"*.
6. **Testimonios que citan el MECANISMO, no la emoción** (9/13), segmentados por
   sub-rol, con iniciales en vez de foto.
7. **CTA en primera persona que nombra el producto** (10/13).

## Las que son FIRMA DEL MOLDE (3 o menos) — el diferencial
8. **Culpa invertida** (3/13, solo las fábricas de infoproducto):
   *"Tu conocimiento clínico no es el problema. La falta de estructura sí."* /
   *"El problema nunca fuiste vos. Era el método."*
   Le saca la culpa al comprador y se la pone a algo comprable. Con profesionales
   funciona porque **no ataca su identidad, la protege**: el producto no le enseña
   su oficio, le ordena el que ya sabe hacer.
9. **Dolores BAUTIZADOS entre comillas**: *El "plan de rehab en blanco"*, *La
   "búsqueda infinita de ejercicios"*. Fórmula: `[artículo] "[sustantivo del
   oficio] + [estado negativo]"` + escena en segunda persona. Bautizar un dolor lo
   convierte en una cosa, y a una cosa se le compra la solución.
10. **Titular en dos tiempos y dos colores**: problema en el color oscuro,
    solución en el color de marca. El lector ve la transición antes de leerla.
11. **Garantía como promesa, no como política** (1/13):
    *"ORGANIZA TU PRÁCTICA O TE DEVOLVEMOS EL DINERO"* en mayúsculas, y el plazo
    en letra chica abajo. **El detalle más barato de copiar de todos.**
12. **Bonos con precios alternados**: 15 · 17 · 15 · 17 · 15 = 79. Nunca redondo.
    Y cada bono ataca **una etapa distinta del flujo** (entrada, planificación,
    progresión, comunicación, seguimiento). *Si dos bonos tuyos atacan la misma
    etapa, uno sobra.*
13. **™ en absolutamente todo**: producto, volúmenes y bonos. Convierte una lista
    de PDF en un catálogo de activos.
14. **FAQ que ataca la objeción de IDENTIDAD PROFESIONAL** (4/13):
    *"¿Esto reemplaza el criterio clínico?"*. Un profesional no teme que el
    producto no sirva: teme que comprarlo signifique que no sabe hacer su trabajo.
    **Toda oferta a profesionales necesita esa pregunta explícita.**
15. **Cierre en pregunta que vuelve al titular** (5/13). La página es un círculo.
16. **Popup de compra reciente** (3/13) — viene de la plataforma, no es decisión
    de copy. Copiarlo como "decisión" es un error de lectura.

## El reparto del espacio
Medido sobre kinesiologiaresuelta (13.844 px): **el 27,6% de la página es "qué te
llevás"** — volúmenes más bonos. Ningún bloque de persuasión se les acerca. Y el
**precio recién aparece al 63,6% del scroll**: antes hay siete bloques que solo
describen el problema y el contenido.

## Aplicación
Al escribir una landing propia, pasar cada bloque por esta lista. Las siete
primeras son piso; las de firma son las que despegan la oferta del resto del
mercado.

Relacionadas: [[medir-la-landing-antes-de-replicarla]].
