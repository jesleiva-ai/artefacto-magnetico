---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Guardias: los que cuidan a los que deciden"]
---

# Guardias: los que cuidan a los que deciden

## Punto clave
Guardias: los que cuidan a los que deciden. Los robots de testeo y escala deciden. Los guardias miran que esas decisiones no se desboquen, que los robots corran, y que una caída se cubra en minutos y no en horas.

Los robots de testeo y escala deciden. Los guardias miran que esas decisiones no se desboquen, que los robots corran, y que una caída se cubra en minutos y no en horas.

## Guardia nocturno con IA (la mano del dueño de madrugada)

**Para qué:** si tus mercados están en otro huso, el pico puede caer de madrugada para vos. Hace falta juicio en ese horario, sin que nadie esté despierto.

**Corre:** cuatro vueltas de madrugada (cada 2 horas), un modelo con un prompt fijo, tope de gasto de IA por vuelta y timeout.

**Lo que puede y no puede:**
- **NO llama a Meta.** Todo lo que necesita ya lo juntan los robots en disco: fotos de cada escala cada 30 min, estado de la escalera de topes, perfiles por mercado, curva horaria, configuración. El cupo de la API de madrugada es de los robots.
- **Una sola palanca:** un script que cambia el tope de **una** escala, con límites duros **en el propio script** (no en el prompt):
  - ±1 escalón por cambio;
  - entre un piso y el techo del modo (más alto solo para escalas "frenadas" que venden por encima de su meta);
  - una vez por hora por campaña;
  - bajo el candado de la configuración de escala;
  - todo queda anotado con su motivo.
- **No toca presupuestos.** Eso es de la escalera y la zanahoria.

**Qué hace en cada vuelta:**
1. Lee el informe del **auditor de robots**: qué % de sus palancas y de las reglas de los robots acertó en 7 días, por mercado. Donde una regla de subida figura "a revisar", no sube salvo evidencia fuerte (ROAS de 3 h muy por encima de la meta con 3+ compras).
2. Compara cada mercado de hoy contra su meta y contra la misma hora de días anteriores. Separa ruido (poca muestra) de señal.
3. Decide con su única palanca: en ofensivo solo sube a los que venden; fuera del ofensivo también baja a los que pierden con muestra.
4. Escribe una sección corta en su bitácora (cómo viene cada mercado, qué tocó y por qué, qué mira la próxima).
5. Si vio algo **nuevo con evidencia** (un patrón horario, cómo reaccionó un mercado a un cambio), lo agrega al cuaderno de aprendizajes de escala con los números. Si no hay nada nuevo, no escribe.
6. En la última vuelta, un resumen de la noche para el informe de la mañana.

**Lo que medimos de él:** sus cortes acertaron 8 de 9; sus subidas, 0 de 4. Por eso hoy lee el auditor antes de subir. Algunos de sus aprendizajes anotados: "con presupuestos bajos y tope moderado la madrugada gasta la mitad pero deja plata"; "con el mismo ROAS, la noche con el doble de volumen deja el doble de ganancia: el siguiente paso es destrabar volumen solo en los que superan su meta por mucho"; "a un mercado que vende de 3 a 4:30 no le sirve una suba a las 5".

**Trampas:** la sesión de la cuenta de IA puede vencer a mitad de la noche: el script reintenta una vez con otra cuenta. Y crear por cron un agente "sin restricciones" no se debe hacer: el agente se arma con herramientas acotadas.

## Guardia mecánico (sin IA)

**Corre:** cada 15 min durante la noche y la mañana.

1. **Candados tomados de más:** si el candado de un robot de escala lleva tomado más de 50 min, mata al que lo tiene y avisa.
2. **Robot quieto:** si un robot no corrió en 40 min (su estado del día sin tocar), lo corre (esperando el candado) y avisa.
3. **Escala en su pico por debajo de su piso de pico:** avisa (y si el robot está quieto, lo corre).
4. **Cuenta con el pago frenado:** avisa una vez.

Avisa **una sola vez por problema y por noche**. Nació porque una noche el robot de escala se salteó 12 horas en silencio: otro script tenía tomado su candado.

## Freno de mano

Lo llama el robot de escala en la vuelta de cada hora. Si una escala lleva un gasto mínimo del día con **ROAS cobrado < 0,8**: presupuesto a la mitad (con piso), tope un escalón abajo, cancela el pico. **Una vez por día por escala.** Avisa. Compara en el huso de la cuenta. No corre en modo ofensivo.

## Salvavidas

**Corre:** cada 15 min. Para cada mercado con respaldo:
- **Dispara** si estamos en horario de venta del mercado, la cuenta principal ya gastó algo hoy (no es el arranque), en los últimos 60 min sumó casi nada, y su escala sigue activa (nadie la apagó a propósito). Sube el respaldo a un presupuesto alto, lo da de alta en la escalera y avisa. Una vez por día por mercado.
- **Vuelve** cuando la cuenta original está al día y gasta de nuevo: el respaldo vuelve a tibio y sale de la escalera.
- Antes de armar un respaldo: chequeo liviano (filtros de idioma de la tabla oficial, nada de diásporas, mismos anuncios por conjunto). Los códigos de idioma no se ponen de memoria.

Se probó con gasto simulado: dispara el que se quedó quieto y no el que gasta.

## Termómetro de ganancia

Cada mañana: ganancia de los últimos 3 días cerrados contra **el mejor tramo de 3 días** de las últimas 3 semanas, y qué mercados explican la caída. Si está debajo del 60 %, avisa. Existe porque una caída lenta de diez días no la marcó nadie.

## Alarma de cansancio

Cada mañana antes del informe: ganadores, últimos 3 días contra los 7 anteriores (CPA, frecuencia, CTR, CPM) → CANSADO / CANSÁNDOSE. Suma su resumen al informe y escribe la lista de relevos que la fábrica hace primero. No toca Meta. Criterio en [[fatiga-y-relevo-de-ganadores|fatiga y relevo]].

**Falla que tuvo:** una mañana la API estaba frenada, no pudo leer ninguna cuenta e informó "0 cansados". Había 8. Ahora espera el freno y, si igual no lee todo, dice "ALARMA INCOMPLETA: no pude leer N de M".

## Por qué guardias separados y no un robot que haga todo

- Cada guardia tiene **una** pregunta y **una** palanca. Es fácil razonar qué puede romper.
- Si un guardia falla, el resto sigue.
- Los guardias **no deciden la estrategia**; cuidan que la estrategia se ejecute y avisan cuando algo se sale de rango.
