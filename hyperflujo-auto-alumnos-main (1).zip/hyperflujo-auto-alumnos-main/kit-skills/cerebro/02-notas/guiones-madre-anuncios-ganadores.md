---
type: nota
created: 2026-07-27
tags: [meta-ads, ofertas]
source: "referencia de tercero — guiones de 11 anuncios ganadores reconstruidos por OCR (de una tienda propia y de una alumna) cruzados con espionaje de anunciantes, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Los 5 guiones madre", "Guiones de anuncios ganadores"]
---

# Seis guiones madre se repiten en los anuncios ganadores de ofertas distintas

## Punto clave
Reconstruidos por OCR los guiones de 11 ganadores reales (2 ofertas, 2 idiomas)
y cruzados con el espionaje: arcos narrativos que se repiten, 1 en TRES fuentes
independientes. AMPLIADO 2026-07-28: el corpus de un operador brasilero (13
videos, todos los nichos) aporta el 6.º arco, calcado entre profesiones. Cuando
se pidan guiones nuevos, se parte de estos, no de teoría.

## Los guiones madre
1. **HOBBY QUE FACTURA** (el más fuerte: 3 fuentes independientes) — "empecé
   por curiosidad, sin pensar en vender → la gente empezó a preguntar → lo
   convertí en ingreso". Visto en: un anuncio de una tienda propia (ES), el
   portfolio de una alumna (EN) y un anunciante espiado (EN).
2. **CONTRASTE INJUSTO** — "hay quienes lo intentan por años sin lograrlo;
   otros lo consiguen al primer intento. La diferencia no es suerte: es la
   información". Fue el caballo de batalla de una tienda propia (el anuncio con
   más compras de la cuenta).
3. **CREENCIA LIMITANTE** — "pensaba que era complicado y para expertos, hasta
   que conocí [el sistema]". Sobre el MISMO metraje del caballo dio ROAS 2,70:
   el guion solo movió el resultado.
4. **MIEDO AL ERROR COSTOSO** — "hay errores que cuestan semanas y se descubren
   demasiado tarde: después de invertir, de esperar, de completar el proceso".
5. **VALOR PRIMERO** — mini-clase con consejos reales y accionables (20 s) antes
   del pitch (en el anuncio de la alumna: consejos de estacionalidad y
   herramientas).
6. **CAOS→SISTEMA** (2026-07-28, corpus brasilero: 13/13 videos, 5 nichos) —
   llamado al ROL ("you just graduated as a nutritionist") → inventario del
   caos (PDFs, screenshots, carpetas) → ABSOLUCIÓN con la firma "you don't
   need more random [X], you need a system" → "that's why we created [X
   Solved]" → el producto scrolleado en pantalla → "walk into every session
   prepared" + CTA. Pareado de cierre en el copy: "Stop improvising. Start
   [with a system]."
   TRANSVERSAL (tanda 2, 2026-07-28): la ABSOLUCIÓN del arranque gana en
   TODOS los mercados relevados — "no necesitás una foto nueva, sino un
   mejor fondo" (un anunciante con 28 anuncios), "las pantallas no son el
   problema, el aburrimiento sí" (otro con 13), "tu planner debería hacerte la
   vida más fácil" (un tercero). Regla: el hook ganador ABSUELVE al avatar y
   nombra un culpable nuevo. Los guiones 1, 2 y 4 aparecen VIVOS como
   story-ads de texto hiperespecífico en otro anunciante (nombre + edad +
   oficio + fecha + cifras raras: "$40... then a copyright strike... last
   month $1,247").

## Mecánicas universales (11 de 11 ganadores)
- CTA imperativo final que NOMBRA el producto.
- La objeción de habilidad muere siempre: "sin experiencia / solo seguí el
  sistema / beginner-friendly".
- El guion vende transformación y método; el descuento vive en el titular
  (escuela oferta-led) o no aparece (escuela beneficio-led).
- Voz testimonial en primera persona o directa en segunda; nunca corporativa.
- Variación barata: mismo metraje ganador + guion madre distinto = anuncio
  nuevo (regla post-Andromeda aplicada con costo cero).

## Aplicación
Pedido de guiones para oferta nueva o corriendo → elegir guion madre según
ángulo y mercado ([[patrones-visuales-y-titulares-ganadores]] para la capa
visual), adaptar con lenguaje del avatar, y marcar como hipótesis a testear.
