---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cada herramienta tiene un trabajo: elegí por lo que la toma tiene que mostrar, no por la marca de moda"]
---

# Cada herramienta tiene un trabajo: elegí por lo que la toma tiene que mostrar, no por la marca de moda

## Punto clave
Cada herramienta tiene un trabajo: elegí por lo que la toma tiene que mostrar, no por la marca de moda. El mapa de herramientas y el índice de costos.

## El mapa
| Trabajo | Herramienta | Para qué sirve mejor | Dónde falla |
|---|---|---|---|
| Agregador de modelos por API (video, imagen, música) | **APIMART** | una sola llave para Veo, Kling, Wan, Seedance, MiniMax, Suno, GPT Image, Nano Banana | archivos que expiran en ~24-72 h (bajalos siempre); se cobra por adelantado y un fallo devuelve el costo |
| Video realista barato | **Veo 3.1 Fast** | tomas realistas de 8 s, b-roll, UGC con diálogo (voz y labios juntos), «modo frame» (primer y último cuadro) | bloquea por seguridad ciertas escenas; mete franjas negras o subtítulos propios; deforma el texto de un monitor o celular en cuadro |
| Video de calidad | **Veo 3.1 Quality** | física difícil (hielo, sal, rayos) | ~7 veces el costo de Fast |
| Video con imagen de inicio y forma estable | **Kling 3.0 / v3** | tomas de personas y objetos con buena forma desde una imagen | objetos que van marcha atrás, cuerpos que cambian de forma con mucho movimiento, cámara que gira al final; no muestra rayos ni imanes |
| 3D estilo animación de estudio | **Wan 3.0 prime** | personajes 3D | más caro |
| Lip-sync con audio propio | **Wan 2.6** | imagen + audio (por URL pública) → la persona canta o habla tu pista | deforma el plano después de ~3,5 s; boca menos fina que Veo en diálogos largos |
| Video semirrealista dinámico | **MiniMax H3** | estética de cinemática de videojuego, diálogo corto en el idioma | en 8 s habla ~5 y después queda mudo; toma el prompt al pie de la letra |
| Espacio, escalas épicas | **Seedance** | planos espaciales | caro; inventa la voz si le pedís que hable |
| Imagen con texto perfecto | **GPT Image 2 / 2.5** y **Nano Banana Pro** | estáticos con texto en español, mockups, cuadros iniciales | otros modelos de imagen meten faltas o texto de más |
| Mockups de diseñador | **ChatGPT** (app o Codex en un servidor) | portadas, presentaciones del producto, recrear una imagen en otro idioma | revisar letra por letra |
| Voz | **ElevenLabs** (v3 para relato; multilingual v2 para algunos idiomas; Voice Changer para unificar voces) | locución con marcas de tiempo por palabra; voces nativas de su biblioteca | etiquetas en inglés cambian el acento; cifras sin lectura en idiomas con alfabeto propio |
| Transcripción | **ElevenLabs Scribe** / **Whisper** grande | guion desde el audio, control voz contra guion | alucina «thank you for watching» sobre música |
| Música | **Suno** (por APIMART) y **ElevenLabs Music** | canciones con letra (Suno), instrumentales de 60 s con energía hasta el final (Eleven) | Suno canta mal nombres propios la mitad de las veces |
| Montaje programático | **ffmpeg** | cortes, mezcla, medición (LUFS, negros, silencios), codificación final | ver trampas en [[montaje-con-ffmpeg-y-sus-trampas]] |
| Montaje con plantillas | **Remotion** | plantillas de video en React (captions, títulos, overlays) | pesado de instalar |
| Plataforma web de modelos | **Higgsfield** | probar modelos por interfaz o por su conector | el plan web y la API son productos distintos con saldos que no se mezclan |
| Espía de anuncios | **GetHookd**, Biblioteca de Anuncios de Meta | ganadores con días y volumen, guiones transcritos | el clonador automático inventa precios y títulos |

## Índice de costos relativos (1 = una toma de Veo 3.1 Fast de 8 s)
| Pieza | Índice |
|---|---|
| Imagen GPT Image 2 | 0,1 |
| Imagen Nano Banana Pro | 0,2 |
| Dos temas de Suno | 0,35 |
| Toma Grok de 6 s | 0,8 |
| **Veo 3.1 Fast 8 s** | **1** |
| Lip-sync Wan 2.6 de 5 s | ~1,8 |
| Kling v3 std 5 s desde imagen / MiniMax H3 6 s / Wan 3.0 5 s | ~2,4 |
| Kling v3 pro 6-8 s | ~3,9 |
| Wan 3.0 prime 6 s | ~4,4 |
| Seedance 2.0 5 s | ~5 |
| Veo 3.1 Quality 8 s | ~7 |
| Seedance 2.5 8 s con audio | ~12 |
| Un anuncio completo de los estilos (guion, voz, 6-12 tomas, música, mockup) | ~7-17 |
| Portar un ganador a otro idioma (solo voz) | ~1,5 |
Con un saldo chico se hace una tanda entera de 5 estilos; el costo grande es humano (revisar), no de generación.

## Cómo aplicarlo
- **Dividí el saldo por el costo por pieza antes de arrancar** y comparalo con la tanda completa. Si no alcanza, avisá
  antes: con el saldo en cero se corta a mitad y se pierde lo encargado.
- Probá 2-3 modelos con **una toma de 5 s** antes de comprometer la tanda: el modelo decide más que el prompt.
- Bancos gratis (Pexels, Mixkit, Pixabay) antes que generar, para b-roll literal ([[el-guion-solo-nombra-lo-que-hay-en-el-banco]]).
- Saldo compartido entre varias personas: el gasto propio se suma de lo **facturado por tarea**, no por diferencia de
  saldo.

Relacionadas: [[cada-modelo-de-video-tiene-su-trampa]] · [[molde-de-tanda-guion-voz-planes-montaje]]
