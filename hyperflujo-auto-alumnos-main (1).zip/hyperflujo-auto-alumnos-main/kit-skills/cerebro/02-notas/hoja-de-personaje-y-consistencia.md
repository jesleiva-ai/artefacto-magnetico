---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un personaje se mantiene igual entre tomas con una hoja de personaje, una descripción fija y su nombre en cada prompt"]
---

# Un personaje se mantiene igual entre tomas con una hoja de personaje, una descripción fija y su nombre en cada prompt

## Punto clave
Un personaje se mantiene igual entre tomas con una hoja de personaje, una descripción fija y su nombre en cada prompt. Character Bible, nombrar siempre, referencia con medida.

## La regla
Si un personaje aparece en más de una toma (presentadora, personaje 3D, figura de marca), antes de la tanda se hace su
**hoja de personaje**: frente, perfil, tres cuartos, espalda, expresiones (contento, sorprendido, preocupado), poses
clave y un frente limpio a 9:16, más **una descripción fija en inglés** para pegar en cada prompt.

## Por qué
- Sin referencia, los modelos de video dan personas «parecidas»: misma ropa, otra cara.
- Con «he/she/his» en vez del nombre, un modelo cambió de cara entre tomas: la descripción fija solo entraba si la toma
  nombraba al personaje.
- Una mascota de marca que ya aparece en el producto (por ejemplo, la gota sonriente de una guía de huerta) cambiaba de
  forma y de color entre tomas. Su versión oficial es la que más se repite en las piezas que ya existen, y la hoja se
  hace a partir de esas piezas (ChatGPT con las piezas de referencia lo resolvió).

## Cómo aplicarlo
- **Character Bible**: un párrafo con rasgos, ropa, colores y materiales, repetido **palabra por palabra** en cada
  prompt. Un cambio de una palabra cambia al personaje.
- **Nombrá al personaje en cada toma** (con una clave en el guion que el generador reemplaza por la descripción), nunca
  con pronombres.
- **Referencia de imagen**: en imagen → video da la misma cara, pero en algunos modelos deja al personaje posando (~30 %
  menos de movimiento). Usala en las tomas donde importa la cara (habla, primer plano) y dejala afuera en las de acción.
- **Varios personajes**: con dos personajes mencionados en una toma, el modelo los confunde. Mencioná solo al que habla.
- **Personas distintas por video** si el formato es explicador; **elenco fijo** solo si el formato lo necesita.
- Para variar ángulos de la misma persona (multicámara): Nano Banana Pro con la foto original como referencia.
- Diseños **originales**: los modelos tienden a reproducir personajes de películas; revisalo en la hoja.

Relacionadas: [[prompts-de-imagen-decir-que-va-no-que-no]] · [[estilo-personaje-3d-que-habla]]
