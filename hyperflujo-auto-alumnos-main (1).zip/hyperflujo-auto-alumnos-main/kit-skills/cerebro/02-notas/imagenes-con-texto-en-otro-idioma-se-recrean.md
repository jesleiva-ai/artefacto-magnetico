---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Las imágenes con texto en otro idioma se recrean con IA tomando la original de modelo: rotularlas por código se nota"]
---

# Las imágenes con texto en otro idioma se recrean con IA tomando la original de modelo: rotularlas por código se nota

## Punto clave
Las imágenes con texto en otro idioma se recrean con IA tomando la original de modelo: rotularlas por código se nota. Recrear con IA, auditar letra por letra.

## La regla
Toda imagen con texto (mockups, estáticos, imágenes de landing, upsells) que va a otro idioma se **recrea** con ChatGPT /
GPT Image tomando la original de modelo. Nunca se borra el texto y se pega uno nuevo por código: «se nota que borraste
algo abajo y arriba le pegaste un texto nuevo» (recuadros, letra plana sobre un diseño 3D, bordes finos).

## Cómo
- Dos imágenes al modelo: **IMAGEN 1** = la original (recrear idéntica, mismo diseño), **IMAGEN 2** = la versión del
  idioma si existe (solo para leer qué dice). El pedido lleva **la lista completa de textos letra por letra** y una nota
  de ortografía del idioma.
- **Cada pieza la audita un agente** leyéndola letra por letra con recortes ampliados: cerca de 1 de cada 5 sale con un
  error de una letra, casi siempre en el texto más chico (bordes y laterales del mockup 3D, textos chicos del mockup). Típicos: tildes inventadas, una diéresis o doble acento cambiado por otro
  signo, el punto de una letra fuera de lugar, sílabas perdidas, un diacrítico cambiado por otro, restos del texto viejo al pie de
  las piezas pequeñas, la marca agregada como logo.
- **Si un error se repite**: 2-3 variantes en paralelo y se elige la perfecta. Si el modelo copia un signo de la
  original (una tilde que en el idioma nuevo no va), se cambia la IMAGEN 1 por una versión ya aprobada de otro idioma
  que no tenga ese signo.
- **Aceptado sin rehacer** (criterio fijado de antemano): la marca bien escrita agregada como sello; un garabato
  ilegible a tamaño real; una mayúscula de estilo.
- **Subir con nombre nuevo** (no pisar la URL vieja: la caché sirve la anterior) y verificar en la página publicada que
  todas las imágenes sean las nuevas.

## Por qué
La prueba recreada se aprobó a la primera («quedaron hermosas»); las rotuladas por código se rechazaron en todos los
idiomas. Y hacerlo con la suscripción de ChatGPT no consumió créditos de generación aparte.

## Error típico
«Provisoriamente la rotulamos por código y después la rehacemos.» Lo provisorio se publica y queda.

Relacionadas: [[mockups-nivel-agencia]] · [[traducir-un-ganador-exacto]]
