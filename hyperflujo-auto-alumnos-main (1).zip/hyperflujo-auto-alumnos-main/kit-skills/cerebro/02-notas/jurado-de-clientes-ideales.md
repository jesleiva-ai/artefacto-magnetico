---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Jurado de clientes ideales"]
---

# Jurado de clientes ideales

## Punto clave
Un jurado de **10 clientes ideales por mercado** (perfiles distintos del comprador típico, con contexto del país) que juzga cada creativo **antes de salir**, lo vuelve a juzgar con lo que pasó, y aprende de sus errores.

Un jurado de **10 clientes ideales por mercado** (perfiles distintos del comprador típico, con contexto del país) que juzga cada creativo **antes de salir**, lo vuelve a juzgar con lo que pasó, y aprende de sus errores.

## Por qué así

Un colega midió que **un jurado de IA sin calibrar acierta como el azar.** Por eso el diseño:
- Vota **a ciegas**: sin el nombre del anuncio (los nombres dicen "GANADOR"), sin números.
- Se cuentan **todas** las piezas, no solo las que recordamos.
- Cada miembro **pesa según acierta**: peso inicial según qué tan típico es (típico 1,0 · medio 0,7 · borde 0,4) × su tasa de acierto. Los que fallan mucho con muestra suficiente se reemplazan.
- **Es consejo, no compuerta:** no frena ni prende nada hasta que en un mercado acierte ≥ 70 % "vende / no vende" con ≥ 20 piezas cerradas.

## El ciclo

1. **Previo** (al terminar la tanda, sin tocar Meta): para cada pieza arma una hoja de 12 cuadros (los primeros 3 s = gancho), una ficha extra del gancho (0-4 s cada medio segundo), la locución transcripta localmente y **medidas objetivas** (cortes, segundos por plano, cortes en el gancho, cuándo arranca la voz, palabras por minuto, % con voz, volumen). Cada miembro vota en primera persona, pone notas 1-10 (gancho, voz, ritmo, impacto, creatividad) y "lo que más me pegó". El jurado llena una planilla de 9 parámetros con su porqué, pronostica **GANADOR / VENDE / NO VENDE** y clasifica la apuesta (VARIACIÓN / NUEVA / TRADUCCIÓN / COPIA).
2. **En la cancha:** todo anuncio activo que el jurado no vio se juzga igual, a ciegas, por la pieza real (id del video o hash de la imagen), con un tope por mercado por día. Hallazgo que lo motivó: **el jurado nunca había visto el 83 % de lo que corría** (solo veía lo de la fábrica, no lo que entraba por otros caminos).
3. **Revisión a los 3 días** con gasto mínimo: acierto SÍ / NO / TEMPRANO + conclusión provisoria.
4. **Final** al apagarse, coronarse ganador o a los 14 días, **con lo cobrado**: cada miembro se autocritica, el jurado reescribe su libreta de aprendizajes del mercado (máximo 40 viñetas, con evidencia) y la sección de lecciones que la fábrica lee antes de producir.
5. **Historia:** se le pasó todo lo ya lanzado (el histórico de anuncios, con lo cobrado por anuncio), juzgando a ciegas una muestra por mercado de ganadores, vendedores y perdedores caros, para calibrarse de entrada.

## Injerencia sobre la producción

- **Plan de hipótesis:** máximo 3 abiertas por mercado, cada una sale de evidencia, al menos una es innovación real (nunca cosmética). Se cierra con 3 piezas (CONFIRMADA / DESCARTADA con lo cobrado). La fábrica dedica los primeros conjuntos de la tanda a la hipótesis prioritaria, **sin sumar volumen**.
- **Vigía del jurado:** alarmas por mercado (renovación baja, repetición, sin ideas nuevas en 7 días, ganadores sin variación, hipótesis quietas) → órdenes por mercado que la fábrica **tiene** que cumplir dentro de su volumen (1 variación de lo que vende + 1 idea nueva). Si no puede, anota por qué; no se saltea en silencio.
- **Semana:** consolida lecciones, elige **una** innovación común para todos los mercados, reemplaza a los miembros que aciertan poco y manda 3 líneas de resumen.

## Lo que midió (la parte honesta)

- Con una muestra grande de piezas cerradas, el acierto global "vende / no vende" ronda el **63 %**. Solo unos pocos mercados pasaron la vara de calibración.
- **Ganadores anticipados: casi ninguno.** El jurado es bueno diciendo "esto no vende" (la mayoría no vende, así que es fácil) y malo encontrando al que explota.
- En la planilla, las notas medias de lo que vende y lo que no se diferencian por décimas. **Ningún parámetro solo predice las ventas.**

**Conclusión:** el jurado sirve como **memoria del mercado** (qué ángulos ya fallaron, qué aprendimos) y como presión para innovar, no como oráculo. Que su opinión no frene nada hasta que acierte con muestra es lo que evita que un modelo seguro de sí mismo apague ganadores.

## Reglas operativas

- Un informe incompleto no es cero: sin lo cobrado no se cierra ningún veredicto.
- La voz no se escucha: se juzga por guion y medidas.
- Si la cuenta de IA del jurado se queda sin cupo, el previo y el seguimiento fallan; eso tiene que avisarse, no pasar en silencio.
