---
type: nota
created: 2026-07-30
tags: [ofertas]
source: "referencia de tercero — medición del render y del código fuente de dos landings públicas de IA para una profesión, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["La paleta se mide, no se elige", "Contar familias de tono", "Saturación del acento"]
---

> Referencia de tercero: es una opinión medida sobre landings ajenas, no canon.
> No sirve como base para tocar una campaña, un precio o un presupuesto.

# La paleta se mide: contá familias de tono y mirá el render, no el CSS

## Punto clave
Elegir paleta deja de ser gusto cuando se convierte todo a HSL. Dos números
deciden casi todo: **cuántas familias de tono hay** (1-2 = diseñada, 5+ = armada
por acumulación) y **cuánta saturación tiene el acento** (≤60% lee prestigio,
≥80% lee descuento). Los dos se miden con la herramienta de paleta
(`paleta.py`), que fotografía la página y muestrea píxeles.

## Lo que disparó esto
Al comparar, la landing de referencia se veía sofisticada y la otra no, usando
el mismo dorado. La diferencia era un solo número: `hsl(45 55% 55%)` contra
`hsl(38 92% 50%)` — el segundo es `amber-500`, el default de Tailwind. **Mismo
tono, 37 puntos más de saturación.** Eso separa "estudio jurídico" de "curso de
Hotmart".

## Las reglas, todas verificables
- **Saturación del acento ≤60% en nichos que venden prestigio** (abogados,
  contadores, escribanos, arquitectos). Arriba de 80% el mismo tono se lee barato:
  la saturación alta es la firma visual del descuento y el comprador ya la tiene
  catalogada.
- **Contá familias de tono, con piso de 0,4% de la página.** Sin ese piso se cuenta
  el antialiasing de los bordes de letra como si fuera una decisión de diseño.
  Medido: la referencia de ese nicho tiene 220 navy + 45 oro + 131 verde (dos de
  estructura, una semántica). La otra landing tiene **una sola**, todo entre 191°
  y 202°. Cinco familias = nadie manda.
- **Los neutros no son grises: son el acento desaturado.** La crema de la
  referencia es `hsl(45 20% 92%)` — el mismo 45° del oro con la saturación baja. El
  gris apagado es `hsl(223 14% 55%)`, el mismo 220° del navy. Un gris de saturación
  0% delata que nadie lo eligió.
- **Un solo color reservado para la plata.** En la referencia el verde no aparece
  en ningún otro lado: ni un ícono, ni un ✓, ni un borde. Sólo el botón que cobra.
  Por eso el ojo lo encuentra sin buscarlo.
- **60/30/10 medido**: en esa landing el fondo se come el 21% de los píxeles
  muestreados y cada acento vive en menos del 2%.
- **En fondo oscuro la elevación no es sombra, es superficie.** Una sombra sobre
  negro no se ve: lo que levanta una tarjeta es ser más clara que el fondo (+3%,
  +5% de luminosidad) más un aro de 1px. Cada sombra lleva su `inset 0 0 0 1px`.
- **Al invertir el fondo los roles se reasignan, no se intercambian valores.** En
  claro la tinta es oscura; en oscuro la tinta pasa a ser la crema y el acento
  manda.
- **Compuerta de contraste, no criterio**: texto ≥4.5:1, botón ≥3:1. Si da rojo no
  se publica aunque sea la más linda.

## El hallazgo que obliga a mirar el render
En la referencia la variable se llama `--primary` y vale oro. **El botón que cobra
es verde** (`#57B468`). El nombre de la variable no es el rol que cumple en
pantalla: leyendo tokens se erraba el color de acción. Corolario general — para
paleta se mide el render; el CSS sirve para los valores exactos, no para los roles.
Cruza con [[medir-la-landing-antes-de-replicarla]] y con
[[2026-07-30-cerebro-ia-replicar-pide-el-fuente]].

## Decisión 2026-07-30
Sobre una página de oro y navy, el verde de la referencia metía una tercera
familia y "se veía raro". Se retiró: **todos los botones del mismo color**. La
paleta quedó en dos familias — más disciplinada que la referencia que se estaba
modelando.

## Relacionadas
[[medir-la-landing-antes-de-replicarla]] ·
[[patrones-visuales-y-titulares-ganadores]]
