---
type: nota
created: 2026-07-25
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["La landing es un tobogán: sin botones arriba"]
---

# La landing es un tobogán: cero botones arriba, cero flotantes, cero WhatsApp

## Punto clave
Regla dura: NINGÚN botón de compra en las secciones superiores de la landing, ningún botón flotante, ningún botón random. La landing es un tobogán: cuanto más lee el usuario (dolores → beneficios → bonus → precio), más motivos del "por qué sí" — un botón arriba corta esa reafirmación y quema tráfico. "Ninguno de los casos de éxito tiene un botón en la parte superior."

## Detalle
- Caso en vivo (masterclass 23-07): a una alumna se le frenaron las ventas al agregar un botón con despliegue de upsells en el hero. Diagnóstico inmediato: ese botón impedía que el tráfico se reafirmara leyendo.
- El botón de WhatsApp flotante en una tienda low-ticket es INESCALABLE: las preguntas que llegan ya están respondidas en la landing; "la persona se tiene que autogestionar en tu tienda, si no sos un autoempleado". (Coherente con la frontera ofertas ≠ ventas: el low-ticket es compra directa, nunca cierre por chat.)
- Orden recomendado: scroll de dolor + beneficios → botón de comprar → debajo bonus, FAQ, testimonios. Los CTA repetidos van del bloque de oferta hacia abajo, jamás arriba.
- "Tocar códigos y agregar cositas se siente divertido, pero esto es simple: distinguir qué es relevante y qué no."

## Refinamiento 2026-07-30: el botón ancla
Se aceptó un botón grande en el hero — el de un molde de referencia de un
tercero — **con una condición que cierra la tensión que estaba abierta**: todo
botón que no esté dentro de la caja de oferta **no cobra, baja hasta ella**. El
único que va al checkout es el de adentro del bloque de precio.

Con eso el molde conserva su botón arriba (que visualmente ancla y da confianza)
sin romper el tobogán: arriba nadie compra, arriba te mandan al precio. La regla
completa queda: **cero botones de COMPRA arriba; los que haya arriba son anclas.**

Esto además resuelve la tensión con las referencias que llevan un botón en el hero:
no hay que elegir entre su hero y esta regla — se implementa como ancla y convive
(`data-ir-oferta` + `scrollIntoView`).

## Confirmación medida 2026-08-23
La regla dejó de ser criterio y pasó a tener número. En una landing propia de IA
para un oficio, el CTA de la sección de videos —al **31% de la altura**, antes del
bloque de precio— cobraba en vez de anclar. Resultado en 43 días:
**247 llegaron al carrito y solo 31 tocaron pagar (12,6%)**, mientras el checkout
convertía al 64,5%. Es decir: **216 personas llegaron al carrito sin haber visto
nunca el precio**, y el carrito hizo de página de precio.

Al pasarlo a ancla (`href="#ofb-oferta"` + `scrollIntoView`, el mismo mecanismo de
las otras landings del molde), el escalón dejó de depender de la distancia física.

**Corolario para medir después de aplicarla:** los agregados al carrito **caen**, y
está bien — eran los que llegaban a ciegas. La métrica pasa a ser el % que alcanza
el bloque de oferta (mapa de scroll) y los checkouts iniciados.

## Aplicación
Auditoría de 10 segundos en cualquier landing propia o de alumno: ¿hay algún botón antes del bloque de oferta o flotando? Sacarlo. Después validar con Clarity si el tráfico llega más abajo.
