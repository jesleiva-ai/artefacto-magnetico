---
type: nota
created: 2026-09-02
tags: [productos-digitales, ofertas]
source: "referencia de tercero — clase del fundador de una plataforma de tiendas en una mentoría, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Las seis ofertas del post-compra", "Qué vender en el post-compra", "Tipos de upsell post-compra"]
---

# En el post-compra hay seis tipos de oferta, y el ebook extra es el peor de todos

> Es la opinión del dueño de una plataforma de tiendas, con acceso a la data
> agregada de todas sus tiendas, dada en una clase de mentoría.

## Punto clave
El error que mata el backend no es el precio ni el diseño: es **agregar por agregar**.
Textual: *"no es agregar por agregar, es realmente que la persona lo necesite"*.
Cada uno de los seis tipos ataca una razón distinta por la que alguien que ACABA de
pagar vuelve a sacar la tarjeta. Poner tres ebooks más al 50% funciona —*"venden,
joya"*— pero es el piso, no el techo.

## Los seis tipos

1. **Complemento necesario** — lo que hace falta para poder usar lo que ya compró.
   No es "más", es "sin esto no arranca". Su ejemplo: *"tenés el método, ahora
   necesitás las herramientas"*.
2. **Acelerador** — la misma promesa, en menos tiempo. Vende velocidad, no
   contenido: *"si ya tenías bajar 50 kilos en 3 meses, ahora además tener la
   inyección mágica que lo hacés en una semana"*.
3. **Prevención de errores** — lo que evita que el método fracase. Trabaja el miedo
   a haber comprado algo que no le va a funcionar.
4. **Versión premium / pro / hecho por vos** — plantillas, recursos, prompts,
   archivos listos, cursos grabados. El salto de "te explico cómo" a "acá está
   hecho": *"vos estás vendiendo ebooks, pero si aparte le das una plantilla, un
   prompt, videos tutoriales, cambia la oferta"*.
5. **Paquete o conjunto** — todo junto, con el volumen como argumento.
6. **Membresía recurrente** — el único que cambia el modelo de negocio y no sólo el
   ticket. Cuenta el caso de alguien que se hizo la plata con una **mini app** en
   suscripción sin vender ebooks: *"diez mil personas suscriptas a 10 dólares"*.

## Advertencias sobre el tipo 6, medidas contra el panel
- **El pago recurrente NO apareció en el panel** en el recorrido completo del
  2026-09-02: los productos son principal, bonos y upsells, todos de pago único.
  La plataforma afirma que se puede. Es la única pieza de la clase que no se pudo
  confirmar contra el producto. **Confirmarlo antes de diseñar una membresía.**
- Las **mini apps** las aclaró él mismo: en la plataforma *"lo va a hacer, todavía
  no, es un proyecto"*.
- **Novedad del 2026-09-02** (llamada de mentoría): la membresía **está en
  desarrollo activo y con fecha estimada**, no es una idea suelta. Textual: *"va a
  estar la posibilidad de crear una membresía a tu producto (…) está en pleno
  desarrollo, hoy está en una partecita avanzada, pero ya en las próximas semanas
  va a estar"*. El pitch que se dio: *"¿te gustaría recibir actualizaciones
  mensuales o trimestrales por 5 dólares mensuales?"*, multiplicado por la base de
  clientes ya adquirida — *"de 1.000 a 5.000 dólares recurrentes sin ads, porque la
  adquisición de tu tráfico ya la hiciste"*. **Sigue sin verse en el panel**: la
  advertencia de arriba vale igual, lo que cambió es que ahora hay una fecha
  declarada contra la cual chequear.
- El argumento con el que se vendió, que es el que conviene retener: el caso de
  **10.000 ventas de un producto digital** cuyo comprador *"no se capitalizó para
  adelante, porque es algo que no se hacía en la industria"*. La membresía no sube
  el ticket de una venta: **convierte una base de compradores vieja en ingreso
  nuevo sin volver a pagar tráfico.**

## Cómo se cruza con lo que ya teníamos
El método de pricing pide **tres upsells en tres dimensiones distintas** —más
contenido, otro flujo, entrega a terceros— para que no sean "más de lo mismo".
Los seis tipos son una taxonomía más fina del mismo principio: el "acelerador" y la
"prevención de errores" no estaban nombrados, y son los dos que más se parecen a un
mecanismo único ([[stack-bonuses-oferta-irresistible]]).

Dónde se configura cada uno: [[el-embudo-post-compra-en-impultienda]].
Por qué conviene poner acá lo mejor: [[el-post-compra-es-lo-unico-que-no-te-copian]].
