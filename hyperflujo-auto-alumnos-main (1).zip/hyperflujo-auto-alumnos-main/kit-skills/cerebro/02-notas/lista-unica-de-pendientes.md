---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Lista única de pendientes (\"el jefe\")"]
---

# Lista única de pendientes ("el jefe")

## Punto clave
Con varias sesiones de IA abiertas, robots corriendo y decisiones que el dueño toma por chat, los pendientes se pierden: cada sesión anota en su lado y nadie ve el conjunto. El jefe es **una sola lista**, un **norte** y una **siguiente jugada**, para que nada se pase y la energía vaya dirigida.

Con varias sesiones de IA abiertas, robots corriendo y decisiones que el dueño toma por chat, los pendientes se pierden: cada sesión anota en su lado y nadie ve el conjunto. El jefe es **una sola lista**, un **norte** y una **siguiente jugada**, para que nada se pase y la energía vaya dirigida.

## Qué es

- **Una fuente única** en el servidor: los pendientes (cada uno con dueño, origen, estado, prueba), el norte (frase, qué construimos, metas, siguiente jugada, frentes, lo que no hacemos) y una bitácora de cada vuelta.
- **Un solo comando** para tocar la lista: ver, resumen, agregar, mover, hecho, descartar, cambiar, publicar. Desde cualquier máquina va por conexión al servidor: no hay copias que se desfasen.
- **Una página** que el dueño mira, que lee en vivo el estado publicado.

## El robot

- **Dos vueltas por día** (mañana y noche), con un modelo mediano.
- **Sin acceso libre a la terminal.** Un script le junta el contexto (disco, notas calientes, crontab, fallas de los logs, números del día) y su **único comando** es el de la lista. Escribe solo en su carpeta.
- A la mañana manda un parte corto; a la noche, solo si hay algo urgente para el dueño.
- Los campos del norte que son del dueño (la frase, qué construimos, lo que no hacemos, lo que está "a confirmar") **el robot no los toca**.

## Cómo se alimenta

- **Cada sesión de trabajo**, cuando cierra, avanza o descubre un pendiente, lo anota en el momento con el comando. **Sin prueba no se cierra.**
- **Al arrancar** cada sesión, un hook le muestra el norte, la siguiente jugada y sus primeros pendientes.
- **Cosecha de chats:** tres veces por día, un proceso local junta lo dicho en los chats y otro agente (con un solo permiso: el comando de la lista) lo convierte en altas, avances y cierres. Las transcripciones **no se suben** al servidor: pueden traer claves.

## Reglas de dueño

- **El dueño humano** solo lleva lo que nadie más puede hacer: pagar, tarjetas, logins con su cara, compartir desde su cuenta, plata fuera del mandato, precio, marca, qué se vende.
- Todo lo demás lo lleva la IA o el equipo.

## Lo que encontró al sembrarla

Al barrer memorias, notas y logs para la primera versión salieron decenas de pendientes y **once contradicciones de metas** (ROAS meta distintos en distintos lugares, inversión vs ganancia, países como conjunto vs como campaña). La lista no solo ordena: deja a la vista lo que se decidió distinto en dos lados.

## Trampas técnicas

- En la lista de permisos de un agente sin supervisión, una ruta absoluta para editar lleva **doble barra** al principio; con una sola, el agente no pudo editar.
- Una regla de "escribir" no alcanza: las reglas de edición cubren todas las herramientas de escritura.
- El norte vigente es el del servidor; cualquier copia local es solo semilla.
