---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Lo que se ve coincide con lo que dice la voz, el plano 0 es un gancho literal y el producto entra a la mitad"]
---

# Lo que se ve coincide con lo que dice la voz, el plano 0 es un gancho literal y el producto entra a la mitad

## Punto clave
Lo que se ve coincide con lo que dice la voz, el plano 0 es un gancho literal y el producto entra a la mitad. Plano 0 literal, producto a la mitad, b-roll sin repetir.

## La regla
Cuatro reglas de montaje que valen para todo video:
1. **Imagen = voz.** Si la voz dice «las raíces se ahogan», en pantalla hay raíces en agua. Un plano genérico sobre
   un dato concreto es un plano perdido.
2. **El plano 0 es un gancho visual literal, raro y con impacto**, de al menos 2,5-3 s: algo que frene el pulgar,
   aunque no sea el producto (una transformación hipnótica, un objeto en un lugar imposible, una acción extrema).
3. **El producto NO abre el video.** La primera mitad entera muestra solo b-roll. El producto entra **cuando el
   guion lo nombra** y los mockups van al final, con la oferta y el CTA.
4. **Ningún b-roll se repite.** Si hay que mostrar la masa tres veces, son tres tomas distintas de masa. Tope: dos
   usos por clip por video.

## Por qué
- Un mockup en el cuadro 1 se lee como publicidad y el pulgar sigue de largo. Las tandas que abrieron con el
  producto o con un plano genérico («alguien tomando café», «una lámpara») fueron rechazadas en revisión y rehechas.
- En el ganador propio más grande (la mayoría de las compras de su cuenta durante semanas), el montaje era
  exactamente esto: abre con una imagen hipnótica que no tiene que ver con el producto sobre la primera palabra, el
  producto aparece al nombrarlo, cada ítem del contenido coincide con una muestra real del contenido (una pantalla, un paso, una plantilla), y cierra con el
  producto completo iluminado.
- En el mismo ganador, **la segunda imagen también pesaba**: al probar relevos, se cambiaba solo la primera y se
  conservaba la segunda.
- Un banco con muchos clips no garantiza variedad: la primera versión de una tanda repetía el mismo clip tres o
  cuatro veces en 20 s. Con un tope de 2 usos y rotación entre clips de la misma etiqueta, 920 planos usaron 859
  clips distintos.

## Cómo aplicarlo
- Escribí el guion con **un sustantivo concreto por frase** y anclá cada plano a una frase, no a un reloj: cuando la
  voz dice la palabra, entra la toma (los tiempos salen de la locución con marcas de tiempo).
- Catalogá el banco **antes** de escribir: el guion solo nombra lo que existe
  ([[el-guion-solo-nombra-lo-que-hay-en-el-banco]]).
- Forzá el plano 0 desde el montador (un parámetro tipo «gancho forzado» con duración mínima) y rotá los ganchos
  entre tandas para que no se repita la apertura.
- El filtro «nada de producto en la primera mitad» tiene que estar en **todos** los caminos del montador, incluidos
  los de respaldo: un clip etiquetado «escena de cocina» que muestra el mockup al 30 % pasa por etiqueta.
- Cortes de 1-3 s por plano. Una toma de 5-8 palabras de voz por plano. El bloque de producto dura 4-5 s como máximo
  con cortes cada 1-1,5 s.
- Si el que decide el gancho visual te manda material, ese material manda (y se audita igual que el propio).

## Error típico
- Abrir con el producto «para que se vea qué vendemos».
- Clips del banco con el producto colado en la primera mitad porque la etiqueta no lo decía.
- La voz dice «sin planillas» y en pantalla hay una planilla. Cada frase se chequea contra su plano.

Relacionadas: [[el-creativo-escalado-tiene-seis-bloques]] · [[el-producto-en-pantalla-es-siempre-el-real]]
