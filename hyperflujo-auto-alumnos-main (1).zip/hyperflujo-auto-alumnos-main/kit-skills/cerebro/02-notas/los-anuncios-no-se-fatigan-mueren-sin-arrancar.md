---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Casi ningún anuncio muere por fatiga: la gran mayoría nunca arrancó"]
---

# Casi ningún anuncio muere por fatiga: la gran mayoría nunca arrancó

## Punto clave
Casi ningún anuncio muere por fatiga: la gran mayoría nunca arrancó. El 91 % de los muertos nunca arrancó.

## La regla
Antes de hablar de «fatiga», medí la frecuencia. Lo normal es que un anuncio que no vende **nunca haya funcionado**,
no que se haya cansado. La respuesta no es «esperar a que madure» ni «refrescarlo»: es testear más piezas distintas
y apagar a tiempo las que no arrancan.

## Por qué (lo medido)
- En cuentas propias, de todos los anuncios que murieron en ~3 meses, el **91 % nunca funcionó** y menos del 1 % se fatigó. La frecuencia de
  vida mediana fue 1,08 (p90: 1,25); casi nadie llegó a 2,0, y la frecuencia diaria no sube con la edad del anuncio.
- Un operador de la comunidad midió lo mismo en otro nicho (frecuencia de vida mediana 1,28 en ~140 anuncios).
- Lo caro de verdad fue **apagar anuncios sanos** por migración o limpieza: un grupo con CPA bueno se cortó sin motivo.
- Las ventas se reparten en **demasiados conjuntos**: con muchísimos conjuntos activos y pocas compras por conjunto, el 20 %
  del gasto se fue a conjuntos con 0 compras. Menos conjuntos con más presupuesto concentra el aprendizaje.
- Que **editar** un conjunto encarezca no se confirmó: el CPA subió igual en ventanas sin tocar que tras editar.

## Cómo aplicarlo
- Testeo con reglas fijas (por ejemplo: a un gasto equivalente a ~1 CPA objetivo sin compra, o con CPA muy por encima
  del objetivo, se apaga), y un día sin ventas no dice nada: se juzga con 3 días o más.
- Volumen de piezas distintas todos los días, en cada mercado, con más peso donde más se vende.
- Anotá **antes de prender** qué creativo creés que va a ganar y por qué. Al juzgar, contrastalo: así sabés si tu
  criterio predice o si estás adivinando.

## Error típico
Tratar cada anuncio que no vende como «fatigado» y producirle variantes. Si nunca arrancó, sus variantes tampoco.

Relacionadas: [[cada-renovacion-mezcla-formatos]] · [[un-ganador-cansado-se-revive-con-su-post]]
