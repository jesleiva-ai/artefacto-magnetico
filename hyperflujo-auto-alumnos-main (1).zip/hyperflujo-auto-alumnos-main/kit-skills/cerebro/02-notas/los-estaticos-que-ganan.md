---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El estático que gana muestra un pedazo real del producto, y se genera con el texto fijado palabra por palabra"]
---

# El estático que gana muestra un pedazo real del producto, y se genera con el texto fijado palabra por palabra

## Punto clave
El estático que gana muestra un pedazo real del producto, y se genera con el texto fijado palabra por palabra. Muestra real, tres beneficios, clon con zona verde.

## La regla
Los estáticos no son relleno: en las cuentas propias, el estático con **una muestra real del contenido** dio el mejor
CPA de la marca (~13 % más bajo que el video héroe). Por eso 1 de cada 3 anuncios de una tanda es un estático. Tres
moldes que funcionaron:
1. **Muestra real**: una pantalla, un paso, una plantilla tal cual está en el entregable, con un titular-gancho
   arriba y el mockup real abajo.
2. **Tres beneficios**: kicker → tres beneficios en mayúscula → banda «con más de N [ítems]» (el N real) → cierre
   contra la alternativa cara → el producto en un dispositivo, en un escenario que evoca el tema.
3. **Clon de un estático ganador ajeno** con texto propio y zona verde para el producto real.

## Ejemplo del molde 2 (guía de yoga en casa, inventada)
«Lo que tu cuerpo te viene pidiendo» → DORMIR MEJOR · MÁS ENERGÍA · MENOS RIGIDEZ → «con 120 rutinas de 10 minutos» →
«con lo que ya tenés en tu living» → el celular con la portada real sobre un mat.
Versión suave para Meta: sin plazos («en 7 días»), sin promesas de salud («aliviarás dolores»), sin «sin depender de
medicación».

## Por qué
- El estático de tres beneficios es un molde que funcionó muy bien en su momento en otro nicho; ahí se volvió
  plantilla.
- En la competencia, los estáticos pesan entre el 12 % y el 35 % del inventario de las marcas que más escalan. Clonar
  rinde con estáticos de **meses corriendo**: la captura de una app de notas con «3 señales», la placa de «oferta
  limitada», la página-despedida «nos estamos despidiendo de…».

## Cómo aplicarlo
- **Género antes que calidad**: antes del prompt, nombrá el género de la pieza (foto de estudio del producto · gráfica de
  venta densa con sello, bullets con ícono, fila de mini-portadas y franja de garantía · captura de app · packaging shot).
  Un lote entero de fotos de estudio prolijas fue rechazado en bloque porque se pedía gráfica de venta densa. Un
  rechazo en bloque casi nunca es de calidad: es de género. Pedí la referencia **antes** de la primera tanda.
- **Texto fijado**: el prompt dice el texto exacto de cada línea y prohíbe precios, monedas, envíos y nombres
  de producto inventados. Las imágenes con texto en español salen bien con GPT Image 2/2.5 y Nano Banana Pro; otros modelos
  meten faltas o texto de más.
- **4:5 primero, aprobado, y recién después el 9:16**: el vertical se genera con el 4:5 de referencia y hereda todos
  sus defectos. «Aprobado» es mirado a tamaño feed y sin defectos anotados, no «terminado».
- Bajadas en **tres renglones cortos**, no dos largos: al recomponer a 9:16 se trunca el renglón largo.
- Cada cifra de la imagen se coteja con la landing de ese idioma antes de generar.

## Error típico
Dejar que el clonador automático escriba el texto: inventa precio, «envío gratis» en un digital y piezas que no
existen.

Relacionadas: [[el-producto-en-pantalla-es-siempre-el-real]] · [[prompts-de-imagen-decir-que-va-no-que-no]]
