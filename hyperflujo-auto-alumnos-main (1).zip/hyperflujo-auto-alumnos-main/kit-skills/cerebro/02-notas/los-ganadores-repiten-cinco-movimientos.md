---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Los creativos que escalan no comparten un formato: comparten cinco movimientos"]
---

# Los creativos que escalan no comparten un formato: comparten cinco movimientos

## Punto clave
Los creativos que escalan no comparten un formato: comparten cinco movimientos. Número, enemigo, persona, prueba, oferta sin riesgo.

## La regla
Un guion nuevo tiene que tener **al menos cuatro de estos cinco movimientos**:
1. **Un número concreto** en el gancho o en el guion (cantidad, tiempo, prueba).
2. **Un enemigo o una causa reencuadrada** antes del producto («no es tu culpa, es X»; la lista de lo que ya
   probaste y falló).
3. **Una persona hablando**, no la marca (cliente, experto, fundador, narrador cercano).
4. **La prueba en cámara**: demostración, el producto real por dentro, antes y después de la tarea.
5. **Una oferta con número y riesgo cero** en el cierre (cantidad de bonos, primer módulo gratis, garantía, entrega
   inmediata). Sin precio en el anuncio: ver [[reglas-de-copy-y-lo-que-meta-rechaza]].

## Por qué (lo medido)
Barrido propio de 66 anuncios activos y escalados en cuatro verticales (productos digitales, salud, belleza-moda,
hogar-apps), con ~45 guiones transcritos:
- El **número concreto** apareció en casi todos los digitales (17 de 18): en digital el volumen reemplaza al
  producto que no se puede tocar.
- La **voz de persona real** dominó belleza (13 de 16). La marca no habla: habla alguien.
- El **reencuadre de la causa** fue el patrón más fuerte de salud (7 de 16).
- La **garantía o el pago fácil** van siempre al final, nunca al principio.
- La **demostración** (en digital: la planilla o la pantalla real del producto) apareció en 10 de 18 digitales.
- Los dos anuncios más longevos de digitales **no tienen voz**: texto grande sobre la demostración y música.
- Los que más escalan no tienen «un» ganador: corren **cientos de variantes** de una misma plantilla
  (ver [[cada-renovacion-mezcla-formatos]]).

## Cómo aplicarlo
- Al terminar un guion, marcá al margen qué línea cumple cada movimiento. Si faltan dos, se reescribe antes de
  gastar un crédito.
- En un producto digital el movimiento 4 es **mostrar el contenido real**: una muestra, la planilla, la pantalla de la
  app, la receta terminada. Nunca un producto dibujado por la IA.
- El movimiento 2 se adapta al nicho sin culpar al cliente. Ejemplo (guía de finanzas personales inventada):
  «No es que no sepas ahorrar. Los gastos hormiga están diseñados para no verse.»

## Error típico
Elegir primero el formato («hagamos un UGC») y después ver qué decir. El formato es la superficie; los cinco
movimientos son lo que vende, en cualquier formato.

Relacionadas: [[el-creativo-escalado-tiene-seis-bloques]] · [[sesgos-en-orden-atencion-identificacion-creencia-accion]]
