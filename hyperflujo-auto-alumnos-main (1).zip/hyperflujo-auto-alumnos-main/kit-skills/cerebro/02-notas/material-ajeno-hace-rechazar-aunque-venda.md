---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un video que vende no prueba que esté limpio: el material ajeno salta cuando la pieza vuelve a revisión"]
---

# Un video que vende no prueba que esté limpio: el material ajeno salta cuando la pieza vuelve a revisión

## Punto clave
Un video que vende no prueba que esté limpio: el material ajeno salta cuando la pieza vuelve a revisión. Material ajeno, clips de clientes, falsos positivos.

## La regla
Antes de **relanzar, iterar, traducir o mover de página** un ganador, o de usar clips que manda un cliente: hoja de
fotogramas (1 por segundo) y OCR buscando productos de otras marcas, marcas de agua, logos, texto en otro idioma y
personajes reconocibles. Si cualquier ventana de un clip muestra marca o rótulo de otra cuenta, **el clip entero queda
afuera**.

## Por qué (lo que ya pasó)
- Un ganador grande mostraba durante la mayor parte de su duración el producto de **otra marca** (una pieza de
  banco con el packaging ajeno). Corría sin problema; al relanzarlo como anuncio nuevo, Meta lo rechazó por «uso de nombre o
  imagen de marca». **El rechazo por marca ajena no se dispara en lo que ya corre: aparece cuando el video vuelve a
  revisión** (anuncio nuevo, creativo nuevo, otra página).
- Otro ganador traía una marca de agua de otro país que se movía por el cuadro.
- Un cliente mandó 36 clips como «suyos» y al menos 11 eran reels de otras cuentas, con sus marcas y rótulos en cuatro
  alfabetos. La hoja a ojo no los delataba; los detectó el OCR sobre 3 cuadros por ventana.
- Una auditoría marcó caracteres de otro alfabeto en tres segundos de un video. El revisor miró solo esos recortes,
  los dio por falso positivo y prendió. En el cuadro entero había **la pieza de un producto ajeno en otro
  idioma**. Venía del cuerpo del ganador más vendedor de ese mercado.

## Cómo aplicarlo
- Rechazo por material ajeno: **no se apela**. Si lo ajeno es la mayor parte del video, se cambia la imagen y se
  **conserva la locución** (el ganador vive en el guion y la voz).
- Una alerta de la auditoría se revisa abriendo **el cuadro completo y sus vecinos (±2 s)** y pasándolo por TODAS las
  reglas (marca, idioma, producto real, precio), no solo por la que disparó. Si agregás una excepción al auditor,
  anotá qué más miraste en ese cuadro.
- Clips de cliente: cortalos en ventanas de ~5 s, OCR en cada una; marca o cuenta ajena = clip fuera; un rótulo de
  electrodoméstico o etiqueta genérica = solo esa ventana fuera. Avisale al cliente qué clips quedaron afuera y por qué.
- Los modelos de imagen y video meten **personajes de películas conocidas** si no pedís diseños originales. Revisá los
  fotogramas.

## Error típico
«Ya está aprobado, ya vende, no hace falta mirarlo.» Es justo el que hay que mirar antes de tocarlo.

Relacionadas: [[reglas-de-copy-y-lo-que-meta-rechaza]] · [[qa-automatico-de-piezas-con-ia]]
