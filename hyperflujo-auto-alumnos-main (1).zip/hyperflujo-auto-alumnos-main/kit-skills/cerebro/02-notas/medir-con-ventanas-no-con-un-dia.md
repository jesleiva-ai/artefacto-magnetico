---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Medir con ventanas, no con un día"]
---

# Medir con ventanas, no con un día

## Punto clave
Un día no dice nada; la tendencia de 3 días contra el mejor tramo, sí. Y medir lo cobrado.

## Un día sin ventas no significa nada

> "Que un día no tenga ventas no significa nada: puede ser un simple mal día."

Reaccionar a un mal día (bajar la escala de un mercado que ganó la semana) mata ganadores, y Meta además reaprende después de cada cambio.

- **No bajar ni apagar una ganadora por un día o una mañana** sin ventas. Decidir con **≥ 3 días** o con los umbrales de los robots.
- **No juzgar en las 48 h siguientes a un cambio** de presupuesto. Un diagnóstico se corta en el último cambio: medí solo desde ahí.
- **Una regla nueva se vuelve fija con 3 días que la confirmen.** Un día que la confirma es una hipótesis.

## Pero la tendencia sí dice

El golpe más caro que tuvimos (ver [[fatiga-y-relevo-de-ganadores|fatiga]]) pasó porque "cada día suelto no dice nada" y nadie miraba la tendencia. Las dos reglas conviven:

- **El día suelto no decide.**
- **La tendencia de 3 días contra el mejor tramo, sí.** Un robot (el termómetro) compara cada mañana la ganancia de los últimos 3 días cerrados contra el mejor tramo de 3 días de las últimas 3 semanas, y si está por debajo del 60 %, avisa y dice qué mercados explican la caída.
- En el informe de la mañana se compara **contra el mejor tramo**, no contra "ayer".

## Medir lo cobrado

- **Ganancia = facturado neto − gasto.** Usamos facturado × 0,9 − gasto como aproximación diaria; pero ojo, los informes "antes de comisiones" sobreestiman. Medir la **ganancia neta** con comisiones, reembolsos y herramientas, y lo que no está medido se muestra como "falta medir", **nunca como 0**.
- **El píxel infla** (cuenta extras como compras). Lo cobrado no ve las compras por vista y llega a tiempo; Meta atribuye tarde de madrugada. Para decisiones en el día, usamos **el mayor entre Meta y lo cobrado** por unidad; para juzgar ganadores, **el menor**.
- **UTMs:** a veces la plataforma de la tienda guarda el **nombre** de la campaña en lugar del id. Sumá por los dos.

## Cada cuenta vive en su huso

Las cuentas publicitarias tienen husos distintos. "Hoy" en una cuenta de otro huso no es tu "hoy".

- Para comparar horas o días entre cuentas, convertí siempre con el huso de cada cuenta.
- En código que queda corriendo, nunca uses "today": usá un rango de fechas explícito en el huso de la cuenta. Así evitamos un tablero que marcaba cero sobre un gasto real.
- Lo cobrado también se cuenta desde la medianoche **del huso de la cuenta** que estás comparando.

## La cuenta que falta entra como cero

Un ROAS por mercado salió mejor de lo esperado porque faltaba una cuenta en la lista que lo calculaba: su gasto no estaba, y lo que falta **entra como cero, no como hueco**. Cotejá la lista de cuentas del tablero contra todas las cuentas reales, y asigná cada cuenta a un mercado por sus **creativos**, no por su nombre. Si una misma cuenta le vende a más de un producto, medí por campaña y controlá que la suma no supere el gasto de la cuenta.

## Antes de culpar

- **A la landing:** compará la misma tienda contra su propio pico, no contra otra tienda.
- **Al mercado:** mirá primero si los robots corrieron y midieron de verdad.
- **A un creativo:** bajá a nivel anuncio con su estado real, días vivos y gasto. El agregado de 7 o 30 días incluye anuncios apagados.
- **"No convierte":** medí visitas ÷ clics en el enlace. Por debajo de ~75 % el problema está entre el clic y la página (carga lenta, redirección), no en el creativo.

## Cómo medir una prueba (tarjeta de prueba)

- **Una sola variable** por prueba.
- Vara de éxito escrita **antes** de prender.
- Mínimo de muestra (algunos P de gasto o 3 eventos).
- **Lectura a las 72 h, decisión a los 7 días.**
- Nunca dos pruebas sobre la misma métrica a la vez en el mismo mercado.
- El poscompra se mide en **ingreso extra por compra**, con 3 días.
