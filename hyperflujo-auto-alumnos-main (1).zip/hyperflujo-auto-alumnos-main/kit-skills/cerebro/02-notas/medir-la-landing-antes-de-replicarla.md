---
type: nota
created: 2026-07-28
tags: [ofertas, cerebro-ia]
source: "referencia de tercero — sesión de reconstrucción de una oferta de IA para una profesión con tres maquetas rechazadas y pedido de un mentor, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Medir la landing antes de replicarla", "La capa tecnica de una referencia", "Huellas de origen de assets"]
---

> Referencia de tercero: sale de una sesión de trabajo con pedido de un mentor.
> Es una opinión, no canon; no sirve como base para tocar una campaña, un precio
> o un presupuesto.

# El análisis por texto no llega a la capa que hace vender: hay que MEDIR la referencia y VERLA

## Punto clave
Los 14 rayos-X de landings guardados como texto dicen todos lo mismo en su
sección de paleta: **"no disponible en captura de texto"**. Con eso alcanza para
copiar el orden de los bloques, y no alcanza para nada más. El 2026-07-28 se
entregaron tres maquetas seguidas —todas rechazadas— construidas sobre
descripciones de texto de referencias que nunca se habían mirado. La cuarta,
la primera medida, fue la primera aceptable.

Antes de replicar cualquier landing hay que correr **las dos** pasadas:

```
python3 anatomia.py <url>          # cómo está construida
python3 ojos.py foto --url <url>   # cómo se ve
```

Ninguna reemplaza a la otra. La medición sin la foto da números sin criterio;
la foto sin la medición da impresiones sin poder replicar.

## Hasta dónde llega anatomia.py: landings AJENAS con URL pública

Es la herramienta para lo que se escribió —medir una referencia de tercero— y
**no sirve para medir lo nuestro**. Medido el 2026-08-05:

- Sobre un **artifact publicado** devuelve un informe perfecto de la cáscara de
  claude.ai: stack Tailwind, tipografías `anthropic-sans`, fondo `#0d0d0d`,
  «BOTONES (2): …Share». La landing vive en un iframe de otro origen y la sonda
  se queda afuera.
- Sobre un **`file://`** su Chrome devuelve `chrome-error`.

Lo grave no es que falle: es que **no falla**. Entrega un análisis convincente
de la página equivocada, y las compuertas 1, 2, 5, 6, 7 y 8 de
`/evaluar-landing` se resuelven leyendo ese informe.

**Para maquetas propias publicadas como artifact**, las compuertas medibles se
resuelven pidiéndole al navegador los **estilos computados** sobre el render
real (sonda propia vía `ojos.py`), y se declara que `anatomia.py` no se pudo
usar en vez de dar el número por bueno.

**Señal:** si el informe dice Tailwind, `anthropic-sans` o un botón «Share»,
estás midiendo el marco, no la landing.

## Detalle

### Lo que solo aparece midiendo (caso de la referencia madre, una oferta de IA para un oficio)
- **Tipografía con nombre y peso**: Bebas Neue 400 para titulares, Montserrat
  400/700/800 para cuerpo. Las dos gratis. Estimar "una condensada pesada" no
  sirve: hay que poder instalarla.
- **La paleta no era custom**: `#f59e0b` y `#d97706` son `amber-500` y
  `amber-600` de Tailwind por defecto. Se replica en un renglón.
- **Relación de aspecto**: 47 de 55 imágenes en **1:1**, assets de producto a
  1254 y 1024 px. Cero 16:9, cero 3:2. Producir el asset con el aspecto
  equivocado desalinea toda la página.
- **Lo que NO hay**: cero carruseles. La nota decía "los 6 módulos (carrusel)"
  y era una inferencia del texto. Se replicaba una cosa inexistente.
- **Dónde cae cada botón**: 5 CTA, el primero al **6%** de la página. Ese dato
  resuelve la discusión del tobogán con número en vez de opinión
  ([[landing-tobogan-sin-botones-arriba]]).

### Huellas de origen de assets
Los nombres de archivo delatan con qué se generó cada imagen, y casi nunca los
renombran. Saberlo dice con qué herramienta se replica:

- **ChatGPT / DALL-E**: el nombre queda literal
  (`ChatGPT_Image_5_jun_2026_...webp`). En la referencia madre hay 17 así. Dos
  conservan además el **prompt** en el nombre (`cambiar-color-a-dorado-blanco...`):
  se puede leer qué le pidieron al modelo.
- **Higgsfield**: arranca con `hf_` + fecha (verificado el 2026-07-28 contra
  una generación propia; el dato que circulaba era "hg" y está mal).
- **Midjourney**: UUID largo con guion bajo y número al final.
- **Bancos** (unsplash, pexels, freepik) y **CDN de Shopify** se leen del dominio.

### El mockup es imagen diseñada, jamás CSS imitando una foto
Regla de la casa de un mentor, confirmada por contraste: una caja 3D hecha con
`transform: rotateY()` se nota y abarata. El mockup se genera (Higgsfield,
`get_cost: true` antes y sin tocar un crédito sin OK del dueño) y se incrusta.
Cruza con el patrón visual 4 —tangibilización— de
[[patrones-visuales-y-titulares-ganadores]].

## Aplicación
Fase 00 de cualquier maqueta, antes de escribir una línea: correr las dos
pasadas sobre la referencia y llenar la sección de paleta del rayo-X con lo
medido. Los 13 rayos-X restantes siguen con el hueco: se cierran corriendo
`anatomia.py` una vez sobre cada uno.

Relacionadas: [[patrones-visuales-y-titulares-ganadores]] (qué mostrar).
