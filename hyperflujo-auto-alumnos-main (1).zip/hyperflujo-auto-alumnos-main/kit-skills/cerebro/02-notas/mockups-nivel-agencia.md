---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Los mockups tienen que verse de agencia: el valor percibido entra por los ojos antes que por el copy"]
---

# Los mockups tienen que verse de agencia: el valor percibido entra por los ojos antes que por el copy

## Punto clave
Los mockups tienen que verse de agencia: el valor percibido entra por los ojos antes que por el copy. Valor percibido de diseñador.

## La regla
Portadas, presentaciones del producto, mockups de bundle y de cada bono se hacen **de diseñador**: realistas, con
dirección de arte, «de alto valor percibido». Nunca un collage por código, una portada HTML como definitiva ni un mockup
tipográfico. Y si se muestra el producto **por dentro**, tiene infografías, fotos y recuadros: nunca texto corrido.

## Por qué
- Una tienda salió con mockups planos y el producto por dentro en texto plano (encabezados de color y listas, cero
  imágenes). El veredicto fue que así no se podía entregar: el texto plano mata el valor percibido en la landing y en
  el anuncio.
- Los productos que mejor vendieron por dentro tenían imágenes, figuras e infografías en cada sección.
- Generar mockups a calidad máxima en una plataforma de créditos se comió una parte enorme del saldo mensual en una
  noche; ChatGPT (por la app o por Codex en un servidor) dio el mejor resultado sin costo aparte.

## Cómo aplicarlo
- **Rediseñar el entregable antes de mostrarlo**: si el PDF sale de un generador automático, se re-renderiza con diseño
  (HTML → PDF) con imágenes, figuras, infografías en HTML y recuadros, y recién ahí se arma el «por dentro».
- **Imágenes sin texto adentro**: la IA hace la foto o el render; el texto lo pone el HTML o la composición.
- **En el dispositivo va la portada**, nunca muestras interiores sueltas. Sin texto extra en la escena.
- **Cada producto con su dirección de arte**, escrita en un documento corto (paleta, luz, materiales, estilo de foto).
  Ejemplo para una guía de carpintería inventada: madera cálida, luz de taller lateral, herramientas de mano reales,
  polvo en el aire, portada con foto a sangre y tipografía condensada.
- Portadas: foto a sangre + tipografía de la marca. Bundle: las piezas reales compuestas por la IA en una escena.
- Todo pasa por una galería para que el dueño lo vea antes de reemplazar.
- El texto de la portada se audita letra por letra: alrededor de 1 de cada 5 piezas sale con un error de una letra, casi
  siempre en el texto más chico.

## Error típico
Mockup «correcto» sobre fondo blanco. Correcto no vende: tiene que dar ganas de tenerlo.

Relacionadas: [[el-producto-en-pantalla-es-siempre-el-real]] · [[imagenes-con-texto-en-otro-idioma-se-recrean]]
