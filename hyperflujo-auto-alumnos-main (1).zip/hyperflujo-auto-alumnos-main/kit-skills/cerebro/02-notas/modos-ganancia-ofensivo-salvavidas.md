---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Modos: ganancia, ofensivo y salvavidas"]
---

# Modos: ganancia, ofensivo y salvavidas

## Punto clave
Abrir la canilla con creativos cansados agranda la pérdida. Cuándo acelerar y cuándo cuidar.

El negocio corre en un **modo** que está escrito en la configuración de los robots, y todos lo leen. Cambiar de modo cambia metas, techos de tope y qué robots actúan, de una vez y en todos lados.

## Modo ofensivo

Definición del dueño: acelerar a fondo.
- Todos los topes suben **ya** a un CPA más caro aceptado (nadie frenado).
- Piso de topes alto, más presupuesto.
- Se prenden los salvavidas como escalas extra.
- Las subidas fuertes entran **antes del pico** de cada mercado.

**Por qué hace falta un molde para activarlo:** la primera vez que armamos un "ofensivo" solo subimos los techos. La escalera de topes siguió con su lógica prudente (arranca abajo, sube poco, baja apenas una venta sale cara). Esa noche hizo el doble de bajadas que de subidas y ninguna escala llegó al techo. Un modo es un **paquete de cambios coherentes**, aplicado por un script que guarda todo lo anterior y vuelve solo.

**Lo que medimos:** una noche agresiva dio ROAS 1,41 y casi el doble de ganancia que la anterior. Pero el ofensivo **sirve donde el creativo está fresco** y no en los mercados grandes y gastados: dos mercados cansados se llevaron casi la mitad del gasto a ROAS ~1.

## Modo ganancia

| Período | ROAS | Ganancia diaria (relativa) |
|---|---|---|
| Antes del ofensivo | 1,42 | 100 % |
| Ofensivo, días 1-2 | 1,20 | ~75 % |
| Ofensivo, día 3 | 0,94 | **negativa** |

**Con creativos cansados, abrir la canilla solo agranda la pérdida.** Se pasó a modo ganancia:
- ROAS meta base 1,4 en todos los perfiles.
- Techo de tope más bajo (cerca del CPA objetivo).
- El pico horario premia solo a los mercados con ROAS cobrado ≥ meta en los **3 últimos días completos**, con un gasto mínimo.
- **Freno de mano** (ver abajo).
- Se mantienen el techo por escala y los ganadores protegidos.

**Volver al ofensivo:** cuando el termómetro marque **3 días seguidos con ROAS ≥ 1,4** y haya ganadores nuevos en los mercados grandes.

## El freno de mano

Un día una escala gastó casi el doble de lo que cobró y nadie la frenó en el día. Ahora:

- Se activa con un gasto mínimo del día y **ROAS cobrado < 0,8**.
- El presupuesto baja a la mitad (con un piso) y el tope baja un escalón. Si estaba en el pico, el pico se cancela.
- **Una vez por día por escala.** Avisa y queda anotado.
- Compara el gasto del día **en el huso de la cuenta** contra lo cobrado desde la medianoche **de ese mismo huso** (si mezclás husos, da ROAS falsos de 0,0-0,3 de madrugada).

## Los salvavidas

Si tenés más de una cuenta publicitaria, escalas de respaldo por mercado en **otra cuenta con historial**, armadas con los mejores posts de la escala (la misma publicación, para conservar la prueba social), prendidas **tibias** (presupuesto mínimo).

- **Disparo:** si la cuenta principal del mercado ya gastó algo hoy y en la última hora **no sumó casi nada**, en horario de venta y con su escala activa (señal típica: pago rechazado o límite diario de Meta) → el salvavidas sube a un presupuesto alto y entra a la escalera. Una vez por día por mercado.
- **Vuelta:** cuando la cuenta original está al día y vuelve a gastar, el salvavidas vuelve a tibio. "Solo se activan cuando falla algo, pero después vuelven."
- **Zanahoria del salvavidas:** presupuesto = mínimo + **lo vendido en el día**. Si arranca en el mínimo y vende una venta, su presupuesto sube en el valor de esa venta; si vende diez, suma diez. Nunca baja dentro del día; a la medianoche vuelve al mínimo. Se le paga con lo que trae.
- **Zanahoria de las escalas** (solo en ofensivo): si gastó el 50 % de su presupuesto con ROAS ≥ meta y ≥ 2 compras, ×2, hasta el techo. Nunca baja (eso lo hace la canilla).

## Los cuatro motores del modo ganancia

1. Surfear bien el día (subir en la franja buena, no castigar la mañana floja).
2. Testeos que funcionan y traen relevo.
3. El salvavidas que cubre caídas.
4. Las escalas con tope que venden mucho a buen CPA.

Cada uno se juzga por **la ganancia cobrada**, no por el volumen.

## Reglas de cualquier modo

- Un modo se activa con un **script** que guarda lo anterior y lo revierte solo (con cron de vuelta), o queda fijo por decisión explícita y con fecha de revisión.
- Se mide contra el período anterior con los mismos criterios: facturado, ROAS y ganancia.
- Ninguna "noche especial" sube techos sin dejar programada la vuelta.
