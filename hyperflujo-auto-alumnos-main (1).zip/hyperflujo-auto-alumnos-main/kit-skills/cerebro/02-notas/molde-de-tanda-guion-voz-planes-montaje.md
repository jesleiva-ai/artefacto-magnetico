---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Una tanda se produce con un molde fijo: guion verificado, voz con tiempos, plan frase→plano, montaje y QA"]
---

# Una tanda se produce con un molde fijo: guion verificado, voz con tiempos, plan frase→plano, montaje y QA

## Punto clave
Una tanda se produce con un molde fijo: guion verificado, voz con tiempos, plan frase→plano, montaje y QA. Guion verificado → voz con tiempos → plan frase→plano → montaje → QA.

## La regla
Toda tanda copia un molde de carpeta, no se arma desde cero. El orden no se negocia:
1. **`guiones.json`**: texto de cada pieza + la fuente de cada dato (dónde está en el entregable) + las reglas de la tanda.
   Pasa el checklist ([[checklist-antes-de-producir]]) antes de seguir.
2. **Catálogo del banco** (hoja de contactos de cada clip, etiquetas por palabra) **antes** de escribir los sustantivos.
3. **Locutar** por API con marcas de tiempo por palabra (ElevenLabs `with-timestamps`): sale el audio y la lista
   `[palabra, inicio, fin]` 100 % alineada, sin Whisper.
4. **`planes.json`**: cada frase de la voz → su plano (gancho, cuerpo, producto, oferta, CTA). El plano entra cuando la
   voz dice la palabra.
5. **Generar solo las tomas que faltan**, con hoja de cuadros de cada una.
6. **Montar** (`montar <id>`) → `finales/`.
7. **QA automático + hojas leídas a ojo** ([[qa-automatico-de-piezas-con-ia]]).
8. **Página de aprobación** con las piezas para que el dueño las vea (o el QA las apruebe solo).
9. **Carga** en pausado: un conjunto por pieza que se quiere medir sola, nombre con número de test, y recién después
   renombrar y archivar el archivo.

## Por qué
- Sin molde cada tanda reinventa decisiones y repite errores ya pagados.
- Escribir el guion antes de catalogar el banco dejó frases que nombraban cosas sin metraje (ver
  [[el-guion-solo-nombra-lo-que-hay-en-el-banco]]).
- Una sola pieza aprobada antes de renderizar la tanda entera ahorra rehacer todo por un pedido visual ambiguo.

## Cómo aplicarlo
- **Una pieza primero.** Se monta una, se muestra, se aprueba el criterio visual, y recién ahí la tanda.
- **De quién es cada archivo**: antes del primer render, el origen de cada clip, música e imagen (propio, banco gratis,
  generado, del cliente). Lo ajeno se audita ([[material-ajeno-hace-rechazar-aunque-venda]]).
- **Cada paso guarda su resultado** (imagen, toma, voz) para retomar sin volver a pagar si algo se corta.
- **Una frase no se repite** en el mismo guion si el montador busca el plano por la frase desde el inicio: la segunda
  aparición cae en el lugar de la primera.
- **Un escritor por archivo**: dos procesos escribiendo el mismo registro se pisan.
- **De noche se produce, de día se carga**: las subidas de video gastan el cupo de llamadas de la API de Meta; si
  coinciden con los robots que optimizan, se frenan todos.
- **Registro de cada pieza**: familia, formato, eje de variante, origen del material, costo. Es lo que permite medir qué
  fuente da ganadores.

## Ritmo de producción que funcionó
Tandas diarias por mercado con más peso donde más se vende: un conjunto de héroe, iteraciones, un ángulo nuevo con
evidencia, traducciones pendientes de ganadores de otros mercados, y 1 de cada 3 piezas en estático.

Relacionadas: [[voz-ritmo-y-locucion]] · [[subtitulos-karaoke-salen-del-guion]] · [[montaje-con-ffmpeg-y-sus-trampas]]
