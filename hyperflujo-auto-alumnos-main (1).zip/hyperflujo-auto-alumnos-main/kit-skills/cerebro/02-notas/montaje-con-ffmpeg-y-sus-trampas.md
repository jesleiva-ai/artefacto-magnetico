---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El montaje por código se hace con ffmpeg en pasos separados, y cada paso tiene una trampa que ya rompió videos"]
---

# El montaje por código se hace con ffmpeg en pasos separados, y cada paso tiene una trampa que ya rompió videos

## Punto clave
El montaje por código se hace con ffmpeg en pasos separados, y cada paso tiene una trampa que ya rompió videos. Pasos separados y las trampas que ya rompieron videos.

## La regla
Audio mezclado en un paso, video con subtítulos sin audio en otro, y se juntan con copia directa. El render final se
verifica con los cuatro controles de [[qa-automatico-de-piezas-con-ia]].

## Trampas que ya rompieron piezas
- **Índice del mp4 al final**: el video «se traba» al abrirlo por red. `-movflags +faststart` en **todo** mp4 que sale,
  y en todos los pasos si hay dos.
- **Normalizar volumen en el render final** sacó el audio a 96 kHz y con 9 s menos de voz; el contenedor seguía
  declarando la duración correcta. El volumen es un paso aparte con `volume=` y se vuelve a medir.
- **Mezclar voz y música en el mismo filtro que los subtítulos** se comió casi 1 s de voz en pedacitos.
- **Render en lote**: 3 de 4 salieron corruptos con la mitad de los cuadros. Renderizados de a uno, perfectos. Verificá
  cada uno aunque el lote «haya andado».
- **Bajar video y audio por separado y pegar tramos con `concat -c copy`** perdió cuadros: la imagen quedó 3,4 s
  corrida contra la voz. Bajá el video entero ya mezclado y recortá todo en un solo filtro (trim + fps fijo + concat).
- **Audio con marcas de tiempo raras** (grabaciones de pantalla): decodificado en orden se atrasa. Extraer con
  `aresample=async=1` y medir contra el video.
- **Audio guardado de una corrida anterior**: desfasa la voz si se retocó el guion. El motor rehace el audio siempre.
- **Imágenes fijas concatenadas con video** sin el rango de color de video: la franja blanca sale gris.
- **Franjas negras** que mete el modelo de video dentro del 9:16: detectarlas y recortar.
- **Cortar en el fin de la voz + 0,15 s** dejó ver un pedazo del cierre viejo; cortar en fin − 0,03.
- **ffprobe roto o ausente** (enlace a una carpeta borrada): los controles de calidad «reprueban» clips sanos y la
  herramienta vuelve a pagar la generación. Verificá el entorno antes de la tanda (`doctor`).
- Una herramienta que no está en el PATH no es una herramienta que no existe: buscala antes de concluir que falta.

## Trucos que sirven
- **Mirar un video** = hoja de contactos (un cuadro cada 1-2 s con el segundo estampado).
- **Ajustar un corte al plano real**: diferencia media entre cuadros consecutivos; el pico cerca del límite estimado es
  el corte.
- **Zoom lento sobre un mockup** para el CTA: gratis y con el texto exacto, mejor que una toma generada que deforma.
- **Recolorear sin regenerar**: un filtro de canales (`geq`) cambia un color que se fue (rojo → verde) dejando el resto.
- **Borrar metadata** (`-map_metadata -1`) como higiene antes de subir; no hace «nuevo» un video para Meta.
- **Tramo con texto basura** en una toma: recortar ese tramo antes que regenerar.
- **Archivo pesado** (~10 Mbps): Meta lo acepta; para mandarlo por mensajería, bajá el bitrate.

## Remotion o ffmpeg
Remotion (plantillas en React) es cómodo para captions con estilo, títulos y overlays repetibles; ffmpeg alcanza para
todo lo demás y es más liviano. Medido por un operador de la comunidad: lo montado por código rindió igual que lo
montado a mano. El editor no mueve la aguja; el guion y las tomas sí.

Relacionadas: [[qa-automatico-de-piezas-con-ia]] · [[musica-de-los-creativos]]
