---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["La música sube el valor percibido o lo baja: tiene que tener energía hasta el final, ir debajo de la voz y no cortarse"]
---

# La música sube el valor percibido o lo baja: tiene que tener energía hasta el final, ir debajo de la voz y no cortarse

## Punto clave
La música sube el valor percibido o lo baja: tiene que tener energía hasta el final, ir debajo de la voz y no cortarse. Energía hasta el final, debajo de la voz, una sola canción, −14 LUFS.

## Las reglas
1. **El registro de la música es parte del posicionamiento.** Para productos que venden estatus, música de alto valor
   percibido (épica, de trailer, «de lujo»); un género bailable barato bajó el estatus de una serie y se rehizo.
2. **Debajo de la voz**: ~12 dB por debajo (ducking o sidechain contra la voz). En videos largos explicativos, la música
   va solo en la apertura, en las placas y en el cierre, muy baja; debajo de la explicación, nada.
3. **Una sola canción de punta a punta**: la música no corta cuando entra el cierre o el spot final. Se rehace el audio
   con la misma canción corriendo hasta el logo.
4. **Energía hasta el final**: temas de 60 s pedidos «full energy to the very end, no intro». Los de 30-40 s se apagan
   antes del logo. Se elige el tema cuya parte fuerte cubre el video y se alinea para que el cierre natural caiga con el
   logo.
5. **Volumen final**: Meta sirve todo normalizado a ~−14 LUFS sea cual sea tu máster; masterizá cerca de ese número con
   un limitador a −1 dBTP para que no te lo aplaste.

## Herramientas
- **Suno** (por APIMART): canciones con letra (ver [[estilo-musical]]) e instrumentales por estilo. Cada envío trae
  dos temas. Transcribí la letra cantada antes de usarla.
- **ElevenLabs Music**: instrumentales de largo exacto; un pedido por vez (en paralelo da error de límite).
- **Bancos propios** por registro (confesión, descubrimiento, urgencia, lujo) con un archivo de datos por tema
  (duración, dónde arranca, último segundo con energía) para que el montador elija solo.
- No uses el nombre de un artista en el pedido: describí el estilo.

## Trampas
- **Logo mudo**: un sidechain que usa la voz sin relleno corta el audio donde termina la voz y el logo queda en
  silencio. Arreglo: rellenar la pista de voz (`apad`) antes del sidechain.
- **Efectos de sonido invasivos** y un golpe en cada corte cansan: un golpe al cortar sirve en estilos animados; en
  UGC y explicadores, sin efectos o muy pocos.
- Música alta en los cierres: bajarla (~0,5) y dejar el golpe final más arriba.
- Sobre la marca hablada, bajar la música y sacar efectos: si no, se pierde una consonante y no se entiende el nombre.

Relacionadas: [[montaje-con-ffmpeg-y-sus-trampas]] · [[estilo-musical]]
