---
type: nota
created: 2026-07-28
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["No le des opciones al comprador", "Validá la transformación, no el formato"]
---

# Cada alternativa que le das al comprador lo confunde: primero validás la transformación, el formato es irrelevante

## Punto clave
Respuesta repetida a quien quiere ofrecer el mismo producto en dos formatos (ej.
PDF o aplicación): "mientras más alternativas le das al usuario, más lo vas a
confundir". A la persona **no le interesa el formato, le interesa la
transformación**. En etapa de validación se elige UN cómo — el que a vos te
resulte más cómodo — y se valida la promesa.

## Detalle
- El error de fondo: dos opciones equivalentes no ayudan a decidir, **obligan a
  decidir**. "Es como elegir A o B: ¿y por qué elegiría A? ¿por qué elegiría B?"
- Cuándo sí se ofrecen opciones: el marketing con opciones usa **tres**, y la
  elegida es siempre la del medio (sesgo psicológico). Pero es juego avanzado —
  no aplica en instancia de validación.
- El formato alternativo no se pierde: vive después como upsell o como oferta
  post-compra por email. Nunca como bifurcación en la landing.
- Es coherente con la landing tobogán: un solo camino, cero bifurcaciones
  ([[landing-tobogan-sin-botones-arriba]]).
- La clave declarada no está en la cantidad de opciones sino en "qué tan buena
  sos comunicando el valor percibido" ([[promesa-cuatro-atributos]]).

## Aplicación
Ante "¿lo ofrezco en los dos formatos?" con la oferta todavía sin validar: uno
solo, el que salga más rápido. La segunda versión entra como upsell si el mercado
la pide.
