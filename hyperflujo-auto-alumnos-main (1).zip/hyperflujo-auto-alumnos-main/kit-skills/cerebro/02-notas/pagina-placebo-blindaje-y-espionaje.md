---
type: nota
created: 2026-07-27
tags: [ofertas, meta-ads]
source: "referencia de tercero — caso de una alumna con un producto vendido en dos idiomas, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Pagina placebo", "La posta y el placebo"]
---

> Referencia de tercero: es el caso de una alumna, no canon. No sirve como base
> para tocar una campaña, un precio o un presupuesto.

# La página placebo: los ganadores esconden su landing real

## Punto clave
Técnica de blindaje usada por operadores exitosos (caso confirmado de una
alumna): la URL pública de la tienda muestra una landing PLACEBO; la landing real
("la posta") solo se alcanza desde la URL exacta que usan los anuncios. Quien
espía desde afuera ve la placebo y descarta una oferta que en realidad es
ganadora.

## Caso documentado
- Posta en inglés: una única URL de producto en un dominio propio de la marca
  (todo lo demás de esa marca en inglés es placebo).
- Versión en español: otra URL de producto en un segundo dominio.
- Placebo pública: un tercer dominio, con una landing floja. Así la vio el
  registro de espionaje, y por eso quien lo armaba la salteó.

## Reglas operativas que salen de esto
1. **Espiando**: una URL pública nunca se da por posta hasta cruzarla con quien
   corre la cuenta. "Landing floja + muchos ads + muchos días" ya no es
   contradicción: puede ser placebo. Afila el criterio de /espia-ofertas.
2. **Blindando**: la placebo es la contracara del watermark y del costcap —
   otra capa del arsenal anti-clones ([[playbook-landings-escaladas]]).

## Aplicación
En el backup, toda entrada lleva la URL posta confirmada por el dueño; las
capturas de landings ajenas se marcan "sin confirmar posta" hasta validarlas.
