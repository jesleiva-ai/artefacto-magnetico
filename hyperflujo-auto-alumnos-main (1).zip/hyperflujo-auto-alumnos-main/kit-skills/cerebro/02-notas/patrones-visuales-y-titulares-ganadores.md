---
type: nota
created: 2026-07-27
tags: [meta-ads, ofertas]
source: "referencia de tercero — análisis cuadro a cuadro de 11 anuncios ganadores (de una tienda propia y de una alumna) más anuncios espiados, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Patrones visuales de anuncios ganadores", "Las dos escuelas de titular"]
---

# Los ganadores comparten 6 patrones visuales y se parten en dos escuelas de titular

## Punto clave
Cuadro a cuadro sobre 11 ganadores de dos ofertas sin relación (un producto
digital en español y un imprimible en inglés): 6 patrones visuales idénticos, y
los titulares se parten en dos escuelas según qué carga el título (la oferta o
el beneficio).

## Los 6 patrones visuales compartidos
1. SIN CARAS: manos + producto, siempre.
2. Subtítulos quemados desde el segundo 0-1, en cápsula de color.
3. Watermark de marca (el dominio de la tienda o un logo circular).
4. TANGIBILIZACIÓN del producto digital: mockup 3D sostenido en la mano sobre
   la escena real (oferta ES) o el imprimible impreso y armado en cámara
   (oferta EN). Lo digital se vuelve físico frente al ojo.
5. CTA explícito al cierre; el mejor ROAS de la oferta ES (4,68) además muestra
   LA GRILLA COMPLETA DE 10 BONOS en pantalla.
6. Duración 20 s+: oferta ES 23-38 s (ES/LATAM), oferta EN 27-50 s (EE. UU.).
   Hipótesis: el mercado EN banca más duración.

## Las dos escuelas de titular
- **OFERTA-led (ES)**: "🔥 50% OFF POR 24hs + 🎁 10 BONOS DE REGALO" —
  descuento + urgencia + stack; 3 emojis (2 abren, 1 marca regalo). Título
  único en los 7 ganadores; el video carga el beneficio.
- **BENEFICIO-led (EN)**: "Start your own business 👉🏻" / "Create Pro
  [resultado] in Minutes 🎉" — verbo imperativo + resultado + 1 emoji al
  cierre; un título por ángulo, sin descuento. El censo del arsenal es dato:
  ~50% negocio, ~20% velocidad, ~20% casa/mamá, 5% creadores, 5% ahorro — y el
  ángulo AHORRO corre en FORMATO IMAGEN, no video.

## Sumados 2026-07-28 (corpus brasilero + recetas, 34 ads más)
7. **EL PRODUCTO ES EL CREATIVO**: screen-recording del PDF real
   scrolleando — el OCR levanta el contenido interior e incluso la ventana
   de archivos con los bonos ("BONO 1 KINE.pdf"). La prueba es mostrar los
   archivos mismos que vas a recibir. Tangibilización llevada al límite.
8. **PÓSTER DE INVENTARIO** (ads imagen, 8/8): mockup explotado — tapa
   "X SOLVED(TM)" rodeada de páginas satélite etiquetadas + badges fijos
   (6 Volumes · 5 Bonuses · 100% PDF · Instant Access) + franja de 3-4
   mini-beneficios + banner CTA con logos VISA/MC y badge de garantía.
   La landing entera comprimida en una imagen.
9. **LLAMADO AL ROL en texto gigante (0-3 s)**: "YOU JUST GRADUATED AS A
   NUTRITIONIST" — el avatar nombrado por profesión antes que el dolor.
   Multi-entrada por etapa de vida (recién recibido / nuevo / veterano)
   del MISMO concepto.
- Regla de precio por escuela CONFIRMADA en copy primario: oferta-led
  (recetas ES) lleva el precio EN el ad ("Por solo 9,99€..."); beneficio-led
  (brasilera, profesional US$27) jamás lo menciona.
- Rotación confirmada con fechas (recetas): UN ganador duplicado ×5 corriendo
  3,5 meses + 1-2 tests nuevos por semana. Nada más en el aire.

## Anatomía de copy primario (fórmulas reales)
- DOLOR-PROCESO (volumen): escena de dolor concreta + emoji nicho → validación
  empática → reencuadre ("no falla por ganas, falla por proceso") → detalle
  específico (verosimilitud) → oferta → CTA 👇.
- AUTORIDAD (eficiencia): pregunta-deseo → objeciones fuera en 2 frases →
  número de autoridad (18.000 personas) → oferta → CTA 👇.

## Correcciones medidas en un nicho profesional (2026-08-06)
Seis anuncios de dos competidores DIRECTOS (mismo producto, mismo comprador,
mismo idioma) corrigen tres cosas de arriba. **Cuando el corpus general y el
nicho exacto chocan, gana el nicho exacto.**

- **El formato es 4:5, no 1:1.** Los seis son 1080×1350. Un cuadrado en el mismo
  espacio del feed se ve ~25% más chico.
- **El precio SÍ va quemado**: 4 de 6 lo llevan. En low ticket profesional el
  precio bajo *es* el argumento, porque el comprador espera que cueste cientos.
  La regla "beneficio-led no menciona precio" salió de otro nicho.
- **Las caras conviven en dos escuelas**: **diagrama** (sin caras, vende método:
  los 5 pasos, el mapa, el checklist) y **autoridad** (con cara, vende persona:
  traje + mockup). El invariante "sin caras" vale para la primera, no para todo.

## Relacionadas
[[guiones-madre-anuncios-ganadores]] (la capa narrativa) ·
[[moc-fabrica-de-creativos]] (producir sobre estos patrones) ·
[[playbook-landings-escaladas]] (la capa landing).

## Aplicación
Brief de creativos para cualquier oferta: elegir escuela de titular, patrón
visual por nicho (qué muestra la prueba: el OFICIO si vende competencia, la
OPERACIÓN si vende negocio), guion madre, y respetar los 6 invariantes.
