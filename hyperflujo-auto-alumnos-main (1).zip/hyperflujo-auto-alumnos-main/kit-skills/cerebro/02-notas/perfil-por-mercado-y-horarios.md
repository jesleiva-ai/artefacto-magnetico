---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Perfil por mercado y horarios"]
---

# Perfil por mercado y horarios

## Punto clave
Cada mercado con su ticket, su meta, su tope y su pico; la mañana anticipa poco.

## Cada mercado con sus propios números

Un tope y un CPA iguales para todos los mercados no sirven: el ticket, la competencia y la hora en que compran cambian mucho. Un robot recalcula cada noche, antes del reset, el **perfil** de cada mercado:

- **Ticket** por comprador de los últimos 14 días (compra + extras), separando los países que tienen un ticket muy distinto dentro del mismo idioma.
- **ROAS meta** según el modo del negocio (ver [[modos-ganancia-ofensivo-salvavidas|modos]]), **corregido por lo aprendido**: si el ROAS de 7 días viene bajo (< 1,1), la meta sube +0,2 (más exigente); si viene alto (> 1,6), baja −0,1 (puede apretar más). Siempre dentro de una banda.
- **CPA = ticket ÷ ROAS meta.** Ese número pasa a ser el **tope y el freno** de todas sus escalas, dentro de un piso y un techo.
- **Pico horario:** la franja de 4 h con más ventas cobradas de los últimos 14 días.
- **Fase del ciclo:** CRECE / ESTABLE / SE CANSA (ROAS cae ≥ 15 % o ≥ 2 ganadores cansados) / CAE (ventas −20 % y ROAS en baja).

Las escalas leen el perfil; la fábrica de creativos también (un mercado que "se cansa" recibe relevos primero).

## Barata antes que mucha, en mercados de ticket bajo

En un mercado donde el ticket es la mitad del resto, ROAS 2 pide un CPA de la mitad. Ese mercado va con techo de tope, freno y piso **propios y bajos**. Y ojo: medido por UTM ese mercado parecía flojo (ROAS 1,3) y medido por país del comprador daba 3. Cuando el idioma no es el país, medí por el país del comprador.

## Los horarios: cuándo compra cada mercado

Medimos ventas cobradas por franja horaria, 7 y 14 días:

- En los mercados que medimos se vendió mucho mejor **de la madrugada al mediodía (hora local)** que a la tarde-noche. En un día típico, la franja buena dio ROAS 2+ y la de la tarde ~1.
- Si tus mercados están en otro huso, el pico puede caer de madrugada para vos; **cada cuenta vive en su huso** y su "día" no empieza a tu medianoche.
- La subida fuerte tiene que entrar **antes** del pico de cada mercado, nunca en su franja floja. Un día subimos un respaldo en la peor franja de su mercado y dio ROAS 0,52; reprogramado para antes del pico, rindió.

**Pero cuidado con sacar reglas de un solo día.** Un día concluimos "después del mediodía local no rinde" y achicamos todo; al otro día la curva mostraba que lo que había fallado era **subir topes a mano** a esa hora, no el horario en sí. El dueño corrigió: "el mercado mantiene todo el día". Una curva de un día es una hipótesis; se confirma con tres.

## La mañana anticipa poco

Medimos 97 días-campaña en 14 días (mañana = primeras 12 h del día de la cuenta, tarde = las otras 12):

| Mañana | CPA de mañana → CPA de tarde |
|---|---|
| Buena (CPA bajo) | sube casi al doble |
| Media | queda igual |
| Mala (CPA alto o sin ventas) | **se recupera sola** a algo menos de la mitad |

Más de la mitad del gasto entra a la mañana. Conclusiones:
- Subir presupuesto a media mañana tiene ventaja, pero chica: de a +20 % y solo con mañana buena.
- **No bajar antes del mediodía** por una mañana mala: cortás tardes que se recuperan.
- Una escala con historia buena (ROAS de 3 días por encima de la meta) tiene **mañana protegida**: antes del mediodía no baja ni por corte duro. Nos pasó que el robot cortó de madrugada a un ganador con ROAS 2,3 de tres días por una mañana floja.

## Medir por campaña, no solo por país

- **El país vacío esconde ventas.** En una tienda, una parte de las órdenes venía sin país del comprador; el país real estaba en otro campo de seguimiento. Un país que parecía "cero ventas" tenía decenas.
- **El país dentro de campañas generales engaña.** Dos países "ganaban" mirados por país del comprador y perdían en su campaña propia. Para decidir, medí por **campaña/conjunto con el UTM**.
- **El idioma no es el país.** La gente compra en la tienda del idioma que entiende, viva donde viva. Esos compradores se prueban como **conjuntos** del testeo del idioma, con el filtro de idioma puesto.

## Mercados chicos vs. grandes, y el medio de pago local

Los mercados grandes, con mucha competencia, suelen rendir menos que los chicos con ticket parecido: no des por hecho que el país más grande es el mejor. La tasa de pagos aprobados cambia muchísimo por país y depende de tener el medio de pago local: en algunos mercados un medio de pago local concentra la mayoría de los cobros; sin él, la aprobación cae fuerte.

**Antes de culpar a la landing comparando tiendas distintas**, compará la misma tienda contra su propio pico. Una vez se culpó a la landing de un mercado y convertía igual que en su mejor época: la caída era de creativos (un solo ganador por semanas, CPM +50 %).
