---
type: nota
created: 2026-07-27
tags: [ofertas, productos-digitales]
source: "referencia de tercero — registro de espionaje de landings ganadoras de la Biblioteca de Anuncios armado por un colega, con curaduría propia, sin confirmar con datos propios"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Playbook de landings escaladas", "Lo que hacen las 21 ganadoras"]
---

> Referencia de tercero: sale de un registro de espionaje armado por un colega.
> Es una opinión, no canon; no sirve como base para tocar una campaña, un precio
> o un presupuesto.

# Las tiendas escaladas no suben presupuesto: multiplican ads que apuntan a una landing de UNA oferta

## Punto clave
Destilado del registro de espionaje (21 tiendas escaladas verificadas + curaduría
propia): **cero VSL en 21/21**; la máquina de escala es un creativo ganador
duplicado en 5-25 ads apuntando a la landing del producto con precio bajo de
decisión rápida y ancla tachada. Las capturas de cada landing se guardan
congeladas y fechadas: sirven para ver cómo iteran los ganadores.

## Reglas que sobreviven con base firme
- **El ad nunca apunta al home genérico**: siempre a la PDP o a la landing del
  bundle.
- **Precio bajo de 5-47 USD con ancla tachada 3-10×**; timer/flash sale en las
  agresivas; prueba social manual ("+15.000 clientes") en funnels.
- Vocabulario "regalos apilados, jamás bonos" ("napa" = el extra que se regala):
  es criterio del colega para su propia tienda, NO nuestro (aclarado
  2026-07-27: "napa no es un concepto que trabajemos"). Queda como observación
  del registro, sin fuerza de criterio propio.
- Duplicar el ganador **en versión video E imagen simultáneas**.
- Hook = pregunta-dolor directa o escena en primera persona; transformación
  medible; checklist de entregables.
- **Ventana estratégica ES**: solo 3 de 21 escalan con Shopify directo en
  español — el modelo tienda-limpia + ebook + ads está flojo en el idioma; la
  ejecución superior gana sin pelear saturación.
- **Validación de dos factores**: ojo de quien decide (estructura/oferta) +
  mercado (días activos, cantidad de anuncios, regla de 3 anunciantes).
  Ninguno alcanza solo.

## Degradada a hipótesis
"Formato por nicho" (educación → imagen, patrones → video): estaba derivada de
tablas que se descartaron como referencias (catálogos multi-producto). A
revalidar con más ganadoras confirmadas.

## Relación con el canon
La anatomía de 15 bloques queda como el arquetipo #1, no como
"la" estructura: el registro muestra varios arquetipos escalados (PDP-funnel
agresiva, advertorial-historia, bundle con inventario numerado, entre otros).
Los arquetipos definitivos salen del análisis de las capturas validadas
(tarea del proyecto de backup de ofertas ganadoras).

## Aplicación
Antes de armar cualquier oferta o
landing nueva: revisar el registro y modelar desde una validada.
