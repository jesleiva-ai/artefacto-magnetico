---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Lo que gana es el guion y el gancho, no el metraje: un ganador se porta a otro idioma por centavos"]
---

# Lo que gana es el guion y el gancho, no el metraje: un ganador se porta a otro idioma por centavos

## Punto clave
Lo que gana es el guion y el gancho, no el metraje: un ganador se porta a otro idioma por centavos. Lo que viaja es guion + gancho.

## La regla
Cuando un creativo gana en un idioma, **se lleva a todos los idiomas que vendés** antes de buscar un ángulo nuevo. Hay
dos maneras, y se elige a propósito:
1. **Traducción exacta**: el mismo video, mismas tomas, misma música, solo cambian la voz, los subtítulos y los planos
   con texto del idioma de origen. Es lo que pide el dueño cuando dice «traducí el ganador».
2. **Reconstrucción**: mismo guion y mismo gancho, tomas nuevas propias (por ejemplo, porque las originales traen
   material ajeno o subtítulos quemados).

## Por qué (lo medido)
- El héroe traducido exacto fue la familia que más plata hizo de todo lo probado ([[receta-medida-heroe-traducido-y-muestra-real]]).
- Un ganador portado a otros dos idiomas **con imágenes nuevas** (en uno se cambió la imagen del gancho por otra igual
  de rara) también vendió: lo que viaja es guion + gancho.
- Portar una pieza cuesta del orden de **una sola toma de video** en créditos de voz. Una variante visual extra, cero.

## Qué se hereda y cómo se saca (sin preguntarle a nadie)
| Qué | Cómo |
|---|---|
| El guion exacto con tiempos de palabra | transcripción del **audio** (nunca OCR de subtítulos: inventa palabras y cambia el argumento) |
| Los puntos de corte | detección de escena sobre el mp4, reescalados a la nueva locución |
| El registro y el ritmo de la voz | tono (F0) y palabras por minuto medidos del audio |
| La identidad del subtítulo | dónde se apoya, color del resaltado (la **moda** de la banda, nunca el promedio), mayúsculas, cada cuánto corta |
| La ventana del producto | fracciones de la duración, no segundos fijos |
Al dueño se le pregunta solo lo que no está en el archivo: por qué cree que ganó, a quién le vende.

## Coherencia por mercado
- **Cada mercado en su dialecto**: inglés británico en el Reino Unido (no el estadounidense), francés de Francia en Francia (no el de Canadá). El léxico
  se busca en sitios reales del país, no en el diccionario.
- **El idioma no es el país**: mirá en las órdenes de qué país compra cada idioma (un idioma puede vender más en
  países vecinos que en el principal).
- Nombres de testimonios, monedas y cifras del país; las frases de rebaja que traía el copy original se sacan.
- Un idioma por anuncio de punta a punta: voz, copy, link, países y filtro de idioma.

## Validar un idioma que nadie del equipo habla
Cuatro pasadas independientes: (1) gramática con LanguageTool; (2) generar la voz y **transcribirla forzando el
idioma**: si un reconocedor entrenado en ese idioma devuelve lo mismo que se escribió, está bien pronunciado;
(3) cuánto del vocabulario ya aparece en la landing publicada para ese mercado; (4) buscar cada término técnico en
sitios reales del nicho en ese país (así se cambia el término de fabricante por el que dice una persona). Ninguna
reemplaza a un nativo; juntas pasan de «confiá en mí» a «mirá los números».

## Cómo aplicarlo
Un tablero ganador × idioma que diga qué traducción falta, y una cuota diaria de traducciones por mercado además de la
tanda. El detalle técnico está en [[traducir-un-ganador-exacto]] y [[trampas-por-idioma-y-alfabeto]].

## Error típico
Traducir «mejorando» el video. Si cambiaste las tomas, ya no es el ganador: es un anuncio nuevo y se mide como tal.

Relacionadas: [[un-ganador-rinde-muchos-anuncios-a-costo-casi-cero]] · [[testimonios-y-personas-en-pantalla]]
