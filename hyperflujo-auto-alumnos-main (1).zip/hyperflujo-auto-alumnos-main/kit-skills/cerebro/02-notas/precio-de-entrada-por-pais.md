---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Precio de entrada por país"]
---

# Precio de entrada por país

## Punto clave
Bajar el precio solo donde hay menos poder adquisitivo, y subirlo por escalones de ventas.

## La hipótesis que salió bien

Un mercado de bajo poder adquisitivo funcionó porque **no arrancó con el precio de siempre**, sino con uno mucho más bajo, con CPA bajísimos. Meta aprende con volumen; con volumen ganado, el precio subió por escalones sin perder la entrega (tres escalones, más ventas en cada uno).

## La regla (corregida)

La primera versión bajaba el precio de entrada en todos los países nuevos. Se corrigió en horas:

> "Los países que sí tienen poder adquisitivo no es necesario bajarlos."

- **Países con poder adquisitivo:** el precio de siempre. No se bajan.
- **Países de menor poder adquisitivo:** arrancan con un precio de entrada de **~55 % del precio normal** (el equivalente local), y suben por escalones.
- **Escalón:** cada **50 ventas aprobadas** (sin contar extras del poscompra) desde el último escalón, sube uno, hasta el precio normal. Un robot lo chequea cada 2 horas y avisa.
- Un idioma que abarca varios países con poder adquisitivo dispar se dejó en el precio normal por decisión del negocio: el precio es una decisión comercial, no solo de testeo.

## Cosas a saber antes de tocar precios por país

- **El precio es por país, no por campaña.** Si lo bajás en un país, lo bajás también para las campañas generales que le venden a ese país.
- **El precio se puede mover solo.** Plataformas con conversión automática de moneda o mercados configurados muestran otra cosa que el panel. Verificá contando los totales de las órdenes por día, y mirá el checkout publicado desde el país.
- **No uses tachados ni urgencia falsa** en la Unión Europea: están prohibidos.
- Algunas regiones pagan en otra moneda que la del catálogo de precios locales: revisá qué moneda ve el comprador.
