---
type: nota
created: 2026-07-28
tags: [meta-ads, productos-digitales]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Primero el ticket promedio, después la escala", "Calidad antes que cantidad de ventas"]
---

# Ante una oferta que convierte, subir el ticket promedio va ANTES que escalar en Meta

## Punto clave
Siempre hay dos opciones y siempre se elige la misma primero: no acelerar
presupuesto en Meta, sino trabajar el ticket promedio. Es más simple, se valida en
1-3 días, no obliga a manosear campañas — y el margen extra es exactamente lo que
después te deja ganar la puja cuando sí escales.

## La corrida real que lo muestra (tienda nueva, jul-2026)
- Lunes: 14 pedidos, tasa de conversión 3,7%, ticket promedio 24 USD.
- Martes: MISMA inversión, MISMOS 14 pedidos, ticket promedio 31 → **la ganancia
  del día subió de forma visible sin gastar un peso más en anuncios**. Las dos
  palancas que se movieron: precio del producto + una variación chica en los
  upsells.
- El mismo mes, un alumno **más que duplicó su ganancia diaria en tres días
  seguidos** trabajando sólo el ticket promedio, sin tocar la escala.

## Por qué el orden importa
- **El AOV no es sólo upsells: subir el precio del producto es la palanca más
  rápida.** "Un cambio de precio es de un día para el otro; en 3 días ya
  validaste el precio nuevo." Recién después entran los upsells
  ([[upsell-treinta-caracteres-y-mockup]]).
- Con más margen por venta se lee **CPA + ROAS**, no CPA solo: "podés tener un
  CPA de 20 con un retorno de 2,3". Los testeos duran más y las campañas de
  escala aguantan más ([[roas-benchmarks-low-ticket]]).
- Escalar con margen chico es amplificar la fragilidad: con 3 USD por venta, un
  solo día malo se lleva la rentabilidad del período.
- **No competir por ego en cantidad de ventas.** La misma ganancia diaria se puede
  hacer con 200 pedidos o con 30. Quien ya hace 200 pedidos/día con un margen chico
  multiplica su ganancia sólo subiendo el ticket y manteniendo el volumen.
- Banda de referencia: afuera, con buenos upsells, el AOV oscila entre 33 y 37
  USD. 24 "no está mal, pero es mejorable".
- **No hay techo por estar arriba de la banda** (2026-07-11): el alumno que aplicó
  la clase al día siguiente ya tenía un AOV **arriba de 40 USD** y aun así empezó a
  recibir tickets de **más de 200 USD**. "El ticket promedio tiene niveles." El
  argumento para insistir con esto incluso a quien ya factura: Meta es una
  plataforma de subastas y **cuanto más podés pagar por resultado, mejor**.

## Contraindicación
Aplica con la oferta ya validada por tasa de conversión
([[validacion-oferta-tasa-conversion]]). Si la TC no responde, el problema no es el
ticket y subir el precio sólo esconde el diagnóstico.

## El piso se movió: al 2026-10-31 son 30-32 USD, y abajo de eso es "el juego anterior"
Tres meses después, la banda de referencia dejó de ser un rango cómodo y pasó a ser
un **piso exigible**. Se dijo con el mismo número a dos casos distintos el mismo día:

> *"Hoy dentro de esta industria es extremadamente simple hablar de un ticket promedio
> de **32 como piso**. Ustedes están jugando con un ticket promedio del juego anterior de
> la industria, de hace diez meses atrás."*

> *"Este ticket mínimo me lo tenés que llevar a **30 dólares**. Esto era el jueguito
> cuando jugábamos Shopify, ya está."*

Y el corolario operativo, dicho como prioridad única y con plazo:

> *"Todo lo que ustedes ejecuten en el día a día que no los esté ayudando a aumentar el
> ticket promedio es innecesario. **No tienen otra acción más importante, por lo menos
> por los próximos siete días**, que no sea aumentar el ticket promedio."*

### La aritmética que lo cierra
Un caso de alumnos con mucho volumen mensual y ticket promedio **16**. El cálculo en
vivo es por qué el AOV gana a cualquier otra palanca: llevar 16 → 32 **sin tocar el
volumen ni la inversión** duplica la facturación, y como el costo de adquisición ya
está pagado, ese extra se lo lleva entero el margen — en su caso, **la ganancia del
mes se duplicaba**.

Y el mecanismo para subirlo ya no es sólo precio + upsells: es también un backend *done for
you* (un servicio hecho por vos, ofrecido después de la compra).

## Aplicación
Ante un "¿ya escalo?" con oferta que convierte y margen chico: primero ticket
(precio + upsells), después presupuesto. La pregunta de una línea es cuánto queda
por venta después del costo por resultado — si son pocos dólares, no es momento
de escalar. Unit economics del mecanismo en [[upsells-unit-economics]].
