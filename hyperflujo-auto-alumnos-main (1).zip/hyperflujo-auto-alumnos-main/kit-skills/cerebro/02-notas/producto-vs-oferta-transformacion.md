---
type: nota
created: 2026-07-24
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Producto ≠ Oferta: se vende transformación"]
---

# El producto son características; la oferta es la transformación

## Punto clave
Concepto fundacional del modelo: producto = características (PDF, 800 páginas, 100 recetas — a nadie le importan). Oferta = transformación: la diferencia entre quién es el cliente hoy y quién va a ser después. Sin esto, nada vende.

## Detalle
- ❌ "Plan de alimentación + sesiones 1:1 + seguimiento por WhatsApp."
- ✅ "Recuperar tu autoestima. Verte en el espejo y verte linda."
- ❌ "Recetas sin azúcar, sin harina." → ✅ "Sentirte liviana, sin hinchazón, con energía."

## Aplicación
En cada landing, anuncio o copy: si el texto arranca en modo característica, reformular a transformación antes de publicar. Es el primer chequeo de toda pieza de venta.
