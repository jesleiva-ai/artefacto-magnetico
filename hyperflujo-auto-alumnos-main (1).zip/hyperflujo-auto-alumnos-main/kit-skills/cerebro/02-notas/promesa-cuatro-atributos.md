---
type: nota
created: 2026-07-24
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Los 4 atributos de una promesa que vende"]
---

# Toda promesa: cuantificable, sencilla, creíble y transformadora

## Punto clave
Una promesa que vende cumple 4 atributos: (1) cuantificable — número concreto de días/cantidad/resultado; (2) sencilla — la entiende tu abuela; (3) creíble — realista para el mercado donde vendés; (4) transformadora — soluciona un problema real. Fórmula: "Te enseño a hacer [X cantidad] de [resultado] en [Y tiempo] mediante [método]."

## Detalle
- Ejemplos: "Aprendé a multiplicar 100 plantas nuevas en 7 días mediante esquejes." / "Te enseño en 7 días a hacer barritas saludables con mis 100 recetas."
- Error clásico de credibilidad: "Ganá $1.000 dólares en una semana" para el avatar argentino promedio — no le entra en la cabeza, rompe la promesa. Adaptar SIEMPRE al mercado y al avatar.
- Las 4 fórmulas de headline validadas: Beneficio+Tiempo, Beneficio+Cantidad, Anti-fracaso, Identidad.

## Aplicación
Al redactar o auditar una promesa, pasarla por los 4 atributos como checklist. Si falla uno (sobre todo credibilidad para el mercado local), reformular antes de testear.
