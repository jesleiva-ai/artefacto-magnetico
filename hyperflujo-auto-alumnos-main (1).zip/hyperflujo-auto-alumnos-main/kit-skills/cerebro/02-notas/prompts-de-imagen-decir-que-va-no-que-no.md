---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un generador llena todo hueco que le dejes: prohibir describe el hueco, decir qué va en su lugar lo llena"]
---

# Un generador llena todo hueco que le dejes: prohibir describe el hueco, decir qué va en su lugar lo llena

## Punto clave
Un generador llena todo hueco que le dejes: prohibir describe el hueco, decir qué va en su lugar lo llena. Prohibir no alcanza; texto fijado; género antes que calidad.

## La regla
En un prompt de imagen o video, **cada prohibición va acompañada de qué va en su lugar**. Y si un elemento se resiste
(texto en bordes y laterales del mockup, portadas, carteles), **se le saca la tarea**: nada de texto en cuadro, y el texto se compone después.

## Por qué (lo que pasó)
- «Sin texto en inglés» falló tres veces seguidas: los bordes y laterales de los mockups 3D salían igual con texto en
  inglés. «Los laterales van LISOS, con una textura abstracta y sin ningún texto» funcionó a la primera.
- Una palabra en mayúscula para indicar tamaño («el titular en cuerpo GIGANTE») salió **dibujada** arriba del titular.
- «Rostro en contraluz, sin rasgos» dibujó una cara; «sin cabeza en cuadro» dio un traje vacío flotando.
- Un modelo de video reinventaba el texto de las portadas en cada toma pese a tres prohibiciones en mayúscula. Lo único que
  funcionó: prohibir **todo** texto en cuadro y pegar el producto real después.

## Cómo aplicarlo
- **Prohibir no alcanza: decí qué va.** «No packaging with words» + «un bol de harina en vez de la bolsa».
- **Adjetivos de tamaño en minúscula** y lejos del bloque de texto que se quema: «cuerpo muy grande», nunca «GIGANTE».
- **Para una figura humana se pide la pose, no la ausencia**: «completamente de espaldas, la cámara detrás».
- **Texto fijado palabra por palabra** cuando la imagen lleva texto: cada línea entre comillas, en orden, y la lista de
  lo prohibido (precios, monedas, envíos, nombres de producto inventados).
- **Bajadas en tres renglones cortos**, no dos largos.
- **Escena pura** para tomas que no son de producto: «A still frame from a 3D animated short film, not a diagram. Pure
  visual scene, absolutely no words, no labels, no signs.»
- **Sufijo de estilo estable** por tanda (luz, lente, materiales, «no text, no logos, original character designs»)
  pegado igual en todas las tomas: da coherencia y se mejora en un solo lugar.
- **Nombrá el género** de la pieza antes de escribir el prompt (foto de estudio, gráfica de venta densa, captura de
  app, packaging shot). Sin género, el modelo pone su default.
- **Personas**: describí a cada una (rasgos acordes al mercado, ropa sencilla «modest everyday clothes», gesto exacto
  «levanta tres dedos de la mano derecha»), incluidos los secundarios.
- **Objetos ambiguos**: el nombre más literal posible («water reservoir cylinder», no «tank»).

## Error típico
Agregar más mayúsculas y más «NEVER» a una prohibición que ya falló. Si falló dos veces, cambiá el método.

Relacionadas: [[cada-modelo-de-video-tiene-su-trampa]] · [[hoja-de-personaje-y-consistencia]]
