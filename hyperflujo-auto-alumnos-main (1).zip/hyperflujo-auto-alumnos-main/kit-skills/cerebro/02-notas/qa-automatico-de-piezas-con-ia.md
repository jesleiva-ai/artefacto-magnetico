---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Los creativos con IA los aprueba un QA automático más la lectura de sus hojas de cuadros: con cero rojos, se prende"]
---

# Los creativos con IA los aprueba un QA automático más la lectura de sus hojas de cuadros: con cero rojos, se prende

## Punto clave
Los creativos con IA los aprueba un QA automático más la lectura de sus hojas de cuadros: con cero rojos, se prende. Qué mide la máquina, qué se mira a ojo, cómo no engañarte.

## La regla
El filtro humano frena el volumen de testeo. Cada tanda pasa por un **script de QA** y por la **lectura a ojo de sus
hojas de cuadros**; con 0 rojos se carga sin pedir aprobación y se avisa después. La única decisión que queda en manos
del dueño es la que no se puede deshacer (por ejemplo, la declaración de IA en Meta).

## Qué mide la máquina
| Control | Rojo / aviso |
|---|---|
| Formato y duración | 1080×1920, cuadros por segundo constantes, duración dentro del rango |
| Planos negros e imagen trabada | cualquier tramo negro o congelado fuera de lo pedido |
| Volumen | LUFS integrado y pico (Meta sirve todo normalizado a ~−14 LUFS: masterizá cerca de −14/−16 con limitador a −1 dBTP) |
| Tono de la voz | por encima de ~300 Hz avisa «voz demasiado aguda» |
| Idioma de la voz | detectado **sin forzarlo**: tiene que ser el de la tienda (con filtro de voz real para que no alucine sobre música) |
| Ritmo | palabras por segundo dentro del rango |
| Voz contra guion | similitud mínima |
| OCR del texto en pantalla | precio o moneda = rojo; otro alfabeto u otro idioma = aviso; marcas ajenas = rojo |

## Qué se mira a ojo (hoja de 12 cuadros por video)
Manos o caras raras, texto grande deformado, logos ajenos, personajes reconocibles, producto ≠ mockup real, casting
que no corresponde al mercado. La letra chica deformada de un mockup no es rojo si a tamaño feed no se lee.

## El video sano no lo prueba la duración
Cuatro videos salieron rotos con duración y tamaño correctos (índice del mp4 al final, 9 s de voz perdidos por un
filtro de volumen en el render, render en lote con la mitad de los cuadros, voz comida de a pedacitos al mezclar en el
mismo filtro que los subtítulos). Controles sobre el mp4 **final**:
- `ffmpeg -v error -i video.mp4 -f null -` → 0 líneas;
- cuadros contados (`ffprobe -count_frames`), no la duración;
- la envolvente de la voz por ventanas contra el audio original → misma cantidad de ventanas y correlación ~1;
- índice (`moov`) antes de los datos (`+faststart`).

## Sincronía de voz e imagen
- Un audio guardado de una corrida anterior desfasó la voz 0,55 s después de retocar el guion: el motor tiene que
  **rehacer siempre el audio** al re-renderizar.
- El control que no comparte nada con el motor: buscar la voz de cada corte en el archivo final con código propio, y
  comparar la apertura de la boca contra la voz en el mismo momento (probado rompiéndolo: 0,3 s de corrimiento se
  detectan).
- Si una queja de «desfasado» no se confirma midiendo, se pide el segundo exacto antes de rehacer.

## Cómo no engañarte con tu propio QA
- **¿Esa medida podía ver el defecto?** Antes de escribir «revisado», preguntátelo. La duración no ve voz perdida; el
  OCR de letras de un alfabeto no ve una página impresa en otro idioma.
- **Una alerta se revisa en el cuadro entero y sus vecinos** contra todas las reglas, no solo la que disparó.
- **El verificador vive aparte del motor**: si comparte funciones, hereda sus errores.
- **Pasale el caso malo**: una compuerta que nunca viste fallar no sabés si funciona.
- **Leé el texto quemado a ciegas** (transcribí lo que se ve sin mirar el guion) y después compará.

Relacionadas: [[montaje-con-ffmpeg-y-sus-trampas]] · [[cada-modelo-de-video-tiene-su-trampa]]
