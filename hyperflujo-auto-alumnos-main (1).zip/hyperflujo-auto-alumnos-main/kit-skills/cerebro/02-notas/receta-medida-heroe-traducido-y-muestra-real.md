---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["La plata la hace un video héroe traducido exacto, y el mejor CPA lo da la imagen con una muestra real del producto"]
---

# La plata la hace un video héroe traducido exacto, y el mejor CPA lo da la imagen con una muestra real del producto

## Punto clave
La plata la hace un video héroe traducido exacto, y el mejor CPA lo da la imagen con una muestra real del producto. La plata la hace el héroe traducido exacto; el mejor CPA, la muestra real.

## La regla
Después de medir por **familia de creativo** todo lo corrido durante ~2 meses (varios idiomas, muestra grande):
1. La tanda diaria **fabrica héroes**: la estructura del ganador grande con otra muestra del contenido y **tomas
   nuevas**. El primer conjunto de video del día es un héroe.
2. **1 de cada 3 anuncios es un estático con una muestra real del contenido** (una pantalla, un paso, una
   plantilla, tal cual está en el entregable).
3. **Cuando un héroe gana, se traduce exacto a todos los idiomas** y entra a la escala.
4. **Nada de maquillaje sobre un ganador** (cambiar solo voz, música, color o el gancho de un video cansado).

## Por qué (lo medido, en relativo)
| Familia | Parte del gasto | ROAS | CPA (índice, héroe = 100) |
|---|---|---|---|
| Video héroe traducido exacto a cada idioma | ~38 % del gasto, más de la mitad de la ganancia | 1,67 | 100 |
| Estático «muestra real del producto» (los mejores) | ~3 % | 1,83 | 87 (el mejor CPA) |
| Segundo ganador traducido exacto | ~1 % | 1,79 | 91 |
| Mismo héroe con otra apertura (relevos) | ~8 % | 1,39 | 90 |
| Video nuevo con la estructura del héroe | ~1 % | 1,50 | 118 |
| Todo lo demás (ángulos e iteraciones sueltas) | ~49 % | 1,28 | 129 |

Lo que **no** sirvió:
- 10 variaciones cosméticas del héroe (gancho, voz, música, color; mismo cuerpo): 0 compras.
- Resubir el mismo video con la metadata borrada: Meta casi no lo entrega.
- UGC hecho con IA en la primera prueba: 0 compras con poco gasto.
- Un anuncio solo por conjunto en la escala: ROAS 0,56.

Prometedor con muestra chica: **review de la app** (grabación real de la app de entrega con voz en off), ROAS 2,1.

## Cómo aplicarlo
- Registrá cada anuncio con su **familia** (héroe, muestra, traducción, relevo, formato nuevo) y su **formato**, y
  medí por familia con 3 días o más, no por anuncio suelto.
- Antes de proponer variar un ganador, acordate de que **Meta agrupa lo que se parece**: si el cambio no es visual
  y grande, es el mismo anuncio para el algoritmo.
- El techo para crecer no es la escala: es tener **héroes nuevos**.

## Error típico
Llenar la tanda de iteraciones chiquitas sobre el ganador «porque ya funcionó». Funcionó ese video; sus clones
compiten contra él por el mismo público.

Relacionadas: [[un-ganador-cansado-se-revive-con-su-post]] · [[los-estaticos-que-ganan]] ·
[[portar-un-ganador-a-otro-idioma]]
