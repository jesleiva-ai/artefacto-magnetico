---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Los reels orgánicos se modelan por cuenta y por molde, se publican a lo sumo 3 por día y las vistas no son ventas"]
---

# Los reels orgánicos se modelan por cuenta y por molde, se publican a lo sumo 3 por día y las vistas no son ventas

## Punto clave
Los reels orgánicos se modelan por cuenta y por molde, se publican a lo sumo 3 por día y las vistas no son ventas. Modelar cuentas, 3 por día, etiqueta IA, bucles, de orgánico a anuncio.

## Las reglas
1. **Modelar cuentas, no hashtags.** Seguí cuentas de referencia que hacen reels virales con IA y medí cada reel contra
   **la mediana de su propia cuenta**: un outlier es ≥ 3 veces esa mediana. (Los resultados por hashtag de la API de
   Instagram traen solo fotos y carruseles, ningún reel: no sirven para esto.)
2. **Bajar a un molde** lo que se repite en los outliers: la frase molde, los bloques, la estética, la voz y la receta de
   producción. Un molde nuevo se prueba con **1 piloto**; si pasa la mediana de tu cuenta, va en serie.
3. **Máximo 3 publicaciones por día y por cuenta** en TikTok. Lo hecho con IA se sube **con la etiqueta de contenido IA**.
   Los creativos de anuncios no se suben como orgánico en TikTok, y ningún caption se repite.
4. **Bucles abiertos** para retener: «Pero eso no es nada.» / «Y el último es el más loco:».
5. **Las vistas no son ventas**: un estilo que explota en orgánico se prueba en anuncios con sus propias reglas.

## Por qué (lo medido)
- Una cuenta de TikTok pasó de miles de vistas por día a casi cero **el mismo día** en que la frecuencia subió de 4-7 a
  10-11 publicaciones diarias (varias colas publicando a la vez, captions repetidos, anuncios resubidos como orgánico y
  contenido IA sin etiquetar). Otras cuentas con 3-5 por día siguieron con vistas. La frecuencia coincide
  con la caída exacta; lo de la etiqueta IA es hipótesis, no está medido, pero el riesgo no vale la pena.
- Las cuentas de referencia que crecieron publican **3 por día**.
- En una tanda de siete reels de un mismo molde, uno solo explotó (ver [[estilo-viral-macro-con-personaje]]); el tema
  pesó más que el formato. Una golondrina no hace verano: se mide qué familia repite el efecto antes de darla por
  ganadora.
- Una cuenta viral de referencia con un personaje 3D que habla: lo morboso se lleva restricción de edad y pierde
  alcance; los objetos neutros que dan consejos desde afuera rinden poco.

## Moldes que se probaron
- **Foto macro + personaje + «Ni se te ocurra… a menos que…»** con 3 casos y bucles.
- **Personaje 3D que es el tema**, amenazado, hablando en primera persona.
- **Canción corta** (10-20 s) cantada por alguien en un decorado del tema, con la marca dentro de la escena.
- **Animación 3D plana programada** (Three.js en un navegador sin pantalla): gancho-pregunta o dato imposible →
  mecanismo con analogías cotidianas → giro → «Así que…» → «Mandáselo a ese amigo que…» (empuja los envíos). Barato y
  traducible (mismo archivo de escena, otra voz y otros textos), pero rindió muy por debajo del macro con personaje.
- Peluche 3D que baila un audio de moda (transferencia de movimiento) y microdramas: en Instagram no rindieron.

## Cómo pasarlo a anuncio
No regales el caso completo ni la respuesta, 30 s o menos, cerrá con el producto real, sin precio, y **cada pieza sola
en su conjunto** para medirla.

## Operación
- Cola de publicación con horario fijo y separación mínima entre publicaciones (~45 min). Facebook no programa a más de
  ~29 días; Instagram no programa con menos de ~20 min de anticipación.
- Lo programado en una red es el archivo que se subió ese día: reemplazarlo en tu carpeta no lo cambia.
- Un CTA de comentario («Comentá GUÍA») con un bot que responde a esa palabra convierte el orgánico en conversación.
- Medí a los 3 días por familia de gancho y repetí lo que pegó.

Relacionadas: [[estilo-viral-macro-con-personaje]] · [[estilo-personaje-3d-que-habla]]
