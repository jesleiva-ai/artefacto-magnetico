---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El anuncio va sin precio, sin rebaja, sin otras redes y sin palabras que delaten la categoría"]
---

# El anuncio va sin precio, sin rebaja, sin otras redes y sin palabras que delaten la categoría

## Punto clave
El anuncio va sin precio, sin rebaja, sin otras redes y sin palabras que delaten la categoría. Sin precio, sin rebaja, sin otras redes, un idioma por anuncio.

## Las reglas
1. **Sin precio en ningún lado**: imagen o flyer, placas, cierre del video, subtítulos, voz, texto principal, título y
   descripción. Ni símbolos de moneda, ni tachados, ni «precio de lanzamiento $X». Se puede nombrar la oferta o el
   lanzamiento **sin cifra** («lo que cuesta una salida al cine», «+8 regalos»). Manda sobre cualquier referencia
   ajena que sí lo muestre.
2. **Sin frases de rebaja ni urgencia** en el copy («ahora a precio rebajado», «solo por hoy», cuentas regresivas). En
   la UE, el tachado solo vale contra el precio más bajo real de los 30 días anteriores (directiva Omnibus) y la
   urgencia ficticia es práctica engañosa.
3. **Sin nombrar otras redes ni marcas** («compite con TikTok», una planilla de una marca conocida, una plataforma de
   video). Se reescribe genérico: «el celular», «una planilla digital».
4. **El copy no nombra el formato del producto** («PDF», «ebook», «descargable», «guía online»): genera curiosidad y
   toca el dolor, sin describir características. Así un competidor que busca la categoría en la Biblioteca de Anuncios
   no te encuentra. El video sí puede cerrar con «acceso inmediato».
5. **CTA mínimo**: «Hacé clic acá», «Tocá el botón». El botón de Meta dice «Más información», casi nunca «Comprar», y
   la pieza no lo tapa.
6. **Un idioma por anuncio, de punta a punta**: voz, copy, link al dominio de esa tienda, países del conjunto y filtro
   de idioma (locale) en el mismo idioma. Texto escrito en pantalla en otro idioma es aviso, no bloqueo; voz, copy y
   link en otro idioma, sí.

## Lo que pide el chequeo de cumplimiento de Meta (aprendido en los ejemplos)
- **Atributos personales**: nunca afirmar o preguntar una condición de quien mira («¿tenés deudas?», «¿te vas de
  viaje y el inglés te frena?»). Contalo en tercera persona («casi nadie anota sus gastos») o desde el deseo («maleta
  lista, pasaporte en mano»).
- **Resultado implícito garantizado**: «tenés tomates en un mes» → «podés tener tomates». Sin plazos de resultado.
- **Promesas de dinero o salud**: sin cifras de ahorro, ingresos ni curas. En salud, la marca usa verbos blandos
  («favorece») y la promesa fuerte, si la hay, la dice una persona real en primera persona.
- **Bucles abiertos**: todo «ni se te ocurra…» se cierra dentro del mismo video.
- **Marcas registradas en el nombre del producto** («X en 7 días» con el nombre de un software): riesgo de denuncia.
  Ningún logo ni interfaz ajena en imagen.

## Por qué (lo que ya pasó)
- Una frase de rebaja que venía copiada de los ganadores en la traducción hizo rechazar varios anuncios por «prácticas
  comerciales inaceptables», mientras la **misma pieza sin esa frase** estaba aprobada en otros cinco idiomas.
- El copy base de muchas cuentas decía «compite con [otra red]» y las tandas lo copiaban: expone a rechazos.
- Sin filtro de idioma, un anuncio en español le salió a angloparlantes en un país y a lusoparlantes en otro.

## La declaración de IA
Meta permite declarar contenido hecho con IA en el creativo, y **no se puede cambiar después de creado**. Es una
decisión del dueño del negocio: tomala una vez, por escrito, y aplicala igual a toda la tanda. En los orgánicos de
TikTok es otra cosa: ahí conviene etiquetar (ver [[reels-organicos]] en producción).

## Rechazos: se resuelven, no se consultan
- **Copy con rebaja, precio, urgencia u otra red** → creativo nuevo con el mismo medio y el copy limpio.
- **Marca o material ajeno** → no se apela: se pausa y se rehace con otro video ([[material-ajeno-hace-rechazar-aunque-venda]]).
- Los aprobados que corren **no se tocan**: cambiar el creativo desoptimiza. La regla entra con los nuevos.

## Cómo aplicarlo
Antes de cargar: OCR de la pieza + lectura del copy con una lista de palabras prohibidas **en cada idioma** (las
frases de rebaja cambian por idioma). Crear en pausado → auditor de idioma con 0 errores → prender.

Relacionadas: [[checklist-antes-de-producir]] · [[adaptar-un-gancho-ajeno-sin-romper-tus-reglas]]
