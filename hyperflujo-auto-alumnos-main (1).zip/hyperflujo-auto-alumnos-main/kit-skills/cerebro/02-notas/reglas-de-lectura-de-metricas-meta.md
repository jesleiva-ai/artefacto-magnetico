---
type: nota
created: 2026-07-27
tags: [meta-ads]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Como leer metricas de Meta", "El reloj, el piso y la banda"]
---

# Cuatro reglas para leer métricas de Meta sin engañarse

## Punto clave
Reglas para que ninguna métrica de Meta se lea como verdad absoluta: el reloj de
una oferta arranca con la primera campaña de VENTAS, las compras de Meta son un
piso (la tienda es la verdad), estamos siempre en etapa de datos, y el AOV es
banda por mercado.

## Las cuatro reglas
1. **El reloj**: la antigüedad de una oferta se cuenta desde que se activó la
   primera campaña de VENTAS y la cuenta empezó a gastar — no desde el rango del
   informe. Suele haber antes una campaña chica de visitas al perfil de IG o de
   tráfico solo para ACTIVAR la cuenta (técnica de calentamiento, vista en
   cuentas propias y de alumnos).
   **La receta exacta** (workshop abierto, 2026-08-16), ante la pregunta de si
   las cuentas nuevas se calientan o se lanzan directo: *"tirale una campaña de
   tráfico de un dólar para que arranque la cuenta, y 7 días, y lanzarla"*. Un
   dólar por día, objetivo tráfico, siete días. Es práctica de la casa, no
   procedimiento documentado por Meta: no existe "calentamiento" en la doc
   oficial.
2. **El piso**: Meta subregistra conversiones — casi siempre hay más ventas
   totales que las trackeadas. El veredicto de rentabilidad se calcula blended:
   ventas totales de la tienda (Shopify o la plataforma que uses) / gasto de
   Meta. Todo ROAS de Meta es conservador.
3. **Etapa de datos**: el administrador varía según la audiencia que va
   alcanzando. Las métricas son referencia y rangos, nunca dogma — vale para
   las propias y para las del backup.
4. **AOV por mercado**: el ticket promedio es banda relativa al mercado — el
   mercado inglés es más sofisticado y de mayor poder adquisitivo que LATAM
   (ej. real: en una misma oferta, el producto dominante en EE. UU. cuesta
   ~2× el dominante en español). El objetivo 30-45 de
   [[validacion-oferta-tasa-conversion]] es la banda internacional, no
   universal.

## Aplicación
Antes de juzgar cualquier oferta del backup o propia: fijar el reloj real,
corregir por subregistro con las ventas de la tienda, y comparar contra la banda
de SU mercado.
