---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Reglas duras de la escala"]
---

# Reglas duras de la escala

## Punto clave
No tocar las escalas por dentro, techo fijo, ganadores que siguen en testeo, concentrar.

Reglas que ningún robot ni ninguna sesión rompe sin que el dueño del negocio lo diga explícitamente. Cada una salió de algo que salió mal.

## 1. Las escalas no se tocan por dentro

En una CBO con tope de costo de escala **no se apagan conjuntos ni anuncios adentro.** Y en ninguna campaña (testeo incluido) se pausa un anuncio suelto dentro de un conjunto.

> "No sirve tener un conjunto con 5 anuncios y apagar los 3 que menos venden. Todo el conjunto es una estrategia."

Meta reparte entre los anuncios del conjunto; recortarle los flojos rompe la estrategia que vendía. Teníamos robots que "limpiaban" anuncios caros dentro de las escalas en todos los mercados; los apagamos. La escala se maneja **solo a nivel campaña** (presupuesto y tope) o **sumando conjuntos nuevos** con ganadores.

## 2. Un techo fijo por escala

Ninguna campaña de escala pasa de un **techo diario fijo**, aunque venda. Más que eso nunca hizo falta: con tope de costo, el presupuesto rara vez es lo que limita. Si una campaña empieza a gastar cerca del techo, se analiza con el dueño antes de subirlo.

El techo acota también todo lo automático: el techo dinámico, el piso del pico y cualquier "zanahoria".

## 3. Los ganadores siguen corriendo en el testeo

Pasar un ganador a la escala **nunca** apaga su conjunto de testeo. Testeo y escala corren en simultáneo. Y si un ganador del testeo quedó apagado con historia buena (≥ 5 ventas y CPA histórico bajo el objetivo), se vuelve a prender.

## 4. No tocar la segmentación ni el link de lo que corre

- Editar países o segmentación de un conjunto que corre lo manda de vuelta a aprendizaje. Con muchos conjuntos, se cae todo junto. Una vez casi sacamos varios países de muchos conjuntos vivos a la vez; se frenó a tiempo.
- Lo mismo con link, dominio o UTM de un anuncio vivo: lo desoptimiza. Va en la próxima tanda (salvo link roto).
- **Qué se hace en su lugar:** los conjuntos **nuevos** nacen sin los países que pierden, y los viejos se apagan **de a poco**.

## 5. El héroe va en un solo lugar

Cuando un creativo explota, la tentación es duplicarlo en seis campañas. En un mercado grande eso aceleró la fatiga: el mismo ganador compitiendo contra sí mismo en varias subastas. Lo que funcionó se lleva a **la escala que ya existe**, como conjunto nuevo. Nada de campañas nuevas para el mismo mercado.

## 6. Un motor rentable no se apaga sin reemplazo probado

En otro mercado grande, un solo creativo en una campaña hacía la mayor parte de las ventas semanales. Lo apagamos por una sospecha que no habíamos probado y el mercado murió. Regla: antes de apagar algo que gana, tenés que tener el reemplazo **ya ganando**.

## 7. Concentrar, no fragmentar

Un testeo + una escala por mercado. Las escalas que sobran se vacían de a poco hacia una sola y después se pausan, sin cortes bruscos donde hay ganancia.

## 8. Lo que no funcionó: un ganador por conjunto ("uno a uno")

La hipótesis: Meta le da a un solo anuncio entre el 48 % y el 91 % del gasto del conjunto, así que poniendo cada ganador en su conjunto (con su propia escalera de topes) se repartiría mejor. Lo probamos tres días en dos mercados al lado de la escala normal.

**Veredicto: no funcionó.** En uno gastó casi nada (con topes de arranque bajos nunca entregó) y en el otro dio ROAS 0,3. Lo que sí funciona: CBO con tope de costo con **varios ganadores** y topes por escalón.

## 9. Escalar de golpe un mercado chico baja la conversión de la tienda

En mercados chicos el ROAS cayó **la misma semana** en que el gasto se multiplicó. El anuncio y la tienda no cambiaron, ni el CPM, ni el CTR, ni la tasa de pago aprobado: **lo que cayó fue la conversión de las visitas** (de ~2,7 % a ~1,5 % en un caso). Más presupuesto de golpe = Meta sale a buscar gente menos interesada. Para recuperar: volver al gasto donde ganaban y crecer de a poco con ROAS, más creativos nuevos.

## 10. Un salvavidas es para cubrir una caída, no para escalar

Si tenés más de una cuenta, podés dejar escalas de respaldo "tibias" en otra cuenta con historial, para prender si la cuenta principal de un mercado se frena (ver [[modos-ganancia-ofensivo-salvavidas|modos]]). Cuando probamos escalarlas como si fueran la escala principal, no rindieron como la original. Se usan, cubren la caída y vuelven a su presupuesto tibio.
