---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Rehabilitar un mercado que se cae"]
---

# Rehabilitar un mercado que se cae

## Punto clave
Una semana de testeo concentrado con ganadores traducidos; si no, borrón y cuenta nueva.

## Primero: ¿se cayó de verdad?

Antes de rehabilitar, descartá lo que no es el mercado:

1. ¿Los robots de ese mercado midieron y corrieron? (un mercado "pinchado" muchas veces es un robot que falló en silencio)
2. ¿La cuenta está al día con los pagos?
3. ¿La tienda cobra? (medio de pago caído, checkout en otro idioma, precio que se movió solo)
4. ¿Mirás 3 días o uno? Un día malo no es una caída.

## La rehabilitación (una semana de testeo concentrado)

Cuando un mercado está por caerse (ROAS de 3 días muy por debajo de 1, o en equilibrio perdiendo plata):

- En la campaña de testeo del mercado, **3 días seguidos, 5 conjuntos nuevos por día** a presupuesto P.
- Cada conjunto lleva **3 anuncios** (mezcla foto y video: 2 + 1).
- Los anuncios son **los ganadores de los otros mercados traducidos**, con la mejor calidad posible. Traducir = el mismo video con voz y textos del idioma, no una recreación.
- Se dejan **prendidos**.
- **A los 7 días** se decide: si no funcionó, se apaga el mercado.

La lógica: antes de apagar un mercado se le da una semana con lo que **ya ganó en otros lados**. Si ni eso vende, el problema no es de creativos.

## Si la rehabilitación no alcanza: borrón y cuenta nueva

Para varios mercados que venían cayendo con cuentas desgastadas, hicimos un relanzamiento completo:

- **Todo nuevo:** dominio, tienda (clonada idéntica: productos, ofertas, poscompra, precios), página, píxel y cuenta publicitaria. Se pueden agrupar varios mercados en una sola cuenta nueva.
- **Una sola campaña por mercado: "1-1-10"** — una CBO, un conjunto, con **los 10 mejores creativos históricos** de ese mercado y sus copies, sin tope.
- El ranking de los 10 se arma por **lo cobrado** del historial, agrupando por la pieza real (video/imagen), no por nombre.
- En cuentas nuevas, los creativos se suben de nuevo (no depender de la página vieja).

**Trampas que aparecieron:**
- Una cuenta nueva quedó con un pago sin saldar y **el vigía de pagos no lo detectó**; los creativos nuevos eran rechazados por permiso hasta que se pagó. En cuentas nuevas, revisá el estado de la cuenta a mano los primeros días.
- Moldes viejos arrastran datos que no querés (beneficiario de la DSA: poné a la empresa, nunca a una persona; ubicaciones restringidas a una sola red). Revisá cada campo heredado.
- Si una cuenta o un portafolio traba por verificación, pasá a otra cuenta activa; no fuerces la verificación.
- Ningún robot de escala manejaba estas campañas nuevas al principio: **se revisan a mano** hasta que entran al perímetro de los robots.

## Recuperar un mercado chico que se escaló de golpe

No es lo mismo que una caída por fatiga. Si el ROAS cayó la misma semana en que multiplicaste el gasto y la conversión de la tienda bajó, volvé al gasto donde ganaba y crecé de a poco. Ver [[reglas-duras-de-la-escala|reglas duras, punto 9]].
