---
type: nota
created: 2026-07-24
tags: [meta-ads]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Escala de ROAS para productos digitales low-ticket"]
---

# La escala de ROAS low-ticket: 1 / 1,5 / 2 son las fronteras

## Punto clave
Benchmark propio para productos digitales low-ticket, en 4 tramos: ROAS < 1 = perdiendo dinero; 1 a 1,5 = no pierde pero es punto de mejora (no escalable, tampoco para pagarla); 1,5 a 2 = aprobada; > 2 = excelente, candidata a escalar. Nunca evaluar contra un único número objetivo: clasificar por tramo.

## Detalle
- La escala nace de la economía del low-ticket: arriba de 1 ya hay rentabilidad, pero el negocio busca 1,5+ sostenido.
- Es la escala que usan los reportes automáticos de campañas (informe diario + comparativo 7 vs 3 días).

## Refinamiento 2026-08-11: estos tramos son para LEER, no para escalar
Los cuatro tramos siguen valiendo como clasificación de estado. Dos precisiones que
salieron de contrastar la economía contra la documentación oficial:
- **El equilibrio real está en ~1,09** (`1 / margen`, con 8% de comisiones y el
  producto ya creado), no en 1. O sea que el umbral de 2 es un **piso de ganancia
  con casi el doble de colchón**, no la frontera de la rentabilidad.
- **Para decidir una suba de presupuesto no sirve este ROAS**, que es el mezclado:
  se usa el **ROAS marginal** del último salto.

## Aplicación
Toda lectura de campaña low-ticket (propia o de alumno) se clasifica en estos 4 tramos antes de decidir. "Candidata a escalar" exige tramo > 2 — y una vez adentro de la escala, la decisión pasa al marginal.
