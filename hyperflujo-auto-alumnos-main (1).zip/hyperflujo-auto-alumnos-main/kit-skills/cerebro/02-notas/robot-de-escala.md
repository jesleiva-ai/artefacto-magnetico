---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Robot de escala: presupuesto, topes, ganadores y perfil"]
---

# Robot de escala: presupuesto, topes, ganadores y perfil

## Punto clave
Robot de escala: presupuesto, topes, ganadores y perfil. La escala la operan cuatro robots que se reparten el trabajo sin pisarse: uno mueve **presupuestos**, otro mueve **topes de costo**, otro **lleva ganadores** del testeo a la escala, y otro calcula el **perfil** de cada mercado que los demás leen. Las reglas de negocio están en [la canilla](../testeo-y-escala/03-escala-con-tope-de-costo-la-canilla.md); acá va cómo funcionan como máquina.

La escala la operan cuatro robots que se reparten el trabajo sin pisarse: uno mueve **presupuestos**, otro mueve **topes de costo**, otro **lleva ganadores** del testeo a la escala, y otro calcula el **perfil** de cada mercado que los demás leen. Las reglas de negocio están en [[escala-con-tope-de-costo-la-canilla|la canilla]]; acá va cómo funcionan como máquina.

## Escalera de presupuesto

**Corre:** cada 30 minutos. **Unidad:** la campaña si es CBO; cada conjunto activo si es ABO (los presupuestos no se reparten).

1. **Reset diario** antes del pico del mercado: cada unidad vuelve a su arranque. El arranque sale de escalones según la historia: ROAS y ventas de ayer y de los últimos 3 días (se toma el mayor). Si el reset no corrió (por un freno de la API), **se reintenta** en las vueltas siguientes durante unas horas.
2. **Cada vuelta**, con el ROAS del día de la unidad (el mayor entre Meta y lo cobrado, porque Meta atribuye tarde de madrugada):
   - **sube** ×4 si el presupuesto es chico, ×2 si es grande, con buen ROAS y compras mínimas, una vez por hora;
   - **sube sin esperar** si gastó la mitad con buen ROAS;
   - **baja** −30 % (−50 % si muy mal) con muestra suficiente; nunca debajo del piso, ni en el pico debajo de su piso de pico;
   - **corte duro** al piso con ROAS muy bajo y gasto suficiente, salvo CPA bueno o mañana protegida.
3. **Techo fijo** por campaña y un tope total. Si una campaña llega a su techo con la mitad gastada, avisa.
4. Cada cambio **se relee** en Meta (presupuesto y que siga activa).
5. Si alguien sube un presupuesto a mano, el robot parte de ese número.

Tiene modo **simulacro**: anota lo que haría con presupuestos virtuales, sin tocar Meta. Toda escala nueva arrancó así unos días.

## Escalera de topes (la canilla)

**Corre:** cada 30 minutos, desfasado del de presupuesto (así no se pisan).

- Solo en las escalas marcadas con "escalera". El robot de presupuesto **no** les toca la puja.
- **Reset** a topes bajos escalonados antes del pico; **memoria** de dónde se abrió la canilla ayer.
- **BUSCA** (sube un escalón por media hora si la campaña no gasta el umbral) → **IMPRIME** cuando gasta el umbral con ventas (queda un escalón arriba) → trabajo fino (baja si caro, sube si se frena).
- **Freno de subidas:** toda subida sobre una campaña que vende queda a prueba; si con muestra mínima el CPA cobrado sale por encima de la línea, vuelve al último tope probado y no lo pasa por 3 h.
- **Umbral por campaña:** en mercados chicos el umbral general era demasiado alto y los topes trepaban al techo sin encontrar precio; cada campaña puede pisar el umbral general.
- **Fase "fuera":** una campaña marcada a mitad del día no se toca hasta mañana.
- Si Meta pausa el conjunto al cambiarle la puja (pasa con algunas herramientas), lo vuelve a prender.

## Pasaje de ganadores (testeo → escala)

**Corre:** a la medianoche, después de la cola. Todos sus números salen del archivo de criterio.

- **Ganador:** anuncio activo del testeo con ≥ 5 ventas cobradas (el **menor** entre píxel y cobrado) y CPA bajo el objetivo.
- **Crear escala:** si un mercado no tiene escala y junta 2 ganadores, arma **una** CBO con tope de costo, 3 escalones de tope, con los ganadores, segmentación copiada del testeo, y la registra en la configuración de escala (en simulacro o con escalera). Si ya existe una pausada con ese nombre, la reusa.
- **Nutrir:** los ganadores que no corren en ninguna escala de la cuenta entran como **conjunto nuevo** en la escala de su mercado, copiando segmentación y tope del conjunto que más gastó. Como mucho uno por día por escala.
- **Sacar anuncios de la escala: APAGADO.** Existía y se apagó: las escalas no se tocan por dentro.
- Siempre reusa la **publicación original** del ganador (mismo post), no un creativo nuevo: conserva la prueba social.
- Las campañas marcadas como manuales del dueño no se tocan.

**Trampa que tuvo:** corrido con un timeout corto, esperaba el candado de los otros robots, se cortaba, y al reintentar reusaba la campaña y le sumaba **otros** 3 escalones. Una escala quedó con 9 conjuntos. Regla: un robot que crea cosas se corre con timeout largo o **verifica en Meta antes de reintentar**.

## Perfil por mercado

**Corre:** cada noche antes del reset. Calcula ticket, ROAS meta adaptativo, CPA = ticket ÷ meta (que pasa a ser tope y freno de sus escalas, dentro de un piso y un techo), pico horario y fase del ciclo. Escribe un informe legible y un JSON por día, y aplica en la configuración guardando lo anterior.

Detalle de criterio en [[perfil-por-mercado-y-horarios|perfil por mercado]].

## Robots de apoyo de la escala

- **Picos horarios:** mide en las ventas cobradas de 14 días la franja de 4 h con más ventas de cada tienda. Desde 2 h antes y durante el pico, la escalera abre la canilla en el último punto conocido y la de presupuesto trata la campaña como "pico".
- **Premio de pico:** a la noche abre más tope **solo** a los mercados con ROAS ≥ meta en 3 días; a la mañana devuelve **exacto** lo guardado.
- **Pico de otro huso:** los mercados de otro continente llegan a su pico ya escalados; un robot les abre el tope antes y los devuelve después. Nunca subirlos después de que empezó su día nuevo.

## Cómo conviven sin pisarse

- **Un candado** (archivo de lock) sobre la configuración de escala. Todo robot que la escribe lo toma; si está ocupado, espera con un tope de tiempo y si no, deja la vuelta para la próxima.
- **Escrituras atómicas:** se escribe a un temporal y se reemplaza (nunca a medias).
- **Cada robot una palanca:** presupuesto uno, topes otro. El guardia nocturno solo puede tocar topes, de a un escalón.
- **No envolver con el mismo candado** un script que adentro pide ese candado: se bloquea contra sí mismo (nos pasó, ver [[robots-que-fallan-seguros|fallar seguro]]).
- **Reintentos ante el freno de la API:** todo robot que llama a Meta reintenta cuando la API está "enfriando". Una noche el de presupuesto abortaba todas las vueltas por el freno y las escalas quedaron con el presupuesto del reset y topes altos: el pico a fondo falló por el presupuesto.
