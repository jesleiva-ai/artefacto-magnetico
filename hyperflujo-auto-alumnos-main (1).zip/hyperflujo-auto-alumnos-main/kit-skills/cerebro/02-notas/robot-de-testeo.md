---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Robot de testeo: la cola y la poda"]
---

# Robot de testeo: la cola y la poda

## Punto clave
Dos robots trabajan el testeo. Uno **prende** (la cola), el otro **apaga y sube** (la poda). Ninguno crea creativos: eso lo hace la fábrica.

Dos robots trabajan el testeo. Uno **prende** (la cola), el otro **apaga y sube** (la poda). Ninguno crea creativos: eso lo hace la fábrica.

## La cola de testeo

**Corre:** a la medianoche, y se puede volver a correr en el día (completa hasta 5).

**Qué hace:**
1. Lee la cola de cada mercado (un JSON con los conjuntos pausados en orden de llegada).
2. Suma solos al final de la cola los conjuntos **pausados, sin gasto**, creados en la campaña de testeo del mercado desde una fecha de alta.
3. Por cada uno de los siguientes 5 del mercado:
   - relee en Meta que siga pausado y sin gasto (si alguien ya lo prendió, no cuenta);
   - le copia la segmentación geográfica, exclusiones y filtro de idioma del **conjunto de testeo vivo más reciente**;
   - lo pone a presupuesto P;
   - prende sus anuncios sanos (no rechazados ni con problemas) y el conjunto;
   - verifica releyendo.
4. Un conjunto sin ningún anuncio sano queda excluido de la cola.

**Compuerta:** lo marcado como "auditoría pendiente" no se prende hasta pasar por el auditor de idioma (copy, dominio, países, filtro de idioma y OCR del video). Los errores de país o de filtro no excluyen, porque el robot los corrige al prender; los de link, copy o precio, sí.

**Modo seco:** `--seco --solo <MERCADO>` muestra qué haría sin tocar nada. `estado` dice cuántos quedan por mercado. `pendientes <mercado>` le dice a la fábrica si ya hay stock (con 10 o más esperando, no produce).

## La poda (el piloto)

**Corre:** dos veces por día (media tarde y noche). Al principio corría una sola; un conjunto de P gasta hasta ~1,7 P por día, así que se escapaban.

**Cómo decide** (todo desde el archivo de criterio único, con ventas cobradas):

| Regla | Acción |
|---|---|
| 3 P sin ventas | apagar |
| 2 P sin ventas ni inicios de pago | apagar |
| CPA histórico > ~0,8 T | apagar |
| CPA de 5 días > ~1,1 T | apagar, **salvo ganador protegido** |
| 2 ventas a CPA < ~0,65 T | subir a 2 P |
| ≥ 5 ventas con CPA histórico < ~0,65 T | proteger (no se apaga, se prende si estaba apagado) |

**Cómo se arma la decisión:**
- Un script de historial reconstruye, para cada conjunto del perímetro, los cambios de presupuesto (los saca del registro de actividad de Meta, que trae valor viejo y nuevo), las compras, el gasto y el ROAS de 3 y 7 días.
- Calcula **dos decisiones**: una con el píxel y otra con lo cobrado. Aplica la de lo cobrado; si la plataforma de la tienda no responde, cae a la del píxel y lo anota.
- Otro script aplica la lista (apagar / subir) y verifica.

**El perímetro:** un archivo dice qué cuentas y qué campañas puede tocar la poda: **solo campañas de testeo** (las que se llaman "TESTEO …", sin tope de costo, ni CBO, ni escala). Un robot nuevo se reparte **por regla**, no por nombre de campaña, y antes de prenderlo se mira quién más escribe ahí.

## Cómo pasamos de la sombra a lo real

Cambiar el criterio del robot de testeo (de píxel a cobrado) se hizo en **modo sombra**:
1. Durante días el robot calculó la decisión nueva al lado de la vieja **sin aplicarla**, y la anotó.
2. Se midió cuántas veces discrepaban y quién acertaba.
3. Con evidencia y el OK del dueño, la nueva pasó a ser la que se aplica.

Es el patrón para cualquier cambio de criterio en un robot que apaga cosas: **primero sombra, después real.**

## Fallas que tuvo y cómo quedó protegido

- **La rotación de una cola reiniciaba el juicio** al volver a prender un conjunto: en el Administrador se veía gasto viejo + nuevo y parecía que el robot no cortaba. Contá desde el reinicio, y que el robot lo sepa.
- **Un robot que lee mal dice "ok" igual.** El piloto ponía "[ok]" aunque no hubiera podido leer las cuentas. Ahora un informe incompleto lo dice. Ver [[robots-que-fallan-seguros|fallar seguro]].
- **El testeo no tenía tope total:** con la cola y la poda a ritmo parejo los conjuntos activos no crecen sin control, pero vigilá la primera semana que la poda apague al ritmo de la carga.
