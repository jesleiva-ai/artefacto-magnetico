---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cómo hacer que los robots fallen seguros"]
---

# Cómo hacer que los robots fallen seguros

## Punto clave
Cómo hacer que los robots fallen seguros. Un robot que falla y avisa es un problema chico. Un robot que falla y dice "todo bien" es el peor problema que podés tener: los mercados se apagan sin que nadie haga el relevo. Casi todo lo que sigue lo aprendimos así.

Un robot que falla y avisa es un problema chico. Un robot que falla y dice "todo bien" es el peor problema que podés tener: los mercados se apagan sin que nadie haga el relevo. Casi todo lo que sigue lo aprendimos así.

## 1. Fallar abierto o cerrado: elegilo a propósito

- **Los módulos de "inteligencia" fallan abiertos.** El auditor, el aprendizaje, el jurado: si no tienen datos o están viejos, el robot hace lo de siempre. Un auditor roto no puede paralizar la escala.
- **Las compuertas de seguridad fallan cerradas.** QA de creativos, semáforo de la tienda, auditoría de idioma: si no pudieron medir, **no se carga**. Un gris ("no se pudo medir") no es verde.
- **Los cortes de plata, ante la duda, cortan.** Si el freno de cortes no tiene datos de las últimas 3 h, el corte se ejecuta como siempre.

## 2. Un informe incompleto dice que está incompleto, nunca "0"

- La alarma de cansancio no pudo leer ninguna cuenta (la API estaba frenada) e informó "0 cansados". Había 8. Ahora: espera el freno y, si igual le faltan cuentas, el informe dice **"INCOMPLETA: no pude leer N de M"**.
- La cola de traducciones marcaba "0 traducciones hechas" cuando había decenas, porque el cron no encontraba una herramienta. Dos ganadores muy fuertes no se tradujeron a ningún mercado.
- En ganancia neta, lo que no está medido se muestra como **"falta medir"**, no como 0.

## 3. Se verifica por lo que produjo, no por su "[fin]"

- La fábrica escribió "[fin]" dos noches sin producir nada. Ahora: si ningún mercado dejó su registro, avisa y sale con error.
- Un robot que crea cosas se verifica **contra la plataforma**, releyendo lo creado (estado y estado efectivo), no contra su propio log.
- Revisá el efecto de negocio: ¿entraron conjuntos nuevos por mercado hoy?

## 4. El cron no es tu terminal

- **PATH:** todo cron del servidor que use el cliente de la API o el llavero de claves lleva el PATH completo explícito. Sin eso, el script no encuentra la herramienta que le da el token y falla en cada cuenta.
- **Huso horario:** los scripts exportan el huso del equipo; la máquina puede estar en otro.
- **Una máquina que duerme** no dispara tareas por intervalo: en la Mac, "cada N segundos" se perdió una vez; "a tal hora todos los días" sí corre al despertar. Mejor: lo que tiene que pasar sí o sí corre en el servidor.
- **Un reinicio** del servidor (actualización de kernel) mantiene cron y estado, pero **borra /tmp**. Nada importante vive en /tmp.

## 5. Candados: que no te bloqueen en silencio

- Una noche el robot de escala **no corrió 12 horas**: su cron usaba "si el candado está tomado, saltear" y otro script tenía el candado. Peor: ese otro script estaba envuelto con **el mismo candado** que pedía adentro, así que se bloqueó contra sí mismo.
- Reglas:
  - nunca envolver con un candado un script que adentro pide ese mismo candado;
  - un guardia que mire candados tomados de más (y mate al que lo tiene) y robots que no corrieron en X minutos (y los corra);
  - para diagnosticar "no corrió": quién tiene el candado y en qué está esperando.

## 6. Ante el freno de la API: parar y reintentar después

- **Todo robot que llama a Meta reintenta cuando la API está "enfriando"**, con espera. Una noche el robot de presupuesto abortaba cada vuelta por el freno y dejó las escalas con el presupuesto del reset en el pico.
- **El reset de medianoche se reintenta** durante unas horas si no corrió.
- **Las lecturas también gastan cupo.** Un gerente o un barrido corrido dos veces "en seco" frena a los robots igual. Depurá con una sola tienda, contá las llamadas de la última hora antes de lanzar algo pesado.
- **Una escritura "fallida" puede haberse creado.** Si una carga masiva vio un freno y la reanudaste, contá contra Meta por conjunto + nombre + creativo y borrá el repetido.

## 7. El conector cambió de nombre

Tres días la carga de testeos no subió casi nada. La fábrica producía, la carga corría, el log no decía nada raro. El conector de Meta había pasado a llamarse con otras mayúsculas, y la lista de herramientas permitidas del agente tenía el nombre viejo. **Un agente sin supervisión no puede pedir permiso**: no hace nada y sigue.

- Si una carga dice "pidió permiso" o "fuera de la lista", compará el nombre exacto de las herramientas en la salida contra la lista permitida.
- Un conector agregado a mitad de una sesión no aparece en esa sesión, pero un proceso nuevo sí lo ve.
- Un error transitorio del conector ("las definiciones cambiaron") se resuelve esperando y reintentando; no hay que arreglar nada.
- Algunas herramientas **pausan** el conjunto al cambiarle la puja: anotá el estado antes y reprendé lo que estaba activo.

## 8. Escribir archivos que alguien está leyendo

- **Editar un script mientras corre:** escribí a un archivo nuevo y reemplazá con un movimiento atómico. Nunca editar en el lugar.
- **Configuración compartida:** temporal + reemplazo atómico, bajo candado.
- **Texto con signos de pesos dentro de un prompt en bash:** escapalos y probá esa línea con el modo estricto de bash.

## 9. Cambios que actúan a medianoche

Antes de cambiar algo que el reset de medianoche aplica (arranques, presupuestos base, topes), fijate la hora del servidor. Si el reset ya corrió, el cambio recién entra mañana: rehacelo a mano bajo el candado y verificá en el log.

## 10. Todo modo especial vuelve solo

Una "noche agresiva", un "día extraordinario", un "pico premio": se aplican con un script que **guarda lo anterior** y una tarea programada que **lo revierte exacto**. Nada queda "subido hasta que alguien se acuerde".

## 11. Los robots no reciben permisos que no necesitan

- El guardia nocturno no llama a Meta y tiene **una** palanca con límites en el código.
- El jefe tiene **un** comando.
- La carga de la fábrica tiene prohibidas las herramientas de prender, editar y promocionar: prender es de la cola o de un humano.
- Crear por cron un agente con permisos sin restricción quedó bloqueado por el sistema de permisos, y está bien: se arma con herramientas acotadas o no se arma.

Esqueletos: guardia de candados (`~/herramientas/esqueletos-robots/guardia_candados.sh`), palanca acotada (`~/herramientas/esqueletos-robots/palanca_acotada.py`).
