---
type: nota
created: 2026-07-24
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Seguridad: prueba social, autoridad, garantía + gatillos"]
---

# Prueba social, autoridad y garantía reducen el miedo; urgencia y escasez empujan

## Punto clave
Dos familias de palancas en toda oferta: las de SEGURIDAD (prueba social, autoridad, garantía 100% sin preguntas) reducen el miedo a equivocarse; las de ACCIÓN (urgencia "solo por hoy", escasez "últimos 5 cupos") activan la aversión a la pérdida. Los gatillos siempre sobre algo verdadero o verosímil: mentir quema la marca.

## Detalle
- Prueba social: testimonios cuyo lenguaje coincida con el del avatar real, cantidad ("+2.800 alumnas"), capturas estilo WhatsApp, mix clásico + UGC.
- Garantía por tipo de oferta: 7 días (Tipo A), 15 (B y C), 30 (D). La devolución en low-ticket es bajísima: no tener miedo.
- La misma promesa se repite 3-5 veces en la página con ángulos distintos ("aprendés una vez, multiplicás toda la vida" / "sin volver a comprar plantas nunca más").

## Aplicación
Chequear que toda landing tenga las DOS familias: seguridad cerca del precio y del CTA, gatillos cerca del CTA. Si solo hay presión sin seguridad (o al revés), la conversión se cae.
