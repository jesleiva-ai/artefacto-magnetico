---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cada ganador apila tres o cuatro sesgos, siempre en el mismo orden: atención, identificación, creencia, acción"]
---

# Cada ganador apila tres o cuatro sesgos, siempre en el mismo orden: atención, identificación, creencia, acción

## Punto clave
Cada ganador apila tres o cuatro sesgos, siempre en el mismo orden: atención, identificación, creencia, acción. Los sesgos por etapa, y lo que no replica.

## La regla
Marcá qué sesgo ocupa cada bloque del guion. Si falta una de las cuatro etapas, el guion está incompleto. Los sesgos
se usan **sobre algo verdadero**: inventar prueba social o escasez se nota y se paga.

## Las cuatro etapas
**1 · Atención (0-3 s)** — la neuroventa del primer segundo
- **Brecha de curiosidad**: la falta de información incomoda y empuja a cerrarla. Se abre en el gancho y se cierra
  recién con el producto.
- **Sorpresa / violación de expectativa**: la imagen que no podías predecir.
- **Amenaza y asco**: la atención prioriza el peligro. Primer plano crudo del problema (la planta podrida, el moho en
  la masa). Usar con medida: lo morboso se lleva restricción de edad y pierde alcance.
- **Especificidad**: «43 segundos» y el video dura 43; «a las 3 de la mañana». Lo específico parece verdadero.

**2 · Identificación (3-12 s)**
- **Reencuadre de la causa** («no es tu culpa, es X»): saca la culpa y deja lugar a un mecanismo nuevo.
- **Identidad / autoselección**: el espectador se reconoce y el resto se filtra solo.
- **Efecto del mensajero**: la misma promesa pesa más en boca de alguien parecido al comprador.
- **Lectura en frío**: «No te conozco, pero sé que alguna vez te pasó esto.»

**3 · Creencia (12-24 s)**
- **Autoridad** real (o el narrador experto declarado como tal).
- **Prueba social con número** («más de 12.000 alumnos»). Un número no redondo se cree más que uno redondo.
- **Demostración**: ver para creer. En digital: el producto real por dentro.
- **Enemigo común**: une al espectador con vos contra un tercero.
- **Mecanismo con nombre**: lo nuevo justifica que esta vez funcione.

**4 · Acción (cierre)**
- **Aversión a la pérdida**: «es más fácil conservar que recuperar».
- **Anclaje contra algo caro** sin decir tu precio («lo que cuesta una salida al cine»).
- **Reciprocidad**: primer módulo gratis, bonos.
- **Reversión del riesgo**: garantía, acceso inmediato.
- **Escasez con razón creíble**. Sin razón no se cree, y en la Unión Europea la urgencia ficticia está prohibida.
- **Regalo en vez de descuento**.

## Lo que NO replica (no gastes guion en esto)
Lecturas de la literatura de replicación que aportó un operador de la comunidad: el **priming**, el **agotamiento del
ego** y la **víctima identificable** no se sostienen al repetir los estudios. El **transporte narrativo** (meter al
espectador en una historia) sí. Y la **preferencia declarada no predice**: lo que la gente dice que le gusta en una
encuesta no anticipa qué anuncio compra. Se testea con plata, no con opiniones.

## Ejemplo completo (producto inventado: curso de inglés para viajar)
Atención: «POV: aterrizás y no entendés ni el cartel del baño» (escena + amenaza). Identificación: «No es que seas
malo para los idiomas: te enseñaron gramática, no frases de aeropuerto» (reencuadre). Creencia: las 40 frases reales
del curso en pantalla (demostración + número). Acción: «Acceso inmediato. Practicalas antes de tu vuelo» (riesgo
resuelto + pérdida: el vuelo ya está comprado).

Relacionadas: [[los-ganadores-repiten-cinco-movimientos]] · [[el-gancho-se-elige-por-el-mecanismo-que-activa]]
