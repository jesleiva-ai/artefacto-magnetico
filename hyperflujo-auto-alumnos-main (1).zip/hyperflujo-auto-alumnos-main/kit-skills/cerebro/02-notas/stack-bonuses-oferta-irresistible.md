---
type: nota
created: 2026-07-24
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Stack de bonuses: la oferta irresistible"]
---

# Bonuses que resuelven problemas FUTUROS hacen la oferta irresistible

## Punto clave
Oferta irresistible = producto principal + 5-7 bonuses (hasta 10-15 si se justifican). Cada bonus resuelve un problema FUTURO y concreto del cliente — costo de producción cero por ser digital, valor percibido enorme. La sensación buscada: "entré por UN producto y me llevo 15". Bonus de relleno = oferta diluida.

> **CONTRADICCIÓN MEDIDA (2026-07-31).** El corpus dice lo contrario: de las 14
> ganadoras desarmadas **solo el bundle usa 10**, y la única con métricas reales
> completas usa **5**. La banda medida es 3-6 con 5 por defecto. Los que escalan son más austeros que el
> canon. Pendiente de decisión: "bonus maximalista vs caso real". Ante la duda,
> manda lo medido.

## Detalle
- Ejemplo (ebook reproducción de plantas): bonus de sustratos, envases, mini vivero, suculentas, carnívoras.
- Presentación: mockups premium, valor monetario visible por bonus ("Valor $9.000"), página limpia.
- Bonus ≠ Upsell: el bonus va sobre la OFERTA (gratis, en la landing, problemas de la promesa principal); el upsell va sobre el AVATAR (pago aparte, en carrito/checkout/post-compra, problemas adyacentes). Confundirlos = regalar lo cobrable o cobrar lo que debía ir incluido.

## Aplicación
Al armar una oferta: listar los problemas que el cliente va a tener DESPUÉS de consumir el producto principal — cada uno es un candidato a bonus. Lo adyacente al avatar (no a la promesa) se reserva para upsell.
