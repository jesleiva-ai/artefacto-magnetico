---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["El subtítulo karaoke sale del texto del guion con los tiempos de la voz, y se compara letra por letra antes de quemarlo"]
---

# El subtítulo karaoke sale del texto del guion con los tiempos de la voz, y se compara letra por letra antes de quemarlo

## Punto clave
El subtítulo karaoke sale del texto del guion con los tiempos de la voz, y se compara letra por letra antes de quemarlo. Texto del guion, tiempos de la voz, una sola capa.

## La regla
- Subtítulo **palabra por palabra** (o de a una palabra), sincronizado con la voz, resaltando la palabra al decirla.
- **El texto lo pone el guion; los tiempos, la voz.** Nunca el texto del transcriptor.
- Antes de renderizar, el texto de los subtítulos se compara **letra por letra** con el guion. Si no coincide exacto, no
  se renderiza: el subtítulo queda quemado para siempre.
- **Una sola capa de texto a la vez**: gancho, placas y karaoke no se pisan.

## Por qué
- Con TTS bueno, 20 videos en cuatro idiomas salieron con entre 1 y 33 palabras mal cuando se usó lo que oyó Whisper
  (palabras inexistentes, un apellido escrito de cuatro maneras, elisiones partidas). Alinear guion contra transcripción
  e imponer el guion corrigió 249 palabras.
- Un montaje con gancho, placas y karaoke encimados se devolvió por «textos que se pisan y subtítulos descoordinados».
- Los ganadores convivían con tres estilos de subtítulo que ganaban por igual (blanco sin fondo, cápsula negra, blanco
  con la palabra clave en color): el estilo importa menos que la sincronía y la legibilidad.

## Cómo aplicarlo
- **Tiempos**: de la API de voz con marcas de tiempo (si la voz se acelera con atempo, dividí los tiempos por el tempo).
  Si la voz no los trae, alineá guion contra transcripción (Needleman-Wunsch) e imponé el guion.
- **Números**: el transcriptor escribe «tres» y el guion «3»; normalizá números en letras a cifra para alinear.
- **Estilo heredado del ganador**: dónde se apoya, color del resaltado (la moda de la banda, no el promedio),
  mayúsculas. Se mide del archivo ([[portar-un-ganador-a-otro-idioma]]).
- **Tipografía**: confirmá que la fuente tenga todas las letras del idioma. Una tipografía popular trae solo una
  fracción de las letras de un alfabeto no latino: elegí una que lo cubra completo.
- **Zona segura**: en reels, dejá libre el ~35 % de abajo (ahí van los botones de la app).
- **Legibilidad**: probá sobre todos los fondos de la pieza; caja o contorno si hace falta.
- **Cambio de marcha en el cierre**: subtítulo chico todo el video y texto gigante en la oferta funciona en ganadores
  longevos.

## Error típico
Quemar el subtítulo «del transcriptor porque ya está sincronizado». Sincronizado y mal escrito.

Relacionadas: [[voz-ritmo-y-locucion]] · [[trampas-por-idioma-y-alfabeto]]
