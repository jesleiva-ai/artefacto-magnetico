---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Los testimonios no se inventan, llevan nombres del país y la persona generada por IA nunca es un cliente"]
---

# Los testimonios no se inventan, llevan nombres del país y la persona generada por IA nunca es un cliente

## Punto clave
Los testimonios no se inventan, llevan nombres del país y la persona generada por IA nunca es un cliente. Sin testimonios inventados, nombres del país, casting por mercado.

## Las reglas
1. **Nada de testimonios inventados.** Una persona generada con IA puede ser **presentadora** (cuenta qué trae el
   producto), nunca **clienta** que relata resultados. Un UGC con IA cuenta experiencia de uso, sin resultados medibles.
2. **Nombres del país.** Al llevar una landing o un anuncio a otro idioma, todos los nombres de testimonios se cambian
   por nombres típicos de ese país, del mismo género que la foto. Un «Miguel T.» en una página de otro país delata la
   copia.
3. **Las fotos de testimonio muestran el producto en el idioma de la tienda.** Una foto con el producto en otro idioma,
   heredada del clon, se nota.
4. **Casting coherente con el mercado.** Los modelos generan un tipo de persona por defecto que puede no ser el del
   público. Describí en el prompt a cada persona, incluidos los secundarios (el recepcionista, la cajera), según el
   país al que va el anuncio, y revisá cada toma.

## Por qué
- Meta y las leyes de consumo castigan los testimonios falsos, y el comprador que se siente engañado pide reembolso.
- En una auditoría de varias landings clonadas, la mayoría tenía las fotos de testimonio con el producto en otro idioma:
  se cambiaron los nombres pero nadie rehízo las fotos.
- Tomas generadas salieron con personas secundarias que no correspondían al público del mercado y hubo que rehacerlas
  describiendo a cada una.

## Cómo aplicarlo
- La localización de nombres se hace **en la transcreación** de la landing, no como paso aparte, y se verifica en la
  página publicada (un `curl` buscando el campo de nombre alcanza).
- Para prueba social sin testimonio: número de alumnos o compradores (real), capturas de comentarios reales, la
  demostración del producto.
- Si una foto de testimonio parece real, confirmá de dónde salió y que haya permiso de uso.

## Error típico
Pedirle a la IA «una clienta contando cómo le cambió la vida». Es un testimonio falso con buena luz.

Relacionadas: [[estilo-ugc]] · [[reglas-de-copy-y-lo-que-meta-rechaza]]
