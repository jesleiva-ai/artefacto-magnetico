---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Traducir un ganador exacto: voz fuera, música adentro, las mismas tomas estiradas a la frase nueva y solo los planos con texto reemplazados"]
---

# Traducir un ganador exacto: voz fuera, música adentro, las mismas tomas estiradas a la frase nueva y solo los planos con texto reemplazados

## Punto clave
Traducir un ganador exacto: voz fuera, música adentro, las mismas tomas estiradas a la frase nueva y solo los planos con texto reemplazados. Demucs, anclas por frase, ±8 %, planos con texto que se mueven.

## La regla
Cuando el pedido es «el mismo video, traducido», el resultado tiene que ser **el mismo video**: mismas tomas, mismo
orden, misma música, mismo estilo de subtítulo. Cambian la voz, los subtítulos y **solo** los planos con texto del
idioma de origen.

## La receta
1. **Bajar el original** con audio. Si es un anuncio propio, la vista previa del anuncio trae el mp4 con audio cuando
   la API no deja bajar el video de la página.
2. **Separar voz y música** con Demucs (dos pistas). Verificado: el transcriptor oye solo música en la pista de fondo.
3. **Transcribir la voz original** con tiempos (Scribe) y armar la tabla de frases: cada frase es un ancla.
4. **Traducir por frase** (una traducción por oración, más los textos de carteles), en el dialecto del mercado.
5. **Locutar** con voz nativa y **ajustar la velocidad para que dure lo mismo que la original (±8 %)**. Si no, el
   video se acelera hasta la mitad y deja de ser el mismo.
6. **Estirar o comprimir cada tramo** del original para que caiga en la frase del idioma nuevo.
7. **Subtítulos en el mismo lugar y estilo**: una franja fija tapa el subtítulo viejo (haya o no franja en el original);
   si cada ganador tiene su estilo quemado, OCR por lotes + inpainting del subtítulo viejo + el nuevo encima.
8. **Reemplazar los planos con texto** del idioma de origen (portadas, carteles, placa final) por los del idioma nuevo.
9. QA completo ([[qa-automatico-de-piezas-con-ia]]).

## Cuando el plano con texto se mueve
- **Portada que entra con zoom sobre una toma en movimiento**: por cuadro, máscara del color dominante de la portada
  (rango HSV), solo por encima de la banda de subtítulos (si son del mismo color, se funden), el componente más grande,
  alto topado por la proporción de la portada; se pega la portada del idioma ~4 % más grande. Conserva la animación y el fondo.
- **Scroll por el contenido**: se rehace con las mismas muestras del contenido en el idioma nuevo, apiladas y desplazadas con aceleración
  suave.
- **El corte se mide por diferencia entre cuadros**, no por «cuánto blanco hay»: un fundido desde negro no lo ve un
  umbral de brillo, y el primer render dejó medio segundo del idioma viejo.

## Trampas
- Si la voz nombra el producto, el OCR toma la portada como subtítulo y la mancha: banda fija para subtítulos fijos y un
  filtro de borde (porcentaje de píxeles negros del contorno) para distinguir subtítulo de pieza del producto.
- Las imágenes fijas que se concatenan con video necesitan rango de color de video (`out_range=tv`): si no, la franja
  blanca sale gris en esos tramos.
- Portadas de un generador por capas pueden traer restos del texto de origen: mirarlas antes.
- Antes de traducir, **hoja de fotogramas del original**: si trae material ajeno, se traduce sobre tomas limpias.
- Una traducción que cambia las tomas ya no es el ganador.

Tiempo de máquina: ~2 min por video una vez armado el motor.

Relacionadas: [[trampas-por-idioma-y-alfabeto]] · [[imagenes-con-texto-en-otro-idioma-se-recrean]]
