---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Trampas de subagentes y sesiones"]
---

# Trampas de subagentes y sesiones

## Punto clave
Cuando trabajás con IA que lanza ayudantes en paralelo, o con varias sesiones abiertas sobre las mismas cuentas, aparecen problemas que no tienen nada que ver con Meta y que igual cuestan plata.

Cuando trabajás con IA que lanza ayudantes en paralelo, o con varias sesiones abiertas sobre las mismas cuentas, aparecen problemas que no tienen nada que ver con Meta y que igual cuestan plata.

## Los ayudantes en segundo plano mueren con la sesión

Un ayudante lanzado en segundo plano vive **dentro** del proceso de la sesión que lo lanzó. Si la sesión se cierra o se reanuda, queda cortado a mitad. Nos pasó dos veces seguidas con trabajos de horas.

- Para un ayudante de más de ~30 min: que vaya anotando su avance en un archivo de **estado** en su carpeta; avisá que no se cierre la sesión; si se cortó, retomalo pidiéndole que lea su estado y lo ya hecho antes de seguir.
- **Al revés también:** un ayudante lanzado por otro ayudante puede seguir vivo aunque el que lo lanzó ya terminó y aunque todavía no haya escrito su estado. Antes de relanzar "porque se cortó", mirá si sus carpetas siguen cambiando. Casi lanzamos un duplicado.

## Lo que tiene hora fija se programa en el servidor

Se prometió "la carga queda antes del pico". Quedó esperando una simulación en la sesión y corrió horas después, con el pico ya pasado.

**Regla:** todo lo que tiene que pasar a una hora fija (antes del pico, a medianoche) se deja **programado en el servidor** (cron o tarea única, en modo real y con log) **antes de cerrar el turno**. Nunca dependiendo de que la sesión siga viva o de que alguien vuelva a escribir. Señal: estás por decir "queda listo antes de X" y el paso todavía no corrió.

## Subagentes que escriben en la misma carpeta se pisan

Cuatro subagentes cargando una tanda grande de creativos compartían una carpeta temporal: se pisaron los scripts de apoyo, anotaron IDs cruzados, **duplicaron 16 creativos y saltearon 7**. Uno además los nombró mal.

- **Carpeta de trabajo propia y archivo de salida propio** por subagente.
- El registro de los agentes **no es confiable; Meta sí.** Antes de crear anuncios, verificá cada creativo contra la plataforma por **contenido** (cuenta + página + video/imagen + copy), no por nombre.
- **La carga a Meta va en cola, una por cuenta.** Varios agentes cargando a la vez disparan el freno de la API y paran a todos.
- Decile a cada ayudante qué procesos, puertos y archivos **no** toca. Un investigador tomó el puerto de otro servicio y lanzó otra corrida.
- Si un proceso terminó con menos de lo pedido y sin error, **antes de relanzar** buscá en el destino lo que alcanzó a crear.
- Para tareas largas, pedí "sin sub-agentes".

## Dos sesiones, la misma cuenta

Dos sesiones cargaron a la misma campaña a la vez; las dos leyeron "el último es TEST 12" y crearon del 13 al 20 duplicados.

- Releé el máximo **justo antes** de cada creación, no al empezar.
- Mirá el registro de llamadas por creaciones recientes que no sean tuyas.
- Avisá a las otras sesiones el rango que tomaste.
- Si ya chocó: renumerá **los tuyos**, nunca los ajenos.
- Otra sesión puede haber creado hoy lo mismo que estás por crear: antes de crear una campaña de un país, listá las campañas de la cuenta por nombre.

## Esperas que se encuentran a sí mismas

`while pgrep -f "script.py"` dentro de un shell se encuentra **a sí mismo** (el texto está en su propia línea de comando) y espera para siempre. Lo mismo con `pkill -f patrón` por ssh: se mata a sí mismo y te corta la sesión.

- Usá el truco del corchete en la primera letra (`pgrep -f "[s]cript.py"`) o esperá un archivo o una línea de fin.
- Python con salida a un pipe no muestra nada hasta el final: corrélo sin búfer.

## Un timeout corto en un robot que crea cosas

Un robot que crea una escala esperaba el candado de otros robots; lo cortábamos con timeout, se reintentaba, y cada corrida reusaba la campaña y le sumaba **otros 3 escalones**. Quedó con 9 conjuntos. Timeout largo, o verificar en la plataforma antes de reintentar.

## Probar sin romper

- Todo script de producción o carga tiene un modo **seco** o de un solo mercado. Usalo primero, y después revisá los procesos para confirmar que no quedó nada corriendo. Una "prueba" lanzó sin querer una tanda real que sumó muchísimas llamadas a la API esa noche.
- Antes de culpar a un robot por lo que "gasta según el registro", mirá su log: dos robots pueden caer bajo el mismo nombre en el medidor.

## Las sesiones de las cuentas de IA vencen

Los robots con IA corren con cuentas logueadas en el servidor. Una sesión vencida hace fallar al robot de madrugada.
- Reintento automático con otra cuenta (el selector lo hace).
- Un vigía de cupo y vencimiento.
- Renovar una sesión requiere al humano: queda en la lista de pendientes con los pasos exactos.
