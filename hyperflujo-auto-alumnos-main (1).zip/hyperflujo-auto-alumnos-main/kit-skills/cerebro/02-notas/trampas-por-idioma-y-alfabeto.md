---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Cada idioma tiene trampas propias: cifras que el TTS lee mal, OCR que no lee el alfabeto y titulares que cambian de orden"]
---

# Cada idioma tiene trampas propias: cifras que el TTS lee mal, OCR que no lee el alfabeto y titulares que cambian de orden

## Punto clave
Cada idioma tiene trampas propias: cifras que el TTS lee mal, OCR que no lee el alfabeto y titulares que cambian de orden. Sin espacios, con alfabeto propio, OCR, dialectos.

## La regla
Un idioma nuevo no se produce «igual que el español con otra voz». Antes de la tanda: una prueba de 5 s con el nombre
del producto y una cifra, el OCR probado sobre ese alfabeto y los textos del producto **en ese idioma** a mano.

## Trampas por familia de idioma
**Idiomas sin espacios entre palabras** (si vas a un idioma como el japonés, por ejemplo)
- El guion se escribe con las unidades de frase separadas por espacio y cada término difícil con su lectura
  (`表示=よみ`); la comparación guion contra transcripción conviene hacerla en un silabario común, no en caracteres.
- El TTS multilingüe suele **leer mal cifras y caracteres sueltos** (un número leído como otro, un caracter leído con otra
  palabra): **toda cifra va con su lectura escrita**.
- Si un contador leído por la voz lo oye el reconocedor como otro número, escribí la forma completa en la voz.
- Con música y un golpe de sonido encima, una consonante del nombre de la marca se puede perder y el reconocedor oye otra
  palabra: bajar la música (~15 %) y sacar efectos debajo de la marca.
- El reconocedor con música puede **variar entre corridas** sobre el mismo audio: el auditor repite una vez antes de marcar rojo.

**Idiomas con alfabeto propio** (con espacios, pero no latinos)
- Sin lectura, el reconocedor puede oír un contador como otro («8 unidades» como «8 tipos»): toda cifra con su lectura y su
  contador nativo.
- Un narrador a la velocidad del español puede quedar demasiado rápido en sílabas por segundo: bajá la velocidad por
  pieza. **El ritmo se transporta en sílabas, no en palabras.**
- El OCR configurado para un alfabeto **no lee otro**: un texto en otro alfabeto colado pasa como basura del
  primero. Segunda pasada con el OCR del alfabeto sospechoso (mínimo de caracteres y confianza).
- Chequeo de «caracteres intactos» en subtítulos: los cuadros a 2 fps caen corridos y marcan falsos rotos. Extraé
  **cuadros exactos por evento** del archivo de subtítulos.
- **Los titulares reales del producto en ese idioma cambian el orden de la frase**: si escribís los guiones antes de tener
  los textos traducidos del producto, vas a relocutar casi toda la tanda. Esperá los textos del producto antes de
  locutar.

**Cualquier alfabeto**
- El OCR de un proveedor grande no lee varios alfabetos latinos con diacríticos y un detector de idioma **le inventa un
  idioma a la basura**: contá palabras propias del idioma ajeno (3 distintas = error real) y abrí el cuadro.
- Una tipografía popular puede no tener todas las letras de un alfabeto: probala con el abecedario completo.
- El texto de 24 px en un estático pierde acentos al portarlo: en idiomas con muchos diacríticos, conviene rehacer
  los estáticos en vez de rotularlos.
- **Frases de rebaja** distintas en cada idioma: la lista de prohibidas del auditor tiene que estar en todos.
- El reconocedor alucina frases típicas («thank you for watching») sobre música o efectos: exigí voz real (filtro de
  actividad de voz) antes de juzgar el idioma.

**Dialecto y mercado**
- Cada mercado en su dialecto (el inglés británico no es el estadounidense; el francés de Francia no es el de Canadá);
  el léxico se busca en sitios del país.
- El idioma no es el país: mirá de qué países compra cada idioma.
- Idiomas de derecha a izquierda: se usa el mismo motor que para idiomas con espacios; verificá en la hoja de cuadros
  que el subtítulo y los textos del mockup salgan en el orden correcto (no medido todavía con un ganador).

## Cómo aplicarlo
Un módulo por familia de idioma (sin espacios / con espacios y alfabeto propio) con: lecturas de cifras, OCR del
alfabeto, comparación en el silabario correcto y función que exige que **la marca y las cifras** aparezcan exactas en la
transcripción. Para un idioma nuevo de la misma familia, se copia el módulo y se cambian fuentes, OCR y lecturas.

Relacionadas: [[traducir-un-ganador-exacto]] · [[voz-ritmo-y-locucion]] · [[qa-automatico-de-piezas-con-ia]]
