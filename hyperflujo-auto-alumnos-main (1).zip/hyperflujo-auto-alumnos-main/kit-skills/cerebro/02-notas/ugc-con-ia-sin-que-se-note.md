---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un UGC hecho con IA se delata por la luz de estudio, la voz que cambia entre escenas y el tono plano: las tres se corrigen"]
---

# Un UGC hecho con IA se delata por la luz de estudio, la voz que cambia entre escenas y el tono plano: las tres se corrigen

## Punto clave
Un UGC hecho con IA se delata por la luz de estudio, la voz que cambia entre escenas y el tono plano: las tres se corrigen. Luz de selfie, una sola voz, tono real.

## La regla
Quien habla a cámara en un UGC **se ve grabado con celular, siempre**. Y es presentadora, nunca clienta
([[testimonios-y-personas-en-pantalla]]).

## Lo que delata a la IA y cómo se corrige
**1. La luz de la referencia.** Veo copia la luz de la foto de referencia en todas las escenas: un retrato de estudio
da un UGC «de estudio» (luz de recorte, cara sobreiluminada). Se corrige generando la referencia **ya como selfie**:
cámara frontal con el brazo estirado, solo la luz del lugar, piel sin retocar, gran angular de ~23 mm, cara un poco
corrida del centro, ruido de celular. En el prompt se niega lo que delata al estudio («no studio lights, no rim light,
no hair light, no beauty light») y para el video: celular en mano con temblor, sin estética de cine, audio de micrófono
de celular.

**2. La voz por escena.** Cada escena generada trae su propia voz: medido, 128 Hz en una y 178 Hz en otra del mismo
video. Se unifica pasando cada escena por **speech-to-speech** (Voice Changer de ElevenLabs) con una sola voz: quedaron
en 111 y 123 Hz, la misma persona. Conserva los tiempos, así que los labios siguen coincidiendo, y la opción de quitar
ruido saca el eco. Después se transcribe cada escena y se repite solo la que falló (el cambio de voz puede cambiar una
palabra).

**3. El tono plano.** Las voces sintéticas medidas tenían la mitad de rango de tono que una persona real. Lo único que
cerró la brecha: **grabar a una persona real** diciendo el guion y cambiarle el timbre con speech-to-speech (la voz
destino también se prueba: una conservó el rango, otra lo aplanó). Quien graba tiene que hablar el idioma.

## La receta completa de un UGC de presentadora
selfie generada → cuadro por escena (gesto descripto si el guion lo pide) → escenas habladas con diálogo exacto (Veo o
Omni, 9:16, la mayor resolución que acepte el cliente) → transcribir cada clip y recortar repeticiones finales → una sola
voz por speech-to-speech → montaje: cortes de silencio con zoom alternado, b-roll real como tarjetas encima, mockup en el
tercio inferior con la cara a la vista, subtítulos con caja → versiones con y sin etiqueta «creado con IA» si el
mercado lo pide.

## Error típico
- Pedirle al modelo de video «eco del lugar»: cada escena lo interpreta distinto.
- Juzgar la sincronía con una medición automática de labios: dio ruido incluso en clips buenos. Se mira la boca.

Relacionadas: [[voz-ritmo-y-locucion]] · [[cada-modelo-de-video-tiene-su-trampa]]
