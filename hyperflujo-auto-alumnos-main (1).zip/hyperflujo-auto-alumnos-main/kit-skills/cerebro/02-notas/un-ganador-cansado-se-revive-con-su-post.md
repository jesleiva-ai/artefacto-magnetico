---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un ganador cansado se revive con su publicación original, y su relevo trae ángulo y cuerpo nuevos, no maquillaje"]
---

# Un ganador cansado se revive con su publicación original, y su relevo trae ángulo y cuerpo nuevos, no maquillaje

## Punto clave
Un ganador cansado se revive con su publicación original, y su relevo trae ángulo y cuerpo nuevos, no maquillaje. Regla del 80 %, el post original, por qué fallan las variaciones cosméticas.

## La regla
1. **Si un anuncio se lleva más del 80 % del gasto de una campaña, su relevo se produce hoy**, no cuando caiga.
2. Para **revivir** un ganador cansado: llevar **su publicación original** (el mismo post, con sus comentarios y
   reacciones) a un **conjunto nuevo** dentro de la escala de su mercado.
3. Para **relevarlo**: ángulo y cuerpo nuevos, o la misma estructura con tomas nuevas (un héroe nuevo). No sirve
   retocar el envoltorio.
4. Si se prueba un relevo cercano, se cambia **solo la primera imagen** y se conserva la segunda tal cual, con la voz,
   la música y los subtítulos del original.

## Por qué (lo medido)
Tres caminos sobre el mismo ganador cansado (su CPM había subido entre un 13 % y un 41 % y su ROAS había bajado entre
un 18 % y un 57 % en dos mercados):
| Camino | Resultado |
|---|---|
| 10 resubidas idénticas con la metadata borrada | 1 compra en total: Meta casi no las entregó |
| 18 variaciones cosméticas con el mismo cuerpo (gancho, voz, música, color) | 0 compras; CTR la mitad del original |
| El post original en un conjunto nuevo de la escala | ROAS +32 %, CPM −43 %, CPA −21 % contra la copia de la misma campaña |

- **Meta reconoce el video por lo que se ve y se oye**, no por el ID ni la metadata: una copia «limpia» es el mismo
  anuncio con menos historia. Borrar la metadata queda como higiene, nunca como estrategia.
- La señal de ganador cansado: **sube el CPM y el CPC, baja el CTR o el ROAS, y la frecuencia sigue normal** (1,1-1,8).
  No se agotó el público: se gastó el rendimiento marginal de la pieza al meterle más plata.
- Un mercado que colgaba de un solo video duplicó su CPA en cinco semanas al triplicar el gasto; la landing
  convertía igual. Se salió con escalas nuevas de 4 ganadores recientes cada una y ángulos nuevos.

## Cómo aplicarlo
- Un control automático que avise cuando un anuncio pasa el 80 % del gasto de 3 días de una campaña (con gasto mínimo
  y al menos 3 anuncios gastando).
- Escalas con **varios ganadores**, nunca colgadas de uno.
- Para revivir: buscar el post con más compras y buen ROAS que hoy esté pausado o en conjuntos viejos y reusar ese
  mismo post (no subir el video de nuevo). Un post no se edita sin perder su historia: si su copy ya no pasa tus reglas,
  se descarta.
- Para iterar un ganador **fresco** (no cansado) sí sirve testear ganchos con el cuerpo fijo
  ([[el-gancho-se-testea-con-el-cuerpo-fijo]]).

## Error típico
- «Borrémosle la metadata y queda nuevo.» No.
- Diez variaciones del mismo video cansado. Comparten público y algoritmo con el original: suman gasto, no ventas.
- Apagar un ganador sano por «antigüedad» o por limpieza. Antes de apagar, mirá su CPA de los últimos 7 días.

Relacionadas: [[receta-medida-heroe-traducido-y-muestra-real]] · [[los-anuncios-no-se-fatigan-mueren-sin-arrancar]]
