---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Un ganador rinde muchos anuncios: mismo metraje con guion nuevo, o misma voz con otro montaje, cuesta casi cero"]
---

# Un ganador rinde muchos anuncios: mismo metraje con guion nuevo, o misma voz con otro montaje, cuesta casi cero

## Punto clave
Un ganador rinde muchos anuncios: mismo metraje con guion nuevo, o misma voz con otro montaje, cuesta casi cero. Variantes de un solo eje.

## La regla
Lo caro de un creativo es la primera vez (tomas, voz, música). Después:
- **Mismo metraje + guion nuevo = anuncio nuevo.** Validado con plata: una variante así dio ROAS 2,7.
- **Misma locución + otra combinación de b-roll = variante de costo cero**: la voz ya está generada y se reusa.
- **Mismo video + otro copy = otro anuncio** (ver [[copy-y-video-cargan-angulos-distintos]]).
- Las tomas de estilos animados **no tienen idioma**: otro mercado = otra voz + otro montaje, cero clips nuevos.

## Cómo armar el set de variantes de un semilla
Una variante cambia **un solo eje** por vez, y nunca la oferta ni la promesa:
| Eje | Qué cambia | Qué se regenera |
|---|---|---|
| Gancho | los primeros 5-9 s (texto, voz, plano 0) | una línea de voz + un clip |
| Estructura | el orden de los bloques | nada (re-montaje) |
| Voz | otra voz / otro registro | la locución |
| Corte | ritmo, orden de b-roll | nada |
| Formato | voz+b-roll → sin voz con texto, → split | casi nada |
Una tanda de 6 escenas UGC + 6 b-roll da 4-6 creativos sin generar nada más.

## El límite
Esto multiplica un ganador **fresco** o un semilla. Sobre un ganador **cansado**, las variantes que se parecen mucho
no venden: Meta las agrupa con el original ([[un-ganador-cansado-se-revive-con-su-post]]). Ahí hace falta un héroe
nuevo, no un clon.

## Cómo aplicarlo
- Guardá todo con nombre estable: tomas por producto, música por registro (confesión / descubrimiento / urgencia), voz
  fija por marca, íconos de resalte por prompt. Antes de generar algo nuevo, listá lo que ya existe.
- Registrá cada anuncio con su semilla, su eje y lo que cambió: así se lee qué eje mueve el número.

Relacionadas: [[el-gancho-se-testea-con-el-cuerpo-fijo]] · [[portar-un-ganador-a-otro-idioma]]
