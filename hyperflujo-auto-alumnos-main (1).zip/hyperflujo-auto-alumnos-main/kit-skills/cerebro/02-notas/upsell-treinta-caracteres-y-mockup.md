---
type: nota
created: 2026-07-28
tags: [ofertas, productos-digitales]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["El upsell se decide en 30 caracteres y un mockup"]
---

# El upsell se decide en ~30 caracteres y un mockup: no repitas el mismo mensaje en los dos

## Punto clave
Si el ticket promedio no sube, el upsell casi nunca falla por el tema: falla por
comunicación. En el checkout del celular el comprador ve unos **30 caracteres de
título + un mockup chiquito**. Son DOS recursos distintos de valor percibido:
poner en el mockup lo mismo que dice el título es tirar uno de los dos.

## El diagnóstico, corregido en vivo
"Si tu ticket promedio no aumenta es porque el upsell no le interesa a la
gente... me equivoqué: no es que el tema no le interese, es que no lo estás
sabiendo comunicar." El error más común es un título largo que se recorta en
pantalla: la persona no entiende de qué se trata y no lo agrega.

## El flujo con IA
1. Contarle al proyecto/chat qué vendés y cuál es tu ticket promedio actual.
2. Pedirle upsells apoyándose en dos fuentes: el módulo de ofertas del programa y
   "Ofertas de $100M" (Hormozi) — cargando la transcripción o el libro.
3. **El paso que casi nadie da:** entrar a la propia tienda como cliente, sacar
   captura del checkout con los upsells actuales, pasársela a la IA y pedirle
   explícitamente que contemple la cantidad de caracteres visibles en pantalla de
   celular. Sin eso devuelve títulos que se recortan.
4. Pedir 5 variantes y lanzarlas ANTES de crear el material.

## Cadencia de testeo
- 4-5 upsells en simultáneo, **~48 h**. No hay número óptimo: "si son buenos, la
  gente los va a agregar".
- De los 5 se suelen agregar 1 o 2. Los otros 3 **no se sacan: se iteran** — son
  los que tienen puntos de mejora.
- Tope práctico del checkout de Shopify (AfterSell): 3 upsells.
- Fuentes de ángulo: la IA, y competidores que comunican tu mismo producto con
  otro ángulo.

## La vara del nombre: "no puedo NO llevarlo" (caso de un alumno, 2026-07-30)
El criterio para evaluar si un upsell está bien comunicado, dicho sin vueltas:
cuando aparece en el checkout, **la persona tiene que decir "no puedo no
llevarlo"** — *"le tiene que resultar irrisorio comprarlo, a nivel valor
percibido contra precio del producto"*.
- Lo mismo desde el lado del alumno que lo aplicó: el upsell tiene que hacer que
  *"si me llevo el producto principal, no tiene sentido si no me llevo esto"*.
  El upsell no es un agregado suelto: es lo que completa al principal.
- La instrucción concreta fue **nombres marketineros basados en el libro de
  Hormozi** — y el alumno los rehízo *"al rato"* de escucharlo.
- El resultado medido: AOV de 15 → 20 USD. Con eso pudo **bajar la inversión
  diaria y sostener la misma ganancia**, en vez de sobre-escalar sin caja.

## Aplicación
Checklist antes de dar por perdido un upsell: ¿el título entra en la pantalla?
¿el mockup dice algo distinto del título? ¿lleva 48 h? ¿iteraste los que no se
agregaron? Es la palanca operativa de
[[primero-el-ticket-promedio-despues-la-escala]].
