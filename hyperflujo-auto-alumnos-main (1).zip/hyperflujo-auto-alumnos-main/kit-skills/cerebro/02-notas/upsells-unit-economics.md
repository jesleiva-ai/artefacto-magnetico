---
type: nota
created: 2026-07-24
tags: [productos-digitales, ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Upsells: subir el ticket para bancar CPA"]
---

# El upsell sube el ticket promedio y te deja pagar más CPA que la competencia

## Punto clave
Lógica estructural (no opcional) del modelo: si con upsells el ticket promedio sube de $15 a $30, podés bancar un CPA que la competencia que solo vende el front de $15 no puede pagar. "Le comés cruda a la competencia." Crítico porque los CPAs de Meta suben año a año. Se aplica SOLO con la oferta principal ya validada.

## Detalle
- 3 momentos pre-compra: landing (pop-up al clickear comprar), carrito (app tipo SellEasy), checkout.
- Post-compra: Upsell #1 → si acepta, Upsell #2; si rechaza, Downsell; si rechaza, página de gracias → WhatsApp + email + comunidad.
- Atreverse con el precio: el upsell puede valer igual o más que el front — el cliente ya está en éxtasis de compra. Títulos disruptivos ("La guía definitiva del ayuno intermitente. 21 días para resetearte"), el título + mockup son el 80% de la conversión del upsell.
- AppSells dentro del PDF: QR/links a comunidad VIP, curso con certificación, físicos, membresías.
- Pivote de jerarquía: si un upsell convierte más que el front, ascenderlo a producto principal.

## Números de decisión (masterclass 2026-07-23; matiz confirmado 2026-07-25)
- AOV objetivo: promedio ARRIBA de USD 30 (oscila 23-42; lo que importa es el promedio). MATIZ (2026-07-25): estar por debajo de 30 NO es negativo en sí — el veredicto real es la relación CPA (costo por resultado de Meta) vs ticket promedio de la venta: si esa relación es rentable, sirve. Los 30 son la ambición, no el umbral de aprobación.
- Con ese AOV se bancan CPAs de hasta USD 19: "el 90% no puede pagar eso porque se le escapa la rentabilidad y apaga — ahí entramos los que sí podemos y ganamos la puja".
- Upsell pre-compra que no convierte: se MEJORA (valor percibido, título, comunicación), no se saca. Iterar el precio del front sin miedo: "¿qué es lo peor que puede pasar? No se valida, vuelvo al precio anterior — no hay peligro."
- Post-compra: AfterSell; AppSells en la app de entrega (módulos bloqueados a desbloquear pagando); email marketing.
- Libro de cabecera para persuasión de ofertas/upsells: "Ofertas de $100M" (Hormozi).

## Checkout vs backend: dónde poner los upsells (2026-07-08)
- El checkout de Shopify (AfterSell) tiene **tope práctico de 3 upsells**. El backend —la app de entrega, con productos bloqueados a desbloquear pagando— no tiene ese límite.
- Caso medido de un alumno: sacó los upsells del carrito, los movió todos al backend y sumó 6-7 productos → **ticket promedio de 28 a 52 USD**. La estrategia complementa, no reemplaza: primero los 3 del checkout, después el backend.
- Requisito no negociable del backend: el producto principal tiene que ser bueno. Ahí la gente compra porque ya te probó.
- El orden de trabajo (subir ticket antes de escalar) y la palanca del precio están en [[primero-el-ticket-promedio-despues-la-escala]]; cómo se escribe el upsell para que se agregue, en [[upsell-treinta-caracteres-y-mockup]].

## El techo del criterio: el front puede ir HASTA break-even (2026-08-26)
Con el post-compra ya montado, la misma lógica va un paso más lejos de lo que dice
el bloque de arriba. Ya no es "banco un CPA alto": es que **el producto principal
puede dejar de ganar plata**.

> *"Del producto principal podés ir hasta break-even, porque vos se lo vendés a 20
> dólares y podés pagar 20 dólares de costo por resultado. Con todo el post-compra,
> capitalización, rentabilidad en la adquisición del cliente."*

Y la contrapartida, que es lo que compra ese margen:

> *"Mientras más alto es el ticket promedio, tenés más margen a que tu tasa de conversión
> sea un poquito más chiquita e igualmente siga siendo rentable."*

Es decir: el ticket promedio compra tolerancia en las DOS variables —CPA arriba y tasa
de conversión abajo—, no solo en el CPA. El front deja de ser el centro de ganancia y
pasa a ser el costo de adquirir al cliente
([[las-seis-ofertas-del-post-compra]]).

> OJO: esto vale **con el post-compra funcionando y medido**. Sin backend, un front a
> break-even es un front que no gana.

## Aplicación
En cada tienda validada, revisar los 3 momentos pre-compra + la cadena post-compra. Si solo se vende el front, se está dejando ticket (y capacidad de puja) sobre la mesa.
