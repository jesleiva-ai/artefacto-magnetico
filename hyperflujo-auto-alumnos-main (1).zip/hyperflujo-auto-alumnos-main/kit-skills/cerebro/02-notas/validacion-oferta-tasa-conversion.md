---
type: nota
created: 2026-07-27
tags: [productos-digitales, meta-ads]
source: "criterio el kit — medido en tiendas propias"
status: activa
moc: "moc-landings-y-ofertas"
aliases: ["Cuando una oferta esta validada", "Umbrales de tasa de conversion"]
---

# Oferta validada: 24-72 horas convirtiendo arriba del 2 por ciento

## Punto clave
La compuerta entre lanzar y escalar: si la oferta principal sostiene una tasa
de conversión **>=2% durante 24/48/72 horas**, está validada y recién ahí se
trabaja ticket promedio con upsells y post-compra. Antes de eso, solo se valida
el front. Hermana del diagnóstico por tasa de conversión (misma métrica, otro
momento: aquella diagnostica una oferta corriendo a 15 días; esta es la compuerta
de lanzamiento a 24-72 h).

## Umbrales de lectura
- **1,5%** — hay cosas por mejorar en la landing/oferta.
- **2%** — tranquilo: hay mejoras posibles pero no son prioritarias.
- **2,5%+** — pensar en escalar o en subir AOV para ganar la puja publicitaria.

## Reglas asociadas
- Lanzamiento a **USD 15-20**; los aumentos de precio se validan con el mercado.
  Objetivo final: ticket promedio **USD 30-45** ([[upsells-unit-economics]]).
- **Microsoft Clarity se conecta SIEMPRE al lanzar**: los puntos de fuga del
  scroll dicen qué sección iterar. Pero si la conversión está >=2%, tocar la
  landing NO es prioridad — el foco va a AOV o a escala.
- Matar vs pivotar la oferta no tiene número fijo: se decide caso por caso, y el
  criterio se va incorporando a medida que se decide.
- Deducción estándar en todo cálculo de profit: **8% de comisiones**
  (plataforma + pasarela).

## El post-compra baja el piso: 1,5% puede ser rentable (2026-09-16)
Matiz agregado en vivo, que **no invalida el 2% — le da una salida**:

> *"Busquemos una conversión arriba del 2 por ciento. Y la magia que tiene
> [la plataforma de la tienda] en este momento es que, al aumentar el AOV, podés
> llegar a tener una conversión del 1,5 y ser muy rentable igual. Porque con el
> post-compra le subís tanto tu ticket promedio que la rentabilidad igual está."*

O sea: **la tasa de conversión dejó de ser la única compuerta.** Lo que se valida
es la unidad económica, y hay dos palancas para cerrarla — cuánta gente compra, y
cuánto deja cada uno. El 2% sigue siendo el objetivo de la landing; el 1,5% deja de
ser un bloqueo si el AOV lo compensa ([[primero-el-ticket-promedio-despues-la-escala]],
[[el-embudo-post-compra-en-impultienda]]).

Se dijo en la misma respuesta en que se corrigió la lectura por volumen: *"podés
estar teniendo 10 ventas por día, pero si la conversión es del 1 por ciento, la
landing tiene puntos de mejora"*. El 1% sigue siendo landing rota; el 1,5% con
post-compra armado, no.

**Cuidado al aplicarlo:** es una salida para una oferta que **ya tiene el
post-compra andando y medido**. Una landing al 1,5% sin post-compra no está
cubierta por esto — está abajo del piso.

## Aplicación
Toda tienda nueva se juzga contra esta compuerta, no contra sensaciones. Y toda
sugerencia de mejora de landing se subordina a la regla del 2%: primero mirar la
tasa, después opinar. Si la tasa cae entre 1,5% y 2%, antes de tocar la landing
mirar si el AOV cierra la cuenta: puede que el trabajo esté en el post-compra y no
en el copy.
