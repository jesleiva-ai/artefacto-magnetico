---
type: nota
created: 2026-11-07
tags: ["meta-ads", "cerebro-ia"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["Vigías y paneles"]
---

# Vigías y paneles

## Punto clave
Robots que no deciden nada: miran y avisan, o juntan todo en un solo lugar.

Robots que no deciden nada: miran y avisan, o juntan todo en un solo lugar.

## Vigía de pagos

**El problema:** un día una cuenta quedó en "pago necesario" varias horas en plena escala de madrugada y nadie se enteró. Trampa conocida: una tarjeta puede dejar de aceptar después de muchos cobros en un día.

**Qué hace** (cada 15 min): si una cuenta pasa a un estado de pago frenado (deuda, gracia, deshabilitada por pago), manda un aviso con la deuda, la tarjeta, **qué otras cuentas usan esa tarjeta**, y el link directo para pagar. Repite cada hora mientras siga frenada y avisa cuando vuelve. Si la API está frenada en esa pasada, avisa en la siguiente.

**Lo que no hace:** pagar ni cambiar tarjetas. Eso es del dueño; lo que se automatiza es **enterarse en minutos y no en horas**.

**Recomendaciones que dejó:** tarjeta de respaldo en cada cuenta grande, una tarjeta distinta por cuenta, avisar al banco del volumen.

**Trampas:**
- Pedir gasto y saldo de **todas** las cuentas en una sola llamada era "carga pesada" para Meta y frenaba a todos los robots 30-45 min, cada 15 min. Ahora: lista liviana y gasto/saldo cuenta por cuenta.
- En una cuenta **nueva**, el vigía no detectó un pago pendiente. Los primeros días revisá el estado a mano.

## Pulso de la API

Un panel que muestra en vivo cuántas llamadas hacen los robots a Meta (cada 10 min), el uso que informa la API y cuándo hubo pausas. No gasta cupo: lee el registro de llamadas que escribe el cliente de la API. Sirve para responder "¿quién frena a los robots?":
- los **frenos reales** de Meta llegan con códigos propios (por usuario, por app, por cuenta);
- las pausas "uso al 90 %" son **preventivas** del propio cliente;
- el freno por usuario **se suma entre apps**: si los robots y tus análisis usan el mismo usuario, tus análisis frenan a los robots.

**Regla:** los análisis pesados **no** van por el token de los robots. Para investigar se usa otra vía (el conector oficial, que es otra app) y lo cobrado de la tienda.

## El freno compartido de la API

Todos los procesos que hablan con Meta (el cliente de los robots, el conector, paneles) comparten **un freno en disco**. Quien recibe un código de estrangulamiento lo escribe, y todos paran. La doc de Meta es textual: si llegaste al límite, **dejá de llamar**; si seguís, el contador sigue subiendo. "Un reintento cortés sigue siendo un reintento." Lo aprendimos cuando un panel se comió decenas de códigos de freno sin escribirlo y los demás siguieron llamando.

## Centro de mando

El panel único: ganancia y ROAS por día y por mes, cada mercado, creativos nuevos y activos por mercado (renovación), pagos y la lista de pendientes. Se actualiza cada 20 min (de madrugada, cada hora, para no gastar cupo). Ganancia con el mismo criterio que el resto de los tableros.

**Detalle técnico útil:** el panel es una página que lee archivos chicos en la nube que el servidor actualiza; hay un tope de tamaño por archivo (medido), así que cada sección va en su propio archivo.

## Vencimientos que avisan solos

- **Token de la API:** vence y no se puede estirar sin el login del dueño. Un vigía avisa cuando quedan menos de 15 días, con los pasos exactos para renovarlo.
- **Cupos de IA:** un vigía mide el uso de las cuentas de IA de los robots y avisa si no llega al reset, si queda poco saldo, si corta y cuando vuelve.

## Salud de la tienda (reglas adoptadas de un colega)

Un robot diario que avisa solo si algo se sale:
- **Tasa de carga** (visitas ÷ clics en el enlace) por debajo de ~75 %.
- Un anuncio con más del **80 % del gasto** de su campaña (pedir relevo).
- Pagos diferidos (medios que tardan días en confirmar) y poscompra.
- Nada de tocar link o UTM de anuncios que corren (hay un recordatorio automático al intentarlo).
- Ticket promedio: **una palanca por día**, y revertir si los pagos aprobados bajan del 70 %.

## Lo que apagamos

Un bot que mandaba **sugerencias de subir o bajar presupuesto** al dueño con botones. Se apagó: "todo eso lo tenés que manejar vos". Los robots de escala deciden presupuestos; al dueño solo le llega lo que solo él puede hacer (pagar, logins, decisiones de marca o precio).
