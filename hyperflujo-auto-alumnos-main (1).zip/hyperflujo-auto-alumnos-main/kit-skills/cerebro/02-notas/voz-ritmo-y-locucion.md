---
type: nota
created: 2026-11-07
tags: ["meta-ads"]
source: "Fabrica de creativos — aporte al cerebro comun (2026-11-07)"
status: activa
moc: "moc-fabrica-de-creativos"
aliases: ["La voz se mide: el ritmo del ganador es el objetivo, cada pieza se calibra sola y toda voz se transcribe contra el guion"]
---

# La voz se mide: el ritmo del ganador es el objetivo, cada pieza se calibra sola y toda voz se transcribe contra el guion

## Punto clave
La voz se mide: el ritmo del ganador es el objetivo, cada pieza se calibra sola y toda voz se transcribe contra el guion. Ritmo del ganador, calibrar por pieza, transcribir contra el guion.

## La regla
1. **Objetivo de ritmo**: medí las palabras por minuto del ganador que estás modelando y apuntá a ese número. Como
   referencia, los anuncios cortos que ganaron hablaban a ~160-195 palabras por minuto; el didáctico más rentable, a
   ~130. Las pausas del ganador **son** su ritmo: no las comprimas por receta.
2. **La velocidad se calibra por pieza**: con la misma voz y el mismo `speed`, textos distintos dieron entre 159 y 203
   palabras por minuto. Generá, medí y recalculá `speed × (objetivo / ritmo obtenido)` para las que se desviaron.
3. **Toda voz generada se transcribe sola** (sin música) contra el guion. Compuerta: 85 % de coincidencia mínima para
   voces de modelos de video; con TTS bueno, palabra por palabra.
4. **El subtítulo sale del guion**, no de lo que oyó el transcriptor (ver [[subtitulos-karaoke-salen-del-guion]]).

## Por qué (lo medido)
- Un post-proceso que comprimía pausas (pensado para otra referencia) subió el ritmo de 162 a 190 palabras por minuto:
  las palabras eran las mismas y la pieza dejó de sonar como el ganador.
- Un TTS barato pronunció mal el nombre del producto en 2 de 5 anuncios y **se comió el CTA** en otro sin que en pantalla
  se notara. ElevenLabs con voz nativa: 5 de 5. Otra voz nativa de la misma cuenta falló 2 de 4: **la voz también se
  prueba**.
- Lo que hace «sonar IA» a una voz no es la pronunciación: es el **rango de tono**. Las voces sintéticas medidas tenían
  la mitad de desvío de tono (en semitonos) que una persona real. Lo único que cerró la brecha: grabar a una persona y
  cambiarle el timbre con speech-to-speech.

## Recetas de voz que funcionaron (ElevenLabs)
- **Relato y explicador**: modelo v3, estabilidad ~.5, similitud ~.8, estilo ~.5, tempo parejo (~1,1 con atempo).
  Da ~3 palabras por segundo. Con multilingual v2 la misma voz salió «trabada y lenta» en un video largo.
- **v3 sale lento** con algunas voces (140-170 palabras por minuto); multilingual v2 a speed ~1,15 da 180-195. Elegí
  modelo por voz, midiendo.
- Speed bajo y estabilidad alta (.95 / .5) sonaron robóticos y pausados; speed 1,05-1,1, estabilidad .3, estilo .5,
  mejor.
- **Sin etiquetas de estilo en inglés** dentro del texto («[epic narrator]»): arrastran el acento a otro país. Voces del
  país del público.
- **Nombres de una palabra** para personajes: «Don Aldo» se leyó «Donaldo».
- **Cifras con lectura** en idiomas donde el TTS duda ([[trampas-por-idioma-y-alfabeto]]).
- **Diálogos**: una pista por voz, y si cada escena trae su propia voz (modelos de video), pasarlas todas por una sola
  voz con speech-to-speech: conserva los tiempos y los labios siguen coincidiendo.
- Tope de llamadas en paralelo (~3): más da error de límite.

## Cómo aplicarlo
generar → transcribir **la voz sola** → compuerta → si falla, transcribir de nuevo con un modelo más grande (si el error
persiste en los dos, es la voz; si desaparece, era el transcriptor) → si el error es real, **reescribir la frase** con
otras palabras (más barato que cambiar de modelo) → recortar el silencio inicial → montar.

Relacionadas: [[molde-de-tanda-guion-voz-planes-montaje]] · [[ugc-con-ia-sin-que-se-note]]
