---
type: moc
created: 2026-11-07
tags: ["meta-ads"]
status: activa
aliases: ["Fábrica de creativos"]
---

# MOC Fábrica de creativos

Lo que se aprendió diseñando, produciendo con IA, testeando y escalando creativos de Meta para productos digitales
de ticket bajo, en varios mercados e idiomas. Viene de una operación real de la comunidad: cada regla salió de una
medición o de un error pagado. Los ejemplos usan productos inventados y las cifras van en relativo.

**Antes de escribir un guion o armar una tanda, leé «Empezá por acá».** Las skills de producción (`/anunciante-supremo`
y las cinco `/anuncio-*`) y `/creativos` corren mejor con estas notas leídas.

**Cómo usarlo en TU cerebro.** Los números (umbrales, topes, ventanas) son de esa operación: tomalos como punto de
partida y ajustalos a tu ticket con tus propios datos. Donde una nota dice que «el dueño dio autonomía» o que «los
robots deciden presupuestos», describe cómo trabaja ese equipo, no un permiso para vos: en este cerebro, nada que
mueva plata, prenda anuncios o cambie presupuestos se hace sin el OK del dueño.

## Creativos que venden

Este paquete destila lo que el equipo aprendió diseñando, produciendo y midiendo creativos para productos digitales en
Meta (Facebook e Instagram) y en orgánico, en varios idiomas. Todo lo que dice «medido» salió de campañas reales; los
ejemplos están reescritos con **productos inventados** (masa madre, finanzas personales, huerta, inglés para viajar,
yoga, carpintería, planillas). Las cifras van en relativo (ROAS, %, índices).

La parte técnica (herramientas, voz, subtítulos, traducción, QA, música, montaje, reels orgánicos) está más
abajo, en «Producción con IA».

### Empezá por acá (antes de escribir un guion)
- [[el-creativo-es-la-palanca-y-la-calidad-no-se-negocia]] — el creativo es la palanca; ganan deseo y miedo, mueren las características
- [[checklist-antes-de-producir]] — las 16 preguntas antes de gastar un crédito
- [[el-creativo-escalado-tiene-seis-bloques]] — frenar, reconocerse, culpable, mecanismo, prueba, oferta; y los cinco arcos ganadores
- [[el-gancho-se-elige-por-el-mecanismo-que-activa]] — ~27 fórmulas de gancho por mecanismo, con ejemplos
- [[lo-que-se-ve-es-lo-que-dice-la-voz]] — plano 0 literal, producto a la mitad, b-roll sin repetir

### Por qué funcionan
- [[los-ganadores-repiten-cinco-movimientos]] — número, enemigo, persona, prueba, oferta sin riesgo
- [[sesgos-en-orden-atencion-identificacion-creencia-accion]] — los sesgos por etapa, y lo que no replica
- [[el-estilo-lo-decide-que-vende-el-producto]] — subtítulo, duración y cara según qué vende el producto

### Lo medido en las cuentas propias
- [[receta-medida-heroe-traducido-y-muestra-real]] — la plata la hace el héroe traducido exacto; el mejor CPA, la muestra real
- [[un-ganador-cansado-se-revive-con-su-post]] — regla del 80 %, el post original, por qué fallan las variaciones cosméticas
- [[los-anuncios-no-se-fatigan-mueren-sin-arrancar]] — el 91 % de los muertos nunca arrancó
- [[cada-renovacion-mezcla-formatos]] — mismo ángulo en 3 formatos por conjunto; catálogo de formatos
- [[el-gancho-se-testea-con-el-cuerpo-fijo]] — variantes de gancho en cuerpo fresco; la absolución primero
- [[copy-y-video-cargan-angulos-distintos]] — la grilla copy × video y cuatro arquetipos de guion
- [[un-ganador-rinde-muchos-anuncios-a-costo-casi-cero]] — variantes de un solo eje
- [[portar-un-ganador-a-otro-idioma]] — lo que viaja es guion + gancho
- [[desarmar-un-ganador-antes-de-modelarlo]] — el método para modelar sin inventar

### Reglas de copy, cumplimiento y producto
- [[reglas-de-copy-y-lo-que-meta-rechaza]] — sin precio, sin rebaja, sin otras redes, un idioma por anuncio
- [[material-ajeno-hace-rechazar-aunque-venda]] — material ajeno, clips de clientes, falsos positivos
- [[adaptar-un-gancho-ajeno-sin-romper-tus-reglas]] — tensión sí, superficie no
- [[el-producto-en-pantalla-es-siempre-el-real]] — zona verde y producto real; lo prometido está en el entregable
- [[los-estaticos-que-ganan]] — muestra real, tres beneficios, clon con zona verde
- [[mockups-nivel-agencia]] — valor percibido de diseñador
- [[testimonios-y-personas-en-pantalla]] — sin testimonios inventados, nombres del país, casting por mercado

### Estilos (mecánica, receta y trampas de cada uno)
- [[estilo-viral-macro-con-personaje]] — macro hiperreal + personajes, psicología inversa, bucles
- [[estilo-ugc]] — persona a cámara, review de la app, podcast, venta directa
- [[estilo-claymation]] — plastilina que personifica al villano
- [[estilo-3d-explicador]] — corto animado en cuatro capítulos con el mecanismo por dentro
- [[estilo-musical]] — canción con letra propia, voz cantada desde el medio segundo
- [[estilo-personaje-3d-que-habla]] — el tema es un personaje amenazado que habla
- [[estilo-cine-y-explicador-simple]] — trama vs. voz en off simple sobre escenas dinámicas

### Orden de trabajo sugerido para tu Claude
1. Leer este índice, el checklist y la nota de seis bloques.
2. Desarmar 3-5 ganadores del nicho e idioma ([[desarmar-un-ganador-antes-de-modelarlo]]).
3. Elegir estilo por lo que vende el producto ([[el-estilo-lo-decide-que-vende-el-producto]]).
4. Escribir 5 conceptos × ≥3 formatos, pasar el checklist, producir **una** pieza, aprobarla, y recién la tanda
   ([[molde-de-tanda-guion-voz-planes-montaje]]).
5. QA automático + hojas de cuadros, cargar en pausado, medir por familia con 3 días o más, anotar qué ganó y por qué.

## Producción con IA

Cómo se fabrican, por código y con modelos generativos, los creativos de la sección de arriba: qué
herramienta para qué toma, el molde de una tanda, la voz y los subtítulos, la traducción de ganadores, el QA automático,
la consistencia de personajes, la música, el montaje con ffmpeg y los reels orgánicos. Los costos van como índice
relativo (1 = una toma de Veo 3.1 Fast de 8 s).

### Herramientas
- [[herramientas-y-para-que-sirve-cada-una]] — el mapa de herramientas y el índice de costos
- [[cada-modelo-de-video-tiene-su-trampa]] — Veo, Kling, Wan, MiniMax, modelos que hablan, modelos de imagen
- [[prompts-de-imagen-decir-que-va-no-que-no]] — prohibir no alcanza; texto fijado; género antes que calidad

### El molde de una tanda
- [[molde-de-tanda-guion-voz-planes-montaje]] — guion verificado → voz con tiempos → plan frase→plano → montaje → QA
- [[el-guion-solo-nombra-lo-que-hay-en-el-banco]] — catalogar antes de escribir; bancos gratis; medir el clip
- [[voz-ritmo-y-locucion]] — ritmo del ganador, calibrar por pieza, transcribir contra el guion
- [[subtitulos-karaoke-salen-del-guion]] — texto del guion, tiempos de la voz, una sola capa
- [[musica-de-los-creativos]] — energía hasta el final, debajo de la voz, una sola canción, −14 LUFS
- [[montaje-con-ffmpeg-y-sus-trampas]] — pasos separados y las trampas que ya rompieron videos

### Calidad
- [[qa-automatico-de-piezas-con-ia]] — qué mide la máquina, qué se mira a ojo, cómo no engañarte
- [[ugc-con-ia-sin-que-se-note]] — luz de selfie, una sola voz, tono real
- [[hoja-de-personaje-y-consistencia]] — Character Bible, nombrar siempre, referencia con medida

### Otros idiomas
- [[traducir-un-ganador-exacto]] — Demucs, anclas por frase, ±8 %, planos con texto que se mueven
- [[trampas-por-idioma-y-alfabeto]] — sin espacios, con alfabeto propio, OCR, dialectos
- [[imagenes-con-texto-en-otro-idioma-se-recrean]] — recrear con IA, auditar letra por letra

### Orgánico
- [[reels-organicos]] — modelar cuentas, 3 por día, etiqueta IA, bucles, de orgánico a anuncio

### Las cinco reglas que más plata ahorraron
1. **Una pieza aprobada antes de renderizar la tanda.**
2. **Dividir el saldo por el costo por pieza antes de arrancar.**
3. **Hoja de cuadros de cada toma generada** (~1 de cada 8 sale mal).
4. **El subtítulo sale del guion**, comparado letra por letra antes de quemarlo.
5. **El mp4 final se verifica** (errores, cuadros contados, voz por ventanas, faststart), no la duración.

## Testeo y escala

Lo que aprendimos operando campañas de Meta para un producto digital de ticket bajo, vendido en muchos mercados e idiomas a la vez, con robots que deciden solos casi todo el día. Nada de esto es teoría: cada regla salió de una medición en campañas reales o de un error que pagamos.

### Cómo leer los números

Los montos van en relativo, para que los traslades a tu ticket:

- **T** = ticket promedio por comprador (compra principal + extras).
- **P** = presupuesto diario de un conjunto de testeo (el mínimo que usás para probar una pieza).
- **CPA objetivo** = T ÷ ROAS meta. Con ROAS meta 1,4, el CPA objetivo es ~0,7 T.
- **Punto de equilibrio** = el CPA en el que ni ganás ni perdés, después de comisiones (para nosotros, ~0,9 T).
- ROAS, porcentajes, días y horas van tal cual, porque son ratios y ventanas, no plata.

### Las notas

| # | Nota | En una línea |
|---|---|---|
| 01 | [[estructura-de-testeo]] | Un testeo fijo por mercado que nunca se apaga, conjuntos 1-1-3, cola diaria de 5 por mercado. |
| 02 | [[cuando-un-creativo-gana-y-cuando-se-apaga]] | Cortes y coronación en múltiplos de P y de T, decididos con lo cobrado, no con el píxel. |
| 03 | [[escala-con-tope-de-costo-la-canilla]] | Con puja de tope, el presupuesto no empuja el gasto: lo abre el tope. Cómo buscarlo cada madrugada. |
| 04 | [[reglas-duras-de-la-escala]] | No tocar las escalas por dentro, techo fijo, ganadores que siguen en testeo, concentrar. |
| 05 | [[fatiga-y-relevo-de-ganadores]] | Los ganadores se cansan sin avisar; el relevo es un ángulo nuevo, no una variación cosmética. |
| 06 | [[perfil-por-mercado-y-horarios]] | Cada mercado con su ticket, su meta, su tope y su pico; la mañana anticipa poco. |
| 07 | [[rehabilitar-un-mercado-que-se-cae]] | Una semana de testeo concentrado con ganadores traducidos; si no, borrón y cuenta nueva. |
| 08 | [[precio-de-entrada-por-pais]] | Bajar el precio solo donde hay menos poder adquisitivo, y subirlo por escalones de ventas. |
| 09 | [[modos-ganancia-ofensivo-salvavidas]] | Abrir la canilla con creativos cansados agranda la pérdida. Cuándo acelerar y cuándo cuidar. |
| 10 | [[medir-con-ventanas-no-con-un-dia]] | Un día no dice nada; la tendencia de 3 días contra el mejor tramo, sí. Y medir lo cobrado. |
| 11 | [[errores-pagados-en-testeo-y-escala]] | La lista de lo que nos costó plata, con la regla que dejó cada uno. |

### Las cinco ideas que sostienen todo

1. **El negocio depende de pocos ganadores por mercado.** Si no hay relevo listo antes de que se cansen, la ganancia se va sin un día malo que lo delate.
2. **El testeo es la máquina.** No se apaga, no se achica: se mejora la calidad de los ángulos con el mismo volumen.
3. **En cost cap, el tope es la canilla.** Subir presupuesto no compra volumen; subir el tope sí, y el tope de arranque es el CPA que vas a pagar.
4. **Se decide con lo cobrado y con ventanas.** El píxel infla (cuenta cada extra como compra) y un día suelto es ruido.
5. **Los robots también son hipótesis.** Cada decisión automática se audita después y la regla que viene errando se frena sola. Ver «Los robots», más abajo.

## Los robots

Un negocio que vende en muchos mercados a la vez no se puede operar a mano: son muchas decisiones por día. Lo que sigue es la flota de robots que opera las campañas y la producción de creativos casi sola: qué hace cada uno, cuándo corre, cómo decide, cómo se audita y cómo se protege cuando falla.

No van horas exactas a propósito: lo importante es el **orden**: medir antes de decidir, producir de noche sin tocar Meta, cargar de tarde cuando el cupo de la API está libre.

### Dos tipos de robot

- **Robots de reglas** (scripts, sin IA): deciden con números fijos de un archivo de criterio. Son baratos, rápidos, no dependen de cupos de IA. Son la mayoría.
- **Robots con IA** (un modelo corriendo sin supervisión, con herramientas acotadas): se usan donde hace falta juicio: producir creativos, juzgarlos, el guardia nocturno, la lista de pendientes. Siempre con **una sola palanca** y límites duros.

### La flota

| Robot | Cuándo | Qué decide | Nota |
|---|---|---|---|
| **Cola de testeo** | al arrancar el día | Prende los 5 conjuntos siguientes de cada mercado | [[robot-de-testeo]] |
| **Poda del testeo** (piloto) | a la tarde y a la noche | Apaga lo que no vende, sube lo prometedor, protege ganadores | [[robot-de-testeo]] |
| **Pasaje de ganadores** | al arrancar el día, después de la cola | Lleva ganadores del testeo a la escala de su mercado (o la crea) | [[robot-de-escala]] |
| **Escalera de presupuesto** | cada 30 min | Sube o baja el presupuesto de cada escala | [[robot-de-escala]] |
| **Escalera de topes** (la canilla) | cada 30 min | Busca el tope de costo donde la escala gasta y vende | [[robot-de-escala]] |
| **Perfil por mercado** | cada noche, antes del reset | Ticket, ROAS meta, CPA/tope, pico y fase de cada mercado | [[robot-de-escala]] |
| **Picos horarios** | al arrancar el día | La franja de 4 h con más ventas de cada mercado | [[robot-de-escala]] |
| **Freno de mano** | cada hora | Corta a la mitad la escala que pierde fuerte en el día | [[guardias-de-los-robots]] |
| **Guardia nocturno (IA)** | 4 vueltas de madrugada | Mueve topes ±1 escalón leyendo logs, sin llamar a Meta | [[guardias-de-los-robots]] |
| **Guardia mecánico** | cada 15 min de noche | Destraba candados, relanza robots quietos, avisa | [[guardias-de-los-robots]] |
| **Salvavidas** | cada 15 min | Si la cuenta de un mercado deja de gastar, prende su respaldo | [[guardias-de-los-robots]] |
| **Termómetro** | a la mañana, después de la alarma | Tendencia de 3 días contra el mejor tramo | [[guardias-de-los-robots]] |
| **Alarma de cansancio** | a la mañana temprano | Marca ganadores cansados y encarga relevos | [[guardias-de-los-robots]] |
| **Auditor de robots** | cada hora | Juzga cada decisión con lo que pasó después; frena reglas que erran | [[auditor-de-robots]] |
| **Jurado de clientes ideales (IA)** | al terminar la tanda + una vuelta a la tarde | Predice cada creativo, lo revisa a los 3 días, aprende | [[jurado-de-clientes-ideales]] |
| **Fábrica nocturna (IA)** | de noche | Produce la tanda de creativos de cada mercado, sin Meta | [[fabrica-nocturna-y-carga]] |
| **QA de creativos** | antes de cargar | Formato, audio, voz, idioma, OCR; bloquea con rojo | [[fabrica-nocturna-y-carga]] |
| **Semáforo de la tienda** | antes de cargar | Frena la tanda si la tienda del mercado está rota | [[fabrica-nocturna-y-carga]] |
| **Carga (IA)** | a la tarde | Crea creativos, conjuntos y anuncios en pausa | [[fabrica-nocturna-y-carga]] |
| **Cola de traducciones** | mañana | Matriz ganador × mercado; encarga 2 por mercado por día | [[fabrica-nocturna-y-carga]] |
| **Vigía de pagos** | cada 15 min | Avisa cuando una cuenta queda frenada por el pago | [[vigias-y-paneles]] |
| **Pulso de la API** | cada minuto | Llamadas, uso y frenos de Meta en vivo | [[vigias-y-paneles]] |
| **Centro de mando** | cada 20 min | El panel único: ganancia, mercados, creativos, pagos | [[vigias-y-paneles]] |
| **Selector de cuentas de IA** | en cada robot con IA | Elige la cuenta con cupo; reintenta con otra si corta | [[vigias-y-paneles]] |
| **El jefe (IA)** | a la mañana y a la noche | Lista única de pendientes y la siguiente jugada | [[lista-unica-de-pendientes]] |

### Las piezas comunes

- **Un archivo de criterio único** con todos los números de testeo y escala. Un número se cambia ahí y en ningún otro lado.
- **Un archivo de configuración de escala** con el modo del negocio, las campañas, topes, techos, ventanas horarias y pisos. Varios robots lo leen y lo escriben **bajo candado**.
- **Bitácoras en disco** (una línea JSON por decisión, con fotos cada 30 min de gasto y cobrado). Son lo que permite auditar, armar paneles y que el guardia decida sin llamar a Meta.
- **Un cliente de la API con freno compartido**: si cualquiera recibe un código de estrangulamiento, escribe el freno y todos paran.
- **Telegram** solo para lo importante, en el idioma del equipo, y nunca con decisiones de presupuesto para el dueño: eso lo manejan los robots.

### Las notas

| # | Nota |
|---|---|
| 01 | [[robot-de-testeo]] |
| 02 | [[robot-de-escala]] |
| 03 | [[guardias-de-los-robots]] |
| 04 | [[auditor-de-robots]] |
| 05 | [[jurado-de-clientes-ideales]] |
| 06 | [[fabrica-nocturna-y-carga]] |
| 07 | [[vigias-y-paneles]] |
| 08 | [[lista-unica-de-pendientes]] |
| 09 | [[robots-que-fallan-seguros]] |
| 10 | [[trampas-de-subagentes-y-sesiones]] |
| — | Esqueletos de código (`~/herramientas/esqueletos-robots/`) |

Para las reglas de negocio que estos robots ejecutan, ver «Testeo y escala», más arriba.

## Lecciones de este dominio
