---
type: moc
created: 2026-11-09
tags: ["ofertas"]
status: activa
aliases: ["Landings y ofertas"]
---

# MOC Landings y ofertas

Cómo se arma una oferta low ticket que vende, cómo se le pone precio, cómo se monta la landing y qué
va en el postcompra. Sale de tiendas propias y de landings ganadoras analizadas; los ejemplos están
anonimizados. Las skills `/investigar-mercado`, `/oferta-completa`, `/pricing`, `/maqueta-landing`,
`/evaluar-landing`, `/desarme-completo` y `/postcompra` citan estas notas: leelas desde acá.

## Landings
- [[landing-tobogan-sin-botones-arriba]] — la landing es un tobogán: cero botones arriba, cero flotantes, cero WhatsApp
- [[medir-la-landing-antes-de-replicarla]] — el análisis por texto no llega a la capa que hace vender: hay que MEDIR la referencia y VERLA
- [[playbook-landings-escaladas]] — las tiendas escaladas no suben presupuesto: multiplican ads que apuntan a una landing de UNA oferta
- [[patrones-visuales-y-titulares-ganadores]] — los ganadores comparten 6 patrones visuales y se parten en dos escuelas de titular
- [[la-paleta-se-mide-no-se-elige]] — la paleta se mide: contá familias de tono y mirá el render, no el CSS
- [[elegir-la-paleta-de-un-nicho]] — el tono de una paleta sale de medir el nicho y el escritorio del avatar, no de una tabla
- [[2026-07-28-marco-copy-visual-gatillos-solved]] — la estrategia brasilera: marco replicable de copy, visuales y gatillos (molde Solved)
- [[pagina-placebo-blindaje-y-espionaje]] — la página placebo: los ganadores esconden su landing real
- [[clarity-y-embudo-puntos-de-fuga]] — el punto de fuga se encuentra con Clarity + las métricas de embudo, no adivinando

## Copy, ángulos y anuncios
- [[formulas-de-copy-de-las-ganadoras]] — las 16 fórmulas de copy, con la frecuencia que dice si son ley del mercado o firma de un molde
- [[guiones-madre-anuncios-ganadores]] — seis guiones madre se repiten en los anuncios ganadores de ofertas distintas
- [[angulos-ocupados-se-leen-en-los-anuncios]] — qué ángulos están ocupados no se deduce de la landing: se lee en los anuncios
- [[reglas-de-lectura-de-metricas-meta]] — cuatro reglas para leer métricas de Meta sin engañarse

## La oferta
- [[producto-vs-oferta-transformacion]] — el producto son características; la oferta es la transformación
- [[promesa-cuatro-atributos]] — toda promesa: cuantificable, sencilla, creíble y transformadora
- [[seguridad-prueba-social-garantia]] — prueba social, autoridad y garantía reducen el miedo; urgencia y escasez empujan
- [[stack-bonuses-oferta-irresistible]] — bonuses que resuelven problemas FUTUROS hacen la oferta irresistible
- [[validacion-oferta-tasa-conversion]] — oferta validada: 24-72 horas convirtiendo arriba del 2 por ciento
- [[el-formato-del-entregable-no-es-el-valor]] — el formato del entregable no es el valor percibido: un PDF le gana a ofertas con vídeo y con app
- [[el-low-ticket-se-entrega-una-sola-vez]] — el producto low ticket se entrega una sola vez: todo lo que no aguante 100 ventas por día no puede estar en la oferta
- [[no-le-des-opciones-al-comprador]] — cada alternativa que le das al comprador lo confunde: primero validás la transformación, el formato es irrelevante

## Precio y ticket promedio
- [[primero-el-ticket-promedio-despues-la-escala]] — ante una oferta que convierte, subir el ticket promedio va ANTES que escalar en Meta
- [[upsells-unit-economics]] — el upsell sube el ticket promedio y te deja pagar más CPA que la competencia
- [[upsell-treinta-caracteres-y-mockup]] — el upsell se decide en ~30 caracteres y un mockup: no repitas el mismo mensaje en los dos
- [[roas-benchmarks-low-ticket]] — la escala de ROAS low-ticket: 1 / 1,5 / 2 son las fronteras
- [[2026-07-28-nutritionsolved-front-y-backend]] — rayo-X — nutritionsolved: FRONT + BACKEND completo (2026-07-28)

## Postcompra
- [[el-post-compra-es-lo-unico-que-no-te-copian]] — todo lo que vive detrás del pago es invisible para el que te espía
- [[las-seis-ofertas-del-post-compra]] — en el post-compra hay seis tipos de oferta, y el ebook extra es el peor de todos
- [[el-embudo-post-compra-en-impultienda]] — el post-compra de la plataforma de la tienda: cómo se configura, medido nodo por nodo

## Lecciones de este dominio
- [[2026-07-28-ofertas-adaptar-mercado-destino]] — si no nombrás el mercado destino, el modelo lo rellena con su default
- [[2026-07-28-ofertas-ausencia-no-es-oportunidad]] — un ángulo que no aparece en la Biblioteca no está libre: lo más probable es que ya lo hayan matado
- [[2026-08-03-ofertas-canal-de-venta-separado]] — un informe de ofertas que mezcla venta por web y venta por WhatsApp no se puede usar para decidir
- [[2026-08-03-ofertas-escala-dos-ejes]] — días activos sin cantidad de anuncios no mide escala: mide supervivencia
- [[2026-07-27-cerebro-ia-el-proxy-miente]] — el proxy dice OK; el artefacto dice la verdad
- [[2026-07-28-cerebro-ia-cero-resultados-no-es-no-existe]] — cero resultados dice que tu consulta no matcheó, no que el dato no existe
- [[2026-07-30-cerebro-ia-replicar-pide-el-fuente]] — si el pedido es "replicá esta pieza", el insumo es su fuente — y la prueba es un diff
- [[2026-08-11-cerebro-ia-leccion-que-se-repite-pide-compuerta]] — un dolor que se repite no se arregla con más esfuerzo —tuyo o del dueño—: se arregla con máquina
