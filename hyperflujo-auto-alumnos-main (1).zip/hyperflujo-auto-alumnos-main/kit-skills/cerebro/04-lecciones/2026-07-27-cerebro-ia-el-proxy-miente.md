---
type: leccion
created: 2026-07-27
tags: [cerebro-ia]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 44
validada: 2026-10-31
moc: "moc-landings-y-ofertas"
aliases: ["El proxy miente", "Verificá el artefacto, no el indicador"]
---

# El proxy dice OK; el artefacto dice la verdad

## Punto clave
Un log, un exit code, un índice, un «200», un «Guardar» sin error o una URL devuelta
solo prueban que **el proceso terminó**, nunca que **produjo lo que creés**. Antes de
reportar que algo funcionó, falta o está mal, andá al artefacto real: el archivo, el
render, el valor releído después de recargar, el registro del otro lado.

## Qué pasó
Siete veces el mismo error con distinta cara. En todas, un indicador barato dijo
una cosa y el artefacto real decía otra — y en todas se le reportó al dueño la
versión del indicador:

| El proxy que mintió | La verdad |
|---|---|
| `JARDIN.md` decía "archivo movido a procesado/" | el `.vtt` seguía en la cola; la próxima corrida habría duplicado notas |
| El log de la corrida automática decía `[fin]` | 3h29 dando vueltas, cero notas, cero commits — idéntico a una corrida exitosa |
| `brew install ffmpeg \| tail -3` salió con exit 0 | brew no existía en esa Mac; el 0 era de `tail` tragándose el "command not found" |
| El scraper escribió OK en 139 transcripciones | 45 tenían adentro el video de otra clase |
| El índice del programa no listaba "buscar ofertas ganadoras" | existía, con 90 min de clase dentro de otro módulo |
| El reloj de la Mac decía 2026-07-25 | la Mac estaba en UTC-4 por viaje; la nube había fechado bien |
| El primer eslabón de la cadena respondió bien | se declaró "único blocker"; el bloqueo real estaba tres eslabones después |
| Un censo externo que volvió **vacío** | La fuente cortó por rate-limit; "cero inquilinos" era "no pude ver", y la tabla de cardinalidad se calculó sobre denominador 0 |
| El panel dijo **"49 de 52 ventas que Meta no vio"** | Meta estaba estrangulada y devolvía **0 ventas**: por eso *todas* parecían no vistas. El número real era **5** |
| "La plataforma de despliegue tiene **solo lectura** sobre el repo" | La pantalla de permisos decía **Read and write** sobre el código. Se dedujo el alcance por el uso, no se leyó lo declarado |
| `config.json` decía `idioma: "es"` desde hacía 5 días | El motor de dictado **no acepta `language=`**: la perilla nunca le llegó. El `.py` lo declaraba con un `# noqa: ARG002` — argumento sin usar |
| El motor se eligió **midiendo**: 116 ms vs 413 ms, WER 3,21% vs 4,59% | La muestra eran clips de 4,8 s. Arriba de 18 s ese motor traduce el dictado entero al inglés: 4 de 4 largos rotos, 4 de 4 cortos perfectos |
| El índice del banco de clips describía un plano con un detalle concreto del producto | El clip **no mostraba ese detalle**: era otra cosa. Casi sale un anuncio cuyo guion hablaba de algo que el plano de apertura no tenía |
| Un `WebFetch` devolvió paleta, tipografía y estructura de una landing | La página es una **SPA**: el HTML pelado son **520 bytes de cascarón**. El modelo chico rellenó con defaults plausibles — «fuente del sistema», `#0066FF`, «sin gradientes». Los tokens reales (tres tipografías de Google Fonts, fondo casi negro, acento verde) sólo aparecieron **renderizando con Chrome headless** y leyendo `getComputedStyle` |

## Por qué pasó
Todos los indicadores baratos —logs, bitácoras, exit codes, índices, el reloj
local, el primer eslabón— miden que **algo terminó**, no que **algo se produjo**.
Son señales de proceso, no de efecto. Leerlos como evidencia convierte el silencio
en falso éxito, y el costo lo paga el dueño: buscó un menú que no servía, esperó
cuatro iteraciones inútiles, y recibió un backlog con una prioridad ALTA falsa.

## Cómo evitar
- **Verificá por artefacto, siempre.** El binario responde `--version`, el archivo
  existe donde debe, el registro dice que es el que pediste, el contenido tiene un
  dato independiente que lo identifica. Si no podés nombrar ese dato, todavía no
  sabés si tenés lo que creés.
- **En procesos desatendidos:** guardar el estado ANTES (archivos en cola, `HEAD`
  de git) y compararlo DESPUÉS. Capturar exit code, poner techo de tiempo, y
  escribir un veredicto único `[ok]`/`[error]`/`[skip]` por corrida. **"Corrió y no
  cambió nada" es `[error]`, no éxito.** La alarma lee solo el veredicto del último
  bloque, no todo el log.
- **En pipes:** el exit visible es el del ÚLTIMO comando. Cortá el pipe o mirá el
  output completo.
- **Una opción escrita en un archivo de configuración no es un comportamiento.**
  Antes de darla por aplicada, grepeá el código y confirmá que el parámetro LLEGA
  a la llamada. Un argumento que la firma recibe y no usa —`# noqa: ARG002`, `_x`,
  un `**kwargs` que se descarta— es la perilla desconectada, escrita por quien la
  desconectó.
- **Un benchmark prueba el rango que midió, nada más.** Si la muestra es el caso
  cómodo y el uso real tiene una cola larga, el ganador puede ser el peor motor
  ahí. Medí el EXTREMO, no la mediana; y desconfiá del que gana en las dos
  dimensiones a la vez —velocidad Y precisión—: suele significar que el eje donde
  pierde todavía no se midió.
- **Antes de decir que algo FALTA** (en su programa, su vault, su negocio): abrí el
  contenido y buscá sinónimos. Un índice o una lista de títulos no alcanza — o
  degradá la afirmación a hipótesis.
- **Antes de decir "X está mal porque no coincide con Y":** ¿verificaste Y, o es
  solo el que tenías a mano?
- **Nunca afirmes sobre toda la cadena habiendo probado un eslabón.** Si no llegás
  al final, decilo así: "probá esto y vemos qué aparece atrás", nunca "solo falta
  esto".
- **Si 2+ arreglos no mueven el síntoma:** dejá de reparar. Corré el experimento
  más barato que DESCARTE el enfoque entero. Suele costar menos que el tercer
  parche.

## Señal de detección
Estás por reportar que algo funcionó, terminó, falta o está mal, y tu evidencia es
un log, una bitácora, un exit code, un índice, un reloj local o el primer eslabón
de una cadena → detente: andá al artefacto real. El proxy solo prueba que el
proceso terminó, nunca que produjo lo que creés.

**También al RECOLECTAR evidencia, no solo al reportarla** (recurrencia 8,
2026-07-28): estás por citar algo textual y viene de un resumen, una traducción
automática o un buscador → detente: eso no es una cita, es un `[I]`. El resumidor
devuelve texto que *parece* la fuente. Los buscadores parafrasean y traducen: en
una investigación de un nicho de cocina, quejas escritas en español volvieron
parafraseadas en inglés y el banco cerró con 18 citas. Con fetch directo a la
página subió a 35 y apareció la queja madre textual del mercado. **El buscador
sirve para encontrar la URL; la cita se saca de la página.**

**Publicar no es que se vea** (recurrencia 9, 2026-07-28): un artifact con un
error de JavaScript **no falla ruidosamente — queda en blanco**, y la llamada a
`Artifact` devuelve una URL perfecta igual. Al ensamblar las 6 estructuras quedó
un `const ph` duplicado, que es un `SyntaxError` que vacía la página entera; se
agarró por grep de casualidad antes de publicar. "Devolvió URL" es proxy de "la
página se ve". El artefacto real acá es el render: `ojos.py foto --url <artifact>`
y mirarlo. Vale igual para el HTML ensamblado por concatenación, donde el
duplicado de `const` y el backtick sin cerrar son silenciosos.

**Medir no es analizar** (recurrencia 10, 2026-07-28): se reportó "medí 12 de 14
referencias" y se presentó como el análisis hecho. Se había MIRADO **una sola**.
Lo detectó el dueño preguntando si el análisis era completo. La medición es una
capa del análisis, no el análisis: faltaban las fotos, el copy y los anuncios.
Antes de decir "analicé N", contar cuántas pasadas de las que el análisis requiere
corriste sobre cada una — **el número que se reporta es el de la pasada más
floja**, no el de la más fácil.

**El entorno de prueba también es proxy** (recurrencia 12, 2026-07-31): se armó
el bloque HTML/CSS de la landing para pegar en Shopify, se escopó bajo un id, se
LEYÓ y se dio por bueno. El bug apareció recién al montarlo dentro de un tema de
prueba: el tema traía `h1,h2,h3{font-family:Georgia}` y **le ganaba a los títulos
propios**, porque las reglas declaraban tamaño y color pero heredaban la fuente.
De haberse entregado, el equipo publicaba la landing con los títulos en serif.

Mirar el render **de la pieza sola** no valida una pieza que en producción vive
adentro de otra cosa. Y miente en las dos direcciones: la misma sesión midió la
maqueta local sin el `<head>` que le inyecta el envoltorio del artifact y
concluyó dos falsedades — que la página era 2,5x más larga de lo debido (era el
`viewport` ausente) y que había un problema de codificación (era el `charset` del
servidor de prueba). Dos bugs inventados y uno real escondido, por el mismo
motivo.

Antes de entregar algo embebido: **replicar el entorno de destino con sus
hostilidades** — estilos del tema, `charset`, `viewport`, ancho del contenedor —
y medir ahí. Y blindar propiedad por propiedad (`font-family`, `list-style`,
`text-decoration`, `text-transform`, márgenes), no confiar en la herencia.

**La evidencia que produce la COMPUERTA también es proxy** (recurrencia 13,
2026-08-03): se publicó un blueprint de nueve secciones, el hook
`hook-ver-artifact.sh` dejó dos capturas, se miraron, apareció un bug real (un
chip pisando el texto), se arregló, se republicó y se volvió a mirar: limpio. Se
iba a reportar. Pero **las dos capturas del hook son siempre del mismo pliegue**
—el artifact vive en un iframe que no scrollea desde afuera— así que se estaba
firmando el 100% del documento habiendo visto el 2%.

Más abajo había **dos bugs peores**: en dos listas numeradas, el `::before` del
contador ocupaba la primera celda del grid y el contenido caía en la columna
angosta (34 px y 82 px), desarmando el texto en una palabra por línea. Aparecieron
solo al envolver el archivo como documento suelto y fotografiarlo entero en tiras
con `ojos.py foto --escritorio` sobre `file://`.

Dos reglas nuevas de esto:
- **Documento largo → no alcanza el hook.** Fotografiarlo entero antes de
  reportar, y abrir tiras salteadas, no solo la primera.
- **La ALTURA es alarma barata.** La página medía 62.433 px contra ~20.000 que
  justificaba el contenido: esa diferencia *era* el bug. Si el alto no se explica
  por lo que escribiste, hay un problema de layout, no un documento largo.

La compuerta no exime de verificar: produce evidencia, y esa evidencia hay que
mirarla con la misma desconfianza que cualquier otro indicador.

## Historial
Fusiona (2026-07-27) siete lecciones que eran la misma: `bitacora-no-es-estado`,
`fallo-silencioso-desatendido`, `verificar-por-artefacto-no-exit`,
`contenido-no-es-el-que-pediste`, `el-indice-miente-sobre-el-contenido`,
`referencia-externa-antes-de-acusar` y `cadena-completa-antes-de-concluir`.
Con 7 recurrencias pasó a regla dura de CLAUDE.md («verificá por artefacto, nunca
por proxy»).

**Y el envoltorio incluye cómo DESPLIEGA la plataforma** (recurrencia 14,
2026-08-04): replicar el tema, el `charset` y el `viewport` no alcanza si la
plataforma monta la pieza **de a pedazos**. La landing partida en 16 secciones de
Shopify se verificó concatenando los archivos —HTML válido, guardián en verde— y
salió publicada como texto plano: Shopify envuelve cada sección en su propio
`<div id="shopify-section-…">`, y el contenedor abierto en la primera se cerró
ahí mismo, dejando los catorce bloques fuera del alcance del CSS. **Se verificó
el ambiente equivocado con mucho rigor.** La réplica tiene que imitar la
topología de despliegue, no solo el entorno visual.

**Y la herramienta de medición también mide el envoltorio** (recurrencia 15,
2026-08-05): `anatomia.py` apuntado a una URL de artifact devolvió «stack:
Tailwind, tipografía anthropic-sans, 1 botón: Share V3». Eso es la interfaz de
claude.ai, no la landing: el artifact vive en un iframe y la herramienta mide la
página de afuera. Para medir la pieza hay que servirla aparte —`python3 -m
http.server` sobre la carpeta— y apuntar ahí. Si el informe no se parece a lo que
estás mirando, sospechá de qué midió antes de creerle el número.

**Reincidió DOS veces el mismo día pese a ser regla dura** (recurrencias 18 y 19,
2026-08-17). Las dos con la misma forma vieja y en la misma sesión:

1. **Un número derivado sobre una fuente caída.** El panel calcula "ventas que
   Meta no vio" restando las de la tienda menos las del píxel. Meta venía
   estrangulada (`code 17`) y devolvía cero, así que la resta dio *todas*. Se
   reportó como el hallazgo del día. **El error estaba escrito en la misma
   respuesta**, en el campo `error` de ese mismo producto, y no se miró: cuando
   un número sale de restar dos fuentes hay que mirar las DOS antes de reportarlo,
   y una que vino en cero con un error al lado no es un cero, es un hueco.
2. **Un alcance deducido por el uso.** "La plataforma solo despliega, entonces
   solo lee" — la pantalla decía *Read and write* sobre el código. El permiso
   declarado estaba a un scroll de distancia.

Que ya sea regla dura y aun así vuelva significa que la regla cubre el
*reportar* pero no el *derivar*: un número calculado a partir de dos fuentes es un
proxy tanto como un log. La compuerta que faltaría vive del lado del panel —
negarse a exponer una métrica de diferencia cuando alguno de sus dos lados vino
con error.

---

**Recurrencias 22 y 23 — 2026-08-23**, las dos en la misma sesión:

22. **La disponibilidad de la plataforma no es la capacidad de la cuenta.** Se
    argumentó *en contra* de una decisión de negocio del dueño —desactivar un
    medio de pago regional— con el dato de que ese medio opera en ocho países de
    LATAM. El dato era correcto y **no aplicaba**: su cuenta es de un solo país, y
    ese país es justamente el que excluye de sus campañas. El proxy fue *"la
    plataforma llega ahí"*; el artefacto era *"¿tenés cuenta ahí para cobrar?"*,
    que nunca se preguntó. **Antes de discutirle una decisión con un dato de
    plataforma, verificá que ese dato describa SU cuenta, no el producto del
    proveedor.**

23. **Numerar de memoria en vez de contar.** Se etiquetaron los bloques de una
    maqueta como B6 y B9 sin contarlos: eran **B4 y B7**. Se entregó con las
    referencias cambiadas y hubo que corregirlo. El texto de la leyenda además
    quedó escrito a mano en vez de generarse del mismo dato, así que al corregir
    el mapeo la leyenda siguió mintiendo. **Un índice, una posición o un conteo
    se cuentan sobre el artefacto y se generan de una sola fuente — nunca se
    recuerdan.**


## Recurrencia 24 — 2026-08-23, el botón que no responde

Automatizando el panel de la plataforma de la tienda, tres botones no hacían nada
al hacerles `.click()` por JavaScript: el selector de moneda, «Agregar bono» y
«Agregar upsell». **«No pasó nada» es un proxy y admite dos lecturas opuestas**:
que mi automatización no llega al handler, o que el control está roto del lado de
ellos. Elegir mal cuesta horas — o peor, hace que le reportes a un proveedor un
bug que es tuyo.

**El artefacto que lo distingue:** disparar un clic REAL a nivel del sistema por
CDP (`Input.dispatchMouseEvent` en las coordenadas del elemento, no
`element.click()`) **y mirar si sale una llamada de red**, con `fetch` y
`XMLHttpRequest` instrumentados antes de tocar (`manos.py --red`). Cero llamadas
después de un clic confiable significa que el control está muerto. Con eso el
reporte al proveedor deja de ser «no me anda» y pasa a ser reproducible — y lo
arreglaron esa misma noche.

El mismo turno dio la versión formulario: un campo que **acepta** lo que
escribís, guarda sin error, y al recargar volvió al valor viejo. Un `Guardar` sin
error tampoco prueba nada: **releé el valor después de recargar**.

## Recurrencia 25 — 2026-08-25

Para saber cuánto acortar 34 bloques traducidos a un idioma de palabras largas
usé un proxy: **contar caracteres**. Dijo que sobraban **cero**. Faltaban recortar
541. El proxy medía el ancho de la línea más larga, y lo que no entraba no era el
ancho: era la **cantidad de renglones**. Medido con el motor que después renderiza
—las fuentes reales, el ancho real de cada letra— la respuesta salió a la primera y
los 34 entraron a cuerpo completo.

## Recurrencia 26 (2026-08-26) — cero hallazgos también es un proxy

Un guardián nuevo de entrega salió con **0 hallazgos** y parecía que estaba todo
bien. No lo estaba: leía 543 conjuntos y evaluaba **0**. Meta manda las fechas
como `2026-08-26T03:00:00+0000`, sin los dos puntos en el huso, y
`datetime.fromisoformat` de Python 3.9 no lo parsea — la excepción se tragaba
y devolvía False para todo.

**"No encontró nada" no prueba que no haya nada: prueba que no encontró.** A un
guardián hay que preguntarle CUÁNTO MIRÓ, no solo qué vio. Si hubiera reportado
"543 leídos, 0 evaluados" el error saltaba a la vista; reportando solo el
resultado, pasaba por sano.

Y el mismo día, la otra cara: afinarlo contra la realidad sacó **4 falsos
positivos** (conjuntos pausados a propósito por perder) y **3 más** por medir el
tiempo desde la hora programada en vez de desde que el anuncio se encendió. Un
guardián ruidoso se ignora, que es lo mismo que no tenerlo.

## Recurrencia 27 (2026-08-31) — la alerta muda que decía la verdad al revés

El vigilante de la landing de precios de un programa propio dio **siete alertas
idénticas en siete días**: *"lo que bajó NO es la landing: faltan las marcas de
los programas"*. Se leyó como lo que decía — un bloqueo del server o un cambio de
nombre de los programas — y se dejó para revisar a mano.

No era ninguna de las dos. **La landing se había mudado**: la URL vieja devuelve
404 y la viva pasó a ser otra. El 404 de ese sitio manda **71 KB de HTML bien
formado**, así que pasaba el chequeo de "no está vacío" y fallaba el de "tiene las
marcas" — que es exactamente como se ve un cambio de contenido.

**Un 404 con cuerpo es indistinguible de un cambio de contenido si solo mirás el
texto.** El guardián anterior —exigir las marcas, falla cerrada— arreglaba el 403
de 57 bytes y dejaba abierto este: subió el piso de "no vacío" a "tiene marcas",
pero nunca miró la única señal que separa *"esta página cambió"* de *"esta página
no existe"*.

Lo que costó: el precio de un programa **se duplicó** y el cerebro se enteró una
semana después, con la nota de precios marcada como vigente todo ese tiempo.

**Compuerta escrita en la misma sesión** (regla de
[[2026-08-11-cerebro-ia-leccion-que-se-repite-pide-compuerta]]): `curl -w
'%{http_code}'` y el código se evalúa **antes de mirar una sola letra del
contenido**. Si no es 200, el mensaje ya no habla de marcas — dice *"la URL
respondió HTTP 404: la página no está donde la buscamos"* y lo deja escrito.
Probada rompiéndola a propósito contra la URL muerta.

**La forma general, que es lo reusable:** cuando una alerta se repite idéntica
varios ciclos, no la leas como el hallazgo que dice ser. Una alerta que se repite
sin cambiar no está detectando algo que pasa, está describiendo algo que se rompió
— y casi siempre el diagnóstico correcto está una capa MÁS ABAJO de donde el
chequeo mira.

## Recurrencia 28 (2026-08-31) — el número del entregable, contado a ojo

En el pie de un instructivo para un colaborador se escribieron **"59 lecciones"** y
**"28 módulos"**. Los dos salieron de contar a ojo: `ls *.md | wc -l` contó
`INDEX.md` como si fuera una lección (eran **58**), y el conteo de carpetas incluyó
tres módulos **vacíos**, sin ninguna transcripción adentro (eran **25**).

Nadie lo habría notado — salvo que el destinatario usó ese pie como checklist para
verificar el paquete, y los tres números que no cerraban lo mandaron a buscar un
problema que no existía. **Un número puesto en un entregable se convierte en el
criterio de aceptación de quien lo recibe.**

Es la recurrencia 23 (*numerar de memoria en vez de contar*) con otra cara, y la
regla es la misma llevada un paso más: el número que va en el entregable se
produce **con el mismo comando que lo va a verificar**, corrido sobre el artefacto
instalado — no sobre la carpeta de origen, y nunca a mano.


## Recurrencia 29 (2026-08-31) — el formulario a medio hidratar

Configurando la verificación de dominio en el panel de la plataforma de la tienda,
la primera lectura de la pestaña de tracking devolvió el **píxel cargado y el token
de CAPI en cero caracteres**. El token existía: la pantalla del dueño lo mostraba
como puntitos. La página todavía no había hidratado ese campo.

Estuve a un clic de apretar «Guardar cambios» en ese estado. El `PATCH` habría
devuelto **200** igual, y la respuesta habría traído la tienda entera con cara de
éxito — mientras borraba un token de más de 200 caracteres que nadie volvía a
mirar.

Lo nuevo respecto de las 28 anteriores es la **dirección**: hasta ahora el proxy
mentía al VERIFICAR (dijo OK cuando estaba mal). Acá miente al **LEER ANTES DE
ESCRIBIR**, y el costo no es un reporte equivocado sino un dato destruido. Un
campo vacío no significa "está vacío": significa **"todavía no se cargó" o "no lo
puedo ver"**, exactamente igual que la población vacía de la recurrencia del
denominador 0.

**Compuerta, en dos tiempos.** Antes de escribir en un formulario ajeno:
(1) releer los campos que NO vas a tocar y exigir que los que deberían tener
valor lo tengan — si un secreto da largo 0, la página no terminó de cargar:
esperar y releer, nunca guardar; (2) después de guardar, recargar y releer, que
es la mitad que ya era regla. Medido en dos tiendas: los dos tokens intactos
después del guardado.

La forma general: **un formulario es un dispositivo de escritura DESTRUCTIVA** —
manda todos sus campos, no solo el que tocaste. Leerlo entero antes de guardar no
es prolijidad, es el único respaldo que hay.

---

**El acuse de recibo tampoco prueba el hecho** (recurrencia 30, 2026-09-02, el
dominio fantasma). Se compró un dominio de TLD nacional por la API del registrador.
Todo dijo que sí: la llamada devolvió éxito, el dominio apareció en el portafolio,
se generó una suscripción y se cobró. Diez días después seguía en estado
`Requested`, sin nameservers, y el registro oficial del TLD —el único que puede
registrar ese dominio— respondía *"No information available about domain name"*.
La compra nunca se completó.

Lo nuevo respecto de las 29 anteriores: hasta acá el proxy mentía sobre algo que
YA había pasado. Este miente sobre algo que **todavía no pasó y quizá no pase
nunca** — el portafolio del registrador es su propia *contabilidad*, no el
*registro*. Son dos sistemas distintos, y solo el segundo constituye el hecho.
Que un proveedor te cobre es prueba de que te cobró, nada más.

El agravante es el que vale guardar: el encabezado de la herramienta del
registrador citaba esa misma compra como prueba de que la función andaba —
*"SÍ: COMPRAR un dominio. Probado comprando <ese dominio>"*—. O sea que el proxy
que mintió **quedó escrito como evidencia** para todos los agentes siguientes. Una
verificación mal hecha no se borra sola: se fosiliza en la documentación y se cita
como si fuera medición.

**Compuerta:** después de comprar un dominio se cruza el portafolio del
registrador contra el RDAP del TLD y contra el DNS, y se marca el que el
registrador da por bueno y el registro no conoce. Falla ABIERTA: si el RDAP no
responde se dice `no se pudo ver el registro`, nunca "no existe" (probado en vivo —
un timeout de `rdap.org` dejó un dominio en `[ ? ]`, y el dominio existía). Una
compra que sigue en `Requested` a las 24 h está colgada — se reclama en el panel
del registrador, porque la API no cancela ni reembolsa (verificado: 404 en
`DELETE /subscriptions/{id}` y en `POST /subscriptions/{id}/cancel`). Lo único
automatizable es apagar la renovación.

**El texto de la interfaz también es un proxy del COMPORTAMIENTO** (recurrencia 31,
2026-09-03): se le explicó al dueño que el interruptor «Métodos de pago locales» de
la plataforma de la tienda era «solo el permiso de la plataforma» y que los métodos
había que activarlos a mano en su Stripe. La fuente de esa afirmación era el texto
de una fila del panel. Era falso: el interruptor escribe una configuración de
métodos en la cuenta conectada de Stripe — y la prueba la trajo **el dueño** con una
captura donde esa configuración figuraba actualizada a la hora exacta del clic. La
herramienta para saberlo estaba en la mano y no se usó: **antes de explicar qué
hace un control de un panel ajeno, clickealo con `manos.py --red` y leé la
llamada**. Lo que la UI *dice* que hace un botón es documentación, no evidencia.

**Y el corolario que costó plata: un ajuste apagado no da error, da menos.**
Una tienda estaba vendiendo con el checkout limitado a tarjeta porque ese
interruptor nació apagado y **no persiste sin «Guardar cambios»**. No había log, ni
alerta, ni síntoma: solo menos conversión. Los fallos silenciosos no se descubren,
se salen a buscar — por eso conviene un chequeo programado que compare el
**checkout publicado** de cada tienda contra la foto del estado bueno y falle
cerrado si no lo puede mirar.

**La descripción de un artefacto es un proxy del artefacto** (recurrencia 32,
2026-09-05, creativos en otro idioma). El índice del banco de b-roll describía un
clip con un detalle concreto del producto. Sobre esa línea —sin abrir el clip— se
le puso la etiqueta, se le escribió un guion sobre ese detalle y se le clavó como
plano de apertura. Mirándolo cuadro a cuadro **el detalle no está**: el plano
muestra otra cosa, y su último tercio es un tercer objeto.

Lo que lo hace distinto de las 31 anteriores: la descripción **no estaba mal
escrita para su propósito**. Se había escrito para *puntuar el gancho* —si el plano
es lindo y tiene movimiento—, no para decir qué producto hay en el cuadro. Un proxy
correcto para una pregunta es basura para otra. Por eso etiquetar el banco ahora es
una pasada propia que saca 3 fotogramas por clip y **se miran**.

El mismo día, la misma trampa dos veces más: el verificador del calce sumaba 0,25 s
y muestreaba el plano *siguiente* —acusando al motor de fallar cuando había elegido
bien—, y un script de subida a Drive contaba `[data-id]` del DOM, que incluye la
barra lateral, y reportó «pasó de 3 a 9 elementos» con 3 de 5 archivos subidos y
«[error] sigue en 21» con el archivo **ya subido**. Miente en las dos direcciones.

**Y la compuerta que la descarga** (2026-09-05): escribir «no confíes en la
descripción vieja» no alcanzó — el día que se escribió ya se había puesto la
etiqueta sobre la línea del índice sin abrir el clip. Ahora un clip sólo entra al
calce semántico si sus etiquetas llevan `verificado_mirando`, y **falla cerrada**:
sin sello queda afuera y el motor lo avisa por nombre (probado quitándole el sello a
un clip: los calces bajaron de 7 a 5 con el aviso explícito). Lo que no es máquina,
no es compuerta.

**Un código de falla único junta estados distintos, y la causa de uno se escribió
como si fuera la de los cuatro** (recurrencia 34, 2026-09-05, apex de las tiendas).
`curl https://apex/` devolvía `000` en los cuatro dominios propios, así que el
`000` se leyó como un diagnóstico y se le puso una sola causa: *«la plataforma de
la tienda rechaza el dominio pelado si el DNS está en el registrador»*. Esa causa
estaba medida en **un** dominio — el único que tenía el `@ ALIAS` puesto. Pidiendo
los mismos ápices por **HTTP pelado** aparecen dos estados que el `000` tapaba: uno
da **409 de Cloudflare** (el DNS ya está bien, el hostname nunca se activó), y los
otros tres dan **200 con la página estacionada del registrador** (se ve en el
`server:`) porque **siguen con el registro `A` por defecto**: a esos tres el apex
nunca se les apuntó a la tienda: les falta el paso que al primero ya se le dio.

Y la trampa gemela, que casi escribo en la misma vuelta: **separar dos estados no
es haber medido el segundo.** Estuve por anotar que a esos tres "se arreglan
borrando el `A`, gratis". No está probado — en el primero se borró y el apex quedó
igual sin certificado. Lo único que la medición autoriza a decir es que están en
otro estado y que la causa escrita no les fue medida; el pronóstico sigue siendo
pronóstico. Deshacer una sobre-generalización con otra en sentido contrario es el
mismo error con el signo cambiado.

Lo que lo hace distinto de las anteriores: acá el proxy no fue un indicador ajeno
sino **el propio código de error**, y el salto no fue creerle a un panel sino
**generalizar una causa medida en un caso a los otros tres sin volver a medirlos**.
Un `000`, un `500` o un timeout son estados de *fallo*, no causas: colapsan todo lo
que no llegó a hablar. La forma general: **cuando N cosas fallan con el mismo
código, mediste una vez, no N veces** — y la salida barata es bajar una capa
(HTTP pelado en vez de HTTPS, `server:` en vez del cuerpo) hasta que los casos
dejen de darte la misma respuesta.

## Recurrencia 35 — 2026-09-06: el artefacto DECLARA que está viejo y no lo leés

Auditoría de un panel de ventas propio contra Meta y la plataforma de la tienda. La
primera pasada dio todo perfecto: gasto y ventas cuadraban al centavo. **Eran
números del caché.** El freno compartido estaba activo (`code 17`, disparado por
mis propios refrescos) y la función de refresco devuelve el último documento
guardado en vez de pegarle a Meta. Coincidían de casualidad, porque el caché era de
minutos antes.

Lo importante: **el documento traía el campo `frenado` con el motivo y la hora**.
El panel avisaba. La pantalla lo muestra. Mi script de comparación no lo miraba.
No fue un proxy que engañó — fue un proxy que se declaró y nadie leyó la etiqueta.

**Regla: auditar un panel exige comprobar que no esté frenado (`frenado: null` o
equivalente) ANTES de comparar nada.**

### La otra cara, el mismo día: un vigía que confunde el CAMINO con el hecho

Un monitor que avisaba "venta nueva por webhook" reportó 30 ventas de golpe —
eran las 57 que yo acababa de **importar del export**. Preguntaba *"¿hay un
documento nuevo?"* cuando la pregunta era *"¿entró por el camino que estoy
probando?"*. La existencia del dato es un proxy de su procedencia. Se arregló
filtrando por `origen !== 'export'`, y cada documento se marca con de dónde vino.

## Recurrencia 36 — 2026-09-06: el arreglo se apoyó en el mismo dato torcido

`payload.created_at` de un webhook parece "cuándo pasó". **Es cuándo se emitió el
aviso.** En una orden real, la orden nació a una hora y el aviso `order.created`
salió 20 segundos después — o sea **después** del `order.approved`.

Lo caro no fue el bug: fue que **el arreglo del bug se apoyaba en el mismo campo
que lo causaba.** Ordenar los eventos "por el más nuevo" se sintió como la
solución correcta, funcionó dos veces seguidas por casualidad (esas dos veces el
aviso viejo sí traía timestamp viejo) y volvió a fallar a la tercera, dejando
otra venta cobrada en `pending`.

**Antes de ordenar por un timestamp ajeno, preguntate de qué es la hora**: del
hecho, de la emisión del aviso, del reintento, o de cuando lo recibiste. Son
cuatro relojes distintos y el proveedor rara vez dice cuál te está dando.

Cuando existe un orden SEMÁNTICO (un ciclo de vida: nace → se aprueba → se
devuelve), ése es el que hay que usar: no depende de ningún reloj. Acá se pasó a
comparar rangos de estado, y un estado desconocido falla cerrado.

## Recurrencia 37 — 2026-09-09: la maqueta que dibujo yo es un proxy de la pantalla que renderiza otro

Ocho pasadas iterando un upsell post-compra (OTO 1) de un producto propio sobre un
artifact mío que decía "así va a quedar". **Dibujaba la pantalla ENTERA a mi
manera** — barra roja, timer dorado, tarjeta de precio — cuando en la página real
**la mitad la pinta la plataforma de la tienda**: cabecera de orden, barra de
progreso, contador y bloque de precio, sobre fondo blanco. El dueño lo vio recién
cuando mandó capturas del panel: *"se ven recontra diferente a como me los enviaste
en el artifact"*.

**Lo caro no fue el estilo: fue el bug que la maqueta no podía mostrar.** El botón
decía `SÍ, LO QUIERO — US$ XX • US$ XX`, con el precio DOS VECES, porque la
plataforma le agrega el importe sola y mi etiqueta del botón ya traía `{price}`.
Por API el texto se leía perfecto. **Los bugs de una pieza que vive dentro de un
contenedor ajeno viven en la juntura**, y una maqueta que no dibuja la juntura no
puede mostrarlos: los 10 nodos de las 5 tiendas salieron con ese error.

Y una vuelta más: cuando quise probar si podía repintar el marco, la primera prueba
fue **solo el fondo negro** — si funcionaba, dejaba la cabecera oscura sobre oscuro,
peor que antes. Se revirtió en el acto y se probó con el CSS completo. **Una prueba
que, de funcionar, deja el sistema incoherente, no es una prueba: es un incidente
a medias.**

### Cómo evitar
- Si la pieza va a vivir dentro de una interfaz que no controlás, la maqueta
  **reproduce el contenedor** (cabecera, marcos, botones que pone el otro) o
  **declara arriba qué parte no es tuya**. Una maqueta "limpia" oculta la juntura.
- **Antes de replicar a N, mirá UNO renderizado de verdad.** El error del precio
  duplicado se vio en una captura, no en 10 lecturas por API.
- La prueba de un cambio visual va **completa**: si entra, tiene que dejar la
  pantalla coherente. Probar "solo el fondo" es diseñar el peor caso a propósito.
- Cuando no podés ver el render (acá la vista previa vive dentro de un editor que
  no responde a la automatización), **decilo y pedí los ojos** — el dueño lo miró
  en 10 segundos. Adivinar el aspecto y afirmarlo es el proxy otra vez.


## Recurrencia 38 — 2026-09-12: el resumen de la sesión es un proxy del archivo, y un error de transporte es un proxy del efecto

Las dos caras aparecieron en la misma carga —una tanda de creativos en inglés, 10
conjuntos nuevos en una campaña de testeo ABO— y las dos son el mismo error con
distinto signo.

**Cara A — el resumen de una sesión compactada no conserva literales.** La
conversación se compactó a mitad de la carga. En el resumen quedaron anotadas las
URLs del CDN de los 20 creativos. Al crear el último anuncio se retipeó una
desde ahí, y el UUID tenía **tres tramos distintos** del verdadero. Meta contestó
`Image Wasn't Downloaded` y se quemó una escritura contra un techo de 25 por hora
que ya venía ajustado. El manifiesto de subidas, que generó esas URLs, estuvo
en disco todo el tiempo.

La prosa conserva el **sentido**, no los **literales**. Y un identificador
equivocado en el medio no tiene cómo delatarse: no rompe la sintaxis, no se ve
raro, tiene el largo correcto. La única señal llega del otro lado, cuando ya
gastaste la llamada.

**Regla: un identificador que existe en un archivo se LEE del archivo.** UUIDs,
URLs, ids de cuenta, hashes, rutas. El resumen sirve para saber *qué archivo*
mirar, nunca para saber *qué valor* tiene. Vale igual para HOT.md, para una nota
del vault citada de memoria y para lo que te pasó otra ventana por la pizarra.

**Cara B — un error de transporte no dice si la escritura entró.** Creando otro
anuncio, la llamada volvió con `Anthropic Proxy: Invalid content from server`. Eso
es el canal, no la cuenta: el POST pudo haber llegado igual. Antes de reintentar se
pidió la lista de anuncios del conjunto — no había entrado ninguno, así que el
reintento era seguro. **Si hubiera entrado, el reintento a ciegas dejaba un anuncio
duplicado, y en un test ABO un duplicado le dobla en silencio la porción de
presupuesto a ese creativo y arruina la lectura del test.** No falla ruidosamente:
falla midiendo mal.

Y Meta contesta sola si conviene reintentar, en el campo `is_retryable`: el
`INTERNAL` («An internal error occurred») vino con `true` y entró al segundo
intento; el `VALIDATION` de la imagen vino con `false`, y ahí reintentar es tirar
escrituras contra el techo sin cambiar nada. Se lee el campo, no se adivina.

### Señal de detección
- Estás por pegar un id, una URL o un hash que leíste **en el resumen de la
  sesión, en HOT.md o en la pizarra** → detente: abrí el archivo que lo generó.
- Una escritura volvió con error de **transporte** (proxy, timeout, conexión) →
  detente: leé el estado antes de reintentar. Error no es "no pasó".

## Recurrencia 40 — 2026-09-18: el comando con el que ibas a MEDIR nunca se probó contra un caso que debe fallar

Iba a entregarle a un alumno, dentro de un instructivo, el comando que cuenta las
notas sin frontmatter:

    grep -rLx -- "---" --include="*.md" CARPETA | wc -l

Dos fallas, y la segunda es la peligrosa:
1. En el `grep` de macOS, el `--` hace que `--include` se lea como nombre de
   archivo: tira `No such file or directory` **y además imprime un número**. Un
   error que igual devuelve un resultado no parece un error.
2. Aun con la sintaxis corregida, `grep -L` busca el patrón en **todo** el archivo:
   una nota **sin** frontmatter que tenga un `---` más abajo (un separador, una
   línea de guiones) **no se detecta**. Probado fabricando el caso: reporta cero
   notas sin frontmatter con una nota sin frontmatter adelante.

Lo correcto es exigir la PRIMERA línea, que es lo que la regla dice de verdad:

    find CARPETA -name "*.md" -exec sh -c 'head -1 "$1" | grep -qx -- "---" || echo "$1"' _ {} \; | wc -l

Lo que generaliza: **un comando de medición es un guardián**, y un guardián que
nunca falló está sin estrenar. Antes de usar un conteo como evidencia —y mucho más
antes de entregarlo— hay que **fabricar el caso que TIENE que atrapar** y ver si lo
atrapa. El número salió igual en las dos versiones (cero) sobre el vault real: si
no hubiera fabricado la nota rota, las dos parecían correctas.

### Señal de detección
- Vas a usar un comando para **contar** algo y decidir con ese número, o a
  entregarlo dentro de un instructivo → detente: fabricá un caso que deba salir en
  el conteo y confirmá que sale. Un cero sobre datos sanos no prueba nada.

## Recurrencia 41 — 2026-10-03 (relanzamiento de una tienda propia en otro idioma)
Tanda de 20 creativos: revisé las piezas en una hoja de contacto de 430 px por pieza y subí a Drive. A tamaño real el dueño vio lo que la miniatura tapaba: manchas oscuras que mi propio retoque automático (la limpieza de un reflejo verde) había pintado sobre el fondo de la escena, y el texto de las cartas pegado al filete. La hoja de contacto es un proxy: sirve para comparar la tanda, no para aprobar una pieza.

Regla: todo retoque automático se mira a tamaño real en TODAS las piezas que toca, y de cada carta se mira el recorte ampliado, antes de subir. Si el retoque depende de un color (verde), buscar en la tanda la escena que tenga ese color de verdad (plantas, agua): ahí es donde rompe.

- **2026-10-04 (recurrencia 42)**: la landing inglesa de una tienda propia se dio por verificada con 200, barrido de palabras y precios leídos del HTML; el defecto visual (las horas en formato de 12 partidas en dos renglones) apareció recién cuando el dueño preguntó «¿se ve bien?» y se abrió la página publicada en tamaño celular. Compuerta: todo lanzamiento de idioma termina con una captura de la página publicada en tamaño celular, y se mira.

- **2026-10-31 (recurrencia 44)**: relanzando una tienda le pedí al dueño entrar al panel del registrador con otra cuenta porque una memoria decía que un dominio vivía ahí. Vivía en la cuenta donde ya estaba adentro: la API del portafolio lo decía en un segundo y fue el dueño quien preguntó. Una nota sobre DÓNDE vive un activo es un proxy del panel: antes de pedir un login, un permiso o un humano, se mira en vivo. Mismo día: el script de subida y la captura daban la entrega por buena, pero los 3 bonus seguían apuntando a la carpeta de otro idioma por un arreglo «provisorio» de dos días antes; un provisorio no vence solo, se barre a dónde apuntan los enlaces antes de relanzar.
