---
type: leccion
created: 2026-07-28
tags: [cerebro-ia]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 5
validada: 2026-11-08
moc: "moc-landings-y-ofertas"
aliases: ["Cero resultados no es no existe", "Probar dos entradas antes de declarar imposible", "La pagina que carga vacia no es una fuente que calla"]
---

# Cero resultados dice que tu consulta no matcheó, no que el dato no existe

## Punto clave
Una búsqueda en cero, una página que carga vacía o una herramienta que no devuelve
nada prueban que **tu consulta no encontró**, no que el dato no exista. Antes de
escribir «no se puede» o «no existe», o de pedirle un acceso al dueño: otra entrada
al mismo dato, reintentar la misma, romper la cache y comparar contra un hermano que
sí aparece.

## Qué pasó
El 2026-07-28, buscando los anuncios de Kinesiología Resuelta en la Biblioteca de
Meta: se buscó por nombre de producto (0 resultados) y por la fórmula del titular
en español (0 resultados). Se concluyó que **"la plataforma de la tienda agrupa
cientos de anuncios y la búsqueda por texto no los aísla"**, se escribió eso como
límite de la fuente, y **se le pidió al dueño que se logueara en Facebook** para ir
por el navegador.

El operador apareció dos minutos después buscando por el **espejo en inglés** del
titular, bajo una página que se llama distinto que el producto, con 57 anuncios
activos en siete nichos. **El acceso que se le pidió no hacía falta para eso.**

## Por qué pasó
La API busca solo dentro del texto del creativo. Cero resultados significa *"tu
consulta no matcheó"*, nunca *"no hay"*. Se confundió el **límite de la
herramienta** con una propiedad del mundo — el mismo error de razonamiento que
[[2026-07-28-ofertas-ausencia-no-es-oportunidad]], pero aplicado a una herramienta
en vez de a un mercado.

Y hay un agravante: se le pidió al dueño un permiso (loguearse) antes de agotar las
vías que no lo necesitaban. Pedir acceso es barato para el que pide y caro para el
que lo da.

## Cómo evitar
- Antes de declarar que algo no se puede: **probar al menos dos entradas distintas
  al mismo dato**. Acá eran el nombre del producto y el idioma espejado; también
  servían el dominio, el nombre del operador y el nicho.
- **Nunca pedir un permiso o un acceso hasta haber agotado lo que no lo necesita.**
  Si igual hace falta, decir qué se probó antes.
- Cuando una fuente devuelve vacío, escribir en el reporte **qué se consultó
  exactamente**, para que se vea si el hueco es del mundo o de la consulta.

## Recurrencia 2 (2026-08-11): la página que carga VACÍA es el mismo error
Investigando la fase de aprendizaje de Meta, `ojos.py ver` devolvió vacío sobre la
página oficial de la zona horaria de la cuenta publicitaria. Se tomó ese vacío como
final: se citó un fragmento de buscador, se dejó un asterisco de "no la pude abrir
renderizada" y se entregó el documento **con el hueco en el centro del entregable**
— justo el dato que más se necesitaba (la zona horaria por defecto de toda cuenta
nueva es **Pacífico**, y de ahí sale todo el folclore de "los horarios nativos").

Apareció horas después probando la misma URL con el parámetro `?id=`. Y al testear
el arreglo se descubrió algo peor: **la URL pelada también funcionaba.** El vacío
había sido transitorio. Dos pasadas fallidas y una tercera idéntica que salió entera.

Dos agravantes propios de este caso:
- **Declarar la limitación tranquiliza.** El asterisco en la lista de fuentes dio
  sensación de estar cubierto. No lo estaba: declarar un hueco no es lo mismo que
  cerrarlo, y "Meta no lo dice" y "no pude abrir la página" son afirmaciones
  distintas que no se pueden entregar como si fueran la misma.
- **Una pasada no es evidencia.** Render lento, página vacía y dato inexistente se
  ven exactamente igual desde afuera.

### Dónde quedó aplicado (mecánico, no de memoria)
`ojos.py` ya no reporta los dos fracasos con el mismo mensaje. Ahora distingue
"ningún target matcheó" de **"LA PÁGINA CARGÓ PERO NO RENDERIZÓ TEXTO"**, lista las
URLs que sí matchearon, y exige nombrar cuál de las vías alternativas se probó
—empezando por reintentar la misma URL— antes de escribir "la fuente no lo dice".
Probado en las dos direcciones: grita con `about:blank`, se calla con una página sana.

## Señal de detección
Una búsqueda dio cero, **una página cargó vacía**, o una herramienta devolvió nada, y
estás por escribir "no se puede", "no existe", "X no publica eso" o por pedirle un
acceso al dueño → detente: ¿probaste otra entrada al mismo dato, **y reintentaste la
misma al menos una vez**? Nombrá las que probaste antes de concluir. Y si igual
entregás con el hueco, el hueco no puede estar en el centro de lo que te pidieron.


## Recurrencia 3 (2026-09-09): la pantalla que no se DIBUJA devuelve cero igual

Montando un upsell post-compra había que borrar cuatro nodos del mapa de un funnel
en el panel de la plataforma de la tienda. El mapa es un canvas (React Flow).

`manos.py js --url <mapa> --espera 24` devolvió **«no hay nodos»**. Cinco pasadas,
cinco veces lo mismo, sin un solo error. Con 24 segundos de espera la conclusión
parecía obvia: el funnel se quedó sin nodos. Los seis estaban ahí — `ojos.py ver`
los leyó enteros a la primera.

**La única diferencia entre las dos herramientas: ojos.py hace `Page.bringToFront`.**
El navegador no pinta las pestañas de fondo, y lo que no se pinta no tiene DOM. El
selector no falló: devolvió honestamente la lista vacía de una pantalla que no
existía todavía.

Y cinco repeticiones idénticas se sintieron como evidencia acumulada. No lo eran:
era el mismo error corriendo cinco veces.

**La compuerta**: hacer `bringToFront`, esperar y evaluar con `awaitPromise`. En la
práctica alcanza el orden **`ojos.py ver --url` primero, `manos.py` después**, sobre
esa misma pestaña.

Tres primos del mismo error, los tres pagados en esa sesión:

- **Un `--buscar` corto engancha la pestaña equivocada cuando dos rutas comparten
  prefijo.** El mapa (`…/post-compra/<funnel>`) y el editor de una oferta
  (`…/post-compra/<funnel>/offer/<id>`) comparten el id del funnel. Filtrar por el
  id más profundo, y dejar **una sola pestaña** abierta antes de una tanda.
- **Entrar por URL directa a una sub-vista carga la página vacía**: el estado lo
  pone la vista padre, así que hay que llegar por clic.
- **Un JS async largo revienta el timeout del websocket habiendo ejecutado igual.**
  Leerlo como «falló» y reintentar es cómo se duplican widgets. Ante un timeout:
  ir a MIRAR el estado, nunca reintentar a ciegas.

Y el primo más peligroso de todos, el mismo día y en el mismo panel: cuando el
vacío no lo devuelve una herramienta sino **la pantalla misma**. Con una tienda
activa en el panel, la URL de otra tienda contestó «Todavía no tenés funnels» y
el funnel estaba entero
(recurrencia 6: el panel sirve la tienda activa, no la de la URL). Un dato raro te frena; un cero te confirma lo que ya pensabas.

## Recurrencia 4 (2026-09-09): lo que no aparece puede estar CACHEADO, no ausente

Creé un producto nuevo como tercer upsell en una tienda, abrí el checkout público
y **no estaba**. Con el contador del plan diciendo `Agregar upsell (3/3)` a la
vista, la explicación se armó sola: *tope del plan alcanzado*. Estuve a una línea
de escribirle al dueño que necesitaba pagar un addon del plan.

Antes de afirmarlo comparé el registro nuevo contra uno que SÍ se mostraba: campo por
campo, idénticos. Ahí el "no aparece" dejó de cerrar. **Abrí el mismo checkout con
`?nc=<timestamp>` y el producto estaba.** Era la cache del storefront.

**La trampa fina**: el cupo `3/3` NO contaba uno de los productos (estaba marcado
como solo post-compra), así que el número era verdadero y la conclusión falsa. Un
dato correcto al lado de una ausencia arma una historia muy convincente.

### Señal de detección
Vas a explicar por qué algo **no aparece** en una superficie pública (tienda,
checkout, landing, CDN) y tenés a mano una razón plausible (límite de plan, permiso,
feature). **Rompé la cache primero**: `?nc=<epoch>`, recarga dura, o pedí el recurso
por otra vía. Y comparalo contra un hermano que SÍ se ve: si los dos registros son
iguales, el problema no es el registro.


## Recurrencia 4 bis — 2026-09-22, el upsell que "no existía"

Auditando la entrega de 4 tiendas en distintos idiomas, reporté que a una le faltaba
un upsell: probé **seis** variantes del slug traducido desde el nombre que tenía en
las otras tiendas y las seis dieron 404. Escribí "no existe en esta tienda".

Existía, con otro nombre: en ese idioma el título se había adaptado («de cero a
cien» en vez de «de cero a mil»). Apareció solo al abrir la página de entrega de un
comprador real, que lo listaba entre sus productos.

**El inventario de una tienda no se adivina traduciendo el nombre de otra.** Sale
del panel, o de la entrega de una orden real. Seis 404 seguidos no son evidencia de
ausencia: son seis nombres mal adivinados.

## Recurrencia 5 (2026-11-08): sin `bringToFront`, el clic por coordenadas cae en la nada
Trabajando en segundo plano a pedido del dueño («no me muevas las pantallas»): pestañas con
`Target.createTarget {"background": true}` y **nunca** `Page.bringToFront`. Eso deja sin efecto la
compuerta de arriba para Meta. Al apelar un anuncio en Calidad de la cuenta (business-support-home)
desde una pestaña de fondo, el clic por coordenadas en «Tomar medidas» no abrió nada tres veces:
la pestaña no se dibuja, `scrollIntoView` no mueve lo que se ve y la captura sale vieja. La rueda
del mouse por CDP colgó el websocket.
**Lo que funcionó:** `elemento.click()` por JS sobre el botón, y después leer el `[role=dialog]`.
**Trampa del mismo día:** subir 6 niveles desde la celda del id agarró la tabla entera y abrió el
anuncio de OTRO mercado. Se cerró sin tocar. La fila se acota subiendo hasta que contenga
**exactamente un** id de anuncio, y antes de cada botón se confirma que el diálogo nombra ese id.
