---
type: leccion
created: 2026-07-28
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 6
validada: 2026-08-23
moc: "moc-landings-y-ofertas"
aliases: ["Nombrar el mercado destino", "Adaptar material entre mercados"]
---

# Si no nombrás el mercado destino, el modelo lo rellena con su default

## Punto clave
Al adaptar, traducir o re-nichar material, nombrá el destino con tres datos: nicho
concreto, ticket y modelo de compra. «Productos digitales» es el formato, no el
mercado. Y el idioma también viaja horneado en las imágenes: cada imagen se abre y
se lee; el nombre o el sufijo del archivo no cuentan como evidencia.

## Qué pasó
La investigación de mercado que se enseña en el programa se armó traduciendo una
investigación de **ecommerce físico de un mentor de Estados Unidos**. Se le pidió a
la IA que la adaptara a "productos digitales", sin especificar a qué mercado, y la
resolvió como **mentorías mid/high ticket**: el avatar quedó siendo un emprendedor
cansado de los gurús que compró diez cursos.

No fue un problema de ejemplos: quedaron mal **las preguntas**. Nunca preguntó
por qué alguien pagaría por algo que está gratis (el mecanismo único en low
ticket) ni qué quiere inmediatamente después de comprar (el bump y el upsell, o
sea el AOV). Faltaban las dos preguntas que definen el negocio. El material
circuló seis meses así, y arrastró el error a las plantillas de Avatar y Offer
Brief que los alumnos copian.

## Por qué pasó
**"Productos digitales" nombra el formato de entrega, no el mercado.** El nicho
real es quesos veganos, carpintería, crochet; lo digital es solo cómo llega la
solución. Ante un destino ambiguo el modelo no pregunta: completa con el prior
dominante de su entrenamiento, que en español es el espacio make-money-online.

Y el error es silencioso. La salida se ve bien redactada, coherente y con
formato de investigación seria, así que no dispara ninguna alarma. Se detecta
recién cuando alguien la lee contra un producto real.

## Cómo evitar
- Al adaptar, traducir o "ajustar" material de un mercado a otro, **nombrar el
  destino con tres datos**: nicho concreto, ticket y modelo de compra. Por
  ejemplo: "low ticket, 9-27 €, compra por impulso, sin llamada de venta".
- Distinguir siempre **formato** de **mercado**. Si el mercado que se declara es
  el formato, todavía no se declaró el mercado.
- **Test rápido de contaminación** sobre la salida: buscar vocabulario del
  mercado equivocado. Si aparecen "emprendedor", "escalar", "algoritmo", "gurú"
  o "libertad financiera" sin que el nicho lo justifique, se fue de mercado y hay
  que rehacerlo, no parcharlo.
- El mismo cuidado vale al re-nichar una oferta ganadora: cambiar el titular sin
  cambiar dolores, objeciones y bonus deja el material anclado al mercado viejo.

## Recurrencia 2 — 2026-08-03: el prior también se cuela en el REGISTRO
Al re-estructurar la landing de un producto propio sobre el molde de 13 bloques,
escribí todo el copy nuevo **en voseo**. La tienda vende en español neutro: sus
testimonios son de Guadalajara, Bogotá, Santiago y Lima, y su copy actual dice
"Haz tus propios…", no "hacé". Lo agarró la compuerta de registro de
`/evaluar-landing` recién al final, con la maqueta ya escrita.

Mismo mecanismo, capa distinta: nadie nombró el mercado, así que rellené con mi
prior — en este caso, que el dueño es argentino. **El dato estaba en el material
que tenía adelante**: el registro del copy existente y el origen de los
testimonios. No hacía falta preguntar, hacía falta leer.

Corolario práctico: la regla "voseo en ES/LATAM" de `evaluar-landing` es un
default, no una ley. Una tienda pan-LATAM va en neutro, y eso se decide leyendo
la tienda, no el pasaporte del dueño.

## Señal de detección
Estás por pedirle a un modelo que adapte, traduzca o re-niche material de un
mercado a otro → detente: ¿nombraste el mercado destino con nicho, ticket y
modelo de compra, o solo dijiste el formato? Si solo dijiste el formato, lo que
vuelve es el prior del modelo con apariencia de trabajo propio.

Y si vas a escribir copy nuevo para una tienda que YA existe → el registro
(voseo / neutro), el vocabulario y el tono salen del copy publicado y del origen
de los testimonios, no de dónde vive el dueño.

## Recurrencia 3 — 2026-08-05: el idioma también viene HORNEADO en las imágenes
Llevando la landing de un producto propio a otro idioma, el mapa de
transcreación cerró limpio y el guardián de idioma dio cero restos de español en el
texto. La landing igual estaba mal, y no se veía en el código: **el mockup del
producto, las 10 tapas de bonus y la foto del hero llevan el nombre del producto,
la cantidad de contenido («+80 …») y el título del bonus impresos EN EL PÍXEL**, en
español.

El HTML no lo dice. El `data-pieza` dice `bonus-1.png` y parece una pieza
neutra. Se descubre **abriendo el archivo**, o mirando el artifact publicado —
que fue como apareció: el hero se veía con el libro en español en el medio,
después de que yo lo hubiera declarado "fotografía sin texto, se reusa".

Efecto sobre el trabajo: el inventario de imágenes pasó de **12 a generar a 24**.
Si no se detecta, se publica una landing en otro idioma con once tapas en español.

Mismo mecanismo que las dos veces anteriores —dar por buena una capa que no se
inspeccionó— pero en un plano nuevo: no es el copy ni el registro, es el
BINARIO. Es [[2026-07-27-cerebro-ia-el-proxy-miente]] aplicado a imágenes: el
nombre del archivo es un proxy de su contenido.

### Cómo evitarlo
Al llevar una oferta a otro idioma, **clasificar cada imagen abriéndola**, no
leyendo el código:
- **fotografía sin texto** → se reusa tal cual (acá: las 8 del carrusel);
- **lleva texto impreso** → se regenera en el idioma destino (acá: mockup,
  hero, 10 bonus, 6 tapas, 5 fichas, sello);
- **lleva marca de terceros** → no se publica hasta que alguien decida (acá
  apareció un logo ajeno estampado en una foto del carrusel, heredado del
  original).

## Recurrencia 4 — 2026-08-10: el sufijo `_IT` es otro proxy que miente

La misma oferta llevada al mercado italiano. Esta vez las tapas **sí** estaban
regeneradas en el idioma destino: nueve de diez archivos tenían sufijo `_IT` en el
CDN. El inventario se veía cerrado.

Abriéndolas una por una aparecieron **cinco rotas**, todas imposibles de ver en el
HTML:

- `BONO 3` — **español** impreso en la faja, en una tapa por lo demás italiana.
- Un sello en **inglés**, y encima con un tema que no correspondía al de la tapa.
- Dos títulos del tipo «guida completa a <tema>» — sin la preposición articulada,
  agramaticales. La plantilla del generador calcaba el español *"guía completa
  a…"*.
- Un apóstrofo suelto en medio de una frase.

**El giro nuevo:** en la recurrencia 3 la trampa era que la imagen parecía
neutra (`bonus-1.png`). Acá era peor, porque el nombre del archivo **afirmaba
el trabajo hecho**: `Bonus4_<Tema>_IT.png` dice idioma, dice número de bonus y
dice tema. Un sufijo de idioma es una declaración de quien la subió, no una
verificación — y es más peligroso que un nombre neutro, porque desactiva la
sospecha en vez de despertarla.

De yapa, los nombres estaban **cruzados** con el contenido: la tapa que se usa
como Bonus 1 se llamaba `Bonus3_..._IT.png` y decía el título de otro bonus.
Guiarse por el nombre para decidir cuál regenerar habría regenerado las
equivocadas.

### Regla que queda
Al auditar imágenes de una oferta traducida, **el sufijo de idioma no cuenta
como evidencia**. Se abren todas igual, y el inventario se arma por lo que dice
la tapa, nunca por lo que dice el archivo. Bajarlas y mirarlas cuesta dos
minutos; publicar una tapa que dice "BONO" en un mercado italiano cuesta la
credibilidad de toda la página.

En la misma tanda, el mockup del hero prometía un video que el producto no tiene.


## Recurrencia 6 — 2026-08-23, las tapas en un tercer idioma

Migrando la oferta a un tercer idioma en la plataforma de la tienda, las **diez
portadas de los bonos seguían en italiano**: se heredaron de la landing italiana y
nunca se regeneraron. El copy alrededor estaba impecable —términos de oficio,
modismos, testimonios con concordancia de género— y aun así la oferta se delataba
en el bloque que vende el stack. El texto viaja; el píxel no.

**Dos giros nuevos de esta vuelta:**

- **El modelo no solo desobedece: inventa afirmaciones de negocio.** Una tapa
  regenerada agregó por su cuenta un «desde <año>» bajo el logo — una fecha de
  fundación que nadie pidió y que no es cierta. No alcanza con auditar el
  idioma: hay que leer **lo que la imagen AFIRMA** y cotejarlo contra el negocio
  real. Otra volvió con una palabra del idioma anterior intacta en la caligrafía,
  invisible en un vistazo rápido.
- **El proveedor se elige probando una pieza, no leyendo su descripción.** Se
  probó la misma tapa en dos modelos antes de lanzar la tanda: el que se vende
  como *"best text rendering"* fue el que deformó el diseño y escribió una palabra
  con faltas. Cuatro créditos de prueba evitaron rehacer diez piezas.
