---
type: leccion
created: 2026-07-28
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 1
validada: 2026-07-28
moc: "moc-landings-y-ofertas"
aliases: ["Ausencia de evidencia no es evidencia de oportunidad", "El hueco en la Biblioteca suele ser un cementerio"]
---

# Un ángulo que no aparece en la Biblioteca no está libre: lo más probable es que ya lo hayan matado

## Punto clave
La Biblioteca de Anuncios muestra lo que corre hoy, no lo que se probó y fracasó.
En un nicho con muchos anunciantes activos, un ángulo ausente es más probablemente
un cementerio que una oportunidad. Lo validado funda la oferta; el hueco, como
mucho, se testea barato y aparte.

## Qué pasó
El 2026-07-28, barriendo la Biblioteca de Anuncios para una oferta de IA para una
profesión regulada: 97 anunciantes activos, y de los 40 anuncios leídos **ninguno**
mencionaba riesgo profesional, matrícula ni responsabilidad. De ahí se concluyó
"el territorio está vacío, ése es el ángulo" y se fundó toda la oferta encima
—promesa, estructura, nombre, bonos— descartando la promesa de la referencia
validada.

El dueño lo rechazó de una: *"las investigaciones de mercado terminan siendo una
hipótesis; lo validado es una validación"*. La promesa que terminó eligiendo es
casi textual la de una referencia de un nicho vecino que ya estaba corriendo.

## Por qué pasó
La Biblioteca muestra **lo que está corriendo hoy**, no lo que se probó y se
descartó. Un anuncio que no funcionó se apaga y desaparece del barrido. Así que
un hueco grande en un nicho con 97 anunciantes activos y muchos meses de
historia es más probable que sea un cementerio que una playa vacía: si el
ángulo fuera obvio y rentable, con esa densidad de operadores alguien ya lo
estaría corriendo.

Es exactamente el reverso de la regla de 3 anunciantes, que ya usamos para lo
que **sí** aparece. La regla se venía aplicando en una sola dirección.

## Cómo evitar
- **Jerarquía de evidencia, de más fuerte a más débil:** ángulo presente en 3+
  anunciantes con días activos → ángulo presente en 1-2 → ángulo ausente. El
  ausente es el más débil de los tres, no el más prometedor.
- **Un ángulo ausente nunca funda la oferta principal.** Se puede testear
  barato y aparte (una E1 express, presupuesto chico), jamás construir encima
  la promesa, el nombre y el producto entero.
- **Antes de declarar un hueco, preguntarse por qué está vacío.** ¿Nadie lo
  pensó, o el mercado lo rechazó? Si el nicho tiene decenas de operadores
  activos, la segunda es la apuesta razonable.
- Cruza con [[angulos-ocupados-se-leen-en-los-anuncios]]: los anuncios dicen lo
  que compran. El silencio no dice lo contrario.

## Señal de detección
Estás por decir "nadie está usando este ángulo, ahí está la oportunidad" →
detente: la Biblioteca no muestra lo que fracasó. Contá cuántos anunciantes
activos tiene el nicho: cuantos más, más probable que el hueco sea un
cementerio.
