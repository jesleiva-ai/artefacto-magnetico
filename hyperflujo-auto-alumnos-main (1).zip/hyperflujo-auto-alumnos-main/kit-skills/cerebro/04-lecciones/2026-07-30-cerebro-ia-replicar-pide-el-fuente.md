---
type: leccion
created: 2026-07-30
tags: [cerebro-ia]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 2
validada: 2026-07-30
moc: "moc-landings-y-ofertas"
aliases: ["Replicar pide el fuente", "Calcar no es acordarse", "El diff de tokens como prueba"]
---

# Si el pedido es "replicá esta pieza", el insumo es su fuente — y la prueba es un diff

## Punto clave
Replicar una pieza exige su fuente en disco, no el copy más una captura. Se extraen
los tokens (colores, tipografías, pesos, radios, sombras) a un archivo y el
entregable se valida como DIFF: «estos N valores cambiaron, el resto quedó igual».
Si no podés mostrar esa tabla, reinterpretaste.

## Qué pasó
El 2026-07-30 el dueño pidió la landing de un conocido con la paleta cambiada:
"solamente te pedí que cambies la paleta de colores, nada más". Se entregó otra
cosa — el orden de bloques de esa landing vestido con un sistema visual propio.
Tuvo que rechazarla y preguntar por qué.

Lo que había en mano al momento de producir: el **copy**, sacado con
`ojos.py ver`, y **una** captura de su hero vista a través del marco del visor de
artifacts. Con eso se reconstruyó una impresión y se la llamó "misma estructura".

El fuente estaba a un `curl` de distancia. El contenido de un artifact se pinta en
un iframe de otro origen (`<uuid>.frame.claudeusercontent.com/_f/<token>/`) que
responde sin cookies cuando la pieza es ajena. Al bajarlo aparecieron 112 KB con
todo lo que faltaba: Inter 900 con `letter-spacing:-2.4px`, el titular a dos tonos
donde la línea 2 es un `<span>` de color, tres tokens de sombra nombrados, radios
de 14/18/20/24, botón de 60px con animación de respiración, y un comentario del
propio autor declarando que él también había calcado tokens de una referencia
medida y comprimido el hero para cerrar antes del pliegue.

## Por qué pasó
Se confundió **tener el contenido** con **tener la pieza**. El copy es la capa más
barata de extraer y la que menos explica por qué una landing se ve bien: lo que
hace que "esté buenísima" vive en la escala tipográfica, los pesos, el
letter-spacing, los radios, las sombras y la anatomía de cada componente — y nada
de eso está en el texto.

El error de segundo orden fue creer que ya se tenía el insumo y dejar de buscar.
Tres veces se produjo desde la impresión antes de ir al fuente.

Distinto de «leer el cerebro primero»: ahí el reclamo es leer
**nuestra** nota sobre la referencia antes de producir, y eso sí se hizo. Acá
faltaba **la pieza ajena misma**. Y distinto de
[[2026-07-27-cerebro-ia-el-proxy-miente]]: eso cubre verificar que algo funcionó,
no conseguir el material con el que se produce.

## Cómo evitar
- **El fuente antes de la primera línea de código.** Artifact ajeno:
  `herramientas/fuente-artifact.sh <url>`. Artifact propio: devuelve 403 porque
  su frame lleva token de sesión — ahí va `ojos.py ver`. Página pública: `curl` +
  el CSS enlazado.
- **Extraer los tokens a un archivo** antes de producir: colores en HSL,
  tipografías con sus pesos, escala de tamaños, radios, sombras, breakpoints.
- **El entregable se valida como DIFF contra ese archivo**: "estos 9 valores
  cambiaron, todo lo demás quedó igual". Si no se puede mostrar esa tabla, no hubo
  calco: hubo reinterpretación. La tabla va en la entrega, no en la cabeza.
- **Medir el render, no sólo el CSS.** En una referencia la variable se llamaba
  `--primary` y valía oro, pero el botón que cobra era verde. El nombre de la
  variable no es el rol que cumple en pantalla — `herramientas/paleta.py`
  muestrea píxeles y devuelve las familias de tono reales.
- Vale para cualquier pieza que se pida replicar, no sólo landings: anuncios,
  estructuras de oferta, secuencias.

## Señal de detección
Estás por escribir "misma estructura", "calcado" o "modelado sobre X" → detente:
¿tenés el fuente en disco, o una impresión formada con el texto y una captura?
Si no podés poner al lado la tabla de qué cambió y qué no, todavía no lo calcaste.

Corolario: si en un pedido de réplica llevás dos entregas rechazadas, el problema
no es el criterio — es que estás produciendo sin el insumo.

## Recurrencia 2 — 2026-08-18 · las tapas en un idioma nuevo

El dueño pidió los mockups «iguales a los otros idiomas, pero en <idioma nuevo>».
Se escribió un prompt maestro describiendo el estilo **de memoria**, se generaron
21 imágenes y salieron distintas. Su corrección fue literal: *«los estás
haciendo diferente a la oferta original… andá a revisar la oferta en inglés o
en italiano y fijate cómo son esos mock-ups»*.

Al bajarlas y **abrirlas una por una** apareció algo que ninguna descripción
habría dado: **cada bonus nuevo tiene su tapa equivalente en otro idioma, 1 a 1,
del mismo tema**. Con eso el prompt dejó de describir un estilo y pasó a decir
«te adjunto esta tapa, cambiá el idioma» — que sale igual porque **es** la
misma. Estaban a un `curl` de distancia, en el CDN de la tienda hermana.

**Lo que agrega esta recurrencia:** el fuente no es solo para copiar bien. Es
para **descubrir la estructura que hace innecesaria la descripción**. Buscá el
mapeo 1:1 con lo que ya existe antes de escribir una sola línea de estilo.
