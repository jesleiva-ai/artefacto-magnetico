---
type: leccion
created: 2026-08-03
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 1
validada: 2026-08-03
moc: "moc-landings-y-ofertas"
aliases: ["Separar por canal de venta", "Web y WhatsApp son dos mercados", "El informe de ofertas se parte en dos columnas"]
---

# Un informe de ofertas que mezcla venta por web y venta por WhatsApp no se puede usar para decidir

## Punto clave
Todo informe de ofertas que escalan sale partido en dos bloques —venta por web y
venta por WhatsApp/DM—, buscando en los dos por igual. El canal se lee en el destino
del anuncio, no se supone; si un bloque queda vacío, se declara. Mezclarlos en una
sola lista ordenada por días compara cosas que no se comparan.

## Qué pasó
El 2026-08-03, en la investigación de un nicho de belleza low ticket, se entregó
una tabla de ocho anunciantes "que escalan" ordenada por días activos. Adentro
convivían cosas que no se comparan:

- **Dos academias de belleza** venden en su propia tienda Shopify, con checkout,
  order bump y upsell post-compra.
- **Un anunciante de cosmetología** (249 días) y **uno de cursos de uñas** (164
  días) corren `Chatea con nosotros` → todo el cierre pasa por WhatsApp, a mano.

El dueño lo marcó: *"contemplaste muchas que se hacen en venta por WhatsApp. No me
parece mal, pero está bueno que me des de forma equitativa siempre ofertas que
estén escaladas en venta por página web —ya sea Shopify u otra plataforma— o por
WhatsApp"*.

## Por qué pasó
Los días activos miden **que la oferta devuelve**, no **cómo la cobra**. Pero el
canal cambia todo lo que viene después de elegirla:

| | Web | WhatsApp |
|---|---|---|
| Escala | sin techo humano | tope: alguien contesta |
| AOV | bump + upsell + post-compra automáticos | lo que el vendedor sepa ofrecer |
| Qué se puede modelar | la landing entera, medible | solo el anuncio; el cierre es invisible |
| Precio típico | más bajo, compra impulsiva | más alto, aguanta conversación |

Una oferta de WhatsApp con 249 días no prueba que la misma oferta funcione en
una landing: prueba que hay demanda y que **alguien la está cerrando a mano**.
Modelarla como si fuera web es cambiarle el motor sin avisar.

Y al revés: descartar las de WhatsApp también es un error. Muestran demanda real
y muchas veces precio más alto. Lo que no se puede es **mezclarlas en una sola
lista ordenada**, porque el número de días termina comparando peras con manzanas.

## Cómo evitar
- **Todo informe de ofertas sale partido en dos bloques**: «venta por web» y
  «venta por WhatsApp/DM». Nunca una sola tabla ordenada por días.
- **Buscar activamente en los dos.** Si un bloque queda vacío, decirlo
  explícitamente — «no encontré ninguna de web con ≥10 anuncios» es un hallazgo,
  no un bloque que se omite en silencio.
- **Cómo se determina el canal**, en orden de confianza:
  1. El destino del anuncio en la Biblioteca: `api.whatsapp.com`, `wa.me` o el
     botón «Chatea con nosotros» / «Envíanos un mensaje» → WhatsApp.
     Un dominio propio → web. `instagram.com` → DM, cuenta como WhatsApp.
  2. Si el destino es un dominio, abrirlo y confirmar que hay checkout y no un
     botón de WhatsApp disfrazado de landing.
- **La recomendación final dice de qué canal es.** Y si se recomienda una de
  WhatsApp para llevarla a web, eso se declara como el cambio de modelo que es.
- Cruza con [[2026-07-28-ofertas-ausencia-no-es-oportunidad]]: el canal también
  se lee en los anuncios, no se supone.

## Señal de detección
Estás por entregar una tabla de anunciantes ordenada por días activos → contá
cuántos son de web y cuántos de WhatsApp. Si no lo sabés para cada fila, no
tenés el informe todavía: tenés media investigación.
