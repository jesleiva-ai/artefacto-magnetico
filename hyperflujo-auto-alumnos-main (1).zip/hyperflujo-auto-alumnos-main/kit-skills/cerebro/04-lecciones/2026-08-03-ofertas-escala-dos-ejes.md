---
type: leccion
created: 2026-08-03
tags: [ofertas]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 1
validada: 2026-08-03
moc: "moc-landings-y-ofertas"
aliases: ["Escala son dos ejes", "Mínimo 10 anuncios prendidos", "Días activos no alcanza"]
---

# Días activos sin cantidad de anuncios no mide escala: mide supervivencia

## Punto clave
Escala son DOS ejes y los dos van en la tabla: días que lleva el anuncio más viejo
(la oferta devuelve) **y ≥10 anuncios prendidos** (le están metiendo plata). Un
anuncio solo con 250 días no escala, sobrevive. Los que no llegan a 10 van a una
lista aparte de «demanda probada, escala sin confirmar».

## Qué pasó
El 2026-08-03 se entregó el ranking de un nicho de belleza low ticket usando **un
solo eje**: días que lleva vivo el anuncio más viejo de cada anunciante. Con eso,
un anunciante de cosmetología entraba tercero con 249 días.

Al mirar el segundo eje, ese anunciante tenía **un (1) anuncio activo**. Un anuncio
solo, corriendo casi un año, es un anunciante que dejó algo prendido con
presupuesto mínimo — no alguien que está escalando.

El dueño fijó el umbral: *"también hay que establecer el criterio de la cantidad de
días y la cantidad de anuncios prendidos. Tiene que tener mínimo diez anuncios
prendidos"*.

## Por qué pasó
Los dos ejes miden cosas distintas, y hacen falta los dos:

- **Días activos = la oferta devuelve.** Nadie sostiene un anuncio 250 días a
  pérdida. Prueba que el producto convierte.
- **Cantidad de anuncios prendidos = le están metiendo plata.** Un operador que
  escala multiplica creativos y conjuntos para conseguir volumen sin romper el
  costo por compra. Diez anuncios activos es alguien peleando por volumen; uno
  es alguien que no apagó una campaña.

**Ninguno de los dos solo alcanza.** Mucho volumen sin días es un lanzamiento
que todavía no probó nada; muchos días sin volumen es una vela prendida.

## Cómo evitar
- **Un anunciante entra al informe solo si cumple los dos**: anuncio más viejo
  con días de recorrido **y ≥10 anuncios activos**. Los dos números van en la
  tabla, siempre, uno al lado del otro.
- **Los que no llegan a 10 no desaparecen: van a una lista aparte** rotulada
  «demanda probada, escala sin confirmar». Sirven como evidencia de que el nicho
  existe, no como referencia a modelar.
- **El conteo se toma de la vista pública** de la Biblioteca con
  `country=ALL`, que es la que el dueño puede abrir y verificar. La API acotada a
  unos pocos países devuelve menos y descalifica anunciantes que sí califican.
- **El conteo es del día.** Se anota la fecha al lado: los listados cambian solos
  cuando el anunciante prende y apaga.

## Señal de detección
Estás por escribir "X lleva N días activo, es el líder" → ¿cuántos anuncios
tiene prendidos ahora mismo? Si no lo miraste, no sabés si escala o si sobrevive.
