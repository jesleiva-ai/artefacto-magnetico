---
type: leccion
created: 2026-08-11
tags: [cerebro-ia]
source: "criterio el kit — medido en tiendas propias"
status: activa
recurrencias: 3
validada: 2026-08-17
moc: "moc-landings-y-ofertas"
aliases: ["Un dolor que se repite pide máquina", "Una lección que se repite pide compuerta", "Recurrencia alta = candidata a hook", "Un costo manual recurrente es deuda que paga el dueño"]
---

# Un dolor que se repite no se arregla con más esfuerzo —tuyo o del dueño—: se arregla con máquina

## Punto clave
Un costo que vuelve cada vez no se resuelve con voluntad ni con una lección mejor
redactada: se resuelve con un mecanismo (script, hook, compuerta). Antes de dejarle
al dueño un paso manual que se repite, nombrá los caminos que probaste; y cuando una
lección llega a recurrencia 3, preguntate qué compuerta la vuelve innecesaria.

## Qué pasó
Tres casos con la misma forma: un costo que vuelve cada vez, resuelto con voluntad
en lugar de con mecanismo.

**1. El costo manual que iba a pagar el dueño (2026-07-27).** Después de agotar
cuatro caminos para leer un artifact compartido, se concluyó que no se podía
automatizar y se le propuso hacer **⌘A + ⌘C dentro del artifact cada vez** que
quisiera que yo viera uno. Presentado como la solución, no como un parche. El dueño
tuvo que empujar —*"quiero que te vuelvas realmente bueno, estamos trabajando sobre
las bases de algo gigante"*— para que se buscara el Chrome DevTools Protocol, que
resolvió el problema entero y además dejó una capacidad permanente: ver cualquier
página detrás de su sesión, no sólo ese artifact. La solución buena existía y era
alcanzable.

**2. La lección que ya estaba escrita y no se leyó (2026-08-11).** El dueño pidió
criterio sobre cómo enseñarles a sus alumnos a armar el Project de Claude. Se le
contestó "hay que mover el cerebro a Cowork" sin abrir una sola de sus clases; dos
módulos de su propio programa ya enseñan Cowork, el plan pago y qué es una skill.
**La lección ya existía**: «leer el cerebro primero», validada siete
días antes, decía textual que había que buscar en las fuentes del programa antes
de inventar un procedimiento que el programa ya enseña. Estaba redactada para ese
caso exacto.


**3. La precaución que no protegía nada (2026-08-17).** Conectando 4 tiendas de
Shopify, el dueño tenía que pasar un client id y un client secret. Se le pidió que
los mandara **"sueltos, no dentro del comando"**, presentado como la forma
cuidadosa. Quedaron escritos en el chat exactamente igual: cambió la forma, no el
efecto. Pasó **tres veces la misma sesión** — dos secrets de Shopify y un token de
GitHub por captura de pantalla. La solución real apareció recién al final y era
mecánica: un script que **pregunta** los valores y los lee ocultos (`read -rs`),
así no quedan ni en el historial de la terminal ni en la conversación. Estuvo
disponible todo el tiempo; lo que faltaba no era cuidado, era la máquina.

## Por qué pasó
En el caso 1, "agoté los caminos que se me ocurrieron" se tomó como "no hay camino"
— son cosas distintas, y la diferencia es exactamente el trabajo que el dueño
espera. Además el workaround era barato para el lado equivocado: dos teclas suyas,
cada vez.

En el caso 2, leer la lección es **opcional por diseño**. El protocolo dice "si vas
a actuar en un dominio con lecciones, leé el índice", y ese *si* lo evalúa el mismo
agente que está por equivocarse: cuando cree que entendió, evalúa que no aplica y
sigue. Nunca se entera de que le falta algo, porque lo que falta no está en la
conversación.

La prueba salió de la misma sesión, mismo modelo, dos turnos seguidos: en el que
`hook-antes-de-afirmar.py` disparó, se investigó y la respuesta fue correcta; en el
que no disparó ningún hook, no se revisó nada. Verificado corriendo el hook contra
los dos prompts: DISPARA / CALLA. La variable no fue el modelo ni la información
disponible: fue **si algo interrumpió antes de pensar**.


En el caso 3 el error tiene una forma propia y peligrosa: **una precaución que se
siente más segura y no lo es**. No hubo descuido — hubo una regla inventada en el
momento ("mandalo suelto") que nadie contrastó contra la pregunta que importa:
*¿dónde queda escrito el dato en el camino nuevo?* Si la respuesta es la misma que
en el viejo, no es una precaución: es un ritual que además tranquiliza, que es lo
que lo hace peor que no hacer nada.

## Cómo evitar
- **Antes de proponerle al dueño un paso manual que se repite**, preguntate si es
  imposible automatizarlo o si todavía no encontraste cómo. Nombrá los caminos que
  probaste; "no se puede" sin esa lista es "no busqué".
- Cuando una lección llegue a **recurrencia 3**, dejá de mejorarle el texto:
  *¿qué hook la haría innecesaria?* Si el disparador se detecta con dos regex sobre
  el prompt o sobre un `tool_input`, es candidata a compuerta.
- El evento que **previene** es `UserPromptSubmit`: inyecta contexto antes de que el
  modelo empiece a redactar. `PostToolUse` sirve para verificar después (así funciona
  `hook-ver-artifact.sh`), pero no evita el razonamiento equivocado.
- Un hook barato **falla abierto y calla**: sale 0 siempre, y si no matchea no cuesta
  nada. Nunca bloquear salvo que el costo del error sea alto.
- **Probalo contra los prompts reales que fallaron** y contra un puñado de prompts
  operativos que NO deben dispararlo. Un hook sin estrenar no está probado: el
  control se prueba rompiendo a propósito lo que tiene que atrapar.

## Señal de detección
- *Estás por dejarle al dueño un paso manual que se repite* → ¿es imposible, o no
  encontraste cómo todavía? Decí qué caminos probaste.
- *Estás por escribir una lección, o subirle la recurrencia a una que ya existe,
  sobre un error del que YA había lección* → no la redactes mejor: preguntate qué
  compuerta la vuelve innecesaria y escribí el hook en la misma sesión.
- *Estás por proponer una precaución* (mandalo de otra forma, borralo después,
  usá otro canal) → nombrá **dónde queda escrito el dato en cada camino**. Si es el
  mismo lugar, no protegiste nada: construí el mecanismo que lo evita de raíz.
- *Estás por contestar sobre el material del dueño sin haber abierto nada de
  `fuentes/` ni del vault* → abrí su material primero; si esto se repite, es
  candidato a hook.

## Lo que se construyó por esta lección
Un segundo hook de `UserPromptSubmit`, hermano de `hook-antes-de-afirmar.py`: aquel
cubre las preguntas sobre **el mundo** (se contestan buscando), éste las preguntas
sobre **lo suyo** (se contestan abriendo su material). Dispara sólo cuando se cruzan
dos ejes —material propio Y pedido de criterio o producción— e inyecta el orden de
lectura con las rutas reales. Probado: atrapa los dos prompts que fallaron, calla en
seis operativos.

Del caso 1 salió `herramientas/ojos.py` (CDP), que es la capacidad permanente que
el workaround manual no habría dado nunca.

Del caso 3 salió `herramientas/hook-secreto-en-el-chat.py`, registrado como
`UserPromptSubmit`. No intenta adivinar "estás por pedir un secreto" —eso vive en
la cabeza del modelo, no en el prompt—: ataja el momento en que la credencial **ya
apareció**, que es observable y es cuando todavía se puede rotar. Detecta por
prefijo publicado (`shpss_`, `github_pat_`, `EAA`, `sk-`, `AIza`,
`BEGIN PRIVATE KEY`…), nunca por "parece aleatorio", que dispararía con cualquier
hash de git. Probado por su interfaz real (stdin JSON, no la función interna):
dispara en los 3 casos reales y calla en 8 operativos, incluidos hash de git, EIN,
VARIANT_ID y la palabra "secret" sin secreto.

Y el propio `/aprende` la ejecuta: su compuerta de techo cuenta las lecciones
activas del área y bloquea un ADD hasta descargar una, y la línea del INDEX se corta
a ~40 palabras — si no entra, la lección pide compuerta, no más texto.
