# Indice de lecciones — leer el area ANTES de actuar en ella

> **Como se lee:** cada vineta empieza con la SENAL en negrita — el momento exacto en
> que la leccion aplica. Escanea las senales del area; si ninguna matchea lo que estas
> por hacer, segui. Abri la leccion completa solo si su senal matchea.
>
> **Como se escribe:** la escribe /aprende, siempre con confirmacion del dueno. Senal
> corta y accionable, no parrafo. Una recurrencia nueva se suma como sub-vineta.
>
> **Techo: 8 lecciones activas por area.** Para sumar la novena, primero se descarga una.

Este indice trae algunas lecciones de base (ofertas y cerebro-ia) y se llena con
los errores que se cometan trabajando en ESTE negocio. Las areas son las del vocabulario de CLAUDE.md.

## meta-ads

## productos-digitales

## ofertas

- **Vas a pedirle a un modelo que adapte, traduzca o re-niche material, o a llevar una oferta a otro idioma** → [[2026-07-28-ofertas-adaptar-mercado-destino]]: nombrá nicho, ticket y modelo de compra. El registro sale del copy publicado, y cada imagen se abre.
- **Estás por decir «nadie usa este ángulo, ahí está la oportunidad»** → [[2026-07-28-ofertas-ausencia-no-es-oportunidad]]: la Biblioteca no muestra lo que fracasó. El hueco se testea barato y aparte; nunca funda la oferta.
- **Vas a entregar una tabla de ofertas que escalan** → [[2026-08-03-ofertas-canal-de-venta-separado]]: partila en dos bloques, web y WhatsApp/DM, buscando en los dos por igual. El canal se lee en el destino del anuncio.
- **Vas a escribir «X lleva N días activo, es el líder» o a ordenar un ranking por días** → [[2026-08-03-ofertas-escala-dos-ejes]]: escala son dos ejes, días y ≥10 anuncios prendidos, los dos en la tabla.

## cerebro-ia

- **Vas a reportar que algo funcionó, falta o está mal y tu evidencia es un log, un exit code, un «200», un índice o una URL devuelta** → [[2026-07-27-cerebro-ia-el-proxy-miente]]: andá al artefacto real (render, valor releído tras recargar, registro del otro lado).
- **Una búsqueda dio cero, una página cargó vacía o algo «no aparece», y estás por escribir «no existe»** → [[2026-07-28-cerebro-ia-cero-resultados-no-es-no-existe]]: probá otra entrada al mismo dato, reintentá, rompé la caché (?nc=) y compará contra un hermano visible. Nombrá lo probado.
- **Vas a escribir «misma estructura», «calcado» o «modelado sobre X»** → [[2026-07-30-cerebro-ia-replicar-pide-el-fuente]]: bajá el fuente, extraé los tokens a un archivo y entregá el DIFF. Si no podés decir qué cambió y qué no, reinterpretaste.
- **Vas a dejarle al dueño un paso manual que se repite, o a subirle la recurrencia a una lección que ya existía** → [[2026-08-11-cerebro-ia-leccion-que-se-repite-pide-compuerta]]: nombrá los caminos probados; desde la recurrencia 3, construí el hook o la compuerta en la misma sesión.
