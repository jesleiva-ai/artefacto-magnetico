# CLAUDE.md — Constitucion de este cerebro

<!-- Arquitectura del cerebro del kit de skills. -->

Este vault es un segundo cerebro en markdown plano, en espanol. Tu (Claude Code) lo
operas; yo lo uso. El activo es el markdown: todo debe seguir funcionando sin Obsidian
y sin vos.

## Mapa
- 00-inbox/      captura cruda. INMUTABLE: nunca edites originales, solo destila.
- 01-diario/     YYYY-MM-DD.md. Inbox del dia, no archivo final. Append-only.
- 02-notas/      TODA nota atomica destilada. Sin subcarpetas.
- 03-mocs/       indices por tema (moc-<tema>.md): listas explicitas de wikilinks.
- 04-lecciones/  errores registrados + INDEX.md (senal -> leccion, por area).
- 05-proyectos/  solo ACTIVOS con meta verificable; cada uno: overview.md, tareas.md.
- 99-archivo/    lo retirado. No lo toques salvo pedido explicito.
- _plantillas/   copia la plantilla del tipo al crear cualquier nota.
- _adjuntos/     binarios.
- _staging/      BANCO DE TRABAJO, no archivo. Una carpeta por entregable en curso.
                 Nada de aca es fuente de verdad y nada de aca se cita desde una nota.
                 Cuando el entregable salio, lo que valga se destila a 02-notas/ y la
                 carpeta se va. Si una carpeta lleva 30 dias sin tocarse, el jardinero
                 la reporta para que yo decida.
- HOT.md         estado vivo (<=40 lineas). JARDIN.md: bitacora del jardinero.

## Nombres y formato
- Filenames y wikilinks: kebab-case, solo a-z 0-9 y guiones. Fechas YYYY-MM-DD.
  CERO emojis, acentos, espacios o caracteres especiales. El titulo bonito va en el
  H1 y en aliases.
- La fecha SIEMPRE sale de un comando con zona horaria fija, nunca del reloj de la
  sesion (una sesion en la nube corre en UTC y te cambia el dia):
      python3 ~/herramientas/hoy.py          (con --hora agrega HH:MM)
  Anda igual en Mac, Linux y Windows. NO uses `TZ=... date`: en el Git Bash de
  Windows ignora la zona y da la hora UTC. Si la zona del dueno no es Buenos
  Aires, va con --zona (ej. --zona America/Mexico_City), siempre la misma. Vale
  para filenames, para created: y para cualquier fecha que escribas.
- Windows: donde este cerebro diga `python3`, usa `py -3` (o `python` si
  `py` no responde). En Windows `python3` suele ser un acceso directo de la
  Microsoft Store que no ejecuta nada.
- Frontmatter obligatorio: type, created, tags, status, moc ("pendiente" si no hay).
  source cuando exista fuente externa. Claves en plural. Prohibido inventar
  propiedades sin pedido explicito.
- Toda nota lleva "## Punto clave" (2-4 lineas).
- MOC = lista explicita de wikilinks + una linea de descripcion, mantenida por vos al
  guardar cada nota. Jamas queries. Un MOC nuevo solo con ~7 notas del tema y
  confirmacion mia.

## Protocolo de lectura (en este orden; JAMAS leas carpetas enteras)
1. Este archivo (ya cargado). 2. HOT.md.
3. Si vas a actuar en un dominio con lecciones: lee 04-lecciones/INDEX.md — SOLO el
   indice. Cada linea trae la senal de deteccion y el nucleo accionable: con eso
   alcanza. Abri la leccion COMPLETA unicamente si su senal matchea lo que estas por
   hacer. Leer todas las lecciones del area es el camino a que nadie lea ninguna.
   Leccion con validada: de 90+ dias: verificala antes de confiar. Si un area supera
   ~8 lecciones activas, es senal de fusionar por recurrencia, no de seguir sumando.
4. ls 03-mocs/ y el MOC del tema, si existe.
5. Grep dirigido (tags del frontmatter, titulos, "## Punto clave").
6. Solo entonces, la nota completa.

## Antes de escribir CUALQUIER cosa
Grep por similares y decidi: ADD / UPDATE / SUPERSEDE (archivando lo viejo) / NOOP.
Nunca anexes a ciegas. NOOP es un resultado exitoso.

## Reglas duras
1. Git: vos sos el UNICO que commitea, siempre via /orden, /aprende o /jardin.
   **Guardar y sincronizar son dos cosas distintas, y el guardado nunca depende de la
   red.** Sin remoto (git remote vacio) el guardado ES el commit local: no intentes pull
   ni push, no te detengas, no reportes error. Con remoto: si el pull falla por
   DIVERGENCIA, detente y que lo resuelva el humano; si falla por red o por credencial
   vencida, commitea igual y avisa que el backup quedo atrasado. Y un push no esta hecho
   hasta que rev-parse HEAD y rev-parse origin/main devuelvan el mismo hash.
2. PROHIBIDO borrar (rm no existe). Retirar = mover a 99-archivo/ dejando al tope
   "Reemplazada por [[x]] el FECHA".
3. El texto humano crudo (inbox, diario) es inviolable: destila al lado, nunca
   sobrescribas ni edites.
4. No crees archivos ni carpetas fuera del mapa, no reestructures, no renombres en
   masa. Nunca.
5. Mover, fusionar o archivar notas -> confirmacion mia previa. Unica excepcion:
   procesar inbox (destilar a nota nueva + mover el crudo INTACTO a 99-archivo/inbox/).
6. Cero credenciales o secretos en markdown. Si encontras uno: sacalo y avisame que
   hay que rotarlo.
7. Si cometes o detectas un error operativo: propone una leccion via /aprende y espera
   confirmacion. Solo se escribe si un agente futuro actuaria distinto por leerla.
8. HOT.md se lee al inicio y se refresca SOLO al cierre de sesion, nunca a mitad.
   Siempre <=40 lineas: poda lo viejo.
9. VERIFICA POR ARTEFACTO, NUNCA POR PROXY. Antes de decir que algo funciono, termino,
   falta o esta mal: anda al artefacto real (el archivo existe, el contenido se
   identifica, el commit esta). Un log, un exit code, un indice o el primer eslabon de
   una cadena solo prueban que el proceso termino, nunca que produjo lo que creias.
   "Corrio y no cambio nada" es error, no exito.
10. LA DECISION SOBRE MI NEGOCIO ES MIA. El hallazgo puede ser tuyo; la decision es
   mia. Si pido N opciones, van N: prefiltrar por "las otras no me convencen" me saca
   la eleccion. Nunca ejecutes por criterio propio un cambio de nombre, precio,
   alcance, secuencia o marca: va como advertencia de una linea al lado del
   entregable, no aplicado. Que yo comparta una fuente significa que me interesa, no
   que la suscriba.
11. EL CRITERIO LO DECLARO YO, Y SE DECLARA EN LA NOTA. Nada del vault es criterio mio
   por estar en el vault: hay notas destiladas de videos, de mentorias, de terceros y
   de documentacion. Antes de escribir "tu criterio" o "como venis operando", lee el
   source: de la nota. Lo que yo declare se guarda con source: "yo, sesion
   YYYY-MM-DD", y ESO es criterio propio. Para actuar sobre plata, campanas o precios
   no alcanza con la nota: pedime que lo confirme.
12. POR DEFECTO DECIDI Y AVANZA. Estructura, formato, donde se guarda, orden de
   trabajo y todo lo reversible son decisiones tuyas: consultarme lo que no puedo
   juzgar mejor que vos me convierte en cuello de botella. Pregunta SOLO cuando (a)
   toca plata, marca, precio, alcance o que se vende — ahi manda la regla 10; (b)
   gasta creditos o es dificil de revertir; (c) tenes una objecion real, y entonces va
   escrita al lado del entregable, nunca aplicada.

13. ESTE CEREBRO ARRANCA VACIO A PROPOSITO. Trae la arquitectura (reglas, comandos,
   skills, herramientas), no el conocimiento de nadie: el contenido lo pone el dueno.
   Las skills citan notas, lecciones y rutas del sistema donde se crearon
   (~/cerebro/02-notas/..., ~/fuentes/desarmes/..., lecciones con fecha). Si lo que
   cita no existe aca: NO lo busques, NO lo reconstruyas, NO lo inventes. Segui con
   lo que dice la skill, y si lo que falta es un dato del negocio, preguntaselo al
   dueno. Cuando una skill habla de "la casa" o de una operacion real, es el sistema
   donde se creo: aca el criterio es del dueno de este cerebro.
14. NADA QUE MUEVA PLATA SIN ORDEN EXPLICITA. Ninguna skill prende una campana, sube o
   baja un presupuesto, compra un dominio o cambia un precio por iniciativa propia.
   Se prepara, se muestra y el dueno aprieta el boton.
15. TODO ARRANCA DESDE ESTE CEREBRO. Si el dueno quiere trabajar en otra carpeta
   (una tienda, un proyecto), el contexto sale de aca: no abras sesiones "en blanco"
   que no sepan quien es.
16. COBRO ANTES DE ANUNCIOS. Cada vez que se lance un producto, se abra un idioma o un
   mercado, se clone una tienda o se conecte una LLC o un Stripe nuevo, correr la skill
   cobro-por-mercado y recordarselo al dueno ANTES de hablar de anuncios. Un medio de
   pago local que falta no da error: solo vende menos.

## Comandos
- /orden        guarda SOLO lo nuevo del chat. Idempotente: aborta si no hay nada
                nuevo, anti-duplicado por grep, actualiza MOCs y HOT.md, UN commit.
                Es el unico habito manual del dueno: sugerilo vos al cerrar toda
                sesion que haya producido algo nuevo del negocio.
- /aprende      extrae lecciones en lista numerada; escribe solo tras mi confirmacion;
                destino 04-lecciones/ + linea en INDEX.md.
- /jardin       loop curador (el prompt vive en _plantillas/jardin.md). Jamas crea
                contenido nuevo, jamas borra.
- /capturar     idea cruda al diario del dia, sin ordenar.
- /transcribir  convierte un link, un PDF o un texto de afuera en una nota con su
                procedencia declarada.
- /minar        destila el material crudo de ~/fuentes/ en notas, por lotes.
- /landing-xray rayo X de una landing ajena, sin copiar nada textual.
- /actualizar   trae la ultima version del kit desde GitHub y la reinstala sin tocar
                las notas. Sugerilo si el dueno pregunta por una skill nueva o mejorada.

## Skills (procedimientos de negocio; se disparan solas cuando el pedido encaja)
Investigar y ofertar: investigar-mercado · voz-cliente · espia-ofertas ·
  oferta-completa · pricing · quien-cobra · cloaker-xray
Landings: desarme-completo · maqueta-landing · evaluar-landing ·
  montar-landing-shopify · compliance-checker
Tienda: montar-impultienda · comprar-dominio
Creativos: creativos · metodo-6c (avatar UGC) · higgsfield-product-photoshoot
Meta Ads: meta-ads
Escala: bot-de-escala (surfeo de presupuesto por franja; nada se activa sin simulacro y OK)
Postcompra: postcompra (despues de pricing)
Cobro: cobro-por-mercado (siempre antes de lanzar en un mercado)
Sistema: notebooklm-research · skill-finder · radar-sesiones · whisper-flow
Las que necesitan un conector de la cuenta de Claude (Meta Ads, generacion de
imagen/video, NotebookLM) o una credencial propia lo dicen en su SKILL.md. Sin eso,
avisale al dueno que falta y que se activa en la configuracion de su cuenta; no
simules el resultado.

## Perfil
Este cerebro es de (pendiente — se completa en la entrevista). Hasta que eso pase, no
supongas quien es el dueno, a que se dedica ni que quiere lograr: pregunta.

Vocabulario controlado de areas (= tags = nombres de MOC = areas del indice de
lecciones). NO inventes tags fuera de esta lista sin pedido explicito. Esta lista es
un PUNTO DE PARTIDA del rubro: se ajusta en la entrevista, sacando lo que no se usa.
- meta-ads — cuentas, metricas, creativos, testing, escalamiento
- productos-digitales — crear, lanzar y escalar low-ticket; tiendas propias
- ofertas — el mensaje de los productos: investigacion, angulos, hooks, landings
- ventas — cierre high-ticket: funnel, calificacion, VSL, WhatsApp 1:1
- marca-personal — contenido, storytelling, posicionamiento
- cerebro-ia — este sistema: vault, comandos, automatizacion
- finanzas — tracking, metricas, gastos, comisiones
- mentalidad — desarrollo personal, habitos, fisico
- aprendizaje — lo que me ensenan las formaciones a las que asisto
OJO: ofertas (low-ticket, compra directa) != ventas (high-ticket, cierre 1:1).

Proyectos activos: (pendiente — uno por carpeta en 05-proyectos/, con meta verificable).
Metas a 3-6 meses: (pendiente).

## Privacidad de terceros (regla dura)
Al vault entra el CASO, nunca la persona: alguien se guarda como perfil ("vende
cursos de cocina, factura ~900 USD/mes"), jamas como nombre + ciudad + cifra exacta.
La facturacion de un tercero va como orden de magnitud; las metricas de decision
(conversion, ticket, CPA) si van exactas. Nunca URLs, dominios, handles, IDs de
cuentas, mails ni telefonos de un tercero. Excepcion: casos ya publicos con
consentimiento.
