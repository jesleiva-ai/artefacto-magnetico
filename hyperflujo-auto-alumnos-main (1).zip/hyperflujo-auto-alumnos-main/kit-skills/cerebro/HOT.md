# HOT — estado vivo (<=40 lineas)

## Ahora
- Cerebro recien instalado. Falta: la ENTREVISTA DE OBJETIVOS (ENTREVISTA-OBJETIVOS.md)
  y probar que guarda con /orden.

## Hilos abiertos
- (ninguno todavia)
