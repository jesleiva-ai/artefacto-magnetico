# JARDIN — bitacora de curaduria

## Diagnostico YYYY-MM-DD
rotos: 0 | inbox: 0 | moc-pendiente: 0 | squeeze: 0 | caducados: 0 | lecciones-viejas: 0

## Para aprobar
(propuestas que el jardinero no puede ejecutar solo: borrar, fusionar, renombrar, mover
o crear un MOC. Cada una con fecha y razon. Esta es la cola de decisiones del dueno.)

## Hecho
