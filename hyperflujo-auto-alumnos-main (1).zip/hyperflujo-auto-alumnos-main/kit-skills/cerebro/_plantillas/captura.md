---
type: captura
created: YYYY-MM-DD
tags: []
source: ""
status: activa
moc: "pendiente"
aliases: []
---

# Título

## Punto clave

## Detalle

## Aplicación
