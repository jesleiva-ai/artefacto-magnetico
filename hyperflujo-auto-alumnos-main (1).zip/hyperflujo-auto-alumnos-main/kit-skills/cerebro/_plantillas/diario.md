---
type: diario
created: YYYY-MM-DD
tags: []
status: activa
moc: "pendiente"
---

# YYYY-MM-DD

## Tareas

## Captura

## Links
