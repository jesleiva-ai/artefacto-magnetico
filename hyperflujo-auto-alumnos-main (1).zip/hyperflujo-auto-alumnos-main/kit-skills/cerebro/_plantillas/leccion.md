---
type: leccion
created: YYYY-MM-DD
tags: []
status: activa
recurrencias: 1
validada: YYYY-MM-DD
moc: "pendiente"
---

# Título de la lección

## Qué pasó

## Por qué pasó

## Cómo evitar

## Señal de detección
