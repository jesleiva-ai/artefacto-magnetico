---
type: nota
created: YYYY-MM-DD
tags: []
source: ""
status: activa
moc: "pendiente"
aliases: []
---

# Título de la nota

## Punto clave

## Detalle

## Aplicación
