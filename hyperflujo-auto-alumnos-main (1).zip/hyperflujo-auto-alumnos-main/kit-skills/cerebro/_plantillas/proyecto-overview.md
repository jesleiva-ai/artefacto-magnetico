---
type: proyecto
created: YYYY-MM-DD
tags: []
status: activa
moc: "pendiente"
---

# Nombre del proyecto

## Meta
Meta verificable:
Fecha objetivo:

## Contexto

## Estado actual
