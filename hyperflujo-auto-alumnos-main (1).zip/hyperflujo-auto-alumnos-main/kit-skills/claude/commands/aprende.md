---
description: Extrae lecciones (formato Reflexion) de esta sesión y las guarda tras confirmación
---

**UBICACION DEL VAULT: `~/cerebro`.** Esta sesion puede estar abierta en cualquier
carpeta. Antes de hacer nada, trabaja SIEMPRE contra `~/cerebro`: todos los `git`,
lecturas y escrituras van ahi (usa rutas absolutas o `git -C ~/cerebro`). Si el
vault no existe, DETENTE y avisa.

Ejecuta el comando /aprende descrito en CLAUDE.md:

1. Revisa la sesión actual en busca de errores operativos o de negocio (tuyos o del humano) de los que un agente futuro se beneficiaría al saber.
2. Para cada candidato, redacta en formato Reflexion:
   - Qué pasó
   - Por qué pasó
   - Cómo evitar
   - Señal de detección (en segunda persona imperativa: "estás por hacer X → detente")
3. Preséntalas como lista NUMERADA al humano. No escribas nada todavía.
4. Pregunta cuáles confirma. Default: no escribir ninguna (NOOP es un resultado exitoso). Solo escribe las que el humano confirme explícitamente, y solo si un agente futuro actuaría distinto por leerlas.
5. Antes de escribir: grep en 04-lecciones/ por lecciones similares en la misma área.
   - Si no existe una similar: ADD — nueva nota en 04-lecciones/YYYY-MM-DD-<slug>.md (plantilla leccion.md) + línea nueva en 04-lecciones/INDEX.md (bajo el área correspondiente, señal primero).
   - Si existe una similar y esta la reafirma: incrementa `recurrencias` en la existente.
   - Si existe una similar y esta la contradice: SUPERSEDE — la nueva reemplaza, la vieja se mueve a 99-archivo/ con nota "Reemplazada por [[x]] el FECHA".
5b. **COMPUERTA DE TECHO — un área no crece sin descargar.** Antes de escribir un ADD,
   contá las lecciones ACTIVAS del área en `04-lecciones/INDEX.md` (las de la sección
   final "Ya son compuerta" NO cuentan). Si el área ya está en 8 o más, no escribas
   todavía: primero descargá una, en este orden de preferencia:
   - **(a) ¿Alguna ya es regla dura de CLAUDE.md o la ejecuta un hook?** → moverla a
     "Ya son compuerta", en UNA línea. Ya no depende de que alguien la lea: la máquina
     la aplica sola, y ocupando lugar en el índice sólo empuja a que no se lea ninguna.
   - **(b) ¿Dos lecciones comparten la misma causa raíz?** → fusionar por recurrencia;
     la absorbida va a `99-archivo/` con "Reemplazada por [[x]] el FECHA".
   - **(c) ¿La que ibas a escribir va por recurrencia 3+?** → no la redactes mejor:
     preguntate qué hook la vuelve innecesaria y escribilo en la misma sesión
     ([[2026-08-11-cerebro-ia-leccion-que-se-repite-pide-compuerta]]).
   Si ninguna se puede descargar, decíselo al dueño con el conteo y esperá. Sumar la
   número 9 sin descargar es exactamente cómo un área termina con el doble de
   lecciones y ninguna se lee.

5c. **La línea del INDEX es una SEÑAL, no un párrafo.** Máximo ~40 palabras: cuándo
   detenerse y qué hacer. El detalle vive en la lección. Si al agregar una señal nueva
   la línea pasa de ahí, es indicio de (c): esa lección pide compuerta, no más texto.

6. Si `recurrencias` llega a 2+ (mismo dolor dos veces) con la lección ya cargada: propón promoverla a regla dura numerada en CLAUDE.md y espera confirmación.
7. Commit semántico ("aprende: <lección>"), como parte del mismo flujo de /orden
   si aplica. El push va **solo si hay remoto**; si no lo hay, el commit local ya es el guardado y se informa así, sin tratarlo como error.
