---
description: Busca en el cerebro por SIGNIFICADO, no por palabra exacta (indice semantico local)
---

# /buscar — recuperacion por significado

Consulta: **$ARGUMENTS**

> **El buscador (una vez).** El script `~/herramientas/indice-cerebro.py` ya lo instaló el kit.
> Le falta su entorno, que se crea una sola vez. Si `PYI` (abajo) no existe, creálo:
>
> ```bash
> python3 -m venv ~/herramientas/.venv-indice        # Windows: py -3 -m venv ...
> "$PYI" -m pip install fastembed numpy
> "$PYI" ~/herramientas/indice-cerebro.py indexar --full
> ```
>
> El modelo de embeddings se baja solo la primera vez (de HuggingFace) y después corre
> local, sin llaves. El índice lee el vault en `~/cerebro` y vive fuera de él.
>
> **El Python del entorno:** en Mac y Linux es `~/herramientas/.venv-indice/bin/python`; en
> Windows, `~/herramientas/.venv-indice/Scripts/python.exe`. En los comandos de abajo, `PYI`
> es ese:
>
> ```bash
> PYI=~/herramientas/.venv-indice/bin/python; [ -x "$PYI" ] || PYI=~/herramientas/.venv-indice/Scripts/python.exe
> ```

## Que hacer

1. Corre la busqueda:

```bash
"$PYI" ~/herramientas/indice-cerebro.py buscar "$ARGUMENTS" -n 10
```

2. Si sale `[error] no hay indice` o `el indice esta vacio`, reconstruilo y volve a buscar:

```bash
"$PYI" ~/herramientas/indice-cerebro.py indexar --full 2>&1 | tail -2
```

3. **Leé el resultado como un mapa, no como la respuesta.** Cada linea trae ruta,
   seccion, tags, `source:` y un fragmento. Con eso alcanza para decidir. Abrí
   completa SOLO la nota (o las dos) que realmente contesten lo que se pregunto —
   nunca las diez.

4. Antes de citar cualquier cosa: mirá el `source:`. Si es criterio propio del
   dueño del vault, se cita como tal. Si dice un tercero, es una opinion. Si no
   tiene source, no es canon.

5. Contestá con lo encontrado, citando las notas como `[[nombre-de-la-nota]]`.

## Filtros disponibles

- `--area <area>` (las áreas del vocabulario de tu CLAUDE.md: ofertas, meta-ads, productos-digitales...)
- `--tipo leccion` (o nota, moc)
- `-n 20` para ampliar

## Cuando usarlo por tu cuenta, sin que te lo pidan

Usalo SIEMPRE que necesites material del cerebro y no sepas exactamente en que
nota esta: grep encuentra la palabra, esto encuentra la idea. Ejemplo medido: la
consulta "que hago cuando un creativo deja de funcionar" devolvia 235 notas por
grep (= inservible) y 3 pertinentes por el indice.

Grep sigue siendo mejor para lo literal: un nombre de archivo, un dominio, una
cifra exacta, un tag del frontmatter.

## Nota sobre el indice

Es descartable y se regenera del markdown. No es una fuente de verdad: si el
indice y la nota difieren, manda la nota.
