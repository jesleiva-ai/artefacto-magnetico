---
description: Captura rápida desde el celular (voz dictada) — mete la idea cruda en el diario del día y la publica
argument-hint: <lo que dictaste>
---

Ejecuta /capturar sobre $ARGUMENTS.

Este comando está pensado para cuando el dueño te habla desde el CELULAR, casi
siempre dictando por voz. La entrada viene sucia: sin
puntuación, con muletillas, con palabras mal transcriptas y a veces con
frases cortadas. NO es un pedido de trabajo elaborado: es materia prima.

## Regla cero: la fecha
Fijá la zona horaria del dueño y usala siempre la misma. Ninguna máquina que
corra este comando es confiable para saber la fecha: las VMs cloud van en UTC y
la computadora del dueño puede tener otra zona configurada. Cerca de medianoche
cada una dice un día distinto y la captura cae en el diario equivocado.

NUNCA uses la fecha ni la hora del sistema tal cual. Obtenelas SIEMPRE así:

```bash
python3 ~/herramientas/hoy.py --hora     # en Windows: python ~/herramientas/hoy.py --hora
```

(Si la zona del dueño es otra, agregá --zona con la misma que usa CLAUDE.md.)

Ese resultado manda para el nombre del archivo, para el `created:` del
frontmatter y para el encabezado `## HH:MM`. Si el diario de "hoy" que ves en
el repo tiene fecha distinta a la que devuelve ese comando, la correcta es la
del comando.

## Regla número uno
NO interpretes de más, NO expandas, NO redactes bonito, NO inventes.
Tu trabajo es GUARDAR lo que dijo, no mejorarlo. Si dudás entre limpiar y
dejar tal cual, dejá tal cual. El texto humano crudo es inviolable
(regla dura 3 de CLAUDE.md).

## Pasos
1. **Guardar y sincronizar son dos cosas distintas: el guardado NO depende de la
   red.** Corré `git -C ~/cerebro remote`.
   - Si NO devuelve nada, el vault es **local** (lo normal en una instalación
     recién hecha): saltá el pull, no intentes ningún push, y seguí. **Que no
     haya remoto NO es motivo para detenerte: el vault se guarda igual, en
     commits locales.**
   - Si devuelve `origin`: `git -C ~/cerebro pull --ff-only`. Si falla, mirá POR QUÉ:
     - "Not possible to fast-forward" / "diverged" → DETENTE y avisá. Hay trabajo
       remoto que no está acá; nunca merge automático.
     - **Cualquier otra causa** (sin internet, "Repository not found", "could not
       read Username", token vencido) → **NO te detengas**: seguí y guardá local
       igual. El commit no necesita red. Avisá en UNA línea al cierre: "guardado
       local; no pude sincronizar: MOTIVO; el backup quedó atrasado".

2. Limpiá SOLO ruido de transcripción: muletillas ("este", "eh", "viste"),
   repeticiones obvias, y puntuación faltante. Si una palabra parece mal
   transcripta y el contexto la hace obvia (ej. "Meta Ads" salió "meta as"),
   corregila. Si NO es obvia, dejala como vino y marcala con `[?]` al lado.
   Nunca reescribas el contenido ni cambies las palabras que él eligió.

3. Decidí dónde va, por tamaño y forma:
   - **Por defecto → `01-diario/YYYY-MM-DD.md`** (append-only). Es el inbox
     del día. Ahí va toda idea suelta, pendiente, observación o "se me
     ocurrió esto". Si el archivo del día no existe, crealo con la plantilla
     de _plantillas/ si hay una de diario; si no, con `# YYYY-MM-DD` y nada más.
   - **A `00-inbox/` solo si es un volcado largo** (más de ~15 líneas o un
     desarrollo entero de una idea). Filename kebab-case:
     `YYYY-MM-DD-<tema-en-tres-palabras>.md`. Ese archivo queda INMUTABLE.

4. Anexá al diario con este formato, sin agregar secciones de más:

   ```
   ## HH:MM — captura desde el celu
   <el texto limpio>
   ```

   Si en el dictado hay algo que claramente es una TAREA ("tengo que",
   "acordate de", "hay que"), agregá abajo una línea `- [ ] <la tarea>`.
   Nada más. No armes plan, no priorices, no sugieras.

5. NO destiles todavía. No crees notas en 02-notas/, no toques MOCs, no
   toques HOT.md. Esto es captura cruda: la destilación la hace `/minar` o
   `/orden` después, con el dueño presente y con el vault completo a mano.

6. Commit + push:
   - Commit: `captura: <5-8 palabras de qué se capturó>`
   - Si `git -C ~/cerebro remote` no devuelve nada, NO hay push: el commit
     local es el guardado. Terminá informando eso, sin tratarlo como error.
   - Si hay remoto, intentá `git push origin HEAD:main`.
   - Si el push a main falla (típico en sesión cloud desde el celu, donde
     la plataforma maneja el push por branch): NO insistas ni fuerces nada.
     Dejá el commit hecho y decile al dueño en una línea que le va a quedar
     un branch/PR para mergear desde GitHub.

7. Respondé CORTO. El dueño probablemente lee en el celu:
   - Qué guardaste, en una línea.
   - Dónde quedó (archivo).
   - Si quedó PR sin mergear, decilo.
   Nada más. Sin resúmenes, sin "¿querés que además...?".

## Lo que NO hace este comando
- No investiga, no busca en el vault, no responde preguntas.
- No arma notas atómicas ni MOCs.
- No refresca HOT.md.
Si lo que el dueño mandó es una PREGUNTA al cerebro y no una captura, ignorá
todo lo de arriba y simplemente contestale leyendo el vault (protocolo de
lectura de CLAUDE.md). No guardes nada.
