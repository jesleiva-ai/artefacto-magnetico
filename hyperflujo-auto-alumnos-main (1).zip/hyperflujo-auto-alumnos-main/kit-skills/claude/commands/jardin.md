---
description: Corre el loop del jardinero (curaduría autónoma del vault) según _plantillas/jardin.md
---

**UBICACION DEL VAULT: `~/cerebro`.** Esta sesion puede estar abierta en cualquier
carpeta. Antes de hacer nada, trabaja SIEMPRE contra `~/cerebro`: todos los `git`,
lecturas y escrituras van ahi (usa rutas absolutas o `git -C ~/cerebro`). Si el
vault no existe, DETENTE y avisa.

Carga y ejecuta al pie de la letra el prompt en `_plantillas/jardin.md`. Ese
prompt manda sobre esta descripción; CLAUDE.md manda sobre ambos. No crees
contenido nuevo, no investigues, no borres nada — solo cura lo que ya existe,
siguiendo exactamente los permisos PUEDES / NO PUEDES y las reglas de parada
ahí descritas.
