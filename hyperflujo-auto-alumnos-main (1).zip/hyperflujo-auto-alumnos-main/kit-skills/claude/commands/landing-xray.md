---
description: Rayo-X completo de una landing/página de ventas AJENA sin copiar nada verbatim (stack, tipo de funnel, estructura, paleta, promesa, avatar, precio+bump+OTOs, journey anuncio→checkout). Use PROACTIVELY cuando el usuario pase un URL de competidor, diga "rayo X a esta landing", "analizá esta página", "qué stack usa", "modelá esta landing" o pegue una referencia que está convirtiendo.
argument-hint: "<URL de la landing ajena>"
model: sonnet
allowed-tools: WebFetch, WebSearch, Read, Write, Grep, Glob, Bash
---

# `/landing-xray` — Rayo-X de landing ajena

Producís el rayo-X estructural de una página de venta AJENA para MODELAR su
esqueleto, jamás para copiarla. Corrés en la conversación principal.

## URL a radiografiar
$ARGUMENTS
> Si arriba no hay una URL, pedí el link y DETENTE.

## 0. Arranque barato (obligatorio, declaralo en tu primera línea)
1. Si el usuario tiene un segundo cerebro / vault, leé su archivo de estado
   vivo (`~/cerebro/HOT.md`) para el contexto activo.
2. Si el vault tiene lecciones registradas de **landings** o **naming**,
   abrilas y aplicalas. Si no hay vault, seguí directo al paso 1.
3. Escribí en una línea qué contexto leíste (o "sin vault, arranco directo").

## 1. Ética (innegociable, antes de tocar la web)
- Chequeá `robots.txt` del dominio; si prohíbe el path, DETENTE y avisá.
- SOLO data pública (lo que ve cualquier visitante). Nada de login, scraping
  de zonas privadas ni endpoints internos.
- Máximo ~2s entre requests. No martilles el servidor.
- REGLA DE ORO: modelás ESTRUCTURA, flujo y enfoque de mensaje. JAMÁS copiás
  copy verbatim ni diseño visual. Copiar hereda las debilidades del otro y
  arriesga trade-dress + rechazo en Meta.

## 2. Recolección (cada afirmación lleva su URL fuente)
- **Stack (estilo Wappalyzer):** con `curl -sI <url>` mirá headers (Server,
  X-Powered-By, Set-Cookie, Link). Con WebFetch buscá firmas en el HTML:
  `cdn.shopify`/`myshopify` → Shopify; `clickfunnels`/`cf-`→ ClickFunnels;
  `wp-content`/`wp-json` → WordPress; `__NEXT_DATA__`/`react` → React/Next;
  `stripe`/`js.stripe` → Stripe; `hotjar`/`gtag`/`fbq` → tracking. Reportá
  con el indicio exacto que lo delata.
- **Tipo de funnel:** clasificá en UNO: VSL / quiz / long-form / advertorial
  / página de imágenes. Justificá con lo que viste.
- **Estructura sección por sección:** recorré la página de arriba a abajo y
  listá cada bloque (hero, prueba social, mecanismo, oferta, garantía, FAQ,
  cierre) en orden, en 1 línea cada uno.
- **Paleta y tipografía:** colores dominantes (hex aproximado), familia
  tipográfica, densidad, tamaño de fuente del cuerpo, jerarquía de la 1ª
  pantalla.
- **Promesa / ángulo / mecanismo único** (el "cómo distinto" si lo nombran).
- **Avatar aparente:** a quién le habla (lenguaje, edad implícita, dolor).
- **Precio + order bump + OTOs:** precio del front, bump en checkout, OTOs si
  se alcanzan a ver; si el checkout no es público, dilo.
- **Journey anuncio → checkout:** si venís de un ad, documentá el recorrido
  completo y si hay costura de color/mensaje entre ad y landing.

## 3. Salida — brief en un archivo markdown
Escribí el brief en tu carpeta de borradores (si tenés vault:
`~/cerebro/_staging/landing-xray/<fecha>-<dominio-kebab>.md`; si no,
donde el usuario te diga). Formato EXACTO:

```
---
type: nota
created: YYYY-MM-DD
tags: [landings]
status: activa
moc: pendiente
source: <URL fuente>
aliases: ["Rayo-X: <dominio>"]
---
# Rayo-X — <dominio> (<fecha>)
## Punto clave
2-4 líneas: qué es, qué funnel, qué vale la pena robar del esqueleto.
## Stack
## Tipo de funnel
## Estructura sección por sección
## Paleta y tipografía
## Promesa / ángulo / mecanismo
## Avatar aparente
## Precio + order bump + OTOs
## Journey anuncio → checkout
## Qué robar (estructura) vs qué mejorar (nuestro ADN)
```
Cada afirmación termina con `(fuente: <URL>)`. En "qué mejorar" aplicás el
ADN propio de la marca del usuario: hook propio, garantía emocional, cómo
presenta los regalos/bonus, naming cuidado (sin palabras que Meta pueda
categorizar mal: salud, religión, dinero fácil, etc.).

## 4. Cierre
Presentá el brief en el chat. Si el usuario tiene un flujo de guardado al
vault (tipo /orden), recordale correrlo. Si quiere el avatar completo del
mercado, enlazá a `/investigar-mercado`.

## Lo que JAMAS haces
- Nunca copiás copy verbatim ni clonás el diseño visual: modelás el esqueleto.
- Nunca afirmás algo sin su URL fuente al lado.
- Nunca ignorás robots.txt ni tocás data no pública.
- Nunca inventás precios/OTOs que no viste: si el checkout es privado, lo decís.
- Nunca metés palabras de categorías restringidas en la sección "qué mejorar".
