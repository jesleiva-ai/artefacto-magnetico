---
description: Busca en Google Drive las grabaciones nuevas de tus llamadas, lee sus transcripciones y destila tu criterio en el vault
argument-hint: (vacío = todas las nuevas) | ultima | <tipo de llamada>
---

> **Requiere:** el segundo cerebro en `~/cerebro` (con `CLAUDE.md`, `JARDIN.md`,
> `02-notas/`, `04-lecciones/`) y el **conector de Google Drive**.
>
> **Configuración (una vez):** completá la tabla de abajo con el ID de la carpeta
> de Drive donde caen tus grabaciones (Zoom, Meet o Fathom suelen guardar ahí la
> transcripción) y con los tipos de llamada que tenés, reconocibles por el nombre
> del archivo.
>
> | Dato | Valor |
> |---|---|
> | Carpeta de grabaciones | `<ID de la carpeta de Drive>` |
> | Quién es «el dueño del criterio» | vos (o el mentor cuyas llamadas guardás) |

**UBICACION DEL VAULT: `~/cerebro`.** Esta sesion puede estar abierta en cualquier
carpeta. Antes de hacer nada, trabaja SIEMPRE contra `~/cerebro`: todos los `git`,
lecturas y escrituras van ahi (usa rutas absolutas o `git -C ~/cerebro`). Si el
vault no existe, DETENTE y avisa.

Trae y destila las llamadas directamente desde Google Drive. No hace falta descargar ni subir nada a mano.

## 1. Buscar (sin pedir archivos)
Usá las herramientas del conector de Google Drive, con `parentId = '<carpeta de grabaciones>'`.

- Leé `JARDIN.md` → `## Importación` (si la sección no existe, creala al final del archivo en la primera corrida) para saber la fecha de la última llamada minada. Buscá solo lo posterior a esa fecha (`createdTime > 'FECHA'`).
- Si `$ARGUMENTS` es `ultima`: traé solo la más reciente. Si es un tipo de llamada: filtrá por el patrón de nombre correspondiente.
- Priorizá SIEMPRE los archivos de texto (transcripciones `.vtt`/`.txt`/Documento de Google) sobre los `.mp4`. Un `.mp4` no se puede leer: si de una llamada solo hay video y no hay transcripción, anotá esa llamada como pendiente en `JARDIN.md` y avisá al cierre — no intentes descargarlo.
- Si no hay nada nuevo: informá "nada nuevo que minar" y terminá. NOOP es éxito.

## 2. Identificar el tipo de llamada por el nombre del archivo
Armá tu propia tabla. Ejemplo:

| Patrón en el título | Tipo | Cómo minarla |
|---|---|---|
| "GRUPAL", "RONDA DE CONSULTAS" | Grupal | Contenido MIXTO: puede ser clase pura o respuestas a dudas. Distinguí siempre quién dice qué: lo que dice un invitado NO es criterio propio |
| "Onboarding \| <nombre>" o nombre propio | 1:1 | Diagnóstico de la situación y recomendaciones puntuales: de acá salen las reglas de decisión |
| Llamada abierta fuera de los horarios fijos | Ronda abierta | ALTA PRIORIDAD: los asistentes traen métricas reales y se diagnostica en vivo. Es la mejor fuente del criterio aplicado |

## 3. Qué extraer (tres capas distintas, no mezcladas)
1. **Respuestas técnicas** del dueño del criterio → notas atómicas con el tag del área. `source: "criterio del dueño — llamada <nombre de la llamada>, FECHA"`.
2. **Reglas de decisión** (cuándo escalar, cuándo pausar, cómo diagnosticar) → lección en `04-lecciones/` SOLO si tiene señal de detección clara y accionable.
3. **Filosofía, visión y forma de acompañar** → notas con tag `mentalidad`.

**REGLA DURA — el chat escrito NO es criterio.** Quien da la llamada no suele leer el chat mientras habla: lo que escriben los asistentes es de ellos. Con un archivo de **chat de reunión**:
- NUNCA escribas una nota con `source: "criterio del dueño"` a partir del chat.
- NUNCA lo mezcles en una nota junto a lo dicho hablando.
- Por defecto, del chat NO sale ninguna nota (NOOP). Si algo parece genuinamente valioso, proponelo en `JARDIN.md` → `## Para aprobar`, citando textual, con el nombre de pila de quien lo escribió y la llamada.
- Ignorá emojis, saludos, chistes y logística.

Lo mismo aplica a **invitados o quienes conducen la llamada con vos**: su voz puede ser valiosa, pero si la guardás, que el `source` diga de quién es.

**Descartá siempre:** logística (horarios, links, audio que no anda), saludos y despedidas, charla suelta sin contenido.

**COMPUERTA DE CONTRASTE — lo técnico se verifica antes de escribirlo.**
Una transcripción destilada es una TRADUCCIÓN: al comprimir se fusionan distinciones.

- **Juicio** (cuándo escalar, qué priorizar, cómo diagnosticar) → va tal cual, no se contrasta.
- **Afirmación técnica verificable** (qué resetea el aprendizaje, qué límite tiene la plataforma,
  qué hace la API, cuánto dura algo) → contrastala contra la doc oficial ANTES de escribirla.

Si no coinciden: escribí la versión dicha, agregá `> Contraste FECHA: la doc oficial dice <Y> — <URL>.
Sin resolver.`, y llevalo a `JARDIN.md` → `## Para aprobar` con las dos citas. La formulación es
*"la nota dice X, la doc dice Y, ¿cuál es?"*.

Señal barata: una **"o"** uniendo dos sujetos distintos en una frase técnica ("conjuntos o
anuncios") casi siempre fusiona dos reglas opuestas.

## 4. Evolución del criterio (CRÍTICO — el criterio cambia con el tiempo)
Lo que funcionaba hace unas semanas puede haber dejado de funcionar. El cerebro tiene que reflejar esa evolución sin borrar la historia.

- **Fecha obligatoria:** toda nota que salga de una llamada lleva la fecha de esa llamada en `source`. Sin fecha, no se escribe.
- Antes de escribir, comparar con lo que el vault ya dice del tema y clasificar:
  - **Refinamiento** (suma matiz sin negar lo viejo) → UPDATE de la nota existente: incorporá el matiz y dejá las dos fechas en `source`.
  - **Contexto distinto** (lo viejo aplica a un caso y lo nuevo a otro — ej. cuentas chicas vs. escaladas) → NO es contradicción: hacé explícito en cada `## Punto clave` a qué contexto aplica.
  - **Contradicción real** (lo nuevo niega lo viejo) → NO decidas solo:
    1. Por defecto manda **lo más reciente**, pero no archives ni pises nada sin confirmación.
    2. Registrá el choque en `JARDIN.md` → `## Contradicciones detectadas`: qué decía antes (nota + fecha), qué dice ahora (llamada + fecha) y la cita textual de las dos.
    3. **Decilo explícitamente en el resumen final**: "acá te pisás con la data".
- Nunca borres el rastro. El cerebro tiene que poder responder "esto pensabas en mayo, esto pensás ahora, y esto cambió en el medio".

## 5. Reglas del vault
- Contrato de nota completo (frontmatter con `type, created, tags, status, moc` + `source`), `## Punto clave` de 2-4 líneas, kebab-case sin acentos.
- Vocabulario controlado del `## Perfil` de CLAUDE.md. `ofertas` (low-ticket) nunca se mezcla con `ventas` (high-ticket).
- **Anti-duplicado antes de cada escritura:** grep por similares → ADD / UPDATE / SUPERSEDE / NOOP. Nunca anexes a ciegas.
- Máximo ~10 notas por iteración. Si hay muchas llamadas nuevas, partí en lotes con un commit cada uno.
- **Privacidad:** nunca escribas en el vault datos sensibles de terceros (teléfonos, mails, datos de facturación, credenciales). El nombre de pila alcanza para dar contexto.

## 6. Cerrar
1. Registrá en `JARDIN.md` → `## Importación`: qué llamadas se minaron, su fecha, y cuántas notas salieron. Anotá también las que quedaron pendientes por no tener transcripción.
2. UN commit semántico (`mina: llamadas <fecha/tema> — N notas, M lecciones`).
   Push solo si hay remoto configurado.
3. Resumen corto: qué se minó, qué aprendió el cerebro, y qué quedó pendiente.
