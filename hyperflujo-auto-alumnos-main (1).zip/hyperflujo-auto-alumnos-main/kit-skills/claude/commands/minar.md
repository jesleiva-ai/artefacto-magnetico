---
description: Destila material crudo de ~/fuentes/ en notas del vault (por lotes, un commit por lote)
argument-hint: mentorias | productos | llamadas
---

**UBICACION DEL VAULT: `~/cerebro`.** Esta sesion puede estar abierta en cualquier
carpeta. Antes de hacer nada, trabaja SIEMPRE contra `~/cerebro`: todos los `git`,
lecturas y escrituras van ahi (usa rutas absolutas o `git -C ~/cerebro`). Si el
vault no existe, DETENTE y avisa.

Mina el material crudo de `~/fuentes/$ARGUMENTS/` (hermana de `cerebro/`, nunca se commitea) y destílalo en el vault. Si no se indicó carpeta, lista qué hay pendiente en las tres y pregunta por dónde empezar.

## Antes de nada
1. **Guardar y sincronizar son dos cosas distintas: el guardado NO depende de la
   red.** Corré `git -C ~/cerebro remote`.
   - Si NO devuelve nada, el vault es **local** (lo normal en una instalación
     recién hecha): saltá el pull, no intentes ningún push, y seguí. **Que no
     haya remoto NO es motivo para detenerte: el vault se guarda igual, en
     commits locales.**
   - Si devuelve `origin`: `git -C ~/cerebro pull --ff-only`. Si falla, mirá POR QUÉ:
     - "Not possible to fast-forward" / "diverged" → DETENTE y avisá. Hay trabajo
       remoto que no está acá; nunca merge automático.
     - **Cualquier otra causa** (sin internet, "Repository not found", "could not
       read Username", token vencido) → **NO te detengas**: seguí y guardá local
       igual. El commit no necesita red. Avisá en UNA línea al cierre: "guardado
       local; no pude sincronizar: MOTIVO; el backup quedó atrasado".
2. Lee `HOT.md` y `04-lecciones/INDEX.md` del área que vas a tocar.
3. Lista los archivos SIN procesar (los que están en la raíz de la carpeta, no en `procesado/`). Si no hay ninguno: informa "nada nuevo que minar" y termina. NOOP es un resultado exitoso.

## Lote e iteración
Trabaja por LOTES: máximo ~10 notas nuevas por iteración, un commit atómico por lote. Enuncia en una línea qué vas a lograr antes de arrancar.

## Qué destilar según la carpeta
- **mentorias/** — clases, formularios de onboarding, materiales de las formaciones o mentorías que toma el dueño. Áreas: `aprendizaje`, `ventas`, `marca-personal`. Lo que le enseñan al dueño va con tag `aprendizaje` y `source` citando la formación o el mentor.
- **productos/** — landings ganadoras, swipe files, métricas de campañas escaladas, investigaciones. Áreas: `productos-digitales`, `ofertas`, `meta-ads`. Buscá PATRONES REPETIDOS entre varias fuentes: eso es lo que vale, no el caso aislado.
- **llamadas/** — transcripciones de las llamadas del dueño (con clientes, socios o su propia comunidad). Extraé tres cosas distintas:
  1. **Respuestas técnicas** del dueño → notas con el tag del área (`meta-ads`, `ofertas`, etc.), `source: "criterio del dueño — llamada FECHA"`.
  2. **Reglas y criterios** que aplica al decidir → lección en `04-lecciones/` si tiene señal de detección clara.
  3. **Filosofía y forma de ver las cosas** (mentalidad, principios, cómo acompaña) → notas con tag `mentalidad`.
  Ignorá la logística de la llamada (saludos, coordinación de horarios, charla suelta).

## Contrato de escritura (igual que el resto del vault)
- Notas atómicas en `02-notas/` con frontmatter completo (`type, created, tags, status, moc`) + `source` obligatorio citando el archivo y la fecha, H1 con título bonito y `## Punto clave` de 2-4 líneas.
- Vocabulario controlado del bloque `## Perfil` de CLAUDE.md. No inventes tags.
- OJO con la frontera: `ofertas` (productos low-ticket, compra directa) NUNCA se mezcla con `ventas` (mentorías high-ticket, cierre 1:1).
- Filenames y wikilinks en kebab-case, sin acentos ni emojis.

## Anti-duplicado y jerarquía del criterio (crítico)
Antes de CADA escritura, grep por tags, títulos y `## Punto clave` similares. Decide ADD / UPDATE / SUPERSEDE (archivando la vieja en `99-archivo/` con "Reemplazada por [[x]] el FECHA") / NOOP.

**El criterio del dueño manda.** Si material de un mentor externo o de una fuente ajena contradice una nota cuyo `source` es criterio propio del dueño, NO la pises: dejá la nota del dueño como está, guardá la versión externa como nota aparte con su `source`, y anotá la contradicción en `JARDIN.md` → `## Para aprobar` para que él decida.

## Compuerta de contraste (antes de escribir cualquier afirmación técnica)
Una nota destilada es una TRADUCCIÓN, no la voz del dueño. Comprimir es donde se pierden
las distinciones finas, y una nota mal destilada lleva su firma pero ya no es su criterio.

Separá lo que estás por escribir en dos:
- **Juicio del dueño** (cuándo escalar, qué priorizar, cómo leer un mercado, qué le pasa a un
  cliente) → va tal cual. Es suyo y no se contrasta con nada.
- **Afirmación técnica verificable** (qué resetea la fase de aprendizaje, qué límite tiene una
  plataforma, qué devuelve una API, cuánto dura algo, qué porcentaje) → **contrastala contra la
  fuente oficial ANTES de escribirla.** WebSearch + la doc del proveedor; si no podés abrir la
  página, probá otra entrada antes de darla por buena.

Si la fuente oficial y lo que dijo el dueño no coinciden:
1. Escribí la nota con SU versión (regla dura 11) y agregá una línea
   `> Contraste FECHA: la doc oficial de <proveedor> dice <Y> — <URL>. Sin resolver.`
2. Anotalo en `JARDIN.md` → `## Para aprobar` con las dos citas textuales al lado.
3. **Nunca** se lo presentes como "esto choca con cómo venís operando": eso lo acusa de operar
   mal cuando lo más probable es que la traducción haya fallado. La formulación es
   *"la nota dice X, la doc dice Y, ¿cuál es?"*.

**Señal de detección barata:** una **"o"** uniendo dos sujetos distintos en una frase técnica
("conjuntos o anuncios", "campañas o conjuntos", "el píxel o el evento") suele estar fusionando
dos reglas OPUESTAS en una sola. Separalas y verificá cada una por su lado.

## Filtro de valor
Por cada nota candidata: "¿le sirve a su futuro yo o al agente?". Si no, no es nota — el material se queda en fuentes sin culpa. Mejor 5 notas destiladas de verdad que 50 copiadas crudas.

## Al cerrar el lote
1. Mové los archivos ya minados a `~/fuentes/<carpeta>/procesado/`. Nunca los edites ni los borres.
2. Registrá el lote en `JARDIN.md` → `## Importación` (qué se minó, cuándo, cuántas notas).
3. UN commit semántico: `mina: <tema/lote> — N notas, M lecciones`. El push va **solo si hay remoto**; si no lo hay, el commit local ya es el guardado y se informa así, sin tratarlo como error.
4. Si un tag llegó a ~7 notas sin su MOC, propónelo en `JARDIN.md` → `## Para aprobar`. No crees MOCs en caliente.

Respetá las reglas duras de CLAUDE.md. Lo que requiera confirmación humana (crear MOCs, fusionar, archivar, tocar diario o archivo), acumúlalo como propuesta y seguí.
