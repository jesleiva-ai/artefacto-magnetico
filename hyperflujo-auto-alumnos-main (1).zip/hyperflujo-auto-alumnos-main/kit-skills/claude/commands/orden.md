---
description: Guarda en el vault solo lo nuevo de esta sesión (idempotente, con guardián de git)
---

**UBICACION DEL VAULT: `~/cerebro`.** Esta sesion puede estar abierta en cualquier
carpeta. Antes de hacer nada, trabaja SIEMPRE contra `~/cerebro`: todos los `git`,
lecturas y escrituras van ahi (usa rutas absolutas o `git -C ~/cerebro`). Si el
vault no existe, DETENTE y avisa.

Ejecuta el comando /orden descrito en CLAUDE.md:

1. **Guardar y sincronizar son dos cosas distintas: el guardado NO depende de la
   red.** Corré `git -C ~/cerebro remote`.
   - Si NO devuelve nada, el vault es **local** (lo normal en una instalación
     recién hecha): saltá el pull, no intentes ningún push, y seguí. **Que no
     haya remoto NO es motivo para detenerte: el vault se guarda igual, en
     commits locales.**
   - Si devuelve `origin`: `git -C ~/cerebro pull --ff-only`. Si falla, mirá POR QUÉ:
     - "Not possible to fast-forward" / "diverged" → DETENTE y avisá. Hay trabajo
       remoto que no está acá; nunca merge automático.
     - **Cualquier otra causa** (sin internet, "Repository not found", "could not
       read Username", token vencido) → **NO te detengas**: seguí y guardá local
       igual. El commit no necesita red. Avisá en UNA línea al cierre: "guardado
       local; no pude sincronizar: MOTIVO; el backup quedó atrasado".
2. Guardián barato: si `git status --porcelain` no muestra nada Y no hay contenido nuevo de esta sesión para guardar, aborta e informa "nada nuevo que guardar".
3. Antes de escribir cualquier nota: grep en 02-notas/, 03-mocs/ y 04-lecciones/ por términos similares. Decide ADD / UPDATE / SUPERSEDE (archivando la vieja a 99-archivo/ con "Reemplazada por [[x]] el FECHA") / NOOP. Nunca anexes a ciegas.
4. Guarda solo lo NUEVO de esta conversación (capturas, notas destiladas, avances de proyecto). Usa las plantillas de _plantillas/ y respeta el frontmatter obligatorio (type, created, tags, status, moc). Cero emojis/acentos/espacios en filenames y wikilinks.
5. Actualiza los MOCs afectados (lista explícita de wikilinks, nunca queries) y HOT.md (≤40 líneas: sección Ahora / Decisiones recientes —máx 10, podar viejas— / Hilos abiertos).
6. **Justo antes del commit, mirá el diff de CADA ruta que vas a commitear**
   (`git -C ~/cerebro diff -- <ruta>`), no solo el `git status` del arranque. Si un
   archivo trae líneas que no escribiste vos, otra sesión lo editó MIENTRAS trabajabas:
   no lo commitees. Sacá esa ruta del commit, dejá tu cambio en el archivo y avisá.
   Commitear por ruta NO alcanza: `git commit -- HOT.md` se lleva todo lo que haya en
   ese archivo.
7. UN solo commit semántico (mensaje tipo "orden: <qué se guardó>"). El push va **solo si hay remoto**; si no lo hay, el commit local ya es el guardado y se informa así, sin tratarlo como error. Si hubo push, **verificalo por artefacto y no por la salida del comando**: `git -C ~/cerebro rev-parse HEAD` y `git -C ~/cerebro rev-parse origin/main` tienen que dar el mismo hash.

Sigue las reglas duras de CLAUDE.md en todo momento. Si algo requiere confirmación humana (mover, fusionar, archivar fuera del flujo de inbox), pregunta antes de actuar.
