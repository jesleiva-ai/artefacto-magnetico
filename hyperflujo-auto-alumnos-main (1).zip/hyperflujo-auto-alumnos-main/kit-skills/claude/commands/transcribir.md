---
description: Convierte un link o recurso externo en una nota atómica (tipo captura) formateada al contrato del vault
argument-hint: <url o texto pegado>
---

**UBICACION DEL VAULT: `~/cerebro`.** Esta sesion puede estar abierta en cualquier
carpeta. Antes de hacer nada, trabaja SIEMPRE contra `~/cerebro`: todos los `git`,
lecturas y escrituras van ahi (usa rutas absolutas o `git -C ~/cerebro`). Si el
vault no existe, DETENTE y avisa.

Ejecuta el comando /transcribir sobre el recurso que te pase el humano ($ARGUMENTS si viene con el comando; si no, pide el link o el texto).

1. Si es una URL: obtén el contenido y extrae la idea central relevante para el vault. Si es texto pegado, trabaja directo sobre él.
2. Grep en 02-notas/ por similares antes de escribir. Decide ADD / UPDATE / SUPERSEDE / NOOP.
3. Si procede escribir: crea una nota nueva en 02-notas/ usando _plantillas/captura.md:
   - `type: captura`, `source:` con la URL o referencia obligatoria, `tags:` con el vocabulario controlado existente (mismos nombres que MOCs y áreas de 04-lecciones/INDEX.md).
   - Filename kebab-case descriptivo, cero emojis/acentos/espacios.
   - "## Punto clave" en 2-4 líneas: la idea central, no un resumen genérico.
   - "## Detalle" y "## Aplicación" si aportan (pueden omitirse si la nota es muy corta).
4. Enlaza la nota al MOC del tema si existe (añade el wikilink); si no existe MOC, deja `moc: "pendiente"`.
5. No hagas commit todavía — eso lo hace /orden al cierre de la sesión, salvo que el humano pida guardar ya.
