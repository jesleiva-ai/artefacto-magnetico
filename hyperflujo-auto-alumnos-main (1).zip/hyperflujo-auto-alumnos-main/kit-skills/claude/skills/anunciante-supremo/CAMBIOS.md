# Cambios

## 1.1.0 — 2026-09-09

**Dos plantillas nuevas, mismo pipeline, misma llave.**

- **Plantilla 3 — Claymation.** Stop-motion de plastilina generado con IA (imagen por toma con
  gpt-image-2, animada con Veo) sobre una voz en off que manda el ritmo. Receta en
  `plantillas/plantilla-3.md`.
- **Plantilla 4 — Zack D Films.** Animación 3D tipo Pixar en cuatro capítulos que explican un
  mecanismo; el Capítulo 3 va en modo frame (cambio de estado) y la música es fija
  (`public/musica/zack-d-films.mp3`). Receta en `plantillas/plantilla-4.md`.
- Scripts nuevos: `gen:clips` (imágenes + clips + QC con corrección automática del letterbox
  oculto), `gen:voz` (una pista por línea, con sus tiempos, y el plan de montaje borrador),
  `montar` (planos ajustados solos a la voz real, captions quemadas, un golpe de sonido en cada
  corte, cama musical, normalización a −16 LUFS) y `batch:t3` / `batch:t4`.
- Ejemplos que corren tal cual: `input/ejemplo-t3/` y `input/ejemplo-t4/`.
- `doctor --fix` crea `src/brand.json` desde `brand.example.json` si no existe, muestra la versión
  instalada y verifica la música fija y los SFX.
- **La carpeta ya no trae `src/brand.json`**: actualizar encima de una instalación anterior no pisa la
  marca configurada. Tampoco toca `.env`, la biblioteca de música, los B-roll ni `out/`.

Las plantillas 1 y 2 no cambian.

## 1.0.0 — 2026-09-04

Primera versión: plantilla 1 (B-roll + voz en off, Remotion) y plantilla 2 (UGC A-roll cosido, ffmpeg).
