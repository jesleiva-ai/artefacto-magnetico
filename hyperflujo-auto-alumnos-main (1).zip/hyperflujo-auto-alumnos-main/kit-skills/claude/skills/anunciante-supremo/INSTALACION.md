# Instalación de anunciante-supremo

## 1. Qué necesitas

| Qué | Para qué | Cómo se instala |
|---|---|---|
| **Node.js ≥ 18** | corre todo | Windows: `winget install OpenJS.NodeJS.LTS` · macOS: `brew install node` · Linux: `nvm install 22` |
| **ffmpeg + ffprobe** | cortar, mezclar, medir audio y video | Windows: `winget install Gyan.FFmpeg` · macOS: `brew install ffmpeg` · Linux: `sudo apt install ffmpeg` |
| **Una llave de APIMART** | voz, transcripción, imágenes, música y video | https://apimart.ai → API Keys |
| Python 3 (opcional) | solo el verificador forense de la plantilla 2 (`verificar-t2.py`) | `python -m pip install numpy scipy pillow` |
| Una llave de ElevenLabs (opcional) | mejor voz en las plantillas 1, 3 y 4 (las de voz en off) | https://elevenlabs.io → Profile → API Keys |

`npm install` baja Remotion (~300 MB, un minuto). El Chrome headless (~400 MB más) se descarga solo la primera
vez que se renderiza la plantilla 1, que es la única que lo usa; las 2, 3 y 4 son ffmpeg puro.

## 2. Instalar con Claude Code (recomendado)

Esta carpeta viene dentro del paquete (`skills/anunciante-supremo`). Abre Claude Code en la carpeta del
paquete y pega:

> Instala la skill anunciante-supremo que está en `skills/anunciante-supremo` de este paquete:
> cópiala a `~/.claude/skills/` (tiene que quedar la carpeta `~/.claude/skills/anunciante-supremo`),
> abre su `SKILL.md`, corre `npm install` y `node scripts/doctor.mjs --fix`, ayúdame a instalar lo que
> quede en rojo, pídeme MI llave de APIMART (y la de ElevenLabs si la tengo) y configura mi marca en
> `src/brand.json` con una mini-entrevista. Cuando esté listo, dime cómo hago mi primer anuncio.

Claude copia la carpeta, instala las dependencias, pide **tus** llaves y configura tu marca. Después solo le
dices *"hazme un anuncio con la plantilla 1 sobre <tu producto>"*.

## 2 bis. Qué NO trae esta carpeta (y lo pones tú)

El paquete viaja sin nada pesado ni personal. Las carpetas existen (con un `.gitkeep`) para que el código
las encuentre:

| Carpeta | Qué va | Cómo se llena |
|---|---|---|
| `public/sfx/` | golpes de sonido de corte (`whoosh`, `pop`, `pop-bell`, `intro-rev`…) | **ya vienen** (≈ 140 KB, efectos genéricos); puedes reemplazarlos por los tuyos con el mismo nombre |
| `public/musica/zack-d-films.mp3` | la pista fija de la plantilla 4 (y del estilo `viral`) | **no viene** (era una pista de biblioteca con licencia que no se puede redistribuir). Pon ahí cualquier instrumental de suspenso/misterio que tengas con licencia, o genera una: `npm run gen:musica -- --id fija-4 --prompt "mysterious playful sneaking orchestral, 100 BPM"` y copia `public/media/_music/music-fija-4.mp3` a `public/musica/zack-d-films.mp3` (si es más corta que el anuncio, el montaje la repite en bucle). Alternativa sin tocar esta carpeta: poner `"musica": { "id": "<id>" }` en el `ad-NN.json`, que tiene prioridad sobre la fija |
| `public/fonts/` | fuentes locales opcionales | vacía: las fuentes se bajan de Google Fonts con `@remotion/google-fonts` |
| `public/media/_music/` | tu biblioteca de música generada | la llena `gen:musica` |
| `public/media/_clips/`, `public/media/_ugc/` | clips generados de las plantillas 2-4 | la llenan `gen:aroll` / `gen:clips` |
| `public/broll-<slug>/` | tu pozo de B-roll de la plantilla 1 | `prep:broll` (clips tuyos) o `gen:broll` |
| `input/` | los briefs y guiones de cada campaña | trae ejemplos (`ejemplo-t1..t4` y `ej-*`) con productos inventados |
| `out/` | los mp4 finales | lo llena el render |
| `.env` | tus llaves | `cp .env.example .env` |
| `src/brand.json` | tu marca | lo crea `doctor --fix` desde `brand.example.json` |
| `node_modules/` | Remotion y dependencias | `npm install` |

## 3. Instalación manual

```bash
cd ~/.claude/skills/anunciante-supremo
npm install
cp .env.example .env        # y completa APIMART_API_KEY
node scripts/doctor.mjs --fix   # crea src/brand.json si no existe
node scripts/test-connections.mjs
```

`node scripts/doctor.mjs --fix` crea `src/brand.json` desde `brand.example.json` si no existe (la carpeta no
lo trae, para no pisar tu marca al actualizar): edita CTA, color de acento y voz.

## 4. La llave

- La única obligatoria es `APIMART_API_KEY`. Puede ir como **variable de entorno del sistema**
  (`setx APIMART_API_KEY "..."` en Windows · `export APIMART_API_KEY=...` en tu shell) o en el `.env`
  de la carpeta de la skill. La skill la lee del entorno primero y nunca la guarda en otro lado.
- `ELEVENLABS_API_KEY` es **opcional**. Sin ella, la voz en off (plantillas 1, 3 y 4) sale por APIMART
  (`gpt-4o-mini-tts`) y los tiempos de las captions por `whisper-1`: funciona bien. Con ella, y con un
  `voiceId` en `brand.json`, la voz es más rica y las captions caen exactas al carácter.
- `.env` está en `.gitignore`. No lo compartas.

## 5. Costos

Todo se cobra en tu cuenta de APIMART. Cada script muestra el estimado y **pide confirmación antes de
gastar** (`--si` o `ANUNCIANTE_SI=1` para saltarla en tandas), y al final imprime lo facturado real.

| Pieza | Costo |
|---|---|
| Clip A-roll UGC (veo3.1-fast, 8 s, con voz y lip-sync) | $0,14 |
| Clip B-roll (veo3.1-lite, 8 s) | $0,07 |
| Imagen (gpt-image-2: frames, resaltes) | $0,0085 |
| Pista de música (Suno, dos tomas) | $0,05 |
| Voz + transcripción de un anuncio | ~$0,01 |
| **Anuncio de plantilla 2 completo** (6 escenas + 6 B-roll) | **≈ $1,30** |
| **Tanda de 7 anuncios de plantilla 1** (b-roll y música compartidos) | **≈ $1** |
| **Anuncio de plantilla 3 o 4** (7 tomas + 7 B-roll, música incluida) | **≈ $1,10** — y su set de 4-6 variantes reusa los clips |

## 6. Tu primer anuncio

Los tiempos: la plantilla 1 renderiza en 1-3 minutos; la 2, 3 y 4 generan los clips **por API, uno por
uno, a razón de 2-4 minutos por clip** (un ejemplo de 7 clips tarda ~20-25 minutos). La consola imprime un
punto cada pocos segundos mientras espera: no está colgado. Todo es reanudable si se corta.

Los ejemplos `ejemplo-t1..t4` venden un producto ficticio («Atlas de Anatomía Aplicada») y corren tal cual.
Los `ej-*` son guiones de referencia de otros productos inventados (pan de masa madre, planilla de
finanzas, huerta en macetas): sirven para ver cómo se escribe cada estilo; algunos usan scripts propios
de esa carpeta y no corren sin ajustar.

**Plantilla 1** (con B-roll descargado: $0,09 — música $0,05, voz e imágenes $0,04; después la música y
el b-roll se reusan y cada anuncio nuevo cuesta ~$0,04). Primero descarga 10-15 clips verticales sobre
estudiar anatomía (manos con un cuaderno, una estudiante frente a apuntes, un teléfono, un gimnasio) en
una carpeta, y:
```bash
npm run prep:broll -- --desde "C:/ruta/a/mis-clips" --a public/broll-ejemplo-t1
npm run gen:musica -- --id ejemplo-pop --prompt "upbeat pop rock for a study-app ad, 118 BPM, energetic"
npm run batch:t1 input/ejemplo-t1 out/ejemplo-t1
```
Si prefieres no buscar clips, el segundo comando puede ser
`npm run gen:broll -- --prompts input/ejemplo-t1/broll.json --out public/broll-ejemplo-t1 --nombre broll-`
(6 clips generados con APIMART, medido $0,47 con un reintento).
Sale `out/ejemplo-t1/ejemplo-t1-ad1.mp4`.

**Plantilla 2** (medido: $0,95 — 4 escenas A-roll $0,56, 5 frames $0,04, 4 B-roll $0,31, QC $0,04; los dos anuncios salen de los mismos clips):
```bash
npm run gen:aroll -- input/ejemplo-t2/guion.json --regenerar
npm run batch:t2 input/ejemplo-t2 out/ejemplo-t2
```
Salen `out/ejemplo-t2/ejemplo-t2-ad1.mp4` (normal) y `ejemplo-t2-ad2-solobroll.mp4` (sin cara).

**Plantilla 3** (claymation; medido: $0,64 — música $0,05, 4 tomas + 3 B-roll con sus imágenes $0,55, 4 líneas
de voz $0,04; si ya creaste `ejemplo-pop` para la plantilla 1, el primer comando sobra):
```bash
npm run gen:musica -- --id ejemplo-pop --prompt "upbeat pop rock for a study-app ad, 118 BPM, energetic"
npm run gen:clips -- input/ejemplo-t3/guion.json
npm run gen:voz   -- input/ejemplo-t3/guion.json
npm run montar    -- input/ejemplo-t3/ad-01.json --salida out/ejemplo-t3/ejemplo-t3-ad1.mp4
```

**Plantilla 4** (Zack D Films; medido: $0,67 — 4 tomas, una en modo frame, + 3 B-roll; la música es la
fija del estilo: antes pon una pista en `public/musica/zack-d-films.mp3`, ver §2 bis):
```bash
npm run gen:clips -- input/ejemplo-t4/guion.json
npm run gen:voz   -- input/ejemplo-t4/guion.json
npm run montar    -- input/ejemplo-t4/ad-01.json --salida out/ejemplo-t4/ejemplo-t4-ad1.mp4
```

## 7. Problemas frecuentes

| Síntoma | Qué es | Qué hacer |
|---|---|---|
| `APIMART_API_KEY inválida (HTTP 401)` | la llave está mal o vencida | regenerarla en apimart.ai |
| `Falta APIMART_API_KEY` | no está ni en el entorno ni en `.env` | `cp .env.example .env` y completarla |
| `No hay b-rolls en public/broll-…` | la plantilla 1 no encontró clips | descargar 10-15 clips y pasarlos por `prep:broll`, o generarlos con `gen:broll` |
| `Falta la música: pon "music": "<id>"` / `no hay ninguna pista con id` | el id no está en `public/media/_music/` | `npm run gen:musica -- --id <id> --prompt "..."` (la plantilla 4 no lo necesita: su música es fija) |
| `falta el clip t03.mp4` / `falta la voz l02.mp3` | el plan de montaje apunta a algo que no se generó | `npm run gen:clips` / `gen:voz` sobre el guion (son reanudables) |
| `necesita 7,4 s del clip y solo tiene 6,6 s` | un plano de la plantilla 3/4 pide más metraje del que da un clip de 8 s | agregar otro plano (toma o B-roll) a ese beat, o bajar `maxPlano` |
| `interpoladas: diecinueve` en el montaje | whisper devolvió `19` y el guion decía la palabra: la caption se colocó a ojo | normal; escribir los números como cifra en el guion evita que pase |
| `sin terminal interactiva: pasa --si` | el script no puede preguntar | agregar `--si` (o `ANUNCIANTE_SI=1`) |
| `cobertura 62 % entre el guion y lo que whisper oyó` | la voz no dice lo que dice el guion | en la plantilla 1, revisar signos raros del `narration`; en la 2, reescribir la línea de esa escena y `--regenerar` |
| `Blocked by a specific content policy` al generar un B-roll o A-roll | el filtro de Veo es probabilístico: el mismo prompt pasa una vez y se bloquea otra | los scripts reintentan una vez solos (el bloqueo no se cobra); si vuelve a fallar, reformular sin partes del cuerpo ni marcas y correr de nuevo (es reanudable) |
| Meta se cuelga al 80 % subiendo el mp4 | frame rate variable | `batch:t1` ya lo normaliza; a mano: `node scripts/normalizar-meta.mjs <mp4>` |
| El render de la plantilla 1 tarda mucho | Remotion dibuja con Chrome | es normal (1-3 min por anuncio); `T1_CONCURRENCY=4` si la máquina se queda sin RAM |
| `Assertion failed … UV_HANDLE_CLOSING` al terminar un script | Node ≥ 22 en Windows cerrando sockets | inofensivo; el archivo ya se escribió |
| `npm install` avisa que bloqueó un `postinstall` (`allow-scripts`) | política de npm de esa máquina, no de la skill | inofensivo para las plantillas 2-4; si la 1 no renderiza, `npm rebuild esbuild` |
| `gen:clips` parece colgado | está esperando a Veo (2-4 min por clip) e imprime un punto cada pocos segundos | esperar; es reanudable si se corta |
