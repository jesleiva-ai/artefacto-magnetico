# anunciante-supremo

Skill de [Claude Code](https://claude.com/claude-code) que produce **anuncios verticales 9:16 para vender
infoproductos**, de punta a punta, con **una sola llave: APIMART**.

- **Plantilla 1 — B-roll + voz en off.** B-roll cortando cada 1,5 s, voz en off, captions karaoke,
  título-gancho, música instrumental, resaltes con campanita. Motor: Remotion.
- **Plantilla 2 — UGC A-roll cosido.** Una persona a cámara con el diálogo generado y sincronizado a
  los labios, cosida a 1,18x con B-roll sobre la palabra que ilustra y captions palabra a palabra.
  Incluye el modo sin cara (`solo-broll`) y la escalera de 6 variantes. Motor: ffmpeg.
- **Plantilla 3 — Claymation.** Stop-motion de plastilina generado con IA (una imagen por toma,
  animada con Veo) sobre una voz en off que manda el ritmo: planos de ≤ 3 s, B-roll sobre la palabra
  que ilustra, un golpe de sonido en cada corte, captions palabra a palabra. Los clips no tienen
  idioma: traducir el anuncio es otra voz. Motor: ffmpeg.
- **Plantilla 4 — Zack D Films.** Animación 3D tipo Pixar en cuatro capítulos que explican un
  mecanismo con un giro; el capítulo del mecanismo va en modo frame (cambio de estado) y la música
  es fija. Mismo montador que la 3. Motor: ffmpeg.

La skill escribe el guion con un método de hooks (`plantillas/hooks.md`), genera voz, imágenes,
música, clips y B-roll con APIMART, y renderiza. Todo lo que gasta muestra el costo y pide
confirmación. Un anuncio UGC completo cuesta ≈ $1,30; una tanda de 7 anuncios de plantilla 1, ≈ $1;
un anuncio de plantilla 3 o 4 con 7 tomas y 7 B-roll, ≈ $1,10 (y su set de 4-6 variantes reusa los
mismos clips).

**Versión 1.1.0** — ver [CAMBIOS.md](CAMBIOS.md).

**Qué no trae esta carpeta** (lo pones tú): tu llave de APIMART en `.env`, tu marca en `src/brand.json`
(lo crea `doctor --fix`), `node_modules/` (`npm install`), la pista fija de la plantilla 4 en
`public/musica/zack-d-films.mp3` (no se redistribuye por licencia) y todo lo generado (`public/media/`,
`public/broll-*`, `out/`). Detalle en [INSTALACION.md](INSTALACION.md), §2 bis.

**Instalación y primer anuncio:** [INSTALACION.md](INSTALACION.md) · **Cómo la usa Claude:** [SKILL.md](SKILL.md)

Requisitos: Node ≥ 18, ffmpeg, una llave de APIMART. ElevenLabs opcional (mejor voz en off en las plantillas 1, 3 y 4).

---
Derivado de [video-vox](https://github.com/santmun/video-vox) de Horizontes IA (Remotion + plantillas
de edición). Esta versión reemplaza los proveedores por APIMART, agrega las plantillas UGC, Claymation
y Zack D Films, la generación de clips y el método de hooks.
