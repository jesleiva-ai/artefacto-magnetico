---
name: anunciante-supremo
description: Crea ANUNCIOS publicitarios verticales (9:16) para vender infoproductos a partir de cuatro PLANTILLAS de edición — plantilla 1 «B-roll + voz en off», plantilla 2 «UGC A-roll cosido» (persona a cámara con lip-sync), plantilla 3 «Claymation» (stop-motion de plastilina generado + voz en off) y plantilla 4 «Zack D Films» (animación 3D tipo Pixar en capítulos que explican un mecanismo). De punta a punta y autónomo con una sola llave (APIMART): escribe el guion con el método de hooks, genera voz, imágenes, música, clips y B-roll, y renderiza (Remotion / ffmpeg) con captions quemadas. Úsalo cuando el usuario diga "hazme un anuncio con la plantilla 1/2/3/4 sobre X", "anuncio UGC de X", "anuncio de plastilina / claymation / stop-motion", "anuncio estilo Zack D Films / explicador animado 3D", "tanda de anuncios de X", "variantes del anuncio", o invoque /anunciante-supremo. La primera vez corre un onboarding (doctor + llave + marca).
---

# anunciante-supremo — Anuncios verticales por plantillas de edición

> **Trampa conocida:** `--regenerar` rehace el VIDEO pero reusa la imagen guardada en `frames/<id>.png/.json`. Si Veo
> rechaza por «content safety», cambiar el prompt NO alcanza: borrar `frames/<id>*` y recién ahí regenerar.
> Veo suele bloquear: jeringas, manos con objetos en primer plano, espuma roja. Hay un estilo extra `viral` (foto
> macro hiperreal + personaje 3D adentro) en `scripts/lib/montar-lib.mjs`; la velocidad de la voz se ajusta con `ELEVENLABS_SPEED`.
> Si tu marca tiene reglas propias de creativos (qué se puede mostrar, si va precio o no), anótalas en tu cerebro / base de notas y respétalas en cada guion.

Convierte un producto en un ANUNCIO 9:16 para Reels/TikTok/Facebook. El objetivo SIEMPRE es persuadir
y convertir. Trabaja SIEMPRE dentro de la carpeta donde está instalada esta skill (normalmente
`~/.claude/skills/anunciante-supremo`): todos los comandos son relativos a ella.

## Las cuatro plantillas
| ID | Nombre | Qué es | Motor | Receta |
|----|--------|--------|-------|--------|
| 1 | B-roll + voz en off | B-roll a pantalla completa cortando cada ~1,5 s · voz en off · captions karaoke negro/blanco · título-gancho 3-5 s · música instrumental · resaltes con campanita · 1,25x | Remotion | `plantillas/plantilla-1.md` |
| 2 | UGC A-roll cosido | Persona a cámara con el diálogo grabado (lip-sync) · clips cosidos a 1,18x · captions palabra a palabra · insertos de B-roll sobre la palabra que ilustran · modo `solo-broll` · escalera de 6 variantes | ffmpeg | `plantillas/plantilla-2.md` |
| 3 | Claymation | Stop-motion de plastilina generado (imagen por toma + Veo) · voz en off que manda el ritmo · planos de ≤ 3 s con B-roll sobre la palabra · captions palabra a palabra · un golpe de sonido en cada corte · 1,15x · los clips no tienen idioma (traducir = otra voz) | ffmpeg | `plantillas/plantilla-3.md` |
| 4 | Zack D Films | Animación 3D tipo Pixar en 4 capítulos (situación → producto → mecanismo interno → payoff) · tomas de mecanismo en modo frame (cambio de estado) · música fija del estilo · 1,12x · mismo montador que la 3 | ffmpeg | `plantillas/plantilla-4.md` |

## Primera vez (onboarding)
1. `node scripts/doctor.mjs --fix` — Node, ffmpeg, dependencias, llave. Ayuda con lo que quede en rojo.
2. **Llave**: la skill necesita `APIMART_API_KEY` (https://apimart.ai → API Keys). Si el usuario ya la
   tiene como variable de entorno, `doctor` la encuentra solo; si no, copia `.env.example` a `.env` y
   pídesela. **Nunca uses una llave que no sea la del usuario.** `ELEVENLABS_API_KEY` es opcional:
   pregúntale si la tiene; si sí, la voz en off (plantillas 1, 3 y 4) sale mejor.
3. **Marca**: `doctor --fix` crea `src/brand.json` desde `brand.example.json` si no existe (el zip no
   trae `brand.json`, así una actualización nunca pisa la marca del usuario). Edítalo con una
   mini-entrevista: CTA, color de acento (hex), voz de APIMART (`nova`/`shimmer`/`alloy`/`echo`) y el
   tono (`instructions`), y el `voiceId` de ElevenLabs si lo tiene. `mostrarTag: false` salvo que
   quiera mostrar su @usuario en pantalla.
4. `node scripts/test-connections.mjs`.

## Antes de escribir el guion
- **Si el usuario tiene un cerebro / base de notas con la ficha del producto** (oferta, avatar,
  anuncios anteriores, ángulos ya usados): léela primero y parte de ahí. No repitas un ángulo quemado.
- **Si no**, haz 5 preguntas: ¿qué producto y qué promete? ¿a quién (avatar y su dolor)? ¿qué prueba
  concreta hay (números, entregables)? ¿precio y garantía? ¿a qué idioma y país va el anuncio?
- Lee `plantillas/hooks.md` **siempre**: el `hook` y las primeras 2-4 frases de cada guion tienen que
  pasar su checklist (sujeto + dolor/resultado, número específico, `|` corte de línea, `*énfasis*`).
- **Si el usuario no dice qué plantilla quiere**, elige por lo que tiene y lo que vende: clips propios
  o descargables → 1; una persona creíble hablando → 2; un mecanismo o villano que conviene
  personificar, o un producto físico → 3 o 4 (la 3 es más cálida y artesanal, la 4 más explicativa).
  Dilo en una línea y sigue; no abras una encuesta.

## Flujo — plantilla 1
1. Leer `plantillas/plantilla-1.md`.
2. Música: `npm run gen:musica -- --id <id> --prompt "<estilo en inglés>"` (una vez; se reusa por id).
3. B-roll — **el camino normal es que el usuario los descargue**: pídele 10-15 clips verticales del
   tema (bancos de clips, capturas de pantalla del producto, material propio) en una carpeta, y
   normalízalos con `npm run prep:broll -- --desde "<carpeta>" --a public/broll-<slug>` (los deja
   como `broll-NN.mp4` a 1080×1920, sin audio). **Solo si no quiere buscar clips**, ofrécele
   generarlos con APIMART: `npm run gen:broll -- --prompts input/<campaña>/broll.json --out public/broll-<slug> --nombre broll-`
   ($0,07 por clip). Un pozo de B-roll se reusa en toda la tanda y en tandas futuras del mismo producto.
4. Briefs: `input/<campaña>/ad-01.json … ad-NN.json` (esquema en la receta). Una tanda = un guion
   ganador × 5-7 ángulos.
5. `npm run batch:t1 input/<campaña> out/<campaña>` → mp4 finales (1,25x, CFR 30, listos para Meta).
6. Entregar los `.mp4` y los copys, ofrecer ajustes.

## Flujo — plantilla 2
1. Leer `plantillas/plantilla-2.md`.
2. Guion por escenas: `input/<campaña>/guion.json` (personaje con retrato forense, escenario, 4-6
   escenas de ≤ 8 s con `dialogo` exacto, B-roll por escena, `musica`).
3. `npm run gen:aroll -- input/<campaña>/guion.json` → muestra el costo, pide confirmación (mostrale el costo al usuario y esperá su OK antes de `--si`), genera
   frames + clips + B-roll, corre el QC y deja `ad-01.json` borrador.
4. Revisar el QC: una escena que reprueba se reescribe (línea más simple) y se regenera con
   `--solo N --regenerar`.
5. Ajustar `ad-01.json` (insertos `sobre`, música) → `npm run batch:t2 input/<campaña> out/<campaña>`.
6. **Mirar el anuncio antes de entregarlo** (los pozos de autoría de la receta).
7. Con el principal aprobado, proponer la escalera de variantes (receta, «La escalera de variantes»).

## Flujo — plantillas 3 y 4 (mismo pipeline, distinto `estilo`)
1. Leer `plantillas/plantilla-3.md` (la base) y, si es la 4, también `plantillas/plantilla-4.md`.
2. Escribir el guion: ángulo (default: problema oculto + mecanismo), líneas de voz (mínimo 30 s,
   `segundos × 2,4` palabras, **números como cifra**), una toma por línea con su B-roll, el Character
   Bible repetido palabra por palabra (plantilla 3) o los cuatro capítulos con el Cap. 3 en modo frame
   (plantilla 4). Todo en `input/<campaña>/guion.json` (`"estilo": "claymation"` o `"zack"`).
3. Entregar en el chat **el paquete completo antes de gastar**: ángulo y dónde ocurre el giro, tabla
   del guion (línea · duración estimada · toma · B-roll), los prompts, el guion de voz limpio, **el set
   de testeo** (semilla + 3-5 variantes con su eje y sus clips nuevos) y el costo estimado. Ofrecer
   producir y **esperar el OK**: es la única pausa.
4. `npm run gen:clips -- input/<campaña>/guion.json` → imágenes + clips + QC (letterbox corregido
   solo). **Mirar frames de cada clip** antes de seguir; regenerar con `--solo <id> --regenerar`.
5. Música: plantilla 3, `npm run gen:musica` (una por registro, reusable) y `"musica": { "id" }` en el
   guion; plantilla 4, nada — es la fija del estilo.
6. `npm run gen:voz -- input/<campaña>/guion.json` → `lNN.mp3` + tiempos + `ad-01.json` borrador (solo
   si no existe; si ya está, se respeta). Tarda 2-4 min por clip en `gen:clips`: avisar al usuario.
7. Revisar `ad-01.json` (planos de cada beat, orden) → `npm run montar -- input/<campaña>/ad-01.json --salida out/<campaña>/<slug>-ad1.mp4`.
   Mirar la línea `interpoladas …` de cada beat y **ver el anuncio** antes de entregarlo.
8. Variantes: cada una es otro `ad-NN.json` (y, si cambia el gancho o la voz, `gen:voz --solo 1` o
   `--forzar`) → `npm run batch:t3 input/<campaña> out/<campaña>` (para la 4, `batch:t4`).
9. Entregar los `.mp4` y los copys, ofrecer ajustes.

## Reuso entre videos (lo que hace barata la segunda tanda)
- **Música**: una pista por registro (confesión / descubrimiento / urgencia) en `public/media/_music/`,
  reusada por `id` en las dos plantillas. Antes de generar una nueva, listar las que hay.
- **B-roll**: un pozo por producto en `public/broll-<slug>/`; se reusa en toda la tanda y en las
  siguientes. Para otro producto del mismo nicho suele servir el mismo pozo.
- **Íconos de resalte**: se guardan solos en `public/media/lib/` y se reusan por prompt sin pagar.
  Escribir prompts estables y repetirlos entre anuncios.
- **Clips UGC**: una tanda de 6 escenas + 6 B-roll da 4-6 creativos sin generar nada más (escalera de
  variantes de la plantilla 2). Un hook nuevo es regenerar una sola escena.
- **Tomas de las plantillas 3 y 4**: no tienen idioma adentro. Otro mercado = otra voz + otro
  montaje, cero clips nuevos. Y el set de testeo (gancho, estructura, voz, corte) reusa los clips del
  semilla: 4-6 creativos por poco más que uno.
- **Voz**: si el usuario tiene ElevenLabs, fijar un `voiceId` por marca y no cambiarlo entre tandas.

## Al terminar una tanda
- Entregar los `.mp4` y los copys de Meta (texto primario, titular, descripción) por anuncio.
- **Si el usuario tiene un cerebro / base de notas**, registrar ahí lo reutilizable: los guiones y
  copys de cada anuncio con su ángulo y su hook, qué `id` de música y qué pozo de B-roll usó, y los
  prompts de íconos que ya existen en la biblioteca. Es lo que evita repetir un ángulo y lo que hace
  que la próxima tanda arranque de lo que funcionó. Sin cerebro, dejar ese resumen en
  `input/<campaña>/NOTAS.md`.

## Reglas
- Todo lo que gasta pide confirmación con el costo estimado e imprime lo facturado real al final.
  Desde Claude no hay terminal interactiva: `--si` (saltar la confirmación) se pasa SOLO después de
  mostrarle al usuario el costo de la tanda y tener su OK por escrito en el chat. Costos de referencia: A-roll / modo frame $0,14 · clip de una imagen
  $0,07 · imagen $0,0085 · música $0,05 · voz ~$0,01 por línea. Un anuncio UGC completo ≈ $1,3; una
  tanda de 7 anuncios de plantilla 1 ≈ $1; un anuncio de plantilla 3 o 4 de 7 tomas + 7 B-roll ≈ $1,1.
- En las plantillas 3 y 4 el gate de costo es **una sola pausa**: se entrega el paquete completo
  (guion, prompts, set de variantes, costo) y recién con el OK se genera. Nunca un clip suelto "de
  muestra" sin haber mostrado el costo del set.
- Nunca dos ejes en la misma variante del set; nunca tocar la oferta, el precio ni la garantía entre
  variantes.
- La narración va en el idioma objetivo. El CTA siempre empuja a tocar el botón del anuncio.
- Nunca copies media pesada a esta carpeta desde otros proyectos; referencia rutas.
- Si algo falla, primero `node scripts/doctor.mjs`, después la tabla de pozos de la receta y la
  sección «Problemas frecuentes» de `INSTALACION.md`.
