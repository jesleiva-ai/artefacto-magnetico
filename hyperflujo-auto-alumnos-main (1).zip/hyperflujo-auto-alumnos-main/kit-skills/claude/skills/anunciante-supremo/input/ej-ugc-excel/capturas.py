#!/usr/bin/env python3
"""B-roll de 'grabación de pantalla' de una planilla GENÉRICA (sin marca), 1080x1920, 30 fps.
Uso: capturas.py <carpeta-salida>  -> broll2.mp4 (fórmula) broll3.mp4 (tabla dinámica)
                                       broll4.mp4 (tablero) broll5.mp4 (archivos de práctica)
La franja central (y 820-1100) queda despejada: ahí van las captions del anuncio."""
import sys, subprocess, math, pathlib
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1080, 1920, 30
OUT = pathlib.Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
FF = "ffmpeg"
def F(sz, bold=False):
    return ImageFont.truetype("/System/Library/Fonts/Supplemental/" + ("Arial Bold.ttf" if bold else "Arial.ttf"), sz)

BG = (244, 246, 250); GRID = (214, 219, 228); HEAD = (232, 236, 243); TXT = (40, 45, 56)
ACC = (37, 99, 235); ACC2 = (16, 163, 127); SEL = (219, 234, 254); MUTE = (120, 128, 142)

def ease(t): t = max(0, min(1, t)); return t * t * (3 - 2 * t)

def enc(nombre, frames_fn, dur):
    n = int(dur * FPS)
    p = subprocess.Popen([FF, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                          "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", "-preset", "medium",
                          str(OUT / nombre)], stdin=subprocess.PIPE)
    for i in range(n):
        im = frames_fn(i / FPS, i / max(1, n - 1))
        p.stdin.write(im.tobytes())
    p.stdin.close(); p.wait()
    print("ok", nombre)

def chrome(d, titulo):
    # barra de app genérica: tres puntos + título del archivo; sin logos
    d.rectangle([0, 0, W, 150], fill=(30, 41, 59))
    for k, c in enumerate([(239, 68, 68), (245, 158, 11), (34, 197, 94)]):
        d.ellipse([40 + k * 44, 58, 70 + k * 44, 88], fill=c)
    d.text((200, 52), titulo, font=F(38, True), fill=(241, 245, 249))

def grilla(d, x0, y0, cols, filas, cw, rh, datos, sel=None, letras=True):
    # cabecera de columnas y números de fila
    d.rectangle([x0, y0, x0 + 70 + sum(cw), y0 + rh], fill=HEAD)
    x = x0 + 70
    for j, w in enumerate(cw):
        if letras: d.text((x + w / 2, y0 + rh / 2), "ABCDEFG"[j], font=F(30, True), fill=MUTE, anchor="mm")
        x += w
    for i in range(filas):
        y = y0 + rh * (i + 1)
        d.rectangle([x0, y, x0 + 70, y + rh], fill=HEAD)
        d.text((x0 + 35, y + rh / 2), str(i + 1), font=F(28), fill=MUTE, anchor="mm")
        x = x0 + 70
        for j, w in enumerate(cw):
            if sel == (i, j): d.rectangle([x, y, x + w, y + rh], fill=SEL)
            d.rectangle([x, y, x + w, y + rh], outline=GRID, width=2)
            v = datos[i][j] if i < len(datos) and j < len(datos[i]) else ""
            if v:
                b = (i == 0)
                num = isinstance(v, str) and (v[:1].isdigit() or v[:1] == "$")
                if num: d.text((x + w - 16, y + rh / 2), v, font=F(34, b), fill=TXT, anchor="rm")
                else: d.text((x + 16, y + rh / 2), v, font=F(34, b), fill=TXT, anchor="lm")
            x += w
        if sel and sel[0] == i:
            pass
    if sel:
        i, j = sel; x = x0 + 70 + sum(cw[:j]); y = y0 + rh * (i + 1)
        d.rectangle([x - 2, y - 2, x + cw[j] + 2, y + rh + 2], outline=ACC, width=6)

# ---------- 2: fórmula SUMA ----------
gastos = [["Día", "Concepto", "Monto"], ["Lunes", "Transporte", "1.250"], ["Martes", "Insumos", "3.480"],
          ["Miércoles", "Servicios", "2.900"], ["Jueves", "Insumos", "1.760"], ["Viernes", "Transporte", "1.310"],
          ["Sábado", "Varios", "640"], ["", "", ""], ]
FORM = "=SUMA(C2:C7)"
def f_formula(t, u):
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    chrome(d, "gastos-semana")
    # barra de fórmula
    d.rectangle([0, 150, W, 250], fill=(255, 255, 255)); d.line([0, 250, W, 250], fill=GRID, width=2)
    d.text((40, 200), "fx", font=F(40, True), fill=MUTE, anchor="lm")
    k = int(max(0, min(len(FORM), (t - 0.5) / 1.6 * len(FORM))))
    escrito = FORM[:k]
    hecho = t > 2.4
    d.text((120, 200), escrito + ("|" if (not hecho and int(t * 3) % 2 == 0) else ""), font=F(44), fill=TXT, anchor="lm")
    datos = [r[:] for r in gastos]
    if hecho: datos[7] = ["", "Total", "11.340"]
    else: datos[7] = ["", "Total", escrito]
    grilla(d, 40, 300, 3, 8, [300, 320, 270], 64, datos, sel=(7, 2))
    if hecho:
        a = ease((t - 2.4) / 0.5)
        y = int(1180 + 30 * (1 - a))
        col = tuple(int(BG[c] + (ACC2[c] - BG[c]) * a) for c in range(3))
        d.rounded_rectangle([140, y, 940, y + 300], 36, fill=col)
        d.text((540, y + 95), "Total de la semana", font=F(48, True), fill=(255, 255, 255), anchor="mm")
        d.text((540, y + 200), "11.340", font=F(110, True), fill=(255, 255, 255), anchor="mm")
    # zoom lento
    z = 1 + 0.06 * u
    return im.resize((int(W * z), int(H * z)), Image.LANCZOS).crop((int((W * z - W) / 2), 0, int((W * z - W) / 2) + W, H))

# ---------- 3: tabla dinámica ----------
import random
random.seed(7)
regiones = ["Norte", "Sur", "Centro", "Este", "Oeste"]
filas_crudas = [["Fecha", "Región", "Ventas"]] + [[f"{random.randint(1,28):02d}/0{random.randint(1,9)}", random.choice(regiones), f"{random.randint(120,980)}"] for _ in range(60)]
resumen = [("Norte", "48.210"), ("Sur", "39.775"), ("Centro", "61.040"), ("Este", "27.390"), ("Oeste", "33.615")]
def f_pivot(t, u):
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    chrome(d, "ventas-anuales")
    off = int(min(t, 1.8) / 1.8 * 40)  # scroll de filas crudas (miles de filas)
    vis = [filas_crudas[0]] + filas_crudas[1 + off:1 + off + 9]
    grilla(d, 40, 190, 3, 10, [260, 300, 300], 60, vis, letras=True)
    d.text((540, 880), "5.000 filas", font=F(40, True), fill=MUTE, anchor="mm")
    if t > 1.6:
        a = ease((t - 1.6) / 0.6)
        x0 = int(W - (W - 90) * a)
        d.rounded_rectangle([x0, 1100, x0 + 900, 1840], 30, fill=(255, 255, 255), outline=ACC, width=5)
        d.text((x0 + 40, 1160), "Resumen por región", font=F(46, True), fill=ACC, anchor="lm")
        for k, (r, v) in enumerate(resumen):
            if t > 2.0 + k * 0.22:
                y = 1250 + k * 100
                d.line([x0 + 40, y + 70, x0 + 860, y + 70], fill=GRID, width=2)
                d.text((x0 + 40, y + 35), r, font=F(44), fill=TXT, anchor="lm")
                d.text((x0 + 860, y + 35), v, font=F(44, True), fill=TXT, anchor="rm")
    return im

# ---------- 4: tablero ----------
base = [62, 48, 80, 55, 71]; nuevo = [62, 48, 80, 90, 71]
meses = ["Ene", "Feb", "Mar", "Abr", "May"]
def f_tablero(t, u):
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    chrome(d, "tablero-mensual")
    cambio = t > 2.3
    kpis = [("Ventas", "316" if not cambio else "351"), ("Clientes", "1.204"), ("Promedio", "63" if not cambio else "70")]
    for k, (n, v) in enumerate(kpis):
        x = 40 + k * 340
        d.rounded_rectangle([x, 200, x + 320, 420], 24, fill=(255, 255, 255))
        d.text((x + 30, 250), n, font=F(34), fill=MUTE, anchor="lm")
        hl = cambio and k != 1
        d.text((x + 30, 350), v, font=F(76, True), fill=(ACC2 if hl else TXT), anchor="lm")
    # gráfico de barras (abajo de la franja de captions)
    d.rounded_rectangle([40, 1120, 1040, 1860], 24, fill=(255, 255, 255))
    d.text((80, 1180), "Ventas por mes", font=F(40, True), fill=TXT, anchor="lm")
    g = ease(t / 1.2)
    for k in range(5):
        val = base[k]
        if cambio and k == 3: val = base[k] + (nuevo[k] - base[k]) * ease((t - 2.3) / 0.6)
        h = int(5.4 * val * g)
        x = 120 + k * 180
        d.rounded_rectangle([x, 1780 - h, x + 110, 1780], 14, fill=(ACC2 if (cambio and k == 3) else ACC))
        d.text((x + 55, 1815), meses[k], font=F(32), fill=MUTE, anchor="mm")
    # celda que cambia (arriba): el dato que dispara la actualización
    d.rounded_rectangle([40, 470, 1040, 760], 24, fill=(255, 255, 255))
    d.text((80, 530), "Datos", font=F(38, True), fill=TXT, anchor="lm")
    d.text((80, 620), "Abril", font=F(44), fill=TXT, anchor="lm")
    v = "55" if not cambio else ("90" if t > 2.45 else "")
    sel = t > 1.6
    if sel: d.rectangle([640, 585, 1000, 655], fill=SEL, outline=ACC, width=5)
    d.text((980, 620), v, font=F(48, True), fill=TXT, anchor="rm")
    d.text((80, 710), "se actualiza solo", font=F(34), fill=(ACC2 if cambio else MUTE), anchor="lm")
    return im

# ---------- 5: archivos de práctica ----------
lecciones = ["Día 1 · Primeros pasos", "Día 2 · Tablas y formato", "Día 3 · Fórmulas básicas", "Día 4 · Funciones útiles",
             "Día 5 · Tablas dinámicas", "Día 6 · Gráficos", "Día 7 · Tu tablero"]
def f_archivos(t, u):
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    chrome(d, "archivos de práctica")
    for k, n in enumerate(lecciones):
        ap = ease((t - 0.15 * k) / 0.4)
        if ap <= 0: continue
        y = 200 + k * 92 if k < 4 else 1150 + (k - 4) * 92  # salta la franja de captions
        x = int(40 + 60 * (1 - ap))
        d.rounded_rectangle([x, y, x + 1000, y + 78], 18, fill=(255, 255, 255))
        d.rounded_rectangle([x + 20, y + 14, x + 70, y + 64], 8, fill=ACC2)
        d.text((x + 45, y + 39), "▦", font=ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Unicode.ttf", 30), fill=(255, 255, 255), anchor="mm")
        d.text((x + 95, y + 39), n, font=F(38), fill=TXT, anchor="lm")
        if t > 1.6 + 0.2 * k:
            d.text((x + 960, y + 39), "✓", font=ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Unicode.ttf", 48), fill=ACC2, anchor="mm")
    return im


# ---------- 6: requisitos de un aviso de empleo genérico ----------
reqs = ["Manejo de planillas de cálculo", "Fórmulas básicas", "Tablas dinámicas", "Tableros con gráficos"]
def f_requisitos(t, u):
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    chrome(d, "aviso: asistente administrativo")
    d.rounded_rectangle([40, 200, 1040, 760], 28, fill=(255, 255, 255))
    d.text((90, 270), "Asistente administrativo/a", font=F(50, True), fill=TXT, anchor="lm")
    d.text((90, 340), "Jornada completa · Oficina", font=F(36), fill=MUTE, anchor="lm")
    d.line([90, 400, 990, 400], fill=GRID, width=3)
    d.text((90, 460), "Requisitos", font=F(42, True), fill=ACC, anchor="lm")
    d.text((90, 540), "Experiencia en atención al cliente", font=F(36), fill=MUTE, anchor="lm")
    d.text((90, 610), "Buena comunicación escrita", font=F(36), fill=MUTE, anchor="lm")
    d.text((90, 680), "Organización y puntualidad", font=F(36), fill=MUTE, anchor="lm")
    d.rounded_rectangle([40, 1120, 1040, 1700], 28, fill=(255, 255, 255), outline=ACC, width=5)
    d.text((90, 1190), "También se pide:", font=F(42, True), fill=ACC, anchor="lm")
    for k, r in enumerate(reqs):
        a = ease((t - 0.3 - 0.35 * k) / 0.35)
        if a <= 0: continue
        y = 1290 + k * 100
        x = int(90 + 40 * (1 - a))
        d.text((x, y), "✓", font=ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Unicode.ttf", 50), fill=ACC2, anchor="lm")
        d.text((x + 70, y), r, font=F(44, k > 0), fill=TXT, anchor="lm")
    z = 1 + 0.05 * u
    return im.resize((int(W * z), int(H * z)), Image.LANCZOS).crop((int((W * z - W) / 2), 0, int((W * z - W) / 2) + W, H))

import os
solo = os.environ.get("SOLO")
for nom, fn in [("broll2.mp4", f_formula), ("broll3.mp4", f_pivot), ("broll4.mp4", f_tablero), ("broll5.mp4", f_archivos), ("broll6.mp4", f_requisitos)]:
    if not solo or solo == nom: enc(nom, fn, 4.4)
