#!/usr/bin/env python3
"""Ejemplo: anuncio estilo VIRAL para «Pan de Casa» (guía digital de masa madre, inventado).
Estilo viral (STYLE_IMG/STYLE_VID, modo frame inicio→fin + B-roll, bucles abiertos)
y cierra como ANUNCIO: mockup de la guía + CTA al botón (sin «síguenos»).
Datos de panificación (verdaderos y verificables):
  1) masa madre = harina + agua; levaduras salvajes y bacterias lácticas fermentan y sueltan CO2 (burbujas).
  2) prueba de la ventana (windowpane): el gluten bien desarrollado se estira en una membrana translúcida que atrapa el gas.
  3) vapor en el horno: mantiene la superficie húmeda y elástica los primeros minutos → el pan crece más (oven spring)
     y la corteza sale brillante."""
import json, pathlib

D = pathlib.Path(__file__).resolve().parent
SLUG = "ej-viral-pan"
VOZ = ""
B2 = "Pero eso no es nada."
STYLE_IMG = (", the scene crowded with several extra small Pixar-style cartoon characters with big eyes reacting with "
             "over-the-top exaggerated expressions, ultra saturated colors, no people, no human hands, every character an "
             "original design, no characters from existing movies, games or brands, absolutely no signs, no labels, no packaging with words, no written words or letters anywhere in the image")
STYLE_VID = ", constant energetic motion, every cartoon character moving and reacting the whole time"

ITEMS = [  # (texto, img inicio, img fin, mov, broll img, broll mov)
 ("Ni se te ocurra dejar harina y agua en un frasco unos días, a menos que quieras criar tu propia levadura salvaje: millones de microbios que llenan la masa de burbujas.",
  "A glass jar on a rustic wooden kitchen counter holding a flat thick paste of flour and water with a sleepy bored cartoon face on its surface, a linen cloth and a plain wooden bowl of flour beside it, soft morning window light",
  "The same glass jar on the same counter, the paste now risen to the very top, foamy and full of big bubbles, tiny round cartoon yeast characters inside the bubbles cheering, the paste with a proud bursting face, flour dust floating in the light",
  "Camera locked off. Motion: bubbles form everywhere and the paste rises up to the top of the jar",
  "Extreme macro of the bubbly surface of a sourdough starter, tiny round cartoon yeast characters blowing gas bubbles like bubble gum, warm golden light",
  "Camera: slow push-in. Motion: the yeast characters blow bubbles that grow and pop"),
 (B2 + " No estires un pedacito de masa contra la luz, a menos que quieras ver el secreto del pan esponjoso: una red de gluten tan fina que la atraviesa la luz.",
  "A smooth round ball of bread dough with a grumpy cartoon face resting on a floured wooden board, several tiny cartoon bread-roll characters gathered around it gripping its edges, bright kitchen window behind",
  "The same dough on the same board, now stretched by the tiny bread-roll characters into a thin translucent membrane like a sail, warm window light glowing through it, a fine web of strands visible inside, the dough with an amazed face",
  "Camera locked off. Motion: the tiny characters pull the dough wider and thinner until light shines through it",
  "Extreme macro inside bread dough: a stretchy elastic web of gluten strands like a net holding shiny round gas balloons, tiny cartoon characters bouncing on the net like a trampoline, warm golden light",
  "Camera: slow drift. Motion: the net stretches and the characters bounce"),
 ("Y el último es el más loco: ni se te ocurra poner un recipiente con agua en el horno, a menos que quieras que tu pan crezca de golpe: el vapor mantiene la corteza blanda unos minutos más.",
  "A pale round raw sourdough loaf with an excited eager smiling cartoon face sitting on a baking tray inside a glowing hot home oven, a small metal pan of water on the rack below, cheerful fluffy white cartoon steam cloud characters rising around the loaf, the only other characters are tiny bread-roll characters, no fire or flame characters, no water drop characters",
  "The same oven interior, the loaf now risen tall and burst open along its score into a golden crackly glossy crust with a crispy ear, the loaf with a triumphant proud face, the fluffy white steam cloud characters and tiny bread-roll characters cheering, no fire or flame characters, no water drop characters",
  "Camera locked off. Motion: the steam swirls, the loaf puffs up tall and its crust turns golden",
  "Extreme macro of a freshly baked sourdough loaf cooling on a wooden board, steam rising from the open airy crumb full of big holes, tiny cartoon crumb characters peeking out of the holes, warm light",
  "Camera: slow push-in. Motion: steam rises and the crumb characters wave"),
]
CIERRE = [
 "Esto, y cómo hacer y mantener tu masa madre paso a paso, está en Pan de Casa: una guía digital con 60 recetas y un calendario de horneado.",
 "Toca el botón y descárgalo hoy.",
]

assert B2 in ITEMS[1][0] and ITEMS[2][0].startswith("Y el "), "faltan los bucles abiertos"
# tomas que Veo bloqueó en modo frame (content safety ×4): van imagen → video simple, sin «fin» ni sufijo de video
SIMPLE = {"t03"}
lineas, tomas, broll = [], [], []
for i, (txt, ini, fin, mov, bimg, bmov) in enumerate(ITEMS, 1):
    lineas.append({"n": i, "texto": txt, "toma": f"t{i:02d}", "broll": f"b{i:02d}"})
    if f"t{i:02d}" in SIMPLE:
        tomas.append({"id": f"t{i:02d}", "imagen": ini + STYLE_IMG, "video": "Camera: slow push-in. Motion: soft steam swirls around the loaf, the loaf puffs up and rises taller and its face beams with pride"})
    else:
        tomas.append({"id": f"t{i:02d}", "imagen": ini + STYLE_IMG, "fin": fin + STYLE_IMG, "video": mov + STYLE_VID})
    broll.append({"id": f"b{i:02d}", "imagen": bimg + STYLE_IMG, "video": bmov + STYLE_VID})
for j, txt in enumerate(CIERRE, len(ITEMS) + 1):  # el cierre va sobre el mockup (m01/m02, ken burns hecho con ffmpeg)
    lineas.append({"n": j, "texto": txt, "toma": "t03", "broll": "b03"})
g = {"title": "Ejemplo viral — Pan de Casa", "slug": SLUG, "estilo": "viral", "idioma": "es",
     "voz": {"elevenlabs": {"voiceId": VOZ}}, "lineas": lineas, "tomas": tomas, "broll": broll}
(D / "guion.json").write_text(json.dumps(g, ensure_ascii=False, indent=2))
print([len(l["texto"].split()) for l in lineas], "palabras por línea;", sum(len(l["texto"].split()) for l in lineas), "en total")
