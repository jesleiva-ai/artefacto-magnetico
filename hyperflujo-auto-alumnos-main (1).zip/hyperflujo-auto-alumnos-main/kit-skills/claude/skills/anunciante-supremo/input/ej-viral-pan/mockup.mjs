// Mockup de la guía (gpt-image-2 por APIMART) → m01.png en la carpeta de frames del slug.
//   node input/ej-viral-pan/mockup.mjs [sufijo]
import { writeFileSync, mkdirSync } from "node:fs";
import * as apimart from "../../scripts/lib/apimart.mjs";

const dir = new URL("../../public/media/_clips/ej-viral-pan/frames/", import.meta.url).pathname;
mkdirSync(dir, { recursive: true });
const prompt = `Hyperrealistic product mockup photograph, vertical 9:16. A modern e-reader standing upright on a rustic wooden kitchen table, its screen showing the cover of a digital recipe book. The cover is clean and elegant: a warm photo of a golden crusty sourdough loaf on a cream background, the title "Pan de Casa" in large elegant dark brown serif letters at the top of the cover, and below it a smaller line "Guía de masa madre". Exactly those words and no other text on the cover. Next to the e-reader: a real crusty sourdough loaf, a glass jar of bubbly sourdough starter and a little scattered flour. Two small original cute Pixar-style cartoon bread-roll characters with big happy eyes peeking from behind the loaf, original designs, not from any existing movie or brand. Soft morning window light, shallow depth of field, warm saturated colors. No people, no hands, no logos, no brand names, no price, no other text anywhere, no watermark.`;
const r = await apimart.generarImagen({ prompt, aspectRatio: "9:16" });
const out = `${dir}m01${process.argv[2] || ""}.png`;
writeFileSync(out, await apimart.descargar(r.url));
console.log("ok", out, "costo", r.cost);
