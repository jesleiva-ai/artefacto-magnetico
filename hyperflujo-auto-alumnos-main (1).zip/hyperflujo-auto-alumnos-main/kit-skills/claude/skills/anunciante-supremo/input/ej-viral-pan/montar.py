#!/usr/bin/env python3
"""Escribe ad-01.json (3 casos: toma frame + B-roll; cierre sobre el mockup m01/m02) y monta out/ej-viral-pan/anuncio.mp4.
Cierre de ANUNCIO (producto + CTA) en vez de «síguenos»."""
import json, pathlib, subprocess, sys

SK = pathlib.Path(__file__).resolve().parents[2]
SLUG = "ej-viral-pan"
g = json.loads((SK / "input" / SLUG / "guion.json").read_text())
n = len(g["lineas"])
beats = []
for i, l in enumerate(g["lineas"], 1):
    if i == n - 1:      # línea de producto: plano general del mockup → acercamiento a la portada
        planos = [["m01"], ["m02"]]
    elif i == n:        # CTA: portada en grande
        planos = [["m02"]]
    else:
        planos = [[l["toma"]], [l["broll"]]]
    beats.append({"linea": l["texto"], "voz": f"l{i:02d}.mp3", "planos": planos})
plan = {"title": g["title"], "slug": SLUG, "estilo": "viral", "idioma": "es",
        "clips": f"../../public/media/_clips/{SLUG}/clips", "voz": f"../../public/media/_clips/{SLUG}/voz", "beats": beats}
(SK / "input" / SLUG / "ad-01.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2))
(SK / "out" / SLUG).mkdir(parents=True, exist_ok=True)
r = subprocess.run(["node", "scripts/montar.mjs", f"input/{SLUG}/ad-01.json", "--salida", f"out/{SLUG}/anuncio.mp4", *sys.argv[1:]],
                   cwd=SK, capture_output=True, text=True)
print(r.stdout[-2500:], r.stderr[-1500:])
sys.exit(r.returncode)
