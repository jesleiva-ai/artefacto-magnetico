# Hooks — receta transversal (vale para las dos plantillas)

Fuente: "The Psychology of Killer Hooks" (Kallaway, 2026) — *interrupt theory*, adaptado a anuncios
de infoproductos en Meta (CTA al botón). Leer ANTES de escribir el `hook` y las primeras frases de
`narration` (plantilla 1) o el `dialogo` de la escena 1 (plantilla 2).

## 1. Qué tiene que lograr el hook (interrupt theory)
El pulgar va a toda velocidad. El hook existe para provocar un **freeze** (respuesta de orientación:
"espera, ¿qué fue eso?") y en ese segundo responder DOS preguntas en la cabeza del viewer:

1. **¿De qué va esto?** → *Sujeto*
2. **¿Qué gano si me quedo?** → *Stakes* (lo que está en juego / el resultado)

Si cualquiera de las dos queda sin responder, no hay hook. Los 4 ingredientes ("4 S"):

| Ingrediente | Regla | Falla típica |
|---|---|---|
| **Sujeto** | Se entiende al instante de qué/quién se habla (el nicho, el oficio, el objeto). | Hooks sin sujeto: "Te lo abro ahora", "Dos minutos y decides", "Estaba por dejarlo". Solos no dicen de qué va. |
| **Stakes** | El viewer tiene una razón para que le importe: dolor que evita o resultado que quiere. | Hooks que solo describen: "¿Qué hay adentro?" — no hay apuesta. |
| **Speed** | Compresión, no velocidad: menos palabras, misma idea. 8 palabras > 28. | Hooks de frase larga con subordinadas. |
| **Súper claro** | Una sola interpretación posible. Sin juegos de palabras, sin misterio vago. Si tiene que pensar medio segundo, se fue. | "La brecha que nadie te cuenta" — ¿qué brecha? No se entiende sin contexto. |

## 2. Los tres hooks se escriben juntos y ALINEADOS
En las plantillas cada hook vive en un campo distinto:

| Hook | Dónde vive | Qué es |
|---|---|---|
| **Texto** (el más importante) | `hook` (plantilla 1) | Titular en pantalla los primeros 3-5 s. Los ojos buscan texto antes de entender la imagen. |
| **Hablado** | primeras 1-2 frases de `narration` (plantilla 1) · `dialogo` de la escena 1 (plantilla 2) | Lo que dice la voz mientras el texto está en pantalla. |
| **Visual** | plantilla 1: primer b-roll (`brollStart`) · plantilla 2: el primer cuadro de la escena 1 (`accion`) | Lo que se ve. |

**Test de alineación (obligatorio):** tapando uno de los tres, ¿se adivinan aproximadamente los otros
dos? Si el texto dice "60 fichas, un solo archivo" y la voz abre con "Hay un momento que todo terapeuta
conoce...", NO están alineados: el viewer ve una cosa y escucha otra. Elegir `brollStart` mirando el
clip con el que abre, no al azar: el clip 0 tiene que mostrar el sujeto (el entrenador explicando, la
planta de balcón sin flores, el terapeuta en consulta).

## 3. Fórmula del hook de TEXTO (`hook`)
> **Repetidor de sujeto + UNA de: recordatorio de dolor · teaser de resultado · cambio de estado**

- **Repetidor de sujeto**: el nombre propio / término técnico / jerga del nicho. Los nombres son imanes
  de atención, más en MAYÚSCULAS. Ej.: *Anatomía aplicada*, *Masa madre*, *Huerta en balcón*,
  *Fisioterapia*, *Entrenador personal*.
- **Recordatorio de dolor**: el dolor que el anuncio resuelve. *"sin saber qué músculo trabaja"*,
  *"tres temporadas de semillas, cero flores"*.
- **Teaser de resultado**: el resultado que quiere. *"explica cada ejercicio con seguridad"*,
  *"3 tallos nuevos en 6 semanas"*.
- **Cambio de estado**: algo cambió en el campo y el futuro es distinto. *"el método que cambió cómo
  se enseña anatomía"*, *"nuevo protocolo 2026"*.

Lo que se busca es un **hueco de curiosidad**: lo que sabe hoy vs. el resultado que quiere mañana.

### Ejemplos re-escritos con la fórmula (mismo ángulo, mejor hook)
El `|` marca el corte de línea (ver §4.2). Los ejemplos están en varios idiomas a propósito: la fórmula
es la misma en todos.

- `Let me open it` → `Sourdough: 60 recipes | ready by Sunday` — agrega sujeto + resultado + número.
- `Dois minutos e você decide` → `Horta na varanda: colheita | em 8 semanas` — sujeto + resultado; el número queda.
- `¿Sabes qué músculos trabajas?` → `Entrenador: ¿qué músculo | trabaja este ejercicio?` — sujeto explícito (filtra al avatar).
- `What's inside?` → `Travel English in 30 days | no textbooks` — stakes + número específico.
- `La brecha que nadie te cuenta` → `Ed. Física: lo que la facultad | no te enseñó` — claridad: se entiende solo.

## 4. Reglas duras del hook de texto
1. **Máximo 2 líneas** (fuente de sistema). Tres líneas nunca.
2. **Cortar la línea donde la frase se lee natural.** La plantilla acepta `|` dentro de `hook` para
   forzar el corte: `"Masa madre: 60 recetas | para el próximo domingo"`. "El próximo domingo" es
   una unidad; no se parte. Sin `|` el corte es automático (puede caer mal).
3. **Números específicos** siempre que existan: *21 días* > *unas semanas*; *140 ejercicios* > *muchos
   ejercicios*; *3 temporadas* > *mucho tiempo*.
4. **Power words**: 1-3 palabras que amplifican el dolor o el resultado y comprimen una frase entera.
   *"científicamente imposible de saltar"*, *"máquina de vender"*, *"cero flores"*. Ver §6 para minarlas.
5. **Sin puntuación** salvo comillas o paréntesis. Un `:` o `|` para separar sujeto de stakes está bien;
   no cerrar con punto. *(Un hook con "." tipo "21 días. Fisioterapia completa." se lee como frase, no
   como trigger. Preferir la forma compacta.)*
6. **Sin conectores ni muletillas**: nada de "y", "pero", "entonces", "que", "por eso". No es una frase,
   son palabras gatillo.
7. **3 segundos mínimo en pantalla** (`hookSeconds` 3-5). Si se acorta pierde efecto: el viewer mira el
   centro, sube a leer, baja a ver el b-roll, vuelve a leer.
8. **No tapar el sujeto visual**: el panel va al tercio superior (`hookPosition: "top"`). Si el b-roll de
   apertura tiene una cara, que el hook no tape ojos ni boca (elegir clip de apertura con eso en mente).

## 5. Hook HABLADO (primeras frases de `narration` / escena 1)
Dos componentes: **formato** + **power words**.

**Formatos que rinden** (estructura gramatical; remixar variables, no copiar):
- Pregunta al avatar: *"¿Te da vergüenza que un alumno te pregunte X y no saber responder?"*
- Tutorial / cómo: *"Así es como explicas cualquier ejercicio en 10 segundos"*
- Problema → solución: *"Si estudias anatomía saltando de un apunte a otro, esto te va a ahorrar meses"*
- Secreto / revelación: *"Los entrenadores mejor pagados no venden rutinas, venden explicaciones"*
- Tarea grande en tiempo chico: *"Toda la fisioterapia aplicada en 21 días"*
- Historia en 1 frase: *"Tenía el certificado y tres clientes"*
- Filtro / psicología inversa: *"Si no entrenas a nadie, este video no es para ti"*

**Nivel 1 (remix de formato):** tomar el formato de un hook ganador y cambiar las variables.
**Nivel 2 (remix de power words):** detectar la frase que hizo ganar al hook y torcerla manteniendo la
psicología: *"imposible de saltar"* → *"imposible de ignorar"* → *"imposible de olvidar"*.
Lo que se hace es: formato torcido + power word torcida → hook nuevo pero respaldado por datos.

Longitud del hook hablado: **8-15 palabras**. Debe decir lo mismo que el hook de texto (o completarlo),
nunca otra cosa.

## 6. De dónde minar formatos y power words (data-driven)
No inventar de cero. Antes de escribir una tanda:
1. **Si tienes un cerebro / base de notas del producto**: los hooks de tus anuncios ganadores (anotar la
   frase que "tiene jugo"), los ángulos ya validados en otros productos del mismo nicho, y el copy de
   referencia de la competencia que guardaste.
2. Si no: mirar 10 anuncios activos del nicho en la Biblioteca de anuncios de Meta y anotar los hooks
   que se repiten entre anunciantes distintos (si varios lo usan, funciona).
3. Listar 5-10 power words del nicho, escribir 3-5 torsiones de cada una, y combinarlas con los formatos.

## 7. Zona de anclaje (los 5-10 segundos DESPUÉS del hook)
El hook solo consigue una oportunidad. Las **2-4 frases siguientes** deciden si se queda. En esa ventana
el espectador hace dos cosas, siempre:
1. **Confirma la promesa**: que el video va de lo que dijo el hook (no bait-and-switch). La primera frase
   después del hook retoma el sujeto + stakes con otras palabras.
2. **Evalúa confianza rápido**: ¿me va a hacer perder el tiempo? Palancas:
   - **Prueba / ancla de confianza (la más importante)**: número concreto de entregables ("140 ejercicios
     analizados"), resultado medible ("3 tallos en 6 semanas"), testimonio, captura, estudio. Ponerla
     en la frase 2 o 3, no al final.
   - **Packaging**: calidad del b-roll de apertura, voz limpia, captions legibles. Un clip feo en los
     primeros 5 s = no hay confianza.
   - **Relatabilidad**: hablar como el avatar (su jerga, su escena: "el alumno te pregunta...",
     "domingo por la noche buscando material"). La voz tiene que sonar como alguien de ese mundo y del
     mercado (acento correcto).

Estructura recomendada de `narration` en la plantilla 1 (y de las escenas en la 2):
`[hook hablado, 1-2 frases] → [anclaje: confirmar + prueba, 2-4 frases] → [agitación] → [mecanismo /
entregables] → [bonos / precio / garantía] → [CTA al botón]`.

## 8. Checklist antes de renderizar
- [ ] `hook` tiene **sujeto** + **stakes** y se entiende sin ver el video.
- [ ] ≤ 2 líneas, corte con `|` donde la frase lo pide, sin punto final, sin conectores.
- [ ] Una sola cosa enfatizada con `*…*` (el número o la power word). `hookStyle: "system"`, `hookPosition: "top"`, `hookSeconds` 3-5.
- [ ] Hay un número específico o una power word.
- [ ] Hook hablado (frase 1-2 de `narration` / escena 1) dice lo mismo que el texto.
- [ ] El b-roll o el primer cuadro de apertura muestra el sujeto (revisar `brollStart` / `accion`).
- [ ] Frases 2-4 confirman la promesa y traen una prueba concreta.
- [ ] Dentro de una tanda, cada anuncio cambia ángulo+hook, pero TODOS cumplen la fórmula.

## 9. Diseño VISUAL del text hook (lo que se ve en los ganadores del video)
Observado cuadro a cuadro en los ejemplos que muestra Kallaway:

| Patrón observado | Qué hace la plantilla 1 |
|---|---|
| **Caja blanca redondeada, texto negro, fuente de sistema, caja normal (no mayúsculas)** — el text hook "nativo" de IG/TikTok. Es el que más rápido leen los ojos porque el feed ya lo entrenó. | `hookStyle: "system"` (Inter 800 negro sobre blanco). Recomendado. El panel oscuro + Anton queda como `"panel"`. |
| **Posición: tercio superior**, encima de la cabeza del sujeto. Nunca tapa ojos/boca ni el objeto del b-roll. Las captions viven abajo, chicas y separadas. | `hookPosition: "top"` (≈ 430 px desde arriba en 1080×1920). Recomendado. |
| **Una sola palabra/número enfatizado** en color contrastante y más grande: "1 MILLION" amarillo, "FULL MONTH" verde-amarillo. El resto queda neutro. | `*palabra*` en el `hook` → color de acento (`hookAccent`, default rojo en caja blanca / amarillo en panel) y ~20 % más grande, sin partirse de línea. Enfatizar **una** cosa: el número o la power word. |
| **2 líneas** en fuente de sistema. | El corte va con `\|`. La fuente se auto-achica si una línea es larga — pero eso es síntoma de hook largo: acortar, no confiar en el ajuste. |
| **Dura 3-5 s.** | `hookSeconds` 3-5 (se clampa a ese rango). |
| **Tamaño legible en celular a 20 cm.** | `system`: 80 px base / 96 px énfasis. Regla: **máx. ~22 caracteres por línea y hasta 3 líneas** con `\|` — partir la frase antes que dejar que la fuente se achique. |
| **Hook auditivo**: un sonido al aparecer el título. Evitar graves puros (no se oyen en parlante de celular/laptop): preferir medios-agudos 800-3000 Hz. | `introSfx` en el brief: `intro-rev` (reversa, control), `crystal-bell` (campana de cristal, revelación), `glitch` (ráfaga digital, corte), `riser`, `whoosh`. |
| **Hook visual 80/20**: mover el cuerpo, mover el visual, o mover el texto sobre la toma. | El hook ya entra animado (spring desde arriba). El clip de apertura (`brollStart`) tiene que tener movimiento o un objeto claro — no un plano estático. |

Brief recomendado:
```json
"hook": "Personal trainer: | *140 ejercicios* explicados",
"hookStyle": "system", "hookPosition": "top", "hookSeconds": 4
```
