# Plantilla 1 — "B-roll + voz en off"

Composición Remotion: **`plantilla-1`** · código en `src/templates/t1/` · **velocidad final 1.25x**.

Anuncio vertical (1080×1920) montado sobre **b-rolls de video real** a pantalla completa que cortan
cada ~1.5 s, con **voz en off**, **captions karaoke NEGRO sobre BLANCO**, un **título-gancho** los
primeros 3-5 s, **música instrumental**, **resaltes** breves con **campanita**, y un **efecto de
intro en reversa** (suspenso). Ritmo alto y muy auditivo.

## Insumos que hay que tener antes
- **B-rolls** en `public/broll-<slug>/` como `broll-01.mp4`, `broll-02.mp4`, … (verticales 9:16).
  **La vía normal es descargarlos**: 10-15 clips del tema del anuncio (bancos de clips como Pexels o
  Pixabay, capturas de pantalla del producto, material propio), de 5-15 s, en una carpeta cualquiera.
  Después: `npm run prep:broll -- --desde "<esa carpeta>" --a public/broll-<slug>` — los renombra,
  los lleva a 1080×1920 (recorte al centro, sin deformar) y les quita el audio. Un buen pozo tiene
  variedad: manos, monitores, el producto, la persona del avatar en su escena, un pulgar tocando.
  **Alternativa, si no quieres buscar clips**: generarlos con APIMART (6-10 clips, $0,07 cada uno):
  `npm run gen:broll -- --prompts input/<campaña>/broll.json --out public/broll-<slug> --nombre broll-`.
  En los dos casos el audio del b-roll se ignora.
- **Una pista de música** en la biblioteca `public/media/_music/music-<id>.mp3`. Se crea una vez y se
  reusa: `npm run gen:musica -- --id <id> --prompt "<estilo en inglés>"`.
- **Guion + datos** del anuncio en `input/<campaña>/ad-NN.json` (ver esquema abajo).

## Esquema — `input/<campaña>/ad-NN.json`
```json
{
  "title": "Nombre corto",
  "slug": "campana-ad1",
  "idioma": "es",             // código ISO del idioma de la narración (lo usa la transcripción)
  "hook": "Sujeto: | *número o power word* resultado",
  "hookStyle": "system",      // "system" = caja blanca/texto negro (recomendado) · "panel" = panel oscuro Anton
  "hookPosition": "top",      // "top" = tercio superior (recomendado) · "center"
  "hookSeconds": 4,           // 3-5 (se clampa)
  "introSfx": "intro-rev",    // hook AUDITIVO al aparecer el título: intro-rev | crystal-bell | glitch | riser | whoosh
  "music": "pop-1",           // id de public/media/_music/music-<id>.mp3 — créala con gen:musica
  "hookAccent": null,         // color hex de las *palabras* enfatizadas; null = rojo (system) / amarillo (panel)
  "brollDir": "public/broll-<slug>",   // carpeta de b-rolls (default public/broll)
  "brollStart": 0,            // con qué clip abre (índice); cada anuncio de la tanda abre con otro
  "narration": "Todo el guion en el idioma objetivo, como UN texto corrido (la voz es una sola narración).",
  "highlights": [
    { "word": "palabraDelGuion", "prompt": "icon subject in English" }
  ]
}
```
### Reglas de autoría
- **narration**: un solo bloque de texto en el idioma objetivo. Evitar comillas „" y guiones largos —
  cambiarlos por coma/punto para que la voz no tropiece.
- **hook**: aparece grande sobre el b-roll los primeros 3-5 s. Se escribe con la fórmula de
  `plantillas/hooks.md`: **sujeto + dolor/resultado/cambio de estado**, número específico o power word,
  ≤ 2 líneas, sin punto final ni conectores. Acepta `|` para forzar el corte de línea
  (`"Entrenador: ¿qué músculo | trabaja este ejercicio?"`) y `*palabra*` para el énfasis. Las primeras
  1-2 frases de `narration` dicen lo mismo (hook hablado) y las 2-4 siguientes confirman la promesa con
  una prueba concreta (zona de anclaje). `brollStart` se elige para que el clip de apertura muestre el
  sujeto del hook.
- **highlights**: pocos (~4-6), breves y puntuales. Cada uno se ata a una `word` EXACTA de la narración
  y aparece ~1.2 s con campanita. Son íconos con fondo transparente (gpt-image-2) — mantenerlos
  puntuales, no saturar. Con `"highlights": []` no hay resaltes.
- **Voz**: sale de `src/brand.json` → `voz.apimart` (voz `nova` por defecto e `instructions` con el
  tono; probar `shimmer`, `alloy`, `echo`) o, si hay `ELEVENLABS_API_KEY` y `voz.elevenlabs.voiceId`,
  ElevenLabs. Elegir una voz cálida con energía de locutor: un anuncio pide energía, no solo corrección.
- **CTA**: la última frase debe empujar a tocar el botón del anuncio.
- **B-roll**: se auto-secuencia (cortes de 1.4–1.9 s, rotando clips, con arranque aleatorio). El timeline
  queda guardado en `src/data/t1.json` y NO se re-mezcla en re-generaciones (estable).

## Sonido — niveles calibrados en `src/templates/t1/AdT1.tsx`
- **Voz**: volume 1.4 (+3 dB), previamente nivelada a −5,1 dB de pico.
- **Música** instrumental: volume 0.22.
- **Intro en reversa** (`public/sfx/intro-rev.mp3`, riser invertido): volume 0.3, primeros ~1 s.
- **Campanita** en cada resalte (`public/sfx/pop-bell.mp3`): volume 0.4 (en `HighlightsT1.tsx`).

## Detalles visuales
- B-roll a pantalla completa (`objectFit: cover`) con leve zoom continuo. `premountFor` evita cuadros
  negros al cambiar de clip. (En el preview de Studio puede haber micro-saltos; el render sale limpio.)
- Captions negro sobre blanco, palabra activa **invertida** (blanco sobre caja negra), centradas abajo.
- Hook: dos estilos en `src/templates/t1/HookTitle.tsx` — `system` (caja blanca, Inter 800 negro, caja
  normal, tercio superior) y `panel` (panel oscuro semitransparente + Anton blanco mayúsculas, centro).
  Entra con rebote y sale; 3-5 s. `*palabra*` = énfasis en color de acento, no se parte de línea. La fuente
  se auto-ajusta a la línea más larga (si se achica mucho, el hook es largo: acortarlo). Ver `hooks.md` §9.

## Pipeline exacto
```bash
npm run gen:musica -- --id pop-1 --prompt "upbeat pop rock, 118 BPM"       # una vez; se reusa por id
npm run prep:broll -- --desde "<carpeta con clips descargados>" --a public/broll-<slug>   # lo normal
npm run gen:broll -- --prompts input/<campaña>/broll.json --out public/broll-<slug> --nombre broll-   # alternativa por APIMART
npm run batch:t1 input/<campaña> out/<campaña>     # por cada ad-NN.json: voz + resaltes + timeline → render → 1.25x → CFR 30
```
`batch:t1` es reanudable: la voz y el timeline de cada anuncio quedan archivados en
`public/media/_ads/<slug>/`, y un anuncio que ya tiene `.mp4` se salta (`FORCE=1` para rehacerlo).
Para un solo anuncio a mano: copiar el brief a `input/ad-t1.json`, la música a `public/media/t1/music.mp3`,
`npm run assets:t1`, `npm run render:t1`, `npm run speed 1.25 out/t1.mp4 out/<slug>.mp4`.

> Si la pista de la biblioteca tiene voz aunque se pidió instrumental:
> `npm run gen:musica -- --id <id> --prompt "..." --forzar` (cada intento sale distinto).

## Qué se reusa entre anuncios (y qué se paga una sola vez)

| Recurso | Dónde vive | Cómo se reusa |
|---|---|---|
| **Música** | `public/media/_music/music-<id>.mp3` | por `id` en el brief; la misma pista sirve para toda una tanda y para la plantilla 2 |
| **B-roll** | `public/broll-<slug>/` | por `brollDir`; un pozo de 10-15 clips alimenta todos los anuncios de un producto, y `brollStart` hace que cada uno abra distinto |
| **Íconos de resalte** | `public/media/lib/<slug-del-prompt>-cut.png` | **automático**: cada ícono generado se guarda ahí y, si otro anuncio pide el mismo `prompt`, se copia sin pagar. También por nombre con `"reuse": "<slug>"` en el highlight |
| **Voz y timeline de cada anuncio** | `public/media/_ads/<slug>/` | `batch:t1` es reanudable: si el render falla, la voz no se vuelve a generar |
| **SFX** | `public/sfx/` | vienen con la skill |

Lo único que se paga por cada anuncio nuevo es la voz (~$0,01) y los íconos que no existan todavía.
Con la biblioteca llena, una tanda de 7 anuncios sale por menos de $0,10. Conviene escribir los
`prompt` de los íconos de forma estable ("a flexed arm muscle icon") para que se reencuentren.

## Variaciones de la plantilla 1
Una tanda = **un guion ganador × 5-7 ángulos**, no 7 guiones nuevos. Lo que se varía sin tocar código:

| Campo | Valores | Para qué |
|---|---|---|
| `hookStyle` | `system` · `panel` | caja blanca nativa (recomendado) vs. panel oscuro |
| `hookPosition` | `top` · `center` | tercio superior (recomendado) vs. centro |
| `introSfx` | `intro-rev` · `crystal-bell` · `glitch` · `riser` · `whoosh` | el hook auditivo |
| `hookAccent` | hex | color del énfasis |
| `brollStart` | índice | cada anuncio abre con otro clip (y el clip de apertura muestra el sujeto del hook) |
| `brollDir` | carpeta | otro pozo de b-roll para otro producto o mercado |
| `highlights` | lista o `[]` | con o sin resaltes |
| `noMusic` | `true` | sin música (casos raros) |
| `music` | id | otra cama para otro registro (confesión 60-75 BPM, urgencia 90-125) |

## Archivos clave
- `src/templates/t1/AdT1.tsx` — composición (b-rolls, audios, hook).
- `src/templates/t1/HookTitle.tsx` — título gancho.
- `src/components/CaptionsT1.tsx` — captions negro/blanco karaoke.
- `src/components/HighlightsT1.tsx` — resaltes breves + campanita.
- `scripts/gen-t1.mjs` — generación de recursos · `scripts/lib/voz.mjs` — voz (APIMART o ElevenLabs) ·
  `scripts/batch-t1.mjs` — la tanda · `scripts/gen-broll.mjs`, `scripts/gen-musica.mjs` — insumos.
