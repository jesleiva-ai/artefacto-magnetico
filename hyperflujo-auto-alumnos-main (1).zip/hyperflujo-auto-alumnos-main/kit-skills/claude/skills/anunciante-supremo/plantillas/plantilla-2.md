# Plantilla 2 — "UGC A-roll cosido"

Sin composición Remotion — motor **ffmpeg puro** · código en `scripts/ensamblar-t2.mjs` +
`scripts/lib/*-t2.mjs` · **velocidad 1.18x**, aplicada en el mismo ensamblado (no hay paso de
`speed` aparte, como en la plantilla 1).

Anuncio vertical (1080×1920) cosido a partir de **clips de A-roll UGC con el diálogo ya grabado y
sincronizado a los labios** (los genera `npm run gen:aroll` con APIMART, Veo 3.1 en modo frame). No hay
guion que convertir en voz: el hook, la narración y el CTA ya están adentro del video. Se recorta
la cola muerta de cada clip, se pegan a tope uno detrás de otro, se aceleran a 1.18x conservando el
tono, se les superpone B-roll sobre la palabra que ilustran, se queman captions blancas centradas
palabra por palabra, y se mezcla la música de fondo baja. **Sin Remotion** — ffmpeg cortando,
acelerando, superponiendo y quemando texto en una sola pasada.

## Insumos previos

- Una carpeta con los clips fuente: `escena1.mp4 … escenaN.mp4` (A-roll 9:16 con el diálogo
  grabado) y `broll1.mp4 … brollM.mp4` (los insertos; su audio se ignora, no hace falta mutearlo a
  mano). Los genera **`gen-aroll`** (ver «Generar los clips» abajo); el ensamblador solo los cose.
  También sirven clips grabados por una persona real, mientras sean 9:16 y el brief diga exactamente
  lo que dicen.
- La música de fondo. Normalmente sale de la **biblioteca compartida** `public/media/_music/` por
  su `id`; si es una canción propia, se pasa por ruta. **Es obligatoria**: sin ella el QC de entrada
  aborta. Se elige según el guion — ver «La música se elige por guion».
- Opcional: PNG/JPG para insertos fijos tipo mockup (`imagen` en vez de `broll`).

## Generar los clips — `npm run gen:aroll`

```bash
npm run gen:aroll -- input/<campaña>/guion.json            # muestra el costo, pide confirmación
npm run gen:aroll -- input/<campaña>/guion.json --si --regenerar   # sin preguntar; reintenta los que reprueban
npm run gen:aroll -- input/<campaña>/guion.json --solo 1   # una sola escena (p. ej. otro hook)
```

Esquema de `input/<campaña>/guion.json`:

```json
{
  "slug": "mi-campana", "idioma": "es", "musica": "ejemplo-pop",
  "personaje": "mujer de 34 años, piel clara, pelo castaño oscuro recogido en un rodete bajo con dos mechones sueltos, cejas gruesas, ojos marrones, sin maquillaje visible, aros pequeños de plata, remera gris jaspeada de cuello redondo",
  "escenario": "living luminoso, pared blanca lisa, estantería de madera clara desenfocada con frascos de cerámica azules y verdes y una planta pequeña, luz de ventana desde la izquierda",
  "encuadre": "plano medio corto, cámara a la altura de los ojos, teléfono vertical apoyado en la mesa, estética UGC realista",
  "encadenar": true,
  "escenas": [
    { "n": 1, "dialogo": "Estudié anatomía durante meses y en el examen me quedé en blanco.", "accion": "mira a cámara, gesto de frustración leve, manos apoyadas en la mesa", "final": "baja la mirada un instante y vuelve a cámara" }
  ],
  "broll": [ { "n": 1, "prompt": "close-up of hands flipping through an anatomy notebook, warm light", "imagen": null } ]
}
```

Qué hace, escena por escena: (1) genera el **frame inicial y el final** con `gpt-image-2` (9:16),
(2) manda los dos frames y el diálogo a `veo3.1-fast` en modo frame — el clip sale de 8 s, 720×1280,
con la voz adentro y sincronizada a los labios —, (3) QC técnico con ffprobe (resolución, pista de
audio con volumen real), (4) **QC de contenido**: transcribe el clip y lo alinea contra el `dialogo`;
si la cobertura es < 80 % el clip reprueba. Con `--regenerar` lo reintenta hasta dos veces. Al final
escribe `input/<campaña>/ad-01.json` **borrador** con una escena por clip y un inserto por escena.
Los clips quedan en `public/media/_ugc/<slug>/clips/`, los frames en `frames/`, el QC en `qc.json`.
Es reanudable: no vuelve a generar lo que ya existe.

**El retrato forense.** El generador de imágenes no acepta una imagen de referencia del personaje:
cada llamada inventa "una persona que encaja en la descripción". Lo que sostiene la consistencia
entre escenas son tres reglas:
1. `personaje` es una **descripción física exhaustiva** (pelo, cejas, ojos, nariz, piel, accesorios,
   prenda exacta con su color y su cuello) y va **palabra por palabra idéntica** en todos los frames.
2. `escenario` fijo, con los objetos y la dirección de la luz. Cambiar el set entre escenas rompe la
   ilusión más que un cambio leve de cara.
3. Solo cambia la **acción** (`accion`, `final`). Con `encadenar: true`, el frame final de la escena N
   es el inicial de la N+1 (misma imagen, no se regenera): la continuidad viene de ahí.

No es consistencia a nivel píxel: dentro de cada clip la cara la sostiene el generador de video, y
entre clips el corte de edición absorbe la microdiferencia.

**El diálogo.** `dice: "..."` con los dos puntos y las comillas es el disparador del lip-sync; el
generador lo arma solo. Lo que sí depende de quien escribe:
- **Una frase por escena, ≤ 8 s hablados** (unas 20-25 palabras).
- **Números como cifra** (`19`, no `diecinueve`): así los devuelve la transcripción, y una palabra que
  no casa se queda sin caption.
- **Evitar construcciones elípticas e interjecciones aisladas al inicio** (`"¿Sinceramente? Un
  cliente me..."`): son las que el modelo completa con muletillas o reordena. `"Sabía mostrarlo"`
  sale bien a la primera; `"Mostrar, sabía"` falla tres veces seguidas.
- Si una escena reprueba: primero **reescribir la línea más simple**, después `--regenerar`. Reprobar
  es barato ($0,14) — el loop es generar → QC → regenerar solo lo que falló.
- Si el modelo agrega una frase **al final** y el resto está bien, no hace falta regenerar: se
  silencia la cola con `ffmpeg -af "volume=0:enable='gte(t,6.9)'"` conservando los 8 s.

**Costo.** A-roll $0,14 por escena + 2 frames ($0,017) · B-roll $0,07 + 1 frame · transcripción del
QC ~$0,01. Un anuncio de 6 escenas y 6 B-roll ≈ **$1,30**; con dos reintentos, ≈ $1,60.

**El filtro de contenido de Veo es probabilístico.** El mismo prompt inocente ("un teléfono mostrando
una página con dibujos") pasa en una corrida y se bloquea en la siguiente con `Blocked by a specific
content policy`. El intento bloqueado **no se cobra**, así que `gen-aroll` y `gen-broll` reintentan
una vez solos con otro primer cuadro. Si se bloquea dos veces seguidas, reformular: describir la
escena, no la anatomía ("página con diagramas" en vez de "lámina de músculos").

**Defectos conocidos de `veo3.1-fast` y qué hacer:** flash de 1-2 cuadros ajenos al final del clip
(el ensamblador ya corta la cola después de la última palabra); pantalla de teléfono apagada cuando el
guion la muestra (pedir "pantalla encendida, brillo visible" en `accion`, o tapar con B-roll);
extremidades de más cuando hay dos acciones simultáneas (una mano activa por escena).

## Esquema — `input/<campaña>/ad-NN.json`

Ejemplo completo (`input/ejemplo-t2/ad-01.json`):

```json
{
  "title": "Qué músculo trabaja",
  "slug": "ejemplo-t2-ad1",
  "clips": "../../public/media/_ugc/ejemplo-t2/clips",
  "idioma": "es",
  "velocidad": 1.18,
  "escenas": [
    { "clip": "escena1.mp4", "dialogo": "Estudié anatomía durante meses y en el examen me quedé en blanco." },
    { "clip": "escena2.mp4", "dialogo": "Sabía los nombres de memoria, pero no cómo funcionaban en el movimiento." },
    { "clip": "escena3.mp4", "dialogo": "Con este atlas veo cada ejercicio con sus músculos y su biomecánica de un vistazo." },
    { "clip": "escena4.mp4", "dialogo": "Son 140 láminas y todo en un solo lugar. Toca el botón de abajo." }
  ],
  "insertos": [
    { "broll": "broll1.mp4", "sobre": "meses", "escena": 1, "dur": 3.0 },
    { "broll": "broll2.mp4", "sobre": "nombres", "escena": 2, "dur": 3.0 },
    { "broll": "broll3.mp4", "sobre": "atlas", "escena": 3, "dur": 3.0 },
    { "broll": "broll1.mp4", "sobre": "biomecánica", "escena": 3, "dur": 2.5 },
    { "broll": "broll4.mp4", "sobre": "Toca", "escena": 4, "dur": 3.0, "desfase": -1.0 }
  ],
  "musica": { "id": "ejemplo-pop", "desde": 0, "db": -20 }
}
```

**Campos y sus reglas:**

- **`clips`** — carpeta con los `escenaN.mp4`/`brollN.mp4`. Ruta absoluta o relativa a la carpeta
  del brief.
- **`idioma`** — código de idioma para la transcripción (`en`, `es`, …).
- **`velocidad`** — default **1.18**.
- **`escenas[].dialogo`** no es documentación: es el **ancla de alineación**. Es el texto EXACTO
  que se le pidió al modelo de video. Obligatorio. **Los números van como cifra** (`19`, no
  `diecinueve`): así los devuelve la transcripción, y una palabra que no casa se queda sin caption.
  Si se olvida, el ensamblador lo avisa con `⚠️ SIN CAPTION`. **Las comillas que envuelvan una cita
  no se queman en pantalla** (se sacan solas); la coma, el punto y los puntos suspensivos sí, y el
  apóstrofo de elisión (`o'clock`) se respeta. Si lo que dice el clip no coincide (cobertura
  < 80 %), el ensamblador **aborta y muestra el diff** brief-vs-transcripción — señal de que el
  clip no dice lo que el brief cree.
- **`insertos[].sobre`** — palabra del diálogo sobre la que entra el inserto. Es la forma normal de
  colocarlo. Se busca en el guion completo (TODAS las escenas, salvo que se pase `escena`); si la
  palabra **aparece más de una vez**, el ensamblador **avisa**, usa la primera, y hay dos salidas:
  acotar con `"escena": N` (busca solo dentro de esa escena) o pasar a `en`.
- **`insertos[].en`** — tiempo literal en el **timeline final** (después de aplicar la velocidad).
  Es la vía para los **parches quirúrgicos**: tapar un tramo con defecto de generación (pantalla
  apagada, flash de cola, tercera mano) no tiene nada que ver con una palabra. `sobre` y `en` son
  excluyentes — pasar los dos es error.
- **`insertos[].desfase`** — corrimiento en segundos sobre el punto calculado. Acepta negativos
  (ver el último inserto del ejemplo); si el resultado da antes de 0, se clampa a 0 con aviso.
- **`insertos[].imagen`** — un PNG/JPG en vez de un clip (mockups). Se muestra fijo durante `dur`,
  sin la restricción de "no superar la duración del clip de inserto" (no aplica: una imagen no
  tiene metraje que agotar). **Entra centrado ENCIMA del personaje, no a pantalla completa** (ver
  "Los dos tipos de inserto"), conservando su relación de aspecto.
- **`insertos[].dur`** — default **3.2 s**. Si supera la duración real del clip de inserto, el
  ensamblador **aborta** (`overlay` congelaría el último cuadro sin avisarlo).
- **`musica`** — **OBLIGATORIA**, y se declara de una de dos formas, excluyentes:
  - **`id`** — una pista de la biblioteca compartida `public/media/_music/music-<id>.mp3`, la
    misma que usa la plantilla 1. Es la vía normal: `"musica": { "id": "ejemplo-pop" }`. Si el
    id no existe, el QC aborta **listando todos los disponibles**.
  - **`archivo`** — ruta absoluta o relativa a `clips`, para una canción propia que no vale la
    pena mover a la biblioteca.

  Más `desde` (default 0) y `db` (default −20). No es un adorno opcional: sin música el QC aborta
  antes de transcribir. Un anuncio de esta plantilla siempre lleva música por debajo de la voz; si
  algún día hace falta uno sin música, hay que cambiar el ensamblador (el `amix` tiene dos
  entradas fijas), no el brief.
- **`captions`** — opcional (`fuente`, `cuerpo`, `contorno`, `sombra`, `hold`); si falta, se usan
  los valores medidos (ver Constantes). `hold` (default 0.15 s) es cuánto se sostiene cada palabra
  después de su fin, para no parpadear entre palabras seguidas.
- **`cola`** (opcional, default 0.25 s) y **`maxCaraSinInserto`** (opcional, default 4.8 s) — para
  ajustar caso por caso sin tocar código.
- **`duracionClip`** (opcional, default 8 s) — duración esperada de cada clip de A-roll, que el QC
  de entrada verifica con ±1 s. Veo 3.1 entrega 8 s fijos; si se cambia de modelo y los clips
  duran otra cosa, se declara acá.
- **`duracionClipTolerancia`** (opcional, default 1.0 s) — cuánto puede apartarse cada clip de
  `duracionClip` antes de que el QC aborte. Se ensancha cuando **los clips vienen de largos
  distintos a propósito**: el caso normal es haberles sacado los silencios antes de entrar acá
  (la plantilla solo corta la cola, no la cabeza ni los huecos internos), y ahí cada clip queda
  de un largo distinto. El chequeo sigue sirviendo para pescar un clip faltante o roto.
  > ⚠️ Al re-armar con clips modificados, correr con **`--forzar`**: la caché de transcripciones
  > no detecta que el archivo cambió, sirve los tiempos viejos y el montaje sale con los cortes
  > del clip anterior **sin un solo aviso**. El delator es que el log dice `(caché)` y la duración
  > final no baja.
- **`salida`** (opcional) — ruta del `.mp4`; si falta, `out/<slug>.mp4` **de la carpeta de la
  skill**, no del cwd (igual que la caché y `public/fonts/`: cuelgan de la raíz del proyecto para
  que la skill se pueda correr parada en otra carpeta sin duplicar el árbol ni re-pagar la
  transcripción). Una `salida` explícita sí se resuelve contra el cwd; el batch la pasa así.

### Modo `solo-broll` — la voz sin la cara

`"modo": "solo-broll"` en el brief. **Se conserva el audio del A-roll entero** —es la voz ya
grabada— y se reemplaza la capa de video: no se ve la cara en ningún momento, solo B-roll y
páginas del producto. Es la variante 4 de la escalera (ver abajo) y el formato de los anuncios donde
«la página es el creativo».

Todo lo del audio queda igual: concatenado, corte por última palabra, 1,18x con tono conservado,
captions palabra por palabra **en el centro** y música a −20 dB. Por eso el arnés lo sigue
verificando entero sin cambios.

Lo que cambia:

| | `normal` | `solo-broll` |
|---|---|---|
| Base del video | el A-roll | negro, tapado por los visuales |
| `insertos` | se superponen sobre la cara | **son** la pista de video |
| Regla | máx. 4,8 s de cara sin inserto (aviso) | **cero huecos** (aborta y dice cuáles) |
| `dur` > duración del clip | aborta | permitido: se loopea con `-stream_loop` |
| Una `imagen` | 80 % del cuadro, encima del personaje | **cuadro completo** |

**`dur` es opcional en este modo.** Si se omite, el visual se estira hasta donde arranca el
siguiente, y el último hasta el final. Es lo que hace escribible un brief anclado por palabra:
se pone `sobre` en cada visual y las duraciones se resuelven solas, tapando la línea de tiempo
exacta. Se puede mezclar con duraciones explícitas. El primer visual siempre se lleva al segundo
0, porque anclado por palabra caería en el 0,07 de la primera sílaba y dejaría un parpadeo negro
sobre el hook.

> **No calcules las duraciones a mano.** Es frágil: contra el redondeo de los bordes de escena un
> `dur` "justo" puede dejar un hueco de milésimas y abortar la corrida. Hay dos salidas y una es
> mejor. **Omitir `dur`** deja que cada visual llegue exactamente hasta el siguiente: tapa perfecto
> y no genera un solo aviso. Poner `dur` de sobra y dejar que el recorte de solapes haga el pegado
> también funciona y da el mismo video, pero llena la consola de avisos de solape —uno por visual—
> y eso **tapa los avisos que sí importan**: el `⚠️ SIN CAPTION`, que señala una palabra del guion
> que se quedó muda, sale por esa misma consola. Enterrado entre trece líneas de ruido rutinario,
> se pierde.
>
> Un borrador real de 13 visuales anclados con `en` y `dur` de sobra daba 13 avisos y escondía
> algo peor: dos mockups quedaban en 1,04 s y 0,83 s, por debajo del piso de legibilidad. La
> versión buena tenía **11 visuales anclados solo por palabra, sin una sola duración escrita y sin
> un solo aviso**. Ese es el brief de referencia.

**El EDL avisa si un visual queda demasiado corto para leerse.** Al omitir `dur`, la duración
deja de escribirse y pasa a ser consecuencia del espaciado de las anclas: dos conceptos pegados en
una frase densa producen un visual de menos de un segundo sin que nada en el brief lo insinúe.
Los pisos son distintos por tipo y esa es la parte que importa — **imagen 1,5 s, b-roll 0,5 s**.
Un b-roll de 1 s se lee: es un corte rápido y el ojo entiende movimiento al vuelo. Una imagen de
0,8 s no se llega a leer, y una página que no se lee **no es prueba**. Es un aviso, no un error:
el arreglo es re-anclar o sacar un visual, porque `dur` solo puede acortar. Solo corre en
`solo-broll`: en modo normal un mockup de 1 s es el beat de una enumeración de bonus, no algo que
haya que leer.

**Los visuales tienen que tapar la línea de tiempo entera.** Si la suma deja un hueco, ahí se ve
negro, así que el EDL aborta nombrando los tramos descubiertos. Reusar el mismo clip varias veces
es normal en este modo: 8 B-roll de 4,9 s tapan 45 s repitiendo, sin generar nada nuevo.

**Las imágenes llenan el cuadro con telón desenfocado, no con barras.** Un mockup cuadrado
(1400×1400) en 9:16 dejaría un tercio del cuadro en negro. Recortarlo tampoco sirve: lo que se
muestra ahí es la prueba, y recortarla corta el renglón que se está mostrando. Se usa el mismo
visual dos veces — escalado para llenar y desenfocado como telón, y encima el original intacto y
centrado.

### La escalera de variantes: 1 tanda de clips → 4-6 creativos

Con los 6 A-roll + 6 B-roll de una tanda salen, **sin generar nada nuevo**:

1. **Principal** (~35 s): la gramática de esta receta.
2. **Corta** (~18-20 s): escena hook + escena prueba + mitad final del CTA, con sus 3 B-roll. Un
   brief nuevo con solo esas `escenas`.
3. **Antes/después**: B-roll de caos + escena de frustración → escena descubrimiento + prueba +
   B-roll social + CTA. Otro orden de las mismas escenas.
4. **Voz en off + páginas** = `"modo": "solo-broll"`: la voz ya grabada, y encima solo B-roll y
   páginas reales del producto (`imagen`).

Con gasto mínimo:

5. **Variante de hook** ($0,14): `npm run gen:aroll -- guion.json --solo 1` con otra primera frase
   (copiar antes el `escena1.mp4` actual a `escena1-hookA.mp4`); el cuerpo queda idéntico. Cada hook
   nuevo = un creativo nuevo.
6. **POV/reacción** (~$0,50): 2-3 clips de un personaje nuevo con su propio retrato forense.

**Bonus $0:** los frames 9:16 (el del teléfono mostrando el producto, las páginas) sirven como
**imágenes estáticas** para anuncios de imagen.

**Regla:** la escalera se propone recién con el principal aprobado. Primero uno que funcione,
después las variantes.

### La música se elige por guion, no hay una fija

**El error a evitar es copiar el `musica` del ejemplo sin pensarlo.** La pista del ejemplo es la del
ejemplo. Una cama de gimnasio a 123 BPM debajo de un anuncio para psicólogos contradice al guion, y
el espectador lo siente aunque no sepa por qué.

Tres criterios, en orden de importancia:

1. **Instrumental, siempre.** En esta plantilla el anuncio *es* una persona hablando. Una letra
   cantada compite con el diálogo y las dos pierden. `gen-musica` ya lo fuerza en dos capas.
2. **El tempo tiene que acompañar al registro del guion.** Confesión y vulnerabilidad piden 60-75
   BPM; enumeración de beneficios y urgencia aguantan 90-125.
3. **Cuanto más oscura, mejor cama.** La inteligibilidad de la voz vive entre 2 y 4 kHz: una pista
   sin agudos ahí no puede tapar las consonantes. Una pista brillante a −20 dB puede pelearle a la
   voz; una oscura no.

Y un cuarto detalle que muerde: **la música entra desde el segundo 0**, encima del hook. Si la pista
arranca de golpe, hay que correrla con `desde` hasta un punto donde entre suave.

### La biblioteca — `public/media/_music/`

Cada pista se crea con `npm run gen:musica -- --id <id> --prompt "<estilo en inglés>"` y queda como
`music-<id>.mp3` (más una segunda toma `music-<id>-b.mp3` para elegir de oído). Para armar una
biblioteca útil, pedir por registro:

| `id` sugerido | Prompt (en inglés) | Para qué guion |
|---|---|---|
| `confesion` | slow warm ambient piano, 70 BPM, dark, no highs | Confesión, vulnerabilidad. Terapia, salud |
| `descubrimiento` | bright even acoustic pop, 90 BPM, gentle intro | Testimonio, descubrimiento, uso general |
| `urgencia` | driving pop rock, 120 BPM, compressed | Fitness, urgencia, enumeración |

> Tiene que ser `.mp3` (el código concatena esa extensión) y el `id` en minúsculas con guiones. Una
> pista propia también sirve: copiarla como `music-<id>.mp3`.

## Reglas de autoría

La gramática es la que funcionaba a mano en un editor de video, medida en los anuncios de referencia
y trasladada a reglas que el ensamblador chequea solo:

- **Nunca más de 4,8 s de cara sin inserto.** Es el máximo medido en los anuncios de referencia. El EDL
  lo valida y **avisa** (no aborta) con el tramo exacto si se pasa — corregirlo es agregar un inserto ahí.
- **El inserto entra sobre la palabra que ilustra** (`sobre`), no en un tiempo elegido a ojo. Es la
  forma normal de escribir un brief; conviene pensar el guion clip por clip y anotar, para cada
  concepto fuerte, qué palabra lo nombra.
- **Los dos tipos de inserto entran distinto, y no son intercambiables.** Es la gramática medida,
  no una preferencia:
  - **`broll` (video) → pantalla completa.** Ocupa todo el cuadro y tapa al personaje: es un
    **cambio de plano**. Los clips son 9:16 nativos, así que llenan el cuadro sin deformarse.
    Es lo que se usa para ilustrar lo que se está diciendo (los apuntes, el cuaderno, el gimnasio).
  - **`imagen` (mockup) → superpuesta y centrada sobre el personaje.** Ocupa una caja del **80 %
    del ancho** del cuadro, centrada, conservando su relación de aspecto, y **el A-roll se sigue
    viendo alrededor**: se lee como un mockup puesto encima, no como otro plano. Así entra el
    mockup en el tramo de los bonus. Nunca hay barras negras: si la imagen no es 9:16 —un mockup
    cuadrado, 1400×1400— lo que sobra del cuadro es la persona hablando, no relleno.

  Elegir mal cambia la lectura: un mockup a pantalla completa corta el contacto visual justo
  cuando se está prometiendo algo, y un b-roll encogido al 80 % parece un error de edición.
- **Los insertos también son parches quirúrgicos.** Tapar un defecto de generación (pantalla
  apagada, flash de cola, una tercera mano de más) no tiene nada que ver con una palabra: para eso
  está `en`, el tiempo literal.
- **El cierre es CTA + inserto del pulgar.** En el ejemplo de arriba, el último inserto (sobre
  `"Toca"`) lleva `"desfase": -1.0` para que el mockup/pulgar cubra **toda** la frase de cierre, no
  solo un flash sobre la última palabra — es la lectura correcta del cierre, no un ajuste
  cosmético.
- Si dos insertos se solapan, el EDL **avisa y recorta el primero** automáticamente.
- **Al reusar un inserto entre idiomas, revisar el texto en pantalla.** Es lo que hace barata la
  plantilla — el mismo clip de un cuaderno o de una pantalla sirve para varios mercados — pero solo
  mientras no muestre texto legible, o lo muestre en el idioma del anuncio. El código no lo
  detecta (no hay OCR en el pipeline): es una revisión manual antes de escribir el brief.

## Constantes

| Constante | Valor |
|---|---|
| Velocidad | **1.18x** (video y audio con `atempo`, tono conservado) |
| Cola tras la última palabra alineada de cada escena | **0.25 s** |
| Hold de cada caption tras su fin | **0.15 s** (puentea el hueco a la próxima palabra solo si es chico, para no parpadear entre palabras seguidas) |
| Fuente de captions | Arial + Bold forzado en el estilo ASS (`Bold: -1`) |
| Cuerpo | **88** sobre 1080×1920 — relación **88/1920**, escala con el alto de salida |
| Contorno / Sombra | **6 / 3** |
| Alineación | **5** — centro exacto (50 % × 50 % del cuadro) |
| Ritmo de captions | una palabra por vez, **sin animación** (ni pop, ni escala, ni resalte karaoke) |
| Música | **−20 dB**, entra desde `musica.desde` (default 0). Biblioteca: `public/media/_music/music-<id>.mp3` |
| Duración de inserto | **3.2 s** por defecto |
| Inserto de video (`broll`) | **pantalla completa** (9:16 nativo), sin deformar |
| Inserto de imagen (`imagen`) | **80 % del ancho del cuadro**, centrado sobre el A-roll, sin barras |
| Máxima cara sin inserto | **4.8 s** |
| Salida | **1080×1920 · CFR 30 · CRF 21 · perfil High 4.0 · aac 192k 48 kHz estéreo · faststart** |

## Pipeline

```bash
npm run gen:aroll -- input/<campaña>/guion.json               # clips + QC + brief borrador
npm run assemble:t2 -- input/<campaña>/ad-NN.json            # un anuncio
npm run assemble:t2 -- input/<campaña>/ad-NN.json --forzar   # ídem, re-transcribiendo
npm run batch:t2 input/<campaña> out/<campaña>               # la tanda entera, reanudable
python scripts/verificar-t2.py out/<campaña>/<slug>.mp4 --brief input/<campaña>/ad-NN.json --musica "<mp3>"
# --clips "<dir>" también sirve, pero solo si los clips se llaman escenaN.mp4
```

- `batch:t2` saltea los anuncios que ya tienen `.mp4` en la carpeta de salida (`FORCE=1` para
  rehacerlos) y sigue con los demás aunque uno falle. Si alguno falló, sale con código 1.
- `assemble:t2` acepta `--debug` (vuelca el grafo de ffmpeg a
  `public/media/_ugc/<slug>/filtro.txt` en vez de ejecutarlo) y `--forzar` (repite la transcripción
  aunque haya caché). ⚠️ **Los flags van después de `--`**: `npm run` se come todo lo que no se
  separe así, y el script no los ve. Sin el `--`, `--forzar` no llega y el ensamblador sirve
  **la transcripción vieja de la caché sin decir nada** — justo cuando se pide `--forzar` es
  porque se regeneró un clip con el mismo nombre, así que el anuncio sale con los tiempos del
  clip anterior. Con `node scripts/ensamblar-t2.mjs <brief> --forzar` el problema no existe.
- La transcripción se cachea en `public/media/_ugc/<slug>/words-<clip>.json`: un reintento no
  vuelve a gastar.
- El EDL queda archivado en `public/media/_ugc/<slug>/edl.json` — audita qué se renderizó
  realmente, sin volver a transcribir.
- **Antes de gastar un centavo, el QC de entrada.** Por cada clip de escena: que exista, que sea
  9:16, que la pista de audio tenga volumen real (`mean_volume` > −45 dB) y que dure lo esperado
  (`duracionClip`, default 8 s ±1); que todos compartan resolución (`concat` exige un solo tamaño);
  que cada inserto y la música existan. Si algo no da, aborta nombrando archivo y motivo, **antes**
  de pedir una sola transcripción. Un clip de otra resolución colado entre las escenas mataba el
  render en el `concat` recién después de haber pagado las N transcripciones.
- `verificar-t2.py` es el arnés forense (correlación cruzada por FFT, F0, geometría de captions):
  compara el `.mp4` recién armado contra lo medido en los anuncios de referencia. Necesita
  numpy, scipy y Pillow (`python -m pip install numpy scipy pillow`). Es opcional: producir
  anuncios no lo requiere.
- **El arnés cubre 8 de los 9 criterios.** El que falta es la **tirada máxima de cara sin inserto**:
  no se mide sobre el video terminado —haría falta detección de escena, que confunde un corte de
  B-roll con un cambio de plano del propio A-roll— sino que la valida `construirEDL` **en tiempo de
  armado**, con los tiempos exactos de cada inserto, y avisa con el tramo.

## Pozos

### Técnicos — los atrapa el código o el arnés

1. **El `Format:` del `.ass` tiene que declararse COMPLETO** — 23 campos en `[V4+ Styles]`, 10 en
   `[Events]`. libass no valida la cantidad de campos: si falta uno, no tira error ni lo dice en
   ningún log, simplemente renderiza mal. Síntoma real: con un `Format:` de `[Events]` recortado, el
   campo `Text` se comía la coma que separaba `Style` de `Name` y cada palabra salía en pantalla
   como **`,palabra`**. Se detectó mirando un cuadro renderizado, no leyendo el `.ass`.

2. **libass cae a Arial en silencio si no encuentra la fuente pedida.** Pedir `Montserrat`, `Inter`
   o `Poppins` sin tenerlas instaladas produce exactamente los mismos píxeles que pedir `Arial`, sin
   ningún aviso. Por eso el default de la plantilla es `Arial` a secas. (`public/fonts/` existe,
   vacío, como lugar para instalar un `.ttf` propio.)

3. **Las rutas absolutas dentro de un `filter_complex` necesitan DOBLE backslash antes de los dos
   puntos** (`C\\:/ruta/...`). El grafo se parsea DOS veces — una como filtergraph, y adentro de
   cada filtro otra vez como AVOption — y cada pasada se come un nivel de escape. `escaparFiltro()`
   en `ensamblar-t2.mjs` hace las dos pasadas.

4. **`overlay` estira el video si el inserto no se recorta a su propia ventana.** El `eof_action`
   por defecto de `overlay` es `repeat`, y la cadena de filtros termina recién cuando TODAS las
   entradas dieron EOF. Sin un `trim=duration` por inserto, un b-roll con más metraje nativo que su
   `dur` sigue produciendo cuadros después de que `enable()` lo "apaga": dio **3 s de cola muda
   después del CTA**. Por eso cada inserto lleva su propio `trim=duration=${dur}` antes del `overlay`.

5. **`-vsync` no existe en ffmpeg 9.** Es **`-fps_mode`** (`cfr`). El flag viejo no rompe el comando,
   pero el mp4 sale con `r_frame_rate` variable — justo lo que hace fallar la subida a Meta a mitad
   de proceso.

6. **Whisper le cuelga el silencio a la palabra anterior**, no lo deja vacío — y alucina palabras
   enteras en las colas de silencio al final de un clip. El delator no es la duración sola sino la
   duración **contra la cantidad de caracteres**: se estima una duración esperada
   (`caracteres × 0.075 s`, piso 0.12 s) y se recorta cuando la real supera 2.5× esa esperada + margen.
   Por eso el ensamblador no confía en los timestamps crudos: alinea la transcripción contra el
   `dialogo` que ya está en el brief (`scripts/lib/alinear.mjs`) y descarta lo que no matchea.

7. **`node --test <directorio>` no funciona.** Hay que pasarle un **glob entrecomillado**
   (`node --test "tests/**/*.test.mjs"`) — así quedó en `package.json`.

### De autoría — solo los atrapa mirar el anuncio antes de subirlo

Estos dos no los atrapa el código ni el arnés: elegir el inserto correcto es lo único que hace
quien escribe un brief de esta plantilla, así que es también lo único que puede fallar sin que
ninguna validación lo avise.

8. **El idioma de lo que se inserta.** El b-roll se reusa entre idiomas — es lo que hace barata a
   esta plantilla: el mismo clip de un cuaderno o de una pantalla sirve para varios mercados, hasta que
   tiene texto legible encima. En un anuncio de referencia quedó colada una portada **en otro
   idioma**, justo por reusar sin mirar. Antes de reusar un inserto en otro idioma: mirar si muestra
   texto, y si lo muestra, si está en el idioma del anuncio.

9. **No prometer un artefacto que el producto no entrega.** Un inserto que muestra una app cuando
   lo que se vende son PDFs es una promesa falsa, aunque nadie la haya escrito en el copy. *El
   inserto puede mentir sobre cómo se ve el producto; nunca sobre qué es ni sobre cuánto trae*: un
   inserto que hojea siete módulos cuando el producto trae cinco miente igual que uno que muestra
   una app inexistente.

## Archivos clave

| Archivo | Qué hace |
|---|---|
| `scripts/gen-aroll.mjs` | Guion por escenas → frames (gpt-image-2) → clips (veo3.1-fast, lip-sync) → QC técnico y de contenido → brief borrador. Reanudable. |
| `scripts/lib/aroll.mjs` | Puro: arma los prompts (retrato forense, disparador de lip-sync), juzga la cobertura y escribe el brief borrador. Testeado. |
| `scripts/gen-broll.mjs` | Insertos sin diálogo con veo3.1-lite, desde un prompt o una imagen local. |
| `scripts/gen-musica.mjs` | Camas instrumentales con Suno a la biblioteca compartida. |
| `scripts/ensamblar-t2.mjs` | El motor: QC de entrada → transcripción → alineación → EDL → `.ass` → una sola pasada de ffmpeg. Punto de entrada del CLI y de `batch-t2.mjs`. |
| `scripts/batch-t2.mjs` | Recorre `input/<campaña>/ad-*.json`, saltea los que ya tienen `.mp4` (reanudable), `FORCE=1` para rehacerlos. |
| `scripts/verificar-t2.py` | Arnés forense de aceptación (opcional): correlación cruzada + F0 + geometría de captions. |
| `scripts/lib/transcribir.mjs` | Cliente de APIMART (`whisper-1`, timestamps por palabra) con caché en disco. |
| `scripts/lib/apimart.mjs` | El único módulo que habla con la red de generación: video, imagen, música, voz, transcripción. |
| `scripts/lib/alinear.mjs` | Alinea la transcripción contra el `dialogo` del brief (subsecuencia común más larga), descarta alucinaciones y recorta palabras estiradas. Puro, testeado con fixtures. |
| `scripts/lib/edl-t2.mjs` | Construye y valida el EDL (escenas + insertos) ya en el timeline final. Puro. |
| `scripts/lib/ass-t2.mjs` | Genera el `.ass` de captions a partir de las palabras del EDL. Puro. |
| `scripts/lib/costo.mjs` | Estimador de costo y confirmación antes de gastar. |
| `scripts/lib/env.mjs` | Carga `.env` de la raíz del proyecto (ahí va `APIMART_API_KEY` si no está en el entorno). |
| `tests/*.test.mjs` | Tests de los módulos puros con el runner nativo de Node (`node --test "tests/**/*.test.mjs"`). |
| `public/fonts/` | Carpeta (vacía) para instalar un `.ttf` propio de captions; mientras tanto se usa el Arial del sistema. |
