# Plantilla 3 — "Claymation" (stop-motion de plastilina + voz en off)

Motor **ffmpeg puro** · código en `scripts/gen-clips.mjs` + `scripts/gen-voz.mjs` + `scripts/montar.mjs`
(+ `scripts/lib/montar-lib.mjs`, puro y testeado) · **velocidad 1,15x** aplicada en el montaje.

Anuncio vertical (1080×1920) contado por una **voz en off** sobre **tomas de plastilina generadas**
(una imagen por toma con `gpt-image-2`, animada con Veo), cortadas cada ~3 s con **B-roll sobre la
palabra que ilustra**, **captions blancas centradas palabra por palabra**, **un golpe de sonido en
cada corte** y una cama musical baja. Es el estilo que más se repite en anuncios reales de
suplementos, resaca, salud del pie, perfumes: un problema oculto, un villano de plastilina y el
producto como respuesta exacta a ese villano.

**La misma tanda de clips sirve para todos los idiomas.** Nadie mueve la boca y los prompts prohíben
texto en cuadro: traducir el anuncio es regenerar la voz y volver a montar. Abrir un mercado nuevo
cuesta una locución, no una tanda.

## El pipeline en tres comandos

```bash
npm run gen:clips -- input/<campaña>/guion.json        # imágenes + clips (muestra el costo, pide OK)
npm run gen:voz   -- input/<campaña>/guion.json        # una pista por línea + ad-01.json borrador
npm run montar    -- input/<campaña>/ad-01.json --salida out/<campaña>/<slug>-ad1.mp4
npm run batch:t3     input/<campaña> out/<campaña>     # todos los ad-*.json (el set de variantes)
```

Los clips quedan en `public/media/_clips/<slug>/clips/<id>.mp4`, los frames en `frames/`, las voces
en `voz/lNN.mp3` (+ `lNN.words.json` con los tiempos, gratis para el montaje) y el QC en `qc.json`.
Todo es **reanudable**: no se vuelve a generar lo que ya existe; `--solo t01,b02` acota y
`--regenerar` fuerza. **Los clips se generan uno por uno, a 2-4 minutos cada uno** (7 clips ≈ 20-25 min);
la consola imprime un punto mientras espera. `gen:voz` escribe `ad-01.json` solo si no existe.

## Esquema — `input/<campaña>/guion.json`

Ejemplo completo en `input/ejemplo-t3/guion.json`. Lo que importa:

```json
{
  "title": "Nombre corto", "slug": "mi-campana", "estilo": "claymation", "idioma": "es",
  "musica": { "id": "confesion" },
  "lineas": [
    { "n": 1, "texto": "La línea EXACTA que dice la voz.", "toma": "t01", "broll": "b01" }
  ],
  "tomas": [
    { "id": "t01", "imagen": "<CHARACTER BIBLE>. <acción y ambiente concreto de esta toma>, <ángulo de cámara>",
      "video": "Camera: <un solo movimiento>. Motion: <una sola acción>" },
    { "id": "t03", "imagen": "<estado inicial>", "fin": "<la MISMA escena, solo cambia el estado>", "video": "..." }
  ],
  "broll": [ { "id": "b01", "imagen": "Macro close-up of ...", "video": "Camera: slow pan right" } ]
}
```

- **`lineas[].texto`** es el ancla de todo: lo dice la voz, lo alinean las captions. **Los números van
  como cifra** (`19`, no `diecinueve`): whisper los devuelve así. Si igual queda alguna palabra sin
  casar, el montador la **interpola** entre sus vecinas para que nada del guion salga mudo.
- **`lineas[].toma` / `broll`**: qué clip ilustra la línea. El plan borrador pone `[toma, broll]` y el
  montaje reparte la duración real de la voz entre los dos, cortando cada ≤ 3 s.
- **`tomas[].imagen`**: el prompt de la imagen. **Empieza SIEMPRE por el Character Bible, palabra por
  palabra idéntico en cada toma** (es lo único que sostiene la consistencia: no hay imagen de
  referencia), sigue con la acción y **un ambiente concreto** (dormitorio, cocina, gimnasio — nunca
  "flotando" en un fondo liso, salvo una macro de detalle), y cierra con el ángulo de cámara. Las
  flags de Midjourney (`--ar`, `--v`) se limpian solas. **El negative prompt no existe acá**: gpt-image-2
  no tiene campo de negativos y si se lo pegás lo dibuja. La coletilla del estilo ya convierte los
  negativos en afirmaciones (marcas de escultura controladas, todo en plastilina mate, sin texto).
- **`tomas[].fin`** (opcional): prompt del **frame final**. Con `fin`, la toma se genera en **modo
  frame** (`veo3.1-fast`, $0,14): una transición real entre dos estados (el villano crece, el vaso se
  llena). Sin `fin`, una imagen animada con `veo3.1-lite` ($0,07). Reservar el modo frame para las
  tomas donde cambiar de estado comunica más que mover la cámara.
- **`tomas[].video`**: solo movimiento — un `Camera:` y un `Motion:`. Las coletillas fijas del estilo
  (`Ensure handmade stop-motion clay animation… Non CGI… Keep character facial consistency…`) se
  agregan solas y **no se parafrasean**: son lo que evita que Veo devuelva CGI liso.
- **`tomas[].referencia`** (opcional): PNG/JPG local (la foto real del envase) que se manda como
  referencia de imagen. Con referencia, gpt-image-2 respeta forma y etiqueta.
- **`musica`**: `{ "id": "<id>" }` de la biblioteca `public/media/_music/` (se crea con
  `gen:musica`, se elige por registro del guion) o `{ "archivo": "<ruta>" }`. Obligatoria.
- **`voz`** (opcional): pisa la voz de `brand.json` para esta campaña
  (`{ "apimart": { "voice": "echo", "instructions": "..." } }`).

## Esquema — `input/<campaña>/ad-NN.json` (el plan de montaje)

`gen:voz` escribe `ad-01.json` una vez; después se edita a mano. Cada variante del set es otro
`ad-NN.json` sobre los mismos clips y voces.

```json
{
  "title": "...", "slug": "mi-campana-ad1", "estilo": "claymation", "idioma": "es",
  "clips": "../../public/media/_clips/mi-campana/clips", "voz": "../../public/media/_clips/mi-campana/voz",
  "musica": { "id": "confesion", "desde": 0 },
  "beats": [
    { "linea": "La línea exacta.", "voz": "l01.mp3", "planos": [["t01"], ["b01"]] },
    { "linea": "Otra línea.", "voz": "l02.mp3", "planos": [["t02", 2.0], ["b02"], ["t02"]] }
  ]
}
```

- **`beats[].planos`**: qué clip y, opcionalmente, cuántos segundos. **La duración del beat la manda la
  voz real** (`lNN.mp3` + 0,20 s de respiro; el último lleva 0,6 s de cola): los planos sin segundos
  se reparten lo que queda, los que traen segundos se respetan en proporción, y ningún plano dura más
  de 3 s (si hace falta, se cicla toma → b-roll → toma). Así video y voz cierran exactos sin calcular
  nada a mano. Un clip da ~6,6 s útiles a 1,15x: si un plano pide más, el montador aborta y lo dice.
- Ajustables por plan (defaults del estilo): `speed` 1.15 · `gap` 0.20 · `volMusica` 0.10 ·
  `sfxCorte` "whoosh" (0.40) · `sfxPlano` "pop" (0.30) · `cola` 0.6 · `maxPlano` 3.

## Cómo se escribe el anuncio

### El ángulo (default: problema oculto + mecanismo personificado)
1. **Problema oculto o acumulativo**: pasa en silencio y no se nota hasta que es grande.
2. **Revelación del mecanismo**, personificado como villano (un monstruo, una molécula, una toxina de
   plastilina) o con una metáfora concreta (obreritos reparando un órgano).
3. **Por qué lo obvio no alcanza**: "ninguna cantidad de X arregla esto".
4. **El producto como respuesta exacta a ESE mecanismo**, no una solución genérica.
5. **CTA con garantía/oferta.**

Otros ángulos válidos: transformación satisfactoria (oddly-satisfying), "yo antes" reaccionando,
comparación en el mismo cuadro, absurdo-cómico con punchline, podcast de dos personajes (ahí sí
hablan con lip-sync: el diálogo va DENTRO del prompt de video como `Character speaks the following
line with natural lip-sync: "..."`, y la toma va en modo frame).

### Mecánica: loop + giro + escalada
Hook con loop de curiosidad (plantar una tensión que necesita resolverse), mini-loops en cada línea,
un beat bisagra antes del producto ("Hasta que…"), imágenes concretas y ninguna frase corporativa.
Antes de entregar: ¿la línea 1 es el hook (no una descripción de escena, no el giro adelantado)?
El hook se escribe con `plantillas/hooks.md`.

**Presupuesto de palabras**: mínimo 30 s; `segundos × 2,4 palabras`. Es una estimación para
escribir: **la duración real es la del mp3**, y el montaje se calcula sobre esa.

### ADN visual y Character Bible
- Claymation, stop-motion, plastilina **con acabado artesanal pero refinado** ("diorama de estudio
  de alto presupuesto"): marcas de escultura sutiles, nunca huellas caóticas.
- Todo en plastilina, también lo que sería vidrio, metal o tela (se describe como imitación esculpida).
- Luz de estudio suave y difusa, lente macro, poca profundidad de campo. Vocabulario de cámara con
  intención: primerísimo primer plano, cenital, contrapicado, a ras de mesa, frontal simétrica, tres
  cuartos.
- **Character Bible** (si hay personaje), repetido palabra por palabra en cada toma:
  `CHARACTER: a claymation character with a rounded handmade clay body, [rasgos], tactile plasticine
  material with refined subtle sculpting marks, matte surface finish, muted [color] clay tone`.
  Con dos personajes (podcast), cada uno lleva el suyo. **Generar primero la toma 1 y mirarla**: si el
  personaje salió mal ahí, todas heredan el error. Las tomas que deriven se regeneran **la imagen**,
  nunca el video.
- Si el envase real aparece: conserva forma y proporciones exactas, esculpido en plastilina; pasar la
  foto como `referencia`.

### B-roll: uno por toma, con ubicación exacta
Macro del material o ingrediente en plastilina, o **personajes secundarios reaccionando** (una
vecina, una mascota, un grupo). Cada línea declara su `broll`: el montaje lo mete sobre la línea y
de paso tapa los defectos de generación.

**Visualizar la oferta**: si el CTA dice "pago contra entrega" se ve un repartidor de plastilina en
la puerta; si dice "garantía", un apretón de manos. No un plano genérico del producto.

## El set de testeo: el semilla + variantes (la entrega no es un anuncio suelto)

Toda campaña ABO de testeo arranca con **4 creativos**. Las variantes salen **del anuncio semilla y
de nada más**, y cada una **mueve UN solo eje**:

| # | Qué es | Eje | Clips nuevos | Cómo se hace |
|---|---|---|---|---|
| AD1 | el semilla | — | los suyos | `ad-01.json` |
| AD2 | gancho nuevo | 1 · Gancho | 0-2 | otra línea 1 en el guion → `gen:voz --solo 1` → `ad-02.json` |
| AD3 | otra estructura (en reversa, lista, dos tiempos, pregunta-respuesta) | 2 · Estructura | 2-4 | reordenar `beats` en `ad-03.json` |
| AD4 | otra puesta en escena (villano, set, escala o protagonista — uno solo) | 4 · Puesta en escena | 5-7 | `gen:clips --solo …` con prompts nuevos |
| AD5 | otra voz (género, registro, ritmo, o que narre el villano) | 3 · Voz | 0 | `"voz"` distinta en el guion → `gen:voz --forzar` |
| AD6 | versión corta 20-30 s, otros SFX, otra cama | 5 · Corte | 0 | otro `ad-06.json` |

Reglas: ninguna variante canibaliza a otra; **la oferta, el precio y la garantía no se tocan**;
reusar siempre los planos de cierre. Un set de 6 casi nunca cuesta más que uno de 4.

## Costo

| Pieza | Costo |
|---|---|
| Imagen de toma o B-roll (gpt-image-2, 9:16) | $0,0085 |
| Clip de una imagen (`veo3.1-lite`, 8 s) | $0,07 |
| Clip en modo frame (`veo3.1-fast`, 8 s) | $0,14 |
| Voz de una línea + transcripción | ~$0,01 |
| Música (Suno, una vez por registro) | $0,05 |
| **Anuncio de 7 tomas + 7 B-roll** | **≈ $1,10** (con 3 tomas en modo frame, ≈ $1,30) |

Contar ~15 % de reintentos: Veo se desvía y regenerar un clip ($0,07) es más barato que entregarlo
roto. La única medida válida es lo que imprime `Facturado real`.

## QC de cada clip (lo hace `gen-clips`, y después hay que MIRAR)

- `ffprobe`: 720×1280 y ~8 s. **El letterbox oculto** (área activa 720×1080 con 100 px de barra
  negra arriba y abajo, y ffprobe informa 720×1280 igual) se detecta midiendo el escalón de brillo a
  la altura de la barra y **se corrige solo** (`crop=608:1080:56:100` + `scale=720:1280`).
- **Mirar frames de cada clip**: el QC técnico aprueba clips rotos.

| Defecto | Arreglo |
|---|---|
| Deriva a CGI liso / plástico brillante | regenerar el **video**; si insiste, una sola acción por clip |
| El personaje cambia de forma o color entre tomas | regenerar la **imagen** con el Character Bible idéntico |
| Materiales reales (vidrio, metal, tela) | regenerar la imagen con "sculpted in matte plasticine" sobre ese objeto |
| Huellas caóticas, acabado amateur | regenerar la imagen con "refined controlled sculpting marks" |
| Interfaz falsa quemada (barra, reloj, cruz) — sobre todo en el CTA | reintentar (es estocástico); tapar con B-roll |
| Flash de 1-2 cuadros al final | el montaje corta desde 0,3 s y rara vez llega al final; si llega, acortar el plano |
| Bloqueo del filtro de contenido | probabilístico y no se cobra: el script reintenta una vez; si repite, reformular |

## Montaje: la gramática, ya implementada

- **La voz se genera PRIMERO y manda el ritmo.** `palabras ÷ 2,4` casi nunca coincide con el mp3.
- **1,15x** sobre el crudo (no pasar de ~1,25x: se pierde la cadencia de stop-motion).
- **Nunca más de ~3 s del mismo plano**; el B-roll entra sobre la palabra que ilustra.
- **Captions quemadas, palabra por palabra, idénticas a las de la plantilla 2**: blancas, contorno 6,
  sombra 3, centro exacto, cuerpo 88/1920. **El texto sale del guion; los tiempos, de la voz** (del
  `.words.json` si lo dejó `gen:voz`, o de whisper-1 por APIMART). Mirar siempre la línea
  `interpoladas …`: dice qué palabras se colocaron a ojo.
- **Un golpe en cada corte**: `whoosh` al cambiar de beat, `pop` al cambiar de plano, 60 ms antes
  del corte para que caiga *sobre* el cambio. `alimiter` al final. Otros SFX disponibles en
  `public/sfx/`: `glitch`, `pop-hi`, `pop-bell`, `crystal-bell`, `riser`.
- Cama musical al 10 % con fundido de salida de 1,5 s. `amix` con `normalize=0` (sin eso la voz baja
  a la mitad en silencio) y `-map_metadata -1` (el MP3 arrastra un chapter track que ensucia el mp4).
- Salida 1080×1920 · CFR 30 · High 4.0 · aac 192k · faststart. Si el master queda bajo −18 LUFS se
  normaliza a −16 solo.

## Pozos
1. **Calcular el montaje antes de tener la voz.** Ya no hace falta: los planos se ajustan a la voz.
   Pero si se escriben segundos a mano, son proporciones, no absolutos.
2. **Pegarle el `Negative prompt:` al generador de imágenes.** No tiene campo de negativos y termina
   dibujando lo que querías evitar. Se convierte a positivo (la coletilla ya lo hace).
3. **`veo3.1-lite` no soporta modo frame ni lip-sync.** Para eso es `fast`; el script lo elige solo
   según haya `fin`.
4. **Un clip con letterbox pasa `ffprobe`.** Por eso el QC mide el escalón de brillo, no las
   dimensiones.
5. **Dos corridas a la vez sobre el mismo `slug` se pisan.** Una tanda por slug.
6. **Reusar un inserto en otro idioma** solo si no muestra texto legible (los prompts lo prohíben,
   pero mirar igual).
