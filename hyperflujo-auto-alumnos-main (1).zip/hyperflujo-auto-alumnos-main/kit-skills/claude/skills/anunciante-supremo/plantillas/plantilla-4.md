# Plantilla 4 — "Zack D Films" (animación 3D tipo Pixar en capítulos + voz en off)

Motor **ffmpeg puro** · **mismo pipeline que la plantilla 3** (`gen-clips` → `gen-voz` → `montar`),
con `"estilo": "zack"` · **velocidad 1,12x** · **música fija del estilo** (`public/musica/zack-d-films.mp3`).

Anuncio vertical (1080×1920) contado por una voz en off sobre **animación 3D cinematográfica estilo
Pixar/Disney**, en **cuatro capítulos** que explican un mecanismo con un giro narrativo: personaje en
situación → producto → **mecanismo interno** (macro estilizada de lo que pasa adentro) → payoff.
Captions quemadas palabra por palabra, un golpe en cada corte, y **siempre la misma pista musical**:
es parte del ADN del estilo igual que el look Pixar. No se pregunta, no se elige, no se genera otra.

**Los clips no tienen idioma adentro**: traducir el anuncio es regenerar la voz y volver a montar.

## Leer primero la plantilla 3
Esquemas de `guion.json` y `ad-NN.json`, comandos, QC del letterbox, montaje, SFX y pozos son **los
mismos** (`plantillas/plantilla-3.md`). Acá va solo lo que cambia.

## Lo que cambia respecto a la plantilla 3

| | Plantilla 3 (claymation) | Plantilla 4 (zack) |
|---|---|---|
| `estilo` | `claymation` | `zack` |
| Velocidad | 1,15x | **1,12x** — las tomas de mecanismo son planos lentos a propósito |
| Música | se elige por guion (`musica.id`) | **fija**: se omite `musica` y el montador usa la del estilo |
| `volMusica` | 0.10 | **0.141** (−17 dB): la pista está masterizada fuerte (−11,6 LUFS) |
| `gap` | 0.20 | 0.18 |
| Modo frame | tomas de transformación | **todo el Capítulo 3** y las transformaciones de producto |
| Coletilla de imagen | plastilina refinada | Pixar-Disney cálido; **semi-3D clínico** en las tomas con `"mecanismo": true` |

### `"mecanismo": true` en una toma
Marca una toma del **Capítulo 3**. Cambia la coletilla de imagen al modo **semi-3D suave** (plástico
mate a satinado, geometría simplificada, luz plana y clínica, sujeto apoyado con sombra de contacto,
fondo parejo y brillante de borde a borde) y, con `fin`, el prompt de video pasa a **cámara fija: solo
cambia el estado físico del sujeto** entre el primer y el último cuadro. Es intencional que se vea más
limpio y clínico que el resto del anuncio.

**El fondo de las tomas de mecanismo se decide UNA vez para todo el anuncio**, y se escribe igual en
todos los prompts del Cap. 3:
- **A · grid técnico azul**: `bright blue grid floor and background in vivid cyan-blue tones (#00BFFF
  to #87CEEB range), made of thin light cyan grid lines, extending evenly with consistent bright
  saturation, no darkening toward the edges`. **Nunca** "dark", "gradient into darkness" ni nada que
  sugiera sombra: es azul uniforme de punta a punta (error confirmado, no repetirlo).
- **B · estudio limpio sin grid**: fondo neutro claro (blanco, gris claro o crema), gradiente simple.

**El par START/END es lo frágil del estilo.** El `fin` se escribe **copiando el prompt de `imagen`
palabra por palabra y cambiando solo la oración del estado físico**: mismo ángulo, encuadre, luz,
fondo y paleta. Generar el START, mirarlo, y recién ahí el END. Si el END cambió el ángulo o el
color del fondo, regenerar **la imagen**, nunca el video: un par desalineado hace que Veo invente
una transición que no es la pedida.

## Cómo se escribe el anuncio

### Los cuatro capítulos
1. **Personaje/situación** — alguien viviendo una escena cotidiana del problema, en un **ambiente
   concreto** (casa, oficina, gimnasio), nunca un estudio vacío.
2. **Producto** — el empaque real o estilizado, con ingredientes cayendo o flotando alrededor. Si hay
   foto del envase, va como `referencia`. ⚠️ **Nunca "no text" en esta toma**: borra la etiqueta real.
   La coletilla del estilo prohíbe *overlays añadidos*, no el texto impreso del producto.
3. **Mecanismo interno** — macro estilizada de lo que pasa dentro del cuerpo: partículas o moléculas
   con caritas, luz cálida, sensación mágica y no clínica en el B-roll; **tomas con `mecanismo: true`
   y `fin`** para el cambio de estado.
4. **Resultado/payoff** — la consecuencia social o emocional, a veces con humor o un giro. Si el CTA
   menciona envío gratis, contra entrega o garantía, se **visualiza** (el repartidor en la puerta).

Si una línea no encaja en un capítulo, sobra o se fusiona con la anterior.

### El ángulo (default: problema mal entendido + revelación del mecanismo)
1. Un problema que parece superficial o cosmético ("podría parecer que es solo cómo se ven tus piernas").
2. "Pero debajo de la superficie, algo está pasando."
3. **El mecanismo explicado con claridad**, a veces con escalada dentro de la misma escena (mañana →
   mediodía → noche).
4. "Ahora imagina en cambio…" → el producto como respuesta a ESE mecanismo.
5. Resultado + CTA.

Otros: mito vs. realidad, cifra shockeante, comparación numerada, relato de descubrimiento ("notó que
sus cabras estaban raras desde que comieron la planta").

**El mecanismo único del producto es la materia prima del Capítulo 3.** Si el producto no tiene uno
visualizable, decirlo antes de escribir y proponer qué se visualiza en su lugar.

**Hook**: una pregunta rara que abre un loop y no se resuelve hasta el final (`plantillas/hooks.md`).
Mínimo 30 s; `segundos × 2,4 palabras` para escribir, el mp3 para montar. La música tiene su arco
natural entre 0:00 y 0:40: un anuncio de 30-40 s cae clavado sobre esa subida sin editar nada.

### Prompts por capítulo (lo que va en `tomas[].imagen`)
- **Cap. 1 y 4**: `[personaje y situación], realistic-stylized environment ([lugar concreto]),
  expressive facial detail, warm cinematic lighting`. Video: un `Camera:` y un `Motion:`.
- **Cap. 2**: `[producto/empaque], clean product presentation with related elements floating or
  falling around it`.
- **Cap. 3** (`mecanismo: true` + `fin`): 5-7 oraciones concretas — sujeto y material, estado físico
  exacto, construcción del entorno (A o B), luz, ángulo y distancia, relación espacial ("resting
  naturally with a soft contact shadow", nunca flotando).
- **B-roll**: `Stylized 3D macro visualization of [proceso] moving across an organic surface,
  semi-transparent warm-toned tissue, glowing particles or molecule-like spheres with subtle
  expressive faces, warm golden-orange light, premium documentary visualization style`.

La verticalidad va **dentro** del prompt (la coletilla ya la agrega): sin eso el generador devuelve
horizontal y la tanda entera va a la basura.

## El set de testeo (semilla + variantes)

Igual que en la plantilla 3, con un eje propio:

| # | Qué es | Eje | Clips nuevos | Costo aprox. |
|---|---|---|---|---|
| AD1 | el semilla | — | los suyos | — |
| AD2 | gancho nuevo | 1 · Gancho | 0-2 `lite` | $0-0,14 |
| AD3 | otro orden de capítulos (cold open por el payoff · lista/conteo · pregunta-respuesta · mecanismo primero) | 2 · Estructura | 0-2 | $0-0,14 |
| AD4 | **otra metáfora del mecanismo** — mismo guion, otra manera de dibujar el Cap. 3 (un filtro que retiene, una cerradura que no gira, una señal que rebota) | 3 · Metáfora | 4-5 `fast` + su B-roll | ~$0,90 |
| AD5 | otra voz | 4 · Voz | 0 | $0 |
| AD6 | versión corta | 5 · Corte | 0 | $0 |

**El Capítulo 3 es lo caro** (modo frame, dos imágenes por toma): una sola variante del set lo toca.
**Los Capítulos 2 y 4 se reusan siempre.** La oferta, el precio y la garantía no se tocan.

## Costo de referencia

| Alcance | Qué incluye | Aprox. |
|---|---|---|
| Solo el semilla | 11 tomas (3-4 en modo frame) + 11 B-roll | ~$2,1 |
| **Set de 4** | semilla + gancho + estructura + otra metáfora | ~$3,1 |
| Set de 6 | los 4 + voz nueva + versión corta | ~$3,1 (los dos últimos son gratis) |

Medido en una tanda real: 11 tomas + 11 B-roll = $2,41 con 25 imágenes y 3 reintentos de video.

## La música fija: qué es y cómo se usa

`public/musica/zack-d-films.mp3` — 2:01,5, MP3 48 kHz estéreo, **−11,6 LUFS integrados**, true peak
+0,1 dBFS. Es un master fuerte y parejo: **debajo de la voz hay que bajarla mucho**. `volMusica`
0.141 son −17 dB (≈ −28,9 LUFS): rango útil −14 dB (0.2) si la voz quedó muy fuerte, −20 dB (0.1)
si quedó baja. Nunca a 0 dB.

| Tramo | Qué hace | Para qué |
|---|---|---|
| 0:00–0:12 | intro suave | el hook del Cap. 1 respira |
| 0:12–0:40 | sube sostenido hasta el pico (0:38) | el mecanismo y el payoff caen sobre la subida |
| 0:40–0:46 · 0:56–1:02 · 1:38–1:44 | bajones | cortes naturales si el anuncio es más largo |

**Empezar en 0:00 en un anuncio de 30-40 s.** Para más largos, entrar con `musica.desde` en un bajón,
nunca a mitad de una subida. `montar` la pone con loop, fundido de salida y `normalize=0`; no
mezclarla a mano.

## Defectos propios del estilo

| Defecto | Arreglo |
|---|---|
| Deriva a 3D genérico / videojuego | regenerar el **video**; si insiste, una sola acción por clip |
| En Cap. 3 la cámara se mueve o el fondo cambia entre start y end | el par estaba desalineado: regenerar el **END** copiando el prompt del start |
| El grid azul se oscurece hacia los bordes | regenerar la imagen: "evenly and brightly lit edge to edge" |
| La etiqueta del producto sale en blanco o inventada | se mandó "no text" en el Cap. 2: regenerar con `referencia` |
| Interfaz falsa quemada (sobre todo en el CTA) | reintentar; tapar con B-roll |
| Letterbox oculto | `gen-clips` lo detecta y lo recorta solo |

Al terminar, verificar el mp4: 1080×1920, `r_frame_rate` == `avg_frame_rate` (si difieren, la subida
a Meta se congela al 80 % sin error), dos streams, y entre −16 y −14 LUFS (el montador normaliza si
quedó bajo).
