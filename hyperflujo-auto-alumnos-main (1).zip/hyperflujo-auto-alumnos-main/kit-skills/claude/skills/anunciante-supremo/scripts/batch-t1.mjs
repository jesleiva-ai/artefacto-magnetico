// Batch de anuncios PLANTILLA 1 (b-roll + voz en off).
//
// Uso:
//   node scripts/batch-t1.mjs input/anuncios out/anuncios          # todos los ad-*.json de esa carpeta
//   node scripts/batch-t1.mjs input/anuncios out/anuncios 03 05    # solo esos números
//
// Por cada ad-NN.json:
//   1. limpia public/media/t1  2. siembra resaltes reusados (public/media/lib) y música (public/media/_music)
//   3. corre gen-t1.mjs (voz + timeline b-roll)  4. render plantilla-1  5. speed 1.25x
// Los assets de cada anuncio quedan archivados en public/media/_ads/<slug>/ para poder rehacerlo.
import { CWD_ORIGINAL } from "./lib/raiz.mjs";
import { execFileSync } from "node:child_process";
import {
  readFileSync, writeFileSync, existsSync, mkdirSync,
  readdirSync, rmSync, copyFileSync,
} from "node:fs";
import { resolve, join } from "node:path";
import { cpus, totalmem } from "node:os";

const SRC_DIR = resolve(CWD_ORIGINAL, process.argv[2] || "input/anuncios");
const OUT_DIR = resolve(CWD_ORIGINAL, process.argv[3] || "out/anuncios");
const ONLY = process.argv.slice(4);
const SPEED = 1.25;
// Concurrencia del render = cuantos Chrome dibujan frames a la vez.
// Se calcula segun la maquina, para que esto ande igual en una notebook modesta que en
// un equipo grande. Forzar con T1_CONCURRENCY=<n> si hace falta.
//
// Calibrado 2026-08-23 en una notebook de 16 hilos / 16 GB, sobre dos anuncios reales:
//   anuncio de 61s, 12 b-rolls  ->  conc 4: 199-222s | conc 8: 142s | conc 12: 113s | conc 16: 184s
//   anuncio de 77s, 40 b-rolls  ->  conc 4: 312s     |              | conc 12: 205s
// OJO: mas NO es mejor. A conc 16 (= todos los hilos) no le queda CPU al SO ni al proceso
// coordinador y el tiempo casi se duplica. Por eso la formula usa 75% de los hilos.
// El flujo de video sale IDENTICO (mismo MD5) con 4, 8 y 12: la concurrencia acelera sin
// cambiar un pixel. RAM: 7.8 GB a conc 4, 8.9 GB a conc 16 -> el cuello es CPU, no memoria.
// La vieja advertencia de "No frame found at position" con >15 clips no se reprodujo
// a conc 12 ni con 40 clips. Si reaparece, bajar con T1_CONCURRENCY.
const autoConcurrency = () => {
  const hilos = cpus().length || 4;
  const porCpu = Math.floor(hilos * 0.75);              // dejar aire para el SO
  const porRam = Math.floor(Math.max(1, totalmem() / 1024 ** 3 - 4) / 0.7);
  return String(Math.max(2, Math.min(porCpu, porRam, 16)));
};
const CONC = process.env.T1_CONCURRENCY || autoConcurrency();
// Sin modo GPU: el ffmpeg que Remotion trae adentro solo tiene libx264/libx265
// compilados (ni rastro de NVENC), asi que --hardware-acceleration no hace nada aca.
// Medido 2026-08-23 con Remotion 4.0.487.
const renderArgs = (out) => ["remotion", "render", "plantilla-1", out, `--concurrency=${CONC}`];

const WORK = resolve("public/media/t1");
const LIB = resolve("public/media/lib");
const MUSIC_LIB = resolve("public/media/_music");
const ARCHIVE = resolve("public/media/_ads");

const ensure = (d) => { if (!existsSync(d)) mkdirSync(d, { recursive: true }); };
// En Windows npx es un .cmd y necesita shell: las rutas con espacios (C:\\Users\\Maria Jose\\...)
// van entre comillas para que la consola no las parta.
const WIN = process.platform === "win32";
const q = (a) => (WIN && /[\s&()^]/.test(a) ? `"${a}"` : a);
const run = (cmd, args) => execFileSync(cmd, WIN ? args.map(q) : args, { stdio: "inherit", shell: WIN });

ensure(resolve(OUT_DIR));
ensure(ARCHIVE);

const files = readdirSync(resolve(SRC_DIR))
  .filter((f) => /^ad-\d+(-[\w-]+)?\.json$/i.test(f))
  .filter((f) => !ONLY.length || ONLY.some((n) => f.startsWith(`ad-${String(n).padStart(2, "0")}`)))
  .sort();

if (!files.length) { console.error(`No hay ad-*.json en ${SRC_DIR}`); process.exit(1); }

console.log(`\n📦 Batch plantilla 1 — ${files.length} anuncio(s) desde ${SRC_DIR}\n`);

// --- Chequeo previo: que existan TODOS los slugs reusados y las músicas (antes de gastar voz) ---
const missing = [];
for (const f of files) {
  const ad = JSON.parse(readFileSync(resolve(SRC_DIR, f), "utf8"));
  for (const h of ad.highlights || []) {
    if (h.reuse && !existsSync(join(LIB, `${h.reuse}-cut.png`))) missing.push(`${f}: reuse "${h.reuse}"`);
  }
  if (ad.music && !existsSync(join(MUSIC_LIB, `music-${ad.music}.mp3`))) missing.push(`${f}: music "${ad.music}"`);
}
if (missing.length) {
  console.error("❌ Faltan recursos en la biblioteca:\n  - " + missing.join("\n  - "));
  process.exit(1);
}
console.log("✅ Biblioteca completa (resaltes + música reusados, sin gasto en generación)\n");

const done = [];
for (const f of files) {
  const ad = JSON.parse(readFileSync(resolve(SRC_DIR, f), "utf8"));
  const slug = ad.slug || f.replace(/\.json$/, "");
  console.log(`\n═══ ${f} — ${ad.title}`);

  if (existsSync(resolve(OUT_DIR, `${slug}.mp4`)) && !process.env.FORCE) {
    console.log("  ⏭  ya existe el mp4 final, lo salto (FORCE=1 para rehacerlo)");
    done.push(resolve(OUT_DIR, `${slug}.mp4`));
    continue;
  }

  // 1. limpiar carpeta de trabajo
  rmSync(WORK, { recursive: true, force: true });
  ensure(WORK);

  // 2. brief activo + siembra
  writeFileSync(resolve("input/ad-t1.json"), JSON.stringify(ad, null, 2));
  (ad.highlights || []).forEach((h, k) => {
    if (h.reuse) copyFileSync(join(LIB, `${h.reuse}-cut.png`), join(WORK, `hl-${k}-cut.png`));
  });
  if (ad.music) copyFileSync(join(MUSIC_LIB, `music-${ad.music}.mp3`), join(WORK, "music.mp3"));

  // Reanudable: si ya se generó la voz de este anuncio, se restaura del archivo
  // (no se vuelve a generar la voz) junto con su timeline de b-roll.
  const arc = join(ARCHIVE, slug);
  ensure(arc);
  const cachedVoice = existsSync(join(arc, "voz.mp3")) && existsSync(join(arc, "words.json"));
  if (cachedVoice) {
    copyFileSync(join(arc, "voz.mp3"), join(WORK, "voz.mp3"));
    copyFileSync(join(arc, "words.json"), join(WORK, "words.json"));
    console.log("  ↺ voz reusada del archivo (sin volver a generarla)");
  }
  if (cachedVoice && existsSync(join(arc, "t1.json"))) {
    copyFileSync(join(arc, "t1.json"), resolve("src/data/t1.json"));
  } else {
    // timeline de b-roll fresco (cada anuncio con sus propios cortes)
    writeFileSync(resolve("src/data/t1.json"), JSON.stringify({ durationInFrames: 0 }));
  }

  // 3. assets (voz + timestamps + timeline)
  run("node", ["scripts/gen-t1.mjs"]);

  // archivar assets ANTES de renderizar (para poder reanudar si el render falla)
  for (const a of readdirSync(WORK)) copyFileSync(join(WORK, a), join(arc, a));
  copyFileSync(resolve("src/data/t1.json"), join(arc, "t1.json"));

  // 4. render + 5. velocidad final (con un reintento: el compositor falla a veces)
  const raw = resolve(OUT_DIR, `_raw-${slug}.mp4`);
  const final = resolve(OUT_DIR, `${slug}.mp4`);
  try {
    run("npx", renderArgs(raw));
  } catch {
    console.log("  ⚠️  render falló, reintentando una vez…");
    rmSync(raw, { force: true });
    run("npx", renderArgs(raw));
  }
  run("node", ["scripts/speedup.mjs", String(SPEED), raw, final]);
  rmSync(raw, { force: true });
  // El modo `remux` de speedup.mjs deja el mp4 a 37,5 fps con un avg_frame_rate que no coincide
  // con el r_frame_rate: Meta lo lee como frame rate VARIABLE y la subida a la biblioteca de
  // multimedia se cuelga al ~80% sin dar error. Una pasada a CFR 30 fps lo deja subible.
  // (2026-08-24)
  run("node", ["scripts/normalizar-meta.mjs", final]);

  done.push(final);
  console.log(`✅ ${slug}.mp4`);
}

console.log(`\n🎉 Listo: ${done.length} anuncio(s) en ${OUT_DIR}\n` + done.map((d) => "   " + d).join("\n"));
