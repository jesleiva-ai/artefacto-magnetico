// Batch de anuncios PLANTILLA 2 (UGC A-roll cosido).
//
// Uso:
//   node scripts/batch-t2.mjs input/ejemplo-t2 out/ejemplo-t2
//   node scripts/batch-t2.mjs input/ejemplo-t2 out/ejemplo-t2 01 04
//
// Reanudable: saltea los que ya tienen mp4 (FORCE=1 para rehacerlos) y la transcripción
// queda cacheada por anuncio, así que un reintento no vuelve a pedirla.
import { readdirSync, readFileSync, existsSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";
import { loadEnv } from "./lib/env.mjs";
import { ensamblar } from "./ensamblar-t2.mjs";

try { loadEnv(); } catch { /* la llave puede venir del entorno */ }

const SRC = process.argv[2] || "input/ejemplo-t2";
const OUT = process.argv[3] || "out/ejemplo-t2";
const SOLO = process.argv.slice(4);

const archivos = readdirSync(resolve(SRC))
  .filter((f) => /^ad-\d+(-[\w-]+)?\.json$/i.test(f))
  .filter((f) => !SOLO.length || SOLO.some((n) => f.startsWith(`ad-${String(n).padStart(2, "0")}`)))
  .sort();

if (!archivos.length) { console.error(`No hay ad-*.json en ${SRC}`); process.exit(1); }
mkdirSync(resolve(OUT), { recursive: true });

console.log(`\n📦 Batch plantilla 2 — ${archivos.length} anuncio(s) desde ${SRC}\n`);

const hechos = [], fallados = [];
for (const f of archivos) {
  let brief, slug, salida, titulo;
  try {
    brief = JSON.parse(readFileSync(resolve(SRC, f), "utf8"));
    slug = brief.slug || f.replace(/\.json$/, "");
    salida = resolve(OUT, `${slug}.mp4`);
    titulo = brief.title ?? slug;
  } catch (e) {
    // Un brief que ni siquiera parsea no llega a renderizarse: no hace falta derivarle
    // slug ni salida, alcanza con el nombre del archivo para nombrarlo en el error.
    console.log(`\n═══ ${f}`);
    console.error(`  ❌ ${e.message}`);
    fallados.push(f);
    continue;
  }

  console.log(`\n═══ ${f} — ${titulo}`);
  if (existsSync(salida) && !process.env.FORCE) {
    console.log("  ⏭  ya existe, lo salto (FORCE=1 para rehacerlo)");
    hechos.push(salida);
    continue;
  }
  try {
    await ensamblar(resolve(SRC, f), { salida });
    hechos.push(salida);
  } catch (e) {
    console.error(`  ❌ ${e.message}`);
    fallados.push(f);
  }
}

console.log(`\n🎉 ${hechos.length} listo(s) en ${OUT}` +
  (fallados.length ? `\n⚠️  ${fallados.length} con error: ${fallados.join(", ")}` : ""));

// Salir con 1 si algo falló: `ensamblar-t2.mjs` y `verificar-t2.py` ya lo hacen, y encadenado
// en un pipeline un batch que falla entero pero devuelve 0 pasa desapercibido.
if (fallados.length) process.exit(1);
