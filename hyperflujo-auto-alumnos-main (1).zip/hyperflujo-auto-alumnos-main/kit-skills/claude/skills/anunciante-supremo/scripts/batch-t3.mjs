// Batch de anuncios de las plantillas 3 y 4 (voz en off + clips generados): monta todos los
// ad-*.json de una carpeta con scripts/montar.mjs.
//
//   node scripts/batch-t3.mjs input/ejemplo-t3 out/ejemplo-t3
//   node scripts/batch-t3.mjs input/ejemplo-t3 out/ejemplo-t3 01 03
//
// Reanudable: saltea los que ya tienen mp4 (FORCE=1 para rehacerlos). Las variantes del set de
// testeo son planes distintos sobre los mismos clips y voces, así que montar la tanda entera no
// genera nada nuevo.
import { readdirSync, readFileSync, existsSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";
import { loadEnv } from "./lib/env.mjs";
import { montar } from "./montar.mjs";

try { loadEnv(); } catch { /* la llave puede venir del entorno */ }

const SRC = process.argv[2] || "input/ejemplo-t3";
const OUT = process.argv[3] || "out/ejemplo-t3";
const SOLO = process.argv.slice(4);

const archivos = readdirSync(resolve(SRC))
  .filter((f) => /^ad-\d+(-[\w-]+)?\.json$/i.test(f))
  .filter((f) => !SOLO.length || SOLO.some((n) => f.startsWith(`ad-${String(n).padStart(2, "0")}`)))
  .sort();
if (!archivos.length) { console.error(`No hay ad-*.json en ${SRC}. Primero: npm run gen:clips y npm run gen:voz sobre el guion.json`); process.exit(1); }
mkdirSync(resolve(OUT), { recursive: true });
console.log(`\n📦 Batch plantillas 3/4 — ${archivos.length} anuncio(s) desde ${SRC}\n`);

const hechos = [], fallados = [];
for (const f of archivos) {
  let plan, salida;
  try {
    plan = JSON.parse(readFileSync(resolve(SRC, f), "utf8"));
    salida = resolve(OUT, `${plan.slug || f.replace(/\.json$/, "")}.mp4`);
  } catch (e) { console.log(`\n═══ ${f}`); console.error(`  ❌ ${e.message}`); fallados.push(f); continue; }
  console.log(`\n═══ ${f} — ${plan.title ?? plan.slug}`);
  if (existsSync(salida) && !process.env.FORCE) { console.log("  ⏭  ya existe, lo salto (FORCE=1 para rehacerlo)"); hechos.push(salida); continue; }
  try { await montar(resolve(SRC, f), { salida }); hechos.push(salida); }
  catch (e) { console.error(`  ❌ ${e.message}`); fallados.push(f); }
}
console.log(`\n🎉 ${hechos.length} listo(s) en ${OUT}` + (fallados.length ? `\n⚠️  ${fallados.length} con error: ${fallados.join(", ")}` : ""));
if (fallados.length) process.exit(1);
