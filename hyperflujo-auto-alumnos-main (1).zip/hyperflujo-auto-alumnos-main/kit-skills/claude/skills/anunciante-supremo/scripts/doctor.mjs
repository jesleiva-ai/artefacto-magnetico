// Chequeo de entorno y llaves. --fix instala npm. Multiplataforma.
import { existsSync, copyFileSync, readFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { loadEnv, mask } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const FIX = process.argv.includes("--fix");
const OS = process.platform;
const hint = (mac, linux, win) => (OS === "win32" ? win : OS === "darwin" ? mac : linux);
const has = (cmd, flag = "-version") => { try { execFileSync(cmd, [flag], { stdio: "pipe" }); return true; } catch (e) { return e.code !== "ENOENT"; } };
const py = () => ["python3", "python"].find((c) => { try { execFileSync(c, ["--version"], { stdio: "pipe" }); return true; } catch { return false; } });

const filas = [];
const ok = (l, d = "") => filas.push(["✅", l, d]);
const bad = (l, d) => filas.push(["❌", l, d]);
const info = (l, d) => filas.push(["ℹ️ ", l, d]);

const v = Number(process.versions.node.split(".")[0]);
v >= 18 ? ok(`Node.js ${process.versions.node}`) : bad("Node.js ≥ 18", hint("brew install node", "nvm install 22", "winget install OpenJS.NodeJS.LTS"));
if (existsSync(resolve(RAIZ, "node_modules"))) ok("node_modules");
else if (FIX) { try { execFileSync("npm", ["install"], { stdio: "inherit", cwd: RAIZ, shell: OS === "win32" }); ok("node_modules", "(instalado)"); } catch { bad("node_modules", "corre: npm install"); } }
else bad("node_modules", "corre: npm install (baja Remotion + Chrome headless, ~700 MB; solo la plantilla 1 lo usa)");
has("ffmpeg") ? ok("ffmpeg") : bad("ffmpeg", hint("brew install ffmpeg", "sudo apt install ffmpeg", "winget install Gyan.FFmpeg"));
has("ffprobe") ? ok("ffprobe") : bad("ffprobe", "viene con ffmpeg");
const p = py();
p ? ok(`Python (${p})`, "opcional: solo lo usa verificar-t2.py (QC forense de la plantilla 2)") : info("Python 3", "no encontrado; es opcional, no hace falta para producir anuncios");

try { loadEnv(); } catch { /* sin .env: la llave puede venir del entorno */ }
if (process.env.APIMART_API_KEY) {
  try { await apimart.probe(); ok("APIMART_API_KEY", `[${mask(process.env.APIMART_API_KEY)}] autenticada`); }
  catch (e) { bad("APIMART_API_KEY", e.message); }
} else bad("APIMART_API_KEY", "falta. Ponla como variable de entorno o en .env (copia .env.example). https://apimart.ai → API Keys");
process.env.ELEVENLABS_API_KEY
  ? ok("ELEVENLABS_API_KEY", "(opcional) la plantilla 1 usará ElevenLabs si brand.json tiene voiceId")
  : info("ELEVENLABS_API_KEY", "opcional — sin ella la voz sale por APIMART; con ella, mejor voz y captions más ajustadas");
if (existsSync(resolve(RAIZ, "src/brand.json"))) ok("src/brand.json");
else if (FIX) { copyFileSync(resolve(RAIZ, "src/brand.example.json"), resolve(RAIZ, "src/brand.json")); ok("src/brand.json", "(creado desde brand.example.json: edita CTA, color y voz)"); }
else bad("src/brand.json", "falta: cp src/brand.example.json src/brand.json (o --fix)");
existsSync(resolve(RAIZ, "public/musica/zack-d-films.mp3")) ? ok("música de la plantilla 4") : info("public/musica/zack-d-films.mp3", "falta la pista fija de la plantilla 4 (y del estilo viral): pon ahí un instrumental tuyo con licencia o uno de gen:musica — ver INSTALACION.md §2 bis");
existsSync(resolve(RAIZ, "public/sfx/whoosh.mp3")) && existsSync(resolve(RAIZ, "public/sfx/pop.mp3")) ? ok("SFX de corte") : bad("public/sfx/", "faltan whoosh.mp3 / pop.mp3");

const VERSION = JSON.parse(readFileSync(resolve(RAIZ, "package.json"), "utf8")).version;
console.log(`\n🩺 anunciante-supremo ${VERSION} — doctor\n`);
for (const [i, l, d] of filas) console.log(`  ${i} ${l.padEnd(26)} ${d}`);
const fallas = filas.filter((f) => f[0] === "❌").length;
if (fallas && !FIX) console.log("\n💡 node scripts/doctor.mjs --fix instala lo instalable (npm).");
console.log(fallas ? `\n⚠️  ${fallas} pendiente(s).\n` : "\n✨ Todo listo.\n");
process.exitCode = fallas ? 1 : 0; // no process.exit(): en Node ≥ 22 sobre Windows mata el proceso mientras undici cierra el socket del fetch
