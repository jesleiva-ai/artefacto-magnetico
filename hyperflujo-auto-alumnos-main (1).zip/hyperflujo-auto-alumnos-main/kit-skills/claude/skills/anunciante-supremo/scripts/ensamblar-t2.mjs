// PLANTILLA 2 — "UGC A-roll cosido".
//
// Uso:  node scripts/ensamblar-t2.mjs input/<campaña>/ad-NN.json [--debug] [--forzar]
//
// Cose los clips de A-roll ya generados (el diálogo viene grabado adentro), les superpone
// B-roll, quema las captions palabra por palabra y mezcla la música. Todo en UNA pasada de
// ffmpeg: esta plantilla no tiene una sola animación, así que no hay nada que renderizar
// cuadro a cuadro y Remotion no aporta.
import { execFileSync, spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { resolve, join, dirname, isAbsolute } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { alinear } from "./lib/alinear.mjs";
import { transcribir } from "./lib/transcribir.mjs";
import { construirEDL } from "./lib/edl-t2.mjs";
import { generarASS } from "./lib/ass-t2.mjs";
import { loadEnv } from "./lib/env.mjs";

// La raíz del proyecto, resuelta contra ESTE archivo y no contra el cwd — igual que hace
// lib/env.mjs con el .env. Esta skill se usa desde una sesión parada en la carpeta de un
// producto: con rutas relativas al cwd, la caché de transcripciones (public/media/_ugc) se
// crea en OTRO árbol y APIMART se vuelve a cobrar las 6 escenas en silencio, la fuente de las
// captions no se encuentra, y el mp4 aparece donde nadie lo busca.
const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), "..");

// Biblioteca de música compartida con la plantilla 1: `music-<id>.mp3`.
const BIBLIOTECA_MUSICA = resolve(RAIZ, "public/media/_music");

const ANCHO = 1080, ALTO = 1920, FPS = 30, CRF = 21;
const VELOCIDAD = 1.18, COLA = 0.25, INSERTO_DUR = 3.2, MUSICA_DB = -20;
// Un inserto de `imagen` es un mockup PUESTO ENCIMA del personaje, no un plano nuevo:
// entra en una caja del 80 % del cuadro y deja ver el A-roll alrededor.
const INSERTO_IMAGEN_REL = 0.8;
// QC de entrada (spec §5.1): los clips de A-roll son 9:16 y traen la voz adentro.
const ASPECTO = 9 / 16, ASPECTO_TOL = 0.01;
const CLIP_DUR = 8, CLIP_DUR_TOL = 1.0;   // Veo 3.1 entrega clips de 8 s fijos
const VOL_MIN_DB = -45;                    // por debajo de esto la "pista de audio" es silencio

// En un filter_complex, `\` y `:` son sintaxis. Una ruta de Windows sin escapar rompe el grafo.
// El escapado se consume en DOS pasadas (el parser del filtergraph y, adentro, el parser de
// AVOption): una sola barra invertida antes de los dos puntos sobrevive la primera pasada y
// se pierde en la segunda, y el `:` vuelve a leerse como separador. Hacen falta dos.
export const escaparFiltro = (p) => String(p).replace(/\\/g, "/").replace(/:/g, "\\\\:");
const f3 = (n) => Number(n).toFixed(3);

export function construirFiltro(edl, { ancho, alto, fps, velocidad, assPath, fontsDir, musica, modo }) {
  const partes = [];
  const nE = edl.escenas.length;
  const soloBroll = modo === "solo-broll";

  // MODO SOLO-BROLL: el audio del A-roll se conserva entero —es la voz grabada— y la capa de
  // video se reemplaza. No se ve la cara en ningún momento: lo que se ve son b-rolls y páginas
  // del producto. Es el item 4 de la escalera de variantes del método UGC, y el formato de los
  // anuncios que escalan mostrando el producto ("la página es el creativo").
  //
  // Por eso acá el A-roll se decodifica SOLO como audio (`concat` con v=0) y el lienzo pasa a
  // ser negro: los visuales no se superponen sobre una cara, la tapan por completo. Si quedara
  // un hueco sin cubrir se vería el negro, y por eso `construirEDL` aborta antes si la suma de
  // los visuales no tapa la línea de tiempo entera.
  if (soloBroll) {
    edl.escenas.forEach((e, i) => {
      partes.push(`[${i}:a]atrim=end=${f3(e.fin)},asetpts=PTS-STARTPTS[a${i}]`);
    });
    partes.push(edl.escenas.map((_, i) => `[a${i}]`).join("") + `concat=n=${nE}:v=0:a=1[ca]`);
    partes.push(`[ca]atempo=${velocidad}[sa]`);
    partes.push(`color=c=black:s=${ancho}x${alto}:r=${fps}:d=${f3(edl.duracionFinal)}[bg0]`);
  } else {
    edl.escenas.forEach((e, i) => {
      partes.push(`[${i}:v]trim=end=${f3(e.fin)},setpts=PTS-STARTPTS[v${i}]`);
      partes.push(`[${i}:a]atrim=end=${f3(e.fin)},asetpts=PTS-STARTPTS[a${i}]`);
    });
    partes.push(edl.escenas.map((_, i) => `[v${i}][a${i}]`).join("") +
      `concat=n=${nE}:v=1:a=1[cv][ca]`);
    partes.push(`[cv]setpts=PTS/${velocidad}[sv]`);
    partes.push(`[ca]atempo=${velocidad}[sa]`);
    partes.push(`[sv]scale=${ancho}:${alto}:flags=lanczos,fps=${fps}[bg0]`);
  }

  edl.insertos.forEach((ins, k) => {
    const idx = nE + k;
    // trim=duration primero: un inserto nunca debe aportar más metraje que su propia
    // ventana. Sin esto, un b-roll con cola nativa más larga que "dur" sigue produciendo
    // cuadros después de que enable() lo apaga, y overlay (shortest=false por defecto)
    // estira TODO el video de salida hasta esa cola — el CTA queda con audio mudo al final.
    // Los dos tipos de inserto entran DISTINTO, y es la gramática medida en los pilotos:
    //
    //   · b-roll (video): 9:16 nativo, ocupa el cuadro entero — es un cambio de plano.
    //   · imagen (mockup): NO tapa el cuadro. Se escala para entrar en una caja del
    //     INSERTO_IMAGEN_REL del cuadro conservando su relación, y se superpone CENTRADO
    //     sobre el personaje, que se sigue viendo alrededor. Es como entra el mockup en el
    //     tramo de los bonus del anuncio de referencia.
    //
    // En los dos casos, `force_original_aspect_ratio` en vez de un `scale=W:H` a secas: un
    // scale a la fuerza deforma todo lo que no sea 9:16, y los mockups de la casa son
    // cuadrados (1400×1400) — salían aplastados un 44 % en horizontal, justo la imagen que
    // el comprador va a reconocer después en la landing, y ningún chequeo la mira.
    // force_divisible_by=2 evita que el overlay caiga en un tamaño impar sobre yuv420p.
    //
    // En SOLO-BROLL la imagen deja de ser un mockup puesto encima de alguien: es el plano.
    // Va a cuadro completo, igual que el b-roll. Se rellena en vez de recortar porque lo que
    // se muestra ahí es la PRUEBA (una página del entregable, un mockup): recortarla para que
    // llene sería tapar justo el renglón que se está mostrando.
    const aCuadroCompleto = !ins.esImagen || soloBroll;
    const caja = aCuadroCompleto
      ? `${ancho}:${alto}`
      : `${Math.round(ancho * INSERTO_IMAGEN_REL)}:${Math.round(alto * INSERTO_IMAGEN_REL)}`;
    const encuadre = aCuadroCompleto
      ? `,pad=${ancho}:${alto}:(ow-iw)/2:(oh-ih)/2`   // llena el cuadro
      : "";                                          // el A-roll queda visible alrededor
    if (soloBroll) {
      // Fondo desenfocado en vez de barras negras. Un mockup de la casa es CUADRADO (1400×1400)
      // y en 9:16 deja un tercio del cuadro en negro — en modo normal no importaba porque abajo
      // estaba el A-roll, pero acá abajo no hay nada. Recortar tampoco sirve: lo que se muestra
      // es la PRUEBA, y recortarla corta justo el renglón que se está mostrando. Así que el
      // mismo visual se usa dos veces: una escalada para LLENAR y desenfocada como telón, y
      // encima la original intacta y centrada. Cuando la fuente ya es 9:16 el telón queda
      // completamente tapado y el resultado es idéntico a antes, así que no hay caso especial.
      partes.push(`[${idx}:v]trim=duration=${f3(ins.dur)},split=2[tel${k}][fig${k}]`);
      partes.push(`[tel${k}]scale=${ancho}:${alto}:force_original_aspect_ratio=increase:flags=lanczos,` +
        `crop=${ancho}:${alto},gblur=sigma=24[telb${k}]`);
      partes.push(`[fig${k}]scale=${ancho}:${alto}:force_original_aspect_ratio=decrease:` +
        `force_divisible_by=2:flags=lanczos[figb${k}]`);
      partes.push(`[telb${k}][figb${k}]overlay=x=(W-w)/2:y=(H-h)/2,fps=${fps},` +
        `setpts=PTS-STARTPTS+${f3(ins.t)}/TB[ins${k}]`);
    } else {
      partes.push(`[${idx}:v]trim=duration=${f3(ins.dur)},` +
        `scale=${caja}:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos` +
        `${encuadre},fps=${fps},` +
        `setpts=PTS-STARTPTS+${f3(ins.t)}/TB[ins${k}]`);
    }
    // La imagen se centra con x/y; el b-roll ya viene del tamaño del cuadro (0,0).
    const posicion = aCuadroCompleto ? "" : `x=(W-w)/2:y=(H-h)/2:`;
    partes.push(`[bg${k}][ins${k}]overlay=${posicion}` +
      `enable='between(t,${f3(ins.t)},${f3(ins.t + ins.dur)})'[bg${k + 1}]`);
  });

  partes.push(`[bg${edl.insertos.length}]ass=f=${escaparFiltro(assPath)}:` +
    `fontsdir=${escaparFiltro(fontsDir)}[vout]`);

  const idxMus = nE + edl.insertos.length;
  partes.push(`[${idxMus}:a]atrim=start=${musica.desde},asetpts=PTS-STARTPTS,` +
    `volume=${musica.db}dB[mus]`);
  // normalize=0 es obligatorio: por defecto amix divide por la cantidad de entradas
  // y la voz se va 6 dB para abajo.
  partes.push(`[sa][mus]amix=inputs=2:duration=first:normalize=0[aout]`);

  return partes.join(";");
}

export function construirArgs(edl, opts) {
  const args = ["-hide_banner", "-v", "error", "-y"];
  for (const e of edl.escenas) args.push("-i", e.ruta);
  for (const ins of edl.insertos) {
    if (ins.esImagen) {
      args.push("-loop", "1", "-t", String(ins.dur));
    } else if (ins.duracionArchivo && ins.dur > ins.duracionArchivo + 1e-6) {
      // Solo puede pasar en solo-broll, donde un visual tiene que cubrir más tiempo del que
      // dura su clip: 8 b-roll de 4,9 s para tapar 45 s obligan a repetir. Se loopea el input
      // las veces que haga falta en vez de exigir material nuevo; el `trim=duration` del
      // filtro lo corta en su ventana exacta.
      args.push("-stream_loop", String(Math.ceil(ins.dur / ins.duracionArchivo)));
    }
    args.push("-i", ins.ruta);
  }
  args.push("-i", opts.musica.ruta);
  args.push("-filter_complex", construirFiltro(edl, opts));
  args.push("-map", "[vout]", "-map", "[aout]");
  args.push("-c:v", "libx264", "-preset", "medium", "-crf", String(opts.crf ?? CRF),
    "-profile:v", "high", "-level", "4.0",
    "-r", String(opts.fps), "-fps_mode", "cfr", "-g", String(opts.fps * 2),
    "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
    "-movflags", "+faststart", opts.salida);
  return args;
}

const duracionDe = (f) => {
  const r = spawnSync("ffprobe", ["-v", "error", "-show_entries", "format=duration",
    "-of", "default=nw=1:nk=1", f], { encoding: "utf8" });
  const d = Number((r.stdout || "").trim());
  // Si ffprobe falla, "".trim() da NaN — y NaN != null es true en JS. construirEDL usa
  // justo `duracionArchivo != null` para saber si hay dato: con NaN, ese chequeo miente
  // (dice "sí hay dato"), y la comparación numérica que sigue (`dur > NaN`) es siempre
  // false, así que la guarda contra un b-roll más corto que "dur" queda desarmada en
  // silencio. null hace que `!= null` diga la verdad: "no hay dato".
  return Number.isFinite(d) ? d : null;
};

const tieneAudio = (f) => {
  const r = spawnSync("ffprobe", ["-v", "error", "-select_streams", "a:0",
    "-show_entries", "stream=codec_type", "-of", "default=nw=1:nk=1", f], { encoding: "utf8" });
  return (r.stdout || "").includes("audio");
};

const dimensionesDe = (f) => {
  const r = spawnSync("ffprobe", ["-v", "error", "-select_streams", "v:0",
    "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x", f], { encoding: "utf8" });
  const m = /^(\d+)x(\d+)/m.exec((r.stdout || "").trim());
  return m ? { ancho: Number(m[1]), alto: Number(m[2]) } : null;
};

// Volumen medio de la pista de audio. "Tiene pista de audio" no es lo mismo que "tiene voz":
// un clip mudo con pista presente pasa el chequeo de existencia y se va igual a APIMART, que
// cobra por transcribir silencio.
const volumenMedioDe = (f) => {
  const r = spawnSync("ffmpeg", ["-hide_banner", "-nostats", "-v", "info", "-i", f,
    "-map", "0:a:0", "-af", "volumedetect", "-f", "null", "-"], { encoding: "utf8" });
  const m = /mean_volume:\s*(-?\d+(?:\.\d+)?) dB/.exec(r.stderr || "");
  return m ? Number(m[1]) : null;
};

export async function ensamblar(rutaBrief, { debug = false, forzar = false, salida: salidaOpt = null } = {}) {
  const brief = JSON.parse(readFileSync(rutaBrief, "utf8"));
  const baseBrief = dirname(resolve(rutaBrief));
  const dirClips = isAbsolute(brief.clips) ? brief.clips : resolve(baseBrief, brief.clips);
  const velocidad = brief.velocidad ?? VELOCIDAD;
  const slug = brief.slug || "ad";
  const trabajo = resolve(RAIZ, "public/media/_ugc", slug);
  mkdirSync(trabajo, { recursive: true });

  // --- 1. QC de entrada, antes de gastar un centavo ---
  // Los cuatro chequeos del spec §5.1 por clip: existe · es 9:16 · la pista de audio tiene
  // volumen real · dura lo esperado. Cada uno nombra el archivo y el motivo, porque el punto
  // de la sección es abortar ANTES de pagarle a APIMART las N transcripciones (y antes de que
  // ffmpeg reviente en el `concat`, que es donde se descubre un clip con otra resolución).
  const faltan = [];
  const durEsperada = brief.duracionClip ?? CLIP_DUR;
  // Tolerancia configurable: los clips salen todos de 8 s del generador, pero si se les sacaron
  // los silencios antes de entrar acá (cabeza, huecos internos y cola) cada uno queda de un largo
  // distinto a proposito. El chequeo sigue sirviendo para pescar un clip faltante o roto.
  const durTol = brief.duracionClipTolerancia ?? CLIP_DUR_TOL;
  const tamanos = new Map();
  for (const e of brief.escenas) {
    const r = join(dirClips, e.clip);
    if (!existsSync(r)) { faltan.push(`clip ${e.clip}: no existe (${r})`); continue; }
    if (!e.dialogo) faltan.push(`${e.clip}: falta "dialogo" en el brief`);

    const dim = dimensionesDe(r);
    if (!dim) faltan.push(`${e.clip}: ffprobe no encuentra pista de video`);
    else {
      if (Math.abs(dim.ancho / dim.alto - ASPECTO) > ASPECTO_TOL)
        faltan.push(`${e.clip}: ${dim.ancho}×${dim.alto} no es 9:16`);
      tamanos.set(`${dim.ancho}×${dim.alto}`, (tamanos.get(`${dim.ancho}×${dim.alto}`) ?? []).concat(e.clip));
    }

    if (!tieneAudio(r)) faltan.push(`${e.clip}: sin pista de audio (¿clip mudo?)`);
    else {
      const db = volumenMedioDe(r);
      if (db == null) faltan.push(`${e.clip}: no pude medir el volumen de la pista de audio`);
      else if (db <= VOL_MIN_DB)
        faltan.push(`${e.clip}: la pista de audio está muda (mean_volume ${db} dB ≤ ${VOL_MIN_DB} dB)`);
    }

    const dur = duracionDe(r);
    if (dur == null) faltan.push(`${e.clip}: ffprobe no pudo leer la duración`);
    else if (Math.abs(dur - durEsperada) > durTol)
      faltan.push(`${e.clip}: dura ${dur.toFixed(2)}s y se esperaban ${durEsperada}s ` +
        `(±${durTol}); si el modelo entrega otro largo, declaralo con "duracionClip", ` +
        `y si los clips vienen de largos distintos a proposito, ensanchá "duracionClipTolerancia"`);
  }
  // concat exige un solo tamaño: dos clips 9:16 de resoluciones distintas también lo rompen.
  if (tamanos.size > 1)
    faltan.push("los clips no comparten resolución: " +
      [...tamanos].map(([t, cs]) => `${t} (${cs.join(", ")})`).join(" vs "));
  for (const ins of brief.insertos ?? []) {
    const nombre = ins.broll ?? ins.imagen;
    if (!nombre) { faltan.push(`inserto sin "broll" ni "imagen"`); continue; }
    const r = isAbsolute(nombre) ? nombre : join(dirClips, nombre);
    if (!existsSync(r)) faltan.push(`inserto ${nombre}: no existe (${r})`);
  }
  // La música se declara de dos formas, excluyentes entre sí:
  //   "id"      -> pista de la biblioteca compartida (public/media/_music/music-<id>.mp3),
  //                la misma que usa la plantilla 1. Es la vía normal.
  //   "archivo" -> ruta suelta, para una canción que vive en la carpeta del producto.
  // La música NO es opcional: el grafo referencia su input incondicionalmente.
  let rutaMusica = null, comoSeLlama = null;
  const { id: musicaId, archivo: musicaArchivo } = brief.musica ?? {};
  if (musicaId && musicaArchivo) {
    faltan.push(`música: "id" y "archivo" son excluyentes, elegí uno`);
  } else if (musicaId) {
    comoSeLlama = `id "${musicaId}"`;
    rutaMusica = join(BIBLIOTECA_MUSICA, `music-${musicaId}.mp3`);
    if (!existsSync(rutaMusica)) {
      const hay = existsSync(BIBLIOTECA_MUSICA)
        ? readdirSync(BIBLIOTECA_MUSICA)
            .filter((f) => /^music-.+\.mp3$/.test(f))
            .map((f) => f.replace(/^music-|\.mp3$/g, "")).sort().join(", ")
        : "(la biblioteca no existe)";
      faltan.push(`música: no hay ninguna pista con id "${musicaId}". Disponibles: ${hay}`);
      rutaMusica = null;
    }
  } else if (musicaArchivo) {
    comoSeLlama = musicaArchivo;
    rutaMusica = isAbsolute(musicaArchivo) ? musicaArchivo : resolve(dirClips, musicaArchivo);
    if (!existsSync(rutaMusica)) {
      faltan.push(`música ${musicaArchivo}: no existe (${rutaMusica})`);
      rutaMusica = null;
    }
  } else {
    faltan.push(`música: falta "musica.id" o "musica.archivo" en el brief (es obligatoria)`);
  }
  if (faltan.length) {
    throw new Error("QC de entrada — no arranco:\n  - " + faltan.join("\n  - "));
  }

  // --- 2 y 3. transcribir + alinear, escena por escena ---
  const escenas = [];
  for (const [i, e] of brief.escenas.entries()) {
    const ruta = join(dirClips, e.clip);
    const { words, deCache } = await transcribir(ruta, {
      idioma: brief.idioma, cacheDir: trabajo, apiKey: process.env.APIMART_API_KEY, forzar,
    });
    const al = alinear(words, e.dialogo, { cola: brief.cola ?? COLA });
    console.log(`  escena ${i + 1} ${deCache ? "(caché)" : "(API) "} — ` +
      `${al.palabras.length} palabras, corta en ${al.finEscena.toFixed(2)}s, ` +
      `cobertura ${(al.cobertura * 100).toFixed(0)}%`);
    for (const d of al.descartadas) console.log(`     ✂  descarto "${d}" (no está en el diálogo)`);
    // Estas son las peligrosas: palabras del brief que se quedan SIN CAPTION. La cobertura sola
    // no las delata (83 % pasa el umbral) y el anuncio sale con una palabra muda, que puede ser
    // justo el precio. Se avisan siempre, aunque la corrida siga.
    if (al.sinCaption.length)
      console.log(`     ⚠️  SIN CAPTION: ${al.sinCaption.map((w) => `"${w}"`).join(", ")}` +
        ` — Whisper no las dijo así. Si son números, escribilos en el brief como cifra (19, no "diciannove").`);
    for (const r of al.recortadas) console.log(`     ✂  "${r.texto}" ${r.antes}s → ${r.despues}s (estirada)`);
    if (al.cobertura < 0.8) {
      throw new Error(`La escena ${i + 1} (${e.clip}) no dice lo que el brief cree ` +
        `(cobertura ${(al.cobertura * 100).toFixed(0)}%).\n   Brief: ${e.dialogo}\n` +
        `   Clip:  ${words.map((w) => w.word).join(" ")}`);
    }
    // Whisper puede devolver timestamps que se PASAN del final del archivo (le cuelga el silencio
    // a la ultima palabra y la estira mas alla del ultimo frame). Si finEscena queda mas larga que
    // el clip, `trim=end=` no falla: entrega lo que hay y el resto es tiempo fantasma. El video se
    // rellena hasta ese largo pero el AUDIO no, asi que la voz se adelanta y arrastra a los
    // subtitulos y a los insertos, con un error que se ACUMULA escena a escena.
    // Se descubrio el 2026-09-03 en un anuncio en francés: dos escenas con 0,73 s y 0,43 s de
    // fantasma dejaban el audio ~1,1 s adelante del video al final del anuncio.
    const durReal = duracionDe(ruta);
    let fin = al.finEscena;
    if (durReal != null && fin > durReal) {
      console.log(`     ⚠️  corte recortado de ${fin.toFixed(2)}s a ${durReal.toFixed(2)}s ` +
        `(el clip no llega; Whisper se pasó del final del archivo)`);
      fin = durReal;
    }
    escenas.push({ clip: e.clip, ruta, finEscena: fin, palabras: al.palabras });
  }

  // --- 4. EDL ---
  const modo = brief.modo ?? "normal";
  if (!["normal", "solo-broll"].includes(modo))
    throw new Error(`"modo" desconocido: "${modo}" (valores: "normal", "solo-broll")`);
  if (modo === "solo-broll")
    console.log(`  modo SOLO-BROLL: se conserva el audio del A-roll y la cara no se ve en ningún momento`);
  const insertos = (brief.insertos ?? []).map((ins) => {
    const nombre = ins.broll ?? ins.imagen;
    const ruta = isAbsolute(nombre) ? nombre : join(dirClips, nombre);
    const esImagen = Boolean(ins.imagen);
    // En solo-broll NO se pone default: `dur` vacío significa «hasta el siguiente visual»,
    // y meterle 3.2 acá lo convertiría en un hueco de los que abortan la corrida.
    const durBrief = ins.dur ?? (modo === "solo-broll" ? undefined : INSERTO_DUR);
    return { ...ins, ruta, esImagen, dur: durBrief,
      duracionArchivo: esImagen ? null : duracionDe(ruta) };
  });
  const edl = construirEDL({ escenas, insertos, velocidad, modo,
    maxCaraSinInserto: brief.maxCaraSinInserto ?? 4.8 });
  for (const a of edl.avisos) console.log(`  ⚠️  ${a}`);
  writeFileSync(join(trabajo, "edl.json"), JSON.stringify(edl, null, 2));

  // --- 5. subtítulos ---
  const assPath = join(trabajo, "subs.ass");
  writeFileSync(assPath, generarASS(edl.palabras, { ancho: ANCHO, alto: ALTO, ...(brief.captions ?? {}) }), "utf8");

  // --- 6. una pasada de ffmpeg ---
  // Precedencia: lo que pase el batch > lo que diga el brief > el default.
  // El default cuelga de la raíz del proyecto (no del cwd): "out/" es una carpeta de ESTA
  // skill. Una `salida` explícita sí se resuelve contra el cwd — el que la escribe sabe dónde
  // está parado.
  const salidaPedida = salidaOpt ?? brief.salida ?? null;
  const salida = salidaPedida ? resolve(salidaPedida) : resolve(RAIZ, "out", `${slug}.mp4`);
  mkdirSync(dirname(salida), { recursive: true });
  const opts = { ancho: ANCHO, alto: ALTO, fps: FPS, velocidad, assPath, modo,
    fontsDir: resolve(RAIZ, "public/fonts"), salida,
    musica: { ruta: rutaMusica, desde: brief.musica.desde ?? 0, db: brief.musica.db ?? MUSICA_DB } };
  console.log(`  música: ${comoSeLlama} · desde ${opts.musica.desde}s · ${opts.musica.db} dB`);
  const args = construirArgs(edl, opts);

  if (debug) {
    writeFileSync(join(trabajo, "filtro.txt"), construirFiltro(edl, opts));
    console.log(`🧪 --debug: grafo en ${join(trabajo, "filtro.txt")}, no ejecuté ffmpeg`);
    return { edl, salida, args };
  }

  execFileSync("ffmpeg", args, { stdio: ["ignore", "ignore", "inherit"] });
  console.log(`✅ ${salida}  (${edl.duracionFinal.toFixed(2)}s)`);
  return { edl, salida, args };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  // Este archivo ES el punto de entrada: es el único que carga el .env, y solo cuando se
  // ejecuta como programa. Los módulos que importa (alinear/transcribir/edl-t2/ass-t2)
  // reciben todo por parámetro y no lo tocan; los tests importan este módulo por sus
  // funciones puras y no deben depender de que exista un .env.
  try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
  const rutaBrief = process.argv[2];
  if (!rutaBrief) { console.error("Uso: node scripts/ensamblar-t2.mjs <brief.json> [--debug] [--forzar]"); process.exit(1); }
  ensamblar(rutaBrief, {
    debug: process.argv.includes("--debug"),
    forzar: process.argv.includes("--forzar"),
  }).catch((e) => { console.error(`❌ ${e.message}`); process.exit(1); });
}
