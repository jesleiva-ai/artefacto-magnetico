// De un guion por escenas a los clips UGC de la plantilla 2, todo por APIMART:
//   frames (gpt-image-2, retrato forense) → clips (veo3.1-fast, frame mode, lip-sync) → QC
//   técnico (ffprobe) → QC de contenido (whisper + alineación contra el diálogo) → brief borrador.
//
//   node scripts/gen-aroll.mjs input/<campaña>/guion.json [--si] [--regenerar] [--solo 1,3]
//
// Reanudable: no vuelve a generar frames ni clips que ya existen. Con --regenerar, repite hasta
// 2 veces los clips que reprueban el QC de contenido (cobertura < 80 %).
import { existsSync, writeFileSync, mkdirSync, readFileSync } from "node:fs";
import { resolve, join, dirname, relative } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { loadEnv } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";
import { parseArgs } from "./lib/util.mjs";
import { estimar, confirmar, Contador } from "./lib/costo.mjs";
import { promptFrame, promptVideo, qcCobertura, briefBorradorT2 } from "./lib/aroll.mjs";
import { transcribir } from "./lib/transcribir.mjs";
import { generarBroll, esBloqueoDeContenido } from "./gen-broll.mjs";

try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const MODELO = () => process.env.APIMART_AROLL_MODEL || "veo3.1-fast";
const a = parseArgs(process.argv.slice(2));
const rutaGuion = a._[0];
if (!rutaGuion) { console.error("Uso: node scripts/gen-aroll.mjs input/<campaña>/guion.json [--si] [--regenerar] [--solo 1,3]"); process.exit(1); }
const guion = JSON.parse(readFileSync(resolve(rutaGuion), "utf8"));
for (const k of ["slug", "idioma", "personaje", "escenario", "encuadre", "escenas"]) if (!guion[k]) { console.error(`El guion no tiene "${k}"`); process.exit(1); }
const solo = a.solo ? String(a.solo).split(",").map(Number) : null;
const escenas = guion.escenas.filter((e) => !solo || solo.includes(e.n));
const brolls = (guion.broll || []).filter((b) => !solo || solo.includes(b.n));

const base = resolve(RAIZ, "public/media/_ugc", guion.slug);
const dirClips = join(base, "clips"), dirFrames = join(base, "frames");
mkdirSync(dirClips, { recursive: true }); mkdirSync(dirFrames, { recursive: true });
const clipDe = (n) => join(dirClips, `escena${n}.mp4`);

// --- costo y confirmación ---
const escFaltan = escenas.filter((e) => !existsSync(clipDe(e.n)));
const brFaltan = brolls.filter((b) => !existsSync(join(dirClips, `broll${b.n}.mp4`)));
const est = estimar([
  { tipo: "imagen", n: escFaltan.length * 2 + brFaltan.length },
  { tipo: "aroll", n: escFaltan.length },
  { tipo: "broll", n: brFaltan.length },
  { tipo: "voz", n: escFaltan.length },
]);
console.log(`🎬 A-roll «${guion.slug}» con ${MODELO()} — ${escFaltan.length} escena(s) y ${brFaltan.length} B-roll por generar`);
if ((escFaltan.length || brFaltan.length) && !(await confirmar({ ...est, si: !!a.si }))) process.exit(1);
const cont = new Contador();

// --- frames ---
// Escena 1: inicial y final propios. Desde la 2 con `encadenar`: el inicial ES el final anterior
// (misma URL, no se regenera) — la continuidad viene de ahí. Las URLs de APIMART expiran a las
// 24 h: el .json guarda `expira` y si quedó vieja se regenera el frame.
async function frame(nombre, accion) {
  const ruta = join(dirFrames, `${nombre}.png`), meta = join(dirFrames, `${nombre}.json`);
  if (existsSync(meta)) { const m = JSON.parse(readFileSync(meta, "utf8")); if (m.expira > Date.now() / 1000 + 600) return m; }
  const r = await apimart.generarImagen({ prompt: promptFrame({ ...guion, accion }), aspectRatio: "9:16" });
  cont.sumar(r.cost);
  writeFileSync(ruta, await apimart.descargar(r.url));
  const m = { url: r.url, ruta, expira: Number(r.raw?.data?.result?.images?.[0]?.expires_at || Date.now() / 1000 + 23 * 3600) };
  writeFileSync(meta, JSON.stringify(m));
  return m;
}

// --- QC ---
const probeDims = (f) => { const r = spawnSync("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:format=duration", "-of", "csv=p=0", f], { encoding: "utf8" }); return (r.stdout || "").replace(/\s+/g, " ").trim(); };
const maxVol = (f) => { const r = spawnSync("ffmpeg", ["-hide_banner", "-i", f, "-map", "0:a:0", "-af", "volumedetect", "-f", "null", "-"], { encoding: "utf8" }); const m = /max_volume:\s*(-?[\d.]+) dB/.exec(r.stderr || ""); return m ? Number(m[1]) : -99; };
async function qcClip(n, dialogo) {
  const f = clipDe(n);
  const dims = probeDims(f), vol = maxVol(f);
  const tecnico = /^720,1280/.test(dims) && vol > -30;
  const { words } = await transcribir(f, { idioma: guion.idioma, cacheDir: base, apiKey: process.env.APIMART_API_KEY, forzar: true });
  cont.sumar(0.01);
  const c = qcCobertura(words, dialogo);
  return { n, dims, vol, tecnico, ...c, ok: tecnico && c.ok };
}

// --- escenas ---
const rutaQc = join(base, "qc.json");
const qc = existsSync(rutaQc) ? JSON.parse(readFileSync(rutaQc, "utf8")) : {};
let finAnterior = null;
for (const e of escenas) {
  console.log(`\n═══ escena ${e.n}: ${e.dialogo.slice(0, 60)}…`);
  const ini = (guion.encadenar && finAnterior && e.n > 1) ? finAnterior : await frame(`escena${e.n}-ini`, e.accion || "mira a cámara, expresión neutra");
  const fin = await frame(`escena${e.n}-fin`, e.final || `${e.accion || "mira a cámara"}, un instante después, leve cambio de gesto`);
  finAnterior = fin;
  for (let intento = 0; intento < (a.regenerar ? 3 : 1); intento++) {
    if (!existsSync(clipDe(e.n)) || intento > 0) {
      // El filtro de contenido de Veo es probabilístico y el bloqueo no se cobra: un reintento.
      let v;
      for (let b = 0; b < 2; b++) {
        try {
          v = await apimart.generarVideo({ model: MODELO(), prompt: promptVideo({ escena: e, personaje: guion.personaje }),
            imageUrls: [ini.url, fin.url], generationType: "frame", aspectRatio: "9:16", resolution: "720p", duration: 8,
            onTick: (s) => process.stdout.write(s === "pendiente" ? "." : "\n") });
          break;
        } catch (err) {
          if (!esBloqueoDeContenido(err) || b === 1) throw err;
          console.log("  ↻ bloqueado por el filtro de contenido (no se cobra); reintento");
        }
      }
      cont.sumar(v.cost);
      writeFileSync(clipDe(e.n), await apimart.descargar(v.url));
    }
    const r = await qcClip(e.n, e.dialogo);
    qc[`escena${e.n}`] = r;
    writeFileSync(rutaQc, JSON.stringify(qc, null, 2));
    console.log(`  ${r.ok ? "✅" : "⚠️ "} ${r.dims} · pico ${r.vol} dB · cobertura ${(r.cobertura * 100).toFixed(0)} %${r.sinCaption.length ? " · sin caption: " + r.sinCaption.join(" ") : ""}`);
    if (r.ok) break;
    if (!a.regenerar) { console.log("  → reprueba. Reescribe la línea (las elípticas fallan más) o corre con --regenerar"); break; }
    console.log(`  ↻ regenerando (intento ${intento + 2})`);
  }
}

// --- b-roll ---
for (const b of brolls) {
  console.log(`\n═══ b-roll ${b.n}: ${b.prompt.slice(0, 60)}`);
  try { await generarBroll({ prompt: b.prompt, imagen: b.imagen ? resolve(dirname(resolve(rutaGuion)), b.imagen) : null, destino: join(dirClips, `broll${b.n}.mp4`), cont }); }
  catch (err) { console.error(`  ❌ ${err.message}`); }
}

// --- brief borrador de la plantilla 2 ---
const rutaBrief = join(dirname(resolve(rutaGuion)), "ad-01.json");
if (!existsSync(rutaBrief)) {
  const rel = relative(dirname(resolve(rutaGuion)), dirClips).split("\\").join("/");
  writeFileSync(rutaBrief, JSON.stringify(briefBorradorT2(guion, { clipsDir: rel }), null, 2));
  console.log(`\n📝 brief borrador: ${rutaBrief} — revisa los insertos (\`sobre\`) y la música antes de ensamblar`);
}
const reprobadas = Object.values(qc).filter((r) => !r.ok).map((r) => r.n);
console.log(`\n${cont.resumen(est.total)}` +
  (reprobadas.length ? `\n⚠️  escenas que reprueban el QC: ${reprobadas.join(", ")}` : "\n✅ todas las escenas pasan el QC") +
  `\nSiguiente: npm run batch:t2 ${relative(RAIZ, dirname(resolve(rutaGuion))).split("\\").join("/")} out/${guion.slug}`);
