// B-roll: insertos cortos sin diálogo. veo3.1-lite (imagen + prompt) es hoy el más barato que se
// ve bien ($0,07). El video exige una URL http para la imagen: si la semilla es un archivo local,
// pasa primero por gpt-image-2 (acepta data URI y devuelve la imagen alojada); si no hay semilla,
// gpt-image-2 genera el primer cuadro a partir del mismo prompt.
//
//   node scripts/gen-broll.mjs --prompts input/mi-campana/broll.json --out public/broll-mi-campana --nombre broll- [--si]
//
//   broll.json = [ { "prompt": "...", "imagen": "ruta/local.png" | null }, ... ]
//   --nombre broll-  → broll-01.mp4 (formato de la plantilla 1)
//   --nombre broll   → broll1.mp4   (formato de la plantilla 2, es el default)
import { existsSync, writeFileSync, mkdirSync, readFileSync } from "node:fs";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";
import { loadEnv } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";
import { parseArgs } from "./lib/util.mjs";
import { estimar, confirmar, Contador } from "./lib/costo.mjs";

const MODELO = () => process.env.APIMART_BROLL_MODEL || "veo3.1-lite";
const ESTILO = "vertical 9:16 UGC-style photo, natural light, realistic, no text, no captions, no watermark";

// El filtro de contenido de Veo es probabilístico: el mismo prompt pasa en una corrida y se
// bloquea en la siguiente. Un bloqueo no se cobra, así que se reintenta una vez con otro primer
// cuadro antes de rendirse.
export const esBloqueoDeContenido = (e) => /content policy/i.test(e?.message || "");

export async function generarBroll({ prompt, imagen, destino, cont, log = console.log, intentos = 2 }) {
  if (existsSync(destino)) { log(`  ⏭  ${destino} ya existe`); return destino; }
  for (let i = 0; i < intentos; i++) {
    // 1. primer cuadro alojado
    const img = await apimart.generarImagen({
      prompt: imagen ? `Recreate this exact image as a vertical 9:16 photo, same subject, same scene. ${ESTILO}` : `${prompt}. ${ESTILO}`,
      aspectRatio: "9:16",
      imageUrls: imagen ? [apimart.dataUri(imagen)] : undefined,
    });
    cont.sumar(img.cost);
    // 2. clip
    try {
      const v = await apimart.generarVideo({ model: MODELO(), prompt: `${prompt}. Slow natural camera movement, no speech, no text on screen.`,
        imageUrls: [img.url], aspectRatio: "9:16", resolution: "720p", duration: 8,
        onTick: (s) => process.stdout.write(s === "pendiente" ? "." : "\n") });
      cont.sumar(v.cost);
      writeFileSync(destino, await apimart.descargar(v.url));
      log(`  ✅ ${destino}`);
      return destino;
    } catch (e) {
      if (!esBloqueoDeContenido(e) || i === intentos - 1) throw e;
      log(`  ↻ bloqueado por el filtro de contenido (no se cobra); reintento con otro primer cuadro`);
    }
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
  const a = parseArgs(process.argv.slice(2));
  if (!a.prompts || !a.out) { console.error("Uso: node scripts/gen-broll.mjs --prompts <lista.json> --out <carpeta> [--nombre broll|broll-] [--si]"); process.exit(1); }
  const lista = JSON.parse(readFileSync(resolve(a.prompts), "utf8"));
  const pref = a.nombre || "broll";
  const nombre = (i) => pref.endsWith("-") ? `${pref}${String(i + 1).padStart(2, "0")}.mp4` : `${pref}${i + 1}.mp4`;
  mkdirSync(resolve(a.out), { recursive: true });
  const faltan = lista.filter((_, i) => !existsSync(join(resolve(a.out), nombre(i))));
  const est = estimar([{ tipo: "imagen", n: faltan.length }, { tipo: "broll", n: faltan.length }]);
  console.log(`🎞  B-roll con ${MODELO()} — ${faltan.length} de ${lista.length} por generar`);
  if (faltan.length && !(await confirmar({ ...est, si: !!a.si }))) process.exit(1);
  const cont = new Contador();
  for (let i = 0; i < lista.length; i++) {
    const it = lista[i];
    console.log(`\n[${i + 1}/${lista.length}] ${it.prompt.slice(0, 70)}`);
    try { await generarBroll({ prompt: it.prompt, imagen: it.imagen ? resolve(it.imagen) : null, destino: join(resolve(a.out), nombre(i)), cont }); }
    catch (e) { console.error(`  ❌ ${e.message}`); }
  }
  console.log(`\n${cont.resumen(est.total)}`);
}
