// Tomas y B-roll de las plantillas 3 (claymation) y 4 (Zack D Films), todo por APIMART:
//   imagen de cada toma (gpt-image-2, 9:16) → clip (veo3.1-lite con una imagen, o veo3.1-fast en
//   modo frame cuando la toma trae un frame final) → QC técnico (dimensiones, letterbox oculto,
//   que se corrige solo) → clips listos para montar.
//
//   node scripts/gen-clips.mjs input/<campaña>/guion.json [--si] [--solo t01,b02] [--regenerar]
//
// Reanudable: no vuelve a generar lo que ya existe. --regenerar repite las que se pidan con --solo
// (o todas). Un bloqueo del filtro de contenido de Veo no se cobra y se reintenta una vez solo.
import { existsSync, writeFileSync, mkdirSync, readFileSync, renameSync, rmSync } from "node:fs";
import { resolve, join, dirname } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";
import { loadEnv } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";
import { parseArgs } from "./lib/util.mjs";
import { estimar, confirmar, Contador } from "./lib/costo.mjs";
import { esBloqueoDeContenido } from "./gen-broll.mjs";
import { promptImagen, promptVideo, detectarLetterbox, ESTILOS } from "./lib/montar-lib.mjs";

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const LITE = () => process.env.APIMART_BROLL_MODEL || "veo3.1-lite";
const FAST = () => process.env.APIMART_AROLL_MODEL || "veo3.1-fast";

export function validarGuion(g) {
  for (const k of ["slug", "idioma", "estilo", "lineas", "tomas"]) if (!g[k]) throw new Error(`el guion no tiene "${k}"`);
  if (!ESTILOS[g.estilo]) throw new Error(`estilo "${g.estilo}" desconocido: claymation | zack | viral`);
  const ids = new Set();
  for (const t of [...g.tomas, ...(g.broll || [])]) {
    if (!t.id || !t.imagen) throw new Error(`toma sin "id" o sin "imagen": ${JSON.stringify(t).slice(0, 80)}`);
    if (!/^[a-z0-9_-]+$/i.test(t.id)) throw new Error(`id "${t.id}": solo letras, números, guion y guion bajo`);
    if (ids.has(t.id)) throw new Error(`id repetido: ${t.id}`);
    ids.add(t.id);
  }
  for (const [i, l] of g.lineas.entries()) {
    if (!l.texto) throw new Error(`línea ${i + 1} sin "texto"`);
    for (const k of ["toma", "broll"]) if (l[k] && !ids.has(l[k])) throw new Error(`línea ${i + 1}: ${k} "${l[k]}" no existe en tomas/broll`);
  }
}

// ---- QC del clip: dimensiones y el letterbox oculto (ffprobe informa 720×1280 igual)
export function probeDims(f) {
  const r = spawnSync("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:format=duration", "-of", "csv=p=0", f], { encoding: "utf8" });
  const [w, h, d] = (r.stdout || "").replace(/\s+/g, " ").trim().split(/[ ,]/).map(Number);
  return { w, h, d };
}
export function letterboxDe(f, { ancho = 72, alto = 128 } = {}) {
  const r = spawnSync("ffmpeg", ["-hide_banner", "-v", "error", "-ss", "1", "-i", f, "-frames:v", "1",
    "-vf", `scale=${ancho}:${alto},format=gray`, "-f", "rawvideo", "-"], { maxBuffer: 1 << 20 });
  if (!r.stdout || r.stdout.length < ancho * alto) return { hay: false, error: "no pude leer un cuadro" };
  return detectarLetterbox(new Uint8Array(r.stdout), ancho, alto);
}
export function quitarLetterbox(f) {
  // el área activa es 720×1080 dentro de 720×1280: se recorta a 9:16 exacto y se reescala.
  // Estirar el 720×1080 a 720×1280 deformaría la escena.
  const tmp = f.replace(/\.mp4$/, "-lb.mp4");
  const r = spawnSync("ffmpeg", ["-hide_banner", "-v", "error", "-i", f, "-vf", "crop=608:1080:56:100,scale=720:1280:flags=lanczos",
    "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-an", "-y", tmp], { encoding: "utf8" });
  if (r.status !== 0) throw new Error(`no pude recortar el letterbox de ${f}: ${r.stderr}`);
  renameSync(tmp, f);
}

async function frame({ prompt, ruta, referencia, cont }) {
  const meta = ruta.replace(/\.png$/, ".json");
  if (existsSync(meta)) { const m = JSON.parse(readFileSync(meta, "utf8")); if (m.expira > Date.now() / 1000 + 600 && existsSync(ruta)) return m; }
  const r = await apimart.generarImagen({ prompt, aspectRatio: "9:16", imageUrls: referencia ? [apimart.dataUri(referencia)] : undefined });
  cont.sumar(r.cost);
  writeFileSync(ruta, await apimart.descargar(r.url));
  const m = { url: r.url, ruta, expira: Number(r.raw?.data?.result?.images?.[0]?.expires_at || Date.now() / 1000 + 23 * 3600) };
  writeFileSync(meta, JSON.stringify(m));
  return m;
}

async function video({ model, prompt, imageUrls, generationType, destino, cont }) {
  let v;
  for (let b = 0; b < 2; b++) {
    try {
      v = await apimart.generarVideo({ model, prompt, imageUrls, generationType, aspectRatio: "9:16", resolution: "720p", duration: 8,
        onTick: (s) => process.stdout.write(s === "pendiente" ? "." : "\n") });
      break;
    } catch (err) {
      if (!esBloqueoDeContenido(err) || b === 1) throw err;
      console.log("  ↻ bloqueado por el filtro de contenido (no se cobra); reintento");
    }
  }
  cont.sumar(v.cost);
  writeFileSync(destino, await apimart.descargar(v.url));
}

export async function generarClips(rutaGuion, { si = false, solo = null, regenerar = false } = {}) {
  const guion = JSON.parse(readFileSync(resolve(rutaGuion), "utf8"));
  validarGuion(guion);
  const dirGuion = dirname(resolve(rutaGuion));
  const base = resolve(RAIZ, "public/media/_clips", guion.slug);
  const dirClips = join(base, "clips"), dirFrames = join(base, "frames");
  mkdirSync(dirClips, { recursive: true }); mkdirSync(dirFrames, { recursive: true });
  const clipDe = (id) => join(dirClips, `${id}.mp4`);

  const todas = [...guion.tomas.map((t) => ({ ...t, tipo: "toma" })), ...(guion.broll || []).map((b) => ({ ...b, tipo: "broll", fin: undefined }))]
    .filter((t) => !solo || solo.includes(t.id));
  if (regenerar) for (const t of todas) rmSync(clipDe(t.id), { force: true });
  const faltan = todas.filter((t) => !existsSync(clipDe(t.id)));
  const nFrame = faltan.filter((t) => t.fin).length, nSimple = faltan.length - nFrame;
  const est = estimar([{ tipo: "imagen", n: nSimple + nFrame * 2 }, { tipo: "frame", n: nFrame }, { tipo: "lite", n: nSimple }]);
  console.log(`🎬 clips «${guion.slug}» (${guion.estilo}) — ${faltan.length} de ${todas.length} por generar (${nFrame} en modo frame). Cada clip tarda 2-4 min; los puntos son la espera.`);
  if (faltan.length && !(await confirmar({ ...est, si }))) return { ok: false };
  const cont = new Contador();
  const qc = {};
  const rutaQc = join(base, "qc.json");
  const ref = (t) => (t.referencia ? resolve(dirGuion, t.referencia) : null);

  for (const t of faltan) {
    console.log(`\n═══ ${t.tipo} ${t.id}: ${t.imagen.slice(0, 70)}…`);
    try {
      const ini = await frame({ prompt: promptImagen(t, guion.estilo), ruta: join(dirFrames, `${t.id}.png`), referencia: ref(t), cont });
      if (t.fin) {
        // frame mode: el frame final se genera con el MISMO prompt de escena y solo cambia el estado
        const fin = await frame({ prompt: promptImagen({ ...t, imagen: t.fin }, guion.estilo), ruta: join(dirFrames, `${t.id}-fin.png`), referencia: ref(t), cont });
        await video({ model: FAST(), prompt: promptVideo(t, guion.estilo), imageUrls: [ini.url, fin.url], generationType: "frame", destino: clipDe(t.id), cont });
      } else {
        await video({ model: LITE(), prompt: promptVideo(t, guion.estilo), imageUrls: [ini.url], destino: clipDe(t.id), cont });
      }
      const dims = probeDims(clipDe(t.id));
      let lb = letterboxDe(clipDe(t.id));
      if (lb.hay) { quitarLetterbox(clipDe(t.id)); lb = { ...letterboxDe(clipDe(t.id)), corregido: true }; }
      qc[t.id] = { ...dims, letterbox: lb, ok: dims.w === 720 && dims.h === 1280 && !lb.hay };
      console.log(`  ${qc[t.id].ok ? "✅" : "⚠️ "} ${dims.w}×${dims.h} · ${dims.d.toFixed(1)} s${lb.corregido ? " · letterbox recortado" : ""}`);
    } catch (err) {
      console.error(`  ❌ ${err.message}`);
      qc[t.id] = { ok: false, error: err.message };
    }
    writeFileSync(rutaQc, JSON.stringify(qc, null, 2));
  }
  const fallados = Object.entries(qc).filter(([, r]) => !r.ok).map(([id]) => id);
  console.log(`\n${cont.resumen(est.total)}` + (fallados.length ? `\n⚠️  con problemas: ${fallados.join(", ")} — vuelve a correr (es reanudable) o --solo ${fallados.join(",")} --regenerar` : "\n✅ todos los clips pasan el QC") +
    `\nClips en ${dirClips}\nSiguiente: npm run gen:voz -- ${rutaGuion}`);
  return { ok: !fallados.length, dirClips, fallados };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
  const a = parseArgs(process.argv.slice(2));
  if (!a._[0]) { console.error("Uso: node scripts/gen-clips.mjs input/<campaña>/guion.json [--si] [--solo t01,b02] [--regenerar]"); process.exit(1); }
  try {
    const r = await generarClips(a._[0], { si: !!a.si, solo: a.solo ? String(a.solo).split(",") : null, regenerar: !!a.regenerar });
    process.exitCode = r.ok ? 0 : 1;
  } catch (e) { console.error(`❌ ${e.message}`); process.exitCode = 1; }
}
