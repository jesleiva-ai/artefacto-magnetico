// Genera una cama musical INSTRUMENTAL con Suno (vía APIMART) y la guarda en la biblioteca
// compartida por las dos plantillas: public/media/_music/music-<id>.mp3
//
//   node scripts/gen-musica.mjs --id gym-1 --prompt "upbeat pop rock for a gym ad, 120 BPM" [--si] [--forzar]
//
// Instrumental en dos capas: el flag `instrumental:true` de la API Y el sufijo en el prompt.
// Suno igual mete voz de vez en cuando: si pasa, --forzar regenera (cada intento sale distinto).
// Suno devuelve DOS pistas por tarea: la primera queda como music-<id>.mp3 y la segunda como
// music-<id>-b.mp3, para elegir de oído sin pagar de nuevo.
import { existsSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { loadEnv } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";
import { parseArgs } from "./lib/util.mjs";
import { estimar, confirmar, Contador } from "./lib/costo.mjs";

try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const LIB = resolve(RAIZ, "public/media/_music");
const SUFIJO = ", purely instrumental, absolutely NO vocals, no lyrics, no singing";

const a = parseArgs(process.argv.slice(2));
if (!a.id || !a.prompt) { console.error('Uso: node scripts/gen-musica.mjs --id <id> --prompt "<estilo en inglés>" [--si] [--forzar]'); process.exit(1); }
if (!/^[a-z0-9-]+$/.test(a.id)) { console.error("El id solo admite minúsculas, números y guiones"); process.exit(1); }
const destino = resolve(LIB, `music-${a.id}.mp3`);
if (existsSync(destino) && !a.forzar) { console.log(`⏭  ya existe ${destino} (--forzar para regenerar)`); process.exit(0); }

const est = estimar([{ tipo: "musica", n: 1 }]);
if (!(await confirmar({ ...est, si: !!a.si }))) process.exit(1);

mkdirSync(LIB, { recursive: true });
const cont = new Contador();
console.log(`🎵 Suno · ${a.prompt}`);
const r = await apimart.generarMusica({ prompt: a.prompt + SUFIJO, onTick: (s) => process.stdout.write(s === "pendiente" ? "." : "\n") });
cont.sumar(r.cost);
for (let i = 0; i < r.urls.length && i < 2; i++) {
  const out = i === 0 ? destino : resolve(LIB, `music-${a.id}-b.mp3`);
  writeFileSync(out, await apimart.descargar(r.urls[i]));
  const conVoz = r.lyrics[i] && !/^\s*\[instrumental\]\s*$/i.test(r.lyrics[i]);
  console.log(`  ✅ ${out} (${Math.round(r.duraciones[i])} s)${conVoz ? "  ⚠️ Suno reporta letra: escúchala; si tiene voz, --forzar" : ""}`);
}
console.log(`\n${cont.resumen(est.total)}\nÚsala en el brief: T1 "music": "${a.id}" · T2 y T3 "musica": { "id": "${a.id}" } (la T4 usa su música fija)`);
