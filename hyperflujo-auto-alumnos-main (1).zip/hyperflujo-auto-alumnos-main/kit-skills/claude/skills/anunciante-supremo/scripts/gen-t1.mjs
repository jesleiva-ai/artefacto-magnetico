import "./lib/raiz.mjs";
import { loadEnv } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";
import { generarVoz } from "./lib/voz.mjs";
import { ensureDir, slug } from "./lib/util.mjs";
import { stylePrompt } from "./lib/styles.mjs";
import { execFileSync } from "node:child_process";
import { existsSync, writeFileSync, readFileSync, copyFileSync } from "node:fs";
import { resolve } from "node:path";

// Genera los recursos de la PLANTILLA 1 (b-roll + voz en off):
//   voz (con timestamps por palabra) · imágenes de resalte · timeline de b-rolls
// La música NO se genera acá: sale de la biblioteca compartida por id (ver gen-musica.mjs);
// batch-t1.mjs la copia a public/media/t1/music.mp3 antes de llamar a este script.
// Salida: src/data/t1.json  (lo consume la composición Remotion `plantilla-1`).
try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
const FPS = 30, W = 1080, H = 1920;
const OUT = resolve("public/media/t1");
ensureDir(OUT);

const ad = JSON.parse(readFileSync(resolve("input/ad-t1.json"), "utf8"));
const brand = JSON.parse(readFileSync(resolve("src/brand.json"), "utf8"));

const normWord = (s) =>
  String(s).toLowerCase().replace(/[ăâ]/g, "a").replace(/î/g, "i")
    .replace(/[șş]/g, "s").replace(/[țţ]/g, "t")
    .normalize("NFD").replace(new RegExp("[\\u0300-\\u036f]", "g"), "").replace(/[^a-z0-9]/g, "");

const ffprobeDur = (f) =>
  parseFloat(execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]).toString().trim());

async function makeVoice() {
  const vozPath = resolve(OUT, "voz.mp3"), wordsPath = resolve(OUT, "words.json");
  if (existsSync(vozPath) && existsSync(wordsPath)) return JSON.parse(readFileSync(wordsPath, "utf8"));
  return generarVoz({ texto: ad.narration, brand, idioma: ad.idioma, outMp3: vozPath, outWords: wordsPath });
}

// Resalte = ícono con fondo transparente. gpt-image-2 devuelve PNG con alfa real
// (verificado 2026-09-04: 47 % de píxeles a alfa 0), así que no hace falta recortar nada.
// Biblioteca de resaltes: cada ícono generado se guarda en public/media/lib/<slug del prompt>-cut.png
// y, si otro anuncio (de esta tanda o de una futura) pide el mismo prompt, se reusa sin pagar.
// El brief también puede pedir uno por nombre con `reuse` (lo copia batch-t1 antes de llegar acá).
const LIB = resolve("public/media/lib");
ensureDir(LIB);
async function makeHighlight(prompt, cutDest) {
  if (existsSync(cutDest)) return true;
  const enLib = resolve(LIB, `${slug(prompt, 60)}-cut.png`);
  if (existsSync(enLib)) { copyFileSync(enLib, cutDest); console.log(`  ↺ resalte reusado de la biblioteca: ${slug(prompt, 60)}`); return true; }
  const { url } = await apimart.generarImagen({ prompt: stylePrompt(prompt, "cutout"), size: "1024x1024", background: "transparent" });
  writeFileSync(cutDest, await apimart.descargar(url));
  copyFileSync(cutDest, enLib);
  return true;
}

console.log("🎬 Plantilla 1 — generando recursos…");
const words = await makeVoice();
console.log(`  ✅ voz: ${words.length} palabras`);

if (ad.noMusic) console.log("  ⏭  anuncio SIN música (ad.noMusic)");
else if (!existsSync(resolve(OUT, "music.mp3")))
  throw new Error(`Falta la música: pon "music": "<id>" en el brief (public/media/_music/music-<id>.mp3) o genérala con: npm run gen:musica -- --id <id> --prompt "..."`);

const vozDur = ffprobeDur(resolve(OUT, "voz.mp3"));
const totalFrames = Math.ceil((vozDur + 0.5) * FPS);

// Resaltes (imágenes breves ligadas a una palabra) — resiliente.
const highlights = [];
const hin = ad.highlights || [];
for (let k = 0; k < hin.length; k++) {
  const h = hin[k];
  const target = normWord(h.word);
  const w = words.find((x) => normWord(x.text) === target) || words.find((x) => normWord(x.text).includes(target) && target.length > 2);
  const start = w ? w.start : ((k + 1) / (hin.length + 1)) * vozDur;
  const cut = resolve(OUT, `hl-${k}-cut.png`);
  try {
    if (await makeHighlight(h.prompt, cut)) highlights.push({ image: `media/t1/hl-${k}-cut.png`, start });
  } catch (e) { console.log(`  ⚠️  resalte ${k} (${h.word}) omitido: ${String(e.message).slice(0, 70)}`); }
}
console.log(`  ✅ resaltes: ${highlights.length}/${hin.length}`);

// Timeline de b-rolls: cortes cada ~1.4–1.9s, rotando clips y con arranque aleatorio.
// La carpeta de b-rolls es configurable por anuncio (`brollDir`); sin el campo, public/broll.
const BROLL_DIR = ad.brollDir || "public/broll";
const BROLL_REL = BROLL_DIR.replace(/^public\//, "");
const brollFiles = [];
for (let i = 1; i <= 40; i++) {
  const name = `broll-${String(i).padStart(2, "0")}.mp4`;
  const p = resolve(BROLL_DIR, name);
  if (existsSync(p)) brollFiles.push({ file: `${BROLL_REL}/${name}`, dur: ffprobeDur(p) });
}
if (!brollFiles.length) throw new Error(`No hay b-rolls en ${BROLL_DIR}/ (broll-01.mp4, broll-02.mp4, …). Genéralos con: npm run gen:broll -- --prompts <lista.json> --out ${BROLL_DIR} --nombre broll-`);

// Reusa el timeline existente si la duración no cambió (para no re-mezclar los cortes ya aprobados).
const t2path = resolve("src/data/t1.json");
const prevT2 = existsSync(t2path) ? JSON.parse(readFileSync(t2path, "utf8")) : null;
let timeline;
if (prevT2?.broll?.length && prevT2.durationInFrames === totalFrames) {
  timeline = prevT2.broll;
  console.log(`  ↺ b-roll: reuso timeline existente (${timeline.length} cortes)`);
} else {
  timeline = [];
  // brollStart (en el brief) desplaza el clip inicial: cada anuncio abre con otro b-roll.
  let f = 0, idx = Number(ad.brollStart || 0), prev = -1;
  while (f < totalFrames) {
    let pick = idx % brollFiles.length;
    if (pick === prev) pick = (pick + 1) % brollFiles.length;
    prev = pick; idx++;
    const b = brollFiles[pick];
    const cutSec = 1.4 + Math.random() * 0.5;
    let cutFrames = Math.round(cutSec * FPS);
    if (f + cutFrames > totalFrames) cutFrames = totalFrames - f;
    const maxStart = Math.max(0, b.dur - cutSec - 0.2);
    const startFrom = Math.round(Math.random() * maxStart * FPS);
    timeline.push({ file: b.file, from: f, durationInFrames: cutFrames, startFrom });
    f += cutFrames;
  }
  console.log(`  ✅ b-roll: ${timeline.length} cortes (${brollFiles.length} clips)`);
}

writeFileSync(resolve("src/data/t1.json"), JSON.stringify({
  fps: FPS, width: W, height: H, durationInFrames: totalFrames,
  hook: ad.hook,
  // hookSeconds 3-5 (el viewer lee, mira el b-roll y vuelve a leer; <3s pierde efecto)
  hookFrames: Math.round(Math.min(5, Math.max(3, Number(ad.hookSeconds || 3))) * FPS),
  hookStyle: ad.hookStyle || "panel",        // "panel" | "system" (caja blanca, recomendado)
  hookPosition: ad.hookPosition || "center", // "center" | "top" (tercio superior, recomendado)
  hookAccent: ad.hookAccent || null,         // color de las *palabras* enfatizadas
  introSfx: ad.introSfx || "intro-rev",      // hook auditivo al aparecer el título: archivo en public/sfx/<nombre>.mp3
  voice: "media/t1/voz.mp3",
  music: existsSync(resolve(OUT, "music.mp3")) ? "media/t1/music.mp3" : null,
  words, highlights, broll: timeline,
}));
console.log(`\n✅ Plantilla 1 lista. Total ${(totalFrames / FPS).toFixed(1)}s. Preview: npm run studio (composición plantilla-1)`);
