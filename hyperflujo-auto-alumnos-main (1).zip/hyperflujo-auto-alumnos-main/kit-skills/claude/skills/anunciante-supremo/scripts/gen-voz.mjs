// Voz en off de las plantillas 3 y 4: UNA pista por línea del guion (l01.mp3, l02.mp3…), con sus
// palabras y tiempos al lado (l01.words.json), y el plan de montaje borrador (ad-01.json).
//
//   node scripts/gen-voz.mjs input/<campaña>/guion.json [--si] [--forzar] [--solo 1,3]
//
// Por qué una pista por línea: la duración real de cada línea es la que define cuánto dura su beat
// en el montaje. «palabras ÷ 2,4» sirve para escribir; para montar manda el mp3.
// Proveedor: ElevenLabs si hay llave y voiceId en brand.json; si no, APIMART (gpt-4o-mini-tts).
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, join, dirname, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { loadEnv } from "./lib/env.mjs";
import { parseArgs } from "./lib/util.mjs";
import { estimar, confirmar, Contador } from "./lib/costo.mjs";
import { generarVoz, proveedorDeVoz } from "./lib/voz.mjs";
import { planBorrador } from "./lib/montar-lib.mjs";
import { validarGuion } from "./gen-clips.mjs";

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), "..");

export async function generarVoces(rutaGuion, { si = false, forzar = false, solo = null } = {}) {
  const guion = JSON.parse(readFileSync(resolve(rutaGuion), "utf8"));
  validarGuion(guion);
  const dirGuion = dirname(resolve(rutaGuion));
  const base = resolve(RAIZ, "public/media/_clips", guion.slug);
  const dirVoz = join(base, "voz");
  mkdirSync(dirVoz, { recursive: true });

  // la marca da la voz; el guion puede pisarla ("voz": { "apimart": {...}, "elevenlabs": {...} })
  const brandPath = resolve(RAIZ, "src/brand.json");
  const brand = existsSync(brandPath) ? JSON.parse(readFileSync(brandPath, "utf8")) : {};
  const marca = { ...brand, voz: { ...(brand.voz || {}), ...(guion.voz || {}) } };
  if (guion.voz?.apimart) marca.voz.apimart = { ...(brand.voz?.apimart || {}), ...guion.voz.apimart };
  if (guion.voz?.elevenlabs) marca.voz.elevenlabs = { ...(brand.voz?.elevenlabs || {}), ...guion.voz.elevenlabs };

  const nombre = (i) => `l${String(i + 1).padStart(2, "0")}.mp3`;
  const lineas = guion.lineas.map((l, i) => ({ ...l, i, mp3: join(dirVoz, nombre(i)) }))
    .filter((l) => !solo || solo.includes(l.i + 1));
  const faltan = lineas.filter((l) => forzar || !existsSync(l.mp3));
  const est = estimar([{ tipo: "voz", n: faltan.length }]);
  console.log(`🎙  voz «${guion.slug}» por ${proveedorDeVoz(marca) === "elevenlabs" ? "ElevenLabs" : "APIMART"} — ${faltan.length} de ${lineas.length} línea(s) por generar`);
  if (faltan.length && !(await confirmar({ ...est, si }))) return { ok: false };
  const cont = new Contador();
  const tokens = (t) => t.split(/\s+/).filter(Boolean).length;
  for (const l of faltan) {
    console.log(`\n═══ línea ${l.i + 1}: ${l.texto.slice(0, 70)}`);
    // El TTS a veces se come la última oración de una línea (pasó con un "Toca el botón de abajo."
    // después de un punto). Se compara lo que la transcripción oyó contra el guion y, si falta más de
    // un 20 %, se regenera la línea; a la tercera se aborta en vez de entregar un CTA mudo.
    let ok = false;
    for (let intento = 1; intento <= 3 && !ok; intento++) {
      const words = await generarVoz({ texto: l.texto, brand: marca, idioma: guion.idioma, outMp3: l.mp3, outWords: l.mp3.replace(/\.mp3$/, ".words.json") });
      cont.sumar(0.01);
      const cob = words.length / tokens(l.texto);
      ok = cob >= 0.8;
      if (!ok) console.log(`  ↻ la voz cubre ${(cob * 100).toFixed(0)} % del guion (${words.length}/${tokens(l.texto)} palabras)${intento < 3 ? ": regenero" : ""}`);
    }
    if (!ok) throw new Error(`línea ${l.i + 1}: la voz no dice el guion completo después de 3 intentos. Simplifica la línea (una sola oración, sin abreviaturas) y corre --solo ${l.i + 1} --forzar`);
  }

  // plan de montaje borrador, una sola vez: después se edita a mano (planos, insertos, música)
  const rutaPlan = join(dirGuion, "ad-01.json");
  if (!existsSync(rutaPlan)) {
    const relDe = (d) => relative(dirGuion, d).split("\\").join("/");
    writeFileSync(rutaPlan, JSON.stringify(planBorrador(guion, { clips: relDe(join(base, "clips")), voz: relDe(dirVoz) }), null, 2));
    console.log(`\n📝 plan borrador: ${rutaPlan} — revisa los planos de cada beat (toma + b-roll) y la música antes de montar`);
  } else console.log(`\n📝 ${rutaPlan} ya existe: lo respeto (borralo si querés un borrador nuevo)`);
  console.log(`\n${cont.resumen(est.total)}\nVoces en ${dirVoz}\nSiguiente: npm run montar -- ${relative(RAIZ, rutaPlan).split("\\").join("/")}`);
  return { ok: true, dirVoz, rutaPlan };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
  const a = parseArgs(process.argv.slice(2));
  if (!a._[0]) { console.error("Uso: node scripts/gen-voz.mjs input/<campaña>/guion.json [--si] [--forzar] [--solo 1,3]"); process.exit(1); }
  try {
    const r = await generarVoces(a._[0], { si: !!a.si, forzar: !!a.forzar, solo: a.solo ? String(a.solo).split(",").map(Number) : null });
    process.exitCode = r.ok ? 0 : 1;
  } catch (e) { console.error(`❌ ${e.message}`); process.exitCode = 1; }
}
