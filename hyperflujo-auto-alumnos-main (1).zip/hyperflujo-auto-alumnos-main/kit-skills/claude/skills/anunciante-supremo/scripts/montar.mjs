// Montador de las plantillas 3 (claymation) y 4 (Zack D Films): voz en off + planos generados +
// cama musical + SFX en cada corte + subtítulos palabra por palabra QUEMADOS, en el mismo estilo
// que la plantilla 2.
//
//   node scripts/montar.mjs input/<campaña>/ad-01.json [--salida out/x.mp4] [--forzar]
//
// Reusa las librerías de la casa: ass-t2 (captions), alinear (whisper vs. guion), transcribir
// (whisper-1 por APIMART, con caché). Los planos de cada beat se ajustan solos a la duración real
// de su línea de voz, así el video y la voz cierran exactos sin calcular nada a mano.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync, spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";
import { loadEnv } from "./lib/env.mjs";
import { parseArgs } from "./lib/util.mjs";
import { generarASS } from "./lib/ass-t2.mjs";
import { alinear } from "./lib/alinear.mjs";
import { transcribir } from "./lib/transcribir.mjs";
import { configDeEstilo, rellenarHuecos, ajustarPlanos, duracionesDeBeats } from "./lib/montar-lib.mjs";

const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SFX_DIR = path.join(RAIZ, "public/sfx");
const BIBLIOTECA_MUSICA = path.join(RAIZ, "public/media/_music");

const ff = (args, opts = {}) => execFileSync("ffmpeg", ["-hide_banner", "-v", "error", ...args],
  { stdio: ["ignore", "ignore", "inherit"], ...opts });
const dur = (f) => Number(execFileSync("ffprobe",
  ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]).toString().trim());

function resolverMusica(plan, cfg, dirPlan, dirClips) {
  const m = plan.musica;
  if (m?.id && m?.archivo) throw new Error('"musica": id y archivo son excluyentes');
  if (m?.id) {
    const r = path.join(BIBLIOTECA_MUSICA, `music-${m.id}.mp3`);
    if (!fs.existsSync(r)) {
      const hay = fs.existsSync(BIBLIOTECA_MUSICA)
        ? fs.readdirSync(BIBLIOTECA_MUSICA).filter((f) => /^music-.*\.mp3$/.test(f) && !/-b\.mp3$/.test(f)).map((f) => f.slice(6, -4)).join(", ")
        : "(ninguna)";
      throw new Error(`música: no hay ninguna pista con id "${m.id}". Disponibles: ${hay || "(ninguna)"}. Genera una con: npm run gen:musica -- --id ${m.id} --prompt "<estilo en inglés>"`);
    }
    return { ruta: r, desde: m.desde ?? 0, nombre: `id "${m.id}"` };
  }
  const archivo = m?.archivo ?? (typeof m === "string" ? m : null);
  if (archivo) {
    const r = path.isAbsolute(archivo) ? archivo : (fs.existsSync(path.resolve(dirPlan, archivo)) ? path.resolve(dirPlan, archivo) : path.resolve(dirClips, archivo));
    if (!fs.existsSync(r)) throw new Error(`música ${archivo}: no existe (${r})`);
    return { ruta: r, desde: m?.desde ?? 0, nombre: archivo };
  }
  if (cfg.musicaFija) {
    const r = path.join(RAIZ, cfg.musicaFija);
    if (!fs.existsSync(r)) throw new Error(`falta la música fija del estilo: ${r}`);
    return { ruta: r, desde: 0, nombre: `la fija del estilo (${cfg.musicaFija})` };
  }
  throw new Error('música: falta "musica": { "id": "<id>" } o { "archivo": "<ruta>" } en el plan (es obligatoria)');
}

// Palabras con tiempo de una línea: si gen-voz dejó el .words.json al lado del mp3 se usa (gratis);
// si no, whisper-1 por APIMART (con caché).
async function palabrasDe(mp3, linea, { idioma, cacheDir, forzar }) {
  const wj = mp3.replace(/\.mp3$/i, ".words.json");
  let words, origen;
  if (fs.existsSync(wj) && !forzar) {
    words = JSON.parse(fs.readFileSync(wj, "utf8")).map((w) => ({ word: w.text ?? w.word, start: w.start, end: w.end }));
    origen = "words.json";
  } else {
    const t = await transcribir(mp3, { idioma, cacheDir, apiKey: process.env.APIMART_API_KEY, forzar });
    words = t.words; origen = t.deCache ? "caché" : "whisper-1";
  }
  const r = alinear(words, linea);
  const tokens = linea.split(/\s+/).filter(Boolean);
  const completas = rellenarHuecos(tokens, r.palabras);
  if (completas.length !== tokens.length) throw new Error(`"${linea.slice(0, 40)}…": ${tokens.length} palabras y ${completas.length} captions`);
  return { palabras: completas, cobertura: r.cobertura, interpoladas: r.sinCaption, origen };
}

export async function montar(rutaPlan, { salida, forzar = false } = {}) {
  const plan = JSON.parse(fs.readFileSync(rutaPlan, "utf8"));
  const dirPlan = path.dirname(path.resolve(rutaPlan));
  if (!plan.estilo) throw new Error('el plan no tiene "estilo" (claymation | zack)');
  if (!Array.isArray(plan.beats) || !plan.beats.length) throw new Error("el plan no tiene beats");
  const cfg = { ...configDeEstilo(plan.estilo), ...Object.fromEntries(Object.entries(plan).filter(([k]) => ["speed", "gap", "volMusica", "volWhoosh", "volPop", "sfxCorte", "sfxPlano", "cola", "maxPlano", "ancho", "alto", "fps"].includes(k))) };
  const rel = (p) => (p ? (path.isAbsolute(p) ? p : path.resolve(dirPlan, p)) : null);
  const dirClips = rel(plan.clips);
  const dirVoz = rel(plan.voz) || dirClips;
  if (!dirClips || !fs.existsSync(dirClips)) throw new Error(`no existe la carpeta de clips: ${plan.clips}`);
  const out = salida ? path.resolve(salida) : path.join(RAIZ, "out", `${plan.slug || "anuncio"}.mp4`);
  const musica = resolverMusica(plan, cfg, dirPlan, dirClips);
  const { speed, gap, cola, ancho, alto, fps } = cfg;
  const clipDe = (id) => path.join(dirClips, `${id}.mp4`);

  // ---- QC de entrada: todo lo que se necesita existe, antes de gastar una transcripción
  const faltan = [];
  for (const [i, b] of plan.beats.entries()) {
    if (!b.linea) faltan.push(`beat ${i + 1}: falta "linea"`);
    if (!b.voz || !fs.existsSync(path.join(dirVoz, b.voz))) faltan.push(`beat ${i + 1}: falta la voz ${b.voz} en ${dirVoz}`);
    for (const p of b.planos || []) { const id = Array.isArray(p) ? p[0] : p; if (!fs.existsSync(clipDe(id))) faltan.push(`beat ${i + 1}: falta el clip ${id}.mp4 en ${dirClips}`); }
  }
  for (const s of [cfg.sfxCorte, cfg.sfxPlano]) if (!fs.existsSync(path.join(SFX_DIR, `${s}.mp3`))) faltan.push(`SFX ${s}.mp3 no está en public/sfx/`);
  if (faltan.length) throw new Error("QC de entrada:\n  - " + faltan.join("\n  - "));

  console.log(`🎬 ${plan.title || plan.slug} · ${plan.estilo} · ${speed}x · música ${musica.nombre}`);
  const td = fs.mkdtempSync(path.join(os.tmpdir(), "t34-"));

  // ---- 1. voz: una pista por línea, con el respiro entre líneas. Su duración manda el ritmo.
  const sil = path.join(td, "sil.wav");
  ff(["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", String(gap), "-y", sil]);
  const wavs = [], durVoz = [];
  for (const [i, b] of plan.beats.entries()) {
    const w = path.join(td, `a${i}.wav`);
    ff(["-i", path.join(dirVoz, b.voz), "-ar", "48000", "-ac", "2", "-y", w]);
    wavs.push(w); durVoz.push(dur(w));
  }
  const durBeats = duracionesDeBeats(durVoz, { gap, cola });
  const inicios = []; let tv = 0;
  const trozos = [];
  for (let i = 0; i < wavs.length; i++) { inicios.push(tv); trozos.push(wavs[i]); tv += durVoz[i]; if (i < wavs.length - 1) { trozos.push(sil); tv += gap; } }
  const la = path.join(td, "a.txt");
  fs.writeFileSync(la, trozos.map((f) => `file '${f.replace(/\\/g, "/")}'\n`).join(""));
  const voz = path.join(td, "voz.wav");
  ff(["-f", "concat", "-safe", "0", "-i", la, "-c", "copy", "-y", voz]);

  // ---- 2. planos: ajustados a cada beat, cortados y medidos (el redondeo a fps mueve los cortes)
  const segmentos = [];
  for (const [i, b] of plan.beats.entries()) {
    const planos = ajustarPlanos(b.planos, durBeats[i], { maxPlano: cfg.maxPlano });
    for (const [j, [id, d]] of planos.entries()) {
      const src = clipDe(id);
      const disponible = dur(src) - cfg.inicioClip;
      if (d * speed > disponible + 0.05) throw new Error(`beat ${i + 1}, plano ${id}: necesita ${(d * speed).toFixed(2)} s del clip y solo tiene ${disponible.toFixed(2)} s. Agrega otro plano al beat o baja maxPlano`);
      const o = path.join(td, `v${String(i).padStart(2, "0")}${j}.mp4`);
      ff(["-ss", String(cfg.inicioClip), "-t", (d * speed).toFixed(3), "-i", src, "-an",
        "-vf", `setpts=PTS/${speed},scale=${ancho}:${alto}:flags=lanczos,fps=${fps}`,
        "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-y", o]);
      segmentos.push({ file: o, beat: i, primeroDelBeat: j === 0, id, d });
    }
    console.log(`  beat ${i + 1}: voz ${durVoz[i].toFixed(2)} s → ${planos.map(([id, d]) => `${id} ${d.toFixed(2)}`).join(" · ")}`);
  }
  let t = 0; const cortes = [];
  for (const s of segmentos) { s.inicio = t; if (t > 0) cortes.push({ t, tipo: s.primeroDelBeat ? "escena" : "plano" }); t += dur(s.file); }
  const totalVideo = t;
  const lv = path.join(td, "v.txt");
  fs.writeFileSync(lv, segmentos.map((s) => `file '${s.file.replace(/\\/g, "/")}'\n`).join(""));
  const video = path.join(td, "video.mp4");
  ff(["-f", "concat", "-safe", "0", "-i", lv, "-c", "copy", "-y", video]);
  console.log(`  ${segmentos.length} planos · ${cortes.length} cortes · video ${totalVideo.toFixed(2)} s · voz ${tv.toFixed(2)} s`);

  // ---- 3. captions: los tiempos salen de la voz, el TEXTO sale del guion
  const cacheDir = path.join(dirVoz, "cache");
  const palabras = [];
  for (const [i, b] of plan.beats.entries()) {
    const r = await palabrasDe(path.join(dirVoz, b.voz), b.linea, { idioma: plan.idioma, cacheDir, forzar });
    console.log(`  línea ${i + 1} (${r.origen}): cobertura ${(r.cobertura * 100).toFixed(0)} %${r.interpoladas.length ? " · interpoladas: " + r.interpoladas.join(" ") : ""}`);
    // Más de un tercio de la línea interpolada ya no es un número escrito con letras: casi seguro
    // la voz NO dijo esa parte (el TTS a veces se come la última oración). Interpolar la taparía.
    if (r.cobertura < 0.67) throw new Error(`línea ${i + 1}: la voz no dice lo que dice el guion (cobertura ${(r.cobertura * 100).toFixed(0)} %, sin oír: "${r.interpoladas.join(" ")}"). Regenera esa línea: npm run gen:voz -- <guion.json> --solo ${i + 1} --forzar`);
    for (const p of r.palabras) palabras.push({ texto: p.texto, start: p.start + inicios[i], end: p.end + inicios[i] });
  }
  const ass = path.join(td, "subs.ass");
  fs.writeFileSync(ass, generarASS(palabras, { ancho, alto }));
  console.log(`  ${palabras.length} captions`);

  // ---- 4. mezcla: voz + música (loop, volumen, fundido) + un golpe en cada corte
  // OJO con los índices: la entrada 0 es el VIDEO sin audio. Si se numera la voz como [0:a] el
  // filtro no casa con nada y ffmpeg aborta con "matches no streams".
  // El MP3 de la música puede traer un chapter track que el muxer copiaría como stream bin_data
  // (basura en un archivo que va a Meta): por eso se mapea explícito y se pasa -dn -sn.
  const entradas = ["-i", voz, "-stream_loop", "-1", "-i", musica.ruta];
  const filtros = [
    `[1:a]apad=whole_dur=${totalVideo.toFixed(3)}[vo]`,
    `[2:a]atrim=start=${musica.desde},asetpts=PTS-STARTPTS,atrim=0:${totalVideo.toFixed(3)},volume=${cfg.volMusica},` +
    `afade=t=out:st=${Math.max(0, totalVideo - 1.5).toFixed(2)}:d=1.5[mus]`,
  ];
  const mezcla = ["[vo]", "[mus]"];
  cortes.forEach((c, k) => {
    const esEscena = c.tipo === "escena";
    entradas.push("-i", path.join(SFX_DIR, `${esEscena ? cfg.sfxCorte : cfg.sfxPlano}.mp3`));
    const ms = Math.max(0, Math.round((c.t - 0.06) * 1000)); // 60 ms antes: el golpe cae SOBRE el corte
    filtros.push(`[${3 + k}:a]volume=${esEscena ? cfg.volWhoosh : cfg.volPop},aformat=sample_rates=48000:channel_layouts=stereo,adelay=${ms}|${ms}[s${k}]`);
    mezcla.push(`[s${k}]`);
  });
  // normalize=0: sin eso amix divide el volumen entre las entradas y la voz baja a la mitad en silencio
  filtros.push(`${mezcla.join("")}amix=inputs=${mezcla.length}:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.95[a]`);
  const conAudio = path.join(td, "conaudio.mp4");
  ff(["-i", video, ...entradas, "-filter_complex", filtros.join(";"), "-map", "0:v", "-map", "[a]",
    "-dn", "-sn", "-map_chapters", "-1", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-map_metadata", "-1", "-shortest", "-y", conAudio]);

  // ---- 5. quemar los subtítulos. Se entra a la carpeta del .ass: en Windows el filtro subtitles se
  // pelea con los dos puntos de la unidad, y un nombre relativo lo esquiva sin escapes frágiles.
  fs.mkdirSync(path.dirname(out), { recursive: true });
  execFileSync("ffmpeg", ["-hide_banner", "-v", "error", "-i", conAudio, "-map", "0:v:0", "-map", "0:a:0", "-dn", "-sn", "-vf", "subtitles=subs.ass",
    "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.0",
    "-fps_mode", "cfr", "-r", String(fps), "-c:a", "copy", "-movflags", "+faststart", "-map_metadata", "-1", "-map_chapters", "-1", "-y", out],
    { cwd: td, stdio: ["ignore", "ignore", "inherit"] });

  // ---- 6. sonoridad: Meta espera un master entre −16 y −14 LUFS. Si quedó bajo, se normaliza.
  const lufs = medirLufs(out);
  if (Number.isFinite(lufs) && lufs < -18) {
    const tmp = out.replace(/\.mp4$/, "-ln.mp4");
    ff(["-i", out, "-map", "0:v:0", "-map", "0:a:0", "-dn", "-sn", "-c:v", "copy", "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-map_chapters", "-1", "-y", tmp]);
    fs.renameSync(tmp, out);
    console.log(`  🎚  master a ${lufs.toFixed(1)} LUFS → normalizado a −16`);
  } else if (Number.isFinite(lufs)) console.log(`  🎚  master ${lufs.toFixed(1)} LUFS`);

  fs.rmSync(td, { recursive: true, force: true });
  const info = execFileSync("ffprobe", ["-v", "error", "-select_streams", "v:0",
    "-show_entries", "stream=width,height,r_frame_rate,avg_frame_rate:format=duration", "-of", "default=nw=1", out]).toString().trim().replace(/\n/g, " · ");
  console.log(`\n✅ ${out}\n   ${info}`);
  return out;
}

function medirLufs(f) {
  const r = spawnSync("ffmpeg", ["-hide_banner", "-i", f, "-af", "ebur128=framelog=quiet", "-f", "null", "-"], { encoding: "utf8" });
  const m = /I:\s*(-?[\d.]+) LUFS/.exec((r.stderr || "") + (r.stdout || ""));
  return m ? Number(m[1]) : NaN;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { loadEnv(); } catch { /* la llave puede venir del entorno */ }
  const a = parseArgs(process.argv.slice(2));
  if (!a._[0]) { console.error("Uso: node scripts/montar.mjs input/<campaña>/ad-01.json [--salida out/x.mp4] [--forzar]"); process.exit(1); }
  try { await montar(a._[0], { salida: a.salida, forzar: !!a.forzar }); }
  catch (e) { console.error(`❌ ${e.message}`); process.exitCode = 1; }
}
