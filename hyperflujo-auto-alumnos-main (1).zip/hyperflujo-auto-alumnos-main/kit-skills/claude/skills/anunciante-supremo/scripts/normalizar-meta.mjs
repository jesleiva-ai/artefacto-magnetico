// Deja un mp4 de la plantilla en el perfil que Meta Ads acepta sin colgarse.
//
// Uso:
//   node scripts/normalizar-meta.mjs "<video.mp4>" [más archivos...]
//
// POR QUÉ EXISTE (2026-08-24): speedup.mjs en modo `remux` no recomprime el video, solo
// reescala los tiempos del contenedor con -itsscale. Eso deja el mp4 a 37,5 fps con un
// avg_frame_rate que NO coincide con el r_frame_rate (p.ej. 13686/365 contra 75/2). Para el
// transcodificador de Meta eso es frame rate VARIABLE, y la subida a la biblioteca de
// multimedia se queda congelada alrededor del 80% — no da error, simplemente nunca termina.
// Visto el 2026-08-24.
//
// La solución es una sola pasada de recompresión a CFR 30 fps, que es exactamente el perfil
// de los anuncios que sí subieron (los hechos antes de que existiera el modo remux). Bajar de 37,5 a 30 fps descarta cuadros, pero sobre b-roll con zoom lento y captions
// es imperceptible, y de paso el archivo baja de ~80 MB a ~45 MB.
import { execFileSync, spawnSync } from "node:child_process";
import { existsSync, renameSync, rmSync, statSync } from "node:fs";
import { resolve, join, dirname } from "node:path";

const FPS = 30;
const CRF = 21;

const archivos = process.argv.slice(2);
if (!archivos.length) {
  console.error('Uso: node scripts/normalizar-meta.mjs "<video.mp4>" [más...]');
  process.exit(1);
}

const info = (f) => {
  const r = spawnSync("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_entries",
    "stream=r_frame_rate,avg_frame_rate", "-of", "default=nw=1:nk=1", f], { encoding: "utf8" });
  const [rfr, afr] = (r.stdout || "").trim().split(/\s+/);
  return { rfr, afr };
};

for (const a of archivos) {
  const f = resolve(a);
  if (!existsSync(f)) { console.error(`No existe: ${f}`); continue; }
  const antes = info(f);
  const mb0 = (statSync(f).size / 1024 ** 2).toFixed(1);
  const tmp = join(dirname(f), `._meta-${process.pid}.mp4`);
  execFileSync("ffmpeg", ["-hide_banner", "-y", "-i", f,
    "-vf", `fps=${FPS}`,
    "-c:v", "libx264", "-preset", "medium", "-crf", String(CRF),
    "-profile:v", "high", "-level", "4.0",
    "-fps_mode", "cfr", "-r", String(FPS), "-g", String(FPS * 2),
    "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
    "-movflags", "+faststart", tmp], { stdio: ["ignore", "ignore", "inherit"] });
  renameSync(tmp, f);
  const despues = info(f);
  const mb1 = (statSync(f).size / 1024 ** 2).toFixed(1);
  console.log(`✅ ${a}`);
  console.log(`   fps  ${antes.rfr} / avg ${antes.afr}  →  ${despues.rfr} / avg ${despues.afr}`);
  console.log(`   peso ${mb0} MB → ${mb1} MB`);
  rmSync(tmp, { force: true });
}
