// Fase de assets del batch t1 (voz + timings + timeline) SIN renderizar.
// Sirve para poder retocar el timeline de b-roll antes de gastar un render.
//   node scripts/prep-assets.mjs input/mi-campana
import { CWD_ORIGINAL } from "./lib/raiz.mjs";
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, rmSync, copyFileSync } from "node:fs";
import { resolve, join } from "node:path";

const SRC = process.argv[2] ? resolve(CWD_ORIGINAL, process.argv[2]) : null;
if (!SRC) { console.error("Uso: node scripts/prep-assets.mjs <carpeta-con-ad-NN.json>"); process.exit(1); }
const WORK = resolve("public/media/t1"), LIB = resolve("public/media/lib");
const MUSIC = resolve("public/media/_music"), ARCHIVE = resolve("public/media/_ads");
const ensure = (d) => { if (!existsSync(d)) mkdirSync(d, { recursive: true }); };

for (const f of readdirSync(resolve(SRC)).filter((f) => /^ad-\d+(-[\w-]+)?\.json$/i.test(f)).sort()) {
  const ad = JSON.parse(readFileSync(resolve(SRC, f), "utf8"));
  const slug = ad.slug;
  const arc = join(ARCHIVE, slug);
  ensure(arc);
  if (existsSync(join(arc, "words.json"))) { console.log(`⏭  ${slug} ya tiene voz`); continue; }
  console.log(`\n═══ ${f} — ${ad.title}`);
  rmSync(WORK, { recursive: true, force: true }); ensure(WORK);
  writeFileSync(resolve("input/ad-t1.json"), JSON.stringify(ad, null, 2));
  (ad.highlights || []).forEach((h, k) => {
    if (h.reuse) copyFileSync(join(LIB, `${h.reuse}-cut.png`), join(WORK, `hl-${k}-cut.png`));
  });
  if (ad.music) copyFileSync(join(MUSIC, `music-${ad.music}.mp3`), join(WORK, "music.mp3"));
  writeFileSync(resolve("src/data/t1.json"), JSON.stringify({ durationInFrames: 0 }));
  execFileSync("node", ["scripts/gen-t1.mjs"], { stdio: "inherit", shell: process.platform === "win32" });
  for (const a of readdirSync(WORK)) copyFileSync(join(WORK, a), join(arc, a));
  copyFileSync(resolve("src/data/t1.json"), join(arc, "t1.json"));
  console.log(`✅ assets de ${slug} archivados`);
}
