// Prepara B-roll DESCARGADO para la plantilla 1: toma una carpeta con videos sueltos (los que
// bajaste de un banco de clips, con cualquier nombre y cualquier formato) y deja en la carpeta
// destino `broll-01.mp4, broll-02.mp4, …` a 1080×1920, sin audio, listos para el brief.
//
//   node scripts/prep-broll.mjs --desde "C:/ruta/a/mis-clips-anatomia" --a public/broll-mi-campana
//
// Un clip horizontal se recorta al centro hasta 9:16 (no se deforma). Los que ya son 9:16 solo se
// escalan. Se ordenan por nombre; los que ya existen en destino se saltan (reanudable).
import { existsSync, mkdirSync, readdirSync } from "node:fs";
import { resolve, join, extname } from "node:path";
import { execFileSync } from "node:child_process";
import { parseArgs } from "./lib/util.mjs";

const a = parseArgs(process.argv.slice(2));
if (!a.desde || !a.a) { console.error('Uso: node scripts/prep-broll.mjs --desde "<carpeta con videos>" --a public/broll-<slug>'); process.exit(1); }
const desde = resolve(a.desde), dest = resolve(a.a);
if (!existsSync(desde)) { console.error(`No existe ${desde}`); process.exit(1); }
mkdirSync(dest, { recursive: true });

const VIDEO = new Set([".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"]);
const fuentes = readdirSync(desde).filter((f) => VIDEO.has(extname(f).toLowerCase())).sort();
if (!fuentes.length) { console.error(`No hay videos (${[...VIDEO].join(" ")}) en ${desde}`); process.exit(1); }

console.log(`🎞  ${fuentes.length} clip(s) de ${desde} → ${dest}`);
let n = 0;
for (const f of fuentes) {
  n++;
  const out = join(dest, `broll-${String(n).padStart(2, "0")}.mp4`);
  if (existsSync(out)) { console.log(`  ⏭  ${out} ya existe`); continue; }
  // scale para cubrir 1080×1920 conservando proporción, crop al centro, sin audio, CFR 30.
  execFileSync("ffmpeg", ["-hide_banner", "-v", "error", "-y", "-i", join(desde, f),
    "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30",
    "-an", "-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out], { stdio: "inherit" });
  console.log(`  ✅ ${f} → broll-${String(n).padStart(2, "0")}.mp4`);
}
console.log(`\nListo. En el brief: "brollDir": "${a.a.replace(/\\/g, "/")}"`);
