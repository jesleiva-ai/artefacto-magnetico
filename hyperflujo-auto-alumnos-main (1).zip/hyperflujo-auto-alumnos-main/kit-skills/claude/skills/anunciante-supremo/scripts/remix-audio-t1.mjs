// Rehace SOLO el audio de un anuncio de plantilla 1 ya renderizado, sin volver a renderizar.
//
// Uso:
//   node scripts/remix-audio-t1.mjs <slug> <video.mp4> [speed]
//   node scripts/remix-audio-t1.mjs ad-01-ejemplo "out/anuncios/ad-01-ejemplo.mp4"
//
// Por qué existe: el render de video es lo caro (minutos), pero la mezcla de audio de la
// plantilla 1 es trivial y 100% determinista — voz (×1.4) + música (×0.22) + hook auditivo,
// los tres arrancando en el frame 0. Si el problema es SOLO de niveles, se rearma la mezcla con
// ffmpeg desde public/media/_ads/<slug>/ y se remuxea sobre el MISMO stream de video (-c:v copy).
// Segundos en vez de minutos, y el video sale idéntico bit a bit.
//
// Nivelado de voz: las voces de distintos proveedores vienen con niveles de
// grabación MUY distintos (una voz con pico -3.4 dB, otra con -24.4 dB: 21 dB de diferencia).
// Con el ×1.4 fijo de la plantilla, una voz baja queda enterrada bajo la música. Acá se lleva
// el pico de la voz a VOZ_PICO_DB antes de mezclar, así cualquier voz suena igual de presente.
import { CWD_ORIGINAL } from "./lib/raiz.mjs";
import { spawnSync } from "node:child_process";
import { existsSync, rmSync, readFileSync, renameSync } from "node:fs";
import { resolve, join, dirname } from "node:path";

const VOZ_PICO_DB = -5.1;   // pico objetivo de la voz ANTES del ×1.4 de la plantilla
const VOL_VOZ = 1.4;        // AdT1.tsx: <Audio src={voice} volume={1.4} />
const VOL_MUSICA = 0.22;    // AdT1.tsx: <Audio src={music} volume={0.22} />
const SFX_FRAMES = 40;      // AdT1.tsx: <Sequence from={0} durationInFrames={40}> del hook auditivo

const slug = process.argv[2];
const video = process.argv[3] ? resolve(CWD_ORIGINAL, process.argv[3]) : null;
const speed = Number(process.argv[4] || 1.25);
if (!slug || !video) {
  console.error("Uso: node scripts/remix-audio-t1.mjs <slug> <video.mp4> [speed]");
  process.exit(1);
}

const ff = (args) => {
  const r = spawnSync("ffmpeg", ["-hide_banner", ...args], { encoding: "utf8" });
  if (r.status !== 0) { console.error(r.stderr || r.error); process.exit(1); }
  return (r.stdout || "") + (r.stderr || "");
};
// Mono -> estéreo duplicando el canal. Sin esto ffmpeg aplica la pan law (-3 dB) al
// convertir la voz mono a estéreo y toda la mezcla queda 3 dB por debajo de la referencia.
const canales = (f) => {
  const r = spawnSync("ffprobe", ["-v", "error", "-select_streams", "a:0",
    "-show_entries", "stream=channels", "-of", "csv=p=0", f], { encoding: "utf8" });
  return Number((r.stdout || "2").trim()) || 2;
};
const aEstereo = (f) => (canales(f) === 1 ? ",pan=stereo|c0=c0|c1=c0" : "");

const picoDb = (f) => {
  const out = ff(["-i", f, "-af", "volumedetect", "-f", "null", "-"]);
  const m = /max_volume:\s*(-?[\d.]+) dB/.exec(out);
  return m ? Number(m[1]) : null;
};

const arc = resolve("public/media/_ads", slug);
const voz = join(arc, "voz.mp3");
const musica = join(arc, "music.mp3");
for (const [n, p] of [["voz", voz], ["t1.json", join(arc, "t1.json")], ["video", video]]) {
  if (!existsSync(p)) { console.error(`No encuentro ${n}: ${p}`); process.exit(1); }
}
const t1 = JSON.parse(readFileSync(join(arc, "t1.json"), "utf8"));

const dur = t1.durationInFrames / t1.fps;
const sfxName = t1.introSfx || "intro-rev";
const sfx = resolve("public/sfx", `${sfxName}.mp3`);
const volSfx = sfxName === "intro-rev" ? 0.3 : 0.8;   // intro-rev es un barrido largo, va más bajo
const hayMusica = Boolean(t1.music) && existsSync(musica);
const haySfx = existsSync(sfx);

const pico = picoDb(voz);
if (pico === null) { console.error("No pude medir el pico de la voz"); process.exit(1); }
const ganancia = +(VOZ_PICO_DB - pico).toFixed(2);
console.log(`🎚  ${slug}: voz pico ${pico} dB → ${VOZ_PICO_DB} dB (${ganancia >= 0 ? "+" : ""}${ganancia} dB)`);

const ins = ["-i", voz];
const parts = [`[0:a]volume=${ganancia}dB,volume=${VOL_VOZ}${aEstereo(voz)}[v]`];
const labels = ["[v]"];
let idx = 1;
if (hayMusica) { ins.push("-i", musica); parts.push(`[${idx}:a]volume=${VOL_MUSICA}${aEstereo(musica)}[m]`); labels.push("[m]"); idx++; }
if (haySfx)    { ins.push("-i", sfx);    parts.push(`[${idx}:a]volume=${volSfx}${aEstereo(sfx)},atrim=0:${(SFX_FRAMES / t1.fps).toFixed(4)}[s]`); labels.push("[s]"); idx++; }
parts.push(`${labels.join("")}amix=inputs=${labels.length}:duration=longest:normalize=0[mix]`);
// atrim al largo real de la composición y después la MISMA velocidad final que aplica speedup.mjs
// El limitador va DESPUÉS del atempo: el estiramiento (overlap-add) vuelve a generar
// picos por encima del techo, así que limitar antes no sirve de nada.
parts.push(`[mix]atrim=0:${dur.toFixed(4)},asetpts=N/SR/TB,atempo=${speed},alimiter=limit=0.94:attack=1:release=60[out]`);

const tmpA = join(dirname(video), `._remix-a-${process.pid}.m4a`);
const tmpV = join(dirname(video), `._remix-v-${process.pid}.mp4`);
try {
  ff(["-y", ...ins, "-filter_complex", parts.join(";"), "-map", "[out]", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2", tmpA]);
  // el video se copia tal cual: cero recompresión, cero pérdida
  ff(["-y", "-i", video, "-i", tmpA, "-map", "0:v", "-c:v", "copy", "-map", "1:a", "-c:a", "copy",
      "-movflags", "+faststart", "-shortest", tmpV]);
  renameSync(tmpV, video);
  console.log(`✅ audio rehecho: ${video}`);
} finally {
  rmSync(tmpA, { force: true });
  rmSync(tmpV, { force: true });
}
