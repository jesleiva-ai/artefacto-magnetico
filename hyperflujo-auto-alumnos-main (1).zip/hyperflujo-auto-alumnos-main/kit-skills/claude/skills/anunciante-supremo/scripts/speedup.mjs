import { execFileSync } from "node:child_process";
import { existsSync, rmSync, statSync } from "node:fs";
import { resolve, dirname, join } from "node:path";

// Aplica una velocidad final al video (video + audio, con tono preservado).
// Uso:
//   node scripts/speedup.mjs [speed] [input] [output]
//   node scripts/speedup.mjs 1.25 out/video.mp4 out/final.mp4
//
// DOS MODOS (ANUNCIANTE_SPEED_MODE):
//
//   remux    -> NO recomprime el video. Reescala los tiempos del contenedor y solo
//               re-encodea el audio (que sí hay que estirar con atempo). El flujo de
//               video sale IDENTICO bit a bit al render: cero perdida de calidad, y
//               ~30x mas rapido. El mp4 queda a fps*speed (30 -> 37.5) conservando
//               TODOS los cuadros. Meta acepta hasta 60fps.
//
//   reencode -> el modo historico: recomprime todo con libx264. Sale a 30fps pero
//               descarta el 20% de los cuadros y pierde una generacion de calidad.
//
// Nota: no hay modo GPU. El encoder NVENC de esta maquina esta bloqueado (ffmpeg 9.0
// pide driver NVIDIA 610+, hay 595.79), y de todos modos el remux es mas rapido que
// cualquier encoder por hardware, porque directamente no comprime.
const speed = Number(process.argv[2] || 1.25);
const input = resolve(process.argv[3] || "out/video.mp4");
const output = resolve(process.argv[4] || `out/final-${speed}x.mp4`);
const MODE = (process.env.ANUNCIANTE_SPEED_MODE || "remux").toLowerCase();

if (!existsSync(input)) {
  console.error(`No encuentro ${input}. Primero corre: npm run render`);
  process.exit(1);
}
if (!(speed > 0.5 && speed <= 3)) {
  console.error(`Velocidad inválida: ${speed} (usá algo entre 0.5 y 3).`);
  process.exit(1);
}
if (!["remux", "reencode"].includes(MODE)) {
  console.error(`ANUNCIANTE_SPEED_MODE inválido: "${MODE}" (usá "remux" o "reencode").`);
  process.exit(1);
}

const ff = (args) => execFileSync("ffmpeg", ["-hide_banner", "-y", ...args], { stdio: "inherit" });

const reencode = () => {
  ff([
    "-i", input,
    "-filter_complex", `[0:v]setpts=PTS/${speed}[v];[0:a]atempo=${speed}[a]`,
    "-map", "[v]", "-map", "[a]",
    "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
    "-c:a", "aac", "-b:a", "192k",
    "-movflags", "+faststart",
    output,
  ]);
};

const remux = () => {
  const tmpV = join(dirname(output), `._spd-v-${process.pid}.mp4`);
  const tmpA = join(dirname(output), `._spd-a-${process.pid}.m4a`);
  try {
    // video: se copia tal cual, solo se reescalan los tiempos de entrada
    ff(["-itsscale", String(1 / speed), "-i", input, "-map", "0:v", "-c:v", "copy", "-an", tmpV]);
    // audio: hay que estirarlo de verdad (atempo preserva el tono)
    ff(["-i", input, "-map", "0:a", "-filter:a", `atempo=${speed}`, "-c:a", "aac", "-b:a", "192k", tmpA]);
    ff(["-i", tmpV, "-i", tmpA, "-c", "copy", "-movflags", "+faststart", output]);
  } finally {
    rmSync(tmpV, { force: true });
    rmSync(tmpA, { force: true });
  }
};

console.log(`⚡ Acelerando ${input} a ${speed}x → ${output}  [modo: ${MODE}]`);
const t0 = Date.now();
if (MODE === "remux") remux(); else reencode();
const secs = ((Date.now() - t0) / 1000).toFixed(1);
const mb = (statSync(output).size / 1024 / 1024).toFixed(1);
console.log(`\n✅ Listo: ${output}  (${mb} MB, ${secs}s)`);
