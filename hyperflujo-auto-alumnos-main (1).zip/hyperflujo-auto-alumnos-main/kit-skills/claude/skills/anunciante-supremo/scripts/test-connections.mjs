import { loadEnv, mask } from "./lib/env.mjs";
import * as apimart from "./lib/apimart.mjs";
try { loadEnv(); } catch { /* la llave puede venir del entorno */ }

const checks = [
  ["APIMART   ", "APIMART_API_KEY", async () => { const r = await apimart.probe(); return "llave autenticada"; }, true],
  ["ElevenLabs", "ELEVENLABS_API_KEY", async () => {
    const res = await fetch("https://api.elevenlabs.io/v1/voices", { headers: { "xi-api-key": process.env.ELEVENLABS_API_KEY } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const v = (await res.json()).voices || []; return `${v.length} voces (ej: ${v.slice(0, 3).map((x) => x.name).join(", ")})`; }, false],
];
console.log("\n🔌 Probando conexiones…\n");
let fallo = false;
for (const [n, k, fn, obligatoria] of checks) {
  if (!process.env[k]) { console.log(`  ${obligatoria ? "❌" : "ℹ️ "} ${n}  [sin llave]  ${obligatoria ? "OBLIGATORIA" : "opcional"}`); fallo ||= obligatoria; continue; }
  try { console.log(`  ✅ ${n}  [${mask(process.env[k])}]  ${await fn()}`); }
  catch (e) { console.log(`  ❌ ${n}  [${mask(process.env[k])}]  ${e.message}`); fallo ||= obligatoria; }
}
console.log(fallo ? "\n⚠️  Revisa la llave obligatoria.\n" : "\n✨ Conectado.\n");
process.exitCode = fallo ? 1 : 0;
