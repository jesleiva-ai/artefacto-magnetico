"""Arnés de aceptación de la plantilla 2.

Mide el .mp4 producido y lo compara contra lo medido en los anuncios de referencia.
Es el mismo método con el que se hizo la ingeniería inversa (spec §10), así que un
anuncio que pasa acá es indistinguible del original en todo lo que se puede medir.

Uso:
  python scripts/verificar-t2.py out/x.mp4 --clips "<dir de clips>" --musica "<mp3>"
"""
import argparse, subprocess, sys, wave, tempfile, os, glob, re, json
import numpy as np
from scipy.signal import fftconvolve

# Windows corre este script con stdout en la codepage ANSI (cp1252) si no está
# conectado a una consola real: cualquier tilde o el ✅/❌ final revienta con
# UnicodeEncodeError, o peor, sale mal codificado sin avisar. Forzar UTF-8.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

SR = 16000
OK, FALLO = "  OK  ", " FALLA"

# Piso de correlación para confiar en un punto de muestreo antes de meterlo al RANSAC
# de fit_robusto. Medido comparando un anuncio de referencia contra sus propios clips
# (match real) contra otro anuncio —OTRA voz, otros clips— contra esos mismos clips
# (mismatch, ver control negativo del task-6-report): en el match cada clip retiene
# 8-13 de 18 puntos con r>=0.30; en el mismatch retiene 0-1, y el r más alto que
# aparece en todo el mismatch es 0.336. 0.30 separa limpio los dos mundos con margen.
UMBRAL_R = 0.30

def wav(path, extra=()):
    f = tempfile.mktemp(suffix=".wav")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, *extra,
                    "-vn", "-ac", "1", "-ar", str(SR), f], check=True)
    w = wave.open(f, "rb")
    d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float64) / 32768.0
    w.close(); os.unlink(f)
    return d

def corr(hay, seg):
    seg = seg - seg.mean()
    if np.abs(seg).max() < 1e-5:
        return 0.0, 0.0
    num = fftconvolve(hay, seg[::-1], mode="valid")
    e = np.sqrt(np.maximum(fftconvolve(hay ** 2, np.ones(len(seg)), mode="valid"), 1e-12))
    r = num / (e * np.sqrt((seg ** 2).sum()) + 1e-12)
    i = int(np.argmax(r))
    return float(r[i]), i / SR

def fit_robusto(puntos, pendiente_min=0.30, pendiente_max=0.99, tolerancia=0.35):
    """Ajusta t_ad = pendiente*t_src + b sobre muestras densas de un clip, robusto
    a matches espurios.

    Con una sola marca por punto de referencia (ej. a 15/50/85% del clip) el
    arnés es frágil: el editor recorta las puntas de cada escena y ese tramo
    directamente no está en el anuncio, así que ahí la correlación cruzada
    "encuentra" el máximo global en cualquier otro lado del audio (r bajo, match
    falso) y arruina la pendiente. La solución es RANSAC minimalista: probar la
    pendiente de cada par de puntos, quedarse con la que junta más consenso
    (más puntos caen sobre esa misma recta dentro de la tolerancia) y reajustar
    por cuadrados mínimos solo sobre ese consenso.

    OJO con el piso de consenso: un par de puntos siempre tiene residuo cero
    consigo mismo, así que cualquier par cuya pendiente caiga en el rango
    permitido ya arma un "ajuste" de 2 sobre 2 por construcción, sin decir nada
    sobre si el clip realmente está en el anuncio. Por eso el piso es
    proporcional al tamaño de la entrada (`puntos` ya viene filtrado por r en
    main(), ver UMBRAL_R) y no un 2 fijo: con datos genuinos, filtrados,
    quedan 8-13 puntos por clip y 7-13 caen en la recta; con un clip que no
    está en el anuncio, el filtro de r ya lo deja en 0-1 puntos, muy por
    debajo del piso.
    """
    n = len(puntos)
    piso = max(4, 0.3 * n)
    if n < 2:
        return None
    ts = np.array([p[0] for p in puntos])
    ta = np.array([p[1] for p in puntos])
    mejor = None
    for i in range(n):
        for j in range(i + 1, n):
            if ts[j] == ts[i]:
                continue
            s = (ta[j] - ta[i]) / (ts[j] - ts[i])
            if not (pendiente_min < s < pendiente_max):
                continue
            b = ta[i] - s * ts[i]
            residuos = np.abs(ta - (s * ts + b))
            inliers = residuos < tolerancia
            if mejor is None or inliers.sum() > mejor[0]:
                mejor = (int(inliers.sum()), inliers)
    if mejor is None or mejor[0] < piso:
        return None
    _, inliers = mejor
    pendiente, b = np.polyfit(ts[inliers], ta[inliers], 1)
    return pendiente, b, int(inliers.sum()), n

def f0(x, lo=70, hi=320):
    n, hop, out = int(0.04 * SR), int(0.02 * SR), []
    for i in range(0, len(x) - n, hop):
        s = x[i:i + n]
        if np.sqrt((s ** 2).mean()) < 0.02:
            continue
        s = s - s.mean()
        r = np.correlate(s, s, "full")[n - 1:]
        r /= (r[0] + 1e-12)
        a, b = SR // hi, min(SR // lo, len(r) - 1)
        k = int(np.argmax(r[a:b])) + a
        if r[k] > 0.35:
            out.append(SR / k)
    return np.median(out) if out else float("nan")

def orden_escena(path):
    """Clave de orden: el número de la escena, no el nombre del archivo."""
    m = re.search(r"escena(\d+)", os.path.basename(path))
    return (int(m.group(1)) if m else float("inf"), os.path.basename(path))

def probe(path, campo):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        campo, "-of", "default=nw=1:nk=1", path], capture_output=True, text=True)
    return r.stdout.split()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--clips", help="carpeta de clips; con --brief es opcional (se toma del brief)")
    ap.add_argument("--brief", help="el ad-NN.json: toma de ahí los nombres y el orden de los clips")
    ap.add_argument("--musica"); ap.add_argument("--velocidad", type=float, default=1.18)
    a = ap.parse_args()
    if not a.clips and not a.brief:
        ap.error("hace falta --clips o --brief")

    fallos = []
    def chequeo(nombre, ok, detalle):
        print(f"[{OK if ok else FALLO}] {nombre}: {detalle}")
        if not ok:
            fallos.append(nombre)

    # Orden POR NÚMERO DE ESCENA, no lexicográfico: con 10 o más escenas, sorted() pone
    # escena10.mp4 antes que escena2.mp4 y el chequeo de monotonía falla contra un anuncio
    # perfectamente correcto.
    # Los clips no siempre se llaman escenaN.mp4: el ensamblador toma el nombre del brief, así que
    # otra convención (`AD1 E1.mp4`) es igual de válida. Si el arnés glob-eara solo
    # `escena*`, no podría verificar la mitad de los anuncios. Con `--brief` lee los nombres y el orden del propio brief.
    if a.brief:
        with open(a.brief, encoding="utf8") as fh:
            brief = json.load(fh)
        base = a.clips or brief.get("clips", "")
        # Igual que el ensamblador: un `clips` relativo del brief se resuelve contra la carpeta
        # del brief, no contra el cwd. Un --clips explícito sí es relativo al cwd.
        if not a.clips and base and not os.path.isabs(base):
            base = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(a.brief)), base))
        fuentes = [os.path.join(base, e["clip"]) for e in brief.get("escenas", [])]
        faltan = [f for f in fuentes if not os.path.exists(f)]
        if faltan:
            chequeo("clips fuente", False,
                    "el brief nombra clips que no existen: " + ", ".join(os.path.basename(f) for f in faltan))
            print(f"\n❌ 1 criterio(s) sin cumplir: clips fuente")
            sys.exit(1)
        patron = f"{len(fuentes)} clips del brief {os.path.basename(a.brief)}"
    else:
        patron = os.path.join(a.clips, "escena*.mp4")
        fuentes = sorted(glob.glob(patron), key=orden_escena)
    # Sin clips fuente no hay nada que medir. Antes, la lista vacía imprimía
    # "[ OK ] clips en orden: []" —un OK sobre cero evidencia— y recién después reventaba
    # con un ValueError de numpy. Es una FALLA explícita, y corta acá.
    if not fuentes:
        chequeo("clips fuente", False,
                f"no encontré ningún clip con el patrón {patron} — revisa --clips "
                f"(el arnés espera nombres escenaN.mp4)")
        print("\n❌ sin clips fuente no hay nada que verificar")
        sys.exit(1)

    ad = wav(a.video)

    # 1. EDL: cada clip aparece, en orden, y la pendiente da la velocidad.
    # Muestreo denso (cada 0.4s, con margen de 0.55s a cada punta del clip para que
    # la ventana de correlación de 1s no se salga) + ajuste robusto (ver fit_robusto):
    # la posición del clip en el anuncio es la recta extrapolada a t_src=0, no una
    # marca suelta.
    posiciones, pendientes, sin_ajuste = [], [], []
    for f in fuentes:
        src = wav(f)
        dur_src = len(src) / SR
        puntos = []
        t = 0.55
        while t < dur_src - 0.55:
            c = int(t * SR)
            seg = src[c - int(0.5 * SR): c + int(0.5 * SR)]
            r, ta = corr(ad, seg)
            puntos.append((t, ta, r))
            t += 0.4
        # Descartar los puntos de correlación floja ANTES del RANSAC: si no, un par
        # de matches de r bajo puede armar un "ajuste" de 2 sobre 2 que no significa
        # nada (ver el comentario de fit_robusto). UMBRAL_R es la línea que separa
        # clip-que-sí-está-en-el-anuncio de clip-que-no, medida en el control negativo.
        confiables = [p for p in puntos if p[2] >= UMBRAL_R]
        ajuste = fit_robusto(confiables)
        if ajuste is None:
            sin_ajuste.append(os.path.basename(f))
            posiciones.append(float("inf"))
            continue
        pendiente, b, _inliers, _total = ajuste
        posiciones.append(float(b))  # t_ad extrapolado a t_src=0: posición del clip en el anuncio
        pendientes.append(1.0 / pendiente)  # velocidad = 1 / pendiente
    if sin_ajuste:
        chequeo("clips en orden", False, f"no pude ubicar en el anuncio: {', '.join(sin_ajuste)}")
    else:
        chequeo("clips en orden", posiciones == sorted(posiciones), f"{[round(p,1) for p in posiciones]}")
    vel = float(np.median(pendientes)) if pendientes else 0
    chequeo("velocidad", abs(vel - a.velocidad) <= 0.02, f"{vel:.3f} (esperado {a.velocidad}±0.02)")

    # 2. tono conservado
    crudo = np.concatenate([wav(f) for f in fuentes])
    razon = f0(ad) / f0(crudo)
    chequeo("tono conservado", abs(razon - 1.0) <= 0.03, f"F0 montado/crudo = {razon:.3f}")

    # 3. música
    if a.musica:
        mus = wav(a.musica)[:len(ad)]
        mus = np.pad(mus, (0, max(0, len(ad) - len(mus))))
        g = float((ad * mus).sum() / ((mus ** 2).sum() + 1e-12))
        db = 20 * np.log10(abs(g) + 1e-12)
        chequeo("nivel de música", abs(db + 20) <= 2, f"{db:.1f} dB (esperado -20±2)")

    # 4. geometría de las captions (spec §2.3): una palabra, centrada exacta
    from PIL import Image
    from scipy import ndimage
    import io
    def cuadro(t):
        p = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(t), "-i", a.video, "-frames:v", "1",
                            "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
        return np.asarray(Image.open(io.BytesIO(p.stdout)).convert("RGB")).astype(np.int16)

    def caja_caption(im):
        """componentes blancos con forma de letra y borde oscuro alrededor"""
        H, W, _ = im.shape
        blanco = im.min(axis=2) > 220
        lab, n = ndimage.label(blanco)
        letras = []
        for i, sl in enumerate(ndimage.find_objects(lab), start=1):
            ys, xs = sl
            h, w = ys.stop - ys.start, xs.stop - xs.start
            if not (0.020 * H < h < 0.075 * H) or w > 0.20 * W or w < 0.004 * W:
                continue
            if (lab[sl] == i).sum() < 0.25 * h * w:
                continue
            y0, y1 = max(0, ys.start - 4), min(H, ys.stop + 4)
            x0, x1 = max(0, xs.start - 4), min(W, xs.stop + 4)
            m = im[y0:y1, x0:x1]
            borde = np.concatenate([m[0].ravel(), m[-1].ravel(), m[:, 0].ravel(), m[:, -1].ravel()])
            if np.median(borde) > 110:
                continue
            letras.append((ys.start, ys.stop, xs.start, xs.stop))
        if len(letras) < 2:
            return None
        mejor, best = None, 0
        for t, *_ in letras:
            sel = [l for l in letras if abs(l[0] - t) < 0.03 * H]
            if len(sel) > best:
                best, mejor = len(sel), sel
        return (min(l[2] for l in mejor), max(l[3] for l in mejor),
                min(l[0] for l in mejor), max(l[1] for l in mejor))

    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                "-of", "default=nw=1:nk=1", a.video],
                               capture_output=True, text=True).stdout.strip())
    cxs, cys, altos = [], [], []
    for t in np.linspace(dur * 0.05, dur * 0.9, 12):
        im = cuadro(float(t))
        b = caja_caption(im)
        if not b:
            continue
        H, W, _ = im.shape
        cxs.append((b[0] + b[1]) / 2 / W * 100)
        cys.append((b[2] + b[3]) / 2 / H * 100)
        altos.append((b[3] - b[2]) / H * 100)
    if cxs:
        chequeo("captions centradas en X", abs(np.median(cxs) - 50) <= 1, f"{np.median(cxs):.1f}% (esperado 50±1)")
        chequeo("captions centradas en Y", abs(np.median(cys) - 50) <= 1, f"{np.median(cys):.1f}% (esperado 50±1)")
        chequeo("alto de la caption", abs(np.median(altos) - 3.1) <= 0.2, f"{np.median(altos):.2f}% (esperado 3.1±0.2)")
    else:
        chequeo("captions detectadas", False, "no encontré ninguna caption en 12 cuadros")

    # 5. perfil de salida
    rfr, afr = probe(a.video, "stream=r_frame_rate,avg_frame_rate")[:2]
    chequeo("frame rate constante", rfr == afr == "30/1", f"r={rfr} avg={afr}")
    w, h = probe(a.video, "stream=width,height")[:2]
    chequeo("resolución", (w, h) == ("1080", "1920"), f"{w}x{h}")

    print()
    if fallos:
        print(f"❌ {len(fallos)} criterio(s) sin cumplir: {', '.join(fallos)}")
        sys.exit(1)
    print("✅ el anuncio cumple los criterios de la plantilla 2")

if __name__ == "__main__":
    main()
