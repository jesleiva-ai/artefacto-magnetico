import React from "react";
import { Composition } from "remotion";
import { AdT1 } from "./templates/t1/AdT1";
import t1 from "./data/t1.json";

// Cada PLANTILLA de anuncio es una composición propia. La plantilla 2 no está acá:
// es un ensamblador de ffmpeg (scripts/ensamblar-t2.mjs) y no dibuja animaciones.
export const RemotionRoot: React.FC = () => (
  <>
    {/* Plantilla 1 — B-roll + voz en off */}
    <Composition
      id="plantilla-1"
      component={AdT1}
      durationInFrames={Math.max(1, t1.durationInFrames)}
      fps={t1.fps}
      width={t1.width}
      height={t1.height}
    />
  </>
);
