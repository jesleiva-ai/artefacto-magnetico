import React from "react";
import { useCurrentFrame, useVideoConfig, spring } from "remotion";
import { loadFont } from "@remotion/google-fonts/Anton";
import { COLORS } from "../theme";

const { fontFamily } = loadFont();

export type Word = { text: string; start: number; end: number };

// Cuántas palabras se muestran juntas en pantalla (bloque estilo Hormozi).
const GROUP = 3;

// Captions karaoke: bloques de pocas palabras, la que se está diciendo se resalta
// en la tarjeta de acento con un pop. Muy visual, centrado, tipografía gruesa.
export const Captions: React.FC<{ words: Word[]; top?: number }> = ({ words, top = 1330 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;

  if (!words || !words.length) return null;

  // Agrupa en bloques de GROUP palabras.
  const groups: Word[][] = [];
  for (let i = 0; i < words.length; i += GROUP) groups.push(words.slice(i, i + GROUP));

  // Bloque activo = el último cuyo inicio ya pasó.
  let gi = 0;
  for (let i = 0; i < groups.length; i++) {
    if (t >= groups[i][0].start) gi = i;
    else break;
  }
  const group = groups[gi];
  const groupStartFrame = Math.round(group[0].start * fps);

  // Pequeño rebote de entrada del bloque completo.
  const appear = spring({
    frame: frame - groupStartFrame,
    fps,
    config: { damping: 14, mass: 0.6, stiffness: 140 },
    durationInFrames: 10,
  });

  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top,
        display: "flex",
        justifyContent: "center",
        padding: "0 70px",
      }}
    >
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "16px 20px",
          justifyContent: "center",
          transform: `scale(${0.9 + 0.1 * appear})`,
        }}
      >
        {group.map((w, i) => {
          const active = t >= w.start && t < w.end;
          const spoken = t >= w.start;
          return (
            <span
              key={i}
              style={{
                fontFamily,
                fontSize: 88,
                lineHeight: 1.0,
                letterSpacing: 1,
                textTransform: "uppercase",
                color: active ? "#FFF4DE" : COLORS.paperText,
                background: active ? COLORS.orange : "transparent",
                padding: active ? "6px 20px" : "6px 4px",
                borderRadius: 16,
                transform: active ? "scale(1.12) rotate(-1deg)" : "scale(1)",
                boxShadow: active ? "0 10px 0 rgba(32,24,15,0.18)" : "none",
                textShadow: active ? "none" : "0 3px 0 rgba(32,24,15,0.14)",
                opacity: spoken ? 1 : 0.32,
                transition: "none",
                display: "inline-block",
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </div>
  );
};
