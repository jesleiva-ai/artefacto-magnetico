import React from "react";
import { useCurrentFrame, useVideoConfig, spring } from "remotion";
import { loadFont } from "@remotion/google-fonts/Anton";
import { Word } from "./Captions";

const { fontFamily } = loadFont();

// Captions karaoke NEGRO sobre fondo BLANCO (estilo pedido para la Plantilla 1).
// Bloques de pocas palabras; la palabra activa se invierte (texto blanco sobre caja negra).
const GROUP = 3;

export const CaptionsT1: React.FC<{ words: Word[]; top?: number }> = ({ words, top = 1200 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  if (!words || !words.length) return null;

  const groups: Word[][] = [];
  for (let i = 0; i < words.length; i += GROUP) groups.push(words.slice(i, i + GROUP));

  let gi = 0;
  for (let i = 0; i < groups.length; i++) {
    if (t >= groups[i][0].start) gi = i;
    else break;
  }
  const group = groups[gi];
  const groupStartFrame = Math.round(group[0].start * fps);
  const appear = spring({
    frame: frame - groupStartFrame,
    fps,
    config: { damping: 16, mass: 0.6, stiffness: 150 },
    durationInFrames: 8,
  });

  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top,
        display: "flex",
        justifyContent: "center",
        padding: "0 70px",
      }}
    >
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "12px 14px",
          justifyContent: "center",
          transform: `scale(${0.94 + 0.06 * appear})`,
        }}
      >
        {group.map((w, i) => {
          const active = t >= w.start && t < w.end;
          return (
            <span
              key={i}
              style={{
                fontFamily,
                fontSize: 76,
                lineHeight: 1.0,
                letterSpacing: 0.5,
                textTransform: "uppercase",
                color: active ? "#FFFFFF" : "#111111",
                background: active ? "#111111" : "#FFFFFF",
                padding: "8px 18px",
                borderRadius: 12,
                boxShadow: "0 6px 14px rgba(0,0,0,0.28)",
                transform: active ? "scale(1.08)" : "scale(1)",
                display: "inline-block",
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </div>
  );
};
