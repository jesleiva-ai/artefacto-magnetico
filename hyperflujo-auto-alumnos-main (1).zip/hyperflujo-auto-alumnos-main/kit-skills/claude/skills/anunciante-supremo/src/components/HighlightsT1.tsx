import React from "react";
import { Img, Audio, Sequence, staticFile, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";

export type Highlight = { image: string; start: number };

// Imágenes de resalte BREVES: aparecen ~1.2s en el momento de su palabra, con pop
// de entrada y salida, alternando lado arriba (no tapan las captions de abajo).
const LIFE = 1.2; // segundos visibles
const SIZE = 340;
const POS = [
  [300, 470],
  [780, 470],
  [300, 470],
  [780, 470],
];

export const HighlightsT1: React.FC<{ items: Highlight[] }> = ({ items }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (!items || !items.length) return null;

  return (
    <>
      {/* Campanita al aparecer cada resalte (siempre montado; el Sequence maneja el tiempo). */}
      {items.map((h, i) => (
        <Sequence key={`sfx-${i}`} from={Math.round(h.start * fps)} durationInFrames={22} name={`sfx-hl-${i}`}>
          <Audio src={staticFile("sfx/pop-bell.mp3")} volume={0.4} />
        </Sequence>
      ))}

      {items.map((h, i) => {
        const sf = Math.round(h.start * fps);
        const life = Math.round(LIFE * fps);
        if (frame < sf || frame > sf + life) return null;
        const local = frame - sf;
        const appear = spring({ frame: local, fps, config: { damping: 11, mass: 0.5, stiffness: 180 }, durationInFrames: 12 });
        const out = interpolate(local, [life - 8, life], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        const [x, y] = POS[i % POS.length];
        const rot = (i % 2 === 0 ? -1 : 1) * 4;
        return (
          <Img
            key={i}
            src={staticFile(h.image)}
            style={{
              position: "absolute",
              left: x - SIZE / 2,
              top: y - SIZE / 2,
              width: SIZE,
              height: SIZE,
              objectFit: "contain",
              opacity: out,
              transform: `scale(${appear}) rotate(${rot}deg)`,
              filter: "drop-shadow(0 12px 16px rgba(0,0,0,0.4))",
            }}
          />
        );
      })}
    </>
  );
};
