import React from "react";

// Marcado del hook (ver plantillas/hooks.md §4 y §9):
//   "|"  o salto de línea → corte de línea forzado donde la frase se lee natural.
//   *texto*               → énfasis: la power word / el número va en color de acento y más grande
//                           (como el "1 MILLION" amarillo o "FULL MONTH" de los ejemplos del video).
// Compartido por t1, t1 y t3.

export type HookSegment = { text: string; em: boolean };

export const parseHook = (text: string): HookSegment[][] =>
  text
    .split(/\s*\|\s*|\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line) =>
      line
        .split(/(\*[^*]+\*)/)
        .filter(Boolean)
        .map((seg) =>
          seg.startsWith("*") && seg.endsWith("*") && seg.length > 2
            ? { text: seg.slice(1, -1), em: true }
            : { text: seg, em: false },
        ),
    );

// Render con <br/> entre líneas y <span> de énfasis opcional.
export const hookLines = (text: string, emStyle?: React.CSSProperties) =>
  parseHook(text).map((segs, i) => (
    <React.Fragment key={i}>
      {i > 0 && <br />}
      {segs.map((s, j) =>
        s.em ? (
          <span key={j} style={emStyle}>
            {s.text}
          </span>
        ) : (
          <React.Fragment key={j}>{s.text}</React.Fragment>
        ),
      )}
    </React.Fragment>
  ));
