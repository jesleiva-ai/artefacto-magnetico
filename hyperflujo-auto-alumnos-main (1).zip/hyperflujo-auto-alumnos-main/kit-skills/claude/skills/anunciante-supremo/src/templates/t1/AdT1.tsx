import React from "react";
import {
  AbsoluteFill, Audio, OffthreadVideo, Sequence, staticFile,
  useCurrentFrame, interpolate,
} from "remotion";
import data from "../../data/t1.json";
import { CaptionsT1 } from "../../components/CaptionsT1";
import { HighlightsT1 } from "../../components/HighlightsT1";
import { HookTitle, HookStyle, HookPosition } from "./HookTitle";

// Un b-roll a pantalla completa (cover) con un leve zoom continuo. Audio del clip MUTEADO.
const BrollClip: React.FC<{ src: string; startFrom: number; dur: number }> = ({ src, startFrom, dur }) => {
  const frame = useCurrentFrame();
  const scale = interpolate(frame, [0, dur], [1.04, 1.12], { extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ overflow: "hidden", backgroundColor: "#000" }}>
      <OffthreadVideo
        src={staticFile(src)}
        startFrom={startFrom}
        muted
        style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${scale})` }}
      />
    </AbsoluteFill>
  );
};

// Plantilla 1 — "B-roll + voz en off". Fondo de b-rolls cortando cada ~1.5s,
// captions karaoke negro/blanco, resaltes breves, hook inicial y música pop.
export const AdT1: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      {/* Fondo: secuencia de b-rolls. premountFor pre-carga el próximo clip para que
          NO haya un frame negro al cambiar de video (transición fluida). */}
      {data.broll.map((b, i) => (
        <Sequence
          key={i}
          from={b.from}
          durationInFrames={b.durationInFrames}
          premountFor={20}
          name={`broll-${i}`}
        >
          <BrollClip src={b.file} startFrom={b.startFrom} dur={b.durationInFrames} />
        </Sequence>
      ))}

      {/* Hook auditivo al aparecer el título (brief: introSfx = nombre en public/sfx/). Default: intro en reversa */}
      <Sequence from={0} durationInFrames={40} name="sfx-intro">
        <Audio
          src={staticFile(`sfx/${(data as { introSfx?: string }).introSfx || "intro-rev"}.mp3`)}
          volume={((data as { introSfx?: string }).introSfx || "intro-rev") === "intro-rev" ? 0.3 : 0.8}
        />
      </Sequence>

      {/* Voz en off (Bella) */}
      <Audio src={staticFile(data.voice)} volume={1.4} />
      {/* Música pop de fondo (instrumental) */}
      {data.music ? <Audio src={staticFile(data.music as string)} volume={0.22} /> : null}

      {/* Resaltes breves */}
      <HighlightsT1 items={data.highlights} />

      {/* Captions karaoke negro sobre blanco */}
      <CaptionsT1 words={data.words} />

      {/* Título gancho (primeros 3-5s). Estilo/posición/acento vienen del brief (hookStyle, hookPosition, hookAccent) */}
      <HookTitle
        text={data.hook}
        frames={data.hookFrames}
        style={(data as { hookStyle?: HookStyle }).hookStyle}
        position={(data as { hookPosition?: HookPosition }).hookPosition}
        accent={(data as { hookAccent?: string | null }).hookAccent}
      />
    </AbsoluteFill>
  );
};
