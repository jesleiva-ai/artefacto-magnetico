import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { loadFont as loadAnton } from "@remotion/google-fonts/Anton";
import { loadFont as loadInter } from "@remotion/google-fonts/Inter";
import { hookLines, parseHook } from "../../components/hookLines";

const anton = loadAnton();
const inter = loadInter("normal", { weights: ["700", "800"], subsets: ["latin", "latin-ext"] });

export type HookStyle = "panel" | "system";
export type HookPosition = "center" | "top";

// Título GANCHO sobre el b-roll durante los primeros 3-5s. Entra con rebote, sostiene y sale.
//
// Dos estilos (plantillas/hooks.md §9):
//  - "panel"  (histórico): panel oscuro semitransparente + Anton blanco en mayúsculas.
//  - "system" (recomendado): caja BLANCA con texto NEGRO en Inter bold, caja normal (no uppercase),
//             como el text hook nativo de IG/TikTok que usan los ganadores del video de Kallaway.
//             Es el que más rápido leen los ojos porque es el patrón que el feed ya entrenó.
// Dos posiciones: "center" (histórico) o "top" (tercio superior, ~1/3 desde arriba, para no tapar
// la cara / el sujeto del b-roll y dejar las captions abajo). Recomendado: "top".
// Énfasis: *palabra* dentro del hook → color de acento y tamaño mayor.
export const HookTitle: React.FC<{
  text: string;
  frames: number;
  style?: HookStyle;
  position?: HookPosition;
  accent?: string | null;
}> = ({ text, frames, style = "panel", position = "center", accent }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame > frames + 10) return null;

  const inP = spring({ frame, fps, config: { damping: 13, mass: 0.7, stiffness: 130 }, durationInFrames: 12 });
  const outP = interpolate(frame, [frames - 8, frames + 8], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const op = Math.min(inP, outP);
  const y = (1 - inP) * -60;

  const isSystem = style === "system";
  // Amarillo tipo "1 MILLION" por defecto en panel oscuro; en caja blanca, un rojo/acento legible.
  const emColor = accent || (isSystem ? "#D7263D" : "#F5E642");

  // Auto-ajuste: la línea más larga (según los cortes "|") tiene que entrar en UNA línea de pantalla.
  // Inter 800 ≈ 0.58em por carácter → ~22 chars a 80px en ~1000px útiles; Anton ≈ 0.45em → ~18 chars a 104px.
  // (2026-08-22: system subió de 66→80px; en celular a 20 cm el hook quedaba chico. Las líneas largas
  // se parten con "|" en el brief hasta 3 líneas en vez de achicar la fuente.)
  const longest = Math.max(1, ...parseHook(text).map((l) => l.map((s) => s.text).join("").length));
  const fit = Math.min(1, (isSystem ? 22 : 18) / longest);
  const baseSize = (isSystem ? 80 : 104) * fit;
  const emSize = (isSystem ? 96 : 124) * fit;

  const wrap: React.CSSProperties =
    position === "top"
      ? { justifyContent: "flex-start", alignItems: "center", padding: "400px 30px 0" }
      : { justifyContent: "center", alignItems: "center", padding: "0 70px" };

  return (
    <AbsoluteFill style={wrap}>
      <div
        style={{
          opacity: op,
          transform: `translateY(${y}px)`,
          background: isSystem ? "#FFFFFF" : "rgba(10,10,10,0.72)",
          borderRadius: isSystem ? 22 : 28,
          padding: isSystem ? "22px 30px" : "34px 44px",
          maxWidth: isSystem ? 1020 : 940,
          boxShadow: isSystem ? "0 10px 30px rgba(0,0,0,0.35)" : undefined,
        }}
      >
        <span
          style={{
            fontFamily: isSystem ? inter.fontFamily : anton.fontFamily,
            fontWeight: isSystem ? 800 : 400,
            fontSize: baseSize,
            lineHeight: isSystem ? 1.18 : 1.02,
            letterSpacing: isSystem ? -0.5 : 1,
            color: isSystem ? "#111111" : "#FFFFFF",
            textTransform: isSystem ? "none" : "uppercase",
            textAlign: "center",
            display: "block",
            textShadow: isSystem ? undefined : "0 4px 14px rgba(0,0,0,0.5)",
          }}
        >
          {hookLines(text, { color: emColor, fontSize: emSize, lineHeight: 1, whiteSpace: "nowrap" })}
        </span>
      </div>
    </AbsoluteFill>
  );
};
