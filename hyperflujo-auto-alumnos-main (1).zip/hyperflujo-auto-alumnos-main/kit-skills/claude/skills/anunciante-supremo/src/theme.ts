// Paleta del canal — se AUTOCONFIGURA desde brand.json (lo escribe el onboarding).
import brand from "./brand.json";

const c = brand.colores || {};

export const COLORS = {
  cream: c.fondo || "#F4ECD6", // fondo papel
  creamDark: (c as { fondoSombra?: string }).fondoSombra || "#EADFC2", // sombras del papel
  ink: c.tinta || "#20180F", // tinta (tarjetas oscuras / hook)
  orange: c.acento || "#FF5A1F", // acento (color de marca)
  paperText: (c as { textoPapel?: string }).textoPapel || c.tinta || "#20180F", // texto sobre el fondo (captions)
} as const;

export const BRAND = brand;
