import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { normalizar, duracionEsperada, alinear } from "../scripts/lib/alinear.mjs";

const fx = JSON.parse(readFileSync(new URL("./fixtures/escena1-words.json", import.meta.url)));
const corr = () => alinear(fx.words, fx.dialogo);

test("normalizar baja, saca acentos y puntuación, conserva el apóstrofo", () => {
  assert.equal(normalizar("Blank."), "blank");
  assert.equal(normalizar("months..."), "months");
  assert.equal(normalizar("teacher's"), "teacher's");
  assert.equal(normalizar("Educación"), "educacion");
  assert.equal(normalizar("..."), "");
});

test("el apóstrofo tipográfico normaliza igual que el ASCII", () => {
  // whisper devuelve indistintamente "teacher\u2019s" y "teacher's". Si normalizan distinto,
  // el LCS no las casa y una escena en un idioma —densos en elisión— se cae de
  // cobertura por palabras que en realidad SÍ están.
  assert.equal(normalizar("teacher\u2019s"), normalizar("teacher's"));
  assert.equal(normalizar("teacher\u2019s"), "teacher's");
  assert.equal(normalizar("o\u2019clock"), "o'clock");
});

test("descarta la alucinación de cola", () => {
  const r = corr();
  assert.deepEqual(r.descartadas, ["Music"]);
  assert.equal(r.palabras.length, 11);
});

test("recorta la palabra estirada y no toca las legítimas", () => {
  const r = corr();
  assert.deepEqual(r.recortadas.map((x) => x.texto), ["a"]);
  const e = r.palabras.find((p) => p.texto === "a");
  assert.ok(e.end - e.start < 0.3, `"a" quedó en ${(e.end - e.start).toFixed(3)}s`);
  const larga = r.palabras.find((p) => p.texto === "teacher's");
  assert.ok(Math.abs((larga.end - larga.start) - 0.9) < 1e-9,
    `"teacher's" quedó en ${(larga.end - larga.start).toFixed(3)}s, se esperaba 0.9`);
});

test("el umbral por caracteres separa el caso real por margen amplio", () => {
  // "a": 1 carácter -> umbral 0.45s contra 1.28s reales.
  // "teacher's": 9 caracteres -> umbral 1.84s contra 0.90s reales.
  assert.ok(2.5 * duracionEsperada("a") + 0.15 < 1.28);
  assert.ok(2.5 * duracionEsperada("teacher's") + 0.15 > 0.9);
});

test("el fin de escena sale de la última palabra real más la cola", () => {
  const r = corr();
  assert.ok(Math.abs(r.finEscena - (5.42 + 0.25)) < 1e-9);
});

test("el texto en pantalla es el del brief, no el de Whisper", () => {
  const r = corr();
  assert.equal(r.palabras[4].texto, "months...");
  assert.equal(r.palabras.at(-1).texto, "blank.");
});

test("cobertura completa cuando el clip dice lo que el brief pidió", () => {
  assert.equal(corr().cobertura, 1);
});

test("cobertura baja cuando el clip dice otra cosa", () => {
  const r = alinear(fx.words, "Esto es un diálogo completamente distinto que no coincide");
  assert.ok(r.cobertura < 0.8, `cobertura ${r.cobertura}`);
});

test("avisa las palabras del brief que se quedan SIN caption", () => {
  // El brief dice "dezenove" y "sete" con letras y Whisper devuelve las cifras.
  // La cobertura queda alta pero esas palabras salen mudas.
  const words = [
    { word: "São", start: 0, end: 0.4 },
    { word: "19",    start: 0.4, end: 0.8 },
    { word: "receitas", start: 0.8, end: 1.2 },
    { word: "e",     start: 1.2, end: 1.4 },
    { word: "7",     start: 1.4, end: 1.8 },
    { word: "bônus", start: 1.8, end: 2.3 },
  ];
  const r = alinear(words, "São dezenove receitas e sete bônus");
  assert.deepEqual(r.sinCaption, ["dezenove", "sete"]);
  assert.ok(r.cobertura > 0.6 && r.cobertura < 0.8, `cobertura ${r.cobertura}`);
});

test("sin palabras perdidas, sinCaption viene vacío", () => {
  assert.deepEqual(corr().sinCaption, []);
});
