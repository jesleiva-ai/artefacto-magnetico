import { test } from "node:test";
import assert from "node:assert/strict";
import { extraerUrls, estadoDe, conReintentos } from "../scripts/lib/apimart.mjs";

test("extraerUrls encuentra la URL de imagen anidada del shape real de APIMART", () => {
  const j = { code: 200, data: { status: "completed", cost: 0.0085,
    result: { images: [{ expires_at: 1, url: ["https://getapib.org/f/image/abc.png"] }] } } };
  assert.deepEqual(extraerUrls(j), ["https://getapib.org/f/image/abc.png"]);
});

test("extraerUrls devuelve las dos pistas de música en orden y sin las carátulas", () => {
  const j = { data: { result: { music: [
    { audio_url: "https://getapib.org/audio/a.mp3", image_url: "https://cdn2.suno.ai/image_a.jpeg" },
    { audio_url: "https://getapib.org/audio/b.mp3", image_url: "https://cdn2.suno.ai/image_b.jpeg" } ] } } };
  assert.deepEqual(extraerUrls(j).filter((u) => u.endsWith(".mp3")),
    ["https://getapib.org/audio/a.mp3", "https://getapib.org/audio/b.mp3"]);
});

test("extraerUrls no repite ni devuelve strings que no son URL", () => {
  const j = { a: "hola", b: ["https://x.org/v.mp4", "https://x.org/v.mp4"] };
  assert.deepEqual(extraerUrls(j), ["https://x.org/v.mp4"]);
});

test("estadoDe mapea los estados de APIMART", () => {
  assert.equal(estadoDe({ data: { status: "completed" } }), "ok");
  assert.equal(estadoDe({ data: { status: "submitted" } }), "pendiente");
  assert.equal(estadoDe({ data: { status: "processing" } }), "pendiente");
  assert.equal(estadoDe({ data: { status: "failed" } }), "fallo");
  assert.equal(estadoDe({ status: "succeeded" }), "ok");
});

test("conReintentos reintenta solo errores de red y respeta el tope", async () => {
  let n = 0;
  const r = await conReintentos(async () => {
    n++;
    if (n < 3) { const e = new Error("fetch failed"); e.code = "ECONNRESET"; throw e; }
    return "ok";
  }, { intentos: 3, base: 1 });
  assert.equal(r, "ok"); assert.equal(n, 3);

  n = 0;
  await assert.rejects(conReintentos(async () => { n++; throw new Error("400 invalid_request"); }, { intentos: 3, base: 1 }));
  assert.equal(n, 1, "un 4xx no se reintenta");

  n = 0;
  await assert.rejects(conReintentos(async () => { n++; const e = new Error("fetch failed"); e.code = "ECONNRESET"; throw e; }, { intentos: 3, base: 1 }));
  assert.equal(n, 3, "se agota el tope");
});
