import { test } from "node:test";
import assert from "node:assert/strict";
import { promptFrame, promptVideo, qcCobertura, briefBorradorT2 } from "../scripts/lib/aroll.mjs";

const G = { slug: "demo", idioma: "es", musica: "pop", personaje: "mujer de 34 años, remera gris", escenario: "living con estantería", encuadre: "plano medio", encadenar: true,
  escenas: [ { n: 1, dialogo: "Estudié anatomía durante meses.", accion: "mira a cámara", final: "sonríe" }, { n: 2, dialogo: "Y en el examen me quedé en blanco.", accion: "gesto de frustración" } ],
  broll: [ { n: 1, prompt: "cuaderno" }, { n: 2, prompt: "examen" } ] };

test("promptFrame repite el retrato forense idéntico y solo cambia la acción", () => {
  const a = promptFrame({ ...G, accion: "mira a cámara" }), b = promptFrame({ ...G, accion: "sonríe" });
  assert.ok(a.includes(G.personaje) && a.includes(G.escenario) && a.includes(G.encuadre));
  assert.equal(a.split(G.personaje)[0], b.split(G.personaje)[0]);
  assert.ok(a.includes("mira a cámara"));
  assert.match(a, /no text|sin texto/i);
});

test("promptVideo lleva el diálogo exacto con el disparador de lip-sync", () => {
  const p = promptVideo({ escena: G.escenas[0], personaje: G.personaje });
  assert.ok(p.includes('mira a cámara y dice: "Estudié anatomía durante meses."'));
  assert.match(p, /exactamente|sin agregar/i);
  assert.match(p, /completa/i);
});

test("qcCobertura aprueba ≥ 80 % y reprueba menos", () => {
  const bien = [{ word: "estudié", start: 0, end: .4 }, { word: "anatomía", start: .4, end: .9 }, { word: "durante", start: 1, end: 1.3 }, { word: "meses", start: 1.3, end: 1.7 }];
  assert.equal(qcCobertura(bien, G.escenas[0].dialogo).ok, true);
  const mal = [{ word: "hola", start: 0, end: .4 }, { word: "meses", start: 1.3, end: 1.7 }];
  const r = qcCobertura(mal, G.escenas[0].dialogo);
  assert.equal(r.ok, false); assert.ok(r.sinCaption.length >= 2);
});

test("briefBorradorT2 arma un brief de plantilla 2 con un inserto por escena", () => {
  const b = briefBorradorT2(G, { clipsDir: "../../public/media/_ugc/demo/clips" });
  assert.equal(b.slug, "demo"); assert.equal(b.idioma, "es"); assert.equal(b.velocidad, 1.18);
  assert.deepEqual(b.escenas.map((e) => e.clip), ["escena1.mp4", "escena2.mp4"]);
  assert.equal(b.escenas[0].dialogo, G.escenas[0].dialogo);
  assert.equal(b.insertos.length, 2);
  assert.equal(b.insertos[0].broll, "broll1.mp4"); assert.equal(b.insertos[0].sobre, "Estudié"); assert.equal(b.insertos[0].escena, 1);
  assert.deepEqual(b.musica, { id: "pop" });
});

test("briefBorradorT2 rota los B-roll cuando hay menos que escenas, y sin B-roll no pone insertos", () => {
  const b = briefBorradorT2({ ...G, broll: [{ n: 1, prompt: "x" }] }, { clipsDir: "c" });
  assert.deepEqual(b.insertos.map((i) => i.broll), ["broll1.mp4", "broll1.mp4"]);
  assert.deepEqual(briefBorradorT2({ ...G, broll: [] }, { clipsDir: "c" }).insertos, []);
});
