import { test } from "node:test";
import assert from "node:assert/strict";
import { tiempoASS, generarASS } from "../scripts/lib/ass-t2.mjs";

const palabras = [
  { texto: "I", start: 0, end: 0.28 },
  { texto: "months...", start: 1.36, end: 1.96 },   // hueco grande antes: silencio real
  { texto: "a", start: 2.1, end: 2.37 },
];

test("formato de tiempo de ASS", () => {
  assert.equal(tiempoASS(0), "0:00:00.00");
  assert.equal(tiempoASS(5.42), "0:00:05.42");
  assert.equal(tiempoASS(75.5), "0:01:15.50");
});

test("las dos líneas Format van completas — si no, libass mete basura en el texto", () => {
  const a = generarASS(palabras);
  const estilos = a.match(/^Format: Name,.*$/m)[0].split(",").length;
  const eventos = a.match(/^Format: Layer,.*$/m)[0].split(",").length;
  assert.equal(estilos, 23);
  assert.equal(eventos, 10);
});

test("cada Dialogue tiene los 9 campos previos al texto", () => {
  const linea = generarASS(palabras).match(/^Dialogue: .*,I$/m)[0];
  assert.equal(linea, "Dialogue: 0,0:00:00.00,0:00:00.43,W,,0,0,0,,I");
});

test("centrado exacto y constantes medidas", () => {
  const a = generarASS(palabras);
  assert.match(a, /PlayResX: 1080/);
  assert.match(a, /PlayResY: 1920/);
  assert.match(a, /^Style: W,Arial,88,.*,1,6,3,5,0,0,0,1$/m);  // BorderStyle 1, Outline 6, Shadow 3, Alignment 5
});

test("una palabra se sostiene hasta la siguiente solo si el hueco es chico", () => {
  const a = generarASS(palabras);
  // "I" termina en 0.28: hueco de 1.08s hasta "months..." -> NO se estira, queda 0.28+hold
  assert.match(a, /0:00:00\.00,0:00:00\.43,W/);
  // "months..." termina en 1.96 y "a" arranca en 2.10: hueco de 0.14s -> se puentea
  assert.match(a, /0:00:01\.36,0:00:02\.10,W/);
});

test("el cuerpo escala con la altura del cuadro", () => {
  assert.match(generarASS(palabras, { ancho: 720, alto: 1280 }), /^Style: W,Arial,59,/m);
});

test("las llaves se escapan (son sintaxis de override en ASS)", () => {
  const a = generarASS([{ texto: "{raro}", start: 0, end: 0.3 }]);
  assert.match(a, /\\\{raro\\\}/);
});

test("las comillas de una cita no se queman en pantalla", () => {
  const a = generarASS([{ texto: "«we", start: 0, end: 0.3 },
                        { texto: "did».", start: 0.5, end: 0.9 }]);
  assert.match(a, /,we$/m);
  assert.match(a, /,did\.$/m);
  assert.doesNotMatch(a, /[«»]/);
});

test("pero el apóstrofo de elisión SÍ se conserva", () => {
  const a = generarASS([{ texto: "teacher's", start: 0, end: 0.4 },
                        { texto: "o’clock", start: 0.6, end: 1.0 }]);
  assert.match(a, /,teacher's$/m);
  assert.match(a, /,o’clock$/m);
});
