import { test } from "node:test";
import assert from "node:assert/strict";
import { PassThrough } from "node:stream";
import { estimar, confirmar, Contador, fmt, PRECIOS } from "../scripts/lib/costo.mjs";

test("estimar suma por tipo y describe cada línea", () => {
  const r = estimar([{ tipo: "aroll", n: 6 }, { tipo: "broll", n: 6 }, { tipo: "imagen", n: 12 }]);
  assert.ok(Math.abs(r.total - (6 * 0.14 + 6 * 0.07 + 12 * 0.0085)) < 1e-9);
  assert.equal(r.lineas.length, 3);
  assert.match(r.lineas[0], /6 .*A-roll.*\$0\.84/);
});

test("estimar rechaza tipos desconocidos", () => {
  assert.throws(() => estimar([{ tipo: "cafe", n: 1 }]), /tipo de costo desconocido/);
});

test("fmt", () => {
  assert.equal(fmt(0.14), "$0.14");
  assert.equal(fmt(0.0085), "$0.0085");
  assert.equal(fmt(1.26), "$1.26");
});

test("confirmar: con si=true no pregunta", async () => {
  assert.equal(await confirmar({ total: 1, lineas: [], si: true, entrada: new PassThrough() }), true);
});

test("confirmar: sin TTY y sin --si devuelve false", async () => {
  const e = new PassThrough(); e.isTTY = false;
  assert.equal(await confirmar({ total: 1, lineas: [], entrada: e }), false);
});

test("confirmar: acepta 's' por stdin", async () => {
  const e = new PassThrough(); e.isTTY = true;
  const p = confirmar({ total: 1, lineas: ["x"], entrada: e });
  e.write("s\n");
  assert.equal(await p, true);
});

test("Contador acumula y resume", () => {
  const c = new Contador(); c.sumar(0.14); c.sumar(0.07);
  assert.ok(Math.abs(c.total - 0.21) < 1e-9);
  assert.match(c.resumen(0.25), /Facturado real: \$0\.21 \(estimado \$0\.25\)/);
});

test("PRECIOS tiene los siete tipos (frame y lite son los de las plantillas 3 y 4)", () => {
  assert.deepEqual(Object.keys(PRECIOS).sort(), ["aroll", "broll", "frame", "imagen", "lite", "musica", "voz"]);
  assert.equal(PRECIOS.frame, PRECIOS.aroll); assert.equal(PRECIOS.lite, PRECIOS.broll);
});
