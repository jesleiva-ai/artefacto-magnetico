import { test } from "node:test";
import assert from "node:assert/strict";
import { construirEDL } from "../scripts/lib/edl-t2.mjs";

const escenas = [
  { clip: "escena1.mp4", ruta: "/c/escena1.mp4", finEscena: 5.9,
    palabras: [{ texto: "I", start: 0, end: 0.28 }, { texto: "months...", start: 1.36, end: 1.96 }] },
  { clip: "escena2.mp4", ruta: "/c/escena2.mp4", finEscena: 5.9,
    palabras: [{ texto: "Knew", start: 0.1, end: 0.6 }, { texto: "months...", start: 2.0, end: 2.4 }] },
];
const base = { escenas, velocidad: 1.18 };

test("la velocidad comprime el timeline", () => {
  const e = construirEDL(base);
  assert.ok(Math.abs(e.duracionFinal - 11.8 / 1.18) < 1e-9);
  assert.ok(Math.abs(e.escenas[1].tIni - 5.9 / 1.18) < 1e-9);
});

test("las palabras de la escena 2 quedan corridas por el offset", () => {
  const e = construirEDL(base);
  const p = e.palabras.find((x) => x.escena === 2 && x.texto === "Knew");
  assert.ok(Math.abs(p.start - (5.9 + 0.1) / 1.18) < 1e-9);
});

test("'sobre' resuelve al arranque de esa palabra en el timeline final", () => {
  const e = construirEDL({ ...base, insertos: [
    { ruta: "/b/broll1.mp4", duracionArchivo: 4, sobre: "Knew", dur: 3.2 }] });
  assert.ok(Math.abs(e.insertos[0].t - (5.9 + 0.1) / 1.18) < 1e-9);
  assert.equal(e.insertos[0].dur, 3.2);
});

test("el desfase corre el inserto, y un negativo antes de 0 se clampa con aviso", () => {
  const corrido = construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "Knew", dur: 3.2, desfase: -0.2 }] });
  assert.ok(Math.abs(corrido.insertos[0].t - ((5.9 + 0.1) / 1.18 - 0.2)) < 1e-9);

  const clampeado = construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "I", dur: 3.2, desfase: -0.5 }] });
  assert.equal(clampeado.insertos[0].t, 0);
  assert.ok(clampeado.avisos.some((a) => a.includes("lo llevo a 0")));
});

test("una palabra repetida avisa y usa la primera; 'escena' la acota", () => {
  const rep = construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "months...", dur: 2 }] });
  assert.ok(rep.avisos.some((a) => a.includes("aparece 2 veces")));
  const aco = construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "months...", escena: 2, dur: 2 }] });
  assert.ok(!aco.avisos.some((a) => a.includes("aparece")));
  assert.ok(aco.insertos[0].t > 5);
});

test("una palabra inexistente es un error, no un aviso", () => {
  assert.throws(() => construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "inexistente", dur: 2 }] }), /no está en el diálogo/);
});

test("dur mayor que el clip de inserto aborta", () => {
  assert.throws(() => construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "I", dur: 5 }] }), /supera la duración/);
});

test("una imagen no tiene ese límite", () => {
  const e = construirEDL({ ...base, insertos: [
    { ruta: "/b/m.png", esImagen: true, sobre: "I", dur: 5 }] });
  assert.equal(e.insertos[0].dur, 5);
});

test("insertos solapados: avisa y recorta el primero", () => {
  const e = construirEDL({ ...base, insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 4, en: 1.0, dur: 3.0 },
    { ruta: "/b/b.mp4", duracionArchivo: 4, en: 2.0, dur: 2.0 }] });
  assert.ok(e.avisos.some((a) => a.includes("se solapan")));
  assert.ok(Math.abs(e.insertos[0].dur - 1.0) < 1e-9);
});

test("un inserto que se pasa del final se recorta a duracionFinal, con aviso", () => {
  const e = construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, en: 9.0, dur: 3.0 }] });
  assert.ok(Math.abs(e.insertos[0].dur - 1.0) < 1e-9);
  assert.ok(e.avisos.some((a) => a.includes("se pasaba del final")));
});

test("un inserto sin margen antes del final se descarta, con aviso", () => {
  const e = construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, en: 10.5, dur: 2.0 }] });
  assert.equal(e.insertos.length, 0);
  assert.ok(e.avisos.some((a) => a.includes("descartado")));
});

test("avisa la tirada de cara demasiado larga", () => {
  const e = construirEDL({ ...base, maxCaraSinInserto: 4.8 });
  assert.ok(e.avisos.some((a) => a.includes("Cara sin inserto")));
});

test("'sobre' y 'en' juntos es un error", () => {
  assert.throws(() => construirEDL({ ...base, insertos: [
    { ruta: "/b/b.mp4", duracionArchivo: 4, sobre: "I", en: 2, dur: 1 }] }), /excluyentes/);
});

test("solo-broll: aborta si los visuales dejan un hueco, y dice cuál", () => {
  assert.throws(() => construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 5, en: 0, dur: 4 }] }),
    /no tapan la línea de tiempo entera[\s\S]*4\.00-10\.00s/);
});

test("solo-broll: con la línea de tiempo tapada, pasa", () => {
  const e = construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 5, en: 0, dur: 5 },
    { ruta: "/b/b.mp4", duracionArchivo: 5, en: 5, dur: 5 }] });
  assert.equal(e.insertos.length, 2);
  assert.ok(!e.avisos.some((a) => a.includes("Cara sin inserto")));
});

test("solo-broll: un visual puede durar más que su clip (se loopea)", () => {
  const e = construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 4, en: 0, dur: 10 }] });
  assert.equal(e.insertos[0].dur, 10);
});

test("en modo normal ese mismo caso sigue abortando", () => {
  assert.throws(() => construirEDL({ ...base, insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 4, en: 0, dur: 10 }] }), /supera la duración/);
});

test("solo-broll: sin `dur`, cada visual se estira hasta el siguiente y el último hasta el final", () => {
  const e = construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 4, en: 0 },
    { ruta: "/b/b.mp4", duracionArchivo: 4, en: 3 },
    { ruta: "/b/c.mp4", duracionArchivo: 4, en: 7 }] });
  assert.deepEqual(e.insertos.map((i) => +i.dur.toFixed(2)), [3, 4, 3]);   // duracionFinal = 10
  assert.equal(e.avisos.length, 0);   // sin huecos y sin solapes: nada que avisar
});

test("solo-broll: se puede mezclar dur explícito con automático", () => {
  const e = construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 4, en: 0, dur: 2 },
    { ruta: "/b/b.mp4", duracionArchivo: 4, en: 2 }] });
  assert.deepEqual(e.insertos.map((i) => +i.dur.toFixed(2)), [2, 8]);
});

test("en modo normal `dur` sigue siendo obligatorio", () => {
  assert.throws(() => construirEDL({ ...base, insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 4, en: 0 }] }), /"dur" tiene que ser > 0/);
});

test("solo-broll: avisa la imagen demasiado corta para leerse", () => {
  const e = construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/m/p.png", esImagen: true, en: 0 },
    { ruta: "/m/q.png", esImagen: true, en: 1 },      // la primera queda en 1s
    { ruta: "/b/a.mp4", duracionArchivo: 9, en: 2 }] });
  assert.ok(e.avisos.some((a) => /Imagen en 0\.00s dura 1\.00s/.test(a) && /no es prueba/.test(a)));
});

test("solo-broll: el b-roll tiene un piso más bajo, 1s no lo dispara", () => {
  const e = construirEDL({ ...base, modo: "solo-broll", insertos: [
    { ruta: "/b/a.mp4", duracionArchivo: 9, en: 0 },
    { ruta: "/b/b.mp4", duracionArchivo: 9, en: 1 }] });
  assert.ok(!e.avisos.some((a) => a.includes("destello")));
});

test("en modo normal una imagen de 1s NO se avisa: es el beat del piloto", () => {
  const e = construirEDL({ ...base, insertos: [
    { ruta: "/m/p.png", esImagen: true, en: 0, dur: 1 }] });
  assert.ok(!e.avisos.some((a) => a.includes("no es prueba")));
});
