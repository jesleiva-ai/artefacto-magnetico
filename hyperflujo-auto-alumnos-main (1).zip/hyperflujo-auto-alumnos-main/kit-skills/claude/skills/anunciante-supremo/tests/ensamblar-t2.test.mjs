import { test } from "node:test";
import assert from "node:assert/strict";
import { escaparFiltro, construirFiltro, construirArgs } from "../scripts/ensamblar-t2.mjs";

const edl = {
  duracionFinal: 10,
  escenas: [
    { clip: "escena1.mp4", ruta: "C:\\clips\\escena1.mp4", fin: 5.9 },
    { clip: "escena2.mp4", ruta: "C:\\clips\\escena2.mp4", fin: 5.9 },
  ],
  insertos: [{ ruta: "C:\\clips\\broll1.mp4", esImagen: false, t: 1.5, dur: 3.2 }],
  palabras: [],
};
const opts = { ancho: 1080, alto: 1920, fps: 30, velocidad: 1.18,
  assPath: "C:\\w\\subs.ass", fontsDir: "C:\\w\\fonts",
  musica: { ruta: "C:\\m\\lady.mp3", desde: 0, db: -20 } };

test("las rutas de Windows se escapan para el filter_complex", () => {
  assert.equal(escaparFiltro("C:\\w\\subs.ass"), "C\\\\:/w/subs.ass");
});

test("el grafo recorta, concatena, acelera y escala", () => {
  const f = construirFiltro(edl, opts);
  assert.match(f, /\[0:v\]trim=end=5\.900/);
  assert.match(f, /concat=n=2:v=1:a=1\[cv\]\[ca\]/);
  assert.match(f, /\[cv\]setpts=PTS\/1\.18\[sv\]/);
  assert.match(f, /\[ca\]atempo=1\.18\[sa\]/);
  assert.match(f, /scale=1080:1920:flags=lanczos,fps=30\[bg0\]/);
});

test("el inserto se desplaza a su tiempo y se habilita en su ventana", () => {
  const f = construirFiltro(edl, opts);
  assert.match(f, /setpts=PTS-STARTPTS\+1\.500\/TB\[ins0\]/);
  assert.match(f, /overlay=enable='between\(t,1\.500,4\.700\)'\[bg1\]/);
});

test("el b-roll llena el cuadro, sin deformarse", () => {
  // Un scale=W:H a secas aplasta todo lo que no sea 9:16 nativo.
  const f = construirFiltro(edl, opts);
  assert.match(f, /\[2:v\]trim=duration=3\.200,scale=1080:1920:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos,pad=1080:1920:\(ow-iw\)\/2:\(oh-ih\)\/2,fps=30/);
  // El b-roll es un cambio de plano: va pegado al origen, sin x/y.
  assert.match(f, /\[bg0\]\[ins0\]overlay=enable=/);
  // El lienzo de fondo sí escala a la fuerza: la voz manda y los A-roll ya son 9:16.
  assert.match(f, /\[sv\]scale=1080:1920:flags=lanczos,fps=30\[bg0\]/);
});

test("la imagen entra centrada ENCIMA del A-roll, sin pad ni barras", () => {
  // Un mockup no es un cambio de plano: se pone encima del personaje, que se sigue viendo
  // alrededor (así entra en el tramo de los bonus del anuncio de referencia). Caja del 80 % del cuadro.
  const e = { ...edl, insertos: [{ ruta: "C:\m\kit.png", esImagen: true, t: 2, dur: 1.5 }] };
  const f = construirFiltro(e, opts);
  assert.match(f, /\[2:v\]trim=duration=1\.500,scale=864:1536:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos,fps=30/);
  assert.match(f, /overlay=x=\(W-w\)\/2:y=\(H-h\)\/2:enable='between\(t,2\.000,3\.500\)'\[bg1\]/);
  assert.doesNotMatch(f, /pad=/);   // nada de barras negras: el A-roll queda a la vista
});

test("los subtítulos van encima de todos los insertos", () => {
  assert.match(construirFiltro(edl, opts), /\[bg1\]ass=f=C\\\\:\/w\/subs\.ass:fontsdir=C\\\\:\/w\/fonts\[vout\]/);
});

test("amix lleva normalize=0 — sin eso la voz baja 6 dB", () => {
  assert.match(construirFiltro(edl, opts), /amix=inputs=2:duration=first:normalize=0\[aout\]/);
});

test("el argv sale en el perfil que Meta acepta, sin pasada correctiva", () => {
  const a = construirArgs(edl, { ...opts, salida: "out/x.mp4" }).join(" ");
  assert.match(a, /-r 30/);
  assert.match(a, /-fps_mode cfr/);
  assert.match(a, /-crf 21/);
  assert.match(a, /-movflags \+faststart/);
  assert.doesNotMatch(a, /-vsync/);   // no existe en ffmpeg 9
});

test("una imagen de inserto entra con -loop 1 -t dur", () => {
  const e = { ...edl, insertos: [{ ruta: "C:\\m\\kit.png", esImagen: true, t: 2, dur: 1.5 }] };
  const a = construirArgs(e, { ...opts, salida: "out/x.mp4" });
  const i = a.indexOf("C:\\m\\kit.png");
  assert.deepEqual(a.slice(i - 5, i), ["-loop", "1", "-t", "1.5", "-i"]);
});

test("solo-broll: el A-roll aporta SOLO audio y el lienzo es negro", () => {
  const e = { ...edl, insertos: [{ ruta: "C:\b\b1.mp4", esImagen: false, t: 0, dur: 10 }] };
  const f = construirFiltro(e, { ...opts, modo: "solo-broll" });
  assert.match(f, /concat=n=2:v=0:a=1\[ca\]/);
  assert.match(f, /color=c=black:s=1080x1920:r=30:d=10\.000\[bg0\]/);
  assert.doesNotMatch(f, /\[cv\]/);            // no se decodifica el video del A-roll
  assert.match(f, /\[ca\]atempo=1\.18\[sa\]/); // el audio sigue igual que en modo normal
});

test("solo-broll: una imagen llena el cuadro con telón desenfocado, sin barras negras", () => {
  const e = { ...edl, insertos: [{ ruta: "C:\m\pagina.png", esImagen: true, t: 0, dur: 10 }] };
  const f = construirFiltro(e, { ...opts, modo: "solo-broll" });
  // el mismo visual dos veces: telón que LLENA y se desenfoca, figura intacta encima
  assert.match(f, /split=2\[tel0\]\[fig0\]/);
  assert.match(f, /force_original_aspect_ratio=increase[^;]*crop=1080:1920,gblur/);
  assert.match(f, /\[fig0\]scale=1080:1920:force_original_aspect_ratio=decrease/);
  assert.doesNotMatch(f, /pad=1080:1920/);     // nunca barras negras en este modo
});

test("solo-broll: un visual más largo que su clip se loopea en el argv", () => {
  const e = { ...edl, insertos: [{ ruta: "C:\b\b1.mp4", esImagen: false, duracionArchivo: 4.9, t: 0, dur: 10 }] };
  const a = construirArgs(e, { ...opts, modo: "solo-broll", salida: "out/x.mp4" });
  const i = a.indexOf("C:\b\b1.mp4");
  // el -i va pegado a la ruta, entre la opcion y el archivo: ceil(10/4.9) = 3
  assert.deepEqual(a.slice(i - 3, i), ["-stream_loop", "3", "-i"]);
});

test("en modo normal no se loopea nada", () => {
  const a = construirArgs(edl, { ...opts, salida: "out/x.mp4" });
  assert.doesNotMatch(a.join(" "), /-stream_loop/);
});
