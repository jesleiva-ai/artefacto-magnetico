import { test } from "node:test";
import assert from "node:assert/strict";
import { rellenarHuecos, ajustarPlanos, duracionesDeBeats, detectarLetterbox, configDeEstilo, promptImagen, promptVideo, planBorrador } from "../scripts/lib/montar-lib.mjs";

test("rellenarHuecos: ninguna palabra del guion queda sin caption — el número escrito con letras se interpola", () => {
  const tokens = "Son diecinueve euros, garantía total.".split(" ");
  const casadas = [
    { texto: "Son", start: 0.1, end: 0.3 },
    { texto: "euros,", start: 1.0, end: 1.3 },
    { texto: "garantía", start: 1.4, end: 1.9 },
    { texto: "total.", start: 2.0, end: 2.4 },
  ];
  const r = rellenarHuecos(tokens, casadas);
  assert.equal(r.length, tokens.length);
  assert.equal(r[1].texto, "diecinueve");
  assert.ok(r[1].start >= 0.3 && r[1].end <= 1.0);
});

test("rellenarHuecos: huecos al principio y al final también se rellenan", () => {
  const r = rellenarHuecos(["Hola", "mundo", "cruel"], [{ texto: "mundo", start: 1, end: 1.5 }]);
  assert.equal(r.length, 3);
  assert.ok(r[0].end <= 1);
  assert.ok(r[2].start >= 1.5);
});

test("ajustarPlanos: sin duraciones, reparte parejo y cierra exacto con la voz", () => {
  const r = ajustarPlanos([["t01"], ["b01"]], 4.0);
  assert.deepEqual(r.map(([id]) => id), ["t01", "b01"]);
  assert.ok(Math.abs(r.reduce((s, [, d]) => s + d, 0) - 4.0) < 1e-9);
});

test("ajustarPlanos: con duraciones explícitas, se escalan en proporción a la voz real", () => {
  const r = ajustarPlanos([["t01", 3], ["b01", 1]], 2.0);
  assert.ok(Math.abs(r[0][1] - 1.5) < 1e-9 && Math.abs(r[1][1] - 0.5) < 1e-9);
});

test("ajustarPlanos: mixto — los fijos se respetan y los libres se reparten el resto", () => {
  const r = ajustarPlanos([["t01", 1.0], ["b01"], ["t01"]], 3.0);
  assert.equal(r[0][1], 1.0);
  assert.ok(Math.abs(r[1][1] - 1.0) < 1e-9 && Math.abs(r[2][1] - 1.0) < 1e-9);
});

test("ajustarPlanos: nunca más de maxPlano seguidos del mismo plano — se cicla toma/b-roll", () => {
  const r = ajustarPlanos([["t01"], ["b01"]], 9.0, { maxPlano: 3 });
  assert.equal(r.length, 3);
  assert.deepEqual(r.map(([id]) => id), ["t01", "b01", "t01"]);
  assert.ok(r.every(([, d]) => d <= 3.0 + 1e-9));
  const solo = ajustarPlanos([["t01"]], 7.0, { maxPlano: 3 });
  assert.equal(solo.length, 3);
});

test("ajustarPlanos: aborta si los fijos no dejan lugar a los libres", () => {
  assert.throws(() => ajustarPlanos([["t01", 5], ["b01"]], 4.0), /no dejan lugar/);
});

test("duracionesDeBeats: respiro entre líneas, cola en la última", () => {
  assert.deepEqual(duracionesDeBeats([2, 3], { gap: 0.2, cola: 0.6 }), [2.2, 3.6]);
});

test("detectarLetterbox: barra negra de 100/1280 arriba y abajo se detecta; sin barra, no", () => {
  const w = 72, h = 128, banda = 10;
  const con = new Uint8Array(w * h).fill(120);
  for (let y = 0; y < h; y++) if (y < banda || y >= h - banda) for (let x = 0; x < w; x++) con[y * w + x] = 8;
  assert.equal(detectarLetterbox(con, w, h).hay, true);
  const sin = new Uint8Array(w * h).fill(120);
  assert.equal(detectarLetterbox(sin, w, h).hay, false);
  // una escena oscura pareja tampoco es letterbox
  const oscura = new Uint8Array(w * h).fill(15);
  assert.equal(detectarLetterbox(oscura, w, h).hay, false);
});

test("configDeEstilo: cada estilo trae sus valores medidos", () => {
  assert.equal(configDeEstilo("claymation").speed, 1.15);
  assert.equal(configDeEstilo("zack").volMusica, 0.141);
  assert.match(configDeEstilo("zack").musicaFija, /zack-d-films\.mp3$/);
  assert.throws(() => configDeEstilo("anime"), /desconocido/);
});

test("prompts: las coletillas fijas van tal cual y se limpian las flags de Midjourney", () => {
  const t = { id: "t01", imagen: "a clay character in a kitchen --ar 9:16 --v 6", video: "slow push-in --ar 9:16" };
  assert.match(promptImagen(t, "claymation"), /^a clay character in a kitchen\. handmade stop-motion/);
  assert.doesNotMatch(promptImagen(t, "claymation"), /--ar/);
  assert.match(promptVideo(t, "claymation"), /Ensure handmade stop-motion clay animation throughout the video\. Non CGI\./);
  assert.match(promptVideo({ ...t, fin: "x" }, "zack"), /camera locked off/);
  assert.match(promptImagen({ ...t, mecanismo: true }, "zack"), /Semi-3D soft plastic-like/);
  assert.match(promptImagen(t, "zack"), /Pixar-Disney tradition/);
});

test("planBorrador: un beat por línea con su toma y su b-roll, y la voz numerada", () => {
  const g = { slug: "x", estilo: "zack", idioma: "es", lineas: [{ texto: "Hola.", toma: "t01", broll: "b01" }, { texto: "Chau.", toma: "t02" }] };
  const p = planBorrador(g, { clips: "c", voz: "v" });
  assert.equal(p.beats.length, 2);
  assert.deepEqual(p.beats[0].planos, [["t01"], ["b01"]]);
  assert.equal(p.beats[1].voz, "l02.mp3");
  assert.equal(p.musica, undefined);
});
