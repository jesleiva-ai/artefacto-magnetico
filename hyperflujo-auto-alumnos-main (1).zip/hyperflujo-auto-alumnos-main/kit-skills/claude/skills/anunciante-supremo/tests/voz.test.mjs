import { test } from "node:test";
import assert from "node:assert/strict";
import { palabrasDesdeAlineacion, palabrasDesdeWhisper, proveedorDeVoz } from "../scripts/lib/voz.mjs";

test("palabrasDesdeAlineacion agrupa caracteres en palabras con start/end", () => {
  const al = { characters: ["H", "o", "l", "a", " ", "y", "a"],
    character_start_times_seconds: [0, .1, .2, .3, .4, .5, .6],
    character_end_times_seconds: [.1, .2, .3, .4, .5, .6, .7] };
  assert.deepEqual(palabrasDesdeAlineacion(al), [{ text: "Hola", start: 0, end: .4 }, { text: "ya", start: .5, end: .7 }]);
});

test("palabrasDesdeWhisper devuelve el texto del guion con los tiempos de whisper", () => {
  const w = [{ word: "cada", start: 0, end: .3 }, { word: "año", start: .3, end: .6 }, { word: "miles", start: .7, end: 1 }];
  const r = palabrasDesdeWhisper(w, "Cada año, miles.");
  assert.deepEqual(r.words.map((x) => x.text), ["Cada", "año,", "miles."]);
  assert.equal(r.words[1].start, .3);
  assert.equal(r.cobertura, 1);
});

test("palabrasDesdeWhisper aborta si la cobertura es muy baja", () => {
  const w = [{ word: "otra", start: 0, end: .3 }, { word: "cosa", start: .3, end: .6 }];
  assert.throws(() => palabrasDesdeWhisper(w, "Cada año miles de personas"), /cobertura/);
});

test("proveedorDeVoz: ElevenLabs solo si hay llave Y voiceId", () => {
  const b = { voz: { elevenlabs: { voiceId: "abc" }, apimart: { voice: "nova" } } };
  assert.equal(proveedorDeVoz(b, { ELEVENLABS_API_KEY: "k" }), "elevenlabs");
  assert.equal(proveedorDeVoz(b, {}), "apimart");
  assert.equal(proveedorDeVoz({ voz: { elevenlabs: { voiceId: "" } } }, { ELEVENLABS_API_KEY: "k" }), "apimart");
  assert.equal(proveedorDeVoz({}, {}), "apimart");
});
