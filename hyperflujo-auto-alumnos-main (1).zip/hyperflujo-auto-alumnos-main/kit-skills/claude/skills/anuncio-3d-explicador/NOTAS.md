# Notas — ejemplo 3 · 3D explicador · «Huerta en el Balcón»

## Resultado
- `anuncio.mp4`: 1080×1920, 30 fps CFR, h264 High + AAC, 40,9 s, −16,1 LUFS, 9 líneas de voz, 19 planos.
- Voz ElevenLabs (una voz en español de la biblioteca), captions palabra por palabra con cobertura 100 % en las 9 líneas.
- Música fija del estilo (zack-d-films.mp3), velocidad 1,12x.
- Campaña en el motor: `anunciante-supremo/input/ej-zack-huerta/` (guion.json, ad-01.json; el mockup.png se genera);
  clips/frames/voces en `public/media/_clips/ej-zack-huerta/` (~100 MB al generarlos, reusables para variantes).

## Costo real (APIMART)
| Concepto | $ |
|---|---|
| Mockup de la guía (gpt-image-2) | 0,008 |
| START del Cap. 3 + 3 END editados (gpt-image-2 con image_urls) | 0,032 |
| Lote abortado del Cap. 3 (2 imágenes + video t04 ya enviado, probablemente cobrado) | ~0,16 |
| gen:clips tomas t01-t03, t07-t09 | 0,43 |
| gen:clips B-roll b01-b06 | 0,45 |
| gen:clips modo frame t04-t06 | 0,40 |
| **Total APIMART** | **≈ 1,48** |
Voz: ElevenLabs (cuenta aparte, no APIMART; ~$0,10 estimado). El total sale de sumar los `Facturado real`, no del saldo.

## Regeneraciones y decisiones
1. **Cap. 3 rehecho antes de gastar en video**: el primer par START/END de t04 salió como infografía en inglés
   ("Loosely Packed Soil", flechas, carteles) y con el END distinto del START (otra planta, otro corte). Se abortó
   el lote y se cambió el método: START generado una vez con "A still frame from a 3D animated short film, not a
   diagram…" + "Pure visual scene: absolutely no words…", y cada END como **edición del START** (image_urls).
   Cadena: t04 = start→raíces que respiran · t05 = start→poros llenos de agua · t06 = (END de t05)→raíces podridas.
   Resultado: los tres clips se leen como una sola animación continua. Los frames se sembraron en `frames/` con su
   .json (url + expira) para que gen:clips los reuse.
2. **Producto**: el mockup se sembró como frame de t03/t09 (texto perfecto). Veo deforma la pantalla después de
   ~5 s (t03 termina en texto inventado; t09 dejó el lector digital EN BLANCO). t03 se usa solo en sus primeros ~2 s
   (limpio); para el CTA se reemplazó t09 por `tz.mp4`, un zoom lento hecho con ffmpeg sobre el mockup (gratis,
   texto exacto). t09 quedó sin usar ($0,07 perdidos).
3. **Compliance**: línea 8 cambiada de «tienes albahaca, tomates y lechugas» a «puedes tener…» (evita resultado
   implícito garantizado); se regeneró solo esa voz.
4. Infra: si `ffprobe` no corre (enlace roto o instalación a medias), montar y gen-clips fallan. Instálalo con ffmpeg
   antes de empezar.

## QA automático (resolución, idioma de la voz, loudness, OCR)
- 🟢 0 rojos. Voz detectada es, LUFS −16,1. Hoja revisada a ojo (`hoja.jpg`): sin manos raras, sin texto
  inventado, sin logos ajenos, producto = mockup, gancho visual (albahaca marchita sobre plato rebalsado) y verbal
  («¿Por qué se muere tu planta…») desde el cuadro 0. La OCR leyó «culthar» en un cuadro del t03 en movimiento:
  es borrosidad de movimiento de un cuadro, no texto inventado visible.
- Personaje: mujer latina adulta, acorde al mercado del anuncio.

## Compliance (compliance-checker, Meta, producto digital, anuncio front-end)
| # | Categoría | Estado | Nota |
|---|---|---|---|
| 1 | Atributos personales | PASS | habla de la planta, no de la persona |
| 2 | Lenguaje negativo/sensacional | WARN (LOW) | «se asfixian y se pudren», «murió ahogada»: refiere a raíces/plantas, es el mecanismo; se mantiene |
| 3 | Salud/medicina | N/A | |
| 4 | Ingresos | N/A | |
| 5 | Antes/después | PASS | no hay comparación lado a lado de personas |
| 6 | Loops / clickbait | PASS | la pregunta del gancho se responde en el mismo video; nombre del producto visible |
| 7 | Palabras gatillo | PASS | sin precio, sin «garantizado», sin urgencia |
| 8-9 | Landing / consistencia | N/A | producto inventado, sin landing |
Issues: 1 LOW (lenguaje de plantas muriendo, aceptado) · 1 MEDIUM corregido (resultado implícito en línea 8).
**Puntaje: 9,5/10 — listo para correr.**

## Lo que no quedó perfecto
- t07 (maceta con drenaje) muestra un agujero de drenaje en el costado de la maceta, no en la base: se entiende
  pero no es técnicamente ideal.
- B-roll repetidos: b04 entra en los beats 4 y 5, b03 en los beats 3 y 7.
- Zoom del CTA (tz) es un movimiento 2D sobre imagen fija, se nota menos «animado» que el resto.
- Las captions son las del motor (blancas al centro, 88 px): legibles, pero no hay título-gancho en caja arriba
  (la plantilla 4 no lo trae).
