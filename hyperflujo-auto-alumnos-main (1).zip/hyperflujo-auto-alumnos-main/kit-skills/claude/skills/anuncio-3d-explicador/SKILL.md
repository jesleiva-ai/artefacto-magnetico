---
name: anuncio-3d-explicador
description: Arma un anuncio vertical 9:16 de 30-45 s en animación 3D estilo película animada que EXPLICA UN MECANISMO en 4 capítulos (situación → producto → lo que pasa adentro, en modo frame → resultado), con voz en off, captions quemadas y la música fija del estilo, usando el motor de la skill anunciante-supremo (plantilla 4) y la llave de APIMART. Úsala cuando el usuario diga "anuncio 3D explicador", "anuncio animado que explique cómo funciona", "explicador 3D de mi producto", "anuncio tipo animación 3D viral que explica algo", "mostrar lo que pasa por dentro", "hazme el anuncio de plantilla 4", o cuando el producto se venda mejor mostrando un proceso invisible (dentro del cuerpo, de la tierra, de una máquina, de la cabeza).
---

# Anuncio 3D explicador

Es el formato de los explicadores 3D virales: una animación de aspecto «película animada» que
muestra **por dentro** algo que el espectador no puede ver, con una voz que lo cuenta como un
misterio que se resuelve. Funciona porque la cabeza no puede dejar una pregunta rara sin
respuesta y porque ver el mecanismo con los propios ojos convence más que cualquier promesa.

Esta skill **no tiene motor propio**: usa el de `anunciante-supremo` (plantilla 4, `"estilo": "zack"`
en el guion). Todo lo que sigue es el método para que salga bien a la primera.

## Requisitos
- La skill `anunciante-supremo` instalada y con el onboarding hecho (`node scripts/doctor.mjs` en verde).
- `APIMART_API_KEY` configurada (en el `.env` de anunciante-supremo o como variable de entorno).
- Opcional: `ELEVENLABS_API_KEY` + un `voiceId` en español: la voz sale bastante más natural.
- `ffmpeg` y `ffprobe` en el PATH (el montador y el control final los usan).
- Saldo en APIMART de al menos **$2,50** (ver «Costo»).

Todos los comandos se corren **dentro de la carpeta de anunciante-supremo**.

## Cuándo conviene (y cuándo no)
Conviene si el producto resuelve un problema cuya **causa real es invisible o malentendida**:
- algo que pasa dentro del cuerpo, de la tierra, de una máquina, de un circuito, de la memoria;
- un error común que el público comete creyendo que hace bien (regar de más, estirar en frío,
  estudiar releyendo);
- un proceso que se entiende mejor con un corte transversal o una lupa.

No conviene si el producto no tiene un mecanismo que se pueda dibujar (una plantilla de Canva, un
pack de stickers): ahí rinde más un anuncio de B-roll o un UGC. Si dudas, intenta escribir el
Capítulo 3 en dos frases; si no puedes, cambia de formato.

## Cómo elegir el mecanismo (la materia prima del anuncio)
El Capítulo 3 es el anuncio. Elige el mecanismo con estas cuatro pruebas:
1. **Es verdadero.** Se puede verificar en una fuente seria. Nada de pseudociencia, nada de "toxinas"
   inventadas, nada de efectos que el producto no causa. Si tienes que exagerarlo, es otro mecanismo.
2. **Es contraintuitivo.** Da vuelta lo que la persona cree ("no muere de sed: muere ahogada").
3. **Se dibuja en 2-3 estados.** Un antes y un después claros: poros con aire → poros con agua →
   raíz podrida. Si no tiene estados visibles, no sirve para modo frame.
4. **El producto responde a ESE mecanismo**, no a uno genérico. La guía, el curso o la plantilla
   tiene que enseñar exactamente cómo evitarlo o aprovecharlo.

## Los cuatro capítulos
| Cap. | Qué se ve | Qué dice la voz | Tomas |
|---|---|---|---|
| 1 · Situación | el problema en un lugar concreto (balcón, cocina, oficina), con un personaje o el objeto afectado | el gancho: una pregunta rara que abre un misterio + el síntoma que la persona reconoce | 2 tomas + 2 B-roll |
| 2 · Producto | el producto digital en un lector digital/celular, en el mismo ambiente | "X te muestra lo que pasa adentro de…" (una línea, sin precio) | 1 toma (mockup) + 1 B-roll |
| 3 · Mecanismo | corte o macro del interior, fondo uniforme, **modo frame** (cambio de estado) | el mecanismo en 2-3 pasos + la frase-revelación | 3 tomas en modo frame + 2 B-roll |
| 4 · Payoff | el mismo personaje/lugar, ahora resuelto; cierre con el producto | qué cambia + CTA "Toca el botón y descárgalo hoy" | 2 tomas + 1 B-roll |

Si una línea no encaja en un capítulo, sobra. Tras el Cap. 3 puede ir una línea de "qué enseña el
producto" (2-3 entregables concretos) antes del payoff.

## El guion
- **Gancho** (línea 1, 8-12 palabras): pregunta rara + sujeto + lo que está en juego.
  Ej.: "¿Por qué se muere tu planta si la riegas todos los días?". La primera imagen muestra
  exactamente eso (gancho visual y verbal en el primer segundo).
- **Frases 2-3**: confirman la promesa con un síntoma reconocible y presentan el producto.
- **Capítulo 3**: tres líneas cortas, una por estado. La última es la revelación en una frase.
- **Largo**: mínimo 30 s. Escribe `segundos × 2,4` palabras (≈ 110-125 palabras para 35-40 s).
  La duración real la manda el mp3 de la voz, no la cuenta.
- **Números como cifra** (`3`, no "tres"): las captions salen alineadas.
- **Español neutro con "tú"**, frases que se puedan decir de un tirón.
- **CTA**: siempre al botón del anuncio. Sin precio, sin "últimas horas", sin "garantizado".

Va todo en `input/<campaña>/guion.json` (esquema completo en `plantillas/plantilla-3.md` de
anunciante-supremo). Lo propio de este estilo: `"estilo": "zack"`, sin campo `musica` (la pista es
fija del estilo) y `"mecanismo": true` + `"fin"` en las tomas del Cap. 3.

## Prompts 3D (lo que va en `tomas[].imagen`)
El motor agrega solo la coletilla del estilo (look de película animada, vertical 9:16). Tú escribes
la escena:
- **Cap. 1 y 4**: `[personaje con rasgos fijos: edad, pelo, ropa de un color] [acción quieta] in
  [lugar concreto], warm cinematic lighting, [plano y ángulo]`. Repite la descripción del personaje
  **palabra por palabra** en todas sus tomas: es lo único que lo mantiene igual.
- **Cap. 2**: no lo generes con texto inventado. Primero crea el **mockup** del producto con
  `gpt-image-2` (ver paso 2) y úsalo como imagen de la toma.
- **Cap. 3** (`"mecanismo": true`): empieza el prompt con **"A still frame from a 3D animated short
  film, not a diagram and not an infographic:"** y termina con **"Pure visual scene: absolutely no
  words, letters, numbers, labels, arrows, callouts, legends, panels or icons anywhere."** Sin eso,
  palabras como *cross-section*, *showing* o *different sizes* hacen que el generador dibuje una
  infografía en inglés con flechas y carteles. Elige UN fondo para todo el Cap. 3:
  - grid azul: `bright blue grid floor and background in vivid cyan-blue tones (#00BFFF to #87CEEB
    range), made of thin light cyan grid lines, extending evenly with consistent bright saturation,
    no darkening toward the edges`;
  - o estudio limpio (blanco, gris claro o crema).
  El sujeto apoyado ("resting naturally ... soft contact shadow"), cámara frontal a media altura.
- **B-roll**: `Stylized 3D macro visualization of [proceso], [pequeños personajes-partícula con
  caritas expresivas], warm golden-orange light, premium documentary visualization style`. Un
  B-roll por línea, sobre la palabra que ilustra.
- **Video** (`tomas[].video`): un solo `Camera:` y un solo `Motion:`. En el Cap. 3: `Camera locked
  off. Motion: [solo el cambio de estado]`.

### Modo frame del Cap. 3: el truco que lo hace funcionar
El par START/END es lo más frágil del estilo: si el END cambia de ángulo, de fondo o de forma, el
video inventa una transición rara. **No generes el END desde cero.** Hazlo así:
1. Genera el **START** una sola vez y míralo.
2. Genera cada **END como edición del START**: misma llamada a `gpt-image-2` pero pasando la URL del
   START en `image_urls` y un prompt del tipo *"Edit this exact image. Keep absolutely everything
   identical: same camera angle, same framing, same [objeto], same background, same lighting and
   palette. Only change this: [el nuevo estado]"*.
3. **Encadena los estados**: el END de una toma es el START de la siguiente (aire → agua → raíz
   podrida). Así los tres clips se ven como una sola animación continua.
4. Deja cada imagen en `public/media/_clips/<slug>/frames/` como `<id>.png` (START) y
   `<id>-fin.png` (END), cada una con su `<id>.json` / `<id>-fin.json` al lado:
   `{"url": "<url de la imagen en APIMART>", "ruta": "<ruta del png>", "expira": <expires_at>}`.
   `gen:clips` reusa los frames que encuentra con URL vigente (vencen a las ~24 h) y solo genera el video.
El mismo truco sirve para la toma del producto: deja el mockup como `frames/<id>.png` + `.json`.

## Paso a paso
1. **Guion y paquete** — escribe `input/<campaña>/guion.json` (9 líneas ≈ 9 tomas + 6 B-roll).
   Muéstrale al usuario el ángulo, la tabla línea → toma → B-roll y el costo estimado; con su OK, sigue.
2. **Mockup del producto** — una imagen `gpt-image-2` 9:16 por APIMART (`POST /v1/images/generations`,
   `"model": "gpt-image-2"`): la portada del producto en un lector digital y un celular, en el ambiente del
   anuncio, **sin manos**, con el título entre comillas y "Spelling must be exact". Revisa letra
   por letra; si sale mal escrito, regenera.
3. **Frames del Cap. 3** — START + END editados y encadenados (sección anterior). Míralos todos juntos
   en una tira antes de gastar en video.
4. **Clips** — `npm run gen:clips -- input/<campaña>/guion.json --si`. Tarda 2-4 min por clip; se
   pueden correr 2-3 procesos a la vez con `--solo` y listas de ids **que no se pisen**.
5. **Mira los clips** (3-4 cuadros por clip en una tira). Lo que falle: borra
   `public/media/_clips/<slug>/frames/<id>*` y corre `--solo <id> --regenerar` (sin borrar el frame,
   `--regenerar` reusa la misma imagen y repite el error).
6. **Voz** — `npm run gen:voz -- input/<campaña>/guion.json --si` → una pista por línea + `ad-01.json`.
7. **Plan** — revisa `input/<campaña>/ad-01.json`: cada beat con `[toma]` y `[B-roll]`. El CTA puede
   cerrar solo con la toma del producto.
8. **Montaje** — `npm run montar -- input/<campaña>/ad-01.json --salida out/<campaña>/<slug>-ad1.mp4`.
   Lee la línea `interpoladas …` de cada beat (palabras colocadas a ojo).
9. **Control final** (abajo) → entrega el mp4 + el copy.

## Controles de calidad (obligatorios antes de entregar)
- `ffprobe` del mp4: 1080×1920, `r_frame_rate` igual a `avg_frame_rate` (si difieren, Meta se traba
  al 80 % de la subida), video + audio, duración ≥ 30 s.
- Volumen entre −16 y −14 LUFS (`ffmpeg -i x.mp4 -af ebur128 -f null -`).
- **Mira una hoja de contactos** (un cuadro cada 1-2 s) y el primer segundo entero: el gancho tiene
  que leerse y verse ya en el primer cuadro.
- Busca en cada cuadro: texto inventado o en otro idioma, manos deformes, interfaz falsa (barras,
  relojes), cambio de cara del personaje, letterbox negro, el fondo del Cap. 3 oscureciéndose.
- Escucha la voz completa: que no se coma la última frase (el CTA) y que pronuncie bien la marca.

## Controles de políticas (Meta)
- **Sin precio** en el video, sin tachados ni cuentas regresivas falsas.
- **Sin resultados garantizados** ("vas a cosechar en 7 días") ni promesas de salud/dinero.
- **Sin testimonios inventados** ni personajes presentados como clientes reales.
- **Sin atributos personales** en el copy ("¿Tienes sobrepeso?", "¿Estás deprimido?"): habla del
  problema, no de la persona.
- **Sin marcas ajenas** ni personajes, escenarios o estilos reconocibles de películas concretas:
  diseños originales.
- Sin mencionar otras plataformas ni declarar cómo se hizo el video en el copy.
- El mecanismo tiene que ser **cierto**: si es de salud, que no prometa curar ni tratar nada.
- Pasa guion y copy por un chequeo de cumplimiento (por ejemplo la skill `compliance-checker` si la tienes).

## Trampas reales
| Trampa | Arreglo |
|---|---|
| El Cap. 3 sale como infografía con etiquetas en inglés y flechas | "A still frame from a 3D animated short film, not a diagram…" + la frase de cierre "Pure visual scene: absolutely no words…" |
| START y END no coinciden (otro ángulo, otra planta, otro fondo) | END como **edición** del START con `image_urls`, nunca desde cero |
| `--regenerar` repite el mismo error | borra antes `frames/<id>*`: si no, reusa la imagen vieja |
| El video se bloquea por "content safety" | cambiar el prompt del video no alcanza: cambia la **imagen**. Evita manos sosteniendo objetos, personas en primer plano, jeringas, líquidos rojos |
| El texto del mockup sale con letras cambiadas | título entre comillas + "Spelling must be exact"; revisa letra por letra |
| Etiqueta del producto en blanco | no pongas "no text" en la toma del producto: la coletilla ya prohíbe solo los textos *añadidos* |
| El generador devuelve horizontal o con barras negras | la coletilla ya pide 9:16; `gen:clips` detecta y recorta el letterbox solo |
| La voz se come la última frase | `gen:voz` lo detecta y reintenta; escucha igual el CTA |
| El personaje cambia entre tomas | descripción del personaje idéntica, palabra por palabra, en cada toma |
| Dos corridas sobre el mismo `--solo` | se pisan: reparte ids distintos entre procesos |

## Costo aproximado (APIMART)
| Pieza | Precio | En un anuncio típico |
|---|---|---|
| Imagen `gpt-image-2` | ~$0,008 | ~17 (tomas, B-roll, mockup, END editados) → ~$0,14 |
| Clip `veo3.1-lite` (una imagen, 8 s) | $0,07 | 12 → $0,84 |
| Clip `veo3.1-fast` modo frame (8 s) | $0,14 | 3 → $0,42 |
| Voz | ~$0,01 por línea | 9 → $0,09 |
| **Total** | | **≈ $1,50**, ≈ $2,00 con reintentos |

Calcula un 15-20 % de reintentos. Lo que vale es la línea `Facturado real` que imprime cada comando.

## Variantes baratas (después del primero)
Los clips no tienen idioma: otro gancho, otra voz u otro idioma = nueva voz + nuevo montaje, sin
clips nuevos. Una variante "otra metáfora del mecanismo" rehace solo el Cap. 3 (~$0,50). Cambia un
solo eje por variante y nunca toques oferta ni garantía entre variantes.
