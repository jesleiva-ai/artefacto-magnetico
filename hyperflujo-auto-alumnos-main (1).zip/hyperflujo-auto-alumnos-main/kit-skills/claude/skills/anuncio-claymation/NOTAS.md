# NOTAS — Ejemplo 2: Claymation · «Mes en Verde» (producto inventado)

Campaña: `anunciante-supremo/input/ej-clay-finanzas/` (guion.json, ad-01.json, hook/hook.ass, mockups/p.json)
Clips reutilizables (~70 MB, se generan al correrla): `anunciante-supremo/public/media/_clips/ej-clay-finanzas/`
Música: `public/media/_music/music-clay-curioso.mp3` (Suno, pizzicato + marimba).
Voz: ElevenLabs «Mario» (latinoamericano neutro), velocidad 1,05.

## Resultado
- `anuncio.mp4`: 1080×1920, 30 fps, 37,6 s, −16 LUFS, 18 planos / 17 cortes, 111 captions (cobertura 100 % en las 9 líneas).
- Hook visual + verbal en el segundo 0: hormigas cargando monedas + texto «Gastos hormiga: el dinero que **no ves** irse» (0-3,6 s) + voz «Estas hormiguitas se llevan el dinero del mes…».
- Giro en la línea 5 («Hasta que los escribes»: el foco atrapa a las hormigas). Producto: 2 mockups (laptop y celular) desde el segundo ~25. CTA «Toca el botón y descárgala hoy» sobre el mockup.

## Costo real (APIMART) ≈ $1,50
| Ítem | $ |
|---|---|
| t01 (imagen + clip, primera prueba) | 0,07 |
| 12 tomas/B-roll (2 en modo frame) | 1,04 |
| Regeneración t02 (imagen + clip) y t03 (solo video, modo frame) | 0,21 |
| Música Suno | 0,05 |
| Mockups gpt-image-2: 6 pedidos × 0,008 (2 descartados por cifras, 2 perdidos por un error de script mío) | 0,05 |
| Voz: el script estima 0,10 (ElevenLabs da los tiempos, así que probablemente no se cobró transcripción) | ≤ 0,10 |
Si compartes la llave, el saldo no sirve para medir tu gasto: la cifra sale de los «Facturado real» y de los costos de cada tarea.

## Regeneraciones y por qué
1. **Mockups v1** → mostraban «Ahorro del mes $12.320» e «Ingresos $20.000»: cifras de dinero que se leen como promesa. Regenerados con montos como barras grises.
2. **t02** → la «suscripción» salió como rectángulo rojo con play blanco = parecía el logo de una plataforma de video. Imagen nueva: lector digital celeste con estrella.
3. **t03 (modo frame)** → Veo cargó tomates y la balanza terminó vacía. Solo video nuevo con Motion descrito paso a paso; ahora se ve la pila crecer y el platillo bajar (tiene un salto de escena a los ~4 s del clip crudo, que el montaje no usa).
4. **Línea 6 de la voz** → decía «para Google Sheets o Excel» (marcas ajenas). Cambiada a «una planilla digital».

## QA
- QA automático (resolución, idioma de la voz, loudness, OCR): **0 🔴**, 🟢 anuncio.mp4 (voz detectada es, −16 LUFS, tono 159 Hz).
- Revisión visual de la hoja (`hoja.jpg`) y de tiras de cada clip: sin caras/manos deformes, sin texto deformado grande, sin logos. Personaje consistente en las 4 tomas en que aparece. La mano con lápiz en t05 salió bien.
- Problema técnico encontrado: `ffprobe` del sistema roto → el QC de gen-clips explotaba después de cobrar. Instala ffprobe real (viene con ffmpeg) antes de empezar.

## Compliance (skill compliance-checker, Meta, finanzas)
| # | Categoría | Estado |
|---|---|---|
| 1 | Atributos personales | PASS — el problema se cuenta en tercera persona («casi nadie las ve», «nadie los anota»); sin «¿llegas justo?» ni «¿tienes deudas?» |
| 2 | Lenguaje sensacionalista/negativo | PASS — «desaparece sin dejar rastro» es suave |
| 3 | Salud | N/A |
| 4 | Promesas financieras | PASS — sin cifras ni ahorro garantizado; promete control («decides tú adónde va tu dinero») |
| 5 | Antes/después | PASS |
| 6 | Loops/clickbait | PASS — el hook se resuelve en la línea 2; nombre del producto en voz, pantalla y copy |
| 7 | Palabras gatillo | PASS |
| 8-9 | Landing / consistencia | N/A (producto inventado) |
- LOW: segunda persona con dinero («tus gastos», «tu dinero») — no afirma una condición del usuario; se deja.
- **Puntaje: 9,5/10 — listo para correr.** Sin precio, sin tachados, sin urgencia falsa («hoy» sin plazo), sin testimonios, sin marcas ajenas, sin declarar IA.

## Lo que no quedó perfecto
- El hook de texto es una caja blanca por línea (ASS BorderStyle 3), no la caja redondeada nativa de la plantilla 1.
- Las captions centrales pisan el centro del mockup en los planos de producto (se leen igual).
- En t05 las hormigas no «se congelan» tan claro como en el guion; el foco sí entra.
- La propia balanza (t03) usa solo ~2,3 s: se ve la pila crecer pero no llega a tocar la mesa en pantalla.
