---
name: anuncio-claymation
description: Arma de punta a punta un anuncio vertical 9:16 estilo CLAYMATION (stop-motion de plastilina generado + voz en off + captions quemadas) para vender un producto digital, usando la skill anunciante-supremo (plantilla 3) y tu llave de APIMART. Úsala cuando digas "anuncio de plastilina", "anuncio claymation", "stop-motion para mi producto", "hazme un anuncio con un villano de plastilina", "personifica el problema en plastilina", o cuando el producto resuelva un problema silencioso que conviene mostrar como un personaje (gastos que se escapan, tiempo que se pierde, desorden que crece, hábitos que se olvidan).
---

# anuncio-claymation — el villano de plastilina que vende tu producto

Un anuncio de 30-45 s donde **el problema es un personaje de plastilina** (el villano), una voz en
off cuenta la historia, el villano queda **al descubierto** por el mecanismo de tu producto y el
cierre muestra el producto real con un llamado a tocar el botón. Se apoya en la skill
`anunciante-supremo` (plantilla 3): esta skill es la receta; aquella, el motor.

## Cuándo conviene (y cuándo no)
- **Sí**: el dolor es invisible o acumulativo (algo que "se va" o "crece" sin que lo notes), hay un
  mecanismo simple que se puede mostrar (anotar, ordenar, medir, revisar) y el producto es la
  herramienta de ese mecanismo. La plastilina baja la guardia: lo que en foto sería sermón, en
  plastilina es simpático.
- **No**: si tu prueba fuerte es una persona real hablando (usa UGC), si necesitas mostrar mucho la
  interfaz del producto (usa B-roll de pantalla), o si el tema es delicado (salud seria, dinero de
  terceros): la plastilina puede sonar a burla.
- Los clips **no tienen idioma**: el mismo set sirve para otro país regenerando solo la voz.

## Antes de empezar
1. Tener instalada `anunciante-supremo` con el doctor en verde (`node scripts/doctor.mjs`) y tu
   `APIMART_API_KEY` en el `.env` o el entorno. ElevenLabs es opcional (mejor voz).
2. Comprobar que existen `ffmpeg` **y** `ffprobe` en el PATH (`ffprobe -version`). Si falta
   `ffprobe`, el generador cobra el clip y después falla el control de calidad.
3. Ver tu saldo de APIMART y fijarte un tope (un anuncio cuesta ~$1,20-1,50).

## 1. El guion: villano → mecanismo → producto → CTA
Mínimo 30 s de voz: ~110-120 palabras en 8-10 líneas cortas. Cada línea = un plano de personaje +
un B-roll. **Los números van en cifra** ("2 minutos", no "dos minutos").

| Bloque | Líneas | Qué dice | Qué se ve |
|---|---|---|---|
| Gancho | 1 | El villano en acción + qué está en juego, en ≤ 16 palabras | El villano haciendo el daño en el primer cuadro |
| Nombre del villano | 2 | Lo bautizas con ejemplos concretos y cotidianos | El villano con los objetos del día a día |
| Agitación | 3-4 | Por qué no se nota: "cada uno parece nada; juntos pesan" | Un cambio de estado (balanza que cae, pila que crece) |
| Giro | 5 | "Hasta que…": el mecanismo lo vuelve visible | El villano atrapado (foco, lupa, red) |
| Producto | 6-7 | Nombre + qué es + 2-3 entregables con un número concreto | El mockup del producto + el personaje aliviado |
| Payoff | 8 | La sensación de control, sin prometer cifras | El villano se va derrotado |
| CTA | 9 | "Toca el botón y descárgalo hoy." | El mockup del producto |

Texto en pantalla de los primeros 3-4 s (el hook de texto, regla de `plantillas/hooks.md`):
**sujeto + lo que está en juego**, 2 líneas, una palabra resaltada. Ej.: `Gastos hormiga: | el dinero que *no ves* irse`.

## 2. El Character Bible (lo único que sostiene la consistencia)
No hay imagen de referencia entre tomas: el personaje se mantiene igual porque **cada prompt
empieza con la misma descripción, palabra por palabra**. Escribe dos: protagonista y villano.

```
CHARACTER: a claymation adult [mujer/hombre] in [edad] with a rounded handmade clay body, simple oval head,
small dark dot eyes, expressive thick dark eyebrows, small curved mouth, [pelo], [tono de piel] clay
skin tone, wearing a muted [color] clay [prenda], tactile plasticine material with refined subtle
sculpting marks, matte surface finish

VILLAIN: tiny mischievous claymation [criatura] made of matte [color] plasticine, round bead heads
with big white clay eyes and small black dot pupils, cheeky grins, [rasgo], refined subtle sculpting marks
```
Define también **un set fijo** (la cocina, el escritorio) y repítelo igual en todas las tomas.

## 3. Cómo se escriben los prompts de plastilina
- **Imagen** = `<Bible(s)>. <una acción concreta> in <el set fijo>, <ángulo de cámara>`. Ángulos con
  intención: "ground-level camera at table height", "frontal symmetrical", "three-quarter angle",
  "extreme macro close-up".
- **Todo es plastilina**: vidrio, metal, papel, monitores → "sculpted in matte plasticine".
- **Sin texto en cuadro**: monitores con "a sculpted clay grid of rows and bars without readable text";
  calendarios "with blank squares and no numbers".
- **Sin logos**: "a tiny clay takeaway coffee cup without any logo". Diseños siempre originales.
- **Nada de negative prompt**: el generador de imágenes no tiene campo de negativos y dibuja lo que
  nombras. Escribe en positivo.
- **Video** = solo `Camera: <un movimiento>. Motion: <una acción>`. Una acción por clip. Las
  coletillas de estilo (stop-motion, non CGI) las agrega el motor solas.
- **Modo frame** (`"fin"`): para 1-2 tomas donde un **cambio de estado** cuenta la historia (la
  balanza se hunde, el foco atrapa al villano). Cuesta el doble; úsalo donde vale.
- **B-roll**: macros del villano con el objeto, el objeto solo, una lupa o un gráfico de plastilina.
  Tapan defectos y le dan ritmo (corte cada ≤ 3 s).
- **Evita** lo que el filtro de video suele bloquear: manos humanas sosteniendo objetos, jeringas,
  personas en primer plano, líquidos rojos. Si una toma necesita "escribir", muestra la libreta
  llenándose sola en modo frame, no una mano con lápiz.

## 4. El producto al final (mockup)
Genera 1-2 mockups con gpt-image-2 por APIMART (9:16): laptop y/o celular con la pantalla del
producto, nombre de tu marca grande, **sin logos de terceros** ("no visible brand logo", "generic
spreadsheet interface"). **Pide las celdas de montos como barras grises de relleno**: si no, el
generador inventa cifras ("Ahorro del mes $12.320") que en Meta se leen como promesa de dinero.
Conviértelos en clip de 8 s con un acercamiento suave:
```bash
ffmpeg -loop 1 -i p01.png -vf "scale=1440:2560:force_original_aspect_ratio=increase,crop=1440:2560,zoompan=z='1+0.0006*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=240:s=720x1280:fps=30,format=yuv420p" -frames:v 240 -c:v libx264 -crf 18 -an public/media/_clips/<slug>/clips/p01.mp4
```
Esos `p01`/`p02` se usan en `ad-01.json` como cualquier otro plano (no van en `guion.json`).

## 5. Paso a paso (dentro de la carpeta de `anunciante-supremo`)
> **Antes de gastar:** mostrale al dueño el guion, la cantidad de tomas y el costo estimado de la
> tanda, y esperá su OK en el chat. Recién con ese OK se corre con `--si` (desde Claude no hay
> terminal interactiva: `--si` es saltear la confirmación, y eso lo autoriza solo el dueño).

```bash
# 0. campaña
mkdir -p input/<slug>            # escribe ahí guion.json (esquema en plantillas/plantilla-3.md)

# 1. primera toma sola, y MIRARLA (si el personaje sale mal, todas heredan el error)
npm run gen:clips -- input/<slug>/guion.json --si --solo t01

# 2. el resto de tomas y B-roll (2-4 min por clip; ~40 min para 13 clips)
npm run gen:clips -- input/<slug>/guion.json --si

# 3. música (una vez; se reusa por id)
npm run gen:musica -- --id <id> --si --prompt "playful quirky pizzicato strings and light marimba, curious and cheerful, stop-motion soundtrack, 100 BPM"

# 4. voz (escribe ad-01.json borrador)
npm run gen:voz -- input/<slug>/guion.json --si
#    cambiar una línea: editar guion.json y  npm run gen:voz -- input/<slug>/guion.json --si --solo 6 --forzar

# 5. editar ad-01.json: planos de cada beat (ej. [["t01",2.6],["b01"]]), mockups en el beat del producto y del CTA

# 6. montar
npm run montar -- input/<slug>/ad-01.json --salida out/<slug>/anuncio.mp4
```
**Hook de texto arriba**: el montador de la plantilla 3 no lo trae; agrégalo con un `.ass` de una
sola línea (caja blanca, texto negro, palabra resaltada en color, ~430 px desde arriba, 0-3,5 s) y
`ffmpeg -vf subtitles=hook.ass` sobre el mp4 final (`-c:a copy`).

Regenerar una toma: `npm run gen:clips -- input/<slug>/guion.json --si --solo t03 --regenerar`.
**Ojo**: `--regenerar` rehace el video pero reusa la imagen guardada. Si falló la imagen o el filtro
de contenido, borra antes `public/media/_clips/<slug>/frames/t03*`.

## 6. Control de calidad (antes de entregar)
- **Mira cuadros de cada clip** (`ffmpeg -i clip.mp4 -vf "fps=1/2,scale=240:-1,tile=4x1" -frames:v 1 tira.jpg`).
  El QC técnico aprueba clips rotos. Busca: manos o caras deformes, villanos que cambian de color,
  aspecto CGI brillante, texto garabateado grande, logos, objetos de vidrio/metal "reales".
- En el log de `montar`, la línea `interpoladas …` dice qué palabras se ubicaron a ojo: si son muchas,
  la voz no dijo lo que dice el guion → regenera esa línea.
- Mira el anuncio completo con sonido: la voz entra en el segundo 0, las captions se leen, ningún
  plano dura más de 3 s, el producto se ve claro al final, duración ≥ 30 s.
- 1080×1920, 30 fps, sonido −16 LUFS aprox. (el montador lo normaliza).

## 7. Control de políticas (Meta)
- **Sin atributos personales**: nada de "¿tienes deudas?", "¿llegas justo a fin de mes?", "si estás
  quebrado". Habla del problema en general ("casi nadie los ve", "a fin de mes pesan").
- **Sin promesas de dinero**: ni "ahorra $X", ni "duplica tus ingresos", ni cifras en el mockup.
  Promete control y claridad, no resultados garantizados. Finanzas es categoría sensible.
- **Sin precio, sin tachados, sin urgencia falsa** ("solo hoy", contadores). "Descárgalo hoy" sin
  plazo está bien.
- **Sin testimonios inventados**, sin marcas de terceros (ni en voz, ni en copy, ni en pantalla),
  sin mencionar otras redes ni declarar cómo se hizo el video.
- Pasa guion y copy por un revisor de cumplimiento (ej. la skill `compliance-checker`) antes de subir.

## 8. Trampas reales (encontradas haciendo el ejemplo)
1. **`ffprobe` ausente** → el clip se paga y luego el QC explota con `Cannot read properties of
   undefined (reading 'toFixed')`. Instalar ffprobe y volver a correr (es reanudable, no repaga).
2. **Mockups con cifras inventadas**: el primer intento puso "Ahorro del mes" con montos grandes.
   Regenerado con celdas grises. Míralos siempre.
3. **Marcas en la voz**: decir "para Google Sheets o Excel" mete marcas ajenas en el anuncio; se
   cambió por "una planilla digital". La compatibilidad va en la página de venta.
4. **El modo frame a veces ignora el cambio de estado** (la primera versión de la balanza cargó
   tomates y terminó vacía). Arreglo: regenerar solo el VIDEO con un `Motion:` que describa el
   proceso paso a paso ("stack more and more… the plate sinks all the way down"). Y puede meter un
   salto de escena a mitad del clip: usa solo los primeros ~2,5 s de esa toma.
5. **Íconos que parecen marcas**: "una pantallita de streaming con un triángulo de play" salió como
   un rectángulo rojo con play blanco, idéntico al logo de una plataforma de video. Se cambió por
   "un lector digital celeste con una estrella blanca". Evita describir íconos genéricos de apps conocidas.
6. **Sin terminal interactiva** (corriendo desde un agente), todo lo que gasta pide `--si`.
7. **Dos corridas sobre el mismo slug se pisan**: una a la vez.

## 9. Costo aproximado (APIMART)
| Pieza | Costo |
|---|---|
| Imagen por toma / B-roll (gpt-image-2) | ~$0,008 |
| Clip de una imagen (veo3.1-lite, 8 s) | $0,07 |
| Clip en modo frame (veo3.1-fast) | $0,14 |
| Música (una vez) | $0,05 |
| Voz + tiempos | ~$0,01 por línea |
| Mockup del producto | ~$0,008 cada uno |
| **Anuncio de 7 tomas (2 en modo frame) + 6 B-roll + 2 mockups** | **≈ $1,25-1,50** con reintentos |

Una vez hecho, cada variante (otro gancho, otra voz, otro idioma) cuesta centavos: reusa los clips.
