# Notas — ejemplo MUSICAL «Inglés para Viajar» (producto inventado)

## Entregables
- `anuncio.mp4`: 36,5 s, 1080×1920, 30 fps. La voz cantada entra a los 0,30 s y el producto a los 15,9 s, cuando se canta su nombre. Tiene 21 planos.
- `copy.json` (texto, título, descripción, CTA LEARN_MORE, letra y ángulo) · `poster.jpg` · `hoja.jpg` (la hoja del QA).
- `SKILL.md`: la skill instalable `anuncio-musical`.
- Carpeta de trabajo (no viaja en el paquete; la armas tú al hacer el tuyo):
  - `montar.py`, el montador que se puede rehacer.
  - `letra.txt` y `plan.json`, la letra y los dos estilos enviados a Suno.
  - `alineada.json`.
  - `canciones/`, los 4 temas.
  - `control/`, las transcripciones Scribe de los 4 temas y del final, más la hoja de cuadros.
  - `img/`, la persona, los 2 ángulos, el mockup y los recortes de audio.
  - `tomas/`, el B-roll de Veo y los 4 playbacks de Wan.

## Costo real (apimart, de las tareas)
| Ítem | $ |
|---|---|
| Suno: 2 envíos (4 temas) | 0,095 |
| Letra alineada | 0,001 |
| 4 recortes Suno crop (1 falló por saturación y se reintentó) | 0,030 |
| GPT Image 2: persona + mockup | 0,029 |
| Nano Banana Pro: 2 ángulos | 0,038 |
| Wan 2.6: 4 playbacks de 5 s | 0,950 |
| Veo 3.1 Fast: 9 tomas (7 + 2 rehechas) | 1,197 |
| **Total** | **≈ 2,34** |

ElevenLabs Scribe: 5 transcripciones (centavos, cuenta aparte).

## Temas de Suno: cuál se eligió y por qué
- Los 4 cantan bien «Inglés para Viajar» (Scribe).
- **Elegido: reggaetón-2 (tema B, `audio_index` 2).** La letra es la más fiel, el estribillo llega antes (16,7 s) y dura ~36 s. Se recortó en 0,72 s para que la voz entre en el primer medio segundo.
- **Pop-1 (tema A, `audio_index` 1):** el estribillo llega tarde (24 s) y el tema dura 40 s. Queda fuera del rango ideal.
- **Pop-2 (tema A, `audio_index` 2):** cambió «go» por «let's go» y «ven» por «ve». Además tiene el mismo problema de largo que pop-1.
- **Reggaetón-1 (tema B, `audio_index` 1):** es la voz que entra más rápido (0,32 s), pero mete «¡Ey! ey, ey, ey» extra y el estribillo llega a los 20 s.

## Tomas descartadas
Las tomas Veo de **hotel** y **farmacia** salieron con recepcionista y farmacéutico que no encajaban con el casting definido para el mercado. Se rehicieron describiendo a cada secundario: un recepcionista latino y una farmacéutica latina (+$0,27). Las viejas se borraron.

## QA automático (resolución, idioma de la voz, loudness, OCR)
- **0 🔴.**
- El primer pase dio 🟡 por un pico de -0,2 dBFS. Se corrigió con `alimiter` (pico final -1,5 dB, LUFS -15,2) y quedó en el montador.
- Sigue un 🟡 de «ritmo 0,7 palabras/s». Es un falso positivo de una canción: el detector transcribe mal la voz cantada sobre la música («Maleda listo», «audífe»). La transcripción Scribe del final, en cambio, da la letra completa y exacta, con «Inglés para viajar» dos veces y el CTA.
- El detector de idioma dio `voz=es`. El «Hello, hello / go» no lo confundió.
- Revisé a ojo la hoja del QA y la de 72 cuadros:
  - No hay caras deformes, cuadros negros ni logos ajenos.
  - El karaoke se lee sobre todos los fondos.
  - El mockup escribe bien «Inglés para Viajar», Aeropuerto, Hotel, Restaurante, Compras y Emergencias.
- Medí el desfase de los playbacks Wan con una correlación del audio contra la canción: 0-20 ms en los 4.

## Compliance (skill compliance-checker, Meta, producto digital, anuncio front-end)
- **Letra:** PASA. El gancho está en primera persona («¿cómo voy a hablar?»). No hay negativos sensacionalistas ni promesas con plazo («pronuncia bien» y «tú puedes» son ánimo, no un resultado garantizado). No hay precio ni urgencia falsa. El CTA es una invitación.
- **Copy:** un hallazgo MEDIO. La primera línea era «¿Te vas de viaje y el inglés te frena?», que supone una limitación de quien mira (atributo personal). Se cambió por «Maleta lista, pasaporte en mano y el inglés del viaje en el bolsillo 🎶». Puntaje final: 10/10.
- No hay marcas ajenas. El avión de las tomas va sin aerolínea. Los monumentos del mockup son genéricos y no tienen logos. Los auriculares son blancos genéricos, sin logo.
- No se declara IA ni se menciona TikTok. No hay testimonios.

## Lo que no quedó perfecto
- **Continuidad de la protagonista:** las tomas de Veo son texto→video, así que la mujer del B-roll se parece a la que canta (misma ropa, pelo y mochila), pero la cara no es idéntica. En el arranque multicámara y en el estribillo cantado la cara sí es la misma. Para que sea igual en todas habría que hacer Veo imagen→video desde la foto, con más costo.
- **Ángulo repetido en el arranque:** el ángulo A se repite en el 2.º corte, porque es el único que cubre de 0,7 a 2,4 s. Se resolvió con un primer plano cerrado (zoom a la cara) para que se lea como otra cámara. Un 4.º ángulo desde 1,5 s lo habría evitado (+$0,25).
- **Cierre:** el mockup fijo dura 6,9 s (con deriva lenta, la placa y el CTA cantado). Es algo largo, pero sostiene el CTA.
- **Archivo pesado:** `anuncio.mp4` pesa 48 MB (~10 Mbps). Si hay que mandarlo por WhatsApp conviene bajar el bitrate.
