---
name: anuncio-musical
description: Crea un ANUNCIO MUSICAL vertical (9:16, 25-40 s) para un producto digital. Una canción pegadiza propia que nombra el producto (Suno V6 por APIMART), un arranque multicámara con una persona cantando a cámara en playback (imagen → ángulos → Wan 2.6 con el audio), planos cortados a la palabra con karaoke y el producto en pantalla cuando se canta su nombre. Usar cuando el usuario diga "anuncio musical", "hazme un jingle", "canción para mi producto", "anuncio con canción pegadiza", "creativo cantado", "anuncio estilo karaoke" o "/anuncio-musical".
---

# Anuncio musical

Produce, de punta a punta, un anuncio vertical en el que **una canción propia vende el producto**. La canción marca el ritmo del montaje: cada plano entra en una palabra cantada, el karaoke se pinta palabra por palabra y el producto aparece justo cuando el estribillo canta su nombre.

**Qué necesitas:**
- Una llave de APIMART (`APIMART_API_KEY`). Con ella haces la música, las imágenes, el video y el playback.
- ffmpeg compilado con libass (para el karaoke) y Python 3 con numpy.
- Opcional: una llave de ElevenLabs (`ELEVENLABS_API_KEY`) para transcribir la canción con Scribe. Si no la tienes, sirve faster-whisper en local.
- Una fuente gruesa en una carpeta `fonts/`, por ejemplo Montserrat ExtraBold (Google Fonts, licencia OFL).

## Cuándo conviene

- **Sirve para** productos fáciles de nombrar y de enumerar: un curso, una guía, una plantilla o una app. El estribillo repite el nombre y la estrofa dice qué trae.
- **Sirve para** públicos amplios y de consumo (viajes, cocina, idiomas, hobbies). La canción frena el scroll y deja el nombre en la cabeza.
- **No conviene** para ofertas que necesitan explicar un mecanismo complejo o mostrar pruebas. Ahí rinde más un guion hablado.
- **Tiene un riesgo:** si la IA canta mal el nombre del producto, el anuncio no sirve. Por eso existe el control de la letra (paso 3), que es obligatorio.

## Costo aproximado (medido en un ejemplo real)

| Paso | Modelo | Costo |
|---|---|---|
| Canción (2 envíos = 4 temas) | Suno V6 | $0,095 |
| Letra alineada | Suno | $0,001 |
| 4 recortes de audio | Suno crop | $0,03 |
| Foto de la persona + mockup | GPT Image 2 (2k) | $0,03 |
| 2 ángulos de la misma persona | Nano Banana Pro | $0,04 |
| 4 playbacks de 5 s (720p) | Wan 2.6 | $0,95 |
| 7-9 tomas de B-roll de 8 s | Veo 3.1 Fast | $0,13 c/u |
| **Total** | | **~$2,0-2,4** |

APIMART cobra cada tarea al enviarla y devuelve el dinero si falla. Para ver el saldo:

```bash
curl -s -H "Authorization: Bearer $APIMART_API_KEY" https://api.apimart.ai/v1/user/balance
```

---

## Paso 1 · Escribir la letra

La letra es el guion. Usa este molde de unos 35 s (11 líneas cantadas):

```
[Intro]            ← 2 líneas: el gancho, cantado ya en el primer segundo. Primera persona.
¡Maleta lista, me voy a volar!
Pero en inglés, ¿cómo voy a hablar?

[Verse]            ← 4 líneas: dónde se usa y QUÉ TRAE el producto (formato, cantidad, partes)
Aeropuerto, hotel y restaurante,
compras, emergencias, ¡adelante!
Trescientas frases para preguntar,
con audio y PDF para practicar.

[Chorus]           ← 4 líneas: el NOMBRE DEL PRODUCTO abre la 1.ª y la 4.ª línea
¡Inglés para Viajar! Hello, hello!
Pide, pregunta, ¡tú puedes, go!
Escucha, repite, pronuncia bien,
¡Inglés para Viajar, y vamos, ven!

[Outro]            ← el CTA cantado
¡Toca el botón y empieza hoy!
```

**Reglas de la letra:**
- **Métrica:** de 8 a 12 sílabas por línea, con rima consonante o asonante por pares (volar/hablar, preguntar/practicar). Si las líneas son cortas, Suno las canta claras. Si son largas, las atropella.
- **Nombre del producto:** va en el estribillo, al principio de una línea y entre signos de exclamación. Así Suno lo acentúa. Que suene 2 veces en el estribillo y nada más.
- **Lo que trae:** cantidad, formato y usos concretos ("trescientas frases", "audio y PDF"). Los números se escriben con letras ("trescientas", no "300"), porque Suno lee mal las cifras.
- **Gancho:** en primera persona ("me voy", "¿cómo voy a hablar?"), nunca "¿tú no sabes…?". Meta penaliza que el anuncio suponga un problema del que mira.
- **Otro idioma:** se pueden meter 1 o 2 palabras muy fáciles en el estribillo ("Hello, hello", "go"). Más que eso confunde a Suno y al público.
- **CTA:** al final y cantado. Es una invitación sin urgencia falsa: "Toca el botón y empieza hoy".
- **Prohibido:** precio, tachados, "últimas horas", promesas de resultado con plazo ("habla inglés en 7 días"), testimonios inventados, marcas ajenas (aerolíneas, apps, plataformas) y mencionar que el anuncio está hecho con IA.

## Paso 2 · Crear la canción (Suno V6)
> **Antes de gastar:** mostrale al dueño el guion, la cantidad de tomas y el costo estimado de la
> tanda, y esperá su OK en el chat. Recién con ese OK se corre con `--si` (desde Claude no hay
> terminal interactiva: `--si` es saltear la confirmación, y eso lo autoriza solo el dueño).


Manda **2 envíos con estilos distintos**. Cada envío trae 2 temas, así que eliges entre 4.

```bash
curl -s -X POST https://api.apimart.ai/v1/music/generations \
  -H "Authorization: Bearer $APIMART_API_KEY" -H "Content-Type: application/json" \
  -d '{
    "model": "suno",
    "version": "v6",
    "custom": true,
    "instrumental": false,
    "title": "Inglés para Viajar",
    "prompt": "[Intro]\n¡Maleta lista, me voy a volar!\n...\n[Outro]\n¡Toca el botón y empieza hoy!\n",
    "style": "feel-good reggaeton pop, light dembow, young adult female lead vocal singing clearly in Latin American Spanish, crowd shouts on the chorus, synth plucks, 96 bpm, party travel vibe, clear diction, vocals start immediately with no intro",
    "vocal_gender": "Female",
    "negative_tags": "explicit, screaming, metal, slow ballad, long instrumental intro, full english lyrics",
    "duration": 40
  }'
# → {"code":200,"data":[{"status":"submitted","task_id":"task_..."}]}
```

- Con `custom: true`, el campo `prompt` es la **letra literal** con sus etiquetas `[Intro] [Verse] [Chorus] [Outro]`.
- Escribe en `style` "vocals start immediately with no intro" y "clear diction". Pon el idioma del canto en `style` y la intro larga en `negative_tags`.
- Otro estilo que funcionó: `"upbeat latin pop, super catchy summer travel anthem, young adult female lead vocal singing clearly in neutral Latin American Spanish, crisp diction, handclaps, acoustic guitar, bright synths, punchy drums, 120 bpm, joyful, vocals start immediately with no intro"`.

**Consultar la tarea** (tarda ~30 s):

```bash
curl -s "https://api.apimart.ai/v1/music/tasks/$TASK_ID" -H "Authorization: Bearer $APIMART_API_KEY"
# data.status: pending|processing|completed|failed
# data.result.music[i].audio_url  (i = 0 y 1 → los dos temas; descárgalos YA, expiran en 24 h)
```

Más adelante, a cada tema lo nombras con `task_id` + `audio_index`: **1** para el primero y **2** para el segundo.

## Paso 3 · Control de la letra (obligatorio)

Transcribe los 4 temas y **descarta todo tema que cante mal el nombre del producto** o cambie palabras clave.

```bash
curl -s -X POST https://api.elevenlabs.io/v1/speech-to-text -H "xi-api-key: $ELEVENLABS_API_KEY" \
  -F model_id=scribe_v1 -F language_code=spa -F file=@tema.mp3
# → text + words[] con start/end de cada palabra
```

Sin ElevenLabs, usa `faster-whisper` (modelo `large-v3`, `language="es"`, `word_timestamps=True`).

**Cómo elegir el tema:**
- Que diga el nombre bien escrito.
- Que la voz entre lo antes posible: mira `words[0].start`.
- Que el estribillo llegue antes de los 18 s.
- Que dure entre 33 y 40 s.
- Escúchalo: tiene que pegarse.

Algunos temas cambian palabras: "go" se vuelve "let's go", "ven" se vuelve "ve". Si toca una palabra secundaria, se tolera. Si toca el nombre, se descarta.

## Paso 4 · Tiempos por palabra (letra alineada)

```bash
curl -s -X POST https://api.apimart.ai/v1/music/generations/alignedLyrics \
  -H "Authorization: Bearer $APIMART_API_KEY" -H "Content-Type: application/json" \
  -d '{"model": "suno", "task_id": "task_...", "audio_index": 2}'
# luego GET /v1/music/tasks/<nuevo_task_id> → data.result.alignment = [{word, start_s, end_s}, ...]
```

**Trampa:** los tokens vienen partidos y con las etiquetas pegadas (`"[Intro]\nMal"`, `"eta"`). Concatena todos los `word` en un texto. Guarda el `start_s`/`end_s` de cada carácter. Parte el texto por `\n`, descarta las líneas `[...]` y vuelve a partir cada línea en palabras. Así obtienes una lista `[(línea, [(palabra, inicio, fin), ...])]`, que es la que manda el montaje.

**Inicio:** recorta la canción unos 0,3 s antes de la primera palabra (`INICIO = start_primera_palabra − 0,3`). Así **la voz cantada entra en el primer medio segundo** del anuncio.

## Paso 5 · La persona que canta (arranque multicámara)

### 5a. La foto base (GPT Image 2)

```bash
curl -s -X POST https://api.apimart.ai/v1/images/generations \
  -H "Authorization: Bearer $APIMART_API_KEY" -H "Content-Type: application/json" \
  -d '{"model": "gpt-image-2", "size": "9:16", "resolution": "2k", "n": 1,
       "prompt": "Photorealistic vertical smartphone photo, medium close-up of a cheerful Latina woman around 27 years old, dark wavy hair in a loose ponytail, small gold hoop earrings, denim jacket over white t-shirt, travel backpack straps on her shoulders, singing joyfully toward the camera with mouth open mid-word, modern bright airport terminal behind her, soft daylight, shallow depth of field, no text, no logos, no airline branding."}'
# estado: GET /v1/tasks/<task_id> → data.result.images[0].url[0]   (la URL viene dentro de una LISTA)
```

Pide la boca **abierta a media palabra**. Wan anima mejor el playback si parte de ahí.

### 5b. Dos ángulos más de la MISMA persona (Nano Banana Pro con la foto como referencia)

```json
{"model": "gemini-3-pro-image-preview", "size": "9:16", "resolution": "2K", "n": 1,
 "image_urls": ["<URL de la foto base>"],
 "prompt": "Side three-quarter view, medium shot, she walks through the airport terminal pulling a carry-on, singing toward the camera. Same woman as the reference photo: identical face, hair, earrings, jacket and backpack. Photorealistic, vertical 9:16, singing with mouth open mid-word, no text, no logos."}
```

Se manda a `POST /v1/images/generations`. Pide planos bien distintos entre sí: selfie, plano medio de costado y contrapicado junto a la ventana con el avión. La cara sale igual.

### 5c. Recortar la canción en pedazos para el playback (Suno crop)

Wan necesita el audio en una **URL pública** y **no más largo que el video** (5 s). Recorta 4,9 s por ángulo, escalonados para cubrir el arranque. Por ejemplo, en el tema elegido: ángulo A desde 0,7 s, B desde 2,4 s, C desde 3,3 s, y uno más para el segundo estribillo.

```bash
curl -s -X POST https://api.apimart.ai/v1/music/generations/crop \
  -H "Authorization: Bearer $APIMART_API_KEY" -H "Content-Type: application/json" \
  -d '{"model": "suno", "task_id": "task_...", "audio_index": 2, "start_s": 2.4, "end_s": 7.3}'
# GET /v1/music/tasks/<id> → data.result.music[0].audio_url
```

### 5d. Playback con Wan 2.6 (imagen + audio → persona cantando)

```bash
curl -s -X POST https://api.apimart.ai/v1/videos/generations \
  -H "Authorization: Bearer $APIMART_API_KEY" -H "Content-Type: application/json" \
  -d '{"model": "wan2.6",
       "image_urls": ["<URL del ángulo>"],
       "audio_url": "<URL del recorte>",
       "duration": 5, "resolution": "720p",
       "prompt": "The woman sings this upbeat song to the camera with accurate lip-sync, expressive joyful face, natural head movement, slight handheld camera motion. She stays the only person in focus; keep her face identical. No text.",
       "negative_prompt": "extra people, deformed face, distorted hands, text, watermark"}'
# GET /v1/tasks/<id> → data.result.videos[0].url[0]   (~$0,24 por clip de 5 s, tarda 2-4 min)
```

- El clip devuelto **trae el audio del recorte** y su segundo 0 = segundo `start_s` de la canción. Mídelo con una correlación del audio del clip contra la canción (numpy, 8 kHz mono). En el ejemplo dio un desfase de 0 a 20 ms.
- `aspect_ratio` **no se acepta** en modo imagen→video: la proporción sale de la imagen (por eso la imagen se pide en 9:16).
- **Wan 2.7 no sirve** para esto: no acepta imagen y audio juntos.

### 5e. Revisar cada ángulo cuadro a cuadro

```bash
ffmpeg -i canta-b.mp4 -vf "fps=2,scale=144:-2,tile=10x1" -frames:v 1 hoja-b.jpg
```

**Trampa real:** Wan a veces deforma el plano después de ~3,5 s (aparecen personas nuevas o se derrite la cara). Si pasa, usa ese ángulo solo hasta el segundo sano y deja que los otros ángulos cubran el resto.

## Paso 6 · B-roll y mockup

**Tomas (Veo 3.1 Fast, 8 s, $0,13):**

```json
{"model": "veo3.1-fast", "aspect_ratio": "9:16", "duration": 8,
 "prompt": "Photorealistic vertical 9:16 handheld travel vlog footage, natural light, cinematic, no text, no logos, no brand names. A cheerful Latina woman in her late twenties ... checks in at a boutique hotel reception desk; the receptionist is a friendly Latino man ..., he hands her a key card and both smile."}
```

Se manda a `POST /v1/videos/generations`.

- Haz una toma por cada sustantivo que nombra la letra: aeropuerto, hotel, restaurante, compras, emergencias, escuchar con auriculares, practicar en un café.
- Describe siempre a la protagonista con la misma ropa, para que haya continuidad.
- **Describe también a los secundarios** (edad, origen, ropa). Si no los describes, Veo inventa personas que quizá no encajan con tu público o con tus reglas de casting. Revisa una hoja de 3 cuadros por toma antes de montar.
- Veo a veces entrega el 9:16 **con franjas negras adentro**. Detéctalas con `cropdetect` y recórtalas antes de encuadrar.

**Mockup del producto (GPT Image 2):** pide un celular con el reproductor de audio y un lector digital con el PDF. Los dos dispositivos llevan el nombre del producto, escrito exactamente entre comillas en el prompt. Agrega "no other brand names, no logos, no prices". GPT Image 2 escribe bien el español: revisa igual cada palabra.

## Paso 7 · Montaje (ffmpeg)

**Lista de planos:** cada uno es `(línea, palabra, clip, desde_en_el_clip, efecto)`. El plano empieza en el `start_s` de esa palabra y termina donde empieza el siguiente.

- **0 a ~5,5 s, multicámara:** solo los ángulos de la persona cantando. Corta cada ≥1,1 s **sobre el inicio de una palabra** y alterna ángulos. Cada clip entra en su tiempo real: `-ss (corte − start_s_del_recorte)`, así los labios caen en la letra. Si un ángulo tiene que repetirse, la repetición va en primer plano cerrado (zoom a la cara) para que se lea como otra cámara.
- **Estrofa:** un B-roll por sustantivo cantado ("Aeropuerto" → aeropuerto, "hotel" → hotel…). Hay planos de 0,5 a 2,5 s.
- **Primer nombre del producto:** entra el mockup con golpe de zoom y flash. **Antes de eso, el producto no aparece.**
- **Segundo nombre del producto:** la persona lo canta a cámara (el cuarto playback).
- **Cierre:** el mockup durante el CTA cantado, con una placa arriba ("300 FRASES · AUDIO + PDF").

**Filtros clave:**

```bash
# encuadre normal
scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30,setsar=1
# golpe de zoom: entra al 122 % y se asienta en 106 % en 0,25 s
scale=w='1080*(1.22-0.16*min(t/0.25,1))':h=-2:eval=frame,crop=1080:1920,fps=30,setsar=1
# flash blanco al arrancar (primer plano y entrada del producto)
,fade=t=in:st=0:d=0.18:color=white
# imagen fija con golpe de zoom y deriva lenta
ffmpeg -loop 1 -framerate 30 -i mockup.png -t 2.35 -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,scale=w='1080*(1.20-0.16*min(t/0.25,1)+0.012*t)':h=-2:eval=frame,crop=1080:1920" ...
# clip que se queda corto: se congela el último cuadro
,tpad=stop_mode=clone:stop_duration=2
```

Cada plano se codifica a un mp4 aparte (`-an`, libx264 crf 16). Después se unen con `concat`, el audio de la canción entra desde `INICIO` y el karaoke se quema encima:

```bash
ffmpeg -f concat -safe 0 -i lista.txt -ss $INICIO -t $TOTAL -i cancion.mp3 -map 0:v -map 1:a \
  -vf "ass=subs.ass:fontsdir=fonts" -c:v libx264 -crf 18 -pix_fmt yuv420p -r 30 \
  -c:a aac -b:a 192k -af "afade=t=in:d=0.04,afade=t=out:st=$((TOTAL-0.8)):d=0.8" -movflags +faststart anuncio.mp4
```

**Karaoke (ASS):** una línea de la letra por evento, con un `\kf` por palabra (centésimas desde el fin de la palabra anterior). Lo ya cantado se pinta en amarillo y lo que falta en blanco. Va con borde negro grueso, abajo y por encima de la zona de botones de Meta (MarginV ≈ 520):

```
Style: Kar,Montserrat ExtraBold,84,&H0000D4FF,&H00FFFFFF,&H00000000,&H96000000,0,0,0,0,100,100,1,0,1,8,4,2,70,70,520,1
Dialogue: 0,0:00:00.12,0:00:02.60,Kar,,0,0,0,,{\kf55}¡MALETA {\kf70}LISTA, {\kf48}ME ...
```

Resta `INICIO` a todos los tiempos. Cada línea empieza 0,15 s antes de su primera palabra y termina 0,15 s antes de la siguiente.

## Paso 8 · Controles finales

1. **Técnicos:**
   - 1080×1920 y 30 fps.
   - Duración de 25 a 40 s.
   - La voz entra antes de 0,5 s: mide la primera palabra − `INICIO`.
   - El audio no satura.
2. **Hoja de contacto:** `ffmpeg -i anuncio.mp4 -vf "fps=2,scale=180:-2,tile=12x6" -frames:v 1 hoja.jpg`. Mírala entera y revisa:
   - Que no haya cuadros negros, caras deformes ni texto basura.
   - Que el karaoke se lea en todos los fondos.
   - Que el producto aparezca cuando se canta su nombre.
3. **Letra final:** vuelve a transcribir `anuncio.mp4` y compárala con la letra.
4. **Políticas de Meta**, sobre la letra, la placa y el copy:
   - No supones atributos del que mira: nada de "¿te cuesta…?" ni "si no sabes…". Usa la primera persona.
   - Sin precio, tachados, cuentas regresivas ni "últimos cupos".
   - Sin resultados garantizados con plazo.
   - Sin testimonios ni marcas ajenas (logos de aerolíneas, apps o tiendas en las tomas).
   - Sin declarar IA. Sin mencionar otras redes.
   - El nombre del producto aparece en el video y en el título.
5. **Póster:** un cuadro del mockup con el nombre bien legible (`ffmpeg -ss <t> -i anuncio.mp4 -frames:v 1 poster.jpg`).

## Trampas reales (y cómo se resolvieron)

- **Suno responde "muchas solicitudes"** (`task_failed`) si mandas varios crops a la vez. Mándalos de a uno y reintenta tras 15 s.
- **Suno cambia palabras** ("go" → "let's go"). Por eso se transcriben siempre los 4 temas.
- **Las URLs de APIMART expiran en 24 h.** Descarga todo al momento y guarda los `task_id`: los necesitas para la letra alineada y para los crops.
- **Wan deforma después de ~3,5 s** en algunos clips. Revisa la hoja de cada ángulo.
- **Veo inventa extras.** Si tu casting tiene reglas (edad, origen, estilo), escribe cómo es CADA persona que aparece y no solo la protagonista. En el ejemplo hubo que rehacer 2 de 9 tomas por esto.
- **Veo mete franjas negras** dentro del 9:16. Recórtalas con `cropdetect` antes del `scale`.
- **El mismo ángulo dos veces seguidas** parece un salto. Hazlo primer plano cerrado o cambia de ángulo.
- **Los detectores de idioma** pueden marcar "mezcla de idiomas" por el "Hello, hello" del estribillo. No es un error si la letra está bien.
