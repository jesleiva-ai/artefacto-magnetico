# Notas: ejemplo UGC A-roll «Excel en 7 Días» (producto inventado)

## Resultado
- `anuncio.mp4`: 1080×1920, 37,1 s, CFR 30. 6 escenas de presentadora (Veo 3.1 fast, lip-sync) a 1,18x,
  6 insertos (5 capturas de planilla genéricas hechas a mano, sin costo, más el mockup dos veces),
  captions palabra a palabra, música Suno a −20 dB.
- Gancho: en el primer cuadro levanta 3 dedos y la caption dice «Hay… 3». Aparece la voz desde el cuadro 0.
- Campaña en el motor: `input/ej-ugc-excel/` (guion.json, ad-01.json). Clips en
  `public/media/_ugc/ej-ugc-excel/clips/`, música `foco-oficina`.

## Costo real (APIMART), unos $1,48
| Ítem | $ |
|---|---|
| Música Suno (2 tomas) | 0,05 |
| 1.ª corrida: escena 1 + cuadros + QC | ~0,17 |
| Reintento de la escena 1 lanzado por el QC roto y cortado a mitad (probablemente se cobró) | ~0,14 |
| 2.ª corrida: escenas 2-6 + B-roll Veo + cuadros + QC (facturado) | 0,84 |
| Mockup GPT Image 2 | 0,008 |
| Escena 1 rehecha (cuadro 0,008 + video y QC 0,14) | ~0,15 |
| Transcripciones del ensamblador (2 pasadas × 6) | ~0,12 |
Lo de arriba sale de los «Facturado real» de cada script más las estimaciones de cada paso (el saldo no sirve
si compartes la llave).

## Regeneraciones y arreglos
1. **El ffprobe de la máquina estaba roto.** Por eso el QC de `gen:aroll` reprobó la escena 1 (con resolución vacía)
   y la empezó a regenerar pagando. Corté el proceso y lo reemplacé por uno que funcionara. Con ffprobe roto la
   plantilla 2 no corre: verifícalo con `ffprobe -version` antes de gastar.
2. **Suno v4.5+ dado de baja en APIMART** → `.env` y `.env.example` de anunciante-supremo pasan a
   `APIMART_MUSIC_VERSION=v6` y el default de `scripts/lib/apimart.mjs` también.
3. **«3» sin caption** (Whisper devolvía «tres»). Arreglado en el motor: `scripts/lib/alinear.mjs` ahora
   normaliza los números en letras del 2 al 30 a cifra para alinear (sin «un/una/uno»). 90/90 tests en verde.
4. **Escena 1 con 4 dedos mientras dice «3».** Regeneré el cuadro inicial (lo revisé antes de pagar el
   video) con el gesto descripto dedo por dedo, y después el video. Ahora muestra 3 dedos durante todo el gancho.
5. **Escena 3: dice «la segunda» con un solo dedo.** No la regeneré: adelanté el B-roll de la tabla dinámica
   a «segunda» (dur 4,3 s) y lo tapa entero.
6. **B-roll de Veo (manos en la laptop) descartado**: la planilla tenía la cinta verde típica de Excel
   (identidad visual de Microsoft) y la persona llevaba otra ropa. Lo reemplazé por una pantalla propia
   («aviso: asistente administrativo → también se pide: fórmulas, tablas dinámicas, tableros») sobre «entrevista».

## QA
- QA automático: **0 🔴, 0 🟡** (LUFS −18,2, pico −0,5 dBTP, voz es p=0,98, 2,9 palabras/s, sin precio en OCR).
- Hoja `hoja.jpg` revisada: manos correctas en lo visible, dientes y ojos estables, sin texto deformado.
  Ningún logo ajeno. El mockup dice «Excel en 7 Días» bien escrito, sin logo de Microsoft.
- `verificar-t2.py`: 9/9 OK (orden de clips, 1,174x, tono conservado, música −20 dB, captions centradas y del tamaño
  correcto, CFR 30, 1080×1920).
- Pronunciación: la transcripción del anuncio final con faster-whisper coincide palabra por palabra con el guion. El
  nombre se oye entero: «Excel en siete días».
- Lip-sync: lo validé a ojo, revisando cuadros por escena (la boca abre al hablar y cierra en las pausas y al
  final, sin cortes de sincronía en las uniones). También probé una medición automática (apertura de labios con
  mediapipe contra la envolvente de la voz), pero no da un pico claro ni en los clips buenos. No sirve como veredicto.

## Compliance (skill compliance-checker, Meta, producto digital, anuncio de entrada): 8/10, listo para correr
| # | Punto | Estado |
|---|---|---|
| 1 | Atributos personales | PASS: ninguna pregunta ni afirmación sobre la situación del espectador |
| 2 | Lenguaje negativo/sensacionalista | PASS |
| 3 | Salud | N/A |
| 4 | Ingresos/empleo | WARN bajo: «te piden en casi cualquier entrevista de oficina» describe requisitos frecuentes, no promete trabajo ni sueldo. Se mantiene con «casi» |
| 5 | Antes/después | PASS |
| 6 | Loops abiertos | PASS: el gancho promete 3 cosas y las nombra las 3. El nombre del producto está en voz, mockup y copy |
| 7 | Palabras gatillo | WARN bajo: «te ahorra horas de calculadora cada semana» es una afirmación de beneficio sin matiz. En el copy escrito no aparece |
| 8-9 | Landing / coherencia | N/A (producto de ejemplo) |
- **WARN medio (propiedad intelectual):** «Excel» es una marca registrada. Nombrarla para describir lo que se enseña es
  aceptable, pero llevarla en el nombre del producto puede generar una denuncia de marca. Mitigaciones aplicadas:
  ningún logo, ícono ni interfaz de Microsoft en imagen. Para un producto real: aclarar «curso independiente, no
  afiliado a Microsoft» en la landing, o considerar un nombre sin la marca («Planillas en 7 Días»).
- Sin precio, sin tachados, sin urgencia, sin testimonios, sin declarar IA ni nombrar redes sociales.

## Lo que no quedó perfecto
- Hay leves diferencias de cara y pelo entre escenas: es lo esperable sin imagen de referencia, y el corte lo absorbe.
- La escena 4 dice «la tercera» con las manos juntas: el conteo con dedos solo aparece de verdad en el gancho.
- Las capturas de B-roll son limpias pero planas, tipo maqueta: no son una grabación de pantalla real.
