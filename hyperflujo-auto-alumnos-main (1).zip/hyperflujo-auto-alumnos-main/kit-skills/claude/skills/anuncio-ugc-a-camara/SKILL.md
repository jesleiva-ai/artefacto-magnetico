---
name: anuncio-ugc-a-camara
description: Arma un anuncio vertical 9:16 estilo UGC con una PRESENTADORA generada que habla a cámara con lip-sync, cosido con B-roll que entra justo sobre la palabra que ilustra, captions palabra a palabra, música baja y el mockup del producto al cierre. Usa la skill anunciante-supremo (plantilla 2) y la llave de APIMART. Úsala cuando el usuario diga "anuncio UGC", "anuncio con una persona hablando a cámara", "presentadora con lip-sync", "anuncio tipo creador de contenido para mi curso/ebook/plantilla", "quiero un anuncio con alguien explicando mi producto", o pida variantes de un anuncio UGC ya hecho.
---

# anuncio-ugc-a-camara — una presentadora creíble que explica tu producto

Resultado: un `.mp4` 1080×1920 de 25-40 s, listo para Reels / Facebook, más su copy para el
Administrador de anuncios. Motor: la **plantilla 2** de `anunciante-supremo` (Veo 3.1 en modo frame
con la voz adentro, cosido por ffmpeg). Todos los comandos se corren **dentro de la carpeta de la skill
anunciante-supremo** (normalmente `~/.claude/skills/anunciante-supremo`).

## Cuándo conviene este estilo
- El producto se entiende **explicándolo**: cursos, guías, plantillas, métodos. Una cara que mira a
  cámara frena el pulgar mejor que un B-roll suelto.
- Tienes 3-4 ideas concretas para mostrar en pantalla (lo que el producto enseña o entrega).
- **No conviene** si el producto es puramente visual (un pack de diseños: mejor B-roll + voz en off)
  o si el mensaje depende de un testimonio real (eso se graba con clientes reales, no se genera).

## La regla de oro: PRESENTADORA, nunca clienta
La persona generada **no existe**. Por eso nunca dice "yo lo usé", "a mí me funcionó", "conseguí X".
Habla como alguien que **presenta y explica**: "Hay 3 cosas que…", "La primera es…", "Lo aprendes
en…". Un testimonio inventado es engañoso y Meta lo castiga. Tampoco se declara IA ni se nombra
ninguna red social en el guion.

## Paso 0 — preguntas mínimas (si no tienes la ficha del producto)
1. ¿Qué es el producto y qué entrega exactamente? (formato, cantidad de lecciones/páginas, bonus)
2. ¿Para quién es y qué quiere lograr? (resultado, no condición personal)
3. ¿Qué 3 cosas concretas se pueden **mostrar** en pantalla?
4. Idioma y país del anuncio (define el acento y quién aparece).

## Paso 1 — el ángulo y el hook (leer `plantillas/hooks.md` de anunciante-supremo)
- Hook = **sujeto + lo que está en juego + número**. Ej.: "Hay 3 cosas de [tema] que te piden en
  casi cualquier [situación], y son más fáciles de lo que crees."
- Los tres hooks alineados: lo que **dice** la escena 1, lo que **hace** en el primer cuadro (ej.:
  levanta 3 dedos cuando dice "3") y la primera caption.
- Estructura que funciona en 6 escenas: **hook (lista de N) → ítem 1 → ítem 2 → ítem 3 → producto
  (nombre + formato) → entregable + CTA**. Cierra siempre los loops que abres: si prometes 3 cosas,
  nombra las 3.

## Paso 2 — el retrato forense (consistencia de la persona)
El generador de imágenes no recibe una foto de referencia: inventa a "alguien que encaje". La
consistencia sale de describir **todo**, idéntico palabra por palabra en cada escena:
- Edad, origen acorde al mercado, tono de piel, pelo (largo, textura, raya, cómo cae), cejas, ojos,
  nariz, labios, maquillaje, accesorios (uno o dos, pequeños), prenda exacta con color y cuello,
  "sin anillos ni reloj" (menos cosas = menos errores en las manos).
- **Escenario fijo** con objetos y dirección de la luz. Si aparece una laptop, que se vea **de
  costado con la pantalla fuera de cuadro y la tapa lisa sin logotipos**: así nunca muestra texto
  deformado ni marcas, y lo que hay "en la pantalla" lo pone el B-roll.
- Encuadre: "plano medio corto de frente, cámara a la altura de los ojos, teléfono vertical apoyado,
  estética UGC casera, ligero grano, sin iluminación de estudio". Look natural, nada de influencer.

## Paso 3 — escenas y diálogo (`input/<campaña>/guion.json`)
Esquema completo en `plantillas/plantilla-2.md`. Reglas que más importan:
- **Una frase por escena, ≤ 8 s hablados (16-20 palabras).** 6 escenas ≈ 30-35 s finales a 1,18x.
  Con 5 escenas cortas quedas por debajo de 25 s.
- **Números como cifra** (`3`, `15`, `7`). Ojo: el nombre del producto con número (`Excel en 7 Días`)
  se escribe igual en el diálogo, el brief y el copy.
- Frases directas, sin interjecciones sueltas al inicio ("¿Sinceramente? …" sale mal).
- **Una mano activa por escena** en `accion` y `final` (levantar dedos, señalar abajo). Dos acciones
  simultáneas = manos de más.
- `encadenar: true`: el último cuadro de una escena es el primero de la siguiente.
- Sin precio, sin "últimas horas", sin tachados, sin "¿estás desempleado/endeudado/…?".

## Paso 4 — B-roll sobre la palabra
- Cada concepto fuerte tiene **una palabra que lo nombra** ("fórmulas", "dinámicas", "tablero"): el
  inserto entra en esa palabra (`"sobre": "fórmulas", "escena": 2`).
- Nunca más de 4,8 s de cara sin inserto: con frases de ~5 s, un inserto por escena alcanza.
- **B-roll de pantalla hecho a mano (gratis y perfecto):** para productos de software/planillas/apps
  conviene renderizar tú las "grabaciones de pantalla" (Python + Pillow → ffmpeg, 1080×1920, 4-5 s):
  una interfaz **genérica** sin logos, con texto en el idioma del anuncio y datos coherentes (que la
  suma dé lo que dice el total). Deja **despejada la franja central** (≈ 820-1100 px de alto): ahí
  van las captions. Guárdalos como `brollN.mp4` en la carpeta de clips.
- B-roll generado (Veo, ~$0,08): solo para planos humanos (manos tecleando, escritorio). Pide
  "generic unbranded spreadsheet slightly out of focus, no logos" y **míralo**: si aparece un logo
  real, se descarta.
- Mockup del producto (`"imagen"`): entra al 80 % del ancho **sobre** la presentadora, cuando dice el
  nombre del producto y otra vez en el CTA (`"sobre": "Toca", "desfase": -0.3`). Genéralo con
  `gpt-image-2` (relación 4:5): laptop + lector digital + celular mostrando la portada con el nombre exacto,
  "no brand logos, no price, no people". Revisa que el texto salga bien escrito.
- No muestres la marca de un software ajeno (logo, ícono, interfaz reconocible). Nombrar la
  herramienta en la voz es descriptivo; mostrar su logo no.

## Paso 5 — comandos
> **Antes de gastar:** mostrale al dueño el guion, la cantidad de tomas y el costo estimado de la
> tanda, y esperá su OK en el chat. Recién con ese OK se corre con `--si` (desde Claude no hay
> terminal interactiva: `--si` es saltear la confirmación, y eso lo autoriza solo el dueño).

```bash
# 0. salud (ffmpeg, ffprobe, llave)
node scripts/doctor.mjs
# 1. música instrumental (una vez; se reusa por id)
npm run gen:musica -- --id foco --prompt "warm calm lo-fi acoustic pop, soft guitar and mellow keys, 92 BPM, dark mellow tone, gentle intro" --si
# 2. A-roll + B-roll generado + QC + brief borrador (muestra el costo; --si lo acepta)
npm run gen:aroll -- input/<campaña>/guion.json --si --regenerar
# 3. mirar los clips (hoja de contacto de cada escena)
ffmpeg -i public/media/_ugc/<slug>/clips/escena1.mp4 -vf "fps=1,scale=240:-1,tile=8x1" -frames:v 1 escena1-hoja.jpg
# 4. editar input/<campaña>/ad-01.json (insertos 'sobre', mockup, música) y armar
node scripts/ensamblar-t2.mjs input/<campaña>/ad-01.json
# 5. rehacer UNA escena que falla (otra línea más simple, o mismo texto)
rm public/media/_ugc/<slug>/clips/escena4.mp4
npm run gen:aroll -- input/<campaña>/guion.json --solo 4 --si --regenerar
node scripts/ensamblar-t2.mjs input/<campaña>/ad-01.json --forzar     # --forzar: re-transcribe
```

## Paso 6 — control de lip-sync y pronunciación
1. El QC de `gen:aroll` transcribe cada clip y exige ≥ 80 % de cobertura del diálogo. Lee la línea
   `sin caption:` — dice qué palabras no se oyeron.
2. **Transcribe el anuncio final** con Whisper (local `faster-whisper` o el de APIMART) y compáralo con
   el guion: el **nombre del producto** tiene que oírse entero y bien (`Excel en 7 Días`, no
   "Excel en siete" cortado ni "Exel"). Si se pronuncia mal, regenera esa escena; si persiste,
   escribe el nombre como se pronuncia solo en el diálogo del clip y deja la grafía correcta en
   caption/copy.
3. Mira cada escena a 1 cuadro por segundo: **boca que se mueve sin voz o voz con boca cerrada**,
   dientes que cambian, manos con 6 dedos, ojos que miran a otro lado, objetos que aparecen o
   desaparecen. Una escena con defecto se tapa con un inserto (`"en": <segundo>`) o se regenera.
4. Escucha el final: el modelo a veces agrega una frase después del CTA. El ensamblador corta tras la
   última palabra del guion, pero confírmalo.
5. Si tienes el arnés: `python scripts/verificar-t2.py out/<slug>.mp4 --brief input/<campaña>/ad-01.json --musica public/media/_music/music-<id>.mp3`.

## Paso 7 — controles de políticas (antes de subir)
- Sin precio ni tachados, sin cuenta regresiva ni escasez falsa.
- Sin promesas de empleo, sueldo, ascenso o ingresos ("te van a contratar" no; "te lo piden en
  entrevistas" sí, es una descripción).
- Sin preguntas o frases que asuman la situación del espectador (desempleo, deudas, salud, edad).
- Sin testimonios inventados; la persona presenta, no opina como clienta.
- Sin marcas ajenas en imagen; el nombre del producto visible (voz, mockup, copy).
- Cierra todos los loops que abre el hook.
- El copy de Meta: texto principal (qué es, qué entrega, formato), título con el nombre del
  producto, descripción corta, CTA "Más información". Pásalo por un chequeo de cumplimiento.

## Escalera de variantes (con el principal aprobado)
Con los mismos 6 A-roll + B-roll, sin generar nada:
1. **Principal** (~30 s).
2. **Corta** (~15 s): escena 1 + escena del producto + CTA.
3. **Solo B-roll** (`"modo": "solo-broll"`): la misma voz sobre capturas y mockup, sin cara.
4. **Otro orden**: abrir por el ítem más visual (el tablero) y dejar la lista para después.
Con gasto mínimo:
5. **Otro hook** (~$0,15): copia `escena1.mp4` a `escena1-hookA.mp4` y regenera solo la escena 1
   con otra primera frase ("La fórmula que te ahorra horas cada semana…").
6. **Otra presentadora** (~$1): mismo guion, otro retrato forense (otra edad / otro país).
Una variante = un solo eje cambiado. Nunca cambies oferta ni precio entre variantes.

## Trampas reales (pasaron haciendo el ejemplo)
- **ffprobe roto = QC que reprueba todo y regenera pagando.** Si el log dice `⚠️   · pico …` con la
  resolución vacía, no es el clip: es `ffprobe` que no corre. Corta el proceso (cada reintento cuesta
  ~$0,14) y arregla `ffprobe` con `node scripts/doctor.mjs` antes de seguir.
- **Suno cambió de versión:** si `gen:musica` responde 400 pidiendo `v6`, pon
  `APIMART_MUSIC_VERSION=v6` en el `.env` de anunciante-supremo (el `.env` pisa el valor del código).
- **"3" vs "tres":** la transcripción puede devolver el número en letras y esa palabra queda sin
  caption. Si pasa en una palabra clave, escribe en el `dialogo` del brief lo que realmente devuelve
  la transcripción, o acepta la palabra muda si es breve.
- **Los dedos mienten.** Pediste "levanta 3 dedos" y el cuadro sale con 4: el gancho dice una cosa y
  muestra otra. Describe el gesto con precisión ("índice, medio y anular extendidos; el pulgar sujeta
  el meñique doblado") y **mira el cuadro inicial** (`frames/escena1-ini.png`) antes de dar por buena
  la escena. Si un gesto sale mal a mitad de escena (dice "la segunda" con un solo dedo), lo más
  barato es tapar ese tramo con el B-roll de esa frase (anclarlo en la palabra anterior y alargar su
  `dur`); regenerar es la segunda opción.
- **El B-roll generado imita la interfaz real.** Pediste "planilla genérica" y salió una cinta
  verde idéntica a la de un programa conocido: es identidad visual de una marca ajena aunque no se
  vea el logo. Descártalo y usa la pantalla hecha a mano.
- **Insertos que se pasan del final:** si el último (el del CTA) supera la duración, el ensamblador
  lo recorta solo; es normal.
- `--regenerar` rehace el video pero **reusa los cuadros guardados** en `frames/`; si Veo bloquea por
  contenido, borra `frames/<escena>*` antes de regenerar.
- Al reemplazar un clip con el mismo nombre, arma con `--forzar` (si no, usa la transcripción vieja
  sin avisar).
- Los clips de Veo salen a 720×1280; el ensamblador los lleva a 1080×1920. No mezcles clips de otra
  resolución entre las escenas.

## Costo aproximado (APIMART)
| Pieza | Costo |
|---|---|
| 6 escenas A-roll (Veo 3.1 fast, 8 s) | ~$0,84 |
| 7 cuadros gpt-image-2 (retrato) | ~$0,06 |
| Transcripciones del QC | ~$0,06 |
| 1 B-roll humano (Veo lite + cuadro) | ~$0,08 |
| Música (Suno, 2 tomas) | $0,05 |
| Mockup gpt-image-2 | ~$0,01 |
| B-roll de pantalla hecho a mano | $0 |
| **Anuncio completo** | **≈ $1,10** · con 2-3 escenas regeneradas ≈ $1,50 |
