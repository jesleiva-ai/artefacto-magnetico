# Ejemplo 1 — estilo VIRAL (macro hiperreal + personajes animados) · «Pan de Casa»

Producto inventado: guía digital (PDF) de pan de masa madre. Español neutro con «tú».
Pieza: `anuncio.mp4` — 1080×1920, 30 fps, 37,1 s, −16 LUFS, voz ElevenLabs (velocidad 1,08), captions quemadas
palabra por palabra, música fija del estilo. Archivos de trabajo: `anunciante-supremo/input/ej-viral-pan/`
(armar.py → guion.json, mockup.mjs, montar.py). Lo generado (frames, clips, voces, ~70 MB) queda en
`public/media/_clips/ej-viral-pan/` y conviene guardarlo para hacer variantes sin pagar video de nuevo.

## Los 3 datos (verdaderos y verificables)
1. **Masa madre = harina + agua fermentando**: levaduras salvajes y bacterias lácticas del ambiente y la harina se
   multiplican en unos días y sueltan CO2, que llena la masa de burbujas.
2. **Prueba de la ventana**: una masa con el gluten bien desarrollado se estira en una membrana translúcida
   que deja pasar la luz; esa red elástica es la que atrapa el gas y da la miga esponjosa.
3. **Vapor en el horno**: el vapor condensa sobre la masa y mantiene la superficie húmeda y elástica los primeros
   minutos, retrasa la formación de la corteza y deja que el pan crezca más (*oven spring*); además da corteza brillante.

## Costo real (APIMART)
| Paso | $ |
|---|---|
| Mockup gpt-image-2 (1 intento, salió perfecto) | 0,01 |
| 1.ª corrida cortada (t01 con cartel en inglés: 2 imágenes + clip en modo frame ya encargado) | ~0,16 |
| Corrida completa (6 tomas: 3 en modo frame + 3 B-roll) | 0,67 |
| t03 rehecha en modo frame (2 imágenes; Veo la bloqueó 4 veces, el bloqueo no se cobra) | 0,02 |
| t03 en modo simple (1.ª versión) | 0,07 |
| t03 en modo simple con cara contenta (versión final) | 0,07 |
| **Total** | **≈ $1,00** |

Voz por ElevenLabs (no consume APIMART). Si compartes la llave con otros, el saldo no sirve para medir tu gasto: la
tabla sale de lo «Facturado real» de cada corrida y de la tarifa de lo que se cortó.

## Qué se regeneró y por qué
- **t01 (frasco)**: la primera imagen inicial traía un cartel grande en inglés («FLOUR + WATER = DOUGH PASTE») y una
  bolsa con «FLOUR». Corté la corrida y sumé al sufijo de estilo «absolutely no signs, no labels, no packaging with
  words, no written words…» (más un bol de harina en vez de la bolsa). Salió limpia.
- **t03 (horno), 1.ª versión**: traía un personaje de fuego y una gota de agua con cara, una dupla que recuerda
  demasiado a una película animada conocida. Rehíce el prompt («no fire or flame characters, no water drop
  characters»). Imágenes nuevas, limpias, pero **Veo bloqueó 4 veces el modo frame por «content safety»** (todo
  indica que el problema son los personajitos dentro de un horno caliente).
- **t03, modo simple**: imagen → video sin `fin` (la misma salida que usa el molde con su lista `SIMPLE`). La 1.ª tenía
  cara de susto/llanto del pan durante dos planos (imagen negativa, sin la transformación que la resuelve) → rehecha
  con cara de entusiasmo y el pan que crece. El resultado dorado del pan lo muestra el B-roll b03 (miga abierta).
- Poster: imagen final de t01 (el frasco desbordando de burbujas con personajes), sin captions.

## QA automático (resolución, duración, idioma de la voz, loudness, OCR)
- **0 🔴**. 🟢 1080×1920 · 37,1 s · voz detectada es · −16,1 LUFS · tono 134 Hz. OCR: solo «Pan de Casa /
  Guía de masa madre» y las captions; sin precio.
- Revisión visual de `hoja.jpg` (y de cada imagen de inicio y fin por separado): sin manos ni personas,
  sin texto deformado ni carteles, sin logos ni personajes ajenos reconocibles, portada del mockup escrita perfecta,
  captions legibles y sin tapar el nombre del producto. La voz y la caption «Ni» arrancan en el cuadro 0.
- Whisper transcribe «crear» donde la voz dice «criar» (es la transcripción del QA; las captions salen del guion y
  dicen «criar»).

## Compliance (skill compliance-checker, Meta, producto digital, anuncio en frío)
- Guion: 9 puntos en PASS (sin atributos personales, sin lenguaje negativo, sin salud ni ingresos, sin antes/después;
  los bucles abiertos se resuelven dentro del mismo video; marca visible).
- Copy: 1 LOW: la 1.ª línea del borrador («Ni se te ocurra hornear tu próximo pan sin conocer estos 3 trucos») dejaba un
  bucle abierto → reescrita como «3 trucos de ciencia del pan que parecen magia» + los 3 trucos listados. Puntaje final
  10/10 (antes del arreglo: 9,5).
- Reglas de la casa: sin precio, sin tachados ni urgencia, sin testimonios, sin resultado garantizado, sin declarar IA,
  sin mencionar otras redes, CTA al botón (sin «síguenos»).

## Lo que no quedó perfecto
- t03 no tiene la transformación en cámara (masa cruda → pan dorado) que sí tienen t01 y t02: Veo no la dejó pasar
  en modo frame. El pan crece y el B-roll muestra el resultado, pero el tercer caso es el menos «wow» visualmente.
- Los beats 2 y 3 repiten su toma (toma → B-roll → toma) porque la línea dura más de 2 × 4,2 s; con un B-roll extra por
  caso (+$0,08) se evitaría la repetición.
- Si `ffprobe` no corre en tu máquina (enlace roto, instalación a medias), el montaje y el QC fallan. Instálalo
  junto con ffmpeg (`brew install ffmpeg`, `winget install Gyan.FFmpeg` o `apt install ffmpeg`) antes de gastar.
- El mp4 pesa 50 MB (bitrate alto del montador); Meta lo acepta igual.
