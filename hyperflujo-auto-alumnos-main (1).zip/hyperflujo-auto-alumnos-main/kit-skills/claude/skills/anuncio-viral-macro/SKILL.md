---
name: anuncio-viral-macro
description: Crea un ANUNCIO vertical 9:16 estilo «viral macro» — foto macro hiperreal con personajes 3D animados originales viviendo adentro de la escena, guion de 3 casos con el gancho «Ni se te ocurra X, a menos que quieras Y», bucles abiertos entre caso y caso, y cierre con el mockup del producto + CTA al botón. Funciona como extensión de la skill anunciante-supremo (agrega el estilo `viral` a su montador). Úsala cuando el usuario diga "anuncio viral", "estilo viral macro", "anuncio con «ni se te ocurra»", "foto macro con personajes animados", "anuncio de 3 datos curiosos", "anuncio estilo reel de datos", "hazme un viral de mi producto", o invoque /anuncio-viral-macro.
---

# anuncio-viral-macro — 3 datos sorprendentes, macro hiperreal + personajes animados, cierre con producto

Un anuncio de ~30-40 s que se mira como un reel de curiosidades: **tres datos reales y verificables del
tema del producto**, cada uno presentado como una prohibición exagerada («Ni se te ocurra X, a menos que
quieras Y»), contados sobre **fotos macro hiperrealistas en las que viven personajes 3D caricaturescos
originales** que reaccionan exagerado. Cada dato se ve como una **transformación en cámara** (estado
inicial → estado final). Entre dato y dato hay **bucles abiertos** que retienen. Al final aparece el
**producto (mockup)** y el **CTA al botón**.

Requisitos: la skill `anunciante-supremo` instalada y funcionando (`node scripts/doctor.mjs` en verde),
tu llave `APIMART_API_KEY`, `ffmpeg` y `ffprobe`. `ELEVENLABS_API_KEY` es opcional (la voz sale mejor).
Todos los comandos se corren **dentro de la carpeta de anunciante-supremo**.

## Cuándo usarla
- El producto enseña algo (guía de cocina, curso, manual, método) y su tema tiene **datos o trucos
  sorprendentes y comprobables**: cocina, jardinería, mascotas, ciencia, finanzas personales, oficios,
  idiomas, deporte, bricolaje.
- Quieres un creativo que **se parezca a contenido orgánico** (curiosidades) y no a una publicidad,
  para frenar el pulgar en frío.
- No la uses si el tema no tiene 3 datos verdaderos y visualizables, ni para productos de salud
  con promesas de resultado (las prohibiciones exageradas rozan las políticas de salud).

## 1. Una sola vez: agregar el estilo `viral` al montador
> **Si instalaste `anunciante-supremo` desde este mismo paquete, el estilo `viral`, sus coletillas y
> `ELEVENLABS_SPEED` ya vienen agregados: verifica con el comando del final de esta sección y salta al paso 2.**
> Lo que sigue es para una versión base que no lo traiga.

La versión base de anunciante-supremo trae los estilos `claymation` y `zack`. Este estilo se agrega en
**`scripts/lib/montar-lib.mjs`** con dos cambios (no hace falta tocar otro archivo: `gen-clips`,
`gen-voz` y `montar` leen los estilos de ahí).

**a) En el objeto `ESTILOS`**, debajo de la línea de `zack`, agrega:
```js
  // viral: foto macro hiperreal + personajes animados adentro; planos un poco más largos para que
  // la transformación se vea entera. Usa la misma música fija de la plantilla 4.
  viral:      { speed: 1.12, gap: 0.16, volMusica: 0.141, musicaFija: "public/musica/zack-d-films.mp3", maxPlano: 4.2 },
```
(`maxPlano: 4.2` pisa el 3,0 por defecto: la transformación de cada toma necesita ~4 s para leerse.)

**b) Debajo del objeto `COLETILLAS`** (después de su `};`), agrega el bloque:
```js
COLETILLAS.viral = {
  imagen: "hyperrealistic macro photograph with real-world textures and lighting, combined with one or more exaggerated ORIGINAL cartoon characters in the style of a modern 3D animated feature film living inside the real scene, big expressive eyes and faces, over-the-top exaggerated scale and emotion, vivid saturated colors, dramatic studio lighting, razor sharp detail, shallow depth of field, no added captions, subtitles, watermarks or overlaid graphics, no interface elements. Vertical 9:16 portrait format, a tall vertical composition framed for a mobile phone screen, taller than it is wide.",
  video: "Hyperrealistic macro footage with exaggerated original 3D-animated cartoon characters, over-the-top expressive animation, satisfying dramatic physics, dynamic energy. Animation must start at the first frame. No text, no captions, no subtitles, no watermark, no user interface elements anywhere in the frame.",
  videoFrame: "Hyperrealistic macro footage with exaggerated original 3D-animated cartoon characters, a dramatic and satisfying physical transformation from the first frame to the last frame, same camera angle and framing, over-the-top expressive animation. Animation must start at the first frame. No text, no captions, no watermark, no user interface elements.",
};
```
Las coletillas van **tal cual, sin parafrasear**: son las que fijan el look (macro real + personaje animado).

**c) Opcional — velocidad de la voz de ElevenLabs.** En `scripts/lib/voz.mjs`, dentro de
`voice_settings` de la llamada a ElevenLabs, agrega `speed: Number(process.env.ELEVENLABS_SPEED || 1)`.
Con `ELEVENLABS_SPEED=1.08` la voz suena más ágil (el estilo lo pide). Sin este cambio funciona igual.

**Verificar:** `npm test` sigue en verde y
`node -e "import('./scripts/lib/montar-lib.mjs').then(m=>console.log(m.configDeEstilo('viral')))"` imprime la config.

## 2. El guion (lo que hace que funcione)
Estructura fija de 5 líneas de voz (≈ 130-145 palabras → 32-38 s finales a 1,12x):

| Línea | Qué dice | Qué se ve |
|---|---|---|
| 1 — **gancho + caso 1** | «Ni se te ocurra [acción concreta del tema], a menos que quieras [resultado sorprendente]: [explicación en 1 frase].» | toma t01 (transformación) + B-roll b01 |
| 2 — **bucle + caso 2** | «**Pero eso no es nada.** No [acción], a menos que quieras [resultado]: [explicación].» | t02 + b02 |
| 3 — **bucle + caso 3** | «**Y el último es el más loco:** ni se te ocurra [acción], a menos que quieras [resultado]: [explicación].» | t03 + b03 |
| 4 — **producto** | «Esto, y [lo que enseña el producto], está en [PRODUCTO]: [qué es y qué trae, con un número].» | mockup (plano general → acercamiento a la portada) |
| 5 — **CTA** | «Toca el botón y descárgalo hoy.» (o el verbo que corresponda) | portada en grande |

Reglas del guion:
- **El gancho es la línea 1 y arranca con «Ni se te ocurra»** desde el primer segundo, con el sujeto del
  nicho adentro (harina, masa, planta, perro, tarjeta…). Pasa el checklist de `plantillas/hooks.md`.
- La «Y» de «a menos que quieras Y» es algo **deseable o asombroso**, no una amenaza: la prohibición es
  un juego, el remate es una recompensa. Nunca miedo, daño ni salud.
- **Los 3 datos tienen que ser verdaderos y verificables** (física, química, biología, historia del
  oficio). Anota la fuente de cada uno en el guion. Si no puedes comprobarlo, no va.
- Ordénalos de menos a más sorprendente: el bucle «el último es el más loco» tiene que cumplirse.
- Habla en «tú»; **nada de «¿estás…?», «si tienes…», «si eres…»** (atributos personales).
- **Sin precio, sin tachados, sin «solo hoy» / cuentas regresivas, sin testimonios, sin promesas de
  resultado garantizado.** El CTA empuja al botón; nada de «síguenos» (es un anuncio, no un orgánico).
- Números como cifra (`60`, no «sesenta»): así casan con las captions.
- Presupuesto: mínimo 30 s. Estima `segundos × 2,4 palabras`; la duración real la da el mp3.

## 3. Los prompts (en inglés)
Cada caso tiene **toma en modo frame** (imagen inicial + imagen final → Veo anima la transformación) y
**un B-roll** (una imagen animada). El mismo prompt vale para el inicio y el fin: **la escena es la
misma y solo cambia el estado**.

- `imagen` (inicio): objeto real del tema en macro + **una carita animada exagerada en el objeto** +
  ambiente concreto (mesada, jardín, taller) + luz. Ej.: *"A glass jar on a rustic wooden kitchen
  counter holding a flat thick paste of flour and water with a sleepy bored cartoon face on its surface…"*
- `fin`: *"The same [objeto] on the same [lugar], now [estado transformado]…, [cara con emoción
  opuesta]"*. Empieza siempre por «The same…».
- `video`: `Camera locked off. Motion: <la transformación en una frase>` (en frame la cámara no se mueve).
- B-roll `imagen`: *"Extreme macro of …, tiny cartoon [personajes] doing [acción que explica el dato]"*;
  `video`: `Camera: slow push-in. Motion: <una acción>`.
- **Sufijo de estilo** que se suma a cada `imagen` y `fin` (además de la coletilla del montador):
  ```
  , the scene crowded with several extra small Pixar-style cartoon characters with big eyes reacting with over-the-top exaggerated expressions, ultra saturated colors, no people, no human hands, every character an original design, no characters from existing movies, games or brands, absolutely no signs, no labels, no packaging with words, no written words or letters anywhere in the image
  ```
  y a cada `video`: `, constant energetic motion, every cartoon character moving and reacting the whole time`.
- **Personajes originales siempre**: el generador de imágenes tiende a meter personajes conocidos de
  películas (peces payaso, robots famosos, emociones con colores). El sufijo lo prohíbe; si igual
  aparece uno, **cambia el objeto** (no uses peces, robots ni juguetes) y regenera.

Esquema de `input/<campaña>/guion.json` (el de la plantilla 3 con `"estilo": "viral"`):
```json
{
  "title": "Viral — <producto>", "slug": "<campaña>", "estilo": "viral", "idioma": "es",
  "voz": { "elevenlabs": { "voiceId": "<tu voz>" } },
  "lineas": [
    { "n": 1, "texto": "Ni se te ocurra …", "toma": "t01", "broll": "b01" },
    { "n": 2, "texto": "Pero eso no es nada. …", "toma": "t02", "broll": "b02" },
    { "n": 3, "texto": "Y el último es el más loco: …", "toma": "t03", "broll": "b03" },
    { "n": 4, "texto": "Esto, y …, está en <PRODUCTO>: …", "toma": "t03", "broll": "b03" },
    { "n": 5, "texto": "Toca el botón y descárgalo hoy.", "toma": "t03", "broll": "b03" }
  ],
  "tomas": [ { "id": "t01", "imagen": "<inicio + sufijo>", "fin": "<The same… + sufijo>", "video": "Camera locked off. Motion: … + sufijo de video" } ],
  "broll": [ { "id": "b01", "imagen": "<macro + sufijo>", "video": "Camera: slow push-in. Motion: … + sufijo de video" } ]
}
```
(Las líneas 4 y 5 declaran t03/b03 solo para que el guion valide; en el paso 6 se cambian por el mockup.)

## 4. Paso a paso
> **Antes de gastar:** mostrale al dueño el guion, la cantidad de tomas y el costo estimado de la
> tanda, y esperá su OK en el chat. Recién con ese OK se corre con `--si` (desde Claude no hay
> terminal interactiva: `--si` es saltear la confirmación, y eso lo autoriza solo el dueño).

```bash
# 0) desde la carpeta de anunciante-supremo, con tu llave en el entorno o en .env
node scripts/doctor.mjs

# 1) voz primero (barata): confirma que dura ≥ 30 s antes de gastar en video
ELEVENLABS_SPEED=1.08 npm run gen:voz -- input/<campaña>/guion.json --si
for f in public/media/_clips/<campaña>/voz/l*.mp3; do ffprobe -v error -show_entries format=duration -of csv=p=0 "$f"; done
#    suma ÷ 1,12 + ~1,3 s ≥ 30 → sigue; si no, alarga las explicaciones.

# 2) tomas y B-roll (3 en modo frame + 3 simples ≈ 20-25 min; reanudable)
npm run gen:clips -- input/<campaña>/guion.json --si

# 3) MIRA las imágenes de public/media/_clips/<campaña>/frames/ (inicio y fin de cada toma)
#    y un cuadro de cada clip antes de seguir (ver «Controles»).
```

**4) Mockup del producto** (una imagen con gpt-image-2, ≈ $0,01). Guarda esto como
`input/<campaña>/mockup.mjs` y córrelo con `node input/<campaña>/mockup.mjs`:
```js
import { writeFileSync, mkdirSync } from "node:fs";
import * as apimart from "../../scripts/lib/apimart.mjs";
const dir = new URL("../../public/media/_clips/<campaña>/frames/", import.meta.url).pathname;
mkdirSync(dir, { recursive: true });
const prompt = `Hyperrealistic product mockup photograph, vertical 9:16. A modern e-reader standing upright on <superficie del nicho>, its screen showing the cover of a digital <tipo de producto>. The cover is clean and elegant: <imagen de tapa>, the title "<NOMBRE>" in large elegant letters at the top, and below it a smaller line "<subtítulo corto>". Exactly those words and no other text on the cover. Next to the e-reader: <2-3 objetos reales del tema>. Two small original cute Pixar-style cartoon characters <del tema> with big happy eyes peeking from behind <objeto>, original designs, not from any existing movie or brand. Soft window light, shallow depth of field, warm saturated colors. No people, no hands, no logos, no brand names, no price, no other text anywhere, no watermark.`;
const r = await apimart.generarImagen({ prompt, aspectRatio: "9:16" });
writeFileSync(`${dir}m01.png`, await apimart.descargar(r.url));
console.log("costo", r.cost);
```
Abre `m01.png`: el título tiene que estar **perfecto, letra por letra**. Si no, regenera (máximo 2-3 intentos;
títulos cortos de 2-3 palabras salen bien casi siempre).

**5) Animar el mockup sin IA** (gratis y el texto de la portada no se deforma): dos clips con zoom lento.
Ajusta `x`/`y` del segundo para centrar la portada (0,62 / 0,33 = portada arriba a la derecha).
```bash
cd public/media/_clips/<campaña>
ffmpeg -y -loop 1 -i frames/m01.png -vf "scale=2160:3840,zoompan=z='1+0.0006*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=240:s=720x1280:fps=30,format=yuv420p" -t 8 -c:v libx264 -crf 18 clips/m01.mp4
ffmpeg -y -loop 1 -i frames/m01.png -vf "scale=2160:3840,zoompan=z='1.25+0.0012*on':x='iw*0.62-(iw/zoom/2)':y='ih*0.33-(ih/zoom/2)':d=240:s=720x1280:fps=30,format=yuv420p" -t 8 -c:v libx264 -crf 18 clips/m02.mp4
cd -
```

**6) Plan de montaje.** `gen:voz` dejó `input/<campaña>/ad-01.json`. Edita los `planos` de los dos
últimos beats: línea 4 → `[["m01"], ["m02"]]`, línea 5 → `[["m02"]]`. Los tres primeros quedan
`[["tNN"], ["bNN"]]`.

**7) Montar:**
```bash
npm run montar -- input/<campaña>/ad-01.json --salida out/<campaña>/anuncio.mp4
```
Sale a 1080×1920, 30 fps, captions quemadas, música fija del estilo de fondo, −16 LUFS.

## 5. Controles de calidad (antes de entregar)
1. **Técnico:** `ffprobe` → 1080×1920, ≥ 30 s; la voz arranca en el primer segundo.
2. **Hoja de cuadros** para revisar todo de un vistazo:
   ```bash
   ffmpeg -i out/<campaña>/anuncio.mp4 -vf "fps=1/2,scale=270:-1,tile=6x4" -frames:v 1 -y out/<campaña>/hoja.jpg
   ```
   Mírala entera buscando: **manos o caras deformes, personas en primer plano,
   texto grande deformado o en otro idioma, logos o personajes conocidos**, la portada del mockup bien
   escrita, planos negros o congelados. Lo que falle se regenera (ver Trampas).
3. **Audio:** escucha completo. Que no se coma palabras ni el CTA; que la música no tape la voz.
4. **Captions:** legibles, sincronizadas, sin palabras mudas, que no tapen el nombre en la portada.
5. **Políticas de Meta (repasa guion Y copy):** sin precio; sin tachados ni urgencia falsa; sin
   resultados garantizados; sin testimonios inventados; sin atributos personales («¿estás…?», «si
   tienes…»); sin marcas ni personajes ajenos; no declarar que está hecho con IA; no mencionar otras
   redes sociales. La primera línea del texto principal **no deja un bucle abierto** (resuélvelo:
   «3 trucos de X: A, B y C»). Si tienes una skill de compliance, córrela sobre guion y copy.
6. **Copy de Meta** junto al video: texto principal, título (≤ 40 caracteres), descripción, CTA
   (`DOWNLOAD`/«Descargar» si el verbo de la voz es descargar; si no, `LEARN_MORE` o `SHOP_NOW`).

## 6. Trampas conocidas
- **`--regenerar` rehace el video pero reusa la imagen** guardada en `frames/<id>.png/.json`. Si una
  imagen salió mal o Veo la bloqueó, **borra antes `public/media/_clips/<campaña>/frames/<id>*`** y
  después `npm run gen:clips -- input/<campaña>/guion.json --solo <id> --regenerar --si`.
- **Veo bloquea por «content safety»**: jeringas, personas en primer plano, manos sosteniendo objetos,
  líquidos rojos tipo sangre, armas. Reescribe la escena para que la acción la hagan **los personajes
  animados**, no manos humanas (ej.: personajitos estiran la masa en vez de unas manos).
- Si una toma en modo frame la bloquea 2+ veces: sácale el `fin` (pasa a imagen → video simple) y
  quítale el sufijo de multitud.
- **Personajes de películas** que se cuelan (peces, robots, muñecos): cambia el objeto, regenera la imagen.
- **Carteles y etiquetas**: sin la cola «no signs, no labels…» el generador suele inventar un cartel
  grande en inglés que explica la escena, o una bolsa con la palabra del ingrediente. Va siempre en el sufijo.
- **Escenas de calor con personajes** (horno, sartén, fuego): Veo las bloquea seguido en modo frame
  (personajitos «dentro» de un horno caliente). Pasa esa toma a modo simple con una cara contenta, o
  muestra el resultado ya horneado afuera del horno.
- **Pares fuego + agua con cara** recuerdan a una película animada conocida: pide que no haya personajes
  de fuego ni gotas de agua con cara.
- **Caras de miedo o llanto**: si la toma queda en modo simple (sin el «fin» que la resuelve), la cara
  inicial es lo único que se ve. Que sea de entusiasmo; una cara asustada durante 6 s se lee negativa.
- **Texto basura en las imágenes**: las coletillas lo prohíben, pero si aparece letrero o etiqueta
  grande, regenera esa imagen. Nunca pidas texto en las tomas; el único texto es la portada del mockup.
- **El mockup NO se pasa por Veo**: anima la portada y deforma el nombre. Zoom con ffmpeg.
- **Voz que se come el CTA**: `gen:voz` lo detecta y reintenta; si persiste, deja el CTA como línea
  propia y corta (como en la estructura de arriba).
- **Un plano pide más segundos de los que tiene el clip** («necesita X s y solo tiene Y»): agrega otro
  plano al beat (repite la toma) o acorta la línea.

## 7. Costo aproximado (APIMART)
| Ítem | Cantidad | Costo |
|---|---|---|
| Imágenes de tomas (inicio + fin) y B-roll | 9 × ~$0,0085 | ~$0,08 |
| Clips en modo frame (veo3.1-fast) | 3 × $0,14 | $0,42 |
| Clips de una imagen (veo3.1-lite) | 3 × $0,07 | $0,21 |
| Mockup (gpt-image-2) | 1-2 | ~$0,01-0,02 |
| Voz | ElevenLabs (tu plan) o APIMART ~$0,01 por línea | ~$0,05 |
| **Total** | | **≈ $0,75-0,80** por anuncio; cada toma que se regenera suma $0,07-0,16 |

Tarda ~30 min de punta a punta (casi todo es la espera de Veo). Los clips no tienen idioma adentro:
**otro idioma = otra voz + otro mockup + volver a montar**, sin generar video nuevo.
