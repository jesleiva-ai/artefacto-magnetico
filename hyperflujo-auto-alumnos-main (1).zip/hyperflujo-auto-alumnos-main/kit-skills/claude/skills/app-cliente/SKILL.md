---
name: app-cliente
description: RECETA para montar y operar un servicio de videos publicitarios para CLIENTES en 5 pasos — link general con formulario, investigación, página propia de cada cliente donde arma su tanda (estilos, imágenes, look, guiones), producción y entrega en Drive con editables y correcciones. Explica qué piezas tenés que construir y cómo se opera cada paso cuando el cliente manda su BRIEF, su PERSONALIZACIÓN o sus CORRECCIONES por WhatsApp. Usar cuando digas "quiero montar el servicio de videos para clientes", "arrancá con un cliente nuevo", "el cliente mandó el formulario", "armale la página del paso 3", "/app-cliente", o pegues un texto que empiece con "BRIEF ·" o "PERSONALIZACIÓN ·".
---

# La app del cliente: receta del servicio

> **Esto es una receta, no una skill lista para correr.** El original funciona
> sobre un motor de video propio que no viaja en este paquete. Acá tenés el
> circuito completo y la lista de lo que hay que construir; la primera vez que la
> uses, pedile a Claude que arme con vos cada pieza de la sección «Qué tenés que
> montar» y anotá las rutas reales en `config.md` al lado de este archivo.

El cliente hace sus videos en 5 pasos: (1) formulario + carpetas de Drive,
(2) investigamos, (3) arma su tanda: cantidad, estilos, imágenes, look, guiones,
(4) producimos, (5) entrega en Drive + editables + correcciones.

## Qué tenés que montar

| Pieza | Qué hace | Cómo armarla |
|---|---|---|
| **Generador de la app** (`app_cliente.py` + una plantilla HTML) | Arma una página estática por cliente con los 5 pasos. Con `--general` sale el paso 1 solo; con la carpeta de un cliente sale su página desde el paso 3 | Pedile a Claude una página HTML de una sola pantalla por paso, sin backend, que guarde lo cargado en `localStorage` y termine cada paso en un botón «Enviar por WhatsApp» con un texto que empiece con una marca fija (`BRIEF ·`, `PERSONALIZACIÓN ·`, `CORRECCIONES ·`) |
| **Landing del servicio** | La página que ve un cliente nuevo, con el formulario del paso 1 adentro | Sale de la misma plantilla. Si cambiás las preguntas del formulario, regenerala |
| **Ficha del producto** (`~/creativos/<slug>/producto.json`) | Todo lo que se sabe del cliente: link, mockup, logo, voz, música, look, país, lo que no se puede prometer | Un JSON con claves fijas; lo llena la investigación |
| **Banco de clips** (`indice-brolls.json`) | ~30 clips por cliente (los suyos + stock con licencia + tomas generadas), cada uno auditado | Ver la skill `de-link-a-creativos`, paso 4 |
| **Lector de la personalización** (`personalizar.py aplicar`) | Lee el texto de WhatsApp y lo escribe en la ficha: clips que el cliente marcó «No va», su look y la TANDA (`{"videos": N, "estilos": {id: cantidad}}`) | Script que falla cerrado: si falta una marca del texto, no aplica nada |
| **Motor de render** | Produce cada pieza desde guion + ficha + banco | La skill `anunciante-supremo` de este paquete, o ffmpeg / Remotion |
| **Estado de correcciones** | Ver la receta `corregir-cliente` | — |

Las páginas se publican como artifacts de Claude. Un artifact nuevo nace privado:
**el dueño lo revisa y lo comparte «cualquiera con el enlace» desde su menú antes de
mandarlo** (nunca lo cambies vos), o al cliente le aparece bloqueado.

## Paso a paso

**1 · Cliente nuevo.** Pasale el link de la landing con el formulario. Si tenés su
número de WhatsApp, regenerá la página con él para que el botón abra tu chat
directo (sin número, WhatsApp le pide elegir el chat).

**2 · Llega «BRIEF · <dominio o producto>».** El paso 1 pide lo mínimo: **solo el
link de su página es obligatorio**; mockup y logo «recomendado»; clips, un video
que ya funcionó, guiones y observaciones opcionales; voz y música en un
desplegable. **Todo lo demás se saca de su página** con la skill
`de-link-a-creativos` (pasos 1-3): nombre, precio, qué trae, garantía, a quién le
habla, colores de marca, competidores y lo que NO se puede prometer. Si no mandó
mockup, recortá el de su página. Creá la carpeta del cliente y su ficha, bajá sus
carpetas de Drive y armá el banco de clips. Si en «Observaciones» dice el país,
manda sobre el que se deduce de la página.

**3 · Abrirle el paso 3.** Generá su página propia y publicala como artifact NUEVO
para ese cliente. **Guardá su URL** en `~/creativos/<slug>/app.json`
(`{"url": …, "etapa": 3, "fecha": …}`): de acá en más se republica siempre en esa
misma URL. Compartila y mandale el mensaje. En esa página los pasos 1 y 2 aparecen
hechos.

**4 · Llega «PERSONALIZACIÓN · <PRODUCTO>».** Guardalo en un .txt y aplicalo con el
lector. Si el lector avisa que una elección todavía no la lee el motor, esa
elección NO saldría en el video: frená y resolvelo antes de producir. Los textos
de guion, gancho, cierre y tono van al armado de guiones.

**5 · Producir** la tanda según la personalización. Aprobación interna antes de
tocar el Drive del cliente (receta `corregir-cliente`, pasos 5 a 7).

**6 · Entregar.** Regenerá la página con el estado de correcciones y republicala en
la MISMA URL. El cliente ve el paso 5: carpeta de videos, editables, guía, y opina
video por video. **Los editables de CapCut van siempre con su tutorial** de
instalación (botón en la página + un documento en la misma carpeta de Drive).

**7 · Llega «CORRECCIONES · <PRODUCTO> · RONDA N».** Receta `corregir-cliente`.
Al cerrar la ronda, regenerá y republicá en la misma URL.

## Lo que decidís vos (no inventarlo)

Cuántos videos trae cada cliente y cuánto cuesta, cuántas rondas de correcciones
entran, el nombre de la app y el número de WhatsApp.

## Lo que hace fallar esto

- Publicar sin compartir: al cliente le aparece bloqueado.
- Crear una página nueva en vez de republicar la del cliente: pierde lo que venía
  cargando (el navegador guarda por página). Siempre la URL de `app.json`.
- Generar la página del paso 3 antes de tener el banco de clips.
- El texto que llega por WhatsApp puede venir cortado: si falta una marca o la
  ficha, pedile que lo reenvíe.
