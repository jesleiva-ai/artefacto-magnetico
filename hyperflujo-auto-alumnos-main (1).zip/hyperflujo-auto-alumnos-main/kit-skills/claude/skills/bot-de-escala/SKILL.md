---
name: bot-de-escala
description: Arma, prueba y opera el bot de escala del dueño con el método de surfeo de presupuesto por franja horaria — (1) analiza 7 días de gasto de Meta por hora contra ventas COBRADAS por hora en cada mercado y mide cuánto tarda en impactar un cambio de presupuesto, (2) arma el bot según la estructura (CBO: presupuesto de campaña · ABO: presupuesto por conjunto · Cost Cap / Bid Cap: escalera de puja) con una BASE por campaña, protecciones y simulacro obligatorio, y (3) lo opera y lo mejora todos los días con el dueño. Usar cuando el dueño diga /bot-de-escala, "quiero que mis campañas escalen solas", "armá el bot de escala", "analizá mis ventas por hora", "a qué hora tengo que subir el presupuesto", "cómo viene el bot", "revisemos el día", "cambiá la base de X", "pausá el bot", o cuando una oferta ya rentable quiera escalar sin depender de que el dueño esté despierto. Solo para ofertas validadas que ya venden todos los días. Jamás activa el bot ni mueve plata real sin el OK del dueño después de ver el simulacro.
---

# /bot-de-escala — surfear el presupuesto por franja horaria

**Por qué existe.** Las ventas no se reparten igual en las 24 horas: hay franjas donde la gente compra mucho
más. Si dependés de estar despierto para subir el presupuesto, llegás tarde todos los días a las mejores
horas. El bot llega a la franja buena con la inversión ya escalada, confirma con las ventas cobradas de hoy,
sube solo lo que ya vende en el pico y baja antes de que la franja se enfríe. Responde **todo el día**, no
solo de madrugada.

**Exclusivo para ofertas validadas y rentables.** El bot escala lo que ya funciona: no encuentra un ganador
ni arregla una oferta que no vende. Si el dueño todavía está testeando, decíselo en una línea y frená acá.

Si el dueño tiene una guía o clase anterior del bot, lo que dice esta skill le gana: el bot ya no trabaja
solo de madrugada, usa una base por campaña y prueba quedarse escalado a la tarde.

En Windows usá `py -3` donde abajo dice `python3`.

## La línea roja

- **Nada se mueve en Meta hasta que el dueño vea el simulacro y diga que sí.** Ni la primera vez, ni después
  de cambiar una regla, una base o un techo. Leer se hace sin preguntar; escribir, con OK.
- Las únicas excepciones son las **pruebas pre-aprobadas** que el dueño dejó escritas en su
  `INSTRUCCIONES.md`, siempre dentro de los techos.
- El bot toca **solo** la lista fija de campañas o conjuntos de su `config.json`. Lo que el dueño pausó, no
  lo prende.

## La mentalidad (leela antes de proponer números)

- **Claude por defecto es conservador, y acá eso cuesta plata.** En productos digitales casi no hay costo
  por unidad: con un ROAS apenas arriba del empate (muchas veces cerca de 1,3) ya se gana. El empate exacto depende de las comisiones del dueño:
  **pedíselas** y calculalo (empate = 1 ÷ (1 − comisiones totales)). El **piso del dinero extra** (el ROAS
  mínimo que tiene que dar lo que se invierte arriba de la base) es el empate más un margen chico que elige
  el dueño.
- **Animate a escalar más fuerte, con freno.** El freno y el control por tramo son los que permiten ser
  agresivo sin miedo: si una suba no responde, en 2 o 3 horas vuelve. Se pierde un rato de gasto, no un día.
- **Ningún día solo es verdad absoluta.** «Con más gasto bajó el ROAS» medido una vez no es veredicto. Decidí
  mirando varios días, y decí siempre con cuántas ventas sostenés cada conclusión.
- **Lo que funciona 2 días o más se vuelve regla** y se anota en la bitácora del `INSTRUCCIONES.md`.

## Fase 1 · Análisis de 7 días (solo lectura)

Nada de esto cambia Meta. Juntá:

1. **Gasto de Meta por hora y por campaña**, últimos 7 días completos: endpoint de insights de cada cuenta
   (el ID de la cuenta con su prefijo de siempre) con `level=campaign`, `time_increment=1` y
   `breakdowns=hourly_stats_aggregated_by_advertiser_time_zone`. Todas las cuentas del dueño. Anotá el huso
   de cada cuenta (`timezone_name`): **todas las horas del bot van en el huso de la cuenta publicitaria**.
2. **Ventas COBRADAS por hora**, mismos 7 días, de la plataforma de cobro del dueño (preguntale cuál y cómo
   darte acceso de solo lectura). Nunca el píxel como fuente. Las compras adicionales (upsells) suman al
   cobrado pero no cuentan como venta. Restá reintegros y disputas para la ganancia.
3. **Historial de cambios de presupuesto** de esos días: endpoint `activities` de la cuenta, eventos
   `update_campaign_budget` y `update_ad_set_budget`.

Entregá, por mercado (o por campaña si no separa por mercado):

- **A.** Por bloque de 3 horas: gasto, ventas, cobrado, ROAS y ganancia (cobrado − comisiones − gasto).
- **B.** Qué parte de las ventas del día entra en cada bloque.
- **C.** Hora por hora: ventas y ROAS. Marcá la **hora en que arrancan las ventas**, las horas pico y la
  hora en que **se enfría**.
- **D.** Consistencia: día por día, el ROAS de la franja buena y en cuántos de los 7 días superó el piso.
- **E.** **Tiempo de impacto**: por cada cambio de presupuesto, el gasto por hora de las 2 horas antes y las
  4 después. (Referencia que hay que verificar en cada cuenta: una suba suele notarse en la misma hora y
  llegar a pleno en 1 o 2 horas; un recorte frena igual de rápido.)
- **F.** Si con más gasto el ROAS bajó (días de más gasto contra días de menos), con la advertencia de que
  pocos días no alcanzan.

Y en lenguaje simple: a qué hora arrancan las ventas en cada mercado y cuál es su mejor franja; a qué hora
hay que subir para llegar escalado (hora de arranque menos el tiempo de impacto); cuándo se enfría cada uno;
qué mercados merecen escala fuerte y cuáles no, con el porqué en números; qué tan confiable es todo según la
cantidad de ventas. Marcá qué verificaste contra la API y qué es estimación. Un detalle que conviene
explicar: el gasto no crece en la misma proporción que el presupuesto, porque Meta reparte el presupuesto
nuevo entre las horas que le quedan al día. Por eso conviene subir temprano y fuerte, no tarde y de a poco.

**Listo cuando:** el dueño vio el análisis y quedó anotado en la sección 3 de su `INSTRUCCIONES.md`.

## Fase 2 · Armar el bot

### 2.1 · Preguntas, todas juntas en un solo mensaje

1. **¿Dónde vive el bot?** En su computadora (gratis, pero tiene que quedar prendida, enchufada y sin
   suspenderse **todo el día**, porque el bot trabaja de la madrugada al cierre) o en la nube: un **VPS**
   (servidor alquilado, el más puntual) o **GitHub Actions** (gratis, sin servidor, pero a veces arranca
   tarde o saltea una vuelta). Si no sabe, recomendá el VPS para algo que mueve plata, o la computadora si
   recién empieza y la puede dejar prendida.
2. **Estructura:** CBO, ABO, Cost Cap / Bid Cap (puede ser una mezcla).
3. **La lista fija** de cuentas y de campañas o conjuntos que el bot puede tocar. Ninguna más.
4. **Fuente de ventas cobradas** y **plan B** si no responde: no subir nada (recomendado) o decidir con el
   píxel, que suele marcar menos ventas que las reales y por eso es más exigente.
5. **Comisiones totales** (para el empate) y **ticket de entrada** (los gastos mínimos de las reglas van en
   tickets, así sirve para cualquier moneda).
6. **Base y techo de cada campaña** (ver 2.3) y **agresividad** (ver 2.5).
7. **¿Informe en Telegram?** Recomendado: le llega al celular en cada vuelta.

**Listo cuando:** tenés todas las respuestas.

### 2.2 · El día del bot

Las horas salen del análisis, una por mercado cuando hace falta. «Tu hora de arranque» es la hora en que
empiezan las ventas de ese mercado.

| Momento | Vuelta (`tipo` en config) | Qué hace |
|---|---|---|
| Tu hora de arranque − tiempo de impacto | Madrugada (`suba_fuerte`) | Pone cada campaña en su **base** (si amaneció inflada, la baja a la base). Si ayer rindió y los últimos 3 días no fueron malos, **sube fuerte** antes de que arranquen las ventas: a esa hora todavía no hay ventas del día, así que decide con el historial. |
| Mañana | Confirmación (`confirma`) | Sube otro escalón si **hoy** ya junta suficientes ventas cobradas con buen ROAS. El mínimo de ventas crece en cada vuelta. |
| Mediodía / pico | Pico (`pico`) | Sube **solo lo que ya vende** (más ventas pedidas, ROAS sobre el piso de la franja). |
| Media tarde | Control (`control`) | No sube. Controla cada tramo. |
| La hora de bajar de cada mercado | (por campaña, `hora_bajar`) | Vuelve a la base **o prueba quedarse** (ver 2.4). |
| Final del día | Cierre (`cierre`) | Red de seguridad: todo a la base. |

En **todas** las vueltas, a lo que está arriba de su base:

- **Freno:** ROAS del día bajo el freno con gasto suficiente → vuelve a la base.
- **Control por tramo:** el ROAS **desde el último cambio** bajo el mínimo con gasto suficiente → baja un
  escalón (**−30 %**), nunca por debajo de la base. El ROAS del día solo no alcanza: una mañana buena tapa
  un tramo malo de varias horas.
- **Presupuesto chico:** a una campaña chica no le podés pedir las mismas ventas que a una grande; alcanza
  con 3 ventas si el ROAS es alto.
- **ABO:** cada conjunto junta menos datos que una campaña entera, así que pide algunas ventas más para
  subir y mide con las compras del conjunto (píxel o UTM), porque la tienda no sabe de qué conjunto vino
  cada venta.

### 2.3 · La BASE de cada campaña

- Cada campaña (o conjunto en ABO) tiene una **base de inicio** fija, no «lo que tenga al empezar el día».
  La madrugada arranca desde ahí, la hora de bajar y el cierre vuelven ahí, y si la campaña amaneció inflada
  el bot usa la base.
- **Nunca subas apiladas:** el día que una campaña estrena base más alta, esa madrugada **no** lleva suba
  fuerte. Base nueva y suba fuerte juntas ya perdieron plata. (El script lo controla comparando con la base
  de ayer.)
- La base **se revisa todos los días** con el ROAS por hora de cada mercado: Claude propone el ajuste con
  números y el dueño aprueba.
- Si a la hora de bajar el día viene flojo (ROAS del día bajo el freno), puede quedar **un escalón debajo de
  la base** hasta la madrugada siguiente (`base_nocturna`).
- **Mercados nuevos entran al bot desde el día 1** con una base chica y un techo. No hace falta esperar días
  para tocar una campaña nueva: el techo es el que limita el daño.

### 2.4 · La hora de bajar no es fija: la prueba de tarde

La hora en que cada mercado «se enfría» es una hipótesis que se prueba todos los días. Si a la hora de
bajar el mercado **todavía vende** (ROAS del día y ventas suficientes), el bot **baja solo la mitad** de lo
escalado y mide unas horas más. Si el tramo extra rinde **bajo el piso del dinero extra**, vuelve a la base;
si no, vuelve igual cuando termina la prueba. Al día siguiente se mira el ROAS de ese tramo extendido y se
mueve la hora de bajar de ese mercado. Así se va encontrando el final real del día de cada uno.

### 2.5 · La agresividad

Los números son del dueño. Tres puntos de partida, todos relativos a la base (sirven para cualquier tamaño
de cuenta). Recomendá **equilibrado** como arranque y pasar a agresivo cuando el freno y el tramo ya hayan
demostrado que cortan a tiempo.

| Regla (clave en `reglas`) | Conservador | Equilibrado | Agresivo |
|---|---|---|---|
| Suba fuerte de madrugada (`fuerte_mult`, si ayer ROAS ≥ `fuerte_roas_ayer` con ≥ `fuerte_ventas_ayer`) | ×1,5 · ROAS ≥ 2 · 5 ventas | ×2 · ROAS ≥ 1,8 · 3 ventas | ×2 en todo mercado que ayer no tuvo un día malo |
| Confirmación (`confirma_mult`, `confirma_roas`, `ventas_min` por vuelta) | ×1,3 · ROAS ≥ 2,2 · 4/6/8 ventas | ×1,5 · ROAS ≥ 2 · 3/5 ventas | ×1,5 · ROAS ≥ 2 · 3/5/5/6 ventas |
| Pico (`pico_mult`, `pico_roas`) | sin subas en el pico | ×1,5 · ROAS ≥ 1,8 · 6 ventas | ×1,5 · ROAS ≥ 1,8 · 6 ventas |
| Freno (`freno_roas`) | < 1,5 → base | < piso del extra → base | < piso del extra → base |
| Tramo (`tramo_roas_min`) | < 1,8 → −30 % | < piso + 0,1 → −30 % | < piso + 0,1 → −30 % |
| Techo por campaña | 2 × base | 3 × base | 4 × base |
| Tope de subas del día (`tope_subas_dia_x_bases`) | 1 × suma de bases | 1,5 × | 2,5 × |

Estos valores suponen un empate de ejemplo cercano a 1,1 (unos 8 % de comisiones). Si el empate del dueño es distinto, corré freno, tramo y piso en la misma medida.

### 2.6 · Las protecciones (cada una sale de un error que ya se pagó; no se quitan)

- **Techo por campaña y tope de subas del día.** Si el bot se equivoca, el daño tiene límite. Ojo: Meta
  pone un límite de gasto diario por cuenta que no se lee por la API, y varias campañas lo comparten.
- **Releer hasta ACTIVE después de cada cambio.** Cambiar presupuesto o puja por API a veces deja la campaña
  en pausa sin avisar, y tras un cambio Meta muestra «en proceso» unos segundos. El bot relee hasta verla
  ACTIVE con el presupuesto nuevo; si quedó en pausa la reactiva una vez y avisa.
- **ROAS con ventas cobradas, no con el píxel.** El píxel subreporta o duplica según el día.
- **Una compra del píxel se cuenta con UN solo tipo de acción** (`omni_purchase`, si no `purchase`): Meta
  devuelve la misma compra con varios nombres.
- **Plan B si la fuente de ventas no responde:** no subir (o decidir con el píxel) y avisar en el informe
  qué fuente se usó. Nunca adivinar.
- **Ventas pedidas solo del día**, con filtro por fecha en la consulta. Si la fuente tiene cupo diario
  (Firebase, Supabase y similares), leer el historial entero en cada vuelta lo agota a media tarde y el bot
  se queda ciego.
- **Error de permiso de Meta: no se reintenta.** Insistir gasta el cupo de llamadas y puede bloquear la app.
  El bot crea `FRENADO.txt`, avisa y no vuelve a llamar hasta que alguien revise el token o los permisos y
  borre el archivo. Con error de límite de llamadas se frena una hora.
- **Si se cae internet**, reintenta cada 5 minutos hasta 30 en vez de perder la vuelta.
- **Token de un usuario del sistema**, no el del perfil personal (ese se cae si Meta restringe el perfil y
  el bot queda ciego justo cuando el dueño no mira). Guardado en el llavero o en los secretos de la nube,
  nunca en un archivo del proyecto ni en un repositorio.
- **Lista fija** de campañas o conjuntos. **Un solo bot por campaña:** dos sistemas (otro bot, reglas
  automáticas de Meta, una persona) moviendo el mismo presupuesto se pisan.
- **Archivo `PAUSA`** en la carpeta del bot: si existe, no toca nada. Se crea y se borra solo con OK del
  dueño.
- **Modo `--simulacro`:** lee y decide, no escribe nada en Meta.
- **Tarjetas:** los pagos rechazados hacen que Meta baje el límite de gasto de la cuenta. Que la tarjeta
  principal sea la que siempre paga.

### 2.7 · Instalación

Hacé vos todo lo que se pueda desde la terminal. Pedile al dueño solo lo que necesita sus manos y explicale
cada paso en simple. Cada paso tiene un «Listo cuando»: no avances sin cumplirlo.

**a · La carpeta.** Python 3.8 o más nuevo. Copiá de esta skill `scripts/escala.py` y
`scripts/config.ejemplo.json` a una carpeta de trabajo (`~/bot-de-escala`, o un repositorio privado o una
carpeta en el VPS). Escribí `config.json` con las respuestas de 2.1: `huso_utc` = huso de la cuenta
publicitaria, `unidades` = la lista fija (CBO: el ID de la campaña; ABO: el ID de cada conjunto), `mercados`
con las campañas que cuentan para el gasto de cada uno, `vueltas` con las horas del análisis (siempre en
punto o y media). Si la fuente es Shopify, ya viene; si es otra, copiá `scripts/ventas_propias.ejemplo.py`
como `ventas_propias.py` y completalo contra la API **oficial** de esa plataforma (buscá la documentación
antes de prometerlo), respetando el contrato del archivo. Para Cost Cap / Bid Cap seguí
`references/escalera-de-puja.md`.
*Listo cuando:* `python3 -m py_compile escala.py` no da error y `config.json` tiene la lista real.

**b · El token de Meta (manos del dueño, 5 minutos).** En su portafolio comercial: Configuración del negocio
→ Usuarios → Usuarios del sistema → Agregar (rol Empleado). Asignarle **solo** las cuentas del bot con
permiso para administrar campañas y generar un token con `ads_read` y `ads_management`, sin vencimiento.
Guardarlo:
- Mac: `security add-generic-password -a bot-de-escala -s bot-de-escala-meta -w` (lo pide sin mostrarlo).
- Windows y Linux con escritorio: `py -3 -m pip install keyring` y después
  `py -3 -c "import keyring,getpass; keyring.set_password('bot-de-escala-meta','bot-de-escala',getpass.getpass('Token: '))"`.
- VPS sin escritorio: archivo `.env` fuera del repositorio con `chmod 600`.
- GitHub Actions: Settings → Secrets and variables → Actions → `META_TOKEN`.
Verificalo solo leyendo: `GET /me/adaccounts?fields=id,name,currency`.
*Listo cuando:* el token lee todas las cuentas de la lista.

**c · Telegram (si lo quiere, 2 minutos).** En Telegram buscar **BotFather** → `/newbot` → nombre → usuario
que termine en «bot»; da un token. Que le escriba «hola» a su bot; sacá el chat id con
`https://api.telegram.org/bot<TOKEN>/getUpdates`. Guardá los dos igual que el de Meta (servicios
`bot-de-escala-telegram` y `bot-de-escala-telegram-chat`, o variables `TELEGRAM_TOKEN` y
`TELEGRAM_CHAT_ID`). Mandá un mensaje de prueba.
*Listo cuando:* el dueño confirma que le llegó.

**d · Simulacro (obligatorio).** `python3 escala.py --simulacro --todas` simula cada vuelta del día con los
datos de ahora (cada una por separado, desde el presupuesto actual). Mostrale al dueño el informe y
explicale fila por fila qué haría y por qué. Si es de madrugada y todavía no hay ventas del día, repetí con
`--simulacro --vuelta HH:MM` más tarde para ver las confirmaciones con datos reales.
*Listo cuando:* el dueño vio el simulacro y dijo que sí. Sin ese «sí», el paso e no se hace.

**e · Dejarlo andando.** El reloj despierta al bot a los **:02 y :32 de cada hora**; el bot solo trabaja
cuando hay una vuelta, una hora de bajar o una prueba de tarde en esa franja, y no repite una ya hecha.
- **Mac:** `~/Library/LaunchAgents/com.bot-de-escala.plist` con `StartCalendarInterval` = dos entradas
  (`Minute` 2 y `Minute` 32), `ProgramArguments` = `/usr/bin/caffeinate -i /usr/bin/python3
  <carpeta>/escala.py` y `StandardOutPath` a un log; `launchctl load`. Para que no se duerma: en Ajustes →
  Batería/Energía, evitar el reposo automático enchufada, y la tapa abierta.
- **Windows:** `schtasks /Create /TN "Bot de escala" /SC MINUTE /MO 30 /ST 00:02 /TR "py -3 C:\ruta\escala.py"`
  y en el Programador de tareas tildar «Activar el equipo para ejecutar esta tarea». Energía:
  `powercfg /change standby-timeout-ac 0`.
- **VPS (Linux):** `crontab -e` → `2,32 * * * * cd ~/bot-de-escala && set -a && . ./.env && set +a && python3 escala.py >> bot.log 2>&1`.
  El `huso_utc` del config manda, no el del servidor.
- **GitHub Actions:** repositorio **privado**, workflow con `cron: "2,32 * * * *"` (en UTC), los secretos
  como variables, `permissions: contents: write` y al final `git add estado informe.md` + commit + push
  (sin eso el estado del día se borra en cada vuelta y el tope y los tramos dejan de funcionar).
*Listo cuando:* forzaste una vuelta sin riesgo por el mismo camino que usa el reloj (por ejemplo
`--forzar` de la vuelta de cierre con todo ya en la base) y viste el informe nuevo.

**f · Entrega.** Llená `references/INSTRUCCIONES.plantilla.md` como `INSTRUCCIONES.md` en la carpeta del
bot, con los números reales. Contale al dueño en simple: dónde vive, a qué horas trabaja, dónde le llega el
informe, cómo se pausa (archivo `PAUSA`) y que cualquier cambio pasa por simulacro.

## Fase 3 · Operarlo y mejorarlo todos los días

### La revisión diaria (con el dueño, una vez por día)

1. Leé `informe.md` (lo más nuevo arriba) y el estado del día anterior en `estado/`.
2. Por mercado: gasto, ventas cobradas, cobrado, ROAS y **ganancia real** (cobrado − comisiones − gasto −
   reintegros y disputas), más el ROAS por bloque horario.
3. Las tres preguntas:
   - **¿Qué hicimos bien?** Subas que trajeron ventas, frenos que evitaron pérdida.
   - **¿Qué pudimos hacer mejor?** Plata dejada en la mesa (vendía y la regla no dejó subir) y plata
     quemada (subas que no respondieron: ¿el freno o el tramo llegaron a tiempo?).
   - **¿Qué probamos mañana?** Una prueba concreta: quién, cuánto, hasta qué hora y cómo se mide.
4. **Revisá la base** de cada mercado con su ROAS por hora y proponé ajustes con números (sin apilar: si
   sube la base, esa madrugada no hay suba fuerte).
5. **Revisá la hora de bajar** de cada mercado con lo que dio la prueba de tarde.
6. Lo que funcionó 2 días o más → a la bitácora como regla. Lo que falló 2 días → se cambia.

### Durante el día

- **Pico:** si un mercado vende fuerte y el bot no lo subió, proponé la suba con números (ventas del día,
  ROAS, tramo) y chequeo a las 3 horas: si el tramo rinde bajo el piso, vuelve. Toca plata: con OK.
- **Cortar temprano lo que no cobra o no mide:** un mercado con 0 ventas y gasto alto, una pasarela que
  rechaza mucho, un píxel ciego. Proponelo apenas lo veas.
- **Bajar un presupuesto por debajo de lo ya gastado en el día** hace que Meta deje de gastar el resto del
  día: sirve como freno total, pero tenelo en cuenta cuando el bot vuelve a la base tarde. Verificalo en
  la cuenta del dueño con el gasto por hora después del cambio.

### Pedidos comunes

- **«¿Cómo viene el bot?»** → últimas entradas de `informe.md`, resumidas por mercado.
- **«Cambiá una regla / la base / el techo»** → editá `config.json` y `INSTRUCCIONES.md` juntos, corré
  `--simulacro --todas`, mostrá el efecto y esperá el OK.
- **«Pausá el bot»** → creá el archivo `PAUSA` en su carpeta (inmediato y reversible). Para apagarlo del
  todo: Mac `launchctl unload` del plist · Windows deshabilitar la tarea · VPS comentar la línea del
  crontab · GitHub deshabilitar el workflow.
- **«Apareció FRENADO.txt»** → leé el motivo. Permiso: revisá el token y los permisos del usuario del
  sistema (no reintentes llamadas); recién con eso arreglado y el OK del dueño, borralo.
- **Mercado nuevo** → sumalo a `unidades` desde el día 1 con base chica y techo, y a `mercados`; simulacro
  y OK.

## Lo que no hay que quitar del script (cada punto sale de un error real)

- El presupuesto se cambia mandando **solo** `daily_budget` por la API directa, y después se relee.
- `cambiar()` relee hasta ACTIVE; lo pausado por el dueño no se toca.
- Ningún reintento automático contra Meta salvo la relectura después de un cambio.
- El estado del día (`estado/AAAA-MM-DD.json`) guarda la foto de cada cambio para medir el tramo, la base
  aplicada (para no apilar al día siguiente), las subas del día (para el tope) y la prueba de tarde en
  curso. En la nube tiene que persistir entre vueltas.
- El candado (`CORRIENDO.lock`) evita dos vueltas a la vez cuando una espera que vuelva internet.
