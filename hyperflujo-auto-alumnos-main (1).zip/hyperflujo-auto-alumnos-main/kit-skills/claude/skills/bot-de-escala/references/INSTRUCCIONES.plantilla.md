# Instrucciones del bot de escala de [tu nombre o tu marca]

> Este archivo es la verdad del bot. Lo lee el dueño y lo lee Claude antes de tocar cualquier cosa.
> El código (`escala.py` + `config.json`) tiene que hacer exactamente lo que dice acá. Si cambia una
> regla, cambian los dos el mismo día, se corre el simulacro y se anota en la bitácora de abajo.

## 1 · Qué escala y qué no

- Estructura: [CBO / ABO / Cost Cap / Bid Cap]
- Cuenta(s) publicitaria(s): [lista fija]
- Campañas o conjuntos que mueve el bot (y NINGUNO más):

| Unidad | Mercado | Tipo | Base | Techo | Hora de bajar | Suba directa a la madrugada |
|---|---|---|---|---|---|---|
| [Mercado A · CBO] | Mercado A | CBO | [ ] | [ ] | [ ] | [sí / no] |
| [Mercado B · conjunto 1] | Mercado B | ABO | [ ] | [ ] | [ ] | [sí / no] |

- Campañas que solo cuentan para el gasto del mercado (testeos, retargeting), pero el bot no toca: [ ]
- Un solo bot por campaña: ninguna otra herramienta, regla automática de Meta ni persona mueve estos
  presupuestos mientras el bot esté prendido.

## 2 · Mis números de negocio

- Ticket de entrada: [ ] [moneda de la cuenta]
- Comisiones totales sobre lo cobrado (pasarela + plataforma + impuestos): [ ] %
- **ROAS de empate** = 1 ÷ (1 − comisiones). El mío: [ ]
- **Piso del dinero extra** (el ROAS mínimo que tiene que dar lo que se invierte arriba de la base): [ ]
- De dónde salen las ventas cobradas: [plataforma] · plan B si no responde: [no subir / píxel]
- Huso de la cuenta publicitaria: [ ] (todas las horas de este archivo van en ese huso)

## 3 · Lo que mostró el análisis de 7 días ([fecha])

| Mercado | Arrancan las ventas | Franja buena | Se enfría | ROAS de la franja buena | Confianza |
|---|---|---|---|---|---|
| Mercado A | [tu hora de arranque] | [ ] | [ ] | [ ] | [alta / media / baja: cuántas ventas] |

- Tiempo de impacto de un cambio de presupuesto: [ ] (una suba se nota en la misma hora y llega a pleno en [ ])
- ¿Con más gasto bajó el ROAS?: [ ] (un solo día no es veredicto)

## 4 · El día del bot

| Hora | Vuelta | Qué hace |
|---|---|---|
| [arranque − impacto] | Madrugada | Pone cada unidad en su BASE (si amaneció inflada, la baja). Si ayer rindió (ROAS ≥ [ ] con ≥ [ ] ventas) y los últimos 3 días no fueron malos, sube ×[ ]. Si hoy estrena base más alta, no sube (nunca subas apiladas). |
| [ ] | Mañana | Sube ×[ ] si HOY lleva ≥ [ ] ventas cobradas y ROAS ≥ [ ]. |
| [ ] | Mediodía / pico | Sube ×[ ] solo lo que ya vende: ≥ [ ] ventas y ROAS ≥ [ ]. |
| [ ] | Media tarde | No sube. Controla cada tramo. |
| Por mercado | Hora de bajar | Vuelve a la base, o prueba de tarde si todavía vende (ROAS ≥ [ ] con ≥ [ ] ventas): baja la mitad de lo escalado y mide [ ] horas. Si el tramo extra rinde bajo el piso, vuelve a la base. |
| [ ] | Cierre | Red de seguridad: todo a la base. |

En TODAS las vueltas, a lo que está arriba de su base:
- **Freno:** ROAS del día < [ ] con ≥ [ ] tickets gastados → vuelve a la base.
- **Tramo:** ROAS desde el último cambio < [ ] con ≥ [ ] tickets gastados → un escalón abajo (−30 %), nunca
  por debajo de la base.
- **Presupuesto chico** (≤ [ ]): alcanza con [ ] ventas si el ROAS es ≥ [ ].
- **Día flojo a la hora de bajar** (ROAS del día bajo el freno): queda un escalón debajo de la base hasta la
  madrugada siguiente. [sí / no]

ABO: limpieza a las [ ]: apaga conjuntos de testeo con 3 días de vida contando hoy, 0 compras en esos días y
al menos [ ] gastados (así no apaga lo recién prendido).

## 5 · Protecciones (no se quitan)

- Techo por unidad y tope de subas del día ([ ] × la suma de las bases).
- Después de cada cambio relee hasta verla ACTIVE con el presupuesto nuevo; si quedó en pausa, la reactiva
  una vez y avisa. Lo que el dueño pausó, el bot no lo toca.
- ROAS con ventas cobradas, nunca con el píxel (salvo ABO, que mide por conjunto).
- Ventas pedidas solo del día que se analiza (filtro por fecha en la consulta).
- Error de permiso de Meta: no reintenta, se frena (FRENADO.txt) y avisa. Error de límite: se frena una hora.
- Sin internet: reintenta cada 5 minutos hasta 30 antes de dar la vuelta por perdida.
- Token de un usuario del sistema, guardado en el llavero o en los secretos de la nube. Nunca en un archivo.
- Archivo `PAUSA` en la carpeta del bot = el bot no toca nada.
- `--simulacro` antes de cada cambio de reglas, y el OK del dueño antes de que mueva plata real.

## 6 · Pruebas pre-aprobadas por el dueño

> Solo lo que esté escrito acá lo puede aplicar Claude sin preguntar, y siempre dentro de los techos.
> Todo lo demás que mueva plata: propuesta con números, simulacro y OK.

- [ej.: la prueba de tarde de la sección 4, en cualquier mercado]
- [ ]

## 7 · Bitácora de reglas

> Lo que funciona 2 días o más se vuelve regla. Ningún día solo es verdad absoluta.

| Fecha | Cambio | Por qué (con números) | Resultado a los 2-3 días | ¿Queda? |
|---|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] | [ ] |

## 8 · Revisión diaria (la hace Claude con el dueño)

Para cada día: gasto, ventas cobradas, cobrado, ROAS y ganancia por mercado (cobrado − comisiones −
gasto − reintegros y disputas), y el ROAS por bloque horario. Después, tres preguntas:

1. **¿Qué hicimos bien?** Subas que trajeron ventas, frenos que evitaron pérdida.
2. **¿Qué pudimos hacer mejor?** Plata dejada en la mesa (mercados que vendían y la regla no dejó subir) y
   plata quemada (subas que no respondieron: ¿el freno llegó a tiempo?).
3. **¿Qué probamos mañana?** Una prueba concreta: quién, cuánto, hasta qué hora, y cómo se mide.
