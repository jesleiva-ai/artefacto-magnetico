# Cost Cap y Bid Cap: la escalera de puja

Con una estrategia de puja el presupuesto puede quedar alto: lo que limita el gasto es la puja. La palanca
del bot es entonces `bid_amount` del conjunto (en centavos, salvo monedas sin centavos), y el trabajo de la
madrugada es **encontrar la puja que gasta ANTES de que arranquen las ventas**. La franja horaria dice cuándo
tiene que estar encontrada; la escalera la encuentra.

Es un método de partida medido un solo día: tomalo como punto de partida, no como verdad.
Todos los porcentajes van contra el **ticket de entrada** del dueño y se calibran con su **CPA objetivo** (el
máximo que le deja ganancia). La puja nunca pasa ese CPA.

## Reglas de partida

| Momento | Qué hace el bot |
|---|---|
| Inicio del día | Todas las pujas vuelven a su valor original. |
| Primera vuelta de la madrugada | Arranca desde abajo: puja cerca del 25 % del ticket. |
| Cada 30 minutos (escalera) | Si en esa media hora gastó menos de lo esperado (Meta no encuentra a quién mostrarle), sube un escalón: ≈ 7 % del ticket; la mitad en mercados chicos. Rango permitido: ≈ 18 % a 70 % del ticket, y nunca arriba del CPA objetivo. |
| Cuando empieza a gastar | Encontró precio. Desde ahí, solo medio escalón: sube si se frena dos medias horas seguidas sin empeorar; baja si lleva 0 compras con el equivalente a 3 pujas gastadas, o si el CPA pasa 1,3 veces la puja con ROAS bajo y gasto suficiente. |
| Si rinde muy bien | Conjunto con ROAS alto, al menos 3 compras y poco gasto: puja +20 %, como mucho una vez por hora. Si el ROAS cae, −15 %, nunca por debajo de la original. |
| Recortes de presupuesto | ROAS del día bajo el freno con gasto suficiente: −30 %. Muy por debajo del empate: −50 %, con un piso que fija el dueño. No recorta si el CPA del día está bien con 3 compras o más. |
| Media tarde en adelante | Ya no sube pujas (la hora sale del análisis: cuando la franja se enfría). |
| Antes del arranque de ventas | Si la escalera no llegó a una puja que gasta, avisa. |

## Cómo lo arma Claude

El script de la skill (`scripts/escala.py`) es para CBO y ABO. Para Cost Cap o Bid Cap Claude escribe
`escalera.py` en la carpeta del bot **reusando de `escala.py`, sin cambiarlas**: `secreto()`, `meta()` con
el freno de permiso y de límite, `esperar_red()`, el candado, `PAUSA`, `FRENADO.txt`, el informe a Telegram,
el estado por día y `--simulacro`. Cambia solo la decisión y la palanca:

- Corre cada 30 minutos (el reloj igual que en la sección de instalación, con `MO 30` / `*/30`).
- Lee por conjunto: gasto y compras de la última media hora y del día (`insights` con
  `breakdowns=hourly_stats_aggregated_by_advertiser_time_zone` o restando la foto de la vuelta anterior).
- Cambia `bid_amount` y relee el conjunto hasta verlo ACTIVE con la puja nueva (cambiar la puja por API
  puede dejarlo en pausa: si pasa, lo reactiva una vez y avisa).
- Guarda en el estado del día la puja original, cada escalón y la puja en la que encontró precio. A la
  mañana siguiente el informe dice a qué puja gastó cada conjunto y con qué ROAS: eso es lo que aprende de
  un día al otro.
- Las ventas cobradas se piden solo del día; si la fuente no responde, no sube pujas y avisa.
- Simulacro con los datos de hoy y OK del dueño antes de moverla de verdad. Reglas escritas en
  `INSTRUCCIONES.md`.
