#!/usr/bin/env python3
"""Bot de escala por franja horaria — plantilla base del kit (CBO y ABO).

Surfea el presupuesto a lo largo del día con una BASE por campaña (o por conjunto):
  · madrugada  (suba_fuerte): arranca en la base y sube fuerte ANTES de que empiecen las ventas
  · mañana     (confirma):    sube otro escalón si HOY ya hay ventas cobradas con buen ROAS
  · pico       (pico):        sube solo lo que ya vende
  · control    (control):     no sube; frena lo que no rinde
  · hora_bajar (por unidad):  vuelve a la base o hace la prueba de tarde (baja la mitad y mide)
  · cierre     (cierre):      red de seguridad al final del día, todo a la base
En TODAS las vueltas, a lo que está arriba de su base:
  · freno: ROAS del día < freno_roas con gasto suficiente → vuelve a la base
  · tramo: ROAS desde el último cambio < tramo_roas_min con gasto suficiente → un escalón abajo (−30 %)

CBO: mueve el daily_budget de la campaña y mide con las ventas COBRADAS del mercado ÷ gasto del mercado.
ABO: mueve el daily_budget del conjunto y mide con las compras de ese conjunto (píxel de Meta).

USO (en Windows: py -3 en lugar de python3)
  python3 escala.py                          vuelta normal (el reloj lo despierta a los :02 y :32)
  python3 escala.py --simulacro              lee y decide la vuelta de ahora, no cambia nada
  python3 escala.py --simulacro --vuelta 08:00   simula esa vuelta con los datos de ahora
  python3 escala.py --simulacro --todas      simula todas las vueltas del día, una por una
  python3 escala.py --forzar 08:00           hace esa vuelta ahora, de verdad (aunque ya se haya hecho)

FRENOS MANUALES
  · Archivo PAUSA en esta carpeta → el bot no toca nada (se crea y se borra a mano, solo con OK del dueño).
  · Archivo FRENADO.txt → lo crea el bot si Meta devuelve un error de permiso o de límite. Permiso: queda
    frenado hasta que alguien revise y borre el archivo. Límite: se libera solo después de una hora.

SECRETOS (nunca en archivos del proyecto): META_TOKEN (token de usuario del sistema), y si se usan
TELEGRAM_TOKEN, TELEGRAM_CHAT_ID y los tokens de la fuente de ventas. Se buscan en este orden: variable de
entorno → llavero del sistema (paquete keyring, si está instalado) → Llavero de macOS.

Solo biblioteca estándar de Python 3.8+ (keyring es opcional). Anda en Mac, Windows, Linux y GitHub Actions.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CONFIG = AQUI / "config.json"
ESTADO_DIR = AQUI / "estado"
INFORME = AQUI / "informe.md"
PAUSA = AQUI / "PAUSA"
FRENADO = AQUI / "FRENADO.txt"
CANDADO = AQUI / "CORRIENDO.lock"
API = "https://graph.facebook.com/v26.0"
SERVICIO_LLAVERO = "bot-de-escala"  # cuenta del llavero; el servicio es bot-de-escala-meta, -telegram, etc.

# Meta no usa centavos en estas monedas (doc oficial: Marketing API › Currencies).
SIN_CENTAVOS = {"CLP", "COP", "CRC", "HUF", "IDR", "ISK", "JPY", "KRW", "PYG", "TWD", "VND"}
# Límite de llamadas: frenar, no reintentar (reintentar es lo que bloquea la app y la cuenta).
LIMITE = {4, 17, 32, 613, 80000, 80001, 80002, 80003, 80004, 80005, 80006, 80008, 80009, 80014}
# Permisos y token: frenar, no reintentar, avisar. 200-299 son todos de permiso.
PERMISO = {10, 102, 190}
# Meta repite la misma compra con varios nombres: se cuenta UN solo tipo.
TIPOS_COMPRA = ("omni_purchase", "purchase", "offsite_conversion.fb_pixel_purchase")

TOKEN = None


class Freno(Exception):
    def __init__(self, texto, permanente):
        super().__init__(texto)
        self.permanente = permanente


# ── secretos ──────────────────────────────────────────────────────────────────
def secreto(variable, servicio):
    v = os.environ.get(variable)
    if v:
        return v.strip()
    try:
        import keyring  # opcional: Llavero de macOS, Administrador de credenciales de Windows, Secret Service
        v = keyring.get_password(servicio, SERVICIO_LLAVERO)
        if v:
            return v.strip()
    except Exception:
        pass
    if sys.platform == "darwin":
        try:
            r = subprocess.run(["security", "find-generic-password", "-a", SERVICIO_LLAVERO, "-s", servicio, "-w"],
                               capture_output=True, text=True, timeout=15)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip()
        except Exception:
            pass
    return None


# ── red ───────────────────────────────────────────────────────────────────────
def hay_red():
    try:
        urllib.request.urlopen("https://graph.facebook.com/", timeout=15)
        return True
    except urllib.error.HTTPError:
        return True  # respondió algo: hay internet
    except Exception:
        return False


def esperar_red(cada=300, maximo=1800):
    """Si se cayó internet, reintenta cada 5 min hasta 30 en vez de perder la vuelta."""
    inicio = time.time()
    while not hay_red():
        if time.time() - inicio >= maximo:
            return False
        print("sin internet: reintento en 5 minutos")
        time.sleep(cada)
    return True


# ── Meta ──────────────────────────────────────────────────────────────────────
def meta(metodo, ruta, params=None):
    params = dict(params or {})
    params["access_token"] = TOKEN
    url = f"{API}/{ruta}"
    datos = None
    if metodo == "GET":
        url += "?" + urllib.parse.urlencode(params)
    else:
        datos = urllib.parse.urlencode(params).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request(url, data=datos, method=metodo), timeout=120) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read() or b"{}").get("error", {})
        except Exception:
            err = {}
        cod, sub, msg = err.get("code"), err.get("error_subcode"), err.get("message")
        if cod in LIMITE or sub in LIMITE:
            raise Freno(f"Meta pidió frenar por límite de llamadas (código {cod}): {msg}", permanente=False)
        if cod in PERMISO or (isinstance(cod, int) and 200 <= cod <= 299):
            raise Freno(f"Meta devolvió un error de PERMISO o de token (código {cod}): {msg}. "
                        "No se reintenta: revisá el token y los permisos del usuario del sistema.", permanente=True)
        raise RuntimeError(f"Meta {cod}: {msg}")


def compras(fila):
    acc = {a["action_type"]: float(a["value"]) for a in fila.get("actions") or []}
    val = {a["action_type"]: float(a["value"]) for a in fila.get("action_values") or []}
    for t in TIPOS_COMPRA:
        if t in acc:
            return int(acc[t]), val.get(t, 0.0)
    return 0, 0.0


def insights(id_, preset=None, rango=None):
    p = {"fields": "spend,actions,action_values"}
    if rango:
        p["time_range"] = json.dumps(rango)
    else:
        p["date_preset"] = preset
    datos = meta("GET", f"{id_}/insights", p).get("data") or [{}]
    n, v = compras(datos[0])
    return float(datos[0].get("spend") or 0), n, v


def leer(id_):
    return meta("GET", id_, {"fields": "name,daily_budget,status,effective_status"})


def cambiar(id_, nuevo_cent):
    """Cambia SOLO daily_budget y relee hasta verla ACTIVE con el presupuesto nuevo."""
    meta("POST", id_, {"daily_budget": nuevo_cent})
    nota, reactivada = "", False
    for _ in range(12):  # ~1 minuto: tras un cambio Meta muestra IN_PROCESS unos segundos
        time.sleep(5)
        r = leer(id_)
        if r.get("status") != "ACTIVE":
            if reactivada:
                break
            meta("POST", id_, {"status": "ACTIVE"})  # nunca dejar apagado algo que tocó el bot
            reactivada, nota = True, "quedó en pausa después del cambio y se reactivó"
            continue
        if r.get("effective_status") == "ACTIVE" and int(r.get("daily_budget") or 0) == nuevo_cent:
            return True, nota
    return False, "NO quedó ACTIVE con el presupuesto nuevo: revisar a mano YA"


# ── ventas cobradas ───────────────────────────────────────────────────────────
def ventas_shopify(cfg_tienda, desde, hasta):
    """Pedidos pagados de UNA ventana de tiempo (nunca el historial entero)."""
    token = secreto(cfg_tienda["token_env"], cfg_tienda.get("llavero", "bot-de-escala-shopify"))
    if not token:
        raise RuntimeError(f"falta el token de Shopify ({cfg_tienda['token_env']})")
    params = {"status": "any", "financial_status": "paid", "limit": 250,
              "created_at_min": desde.isoformat(), "created_at_max": hasta.isoformat(),
              "fields": "id,total_price"}
    url = f"https://{cfg_tienda['tienda']}/admin/api/2025-07/orders.json?" + urllib.parse.urlencode(params)
    n, total = 0, 0.0
    while url:
        req = urllib.request.Request(url, headers={"X-Shopify-Access-Token": token})
        with urllib.request.urlopen(req, timeout=120) as r:
            pedidos = json.loads(r.read()).get("orders", [])
            enlace = r.headers.get("Link") or ""
        n += len(pedidos)
        total += sum(float(p.get("total_price") or 0) for p in pedidos)
        m = re.search(r'<([^>]+)>;\s*rel="next"', enlace)
        url = m.group(1) if m else None
    return n, total


def ventas_cobradas(cfg, mercado, desde, hasta):
    fuente = cfg.get("fuente_ventas", "pixel")
    if fuente == "shopify":
        return ventas_shopify(cfg["mercados"][mercado]["shopify"], desde, hasta)
    if fuente == "propia":
        sys.path.insert(0, str(AQUI))
        import ventas_propias  # lo escribe Claude para la plataforma del dueño (ver ventas_propias.ejemplo.py)
        return ventas_propias.ventas(mercado, desde, hasta)
    return None


# ── medición ──────────────────────────────────────────────────────────────────
def ventanas(zona, ahora):
    hoy0 = datetime(ahora.year, ahora.month, ahora.day, tzinfo=zona)
    return {"hoy": ("today", None, hoy0, ahora),
            "ayer": ("yesterday", None, hoy0 - timedelta(days=1), hoy0),
            "3d": ("last_3d", None, hoy0 - timedelta(days=3), hoy0)}


def medir(cfg, u, cual, zona, ahora, cache):
    """Devuelve gasto, ventas, cobrado, roas y de dónde salió la venta, para la unidad u."""
    clave = (u["mercado"] if u["tipo"] == "CBO" else u["id"], cual)
    if clave in cache:
        return cache[clave]
    preset, rango, desde, hasta = ventanas(zona, ahora)[cual]
    m = {"gasto": 0.0, "ventas": 0, "cobrado": 0.0, "origen": "píxel de Meta", "no_subir": False, "aviso": ""}
    if u["tipo"] == "ABO":
        m["gasto"], m["ventas"], m["cobrado"] = insights(u["id"], preset, rango)
    else:
        mk = cfg["mercados"].get(u["mercado"], {})
        ids = mk.get("campanas_gasto") or [x["id"] for x in cfg["unidades"]
                                           if x["tipo"] == "CBO" and x["mercado"] == u["mercado"]]
        for cid in ids:
            g, n, v = insights(cid, preset, rango)
            m["gasto"] += g
            m["ventas"] += n
            m["cobrado"] += v
        if cfg.get("fuente_ventas", "pixel") != "pixel":
            try:
                m["ventas"], m["cobrado"] = ventas_cobradas(cfg, u["mercado"], desde, hasta)
                m["origen"] = f"ventas cobradas ({cfg['fuente_ventas']})"
            except Exception as e:
                plan = cfg.get("si_falla_fuente", "no_subir")
                m["aviso"] = f"la fuente de ventas de {u['mercado']} no respondió ({type(e).__name__}: {e})"
                m["origen"] = "píxel (plan B)"
                if plan != "pixel":
                    m["no_subir"] = True
                    m["origen"] = "píxel (plan B, sin subas)"
    m["roas"] = m["cobrado"] / m["gasto"] if m["gasto"] else 0.0
    cache[clave] = m
    return m


def tramo(m, foto):
    foto = foto or {"gasto": 0.0, "cobrado": 0.0, "ventas": 0}
    g = max(m["gasto"] - foto["gasto"], 0.0)
    c = max(m["cobrado"] - foto["cobrado"], 0.0)
    return {"gasto": g, "cobrado": c, "ventas": max(m["ventas"] - foto["ventas"], 0), "roas": c / g if g else 0.0}


# ── horario ───────────────────────────────────────────────────────────────────
def minutos(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def hhmm(mins):
    mins = min(mins, 23 * 60 + 30)
    return f"{mins // 60:02d}:{mins % 60:02d}"


def franja(ahora):
    return f"{ahora.hour:02d}:{'30' if ahora.minute >= 30 else '00'}"


def eventos(cfg, slot, est):
    ev = {"vuelta": None, "bajan": [], "pruebas": [], "limpieza": False}
    for v in cfg.get("vueltas", []):
        if v["hora"] == slot:
            ev["vuelta"] = v
    for u in cfg["unidades"]:
        if u.get("hora_bajar") == slot:
            ev["bajan"].append(u["id"])
        hasta = est["unidades"].get(u["id"], {}).get("prueba_hasta")
        if hasta and (slot.endswith(":00") or minutos(slot) >= minutos(hasta)) and u["id"] not in ev["bajan"]:
            ev["pruebas"].append(u["id"])
    lim = cfg.get("limpieza_abo") or {}
    ev["limpieza"] = bool(lim.get("activa")) and lim.get("hora") == slot
    return ev


def hay_algo(ev):
    return bool(ev["vuelta"] or ev["bajan"] or ev["pruebas"] or ev["limpieza"])


# ── estado por día ────────────────────────────────────────────────────────────
def leer_estado(fecha):
    f = ESTADO_DIR / f"{fecha}.json"
    if f.exists():
        return json.loads(f.read_text(encoding="utf-8"))
    return {"fecha": fecha, "hechas": [], "subido_hoy": 0.0, "bases": {}, "unidades": {}}


def guardar_estado(est):
    ESTADO_DIR.mkdir(exist_ok=True)
    (ESTADO_DIR / f"{est['fecha']}.json").write_text(json.dumps(est, ensure_ascii=False, indent=1), encoding="utf-8")


# ── la decisión ───────────────────────────────────────────────────────────────
def decidir(cfg, u, actual, ev, slot, m, m_ayer, m_3d, st, est, base_ayer):
    """Devuelve (nuevo_presupuesto o None, motivo). Montos en la moneda de la cuenta."""
    R, base, techo = cfg["reglas"], float(u["base"]), float(u["techo"])
    tk = float(cfg.get("ticket", 1))
    t = tramo(m, st.get("foto"))
    dia_malo = m["roas"] < R["freno_roas"] and m["gasto"] >= R["gasto_min_freno_tickets"] * tk
    vuelta = (ev["vuelta"] or {}).get("tipo")

    # 1 · hora de bajar de esta unidad (la hora no es fija: se revisa todos los días)
    if u["id"] in ev["bajan"]:
        if actual > base:
            if (R.get("prueba_tarde") and not m["no_subir"] and m["roas"] >= R["prueba_roas"]
                    and m["ventas"] >= R["prueba_ventas"]):
                st["prueba_hasta"] = hhmm(minutos(slot) + int(R["prueba_horas"] * 60))
                return base + (actual - base) / 2, (f"prueba de tarde: todavía vende (ROAS {fmt(m['roas'])}, "
                                                    f"{m['ventas']} ventas); baja la mitad y mide hasta las {st['prueba_hasta']}")
            if dia_malo and R.get("base_nocturna"):
                return base * (1 - R["escalon"]), "hora de bajar con el día flojo: base nocturna (un escalón debajo)"
            return base, "hora de bajar: vuelve a la base"
        if dia_malo and R.get("base_nocturna") and actual > base * (1 - R["escalon"]):
            return base * (1 - R["escalon"]), "hora de bajar con el día flojo: base nocturna (un escalón debajo)"
        return None, "hora de bajar: ya está en la base"

    # 2 · prueba de tarde en curso
    if st.get("prueba_hasta") and vuelta != "cierre":
        if minutos(slot) >= minutos(st["prueba_hasta"]):
            st["prueba_hasta"] = None
            return (base if actual > base else None), "terminó la prueba de tarde: vuelve a la base"
        if t["gasto"] >= R["prueba_gasto_min_tickets"] * tk and t["roas"] < R["piso_extra_roas"]:
            st["prueba_hasta"] = None
            return base, f"el tramo extra rindió {fmt(t['roas'])}, debajo del piso {fmt(R['piso_extra_roas'])}: vuelve a la base"
        return None, f"sigue la prueba de tarde (tramo ROAS {fmt(t['roas'])} con {plata(t['gasto'])} gastados)"

    # 3 · cierre: red de seguridad
    if vuelta == "cierre":
        st["prueba_hasta"] = None
        return (base, "cierre: vuelve a la base") if actual > base else (None, "cierre: ya está en la base o debajo")

    # 4 · madrugada: arranca en la base y sube fuerte antes de que empiecen las ventas
    if vuelta == "suba_fuerte":
        arranque = base
        nota = ("amaneció inflada: arranca en la base" if actual > base else
                "arranca en la base" if actual < base else "en la base")
        if base_ayer is not None and base > base_ayer:
            return (arranque if actual != base else None), nota + "; base nueva hoy: sin suba fuerte (nunca subas apiladas)"
        if m_ayer["no_subir"]:
            return (arranque if actual != base else None), nota + "; sin ventas confiables: no sube"
        malos_3d = m_3d["roas"] < R["freno_roas"] and m_3d["gasto"] >= R["gasto_min_freno_tickets"] * tk
        ayer_bien = m_ayer["roas"] >= R["fuerte_roas_ayer"] and m_ayer["ventas"] >= R["fuerte_ventas_ayer"]
        if malos_3d:
            return (arranque if actual != base else None), nota + f"; los últimos 3 días rindieron {fmt(m_3d['roas'])}: no sube"
        if u.get("suba_directa") or ayer_bien:
            return min(base * R["fuerte_mult"], techo), (nota + f"; suba fuerte ×{fmt(R['fuerte_mult'])} "
                                                         f"(ayer ROAS {fmt(m_ayer['roas'])}, {m_ayer['ventas']} ventas)")
        return (arranque if actual != base else None), (nota + f"; ayer no alcanzó (ROAS {fmt(m_ayer['roas'])}, "
                                                        f"{m_ayer['ventas']} ventas): queda en la base")

    # 5 · freno y tramo: valen en toda vuelta para lo que está arriba de su base
    if vuelta in ("confirma", "pico", "control") and actual > base:
        if dia_malo:
            return base, f"FRENO: ROAS del día {fmt(m['roas'])} con {plata(m['gasto'])} gastados: vuelve a la base"
        if t["gasto"] >= R["tramo_gasto_min_tickets"] * tk and t["roas"] < R["tramo_roas_min"]:
            return max(base, actual * (1 - R["escalon"])), (f"TRAMO flojo: desde el último cambio ROAS {fmt(t['roas'])} "
                                                           f"con {plata(t['gasto'])}: un escalón abajo")

    # 6 · subas con ventas de hoy
    if vuelta in ("confirma", "pico"):
        if m["no_subir"]:
            return None, "sin ventas confiables (plan B): no sube"
        if actual >= techo:
            return None, "en el techo"
        vmin = ev["vuelta"].get("ventas_min", R["pico_ventas"] if vuelta == "pico" else 3)
        rmin = R["pico_roas"] if vuelta == "pico" else R["confirma_roas"]
        mult = R["pico_mult"] if vuelta == "pico" else R["confirma_mult"]
        if actual <= R.get("chico_hasta", 0):
            vmin, rmin = min(vmin, R["chico_ventas"]), max(rmin, R["chico_roas"])
        if u["tipo"] == "ABO":
            vmin += R.get("abo_ventas_extra", 0)
        if t["gasto"] >= R["tramo_gasto_min_tickets"] * tk and t["roas"] < R["tramo_roas_min"]:
            return None, f"el tramo viene flojo (ROAS {fmt(t['roas'])}): no sube"
        if m["ventas"] >= vmin and m["roas"] >= rmin:
            return min(actual * mult, techo), f"vende hoy ({m['ventas']} ventas, ROAS {fmt(m['roas'])}): sube ×{fmt(mult)}"
        return None, f"no alcanza para subir (pide {vmin} ventas y ROAS {fmt(rmin)})"
    return None, "nada que hacer en esta vuelta"


# ── limpieza ABO ──────────────────────────────────────────────────────────────
def limpieza_abo(cfg, zona, simulacro):
    """Apaga conjuntos de testeo con N días de vida (contando hoy), 0 compras y gasto mínimo en esos días."""
    L = cfg["limpieza_abo"]
    dias, gasto_min, marca = int(L.get("dias", 3)), float(L.get("gasto_min", 0)), L.get("marca_nombre", "").upper()
    hoy = datetime.now(zona).date()
    desde = hoy - timedelta(days=dias - 1)
    rango = {"since": desde.isoformat(), "until": hoy.isoformat()}
    out = []
    for cid in L.get("campanas", []):
        sets = meta("GET", f"{cid}/adsets", {"fields": "id,name,effective_status,created_time", "limit": 200})
        for z in sets.get("data", []):
            if z.get("effective_status") != "ACTIVE" or (marca and marca not in z["name"].upper()):
                continue
            creado = datetime.strptime(z["created_time"], "%Y-%m-%dT%H:%M:%S%z").astimezone(zona).date()
            if creado > desde:
                continue  # todavía no cumplió los días: no se apaga lo recién prendido
            g, n, _ = insights(z["id"], rango=rango)
            if n > 0 or g < gasto_min:
                continue
            if not simulacro:
                meta("POST", z["id"], {"status": "PAUSED"})
            out.append(f"{z['name']} ({plata(g)} gastados, 0 compras en {dias} días)")
    return out


# ── informe ───────────────────────────────────────────────────────────────────
def fmt(x):
    return f"{x:.2f}".replace(".", ",")


def plata(n):
    return f"{n:,.0f}".replace(",", ".")


def telegram(texto):
    tk = secreto("TELEGRAM_TOKEN", "bot-de-escala-telegram")
    chat = secreto("TELEGRAM_CHAT_ID", "bot-de-escala-telegram-chat")
    if not (tk and chat):
        return "sin Telegram"
    try:
        req = urllib.request.Request(f"https://api.telegram.org/bot{tk}/sendMessage",
                                     data=json.dumps({"chat_id": chat, "text": texto[:4000]}).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return "ok" if json.loads(r.read()).get("ok") else "falló"
    except Exception as e:  # el informe nunca tumba la vuelta
        return f"falló: {e}"


def avisar(texto, simulacro):
    if not simulacro:
        previo = INFORME.read_text(encoding="utf-8") if INFORME.exists() else ""
        INFORME.write_text("## " + texto + "\n\n" + previo, encoding="utf-8")
        print("telegram:", telegram(texto))
    print(texto)


# ── la vuelta ─────────────────────────────────────────────────────────────────
def vuelta(cfg, slot, simulacro):
    zona = timezone(timedelta(hours=cfg["huso_utc"]))
    ahora = datetime.now(zona)
    fecha = ahora.date().isoformat()
    est = leer_estado(fecha)
    base_ayer_todas = leer_estado((ahora.date() - timedelta(days=1)).isoformat()).get("bases", {})
    ev = eventos(cfg, slot, est)
    moneda = cfg.get("moneda", "USD")
    div = 1 if moneda in SIN_CENTAVOS else 100
    R = cfg["reglas"]
    tope = R["tope_subas_dia_x_bases"] * sum(float(u["base"]) for u in cfg["unidades"])

    nombre_v = (ev["vuelta"] or {}).get("tipo") or ("hora de bajar" if ev["bajan"] else
                                                    "prueba de tarde" if ev["pruebas"] else
                                                    "limpieza" if ev["limpieza"] else "sin eventos")
    L = [f"Bot de escala · {ahora:%d/%m} vuelta {slot} ({nombre_v})" + (" · SIMULACRO" if simulacro else ""), ""]
    errores, avisos, cache = [], [], {}
    try:
        for u in cfg["unidades"]:
            if not (ev["vuelta"] or u["id"] in ev["bajan"] or u["id"] in ev["pruebas"]):
                continue
            st = est["unidades"].setdefault(u["id"], {})
            est["bases"][u["id"]] = float(u["base"])
            r = leer(u["id"])
            if r.get("status") != "ACTIVE":
                L.append(f"· {u['nombre']}: está pausada (la pausaste vos o Meta): no la toco")
                continue
            if not r.get("daily_budget"):
                L.append(f"· {u['nombre']}: no tiene presupuesto diario en este nivel: revisá si es CBO o ABO")
                continue
            actual = int(r["daily_budget"]) / div
            m = medir(cfg, u, "hoy", zona, ahora, cache)
            tipo_v = (ev["vuelta"] or {}).get("tipo")
            m_ayer = medir(cfg, u, "ayer", zona, ahora, cache) if tipo_v == "suba_fuerte" else m
            m_3d = medir(cfg, u, "3d", zona, ahora, cache) if tipo_v == "suba_fuerte" else m
            for x in (m, m_ayer, m_3d):
                if x["aviso"] and x["aviso"] not in avisos:
                    avisos.append(x["aviso"])
            nuevo, motivo = decidir(cfg, u, actual, ev, slot, m, m_ayer, m_3d, st, est,
                                    base_ayer_todas.get(u["id"]))

            if nuevo is not None and nuevo > max(actual, float(u["base"])):
                piso_suba = max(actual, float(u["base"]))
                delta = nuevo - piso_suba
                libre = tope - est["subido_hoy"]
                if libre <= 0:
                    nuevo, motivo = (float(u["base"]) if actual < float(u["base"]) else None), motivo + " · PERO se llegó al tope de subas del día"
                elif delta > libre:
                    nuevo, motivo = piso_suba + libre, motivo + " · recortada al tope de subas del día"

            t = tramo(m, st.get("foto"))
            dato = (f"hoy {m['ventas']} ventas · ROAS {fmt(m['roas'])} · tramo {fmt(t['roas'])} · "
                    f"gasto {plata(m['gasto'])} ({m['origen']})")
            if nuevo is None or round(nuevo * div) == int(r["daily_budget"]):
                L.append(f"= {u['nombre']}: {plata(actual)} {moneda} · {dato} · {motivo}")
                continue
            nuevo_cent = int(round(nuevo * div))
            ok, nota = (True, "") if simulacro else cambiar(u["id"], nuevo_cent)
            flecha = ("⬆️" if nuevo > actual else "⬇️") if ok else "❌"
            L.append(f"{flecha} {u['nombre']}: {plata(actual)} → {plata(nuevo)} {moneda} · {dato} · {motivo}"
                     + (f" · {nota}" if nota else ""))
            if not ok:
                errores.append(f"{u['nombre']}: {nota}")
                continue
            if nuevo > max(actual, float(u["base"])):
                est["subido_hoy"] += nuevo - max(actual, float(u["base"]))
            st["foto"] = {"gasto": m["gasto"], "cobrado": m["cobrado"], "ventas": m["ventas"], "hora": slot}

        if ev["limpieza"]:
            apagados = limpieza_abo(cfg, zona, simulacro)
            L += ["", f"Limpieza ABO: {len(apagados)} conjunto(s) apagado(s)"] + [f"⏸ {a}" for a in apagados]
    except Freno as e:
        errores.append(str(e))
        if not simulacro:
            hasta = "" if e.permanente else (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
            FRENADO.write_text(json.dumps({"motivo": str(e), "desde": datetime.now(timezone.utc).isoformat(),
                                           "hasta": hasta}, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:  # una falla se informa, no se adivina
        errores.append(f"{type(e).__name__}: {e}")

    L.append("")
    L.append(f"Subas del día: {plata(est['subido_hoy'])} de {plata(tope)} {moneda} de tope")
    L += [f"⚠️ {a}" for a in avisos]
    L += [f"⚠️ {e}" for e in errores]
    if not simulacro:
        if slot not in est["hechas"]:
            est["hechas"].append(slot)
        guardar_estado(est)
    avisar("\n".join(L), simulacro)
    return 1 if errores else 0


# ── arranque ──────────────────────────────────────────────────────────────────
def validar(cfg):
    R, prob = cfg["reglas"], []
    for u in cfg["unidades"]:
        if u["tipo"] not in ("CBO", "ABO"):
            prob.append(f"{u['nombre']}: tipo tiene que ser CBO o ABO")
        if float(u["base"]) > float(u["techo"]):
            prob.append(f"{u['nombre']}: la base es mayor que el techo")
        if u["tipo"] == "CBO" and u["mercado"] not in cfg["mercados"]:
            prob.append(f"{u['nombre']}: el mercado {u['mercado']} no está en «mercados»")
        if u.get("hora_bajar") and not re.fullmatch(r"\d\d:(00|30)", u["hora_bajar"]):
            prob.append(f"{u['nombre']}: hora_bajar va en punto o y media (HH:00 o HH:30)")
    for v in cfg.get("vueltas", []):
        if not re.fullmatch(r"\d\d:(00|30)", v["hora"]):
            prob.append(f"vuelta {v['hora']}: va en punto o y media")
    ids = [u["id"] for u in cfg["unidades"]]
    if len(ids) != len(set(ids)):
        prob.append("hay una campaña o conjunto repetido en «unidades»")
    if R["piso_extra_roas"] < R["empate_roas"]:
        prob.append("piso_extra_roas está debajo del empate: el dólar extra perdería plata")
    return prob


def main():
    global TOKEN
    p = argparse.ArgumentParser(description="Bot de escala por franja horaria")
    p.add_argument("--simulacro", action="store_true", help="lee y decide, no cambia nada")
    p.add_argument("--vuelta", help="HH:MM de la vuelta a simular")
    p.add_argument("--todas", action="store_true", help="con --simulacro: simula todas las vueltas del día")
    p.add_argument("--forzar", metavar="HH:MM", help="hace esa vuelta ahora, de verdad")
    a = p.parse_args()

    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    prob = validar(cfg)
    if prob:
        sys.exit("config.json tiene problemas:\n  - " + "\n  - ".join(prob))
    zona = timezone(timedelta(hours=cfg["huso_utc"]))
    ahora = datetime.now(zona)

    if PAUSA.exists() and not a.simulacro:
        print("PAUSA activa: el bot no toca nada. Se borra el archivo PAUSA solo con OK del dueño.")
        return 0
    if FRENADO.exists() and not a.simulacro:
        f = json.loads(FRENADO.read_text(encoding="utf-8"))
        if not f.get("hasta") or datetime.fromisoformat(f["hasta"]) > datetime.now(timezone.utc):
            print("FRENADO por Meta:", f.get("motivo"))
            return 0
        FRENADO.unlink()

    TOKEN = secreto("META_TOKEN", "bot-de-escala-meta")
    if not TOKEN:
        sys.exit("No encuentro el token de Meta (variable META_TOKEN o llavero «bot-de-escala-meta»).")

    if a.simulacro:
        if a.todas:
            horas = sorted({v["hora"] for v in cfg.get("vueltas", [])} |
                           {u["hora_bajar"] for u in cfg["unidades"] if u.get("hora_bajar")}, key=minutos)
            if (cfg.get("limpieza_abo") or {}).get("activa"):
                horas = sorted(set(horas) | {cfg["limpieza_abo"]["hora"]}, key=minutos)
            return max([vuelta(cfg, h, True) for h in horas] or [0])
        return vuelta(cfg, a.vuelta or franja(ahora), True)

    if CANDADO.exists() and time.time() - CANDADO.stat().st_mtime < 40 * 60:
        print("ya hay una vuelta corriendo")
        return 0
    slot = a.forzar or franja(ahora)
    est = leer_estado(ahora.date().isoformat())
    if not a.forzar and (slot in est["hechas"] or not hay_algo(eventos(cfg, slot, est))):
        return 0  # el reloj lo despierta seguido; solo trabaja en sus vueltas y no repite una ya hecha
    CANDADO.write_text(str(os.getpid()))
    try:
        if not esperar_red():
            avisar(f"Bot de escala · {ahora:%d/%m} vuelta {slot}: sin internet durante 30 minutos, vuelta perdida", False)
            return 1
        return vuelta(cfg, slot, False)
    finally:
        CANDADO.unlink(missing_ok=True)


if __name__ == "__main__":
    sys.exit(main())
