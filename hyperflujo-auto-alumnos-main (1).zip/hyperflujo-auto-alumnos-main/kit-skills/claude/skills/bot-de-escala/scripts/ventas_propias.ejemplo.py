"""Fuente de ventas propia del bot de escala — CONTRATO (Claude lo completa para tu plataforma).

Se usa cuando config.json tiene "fuente_ventas": "propia". Copialo como ventas_propias.py en la carpeta
del bot y completá ventas() contra la API OFICIAL de tu plataforma de cobro (Hotmart, Tiendanube,
Stripe, tu tienda, tu base de datos…). Buscá su documentación antes de escribir una línea.

Reglas que no se negocian (cada una sale de un error real):
  1. Solo ventas COBRADAS: pagos aprobados. Nada de carritos, pendientes ni rechazados.
  2. Pedí SOLO la ventana [desde, hasta) con un filtro por fecha EN LA CONSULTA. Nunca bajes la base o el
     historial entero para filtrar después: si la fuente tiene cupo diario (Firebase, Supabase y
     similares), leer todo en cada vuelta lo agota a media tarde y el bot se queda ciego.
  3. Las compras adicionales (upsells, order bumps) suman al cobrado pero no cuentan como venta nueva.
  4. Devolvé el cobrado en la MISMA moneda que la cuenta publicitaria (si no, convertí acá).
  5. Si la plataforma no responde, levantá una excepción: el bot pasa al plan B ("si_falla_fuente") y
     te avisa. Nunca devuelvas 0 ventas cuando en realidad no pudiste leer.
  6. El token de la plataforma sale del entorno o del llavero, nunca escrito en este archivo.
"""
import os


def ventas(mercado, desde, hasta):
    """Ventas cobradas de UN mercado entre desde y hasta (datetime con huso, el de la cuenta publicitaria).

    Devuelve (cantidad_de_ventas_principales, total_cobrado).
    """
    token = os.environ.get("TOKEN_DE_MI_PLATAFORMA")
    if not token:
        raise RuntimeError("falta el token de la plataforma de cobro")
    # Ejemplo de forma (reemplazar por la llamada real, con filtro por fecha y por mercado):
    #   pagos = api.listar_pagos(estado="aprobado", desde=desde.isoformat(), hasta=hasta.isoformat(),
    #                            pais=CODIGO_DEL_MERCADO[mercado])
    #   principales = [p for p in pagos if not p["es_adicional"]]
    #   return len(principales), sum(p["monto"] for p in pagos)
    raise NotImplementedError("Completar con la API oficial de tu plataforma de cobro")
