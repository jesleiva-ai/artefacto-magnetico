---
name: carga-creativos
description: Carga automática de una carpeta de Drive a tu cuenta publicitaria de Meta, de punta a punta, sin preguntar por el camino lo que ya está resuelto (solo frena ante lo que choca) — resuelve la marca desde tu archivo de configuración, descubre en qué número de TEST va la cuenta, baja y audita los videos, clona el conjunto molde, crea un conjunto y un anuncio por pieza SIEMPRE EN PAUSADO, y después renombra cada archivo en Drive con su número de TEST y lo mueve a la carpeta de subidos. Usar cuando digas "carga automática con <marca>", "/carga-creativos", "cargá esta carpeta a <marca>", "subí estos creativos a la cuenta de <marca>", o pases un link de carpeta de Drive junto al nombre de una de tus marcas. JAMÁS prende un anuncio — prender es decisión tuya en el Administrador.
allowed-tools: Bash, Read, Write, Edit, mcp__claude_ai_Google_Drive__get_file_metadata, mcp__claude_ai_Google_Drive__get_file_permissions, mcp__claude_ai_Google_Drive__search_files, mcp__claude_ai_Google_Drive__download_file_content, mcp__claude_ai_Google_Drive__update_file
---

# Carga automática: de una carpeta de Drive a la cuenta publicitaria

Decís **«carga automática con <marca>»** y pegás un link de Drive. Con eso alcanza.
Esta skill es todo lo que va después, sin volver a preguntarte lo que ya está resuelto: solo frena ante
lo que choca (un video que no pasa la auditoría, un molde que no aparece, un permiso que falta).

**El disparador es siempre el mismo:** un nombre de marca + un link de carpeta de
Drive. Si falta la marca, se deduce del propio Drive (paso 1). Si falta el link,
es lo único que se pregunta.

## Qué necesitás tener montado (una sola vez)

- **Conector de Meta Ads** en Claude (el oficial de Meta: herramientas `ads_*`) con
  acceso a tus cuentas publicitarias.
- **Conector de Google Drive** en Claude.
- **ffmpeg y ffprobe** instalados (para auditar los videos), y opcionalmente
  `tesseract` para leer el texto en pantalla.
- **El archivo de configuración** `config.json` al lado de esta skill (copiá
  `config.ejemplo.json` y completalo). Ahí viven tus marcas, cuentas, campañas de
  testeo, moldes y carpetas. Esta skill no guarda ningún ID adentro: si cambia una
  cuenta, cambiás el archivo y listo.

Si `config.json` no existe o tiene campos vacíos, el **paso 0** es completarlo con
vos: pedí los datos que faltan de una sola vez, en una lista, y guardalo.

## Lo que esta skill NO hace, nunca

- **No prende nada.** Todo nace `PAUSED` y se queda `PAUSED`. Prender es tuyo, en
  el Administrador. Tampoco toca presupuestos de nada que ya exista.
- **No inventa el copy.** El copy sale del anuncio molde de la propia cuenta,
  leído por API. Si en la campaña hay más de un copy vigente, se te muestran y
  elegís vos. **Antes de clonarlo, cada promesa del copy del molde (garantía,
  cantidades, plazos) se coteja con lo que hoy vende la landing**: un molde viejo
  puede seguir prometiendo una garantía que ya no existe. Lo que choca se pregunta
  antes de cargar; nunca se corrige solo ni se clona callado.
- **No carga lo que no sabe de dónde vino.** La carpeta de nuevos puede tener
  piezas ajenas a la tanda; si hay algo que no se reconoce, se muestra la lista antes.
- **No crea la campaña de testeo si no existe.** Crear una es decisión tuya. Ahí
  se para y se pregunta.
- **No borra nada de Drive.** Mueve, no borra.

## Paso 0 — Configuración y semáforo de la tienda

1. Leé `config.json`. Si falta, armalo con vos desde `config.ejemplo.json`.
2. Si tu marca tiene un chequeo propio de la tienda (landing publicada, checkout,
   precio, entrega, píxel), corrélo antes. **Ninguna tanda se carga sobre una
   tienda rota.** Si no tenés uno, como mínimo abrí la landing de destino con
   `curl` y confirmá que responde 200 y que el link del molde apunta ahí.

## Paso 1 — Resolver la marca y la carpeta

Con el nombre de marca, buscá su bloque en `config.json`. El link de Drive
confirma la marca sin creerle al nombre de la carpeta: pedí el metadato del
folder y **subí por las carpetas contenedoras** (`parentId`) hasta la carpeta raíz de la marca.

```
mcp__claude_ai_Google_Drive__get_file_metadata(fileId=<id del link>)
→ title, parentId, owner   … y otra vez con el parentId hasta la raíz de la marca
```

Ese recorrido da también la carpeta hermana **de subidos** (destino del paso 7).
Si no aparece, usá la que diga `config.json`.

### Chequeá el permiso de ESCRITURA acá, no en el paso 7

Leer y escribir en Drive son dos permisos distintos, y una carpeta compartida
«por link» casi siempre viene de solo lectura:

```
mcp__claude_ai_Google_Drive__get_file_permissions(fileId=<nuevos>)
```

**`{"role":"reader","type":"anyone"}` y nada más = NO se va a poder renombrar ni
mover.** Si el permiso no está, **la carga a Meta se hace igual** —es lo que de
verdad importa— y el paso 7 queda como lo único pendiente, con la salida concreta:
darle permiso de Editor a la cuenta con la que está conectado el conector.

## Paso 2 — Listar la carpeta y armar el plan

Listá los videos de la carpeta de nuevos con el conector
(`search_files` con `parentId = '<id>' and mimeType = 'video/mp4'`). Ojo: si la
carpeta es de otra cuenta de Google, el conector puede devolver `{}` y eso **NO
significa vacía**: verificalo abriendo la carpeta en el navegador antes de seguir.

**El número de TEST sale de la cuenta, no de una suposición.** Listá los
conjuntos de la campaña de testeo (`ads_get_ad_entities`) y buscá el máximo real
**contando los repetidos como uno solo**: si hay números duplicados, «el último + 1»
es un error conocido.

Escribí un `plan.json` en el scratchpad con una fila por pieza: `test`,
`archivo`, `drive_id`. Ordená por nombre para que la asignación sea determinista.

**Verificá el plan contra Drive con código, no a ojo**: ids que sobran, ids que
faltan, nombres que no coinciden, números de TEST repetidos o no correlativos.
Cualquiera de esas cosas es `[error]` y se para.

## Paso 3 — Bajar los videos

Bajá cada archivo a una carpeta de trabajo (`~/Downloads/<marca>-tanda-<fecha>/`)
con el conector de Drive o con `curl` si la carpeta está compartida por link.
Chequeá con `file` que cada archivo sea un mp4 real: una pantalla de login de
Google se baja igual, pesa poco y es HTML.

## Paso 4 — Auditar la tanda

Por cada pieza, con `ffprobe` y `ffmpeg`:
- formato (9:16 o 4:5), duración, que no arranque en negro;
- **el texto en pantalla**, leído con OCR sobre 6-8 cuadros. El nombre del archivo
  miente: se cuelan piezas con texto en otro idioma. Y el texto **es copy que
  promete**: cotejá lo que afirma (formato, cantidad, acceso, garantía) contra el
  producto real y **avisá lo que no cierre, sin frenar la carga por eso**.

## Paso 5 — Subir los videos

Con el conector de Meta (`ads_creative_upload_media`). Si el conector solo acepta
URL pública, pedile al dueño que comparta él mismo la carpeta «cualquiera con el enlace»
(nunca cambies el permiso vos) y que la vuelva a cerrar al terminar; recién ahí usá el link
de descarga directa. Anotá el `video_id` en el plan pieza por pieza y
**cortá ante el primer error** en vez de seguir subiendo a ciegas.

## Paso 6 — Crear conjuntos y anuncios, EN PAUSADO

1. Leé el conjunto molde (el que diga `config.json`, por defecto `TEST 1`) y un
   anuncio vigente con su `object_story_spec` completo.
2. Un conjunto **por pieza**, clonando presupuesto, puja, píxel, evento,
   segmentación y ventana de atribución del molde. **Nunca inventes el
   presupuesto**: sale del molde.
   **COMPUERTA — el primero se compara antes de seguir.** Creá UN conjunto,
   releelo y compará campo por campo contra el molde (`targeting` completo,
   presupuesto, puja, píxel, atribución). Recién si da igual, creá el resto.
   La API puede reescribir campos sin avisar (por ejemplo
   `targeting.user_age_unknown`): pasá esos campos explícitos en todos.
3. Un anuncio por conjunto, con el copy del molde y el video de la pieza. Conjunto
   y anuncio llevan **el mismo nombre**: `TEST N`. Si `config.json` indica página
   e Instagram para la marca, verificá releyendo que el anuncio quedó con esos y no
   con los que traía el molde.
4. Si el molde tiene todas las mejoras automáticas de Advantage+ creativo en
   `OPT_OUT`, replicá eso.

## Paso 7 — Devolver el resultado a Drive

Renombrar cada archivo a `TEST N` y moverlo de nuevos a subidos. El conector lo
hace en una sola llamada:

```
mcp__claude_ai_Google_Drive__update_file(fileId=<id>, title="TEST N", parentId=<id de subidos>)
```

Releé el metadato: `parentId` ya tiene que ser el destino. Si el conector rechaza
algún archivo (suele pasar con archivos cuyo dueño es otra cuenta), dejá dicho
contra qué archivo y con qué mensaje, y movelo a mano. Después de mover, **dale
unos segundos antes de verificar**: Drive tarda en sacar la fila del origen.

**Lo que queda en nuevos es, por definición, lo que no entró a Meta.** Por eso
este paso no es cosmético: es el índice.

## Paso 8 — Verificar por artefacto y reportar

No alcanza con que ningún paso haya tirado error. Volvé a **leer la cuenta** y
contá con código:

- cuántos conjuntos `TEST N..M` existen y cuántos tienen exactamente 1 anuncio;
- que **ninguno** quedó en `ACTIVE`;
- que cada anuncio apunta al `video_id` que le tocaba, leído en
  `creative.object_story_spec.video_data.video_id` (no en `creative.video_id`,
  que es una copia que Meta hace a nombre de la página y nunca coincide);
- que la tanda habla **un solo idioma**: video, copy, dominio del link y países;
- y volvé a listar las dos carpetas de Drive: nuevos vacía, subidos con las
  piezas renombradas.

Cerrá con una tabla `TEST N → archivo → video_id → adset_id` y **una línea que
diga que falta prenderlos**. Una corrida que no cambió nada es `[error]`, no `[ok]`.

## Al final

Si tenés el segundo cerebro instalado, ofrecé `/orden` para guardar la tanda y
`/aprende` si algo del proceso falló de una forma que conviene evitar la próxima.
