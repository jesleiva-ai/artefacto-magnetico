---
name: cloaker-xray
description: Chequea si una landing ajena te está sirviendo a VOS una página distinta de la que le sirve al comprador real (cloaking). Corre la misma URL con varias identidades —celular que viene del anuncio, visitante directo, escritorio, revisor de Meta, buscador, otro idioma— más el render con JavaScript, mide el piso de ruido de la propia página para no confundir un test A/B con un cloaker, y dice cuál de las versiones es la que recibe el dinero. Usar cuando el usuario diga /cloaker-xray, "¿me están mostrando otra página?", "chequeá si hay cloaking", "esta landing no me cierra", "¿esto es la posta o la vidriera?", cuando una referencia se vea sospechosamente floja para los días que lleva escalando, o como pasada 0b de /desarme-completo antes de medir cualquier landing. Solo lectura.
---

# Rayo-X de cloaking: ¿te sirven la misma página que al comprador?

## El problema, en una línea

`rompe_placebos.py` contesta **¿los anuncios apuntan a esta URL?**. Esta skill
contesta la de arriba: **aunque la URL sea la correcta, ¿el contenido que te
devuelven a vos es el mismo que le devuelven al que paga?**

Un operador puede ramificar por dispositivo, por referrer, por país, por idioma
o por "esto parece un revisor". Si medís, copiás y modelás la versión de
vidriera, **todo el desarme queda construido sobre la página equivocada**. Ya
pasó en un caso real: una referencia pública (instanthandbook) se descartó por
error porque en el navegador aparecía una landing anti-hype
([[pagina-placebo-blindaje-y-espionaje]]).

## El comando

```
python3 ~/herramientas/cloaking.py <url> [--desde <url-real-del-anuncio>] [--guardar <dir>] [--json]
python3 ~/herramientas/cloaking.py --autotest     # el detector contra un cloaker local
```

| Exit | Veredicto | Qué se hace |
|---|---|---|
| 0 | `[limpio]` | todas las identidades reciben la misma oferta → medí tranquilo |
| 1 | `[sospechoso]` | hay contenido diferencial que cambia la oferta → **medí con la receta que imprime**, y anotá en el rayo-X qué versión mediste |
| 2 | `[indeterminado]` | no se pudo determinar → el rayo-X se marca **"sin confirmar"**. **Jamás se reporta como limpio** ([[2026-07-27-cerebro-ia-el-proxy-miente]]) |

`--desde` es la URL exacta que sale de `rompe_placebos.py` (con sus parámetros):
la identidad "comprador-anuncio" la usa tal cual. Con eso el chequeo deja de
depender de un `fbclid` inventado.

## Cómo funciona (para saber qué creerle)

**Comparar es el método.** Una sola visita no detecta nada. Se pide la misma URL
con ocho identidades y la señal es la diferencia entre ellas:

| Identidad | Qué representa |
|---|---|
| `comprador-anuncio` | celular Android + Referer de Facebook + fbclid — **la referencia: el que paga** |
| `comprador-ig` | navegador embebido de Instagram |
| `visitante-directo` | mismo celular, sin referer (el espía) |
| `escritorio-directo` | Chrome de escritorio |
| `revisor-meta` | `facebookexternalhit` (el scraper de Meta) |
| `buscador` | Googlebot |
| `idioma-en` | `Accept-Language: en-US` |
| `control` | **repetición exacta de la referencia, al final de la corrida** |

Más dos renders reales con JavaScript (Chrome por CDP) para el comprador y para
el visitante directo.

### El control es la pieza que evita gritar lobo

Diferencia no es cloaking. Un test A/B, un banner de cookies, un contador o un
precio en otra moneda dan diferencias legítimas. El `control` pide la página una
segunda vez con la identidad idéntica: **lo que se mueve entre dos pedidos
iguales es ruido de la página, no cloaking**, y fija el umbral del resto de la
corrida. Si la página ni siquiera coincide consigo misma (<65%), el veredicto
baja a `indeterminado` en vez de acusar.

### Señales DURAS (mandan el veredicto)

- **destino distinto** — dos identidades terminan en URLs distintas
- **solo una versión cobra** — una tiene checkout+precio y la otra no
- **el dinero va a otro lado** — los destinos de pago no se pisan
- **otra oferta** — cambian el titular Y los encabezados, en el mismo idioma
- **el JavaScript te muda de página** — sin JS quedás en A, con JS terminás en B
- **cloaker declarado** — la firma completa está en el código (abajo)

### Señales BLANDAS (solo avisan)

Localización por idioma, localización por moneda, "misma oferta con otra piel"
(el texto cambia pero el esqueleto numérico de la oferta y el checkout no se
movieron: es una traducción), y "no atribuible" cuando la página ya se movía
sola.

### La firma del cloaker: evidencia, no inferencia

Un cloaker de verdad no es "código condicional" (eso lo tiene cualquier
analítica). Es la maquinaria entera, y `cloaking.py` la busca **abriendo también
los scripts de primera parte** — viven en un subdominio del propio sitio
(`track.midominio.com`) justo para no parecer un tercero:

1. esconde el body mientras decide
2. te toma las huellas digitales (UA, referrer, huso, pantalla, idiomas, fbclid, GPU)
3. chequea si sos un navegador automatizado (`navigator.webdriver`, Puppeteer…)
4. manda el perfil a su servidor
5. **el servidor devuelve la sentencia y el script te muda** (obligatorio para
   que cuente como firma)
6. cachea la decisión
7. a veces trae un modo "verificación" que cierra la ventana del revisor

Si además el `<script>` lleva un `data-ref`, ese es el token de «vengo del
anuncio»: la skill lo reporta para que pruebes la URL con `?ref=<token>`.

## Cuál versión recibe el dinero (lo que después se desarma)

Cuando hay salto por JavaScript hay dos arquitecturas opuestas y **no se
distinguen a ojo**:

- **funnel legítimo** → el salto *lleva* al comprador al paso que cobra: la que
  cobra es el destino.
- **cloaker** → el salto *saca* al que no calificó y lo deposita en un señuelo:
  la que cobra es la que estaba **antes** del salto, en la URL que compran los
  anuncios.

`cloaking.py` decide por la firma: si la maquinaria está en el código, el salto
es una sentencia y no un paso de funnel. En ese caso reporta la versión
pre-salto como la que recibe el dinero, nombra el señuelo, y baja la confianza a
media avisando que **la versión del comprador no la vimos renderizada**.

## Qué NO se puede ver desde acá (decilo, no lo escondas)

- **Geo real por IP.** Cambiar de país exige salir por una IP de ese país y no
  tenemos exit nodes. `Accept-Language` y el locale del navegador solo tocan la
  rama de idioma. Un sitio que ramifica por IP en el servidor **no se detecta
  desde esta Mac**: sale como `[límite]` en toda corrida, y no cuenta como limpio.
- **La versión del comprador real detrás de un cloaker vivo.** El cloaker
  clasifica con IP, GPU, engagement y huso: cualquier navegador nuestro cae del
  lado equivocado. Lo que sí se ve es lo que el servidor manda **antes** de que
  el script decida.
- **Cloaking dentro del checkout.** Solo se mira la landing: no se mandan
  formularios ni se compra nada.

## Dónde encaja

Es la **pasada 0b** de `/desarme-completo`, entre el rompe-placebos y el
pipeline de medición. `desarme.sh` ya la corre sola y escribe `00b-cloaking.txt`:

- `[limpio]` → sigue normal
- `[sospechoso]` / `[indeterminado]` → **no frena** (a diferencia del placebo,
  acá la URL sí puede ser la correcta), pero deja la advertencia en mayúsculas
  en `VEREDICTO.txt` y el rayo-X se marca "medido sobre la versión que nos
  sirvieron a nosotros".

La diferencia con `rompe_placebos.py`, que conviene tener clara:

| | pregunta | criterio duro |
|---|---|---|
| `rompe_placebos.py` | ¿es ESTA la URL que compran los anuncios? | el destino de los anuncios activos |
| `cloaking.py` | ¿es ESTE el contenido que recibe el comprador? | la diferencia entre identidades, contra el ruido de la propia página |

Las dos pueden dar limpio y la página seguir siendo mentirosa por geo. Por eso
el límite se imprime siempre.

## Lo que NO se hace

Solo lectura: se piden páginas y se leen. No se manda ningún formulario, no se
compra, no se toca ninguna plataforma y no se intenta evadir el cloaker
falsificando identidad más allá de las cabeceras que manda cualquier navegador.
Si el cloaker gana, se reporta que ganó — no se fuerza.
