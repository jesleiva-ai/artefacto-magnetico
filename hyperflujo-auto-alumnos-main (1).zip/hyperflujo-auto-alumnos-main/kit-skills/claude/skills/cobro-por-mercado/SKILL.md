---
name: cobro-por-mercado
description: Se asegura de que cada mercado donde vendés tenga los MEJORES medios de pago de ese país, activos y visibles en el checkout. Investiga en internet (documentación oficial de Stripe primero, después fuentes del mercado) qué medios usa la gente en cada país, cruza contra lo que tu cuenta de Stripe puede cobrar de verdad (incluida la tabla de cobros entre países), lee tu cuenta y tus cobros reales por API en solo lectura, prueba tu checkout con IP de cada país y te entrega qué prender, qué falta y qué no se puede. Usar SIEMPRE que se lance un producto, se abra un idioma o un mercado, se clone una tienda o se conecte una LLC o un Stripe nuevo — cualquier nicho, idioma o mercado — y cuando el dueño diga /cobro-por-mercado, "¿qué medios de pago necesito en X?", "revisá los métodos de pago", "¿cobro bien en X?", "abrí la LLC". También sin LLC (Whop / Impul Pay). Solo lee y prueba: nunca cambia nada en Stripe ni en la tienda.
---

# /cobro-por-mercado — los mejores medios de pago en cada mercado

**Por qué existe.** En muchos países la gente no paga con tarjeta: paga con la app de su
banco, una billetera o un voucher. Si ese botón no aparece en tu checkout, el comprador
llega hasta el final y se va, y nada te avisa: no da error, solo vende menos. Una LLC
nueva arranca con su cuenta de Stripe en cero. Por eso esta skill corre **siempre**, en
cada lanzamiento, y se le recuerda al dueño **antes de hablar de anuncios**.

**Lo que no se sepa de un país, se busca.** Nunca se contesta de memoria: los medios de
pago, sus monedas y sus restricciones cambian seguido.

Guía para leer con el dueño: `https://claude.ai/artifact/BkPRejwk142zyWVBaaTxTY`
(Cobrar en cada país).

## Recomendaciones del programa (el dueño decide; si declara otra cosa, manda lo suyo)
- **PayPal: no se recomienda** para productos digitales: el comprador tiene 180 días
  para disputar, la protección al vendedor casi nunca cubre bienes intangibles, cada
  disputa suma a la tasa de reclamos, y Stripe no ofrece PayPal a cuentas de EE. UU. ni
  en plataformas que hospedan tiendas de terceros.
- **Multibanco (Portugal) y otros vouchers: prendidos + recuperación por mail.** El
  comprador recibe datos para pagar después y muchos se olvidan: secuencia de mails
  (datos de pago al instante, recordatorios, un regalo por completar el pago, acceso
  apenas se confirma).
- **Impul Pay (Whop gestionado por Impultienda) se puede tener junto con Stripe.** La
  prueba del paso 5 confirma que los medios locales de Stripe se sigan viendo.
- **Nada de compras de prueba:** la prueba la hace Claude con una IP del país.

## Entrada
País o países (código de 2 letras), la dirección del checkout de la tienda y con qué
se cobra: Stripe (de qué LLC) o Whop / Impul Pay sin LLC. Para leer Stripe hace falta
una **clave restringida de SOLO LECTURA** de esa cuenta guardada en
`~/herramientas/.env` (por defecto `STRIPE_KEY_LECTURA=rk_live_...`; una LLC nueva, su
propia variable). Si falta, explicale al dueño en una línea cómo crearla (Stripe →
Desarrolladores → Claves de API → Crear clave restringida, todo en «Lectura») y seguí
con los pasos que no la necesitan. Nunca pidas la clave secreta completa ni la pegues
en el chat o en una nota.

En Windows usá `py -3` donde abajo dice `python3`.

## Pasos

### 1. Investigar el país (internet, cada dato con su procedencia)
Marcá cada dato como *documentación oficial · terceros · medido en la cuenta*.
1. **Documentación oficial de Stripe**: `https://docs.stripe.com/payments/payment-methods/payment-method-support`
   (países y monedas) y la página de cada medio candidato (`https://docs.stripe.com/payments/<medio>`).
   En cada una leé **tres cosas**: *Customer locations*, *Presentment currency* y
   **Business locations + Cross-border payments** (si una cuenta del país de tu LLC
   puede cobrarle a ese país).
   Trampa conocida: Klarna figura disponible para cuentas de EE. UU., pero con una
   cuenta de EE. UU. **solo cobra a compradores de EE. UU. en dólares**. Eso está en la
   sección Cross-border, no en la tabla. Revisá esa sección en todos los medios.
2. **Qué usa la gente** para pagar online en ese país: WebSearch (guías de Stripe por
   país, informes de pagos del mercado, el banco central). Buscá la participación de
   cada medio: billetera, banco, voucher, cuotas, tarjeta.
3. **Lo medido en la cuenta** (paso 3) le gana a cualquier informe.
No escribas «no existe» ni «no se puede» sin la fuente oficial abierta en esta sesión.

Referencia rápida (verificar igual, cambia): BLIK en Polonia (PLN) · iDEAL en Países
Bajos (EUR) · Bancontact en Bélgica (EUR) · Satispay en Italia (EUR) · EPS en Austria
(EUR) · Bizum en España (EUR, pide número fiscal) · MB WAY y Multibanco en Portugal
(EUR) · OXXO en México (MXN, voucher) · Pix en Brasil (BRL) · UPI en India (INR).
Con cuenta de EE. UU. no hay MobilePay, Swish, TWINT ni Vipps: ahí se cobra con
tarjeta, Apple Pay y Google Pay.

### 2. Leer la cuenta de Stripe (solo lectura)
`python3 ~/.claude/skills/cobro-por-mercado/scripts/stripe_medios.py [--key-env VARIABLE]`
- Capacidades activas e inactivas de la cuenta.
- Las configuraciones de medios: la **PROPIA** (ahí se prende; el dueño la puede editar)
  y la de **Impultienda** u otra plataforma (no se puede editar y ya viene con todo
  prendido). Un medio aparece en el checkout solo si está **activo en la cuenta**: eso se
  logra prendiéndolo en la configuración propia (Stripe → Configuración → Métodos de pago).
- Un medio en «Pendiente» pide datos: decí cuáles.

### 3. Leer lo cobrado de verdad
El mismo script trae los cobros de los últimos 30 días por medio y por país, con los
fallidos. Un medio fuerte del país con 0 cobros es la alarma: no aparece, o el precio no
está en la moneda local.

### 4. Leer el checkout publicado
`python3 ~/.claude/skills/cobro-por-mercado/scripts/leer_checkout.py <checkout> PL NL ...`
Revisá: moneda local (si sale en dólares, el medio local no aparece: crear el mercado
en Markets y cargar el precio en CADA producto, bono y post-compra), «Métodos de pago
locales» prendido (Configuraciones → Pagos, es por tienda y nace apagado), `prefs` vacío
(ningún medio apagado a mano), qué cuenta de Stripe cobra, PayPal, Impul Pay / Whop.

### 5. Probar con IP real del país
`python3 ~/.claude/skills/cobro-por-mercado/scripts/proxy_pais.py <CC> https://www.<dominio>/`
→ `leer_checkout.py <checkout> <CC> --proxy <proxy>`. Para ver los botones de pago que
dibuja Stripe, abrí el checkout en un navegador que salga por ese proxy y leé lo que se
ve: tiene que aparecer el medio local y el precio en la moneda del país. Si no hay proxy
limpio del país, usá `?country=XX` y decile al dueño que la prueba con IP real quedó
pendiente.

### 6. Entregar
Una tabla por país: **medio · participación (fuente) · ¿la cuenta lo puede cobrar? ·
¿activo? · ¿se ve en el checkout? · cobros 30 días · qué hacer**. Lo que hay que hacer
puede ser: prenderlo en la configuración propia de Stripe · completar los datos de un
medio pendiente · crear el mercado en moneda local · prender los medios locales en la
tienda · «no se puede con esta cuenta» (decí con qué se cobra ahí). Cambiar algo en
Stripe o en la tienda lo hace el dueño o lo autoriza explícitamente; leer y probar se
hace sin preguntar. Proponé repetir la prueba del paso 5 cada vez que se toque la tienda.
Si aparece algo nuevo (un medio, una trampa, un país), guardalo con /orden.

## Sin LLC (Whop / Impul Pay)
Sin Stripe no hay medios locales de Stripe: lo que manda es **cuántos pagos aprueba Whop
en cada país**. Pedile al dueño el dato al equipo de Impultienda. Referencia de octubre
de 2026: España 84 %, Reino Unido 82 %, Irlanda 82 %; Hungría, Rumania, Suiza, República
Checa, Alemania, Croacia y Chipre entre 70 y 79 %; Bulgaria, Dinamarca, Francia y
Eslovaquia entre 67 y 69 %. Arrancar por los de 80 % o más; debajo de 70 % se pierde casi
un tercio de las ventas en el checkout. Whop no cobra a compradores de Argentina: ahí va
Mercado Pago.
