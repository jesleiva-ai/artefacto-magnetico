# -*- coding: utf-8 -*-
"""leer_checkout.py — lee lo que ve el COMPRADOR en un checkout de Impultienda, por pais.
Uso: python3 leer_checkout.py <url del checkout> PL NL BE ... [--proxy socks5://ip:puerto]
Sin --proxy usa ?country=XX (aproximacion: avisarle al dueño que la IP real quedo pendiente).
Con --proxy (sacarlo de proxy_pais.py <CC> <tienda>, en esta misma carpeta) va por IP real del pais.
Imprime por pais: moneda, pais detectado, medios locales ON, prefs (medios apagados a mano), cuenta de Stripe,
PayPal / Whop / Impul Pay / dLocal. Falla cerrada: HTTP != 200 o pagina sin checkout = [error]."""
import re, subprocess, sys
for _s in (sys.stdout, sys.stderr):
    try: _s.reconfigure(encoding='utf-8')
    except Exception: pass
args = [a for a in sys.argv[1:] if not a.startswith('--')]
proxy = None
if '--proxy' in sys.argv:
    i = sys.argv.index('--proxy')
    if i + 1 >= len(sys.argv): sys.exit('[error] --proxy necesita un valor: socks5://ip:puerto')
    proxy = sys.argv[i + 1]
if proxy in args: args.remove(proxy)
url, paises = args[0], args[1:] or ['']
F = ["ebook-currency", "buyer-country", "live-country", "stripe-enabled", "stripe-pe-enabled", "stripe-pe-prefs",
     "stripe-account-id", "stripe-account-country", "paypal-enabled", "whop-enabled", "whop-embed-enabled",
     "impulpay-page-enabled", "dlocal-card-enabled", "store-custom-domain"]
fallo = False
for cc in paises:
    u = url + (('&' if '?' in url else '?') + 'country=' + cc if cc and not proxy else '')
    cmd = ['curl', '-sL', '-A', 'Mozilla/5.0', '--max-time', '120', '-w', '\n%{http_code}', u]
    if proxy: cmd[1:1] = ['-x', proxy]
    out = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace').stdout
    html, code = out.rsplit('\n', 1) if '\n' in out else (out, '0')
    if code != '200' or 'stripe-enabled' not in html:
        print(f'[error] {cc or "-"}: HTTP {code} o no es un checkout'); fallo = True; continue
    d = {k: (re.search(r'id="%s"\s+value="?([^">]*)' % re.escape(k), html) or [None, '(ausente)'])[1] for k in F}
    print(f"{cc or '-':3} via={'IP real' if proxy else '?country'} moneda={d['ebook-currency']} detectado={d['live-country']} "
          f"locales={d['stripe-pe-enabled']} prefs={d['stripe-pe-prefs']} stripe={d['stripe-account-id'][-6:]}({d['stripe-account-country']}) "
          f"paypal={d['paypal-enabled']} whop={d['whop-enabled']}/{d['whop-embed-enabled']} impulpay={d['impulpay-page-enabled']} "
          f"dlocal={d['dlocal-card-enabled']} dominio={d['store-custom-domain']}")
print('[error] hubo checkouts sin leer' if fallo else '[ok] checkouts leidos')
sys.exit(1 if fallo else 0)
