# -*- coding: utf-8 -*-
"""proxy_pais.py — busca un proxy gratuito que salga DE VERDAD por el pais pedido y no intercepte TLS.
Uso: python3 proxy_pais.py <ISO-2, ej. GR> [https://www.<tienda>/]   → imprime los que sirven, el mejor primero, como
     <protocolo>://ip:puerto  (listo para curl -x y para Chrome --proxy-server).
Fuentes: proxyscrape v4 y geonode. Valida TODOS en paralelo contra ipinfo (muchos «GR» salen por otro pais) y, si se da la
tienda, exige que el certificado valide (ssl_verify_result 0) y que responda 200. Sale 1 si no queda ninguno: en ese caso se
verifica con ?country=XX y se le avisa al dueño que la IP real quedo pendiente."""
import json, os, subprocess, sys, urllib.request
for _s in (sys.stdout, sys.stderr):
    try: _s.reconfigure(encoding='utf-8')
    except Exception: pass
from concurrent.futures import ThreadPoolExecutor
cc = sys.argv[1].upper(); tienda = sys.argv[2] if len(sys.argv) > 2 else None
UA = {'User-Agent': 'Mozilla/5.0'}
cand = set()
try:
    t = urllib.request.urlopen(urllib.request.Request(f'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&country={cc.lower()}&proxy_format=protocolipport&format=text&timeout=20000', headers=UA), timeout=30).read().decode()
    cand |= {l.strip() for l in t.splitlines() if '://' in l}
except Exception as e: print('proxyscrape:', str(e)[:80])
try:
    j = json.load(urllib.request.urlopen(urllib.request.Request(f'https://proxylist.geonode.com/api/proxy-list?country={cc}&limit=200&page=1&sort_by=lastChecked&sort_type=desc', headers=UA), timeout=30))
    for p in j.get('data', []):
        for pr in p.get('protocols', []): cand.add(f"{pr}://{p['ip']}:{p['port']}")
except Exception as e: print('geonode:', str(e)[:80])
try:   # tercera fuente: lista de monosans con geolocalizacion (se actualiza cada hora)
    j = json.load(urllib.request.urlopen(urllib.request.Request('https://raw.githubusercontent.com/monosans/proxy-list/main/proxies.json', headers=UA), timeout=60))
    for p in j:
        if ((p.get('geolocation') or {}).get('country') or {}).get('iso_code') == cc: cand.add(f"{p['protocol']}://{p['host']}:{p['port']}")
except Exception as e: print('monosans:', str(e)[:80])
print(f'{len(cand)} candidatos de {cc}')
def probar(px):
    try:
        r = subprocess.run(['curl', '-s', '-m', '18', '-x', px, 'https://ipinfo.io/json'], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=25)
        j = json.loads(r.stdout)
        if j.get('country') != cc: return None
        seg = float(subprocess.run(['curl', '-s', '-o', os.devnull, '-m', '18', '-x', px, '-w', '%{time_total}', 'https://ipinfo.io/json'], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=25).stdout or 99)
        if tienda:
            v = subprocess.run(['curl', '-s', '-o', os.devnull, '-m', '40', '-x', px, '-w', '%{ssl_verify_result} %{http_code}', tienda], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=50).stdout.split()
            if v != ['0', '200']: return None
        return (seg, px, j.get('city'), j.get('org'))
    except Exception: return None
with ThreadPoolExecutor(40) as ex: ok = sorted(x for x in ex.map(probar, cand) if x)
for seg, px, ciudad, org in ok[:8]: print(f'{px}   {ciudad} · {org} · {seg:.1f}s')
if not ok: sys.exit(f'[x] ningun proxy de {cc} sirve ahora')
