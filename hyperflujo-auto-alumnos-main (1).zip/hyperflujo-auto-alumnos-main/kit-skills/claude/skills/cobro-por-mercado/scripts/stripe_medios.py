# -*- coding: utf-8 -*-
"""stripe_medios.py — que medios tiene ACTIVOS una cuenta de Stripe y con cuales cobro de verdad (solo lectura).
Uso: python3 stripe_medios.py [--key-env STRIPE_KEY_LECTURA] [--dias 30]
La clave sale de ~/herramientas/.env (variable indicada). Una LLC nueva = su propia clave de lectura.
Imprime: (1) capacidades activas/inactivas de la cuenta, (2) cada configuracion de medios (la propia y la de
Impultienda, que el vendedor NO puede editar) con lo disponible, (3) cobros por medio y por pais de la tarjeta/
facturacion, con fallidos. 'Disponible' en la de Impultienda = capacidad activa en la cuenta + preferencia on."""
import base64, collections, json, os, sys, time, urllib.parse, urllib.request
for _s in (sys.stdout, sys.stderr):
    try: _s.reconfigure(encoding='utf-8')
    except Exception: pass
env = sys.argv[sys.argv.index('--key-env') + 1] if '--key-env' in sys.argv else 'STRIPE_KEY_LECTURA'
dias = int(sys.argv[sys.argv.index('--dias') + 1]) if '--dias' in sys.argv else 30
try:
    for l in open(os.path.expanduser('~/herramientas/.env'), encoding='utf-8'):
        if l.startswith(env + '='): os.environ[env] = l.split('=', 1)[1].strip().strip('"\'')
except FileNotFoundError: pass
K = os.environ.get(env) or sys.exit(f'[error] falta {env}: creá una clave restringida de SOLO LECTURA en Stripe (Desarrolladores → Claves de API) y guardala en ~/herramientas/.env como {env}=rk_live_...')
H = {'Authorization': 'Basic ' + base64.b64encode((K + ':').encode()).decode()}
get = lambda p: json.load(urllib.request.urlopen(urllib.request.Request('https://api.stripe.com/v1/' + p, headers=H), timeout=60))
a = get('account'); print(f"== cuenta {a['id']} pais={a.get('country')} {(a.get('business_profile') or {}).get('name')}")
caps = a.get('capabilities', {})
print('  ACTIVAS:', ', '.join(sorted(k.replace('_payments', '') for k, v in caps.items() if v == 'active')))
print('  NO ACTIVAS:', ', '.join(sorted(f"{k.replace('_payments', '')}({v})" for k, v in caps.items() if v != 'active')))
for c in get('payment_method_configurations?limit=20')['data']:
    quien = 'IMPULTIENDA u otra plataforma (no editable)' if c.get('parent') else 'PROPIA (aca se prende)'
    disp = sorted(k for k, v in c.items() if isinstance(v, dict) and v.get('available'))
    print(f"== config {c['id']} · {quien}\n  disponibles: {', '.join(disp)}")
todo, sa, desde = [], None, int(time.time()) - dias * 86400
while True:
    q = {'limit': 100, 'created[gte]': desde}
    if sa: q['starting_after'] = sa
    d = get('charges?' + urllib.parse.urlencode(q)); todo += d['data']
    if not d['has_more']: break
    sa = d['data'][-1]['id']
ok, ko = collections.Counter(), collections.Counter()
for x in todo:
    pm = x.get('payment_method_details') or {}; t = pm.get('type', '?')
    w = ((pm.get('card') or {}).get('wallet') or {}).get('type')
    pais = (pm.get(t) or {}).get('country') or ((x.get('billing_details') or {}).get('address') or {}).get('country') or '?'
    (ok if x['status'] == 'succeeded' else ko)[(pais, t + ('/' + w if w else ''))] += 1
print(f'== cobros {dias} d: {sum(ok.values())} aprobados / {len(todo)} intentos ({100*sum(ok.values())//max(len(todo),1)} %)')
for (p, t), n in sorted(ok.items(), key=lambda z: (z[0][0], -z[1])):
    print(f'  {p:3} {t:22} {n:5} aprobados  {ko.get((p, t), 0):4} fallidos')
print('  (pais "?" = medio sin pais en Stripe, p. ej. iDEAL o Satispay: cruzar por tienda con metadata.storeId)')
