---
name: comprar-dominio
description: Elige, compra y deja funcionando el dominio de una tienda de producto digital — nombre corto en el idioma del mercado, TLD que convenga (.shop es el patrón de tiendas), disponibilidad y precio real de tu cuenta (alta Y renovación), restricciones del TLD contra el país del titular, compra por la API del registrador (Hostinger; con otro se adaptan los pasos), verificación en el registro real (RDAP/whois, no el panel) y DNS apuntando a la tienda (Impultienda, Shopify u otra) con y sin www. Usar cuando el dueño diga /comprar-dominio, "comprame un dominio", "necesito dominio para la tienda", "buscá un dominio para X", "¿está libre tutienda.shop?", "apuntá el dominio a la tienda", "el dominio no anda", o cuando un lanzamiento, un idioma o un mercado nuevo necesite dominio propio. Nunca paga sin el OK del dueño salvo que su configuración fije un tope y el precio entre; nunca reintenta una compra a ciegas.
---

# /comprar-dominio — el dominio de la tienda, comprado y funcionando

**Por qué existe.** Comprar un dominio parece un clic, pero tiene tres trampas que ya
costaron plata: (1) hay TLD que solo puede tener alguien con residencia o empresa en
el país, y si el titular no cumple **el registrador cobra igual y el registro lo
rechaza**; (2) un error en la compra **no quiere decir que no se cobró**, y reintentar
puede cobrar dos veces; (3) que el panel diga «activo» no prueba que el dominio
exista: la prueba es el **registro del TLD**. Esta skill hace todo el camino con esas
compuertas puestas.

**Es la API de Hostinger.** La herramienta `dominio-hostinger.py` habla con Hostinger
(endpoints verificados en su OpenAPI oficial, v2.2.0, octubre 2026:
`https://developers.hostinger.com/openapi/openapi.json`). Con otro registrador
(Namecheap, Porkbun, GoDaddy, Cloudflare…) los **pasos y las reglas son los mismos**,
pero los endpoints y campos cambian: buscalos en la documentación oficial de ese
registrador antes de escribir una sola llamada, y no uses este script contra él.

**Lo que no se sepa, se busca.** Las reglas de cada TLD y los registros que pide cada
plataforma cambian: nunca de memoria, siempre con la fuente abierta en esta sesión.

## Reglas duras (salen de errores pagados)
- **Pagar lo decide el dueño.** Por defecto se le pregunta **siempre** antes de pagar.
  Solo si el dueño fijó un tope en `~/herramientas/.env`
  (`DOMINIO_TOPE_SIN_PREGUNTAR=` y `DOMINIO_TOPE_MONEDA=`) y el alta entra en ese tope,
  se compra sin preguntar y se le avisa en una línea. Si el precio viene en otra moneda
  que la del tope, se pregunta. La herramienta lo hace cumplir: sin tope, `--confirmar`
  se niega hasta que se agregue `--ok-del-duenio`, y ese flag solo se usa con un OK
  del dueño **en este turno, para este dominio y este precio**.
- **Un HTTP 500 (o timeout, o 502) en la compra NO significa que falló.** Primero se
  relee el portafolio; después se mira Facturación. **Nunca se reintenta a ciegas.**
  La herramienta anota cada intento y frena el siguiente del mismo dominio hasta que
  se verifique que no quedó comprado (`--reintento-verificado`).
- **El medio de pago va explícito** (`--pago`). Sin él, Hostinger cobra a la tarjeta
  por defecto y, si la tarjeta rechaza, el error llega como un 500 mudo; con el medio
  explícito el mismo rechazo llega como 422 con el motivo.
- **El titular se elige mirando el nombre y el país.** En una cuenta puede haber
  perfiles de titular de otras personas: nunca el primero de la lista. Los IDs de
  perfil y de tarjeta se listan por API en el momento y **no se guardan en notas**.
- **Que exista lo dice el registro** (RDAP / whois del TLD) y el DNS público, no el
  panel ni la respuesta de la compra.
- **Mirá la renovación, no solo el alta.** En TLD baratos como .shop la renovación
  puede ser decenas de veces el precio del primer año. Mostrale los dos al dueño.

## Entrada
- Qué vende la tienda y **en qué idioma/mercado** (para el nombre).
- En qué plataforma está la tienda: Impultienda, Shopify u otra (y qué registros pide).
- Token de la API del registrador en `~/herramientas/.env` (`HOSTINGER_API_TOKEN=`).
  Si falta, explicale al dueño en una línea: hPanel → Perfil → API → generar token, y
  pegarlo **en el .env, nunca en el chat**. Sin token se puede hacer el paso 1 igual.

En Windows usá `py -3` donde abajo dice `python3`.

## Pasos

### 1. Elegir el nombre (3 a 5 candidatos)
- **Corto**: idealmente menos de 15 letras, fácil de dictar y de escribir sin errores.
- **En el idioma del mercado** donde se vende, revisado por alguien (o algo) nativo:
  una palabra que suena bien en castellano puede ser rara o fea en otro idioma.
- **Sin guiones, sin números, sin tildes ni eñes** (los caracteres especiales rompen
  links y confunden).
- **Sin marcas ajenas** ni nombres que imiten a otra empresa.
- **Sin palabras que las plataformas de anuncios marcan** (salud con promesas, adultos,
  finanzas, «gratis», «garantizado»): el dominio de la landing lo leen los sistemas de
  revisión de anuncios.
- **TLD**: `.shop` es el patrón para tiendas (barato el primer año, se entiende en
  cualquier idioma). `.com` si está libre y el precio cierra. Un TLD de país (`.it`,
  `.pl`, `.de`…) solo si el titular cumple sus reglas (paso 2).
Ejemplo de candidatos: `tutienda.shop`, `tutiendaonline.shop`, `latienda.com`.

### 2. Disponibilidad, precio y restricción
`python3 ~/herramientas/dominio-hostinger.py buscar tutienda --tlds shop,com,store`
- Muestra libre/ocupado, **alta y renovación en la moneda de TU cuenta** (puede no ser
  dólares) y la **restricción** del TLD, si tiene.
- `--alternativas` (con un solo TLD) pide sugerencias a Hostinger.
- La restricción llega como un código (por ejemplo `v2.it_legal_documents`), no como
  explicación. **Cualquier restricción = frenar y leer la regla del registro** en la
  ayuda oficial del registrador o en el sitio del registro del TLD. Ejemplo verificado:
  los `.it` solo los pueden tener personas o empresas del Espacio Económico Europeo,
  Suiza, San Marino o el Vaticano (ayuda oficial de Hostinger, «Requirements to Register
  .IT Domains»). Otros TLD piden datos extra (`additional_details`).
- Cruzá la restricción con el **país del perfil de titular** (paso 3). Si no cumple,
  **otro TLD**, aunque sea más barato. No hay atajo: se cobra y el registro lo rechaza.

### 3. Titular y medio de pago (los elige el dueño)
`python3 ~/herramientas/dominio-hostinger.py perfiles`
- Lista los perfiles de titular (nombre, país, persona/empresa, para qué TLD) y los
  medios de pago (vencido/suspendido/por defecto).
- Mostrale la lista al dueño y que elija. Si no hay perfil para ese TLD, se crea en
  hPanel (o con `POST /api/domains/v1/whois`): un perfil incompleto es la causa más
  común de un dominio pagado y sin registrar.

### 4. Simulacro (siempre, antes de pagar)
`python3 ~/herramientas/dominio-hostinger.py comprar tutienda.shop --perfil <id> --pago <id>`
Sin `--confirmar` no cobra: chequea que no esté ya en tu portafolio, que esté libre, el
precio real, a nombre de quién queda y la restricción. Mostrale al dueño, en una línea
cada uno: **dominio · titular y país · alta · renovación por año**.

### 5. Comprar
Con el OK del dueño (o dentro del tope que él configuró):
`python3 ~/herramientas/dominio-hostinger.py comprar tutienda.shop --perfil <id> --pago <id> --confirmar [--ok-del-duenio]`
- Hace **una sola** llamada de compra (`POST /api/domains/v1/portfolio`). No hay pantalla
  de pago: cobra apenas se llama, y la API no cancela ni reembolsa.
- **Si responde error**: no reintentes. La herramienta relee el portafolio 3 veces; si
  el dominio aparece, la compra pasó. Si no aparece, mirá Facturación en hPanel y volvé
  a `verificar` en unos minutos.
- **Si responde 202**: según la doc oficial, el pago se está procesando y el dominio
  **todavía no está registrado**. Cuando aparezca en el portafolio, seguí con el paso 6.

### 6. Verificar en el registro real
`python3 ~/herramientas/dominio-hostinger.py verificar tutienda.shop`
Cruza tres fuentes: lo que dice Hostinger, el **registro del TLD por RDAP** y el **DNS
público**. Lecturas:
- **Existe en el registro y tiene NS** → listo, paso 7.
- **`pending_setup`** → está pagado y sin registrar (pasa cuando faltaban o estaban mal
  los datos del titular). Se destraba sin volver a pagar:
  `python3 ~/herramientas/dominio-hostinger.py setup tutienda.shop --perfil <id>`
  (`POST /api/domains/v1/portfolio/{dominio}/setup`: según la doc oficial no crea orden
  ni cobra). También se puede confirmar en hPanel, en la ficha del dominio. «Aceptado»
  no es «registrado»: volvé a `verificar` en unos minutos.
- **En el portafolio pero el registro no lo conoce** → normal los primeros minutos. Si a
  las 24 h sigue igual, la compra está colgada: se reclama en el chat de hPanel.
- Si RDAP no responde para ese TLD, usá el whois web del registro del país.

### 7. Apuntar el DNS a la tienda (con y sin www)
Siempre primero el simulacro (valida contra Hostinger sin escribir), después `--confirmar`.
- **Shopify** (registros de su ayuda oficial «Connect a domain manually»: raíz `A` a
  `23.227.38.65`, `www` `CNAME` a `shops.myshopify.com`; verificá que no hayan cambiado):
  `python3 ~/herramientas/dominio-hostinger.py dns tutienda.shop --plataforma shopify --confirmar`
- **Impultienda** (la tienda va **con www**; la raíz se redirige a `https://www.`):
  `python3 ~/herramientas/dominio-hostinger.py dns tutienda.shop --plataforma impultienda --www <destino> --confirmar`
  El `<destino>` es el que muestra tu panel de Impultienda en Configuraciones → Dominio
  (en 2026 era `ssl.impultienda.ar`; confirmalo en tu panel). La redirección de la
  raíz la hace Hostinger (`POST /api/domains/v1/forwarding`); probá a mano que
  `http://tutienda.shop` y `https://tutienda.shop` lleguen a `https://www.tutienda.shop`.
  Si la de https no anda, pedile a la plataforma una IP para la raíz y usá `--raiz-ip`.
- **Otra plataforma**: `--www <host>` y/o `--raiz-ip <ip>` con lo que pida su ayuda.
Detalles:
- Escribe con `overwrite: true`, que según la doc oficial reemplaza **solo** los
  registros con el mismo nombre y tipo; el resto de la zona queda. Después **relee la
  zona** para confirmar que quedó escrito.
- Si el dominio no usa los nameservers de Hostinger, los registros se cargan donde
  esté el DNS (por ejemplo Cloudflare), no acá.
- Lo último es en la plataforma: cargar `www.tutienda.shop` en su panel y tocar
  Verificar cuando propague (de minutos a unas horas). Después, `verificar` otra vez.

### 8. Entregar
Una tabla corta: **dominio · titular (nombre y país) · alta pagada · renovación por año
· estado en el registro · NS · raíz → · www → · verificado en la plataforma (sí/no)**.
Si quedó algo pendiente (`pending_setup`, propagación, verificar en la plataforma),
decilo como próximo paso con fecha. Proponé apagar la renovación automática si el
dominio es de prueba (eso lo decide el dueño). Si aparece una trampa nueva de un TLD o
de la API, guardala con /orden.

## Qué NO hace
- No paga sin el OK del dueño ni por encima de su tope.
- No reintenta una compra.
- No guarda IDs de titular ni de tarjeta, ni el token, en notas o en el chat.
- No toca SSL: el certificado lo emite la plataforma de la tienda cuando verifica el
  dominio.
