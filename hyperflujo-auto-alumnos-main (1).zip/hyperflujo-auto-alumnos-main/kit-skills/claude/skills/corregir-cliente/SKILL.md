---
name: corregir-cliente
description: RECETA del circuito de correcciones de creativos de un CLIENTE, de punta a punta — recibe el resumen que manda el cliente desde su página de correcciones (o capturas/audio de WhatsApp), lo registra como ronda en <producto>/correcciones/estado.json, traduce cada pedido a una acción de tu motor de video, re-renderiza solo lo pedido, verifica por artefacto, lo pasa a tu aprobación, reemplaza el video en el Drive del cliente como versión nueva (mismo link), actualiza la página del cliente con el historial y deja listo el mensaje de WhatsApp. Usar cuando digas "correcciones de <cliente>", "/corregir-cliente", "el cliente mandó correcciones", o pegues un texto que empiece con "CORRECCIONES · <PRODUCTO> · RONDA N".
allowed-tools: Bash, Read, Write, Edit, mcp__claude_ai_Google_Drive__search_files, mcp__claude_ai_Google_Drive__get_file_metadata, mcp__claude_ai_Google_Drive__update_file
---

# Correcciones de un cliente: del pedido a la versión nueva

> **Receta.** Va junto con `app-cliente`. Depende de un motor de video que vos
> elegís (la skill `anunciante-supremo` de este paquete, ffmpeg o Remotion) y de
> dos páginas que tenés que armar una vez (ver «Las piezas»). Anotá sus rutas en
> `config.md` al lado de este archivo.

**Las correcciones las hace el equipo, video por video.** El cliente no edita en
CapCut. Esta receta es el circuito completo para que cualquier sesión lo haga igual.

## Las piezas del sistema

| Pieza | Dónde | Para qué |
|---|---|---|
| Estado | `~/creativos/<producto>/correcciones/estado.json` | La verdad: versión vigente de cada video, qué se cambió, qué está aprobado, rondas y pedidos |
| Página del cliente | artifact estático, generado por un `armar_correcciones.py <producto>` que armás una vez | El cliente mira cada video en Drive, marca veredicto, toca la frase a cambiar o anota el segundo, y copia un resumen |
| Canal de vuelta | WhatsApp / mail | El cliente pega el resumen. **La página no puede escribirte sola**: el cliente no está logueado en claude.ai |
| Aprobación interna | artifact con base de datos, solo para vos | Aprobás las versiones corregidas antes de que las vea el cliente |
| Entrega | la carpeta de Drive del cliente | La versión nueva **reemplaza** al archivo (misma URL): los links viejos muestran lo último |

## El circuito, paso a paso

**1 · Recibir.** El insumo es el resumen `CORRECCIONES · <PRODUCTO> · RONDA N` (o
capturas). Si llega en capturas o audio, transcribilo al mismo formato antes de seguir.

**2 · Registrar.** En `estado.json → rondas[N].pedidos`, un pedido por ítem:
`{video, tipo, segundo, frase, pide, estado: "pendiente"}`, con la fecha de
`recibida`. Lo que el cliente marcó «Aprobado» pasa a `piezas[].estado = "aprobado"`
y no se vuelve a tocar.

**3 · Traducir cada pedido a una acción del motor.**

| El cliente pide | Acción | Costo |
|---|---|---|
| Cambiar lo que dice la voz (frase) | editar el guion y regenerar la voz de ESA pieza | créditos de voz: avisar si son varias |
| Cambiar un clip en un segundo | excluir el clip o el tramo, o fijar otro en ese tramo | render |
| Mockup, colores, subtítulos, marca de agua | assets / look de la ficha | render |
| Música o sonidos | música / efectos de la ficha | render |
| Ritmo, transiciones, duración | parámetros de edición de la pieza | render |
| Algo que toca precio, promesa, marca o qué se vende | **no se aplica**: te lo paso en una línea | — |

Si un pedido es ambiguo («no me gusta»), se interpreta con el segundo que marcó y
se anota la interpretación; no se frena la ronda por eso.

**4 · Producir.** En una copia de trabajo de la ronda (nunca pisar la entregada).
Render **de a una pieza**, con los intermedios en una carpeta temporal que se
borra al tener veredicto; frená si el disco baja de ~2 GB. Solo se re-renderizan
las piezas con pedidos.

**5 · Verificar por artefacto.** El verificador del motor en 0 errores, y
**cuadros en el segundo exacto de cada pedido**, antes y después. Si pidió cambiar
una frase, transcribí el tramo y confirmá el texto nuevo.

**6 · Tu aprobación.** Página interna con portada + Drive + Aprobar, con la lista
«qué pidió → qué hicimos» por video. Leé el veredicto de la base de la página;
no te pidas una lista por chat.

**7 · Entregar.** Subí al Drive del cliente como **nueva versión del mismo archivo**
(Drive → Administrar versiones → Subir nueva versión, o la API con el mismo
`fileId`). Verificá con `search_files` que el id no cambió y el tamaño coincide.

**8 · Cerrar la ronda.** En `estado.json`: agregá a cada pieza corregida una versión
`{n, fecha, drive_id, video, plan, cambios: ["qué cambiamos, en palabras del cliente"]}`,
marcá los pedidos como hechos y subí `ronda_actual`. Rearmá la página del cliente y
republicala en la MISMA URL (leé antes su versión viva: otra sesión pudo tocarla).

**9 · Avisar.** Dejá listo el mensaje de WhatsApp: qué se corrigió por video, el
link de la página y que puede volver a marcar. Cuántas rondas entran lo decidís
vos (`estado.json → rondas_incluidas`); si se pasa, se te avisa a vos, no al cliente.

## Estados de una pieza en `estado.json`

`revision` (el cliente la tiene que mirar) · `en_proceso` (hay una versión nueva en
camino: la página se lo dice y no le pide veredicto) · `aprobado` (cerrada).

## Lo aprendido operándolo

- Una versión corregida subida como archivo NUEVO rompe los links que el cliente ya
  tenía. Desde entonces: versión nueva = versión del mismo archivo.
- Una pieza rechazada internamente después de estar en la carpeta del cliente es
  un papelón: por eso la aprobación interna va ANTES de mover nada.

## Lo que hace fallar este circuito

- Otra sesión trabajando en el mismo cliente: antes de producir, fijate (comando
  `/radar`) y coordiná.
- El resumen trae tiempos de la versión anterior: el segundo se busca en el plan de
  la versión que vio el cliente (la última de `versiones`), no en la nueva.
- Republicar la página del cliente sin leer antes su versión viva.
