---
name: creativos
description: Produce una TANDA de creativos para Meta de punta a punta — ángulos desde la investigación, guiones sobre los 5 patrones medidos de las ganadoras, las piezas 4x5 y 9x16, la auditoría de imagen obligatoria y la carga en pausado a la cuenta. Usar cuando el usuario diga /creativos, "armá los creativos de esta oferta", "necesito una tanda nueva", "hacé las versiones de historias", "generá los anuncios de X", "cambiá el ángulo de estos", o cuando una oferta ya tenga landing y falten las piezas para prenderla. Jamás inventa el ángulo: sale de la investigación o de los anuncios del competidor. Jamás prende nada.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Skill
---

# Producir una tanda de creativos

El único eslabón de la cadena que no tenía proceso, y el que más plata mueve: una
landing buena con creativos flojos no vende, y al revés a veces sí.

**Esta skill no inventa nada.** El ángulo sale de la investigación o de los anuncios
que ya corren; los guiones salen de los 5 patrones medidos en 11 ganadoras; las
reglas de prompt salen de errores ya pagados. Si te falta la entrada, pedila —
no la rellenes con tu prior.

## De dónde sale cada cosa

| Necesitás | Está en |
|---|---|
| Los guiones madre | [[guiones-madre-anuncios-ganadores]] |
| Cómo se diseñan, producen y testean | [[moc-fabrica-de-creativos]] |
| Ángulos que ya ocupa la competencia | `/espia-ofertas`, y `[[angulos-ocupados-se-leen-en-los-anuncios]]` |
| Voz literal del mercado | `/voz-cliente` → `~/fuentes/voz-cliente/<nicho>/` |
| La oferta, el mecanismo y los bonus | la salida de `/oferta-completa` |

Los 5 guiones madre, para no releer el archivo entero: **hobby que factura** ·
**contraste injusto** (el más fuerte de los cinco) · **creencia limitante** · **miedo al
error costoso** · **valor primero**.

Y lo que aparece en **11 de 11** ganadoras, o sea que no es opcional:
- CTA imperativo final que **nombra el producto**.
- Matar la objeción de habilidad, siempre ("sin experiencia / solo seguí el sistema").
- Se vende la **transformación y el método**; el precio vive en el titular o no aparece.
- Voz en 1ª persona testimonial o 2ª directa. **Nunca corporativa.**

## El orden

### 1 · Fijar el ángulo antes de escribir una línea
Un ángulo por conjunto. Nombralo en una frase y decí de dónde sale. Si el dueño del cerebro no
definió cuántos ángulos entran, **preguntale cuántos, no cuáles** — la elección de
qué se vende es suya (regla dura 11).

### 2 · Escribir los guiones
Uno por pieza, sobre uno de los 5 patrones. Cada guion lleva: gancho (primeros 3
segundos), desarrollo, y CTA imperativo con el nombre del producto. Mostráselos al
dueño del cerebro **antes** de generar imágenes: corregir texto es gratis, regenerar piezas no.

### 3 · Generar las piezas — las reglas que costaron caro
Para imágenes de producto y mockups, la skill es `/higgsfield-product-photoshoot`
(cotiza antes de gastar créditos). Para el resto:

- **Nunca digas lo que NO querés. Decí qué va EN SU LUGAR.** «Sin inglés» falló
  tres veces; «lomos lisos con relieve dorado» salió a la primera. Para una figura
  humana se pide la POSE, no la ausencia de algo.
- **Releé el bloque de texto quemado antes de mandarlo.** «GIGANTE» escrito para
  indicar tamaño salió dibujado en la imagen. Bajadas en **3 renglones cortos**.
- **Tres intentos sin moverse = cambiá el método, no el fraseo.** Si a la tercera
  reformulación el resultado no se movió, el prompt no es el camino: se monta en
  editor. La barra de CTA de historias es el caso conocido — no obedece porcentajes.

### 4 · El vertical NO se genera hasta que el feed esté APROBADO
La versión 9x16 se hace pasando la de feed como referencia, y **arrastra los
defectos igual que los aciertos**. Por ejemplo: un título mal escrito en la tapa de la
versión feed se paga dos veces si se saltea esto. La pregunta es literal: *¿el
dueño del cerebro aprobó la de feed, o solo está terminada?* Si solo está terminada, frená.

### 5 · Auditar cada imagen ABRIÉNDOLA (regla dura 14, no se saltea)
El nombre del archivo miente en las dos direcciones. Un sufijo de idioma en el nombre
(por ejemplo `_EN`) no es evidencia de nada: en una operación real se vio una
tanda de tapas "traducidas" con más de la mitad rotas adentro.

Abrí cada pieza con `Read` y clasificá:
- **foto sin texto** → se reusa.
- **texto impreso** → se lee **como copy**. Listá lo que la imagen PROMETE
  (formato, cantidad, acceso, garantía) y cotejalo contra el producto real. Por
  ejemplo, un mockup que dice `VIDEO PASO A PASO` sobre un PDF sin un solo video.
- **marca de terceros** → no se publica hasta que el dueño del cerebro decida.

Una pieza heredada de otra versión de la oferta conserva las promesas de aquella
oferta: **se re-audita siempre**.

### 6 · Nombrar y guardar
```
~/Desktop/creativos-<oferta>/tanda-NN-<variante>/
    01-<slug-del-angulo>_4x5.jpg
    01-<slug-del-angulo>_9x16.jpg
```
Dos dígitos siempre, kebab-case, el mismo slug en los dos formatos. El orden
alfabético es contrato: así se cargan y así se leen las métricas después.

Escribí al lado un `guiones.md` con el guion de cada pieza y su ángulo. Sin eso,
en dos semanas nadie sabe qué probó cada anuncio y la tanda no enseña nada.

### 7 · Cargar a la cuenta EN PAUSADO
Con `/meta-ads`. Todo nace pausado y **prender es decisión del dueño del
cerebro en el Administrador**. Antes de cargar, decile en una línea qué campaña, qué conjunto y
cuántos anuncios vas a crear.

Acordate del límite del conector: los uploads piden **URL pública**, no leen del
disco. El puente está documentado en `/meta-ads`.

## Antes de decir que la tanda está lista

- [ ] Cada pieza tiene guion escrito y ángulo nombrado.
- [ ] Cada imagen fue **abierta y leída**, no solo listada por nombre.
- [ ] Lo que promete el texto impreso existe en el producto.
- [ ] Los 9x16 salen de un feed **aprobado**.
- [ ] Están los dos formatos de cada pieza, con el mismo slug.
- [ ] `guiones.md` escrito al lado de los archivos.
- [ ] Cargados en pausado, o dicho explícitamente que faltan cargar y por qué.

Lo que no construiste **se declara**; no se pierde en silencio.
