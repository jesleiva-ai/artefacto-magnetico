---
name: de-link-a-creativos
description: De un link de landing que vende un producto digital a una tanda de creativos de video nuevos — lee la landing y lo que promete, revisa qué corre en la Biblioteca de Anuncios (la marca y el nicho), saca los ángulos de ahí, junta material con licencia comercial y produce 5 videos (uno por estilo) con una página para revisarlos. Usar cuando pases un link de landing y digas "hacele creativos", "investigá y hacé creativos para este link", "probá la máquina con esta landing", o pegues un link de una página de venta de producto digital pidiendo creativos.
---

# De un link a creativos

Pasás el link de una landing que vende un producto digital y esta skill hace la
investigación completa (qué promete la página, qué corre en la Biblioteca de
Anuncios) y produce creativos nuevos a partir de eso.

## Paso de configuración (la primera vez)

Antes de la primera corrida, confirmá con vos qué tenés y anotalo en
`config.md` al lado de esta skill:

- **Carpeta de trabajo** de creativos (por defecto `~/creativos/<slug-del-producto>/`).
- **Motor de video**: con qué montás las piezas. Cualquiera de estos sirve:
  `ffmpeg` a pelo, Remotion, CapCut a mano, o la skill `anunciante-supremo` de este
  mismo paquete (recomendada: ya trae plantillas, voz, captions y render).
- **Voz**: ElevenLabs, el TTS de Higgsfield o el de tu proveedor de IA. Medí los
  créditos antes de arrancar; nunca supongas que hay saldo.
- **Transcripción para alinear subtítulos**: Whisper local (`faster-whisper`).
- **Navegador** para la Biblioteca de Anuncios (Claude in Chrome o el conector de
  Meta Ads con `ads_library_search`).
- Si tenés un segundo cerebro con notas de creativos ganadores, la ruta a esas
  notas: se leen antes de escribir un guion.

## Antes de escribir un guion

Si tenés un cuaderno de creativos (checklist, estructura de un creativo escalado,
fórmulas de gancho), leelo y pasá cada guion por el checklist antes de gastar un
crédito. Si no tenés, usá como mínimo estas preguntas: ¿el gancho para el scroll
en 2 segundos? ¿se entiende qué se vende sin sonido? ¿cada promesa la respalda la
landing? ¿hay un solo llamado a la acción?

## 1 · La landing (comando `/landing-xray`)

- `robots.txt` primero. Bajar el HTML con `curl` (UA de celular) y sacar el texto
  visible: qué vende, precio y niveles, garantía, FAQ, a quién le habla. Firmas:
  `fbq`, Shopify, etc.
- Listar **lo que promete** y cotejarlo con lo que entrega: toda inconsistencia
  («+1000 técnicas» en el título contra «+200 proyectos» en la página) va a una
  lista `no_reclamar`.
- Bajar sus imágenes: el mockup del producto y las fotos de estilo de vida.
  **Abrir cada una**: fuera caras de testimonios, sellos de prueba social no
  verificables y cualquier marca de terceros.
- Dejar el brief en tu carpeta de borradores.

## 2 · La Biblioteca de Anuncios

- **Sus anuncios:** buscá por el dominio de la landing. Contá anuncios, desde
  cuándo corren, video o imagen, textos distintos; bajá las placas y armá una hoja
  para verlas.
- **El nicho:** 2 búsquedas en el idioma del mercado (filtro de idioma del
  contenido) y agrupá por anunciante: cantidad, días del más viejo, cuántos son
  video, gancho más repetido.
- **El hueco** se busca entre las dos: qué no hace la marca que el nicho sí hace
  (ejemplo: la marca tiene 16 placas de descuento y cero video).

## 3 · Ángulos y guiones

- Cada ángulo sale de la landing o de un anuncio que corre. **El ángulo no se inventa.**
- Cinco estilos, uno por video (ejemplo de receta: historia, pregunta que engancha,
  lista rápida, demostración del producto, objeción respondida).
  **Primera persona solo con un testimonio real:** si no hay, va «pregunta que engancha».
- `no_reclamar` escrito antes del guion: precio y promos cambiantes, lo que la
  página no respalda, testimonios, salud, resultados garantizados.

## 4 · Material con licencia

- Stock de video **solo con licencia que permita publicidad** (por ejemplo Mixkit
  «Stock Video Free»; la «Restricted» la prohíbe). Verificá la licencia en la
  página de CADA clip y guardá un registro en `<base>/LICENCIAS.json`.
- Abrí una hoja de cuadros de cada clip: fuera lo borroso, lo que muestra otra
  disciplina (pesas cuando el producto es de yoga) y los textos o marcas.
- Música con licencia para anuncios online, con su procedencia anotada.
- Fotos de la landing: con zoom horneado si la receta es «solo video».
- Mockup sin transparencia → tarjeta con bordes, marco y sombra; anotá que
  conviene uno recortado.
- En nichos profesionales el stock libre suele venir restringido: presupuestá
  tomas propias generadas con IA (por ejemplo clips de 5 s, 9:16, sin sonido) y
  auditá cada una abriéndola (manos, textos, marcas).

## 5 · Producir

- **Voz:** generala con tu proveedor, acelerala un poco (×1,05 en historias, hasta
  ×1,18 en piezas rápidas) y normalizá volumen (`loudnorm`, ≈ -14 LUFS).
- **Subtítulos:** alineá el guion contra la transcripción por palabra (Whisper) y
  **fallá cerrado** si menos del 85 % de las palabras se alinean. El subtítulo dice
  el guion, no lo que entendió Whisper («doscientos» → 200).
- **Cortes de plano:** atá cada clip a una palabra que dice la voz. Cuidado con los
  plurales y las raíces (un clip llamado «cajon» se dispara con «cajones») y con
  palabras que la voz dice en otro sentido: renombrá el clip a algo que no se diga.
- **Avatar a cámara (UGC):** la avatar es presentadora, nunca clienta (nada de
  «yo lo usé»). Presupuestá los créditos ANTES (un video de 15 s con labios
  sincronizados es caro). Transcribí el nombre del producto con dos modelos de
  Whisper: la avatar puede pronunciarlo mal.
- **La misma tanda en otro idioma:** marcá en el guion traducido dónde entra cada
  plano (⟨1⟩, ⟨2⟩…) para no rehacer el plan; revisá de nuevo tomas con carteles
  legibles en el idioma original (OCR a 2×) y la pronunciación (si una palabra sale
  mal, escribila fonética SOLO para el TTS).
- **Números en pantalla:** en historias largas, apagá los números automáticos
  («el café de las dos» no es un 2) y marcá a mano los que importan.
- **Mirá la hoja de cuadros de cada pieza** antes de largar el resto: un clip
  borroso que se repite en tres piezas se excluye y se re-renderiza.
- Los armadores y planes de cada producto viven en su carpeta de trabajo, nunca en
  el scratchpad (se borra entre sesiones).
- Colas de render: esperá por PID, nunca con `pgrep -f` sobre el nombre del script
  (el shell que espera se encuentra a sí mismo).

## 6 · Entregar

- Página privada (artifact) con los 5 videos embebidos en versión liviana
  (540×960), lo que encontraste (landing, sus anuncios, el nicho), lo que los videos
  no dicen a propósito y sus anuncios de hoy.
- **Si entregás editables de CapCut, van siempre con su tutorial** de instalación
  (el .zip no se abre con doble clic): 5 pasos, ruta de la carpeta de borradores en
  Mac y en Windows, qué se puede cambiar, cómo exportar (1080p, 30 fps, MP4) y qué
  hacer si el proyecto no aparece. Botón en la página y un documento en la misma
  carpeta de Drive.
- Si es material para un cliente: el dueño comparte la carpeta «cualquiera con el enlace»
  después de revisarla (nunca cambies el permiso vos), y seguí con la receta `app-cliente`.
