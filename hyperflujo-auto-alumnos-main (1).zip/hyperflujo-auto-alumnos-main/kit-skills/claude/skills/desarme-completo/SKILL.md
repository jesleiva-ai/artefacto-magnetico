---
name: desarme-completo
description: Desarma una landing ganadora completa — chequeo anti-placebo ejecutable, fuente con tokens, estructura medida al píxel, paleta medida del render, visuales, copy, anuncios del anunciante, guiones, identidad visual, ángulo de comunicación y gatillos mentales — y la incorpora al backup de referencia. Usar cuando el usuario pase una landing nueva para modelar, diga /desarme-completo, "desarmá esta", "analizá esta referencia", "sumala al backup", "rayo X completo", o cuando aparezca un competidor que valga la pena fichar. Corre el pipeline automático (rompe-placebos + fuente + forense + anatomía + copy + paleta + fotos) y después las pasadas manuales que no se automatizan: mirar las fotos, desarmar los anuncios y escribir los tres entregables (identidad visual, ángulo, gatillos).
---

# Desarme completo de una referencia

Lo que se quiere de cada ganadora, textual: *"se tiene que analizar paleta de
colores, visuales, tenés que ver literalmente esa oferta, toda la identidad
visual, la forma de comunicar, los gatillos mentales que hay, el copy, las
imágenes… entender el ángulo de comunicación, tanto textual como visual, tenés
que ver absolutamente todo."*

El desarme es QUIRÚRGICO o no es desarme: **landing medida, fuente en disco,
visuales, estructura, copy de la landing, copy de los anuncios, títulos,
descripciones, guiones, visuales de los anuncios, identidad visual, ángulo de
comunicación, gatillos mentales, cómo presentan los bonos y qué se mueve en la
página.** Todo, en todas, con el mismo nivel de detalle.

El destino es el backup de referencia: `~/fuentes/desarmes/<slug>/` para el crudo
y el rayo-X del vault para el criterio destilado.

## Paso 0 · Correr el rompe-placebos (no es prosa: es un comando)

Los que escalan esconden la posta ([[pagina-placebo-blindaje-y-espionaje]]).
**Siempre aprendemos de páginas originales, nunca de placebos.** El criterio duro:
la página que recibe el dinero es la que apuntan los anuncios que están corriendo
— todo lo demás es inferencia.

```
# 1. page_id del anunciante (MCP de Meta, solo lectura):
#    ads_library_search con search_terms de la marca/nicho → page_id
# 2. el chequeo:
python3 ~/herramientas/rompe_placebos.py <url> --page-id <id>
```

Sin page_id también corre (busca por dominio en la Biblioteca), pero con page_id
es más preciso. Lee el destino real de cada anuncio activo
(`l.facebook.com/l.php?u=...` de la grilla, vía CDP), sigue dominios intermedios,
y cruza precio, checkout, idioma, moneda y días activos.

| Exit | Veredicto | Qué se hace |
|---|---|---|
| 0 | `[posta]` — los anuncios apuntan acá y la página cobra | seguir al paso 1 |
| 1 | `[placebo]` — apuntan a OTRA URL, o esta página no cobra | **NO se mide esta página.** Rearrancar el desarme sobre la URL posta que reporta |
| 2 | `[indeterminado]` | se puede seguir, pero el veredicto queda EN MAYÚSCULAS en VEREDICTO.txt y el rayo-X se marca "sin confirmar posta". **Indeterminado JAMÁS se reporta como posta** — esa confusión es la lección de [[2026-07-27-cerebro-ia-el-proxy-miente]] |

`desarme.sh` ya lo corre como pasada 0 y frena solo si da placebo.

### Paso 0b · El cloaking (la otra mitad de la pregunta)

Son dos preguntas distintas y hay que contestar las dos:

| | Pregunta | Herramienta |
|---|---|---|
| 0 | ¿Es **esta URL** la que recibe el dinero? | `rompe_placebos.py` |
| 0b | ¿Es **este contenido** el que ve el comprador? | `cloaking.py` |

Una URL puede ser la correcta y el contenido no. Es exactamente lo que pasó con
**instanthandbook**: 36 de 42 anuncios activos apuntaban a la URL correcta —el
rompe-placebos da `[posta]`— y sin embargo cualquier navegador termina en un
señuelo. El servidor sirve el advertorial real; un script propio te mide y te
muda antes de que lo veas.

`desarme.sh` corre esta pasada sola (`00b-cloaking.txt`) y le pasa el destino
real de los anuncios. **No frena** el pipeline —a diferencia del placebo— pero
deja la advertencia en mayúsculas en `VEREDICTO.txt`.

Si da sospechoso: el tool imprime la receta para bajar la versión honesta sin
JavaScript. Sirve para el copy y el HTML. **No sirve para `forense.py`,
`paleta.py` ni las fotos**, que renderizan con Chrome y se comen el señuelo: en
una página cloakeada, la capa visual del desarme queda sin medir y hay que
decirlo, no estimarla.

## Paso 1 · El pipeline automático

```
~/herramientas/desarme.sh <slug> <url> [page_id]
```

Corre las siete pasadas y escribe veredicto `[ok]`/`[error]` por cada una. Deja
todo en `~/fuentes/desarmes/<slug>/`:

| Archivo | Qué trae |
|---|---|
| `00-posta.txt` | Veredicto rompe-placebos: destinos reales de los anuncios activos, días corriendo, señales de la landing (precio, checkout, idioma, moneda) |
| `01-fuente/` | `index.html` + `css/` + `TOKENS.txt` — el FUENTE. Replicar pide el fuente, no la impresión ([[2026-07-30-cerebro-ia-replicar-pide-el-fuente]]). TOKENS.txt (colores HSL, tipografías con pesos, escala, letter-spacing, radios, sombras, breakpoints) es contra lo que se valida un calco por DIFF |
| `02-forense-celular.txt` | Pliegue real, presupuesto del hero, mapa de secciones con %, escala tipográfica con proporciones, gradientes, sombras, densidad de imagen, animaciones, botones con su % de scroll |
| `03-anatomia.txt` | Stack, checkout, paleta por área pintada, aspectos de imagen, carruseles, origen de assets |
| `04-copy.txt` | El texto verbatim completo |
| `05-paleta.txt` | La paleta MEDIDA del render con `paleta.py`: familias de tono con piso de 0.4%, saturación de cada color, veredicto diseñada/acumulada. El CSS da los valores exactos; el render da los ROLES — la variable `--primary` puede mentir ([[la-paleta-se-mide-no-se-elige]]) |
| `06-fotos/` | Tiras del alto real del dispositivo |

**Se mide contra 384px de ancho y 681px de pliegue** — el peor caso (Samsung S24
Ultra con la barra del navegador). En low ticket casi todas las conversiones entran
por celular; el emulador miente si medís contra el viewport CSS completo.

Una corrida que no midió nada es `[error]`, no éxito.

(Desarmes anteriores al 2026-07-30 usan la numeración vieja:
`00-forense-celular / 01-anatomia / 02-copy / 03-fotos`, sin posta, fuente ni
paleta. Al re-desarmar uno viejo conviven las dos numeraciones; vale la nueva.)

## Paso 2 · MIRAR las fotos

No listarlas: abrirlas. La jerarquía visual y el ritmo del scroll no salen de un
informe de texto. Este paso se saltó tres veces el 2026-07-28 y costó tres
entregas rechazadas ([[medir-la-landing-antes-de-replicarla]]).

## Paso 3 · Desarmar los anuncios del anunciante

**Encontrar la página** con el MCP de Meta:
`ads_library_search` con `search_terms` de la marca o del nicho → sale el
`page_id` (y la moneda de cada anuncio, dato que la grilla no muestra). Después,
todo su inventario con `page_ids: ["<id>"]`.

**Leer los cuerpos.** La API devuelve solo el título del enlace. El copy primario,
el creativo y el video están en el snapshot, que es **React virtualizado y no se
puede leer por DOM**. Se esquiva por foto:

```
ojos.py foto --escritorio --max 8 --url \
 'https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&view_all_page_id=<PAGE_ID>&search_type=page&media_type=all'
```

La grilla trae muchos anuncios por pantalla con su copy primario completo, el
creativo, el título y la descripción. Mucho más eficiente que abrir de a uno.
(`espia_fb.py <url-grilla>` saca además el texto y los links de cada tarjeta en
JSON, para archivar.)

**Qué extraer de ahí:** título del enlace · descripción · copy primario completo ·
anatomía del creativo · frame 0 y texto quemado de los videos · y el estado
(*«Impresiones: <100 · Número de impresiones bajo»* es el termómetro gratis de qué
creativo del competidor está muriendo).

## Paso 4 · Destilar, con las rejillas ya construidas

No analizar en abstracto: pasar el material por lo que ya está escrito.

- **Copy de la landing** → las 16 fórmulas de [[formulas-de-copy-de-las-ganadoras]]:
  tríada de fricción, titular en dos tiempos y dos colores, subtítulo condicional,
  culpa invertida, dolores bautizados, antes/con sin features, volúmenes con arco
  del oficio, bonos con precios alternados, ™ en todo, precio que mata dos
  objeciones, garantía como promesa, testimonios que citan el mecanismo, CTA en
  primera persona, cierre en pregunta, FAQ de identidad profesional, popup de compra.
- **Copy del anuncio** → los cuatro movimientos: pregunta de rol → reencuadre →
  producto como sistema con 4-6 componentes → checklist.
- **Títulos** → las cuatro familias: DEJÁ DE · ORGANIZADO/RESUELTO · TIEMPO ·
  SISTEMA COMPLETO.
- **Visuales** → los invariantes de [[patrones-visuales-y-titulares-ganadores]] y
  la anatomía del póster de inventario.
- **Estructura** → si se parece a E1 (PDP express) o a E6 (Solved), las dos del
  arnés de `/maqueta-landing`, o a ninguna (y en qué se aparta).

Y escribir **los tres entregables** en `~/fuentes/desarmes/<slug>/`. Mediciones
crudas sin estos tres archivos = desarme incompleto:

### `IDENTIDAD-VISUAL.md`
Sale de `05-paleta.txt` + `01-fuente/TOKENS.txt` + `03-anatomia.txt` + las fotos:
- **Paleta en HSL con sus familias**: cuántas familias manda el render, cuál es
  el fondo, cuál la tinta, cuál el acento y su **saturación** (≤60% prestigio,
  ≥80% descuento), y **qué color queda reservado para el botón que cobra**.
  Los neutros: ¿son el acento desaturado o grises que nadie eligió?
- **Tipografías con pesos reales** (de TOKENS.txt, no estimadas), escala de
  tamaños, letter-spacing.
- **Radios y sombras**: los valores exactos y si las sombras son negras o teñidas
  de marca.
- **Aspectos de imagen** dominantes y origen de los assets (huellas de nombre).
- **Veredicto**: qué tan "diseñada" es la paleta según el criterio de
  [[la-paleta-se-mide-no-se-elige]], y qué se roba vs qué se mejora.

### `ANGULO.md`
El ángulo de comunicación, textual Y visual:
- **Textual**: qué promete (la promesa madre en sus palabras), a quién le habla
  (el avatar nombrado: rol, etapa, dolor), desde qué mecanismo reencuadra, y qué
  emoción carga el titular (¿oferta-led o beneficio-led?).
- **Visual**: qué promete la imagen que el texto no dice — **qué se ve** (manos,
  producto, resultado, entorno), **qué no se ve nunca** (¿caras? ¿pantallas?
  ¿el creador?), y **qué se tangibiliza** (mockup 3D, printable impreso, el PDF
  scrolleando). Cruzar con los 6+3 patrones de
  [[patrones-visuales-y-titulares-ganadores]].
- **El cierre**: ¿texto e imagen prometen lo mismo o el visual vende otra cosa?

### `GATILLOS.md`
Los gatillos mentales, mapeados, no listados:
- **Cuáles usa**: urgencia, escasez, prueba social, autoridad, anclaje de precio,
  garantía/riesgo invertido, reciprocidad (bonos), culpa invertida, dolor
  bautizado, identidad profesional, curiosidad, pertenencia.
- **Dónde cae cada uno en el scroll**: px absoluto y sección (del forense), no
  "por ahí abajo". ¿Cuáles entran antes del primer precio?
- **Contra qué objeción ataca cada uno**: "no tengo tiempo", "no va a funcionar
  para mí", "es caro", "no confío", "comprarlo diría que no sé mi oficio".
- **Cuáles NO usa** — el hueco es dato (pero ausencia no es oportunidad:
  [[2026-07-28-ofertas-ausencia-no-es-oportunidad]]).

## Paso 5 · Escribir el rayo-X y actualizar el registro

Al vault va el **criterio**, no el volcado. El rayo-X lleva su sección "Paleta y
tipografía" con lo MEDIDO, la estructura por bloques con %, dónde cae el primer
CTA contra el pliegue, y qué se roba vs qué se mejora. Si el paso 0 dio
indeterminado, el rayo-X se marca **"sin confirmar posta"** hasta validarla.

## Las nueve preguntas que el desarme tiene que contestar

Si al terminar no podés contestarlas, el desarme está incompleto:

1. **¿Se ve el CTA en el primer pantallazo de un Android?** (píxel absoluto contra
   681, no porcentaje de página — el % miente en páginas de 15.000px)
2. **¿Qué estructura es, y por qué esa para este nicho y mercado?**
3. **¿Cuál es la frase-mecanismo?** La que reencuadra el problema. Si no la
   encontrás, o no la tiene —y eso es una oportunidad— o no leíste bien.
4. **¿Cómo presentan los bonos?** Precio unitario, alternancia, y si cada uno
   ataca una microtarea distinta del flujo o son cinco variaciones de lo mismo.
5. **¿Qué se mueve, y respeta `prefers-reduced-motion`?** Casi ninguna lo hace.
6. **¿Es la página que cobra?** ¿Qué dijo el rompe-placebos, y si dio
   indeterminado, quedó escrito así en el rayo-X?
7. **¿Cuántas familias de tono midió el render, qué saturación tiene el acento,
   y qué color queda reservado para el botón que cobra?**
8. **¿Tenés el fuente en disco y su TOKENS.txt?** Un calco se valida como DIFF
   contra ese archivo: si no podés decir qué cambió y qué no, reinterpretaste.
9. **¿Qué gatillo cae en qué punto del scroll, contra qué objeción — y qué
   promete la imagen que el texto no dice?**

## Lo que NO se hace

No se copia copy ni diseño verbatim. Se modela **estructura y mecánica**. El clon
jamás se publica.
