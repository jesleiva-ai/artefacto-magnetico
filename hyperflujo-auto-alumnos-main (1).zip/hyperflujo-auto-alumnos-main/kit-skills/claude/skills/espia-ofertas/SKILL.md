---
name: espia-ofertas
description: Espionaje v2 de ofertas ganadoras en la Biblioteca de Anuncios de Meta con las señales 2026 y guía de réplica mejorada. Usar cuando el usuario diga /espia-ofertas, "espiar la biblioteca", "buscar ofertas que estén escalando", "encontrar productos fáciles de replicar", "quién más corre esta oferta", o pase landings de referencia que ya convierten para hallar más como esas. Barre varios países/idiomas con URLs de filtros guardadas, mide escala con DOS ejes (días activos Y mínimo 10 anuncios prendidos), separa SIEMPRE el informe por canal de venta (web vs WhatsApp/DM, buscando en los dos por igual), aplica la regla de 3 anunciantes, DESCARTA VSLs y ofertas difíciles, califica replicabilidad /10, cura un swipe file y entrega dossier + guía para replicar la estructura MEJORANDO la oferta. Solo lectura de Meta; jamás muta nada.
---

# Espía de Ofertas v2 — Biblioteca de Anuncios → Réplica mejorada

Sistema de 6 fases. Objetivo: hallar ofertas de **entregables digitales simples** (ebooks, planos, plantillas, prompts, recetarios, cursos cortos) con **landings de comunicación directa** (texto + imágenes; NADA de VSL) que estén escalando AHORA, y producir la guía para replicarlas mejor. Herramienta central: `mcp__claude_ai_Meta_Ads_MCP__ads_library_search` (conector META ADS, SOLO lectura — cargarla con ToolSearch). Complementos: WebFetch para landings, Read/Write/Bash para el staging, agent-browser headless solo si responde.

## Arranque (barato, en orden — NO releas el vault entero)
1. HOT.md del cerebro (estado vivo).
2. `04-lecciones/INDEX.md` y abrí las lecciones activas de las áreas que tocás (meta-ads, ofertas, productos-digitales) cuya señal matchee. Mandan sobre la fase de réplica.
3. Grep dirigido en 02-notas por el nicho antes de crear nota nueva → decide ADD/UPDATE/SUPERSEDE/NOOP.

## Entradas (pedir lo que falte)
1. **Landings de referencia** (URLs que ya convierten) — lo ideal para calibrar.
2. O **nicho/keywords** semilla.
3. Países/idiomas objetivo. Default: los mercados que el dueño declaró en la entrevista (si no hay, preguntá) · video · solo activos.

## URLs de filtros guardadas (marcadores para repetir en 1 clic)
Base: `https://www.facebook.com/ads/library/`. Plantilla de parámetros por mercado:
`?active_status=active&ad_type=all&media_type=video&content_languages[0]=es&country=<XX>&q=<keyword>&search_type=keyword_unordered`
Guardar un marcador por cada mercado objetivo (código de país de 2 letras, por ejemplo `MX`, `AR`, `US`) con el idioma del mercado + video + solo activos. Keywords = entregable + dolores del avatar, JAMÁS el nombre de la marca. Registrar las URLs usadas en el dossier para el radar semanal.

## FASE 0 — Calibrar con las referencias
Por cada landing de referencia:
- Bajar HTML crudo (WebFetch; si rebota 503, `Invoke-WebRequest -UseBasicParsing`). Guardar en `_staging\espionaje\<nicho>\`.
- Extraer la **firma de la oferta**: tipo de entregable · precio y ancla · orden de secciones · plataforma (grep: shopify/woocommerce/elementor/systeme/clickfunnels/hotmart/kajabi) · proporción imágenes-vs-HTML (contar `<img>`/`<video>`) · fuentes/paleta · ángulo de la promesa.
- Derivar **keywords de caza** por idioma (entregable + dolores del avatar).

## FASE 1 — Barrido con la señal correcta: DOS EJES, y el canal
Por keyword × país (batches de 3-4 búsquedas paralelas): `ads_library_search` con `search_terms`, `countries:[XX]`, `ad_active_status:"ACTIVE"`, `limit:25`. Registrar page_name, page_id, título del creative, `ad_delivery_start_time`, snapshot URL.

**La escala se mide con DOS ejes, y hacen falta los dos** ([[2026-08-03-ofertas-escala-dos-ejes]]):
- **Eje 1 — DÍAS ACTIVOS** = la oferta devuelve (nadie paga meses por un ad que pierde): **descartar <14 días**; estudiar **30-90+ días**. Días = hoy − `ad_delivery_start_time` del anuncio activo MÁS VIEJO.
- **Eje 2 — ANUNCIOS PRENDIDOS ≥ 10** = le están metiendo plata. Menos de 10 no es escala: es una vela prendida. Los dos números van SIEMPRE juntos en la tabla; ninguno solo califica.
- Los que pasan un eje pero no el otro **no se borran**: van a una lista aparte, «demanda probada, escala sin confirmar».
- **El conteo se toma de la vista pública** con `country=ALL` (`view_all_page_id=<id>`), que es la que el usuario puede abrir y verificar; la API acotada a pocos países devuelve menos y descalifica a quien sí califica. Anotar la fecha del conteo: los listados cambian solos.

**El informe SIEMPRE sale partido por CANAL DE VENTA** ([[2026-08-03-ofertas-canal-de-venta-separado]]):
- **Web** (Shopify / Impultienda / Systeme / WordPress / dominio propio con checkout) y **WhatsApp/DM** (`api.whatsapp.com`, `wa.me`, «Chatea con nosotros», «Envíanos un mensaje», `instagram.com`).
- Se busca en los dos **por igual** y se entregan en dos bloques separados, nunca en una tabla única ordenada por días: el canal cambia el techo de escala, el AOV y qué se puede modelar.
- Si un bloque queda vacío, **se declara** («no encontré ninguna de web con ≥10 anuncios»). Un bloque vacío es un hallazgo, no un bloque que se omite.
- El canal se lee en el destino del anuncio. Si es dominio propio, abrirlo y confirmar que hay checkout y no un botón de WhatsApp disfrazado de landing.

- **Regla de 3 anunciantes**: una oferta/ángulo está PROBADA cuando **3+ anunciantes DISTINTOS** corren el mismo hook/oferta/formato 14+ días. Un mismo creativo reusado en 20+ anuncios de una página = despliegue masivo = ganador confirmado.
- **ANTI-HUMO**: la Biblioteca NO muestra impresiones ni gasto para ofertas comerciales (solo en anuncios políticos). Cualquier consejo tipo "filtra por 100K impresiones" es alucinación de blogs SEO: IGNORAR.
- Dentro de cada bloque de canal, tabla de candidatos ordenada por (días activos × nº de anuncios prendidos).

## FASE 2 — Landing, escala real y original-vs-copia
- Link saliente del snapshot: `curl` al `ad_snapshot_url` + grep de URLs externas; si Facebook no lo entrega (JS/login), pedir al usuario que abra los 3-5 mejores y pegue las URLs (10s c/u). Bajar el HTML crudo.
- **Tarjeta de gasto 12m**: en la página del anunciante (desde fines de 2025) figura el gasto acumulado a 12 meses — la única ventana de escala real fuera de anuncios políticos. Registrarla por anunciante.
- **UE (ley DSA)**: para ads dirigidos a la UE la Biblioteca expone `eu_total_reach` con desglose por país/edad/género y `target_ages`/`target_gender`/`target_locations` (1 año de histórico) — la ÚNICA data demográfica real de espionaje. Fuera de la UE el targeting no se divulga: se infiere por creativo y lenguaje.
- **Original vs copia**: el ORIGINAL es el anunciante con gasto 12m alto + más creativos vivos + más días corriendo; los CLONEROS aparecen después, con pocos días y menos creativos. Modelar SIEMPRE al original, no a un clon (hereda sus debilidades).

## FASE 3 — Calificar replicabilidad (score /10)
**Descarte inmediato** (score 0): VSL (player central + botón que aparece + poco texto); software/SaaS, servicios 1-a-1, físico con logística, membresías complejas.
**Las de WhatsApp NO se descartan del informe** — van en su propio bloque (ver FASE 1). Lo que sí puntúan bajo es la *replicabilidad tal cual*: no hay landing que modelar y el cierre es invisible. Si se propone llevar una de WhatsApp a web, eso se declara como el cambio de modelo de negocio que es, no se presenta como réplica.
| Criterio | Puntos |
|---|---|
| Entregable digital simple (ebook/planos/plantillas/prompts/recetario/curso corto) | +3 |
| Landing de comunicación directa (texto+imágenes; video opcional no obligatorio) | +2 |
| Contenido generable con IA (texto, imágenes, renders — sin expertise raro) | +2 |
| Precio impulso (USD 10-40 o equivalente local) | +2 |
| Plataforma simple (Shopify/Systeme/WordPress) | +1 |
Anotar: cómo está hecha (HTML propio vs page builder vs imágenes apiladas), checkout, y en qué idiomas/países corre (misma oferta en varios idiomas = doblemente validada).

## FASE 3.5 — Arbitraje geográfico (semáforo por mercado)
El país de origen no importa; importa el mapa de saturación. Buscar el tipo de oferta (keywords del entregable traducidas) en cada mercado y clasificar: **VIRGEN** (nadie la corre → entrar con todo) · **FLOJO** (existe con landings malas, sin estructura/regalos/prueba → la versión superior aplasta) · **SATURADO** (3+ jugadores escalados y bien ejecutados → evitar o diferenciar fuerte). Recomendar los 2-3 mercados de entrada.

## FASE 4 — Swipe file curado (tope 50-100, cero hoarding)
Solo ganadores confirmados: capturar snapshot + guardar creativos en `_staging\espionaje\<nicho>\creativos\` **SOLO para estudiar qué escala; JAMÁS montar nada con esos assets**. Por creativo, taguear EN EL CUERPO (nunca en frontmatter — los tags de frontmatter son las 11 áreas del Perfil): arquetipo de hook (pregunta / prueba-social / problema-primero / resultado / controversia) · mecánica · nivel de sofisticación (Schwartz). Al llegar a 100 se poda: sale el de menor score.

## FASE 5 — Dossier + guardado al cerebro
Score ≥ 7 → escribir en `_staging\espionaje\<nicho>\`:
1. `DOSSIER-<nicho>.md`: tabla de candidatos con días activos, nº de anunciantes distintos, gasto 12m y score; semáforo por mercado; original identificado; URLs de filtros usadas.
2. **Nota atómica** con el contrato de 02-notas lista para /orden — frontmatter `type: nota`, `created: <fecha>`, `tags: [copy, landings, meta-ads]`, `status`, `moc: pendiente`, `source` (URLs); cuerpo con la GUÍA DE RÉPLICA + **## Punto clave** (2-4 líneas: qué oferta, quién escala, mercado de entrada).
   GUÍA DE RÉPLICA (modela, no copies): mapa sección por sección del original · **mejora de OFERTA** = tu hook, mecanismo único NOMBRADO, garantía emocional, **bonus** con valor tachado (se dice "bonus" — "regalos apilados" y "ñapa" son jerga ajena, rechazada por la casa) · plan de producción con el Playbook de landing del cerebro · esfuerzo estimado (entregable, imágenes, días).
El vault tiene UN solo escritor: /orden mueve la nota a 02-notas/ y actualiza el MOC. La skill deja todo en `_staging\`.

## Lo que JAMAS haces
- Copiar copy, imágenes, marca ni creativos textualmente: modelas ESTRUCTURA, ÁNGULO y OFERTA; assets 100% propios (pasa compliance-checker antes de lanzar).
- Tocar ninguna herramienta de mutación de Meta/Shopify u otra plataforma: SOLO `ads_library_search` de lectura. La cuenta jamás se muta desde aquí.
- Creer cifras de impresiones/gasto de terceros fuera de la tarjeta 12m y el alcance UE: no existen públicamente, toda tool que las promete las inventa.
- Escribir directo en el vault (02-notas, MOCs, HOT.md) ni hacer git commit/push: eso es exclusivo de /orden. Tú dejas borradores en `_staging\`.
- Usar "bonos", nombres de categorías restringidas, ni visuales decorativos sin mensaje en la réplica.
- Scraping masivo: barridos dirigidos, batches chicos, robots.txt innegociable y 2s entre requests.
