---
name: evaluar-landing
description: Audita una maqueta o landing contra el criterio destilado del dueño del cerebro ANTES de entregarla. Usar SIEMPRE antes de mostrarle una maqueta, y también cuando diga /evaluar-landing, "puntuá esta landing", "auditá esto", "está lista para publicar", o pase una landing propia o de alumno para revisar. Corre 12 compuertas duras, la mitad verificables por máquina con anatomia.py, y devuelve veredicto ENTREGABLE / NO ENTREGABLE con la lista de arreglos.
---

# Evaluador de landings

Existe porque el que escribe la landing no puede juzgarla. Pasó en una
operación real: en pocos días se entregaron tres maquetas seguidas que el dueño
rechazó, y las tres veces el autor las había dado por buenas. Esta skill corre **después**
de escribir y **antes** de mostrar.

Regla de uso: si una compuerta dura falla, **no se entrega**. Se arregla o se
le dice al dueño qué falta y por qué, antes de pasarle el link.

## Primero, los datos objetivos

No opinar sobre lo que se puede medir. Sobre la maqueta ya publicada:

```
python3 ~/herramientas/anatomia.py <url-del-artifact> --escritorio
```

Y sobre la referencia que se está modelando, para comparar contra ella:

```
python3 ~/herramientas/anatomia.py <url-de-la-referencia>
```

Las compuertas 1, 2, 5, 6, 7 y 8 se resuelven con esos dos informes al lado.

## Las 12 compuertas

### Duras — si falla una, no se entrega

**1 · Tobogán.** Cero botones de compra arriba del bloque de oferta
([[landing-tobogan-sin-botones-arriba]]). En el informe de `anatomia.py`, mirar
`BOTONES` y el `en_pct` del primero: tiene que caer después del bloque de
oferta. Excepción declarada: si el dueño pidió el A/B contra la referencia, van
las dos versiones y se dice cuál es cuál.

**2 · Promesa cuantificable y con plazo.** Tiene que haber un número y una
ventana de tiempo en el H1. «Recuperá 10 horas por semana en 3 días» pasa.
«Un método que aguante una auditoría» no pasa. Las validadas del registro
siempre traen número.

**3 · Referencia validada, no investigación.** Preguntarse: ¿de dónde salió
esta estructura? Si la respuesta es «de la investigación de mercado» o «del
hueco que encontré en la Biblioteca de Anuncios», está mal. Tiene que salir de
un rayo-X de `_staging/landing-xray/`. La investigación produce hipótesis; el
registro produce validación. Ausencia de un ángulo en la Biblioteca **no es**
evidencia de que funcione.

**4 · Nada inventado que sea verificable.** Prohibido: testimonios con
credenciales verificables del oficio (números de registro profesional o similares); estadísticas con fuente nombrada
que no se puedan citar; precios de mercado como ancla externa sin comprobar.
Van como hueco marcado en ámbar, no como contenido.

**5 · Mockup como imagen, jamás CSS imitando una foto.** Regla de la casa, y
tiene razón: cupones, sellos y mockups son imagen diseñada. Una caja
3D hecha con `transform: rotateY()` no pasa. Se genera con Higgsfield
(`get_cost: true` primero, y no se toca un crédito sin OK del dueño).

**6 · Paleta y tipografía medidas, no estimadas.** Salen de `anatomia.py`
sobre la referencia, no de la intuición. Si el informe dice `#f59e0b` y
`Bebas Neue`, eso va — no «un dorado parecido» ni «una condensada pesada».

### Blandas — se reportan, no bloquean

**7 · Aspectos de imagen igual que la referencia.** Si la referencia usa 47 de
55 imágenes en 1:1 a 1254px, las nuestras van 1:1 a 1254px. El informe de
`anatomia.py` da la distribución de aspectos de las dos.

**8 · Ancla creíble.** Entre 2x y 10x. El 79% OFF de la landing original es
menos creíble que el 3.3x de ia-inmo. Y tiene que ser comprobable si es
externa.

**9 · Prueba social numérica.** Presente en 12 de 14 ganadoras. Si todavía no
hay número real, va el hueco marcado — nunca un número inventado.

**10 · Bonos nichados.** Cada bono ataca una microtarea distinta del flujo del
avatar, y están traducidos al nicho. ia-inmo dejó los suyos genéricos: esa es
la mejora que nos corresponde, no el error a copiar.

**11 · Garantía que cubre la entrega completa.** Si algo se entrega el día 8,
la garantía no puede ser de 7 días. Ese fue el hallazgo más caro de
una auditoría real.

**12 · Vocabulario de la casa.** Se dice **bonus** — es el término de la casa.
NO se dice «ñapa» ni «regalos apilados»: es jerga de otras tiendas y la casa la
rechazó explícitamente. Voseo en ES/LATAM. Nada de
palabras de categorías restringidas en nombres, dominios ni titulares.

## Veredicto

Devolver así, sin adornos:

```
VEREDICTO: ENTREGABLE / NO ENTREGABLE
Duras:   6/6 · o cuáles fallaron
Blandas: N/6 · o cuáles fallaron
ARREGLAR ANTES DE ENTREGAR
  1. ...
LO QUE FALTA DEL DUEÑO (huecos en ámbar)
  1. ...
```

Si el veredicto es NO ENTREGABLE, arreglar y volver a correr. Solo se le pasa
el link al dueño cuando las seis duras están verdes, o cuando la que falla es
una decisión suya declarada.

## Lo que esta skill NO hace

No opina sobre gusto. No propone rediseños. No reescribe copy. Puntúa contra
criterio escrito y devuelve una lista de arreglos. Para reescribir está
`/maqueta-landing`; para el copy, `copychief`.
