---
name: higgsfield-product-photoshoot
description: >-
  Produce las IMÁGENES de una oferta low ticket con Higgsfield: mockup del
  producto digital, hero, tiras de carrusel, sellos, cupones y cajas de bonus.
  Usar cuando el usuario diga /higgsfield-product-photoshoot, "generá el mockup",
  "necesito la foto del producto", "armá el hero", "tangibilizá esto", "hacé el
  sello de garantía", o cuando una maqueta llegue a la compuerta de
  evaluar-landing con un mockup hecho en CSS. SIEMPRE cotiza antes de gastar
  créditos y jamás genera sin OK explícito.
---

# Fotografía de producto para ofertas low ticket

Un producto digital no se ve. La imagen es la que lo vuelve una cosa que se
puede tener, y en low ticket eso decide la compra más que el copy. Esta skill
produce esas imágenes **medidas contra la referencia**, no "bonitas".

## La regla que la hace existir

**Mockups, sellos y cupones son IMAGEN DISEÑADA, jamás CSS imitando una foto.**
Una caja 3D hecha con `transform: rotateY()` se nota, y es compuerta dura de
`evaluar-landing`: si aparece, la maqueta no se entrega. Esta skill es la forma
correcta de cumplir esa compuerta.

## Paso 1 · Medir antes de generar (si no, el asset desalinea la página)

No se genera nada hasta tener estos cuatro datos de la referencia desarmada:

1. **El aspecto y el tamaño.** Salen de `03-anatomia.txt` del desarme. Dato
   real: ia-inmo usa **47 de 55 imágenes en 1:1**, con assets de producto a
   **1254 y 1024 px**, y cero 16:9. Producir con el aspecto equivocado
   desalinea toda la página y no se arregla con CSS.
2. **La paleta medida**, de `05-paleta.txt`. La imagen tiene que vivir dentro de
   esas familias de tono. Y el techo de saturación manda: **≤60% en nichos que
   venden prestigio** (escribanos, consultores, arquitectos). Un mockup con acento
   al 90% convierte una página seria en un curso de Hotmart
   ([[la-paleta-se-mide-no-se-elige]]).
3. **Dónde cae en el scroll**, de `02-forense-celular.txt`. Un asset que entra
   arriba del pliegue de 681 px tiene otro presupuesto visual que uno del medio.
4. **Qué hace la referencia con el producto**: ¿mockup 3D en la mano? ¿el
   printable impreso y armado en cámara? ¿la grilla completa de bonus?

## Paso 2 · Los invariantes visuales del nicho

Medidos sobre 11 ganadores de dos ofertas sin relación
([[patrones-visuales-y-titulares-ganadores]]). No son gustos:

- **SIN CARAS.** Manos + producto, siempre. Una cara mete un compromiso de
  identidad que la oferta no necesita y que además envejece mal.
- **TANGIBILIZACIÓN.** Lo digital se vuelve físico frente al ojo: el mockup
  sostenido en la mano sobre la escena real de uso, o el material impreso y
  armado en cámara. Es el patrón que más se repite y el que más rinde.
- **La escena es la del avatar**, no un estudio. La mesa de la cocina de noche,
  el taller, el escritorio del consultorio — lo que salió de la investigación.
- **Grilla de bonus visible.** La referencia pública con más escala muestra los 10
  bonus en pantalla. Si la oferta tiene stack, se ve.

## Paso 3 · Elegir modelo y COTIZAR

| Para qué | Modelo | Nota |
|---|---|---|
| Imagen de producto / ad comercial | `marketing_studio_image` | El default para esto. Resolución 1k/2k/4k |
| Partiendo de una imagen de referencia | `flux_2` · `seedream_v5_pro` | Aceptan referencias; adherencia alta al prompt |
| Máxima resolución | `seedream_v4_5` | Hasta 4K (y ~6K en calidad alta) |
| Barato, para explorar variantes | `nano_banana` | Para tantear composición antes de gastar en la buena |

Consultá `models_explore` si el caso no encaja en la tabla: el catálogo cambia.

### La compuerta de crédito — innegociable

```
generate_image  con  params.get_cost: true
```

**Siempre primero.** Devuelve el costo sin encolar nada. Le decís al dueño del cerebro
el número exacto y **esperás su OK**. Nunca se toca un crédito por iniciativa
propia, ni "para probar", ni porque parezca barato.

`use_unlim` va **solo** si el dueño del cerebro pide explícitamente usar sus generaciones
gratis. Jamás lo actives por tu cuenta para ahorrarle créditos: una llamada que
no puede servirse gratis se rechaza, y ahí ya perdiste el turno explicando.

Antes de una tanda grande, cotizá **una** y multiplicá: `count` y `batch_size`
escalan el costo linealmente.

Referencia orientativa (puede cambiar): `marketing_studio_image` a 1:1 y 2k costó
**2 créditos** por imagen. Sirve para estimar de memoria, no para saltearse la
cotización — el precio depende del modelo, la resolución y la calidad.

## Paso 4 · Verificar la imagen, no el job

Un `job_id` devuelto no es una imagen buena. **Mirala** — con `job_display` o
bajándola y abriéndola. Contra esta lista:

- ¿El aspecto es el que mide la referencia?
- ¿La resolución alcanza para el ancho al que se va a mostrar? (mínimo 2x el
  ancho de despliegue: los celulares son retina)
- ¿La paleta cae dentro de las familias medidas, con la saturación del acento
  bajo el techo del nicho?
- ¿Se lee a **384 px de ancho**? Todo texto quemado se juzga ahí, no en el
  monitor.
- ¿Hay caras, manos de seis dedos, texto deformado o logos inventados?
- ¿El producto se ve como una cosa que se puede tener?

Si falla una, se regenera ajustando el prompt — no se "arregla" con CSS.

## Paso 5 · Antes de publicarla, renombrala

Los nombres de archivo delatan con qué se generó cada imagen, y casi nadie los
renombra. **Higgsfield deja `hf_` + fecha.** Nosotros leemos las huellas de los
competidores exactamente así ([[medir-la-landing-antes-de-replicarla]]): ellos
pueden leer las nuestras. Nombre descriptivo antes de subir a Shopify.

## Lo que JAMÁS hacés

- **Gastar un crédito sin OK explícito del dueño del cerebro.** Cotizás, informás, esperás.
- **Generar personas que parezcan testimonios reales.** Prueba fabricada es
  compuerta dura de `evaluar-landing` y no se negocia. Si falta prueba social,
  va el hueco marcado, no una cara inventada.
- **Imitar la marca, el logo o los assets de la referencia.** Se modela
  estructura y mecánica; el clon no se publica.
- **Generar antes de medir.** Sin aspecto y sin paleta de la referencia estás
  produciendo desde una impresión, que es exactamente el error que ya costó
  tres maquetas rechazadas.
- **Reportar que quedó bien sin haber abierto la imagen.**
- Decir "regalos apilados" o "ñapa" en cualquier texto que acompañe: se dice
  **bonus**.
