---
name: investigar-mercado
description: >-
  Investigación de mercado v3 para productos digitales LOW TICKET (método del kit,
  estilo Agora/E5) + auditoría de oferta. Usar cuando el usuario diga
  /investigar-mercado, "investigá este mercado", "armá el avatar/offer brief",
  "método del kit", o pase una landing/oferta ganadora para investigarla.
  Empieza por un chequeo liviano de potencial (10 preguntas, 3 asesinas) y solo
  si pasa corre la investigación completa: 4 archivos encadenados
  (Investigación, Avatar, Oferta, Creencias) con lenguaje real citado y fuentes,
  más offer-audit con las 5 claridades, ecuación de valor, mecanismo único
  nombrado, plan de AOV y benchmarks → veredicto de cuello de botella
  OFERTA/CREATIVO/FUNNEL. Solo investiga y escribe borradores; jamás muta
  plataformas.
---

# Investigar Mercado v3 — método del kit, low ticket

Corre **de punta a punta**. El dueño del cerebro no pega prompts, no saca
capturas de pantalla, no descarga ni sube plantillas: pasa una oferta y recibe
los archivos.

**Entradas aceptadas** (cualquiera):
- una URL de landing ganadora,
- el dossier de `/espia-ofertas` con una o varias candidatas (procesalas en
  tanda, una por una),
- el nombre de una entrada que ya esté en el registro de espionaje.

Herramientas: WebFetch/WebSearch (investigación), Read/Write/Bash (staging).
Solo lectura de fuentes públicas.

> Si no hay oferta ni URL, pedila y detente.

## Encuadre que manda sobre todo
Esto es **low ticket**: compra por impulso, sin llamada de venta, sin proceso de
consideración. NO apliques lógica de mentoría / coaching / high ticket. En
concreto: la figura de autoridad y la discovery story casi no importan (nadie te
googlea por 17 dólares), los fracasos previos son domésticos ("lo intenté tres
veces y me quedó mal") y no "compré diez cursos", y las objeciones son de
fricción, no creencias profundas.

**"Producto digital" es el formato, NO el nicho.** El nicho es quesos veganos,
carpintería, crochet. Si en tu salida aparecen "emprendedor", "escalar",
"algoritmo", "gurú" o "libertad financiera" sin que el nicho real sea ese, te
fuiste de mercado: volvé a empezar.

## Arranque (barato, en orden)
1. HOT.md del cerebro.
2. `04-lecciones/INDEX.md` → solo el índice; abrí una lección solo si su señal
   matchea. Regla de autoridad: el hallazgo es tuyo, la decisión sobre su
   negocio es del dueño del cerebro.
3. `02-notas/blueprint-low-ticket-fases-y-loops.md` → esta skill vive en los
   pasos 1 y 2 del Loop A. Cuando el canon del programa lo contradiga, manda el
   blueprint.
4. Grep en 02-notas por el nicho/producto → decidí ADD/UPDATE/SUPERSEDE/NOOP.

## Paso 0 — Chequeo liviano de potencial (15 min, antes de gastar nada)
Diez preguntas; **las marcadas ☠ matan la oferta solas**:
1. ¿Está escalada? Días activos + cantidad de anuncios + regla de 3 anunciantes.
2. ☠ ¿Es replicable sin la cara/autoridad del que la corre? ¿No es VSL larga?
3. ¿El resultado se ve en video en 3 segundos?
4. ¿Qué hay gratis del tema y de qué se quejan en los comentarios?
5. ☠ ¿La promesa se puede escribir sin pisar categorías restringidas de Meta?
6. ☠ ¿Hay deseo adyacente obvio para bump y upsell? Sin AOV no cierra.
7. ¿Hay volumen en el idioma que se va a atacar?
8. ¿Se puede producir el producto?
9. ¿Es estacional? (Google Trends)
10. ¿El precio del front aguanta el CPA esperable?

Veredicto **GO / DUDOSA / NO**. Solo con GO seguís al paso 1. Con NO o DUDOSA,
anotás el veredicto en el registro y **frenás ahí**: no gastes la investigación
completa en una oferta que ya descartaste.

### El registro (obligatorio, siempre, incluso con NO)
Vive en `_staging/espionaje/landings-ganadoras.md` (esta skill lo crea con el primer
veredicto); desde ahí, nunca crees otro. Usa su esquema (`estado:` validada | potencial | pendiente |
descartada | placebo, más `rol:`). Es lo único que evita re-evaluar la misma
oferta cada quincena y lo que hace posible el barrido diario.

Es un **archivo vivo con varios escritores** (rule 9 de CLAUDE.md): releelo
**justo antes** de tocarlo, agregá solo tu bloque fechado con la URL, el
veredicto y en una línea por qué, y jamás reescribas ni reordenes lo que ya
está. Si ves cambios sin commitear que no hiciste vos, avisá y dejá la entrada
propuesta en tu salida en vez de escribirla.

## Paso 1 — Leé la oferta de referencia
WebFetch sobre la URL. Extraé literal: titular, promesa, bullets, precio, ancla,
bonus, garantía, testimonios, FAQ, CTAs, bump y upsells si se ven. Detectá el
**nicho real** y el avatar. Anotá qué mecanismo usa y qué nivel de sofisticación
implica.

## Paso 2 — Investigación profunda con fuentes reales

> **El banco de ≥30 citas lo produce `/voz-cliente`, no vos a mano.** Esa skill
> tiene la cadena de custodia de la cita y `~/herramientas/verbatim.py`, que
> verifica que cada frase exista TAL CUAL en su página fuente. Corré
> `/voz-cliente <nicho>` y consumí su corpus de `~/fuentes/voz-cliente/<nicho>/`.
>
> **WebSearch NO sirve para citas. Resume y TRADUCE.** Usalo solo para
> **encontrar** las URLs; después **WebFetch a cada página fuente** y pedile las
> frases textuales en el idioma original, sin corregir ortografía. Por ejemplo,
> en una corrida de prueba: las quejas más valiosas volvieron
> parafraseadas en inglés desde reseñas en español y hubo que descartarlas del
> banco. Una cita que pasó por el resumidor **no es una cita**: como mucho es un
> [I].

Buscá **en el idioma del mercado**, con las palabras que usa la gente ("no me
sale", "me quedó duro", "por qué no me queda"), nunca con jerga de marketing.
Fuentes por rendimiento:
- **Comentarios del tutorial gratuito más visto del tema**, ordenados por más
  votados. La fuente número uno: dice por qué lo gratis no alcanza.
- **Preguntas de producto en MercadoLibre** (LATAM) y **Q&A de Amazon**: ahí
  viven las objeciones de fricción.
- **Reseñas de 3 estrellas** (Amazon, Goodreads, Etsy, Hotmart): las únicas
  honestas.
- Autocompletar de Google/YouTube y "otras preguntas de los usuarios".
- Reddit, Quora, grupos de Facebook (posts con más comentarios), comentarios de
  TikTok/Instagram, Pinterest.
- Google Trends (estacionalidad) y Biblioteca de Anuncios (qué se promete hoy).

Cubrí: quién es realmente (qué hace 5 min antes del anuncio) · disparador de
compra · deseo concreto y visual · intentos fallidos · **competencia gratis y por
qué no alcanza** · otras soluciones pagas · qué valora y qué odia · de qué
desconfía · **objeciones de fricción** · **deseo adyacente** · sofisticación
deducida de evidencia · estacionalidad · **banco de ≥30 citas textuales con
fuente** · 5-8 ángulos candidatos marcando cuáles ya están ocupados.

Marcá cada dato **[V]** verificado (con URL) o **[I]** inferido. Lo que no
encontraste va a "Preguntas abiertas", no se rellena.

### Paso 2b — La capa de ANUNCIOS (obligatoria antes de clasificar ángulos)
**Foros y reseñas dicen lo que la gente dice; los anuncios ganadores dicen lo que
la gente compra. No son la misma lista.** Antes de marcar un ángulo como libre u
ocupado, mirá los anuncios activos del operador y de la categoría — vía
`~/fuentes/creativos/<oferta>/analisis-ganadores-*.md` si ya existe, o Biblioteca
de Anuncios.

Sacá de ahí: **cuál es el ganador y desde cuándo corre** (días activos = qué
ángulo está probado) · qué ángulos secundarios sostiene · **qué está testeando
esta semana** (hacia dónde migra el nicho) · si el copy ya nombra tu mecanismo ·
qué fricciones responde el copy (suscripción, entrega, "historias raras") · la
escuela de titular (precio EN el ad = oferta-led; sin precio = beneficio-led).

Por ejemplo, en una corrida de prueba: dos ángulos clasificados como libres
mirando solo la landing **resultaron ser el ganador de 3,5 meses y un ángulo
estable de dos meses**. Además apareció un dolor (limpieza) que no existía en
ninguna fuente de voz de mercado. Sin esta capa, la tabla de ángulos sale mal.

## Paso 3 — Escribí los 4 archivos encadenados
Carpeta: `_staging/investigacion/<producto>/` (Bash `mkdir -p`). Markdown,
español, con Write (UTF-8), nunca impresos crudos en consola:
1. `1. Investigacion - <Producto>.md` — todas las secciones del paso 2 +
   resumen ejecutivo + fuentes + preguntas abiertas + refutado.
2. `2. Avatar - <Producto>.md` — quién es (una escena, no un rótulo), momento de
   compra, 3 dolores con cita, intento fallido concreto, lo que quiere que pase,
   15 frases textuales, qué lo frena, deseo adyacente.
3. `3. Oferta - <Producto>.md` — MUP, **por qué no le alcanza lo gratis**, UMS
   con nombre propio, promesa + 3 variantes, 5 claridades, ecuación de valor,
   qué incluye (bonus atados a objeciones), garantía, precio y ancla, estructura
   económica, conciencia y sofisticación, objeciones con dónde se responden,
   5 títulos. **Declaración obligatoria de estructura**: si encaja en E1
   (PDP express) o E6 (Solved), las dos de `/maqueta-landing` + **guion madre**
   ([[guiones-madre-anuncios-ganadores]], son 6) + **escuela de titular**
   (oferta-led con precio en el ad / beneficio-led sin precio) + los invariantes
   visuales ([[patrones-visuales-y-titulares-ganadores]], son 9).
4. `4. Creencias - <Producto>.md` — **máx 6**, en primera persona, cada una con
   la creencia que reemplaza, qué la instala y dónde (anuncio / arriba de la
   landing / cuerpo / checkout), en secuencia. Marcá la **Estrella del Norte**.

Sin duplicar: las belief chains viven solo en el archivo 4.

## Paso 4 — OFFER-AUDIT
Anexo al archivo 3:
- **5 claridades**: outcome concreto · entregable claro · mecanismo único (por
  qué esto y no lo gratis) · para quién exactamente · precio y alcance sin
  ambigüedad. Si falla una, el cuello es la OFERTA y ningún volumen de creativos
  lo salva.
- **Ecuación de valor**: el resultado soñado ya viene alto; mové **TIEMPO** y
  **ESFUERZO**.
- **Mecanismo único NOMBRADO**: sin nombre propio no es mecanismo, es promesa
  intercambiable. Verificá que no esté ocupado por la competencia.
- **Plan de AOV**: con CPA parecido al front, la ganancia está en el backend.
  Modelo medido sobre compra real ([[2026-07-28-nutritionsolved-front-y-backend]]):
  order bump atado al deseo adyacente + **3 upsells que cubren dimensiones
  DISTINTAS del mismo trabajo** (más contenido / el flujo / lo que muestra o
  entrega), **anclados MÁS CAROS que el front**, en escalera descendente de
  fricción, con **downsell = mismo producto 7-10 puntos más barato**. Techo
  medido +163% de AOV; esa misma compra tomando 1 de 3 upsells: **+70%**.
  Banda de precio del ecosistema: front US$7-27, modas $17 y $27; escalón
  $9-15 para ES y nichos blandos ([[2026-07-28-marco-copy-visual-gatillos-solved]]).
- **Benchmarks**: front frío 1.5-3% · bump 30-40% · upsell 1 15-25% · hook rate
  >30% (reeditar los 3s si baja de 25%) · hold rate >25% · si hay VSL en low
  ticket, 5-10 min, nunca 20-45.
- **VEREDICTO**: **OFERTA** (falla una claridad, no hay mecanismo o no hay AOV) ·
  **CREATIVO** (oferta sólida, hook/hold bajo) · **FUNNEL** (se cae en
  bump/upsell/checkout) — y qué se arregla PRIMERO.

## Paso 5 — Reportá y entregá la posta
4-6 líneas: nicho y avatar detectados, **el mecanismo único hallado**, dónde
quedaron los archivos, el **VEREDICTO** y 2-3 ángulos recomendados marcando
cuáles están libres.

**Lo que sigue, y no lo hacés vos:** el archivo `3. Oferta` que dejaste es una
**hipótesis**. La oferta terminada la arma `/oferta-completa` (que exige esta
carpeta como entrada) y la estructura económica la arma `/pricing`. Decílo en el
reporte para que la cadena no se corte acá. El vault tiene UN solo escritor: /orden decide la
integración final. Vos dejás todo en `_staging/investigacion/`.

## Lo que JAMÁS hacés
- Inventar datos. Investigación real con fuentes; distinguí [V] de [I]; lo que
  falta va a Preguntas abiertas.
- Pegar el genérico de "ganar dinero online": adaptás SIEMPRE al nicho real.
- Aplicar lógica de mentoría a un producto de impulso (autoridad, discovery
  story, objeciones profundas, VSL larga).
- Entregar los 4 archivos desencadenados: Avatar, Oferta y Creencias SALEN de la
  Investigación.
- Imponerle vocabulario que no es suyo. La casa dice **"bonus"**; "regalos apilados
  y ñapa" es jerga de un tercero y está rechazada.
- Prescribir cómo debe trabajar: entregás hallazgo + evidencia, la decisión sobre
  su negocio es del dueño del cerebro.
- Devolverle prompts para que los pegue en otra herramienta, o pedirle capturas
  de pantalla y subidas de archivos. Si un paso se repite y se lo estás dejando
  a mano, o es imposible automatizarlo o no encontraste cómo todavía
  ([[2026-08-11-cerebro-ia-leccion-que-se-repite-pide-compuerta]]).
- Escribir directo en el vault o hacer git commit/push: eso es de /orden.
- Tocar ninguna plataforma (Meta/Shopify u otra plataforma): solo fuentes públicas y
  borradores.
