---
name: jurado
description: Arma y opera un JURADO DE CLIENTES IDEALES que juzga cada creativo antes de que gaste, lo revisa a los 3 días con los números y aprende de lo cobrado; además vigila la renovación de creativos y deja órdenes para la producción. Usar cuando el usuario diga "armá el jurado", "que el jurado juzgue esta tanda", "cómo viene el jurado", "/jurado".
---

# Jurado de clientes ideales

## Principios (no se negocian)
- A ciegas: el jurado nunca ve el nombre del anuncio ni números al juzgar. Limpiá del nombre GANADOR, ESCALA, COPIA, WINNER.
- Se cuenta TODO: aciertos y errores, piezas propias y de terceros.
- Resultado = ventas COBRADAS en la tienda por anuncio (UTM del anuncio), no el píxel.
- Sin dato no es cero: si las ventas no se pudieron leer, ese día no se cierra ningún veredicto.
- Es CONSEJO: nunca prende ni apaga nada; propone y el dueño decide. Con >= 70 % de acierto vende/no vende sobre >= 20 piezas cerradas en ese mercado, su opinión gana peso, pero la decisión sigue siendo del dueño.
- Lecciones concretas y comprobables, cada una con su evidencia.

## Archivos
- avatares/<mercado>.json: {"mercado", "contexto", "avatares": [10 × {id, nombre, edad, ciudad, familia, trabajo, nivel_economico, redes, preocupacion, que_lo_frena, que_lo_hace_parar, que_lo_hace_comprar, como_habla, escepticismo 1-10, peso (típico 1.0 / medio 0.7 / borde 0.4), aprendido: []}]}
- veredictos/<mercado>/<clave>.json: una pieza = previo + revision (3 días) + final.
- aprendizajes/<mercado>.md (libreta, máx. 40 viñetas con evidencia) · LECCIONES.md (comunes) · pruebas/<mercado>.md (plan) · ordenes/<mercado>.md · ALARMAS.md · MARCADOR.md.

## 1. Juicio previo (antes de cargar, y de todo lo activo que no vio)
Por pieza: ficha del gancho (0-4 s cada 0,5 s, cuadros grandes), ficha completa (12 cuadros con el segundo marcado), locución transcripta con Whisper local, y medidas con ffmpeg: cortes (select='gt(scene,0.3)'), segundos por plano, cortes en 0-3 s, segundo en que arranca la voz, palabras por minuto (130-160 ágil), % con voz, volumen (ebur128, ≈ -14 LUFS).
Cada uno de los 10, en primera persona: para_scroll, mira_hasta (0-3 s / mitad / final), compra, prob_compra 0-100, por_que, notas 1-10 (gancho, voz, ritmo, impacto, creatividad), lo_que_mas_me_pego.
El jurado: planilla 1-10 con porqué (gancho, locucion, voz, ritmo, impacto, creatividad, producto, confianza, mercado), pronóstico GANADOR / VENDE / NO VENDE, nota, por qué funcionaría, riesgo, mejora, angulo_corto (≤ 8 palabras), apuesta (VARIACION / NUEVA / TRADUCCION / COPIA), y un ranking de la tanda.
Darle al jurado la tasa real de su mercado ("la mayoría no vende") y la tabla de qué parámetro predice.

## 2. La cancha
Cada día, leer TODOS los anuncios activos de todas las cuentas. Agrupar por video_id / image_hash (las copias de la escala son la misma pieza). Lo que no tiene veredicto se juzga a ciegas (paso 1), lo más nuevo primero, con un tope por mercado por día.

## 3. Seguimiento diario
Por anuncio: gasto, impresiones, clics, CTR, CPM y estado (API) + compras e ingreso cobrados (tienda).
- A los 3 días en la cancha con gasto mínimo: informe. Acierto SÍ / NO / TEMPRANO, qué vio bien o mal, conclusión → libreta como "(provisorio)".
- Cierre (se apagó, llegó a tu criterio de ganador o venció a los 14 días): cada uno de los 10 se autocritica y guarda una nota de sí mismo (últimas 8); el jurado explica por qué pasó, saca la lección y reescribe la libreta (3 en contra y 0 a favor → se borra). Lo general va a LECCIONES.md.
- Lo que casi no gastó no cuenta como error.

## 4. Marcador (cada día)
Acierto vende/no vende, exacto, mitad de arriba del ranking, ganadores anticipados y provisorio a 3 días, por mercado. Peso de cada cliente = peso inicial × (0,5 a 2 según acierta). Tabla de predictores: nota media de cada parámetro y medida en lo que vende vs lo que no.

## 5. Plan de pruebas (por mercado)
Qué sabemos (con evidencia) + máx. 3 hipótesis abiertas (al menos 1 innovación real), cada una con qué cambia, por qué, cómo se prueba y qué la confirma. Se cierra con 3 piezas cerradas (confirmada o descartada).

## 6. Vigía (cada día, al final)
Alarmas: renovación (< 3 nuevas en 3 días / < 6 en 7; roja si 0 en 3 días), repetición (> 50 % mismo ángulo o COPIA/TRADUCCION), sin ideas NUEVAS en 7 días, ganador sin VARIACION en 7 días, hipótesis quietas. Escribe ALARMAS.md y ordenes/<mercado>.md: "la próxima tanda trae sí o sí" (1 VARIACION de lo que vende con qué se cambia + 1 NUEVA) y "no repetir". Avisa solo las rojas.
La producción lee las órdenes antes de elegir, las cumple dentro de su volumen, marca la apuesta de cada conjunto y anota "orden_no_cumplida" si no pudo.

## 7. Semana
Consolidar LECCIONES.md, elegir UNA innovación común para todos los mercados, reemplazar a los clientes con >= 15 votos y < 45 % de acierto, escribir un informe corto.
