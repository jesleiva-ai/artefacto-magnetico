---
name: lanzar-idioma
description: Lanza un idioma o país nuevo de punta a punta (guía del traductor, marca y dominio, tienda clonada con precio y cobro locales, landing, imágenes, PDF, bonos, post-compra, entrega, fanpage, Instagram, cuenta publicitaria, píxel + CAPI, dominio verificado, creativos y carga en pausa) y termina con un diagnóstico que tiene que dar cero errores. Usar cuando el usuario diga "lancemos en <idioma/país>", "abrí un idioma nuevo", "/lanzar-idioma".
---

# Lanzar un idioma nuevo

## Reglas fijas
1. Cada fase tiene una compuerta y se verifica contra el ARTEFACTO real (página publicada, PDF abierto, cuenta leída por API). "El script dijo ok" no es prueba.
2. Todo se carga en PAUSA. Prender lo decide el usuario, después del diagnóstico.
3. Un anuncio habla un solo idioma: video, copy, link, país, fanpage y filtro de idioma del conjunto.
4. Orden: tarjeta en la cuenta antes de cargar; idioma en la entrega antes de apuntar productos; PDF definitivos antes de locutar.
5. Se traduce lo que ya ganó: mismo video, otra voz y otros subtítulos.
6. Nada personal del dueño en nada que vea un cliente: solo la marca y, si hace falta, la empresa.

## Banco de trabajo
Crear una carpeta por idioma con ESTADO.md: tabla de fases | dueño | estado | prueba. Actualizarla después de CADA fase. Al retomar, leerla y no rehacer lo que ya tiene ✅ con prueba. El molde es el idioma lanzado más recientemente: copiar sus scripts, nunca editar los compartidos.

Repartir: 4 agentes locales en paralelo (textos · PDF y bonos · imágenes · creativos) que guardan después de cada tanda; la sesión principal hace en serie lo que toca plataformas (dominio, tienda, Meta, carga, diagnóstico).

## Fases
0. VOZ Y GUÍA: ~100 frases reales de compradores del país con fuente → guía del idioma (registro, puntuación, números, léxico, tabla de nombres fijos del producto y sus piezas). Nada se traduce antes. Compuerta: la guía existe y todos la usan.
1. MARCA Y DOMINIO: equivalente local nativo + 2 alternativas, buscadas en la Biblioteca de Anuncios y en el buscador del país (libre, sin doble sentido, sin chocar con una marca famosa). Dominio .com con el perfil de la empresa; www por CNAME a la tienda, raíz con A. Compuerta: https://www.dominio abre con certificado.
2. TIENDA: clonar la tienda base VIVA (ajustes, cobro, landing, productos, funnel completo). Nombre de tienda = marca local. Precio local redondo en mercado propio por país; no bajar precio en países con poder adquisitivo. Confirmar que la cuenta de cobro puede cobrar el medio local (doc oficial; si está instalada, correr /cobro-por-mercado). Compuerta: checkout PUBLICADO abierto desde el país cobra el precio y la moneda correctos (campo de lo que paga el comprador).
3. LANDING Y TEXTOS: transcrear desde la landing base leída en vivo. Revisar los TRES lugares: HTML visible, campos de la tienda (título/descripción de la pestaña) y funnel post-compra. Testimonios: solo reales y con permiso; un testimonio de otro mercado no se rebautiza con un nombre local (eso es inventarlo). Verificador propio de restos del idioma y la marca base, probado rompiéndolo. Buscar por palabra suelta, no por acentos. En la UE: sin tachado inventado, sin cuentas regresivas. Compuerta: landing publicada con 0 idioma base, 0 marca base, 0 imágenes rotas.
4. IMÁGENES CON TEXTO: recrear con GPT Image pasando la original + lista completa de textos letra por letra. No borrar y pegar texto por código. Dos juegos: mockups de producto e imágenes de landing. Auditor que lee cada imagen ampliada; tras 2 intentos fallidos, 3 variantes y elegir. Subir con nombre nuevo y reemplazar por URL. Compuerta: cada imagen leída como copy; landing sirve solo las nuevas.
5. PDF: cada página en dos capas (base limpia sin letras + capa de texto con caja/color/tamaño/estilo); traducir la capa y renderizar por código. Fuentes con el alfabeto completo; corte de línea correcto en idiomas sin espacios. Borrar sellos de fondo; traducir mapas y carteles dentro de las imágenes; ninguna página queda solo con texto. Compuerta: OCR de cada PDF con 0 restos y revisión página por página.
6. BONOS Y POST-COMPRA: igual que la fase 5; adaptar al sistema de escritura lo que dependa del idioma. Copiar precios y descuentos del funnel desde la base viva. Compuerta: cada PDF abierto, ninguno en otro idioma ni repetido.
7. ENTREGA: link directo a la app o área de miembros con el idioma en el link, sin PDF intermedio. Primero el idioma publicado en la app (textos, productos nuevos, archivos); después los productos de la tienda. Compuerta: en la app PUBLICADA, con un mail de prueba, se baja un archivo del idioma.
8. META:
   - Fanpage desde el portafolio (Páginas → Añadir → Crear nueva). Logo premium (referencias, 3 rutas, pensado para el círculo), portada, información completa, 3 posts fijos.
   - Instagram desde el Inicio de la página en Business Suite → Conectar → Crear perfil. Máx. 1-2 altas por día; no entrar por web a una cuenta recién creada; foto y bio desde el celular; verificar instagram_business_account por API y autorizarlo en la cuenta.
   - Cuenta publicitaria: si es nueva, crearla con país y moneda desde el primer paso; cargar la tarjeta ANTES de todo; leer por API país de negocio y método de pago. Mismo huso horario que el resto de tus cuentas.
   - Píxel propio, vinculado a la cuenta y cargado en la tienda. Token CAPI por "Configurar la integración directa" → "Configurar sin Dataset Quality API" → "Generar identificador de acceso"; probar con evento de prueba y guardarlo en la tienda.
   - Dominio verificado por TXT en el DNS (TTL corto; Meta mira la raíz sin www).
   Compuerta: cuenta leída por API (activa, moneda, país, pago), evento de prueba recibido, dominio VERIFIED.
9. CREATIVOS Y CARGA: ~12 piezas desde los ganadores de otros idiomas + el ganador histórico traducido exacto; voces nativas; subtítulos quemados rehechos con el mismo estilo; muestras del producto en el idioma; 2-3 placas fijas. Auditar cada pieza: transcripción contra el guion (marca y cifras exactas), OCR de cuadros (0 otro idioma, 0 marcas ajenas), cifras escritas como se leen, música baja bajo la marca. Carga: campaña de testeo del idioma, un conjunto por pieza clonado del molde con el mismo presupuesto chico, región donde se habla el idioma + FILTRO DE IDIOMA siempre, fanpage + su Instagram, ciclo de vida "todas las audiencias" (a mano), mejoras de Advantage+ creativo todas apagadas, link al dominio del idioma, píxel del idioma, evento de compra, TODO EN PAUSA. Máx. 2 cargas en paralelo a la API. Compuerta: cada anuncio leído uno por uno.
10. DIAGNÓSTICO: script propio que revisa Tienda · Landing publicada · Checkout · Funnel · Entrega · Meta · PDF y termina en "LISTA PARA LANZAR" o "NO LISTA". Un chequeo que no corrió es [skip], nunca [ok]. Después, auditor de idioma sobre los anuncios en pausa = 0 errores. El usuario prende. Sumar el idioma al tablero y a los robots de medición. Compuerta del testeo: 3 días.

## Lo que decide el usuario
Nombre de marca, compra del dominio, precio, cifras de prueba social, la tarjeta de la cuenta y prender.

## Al terminar
Respuesta final: tabla por fase (✅/🟡/⬜ + la prueba), marca y dominio, bloqueos, y qué falta que haga el usuario.
