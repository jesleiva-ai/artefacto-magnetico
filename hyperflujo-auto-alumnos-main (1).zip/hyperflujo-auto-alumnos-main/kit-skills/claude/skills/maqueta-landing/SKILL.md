---
name: maqueta-landing
description: Convierte una oferta en una maqueta de landing VISIBLE y navegable (link privado) para que el dueño del cerebro elija estructura, copy y jerarquía antes de tocar Shopify. Usar cuando diga /maqueta-landing, "armá la landing de esta oferta", "mostrame cómo quedaría", "maquetá esto", "quiero verla", o cuando pase el link de una oferta a rehacer. Monta el copy sobre una de las dos estructuras validadas que trae el arnés (E1 PDP express o E6 Solved), lo renderiza en el arnés con marco de celular, marcas de bloque B1..Bn, modo esqueleto e índice navegable, y lo publica como artifact para iterar por número de bloque.
---

# Maqueta de landing

El dueño del cerebro no aprueba copy en un documento. Aprueba **la página renderizada, en un
marco de celular**, porque ahí es donde su comprador decide. Esta skill existe
para que la distancia entre "tengo una oferta" y "la estoy mirando como el
mercado la va a ver" sea de una sesión.

Salida: un artifact (link privado) con la landing montada sobre una estructura
validada, no un archivo de texto.

## REGLAS DURAS — se chequean antes de mostrar nada

Estas tres se rompieron una vez en una operación real y costaron una entrega completa.

1. **La referencia validada gana sobre la investigación de mercado.** Buscar
   PRIMERO en `_staging/landing-xray/` si ya hay un rayo-X de una landing del
   mismo tipo de oferta. Si lo hay, ese es el molde. La investigación de
   mercado produce **hipótesis**; el registro de ganadoras produce
   **validación**. No inventar un ángulo nuevo teniendo uno validado.
   Ausencia de un ángulo en la Biblioteca de Anuncios **no es** evidencia de
   que ese ángulo funcione.

2. **Cero botones de compra arriba del bloque de oferta**
   ([[landing-tobogan-sin-botones-arriba]]). Regla dura de la casa, con caso en
   vivo: pasó en una operación real que las ventas se frenaron al meter un botón en el hero.
   El orden es dolor + beneficios → **bloque de oferta** → bonus, FAQ,
   testimonios. Los CTA se repiten de la oferta hacia abajo, jamás arriba.
   Ningún flotante, ningún WhatsApp. En el hero va un **ancla que baja al
   bloque de oferta**, nunca un botón que va al checkout: obliga a leer.
   El arnés cuenta los botones que quedan arriba y lo muestra en la barra —
   si dice ✕, no se entrega.

3. **La promesa va cuantificada y con plazo.** «Recuperá 10 horas por semana,
   en 3 días» sí. «Un protocolo que aguante una auditoría» no. Las validadas
   del registro siempre traen número: *«en 3 días»*, *«+40 planes»*,
   *«en apenas 5 minutos»*.

Y una de forma: **si el dueño pide N estructuras, se entregan N**, no las dos
que parecen mejores. Él elige; la skill no pre-filtra.

4. **MIRAR la referencia antes de diseñar.** Los rayos-X del vault dicen casi
   todos «Paleta y tipografía: no disponible en captura de texto» — el texto no
   alcanza. Correr **siempre**:

   ```
   python3 ~/herramientas/ojos.py foto --url <referencia> --cerrar
   ```

   Devuelve tiras PNG del alto de la pantalla en `~/fuentes/artifacts/`. Hay que
   **abrirlas y verlas**, no listarlas. De ahí salen paleta, tipografía,
   mockups y gestos. Sin esa pasada, la maqueta sale gris y genérica — pasó en
   una operación real y costó dos entregas.

   Y verificar lo publicado igual: `ojos.py foto --url <artifact> --escritorio`.

5. **La comunicación es el 90%, y la mitad de eso es visual.** No se entrega
   una maqueta con rectángulos rayados donde va la imagen. Mínimo:
   paleta elegida por nicho, tipografía display condensada pesada para el
   titular, y el producto **tangibilizado** (caja 3D en CSS, patrón visual 4 de
   [[patrones-visuales-y-titulares-ganadores]]). Lo digital se vuelve físico
   frente al ojo o no vende.

6. **El producto va DESPUÉS de la oferta.** El dueño produce lo que haga falta:
   curso en video, pack de plantillas, agentes configurables, comunidad. No
   limitar la oferta a lo que vende la referencia — se propone la mejor oferta
   y él fabrica el producto. Cada variante entregada dice **qué producto hay
   que crear**.

## La paleta se MIDE por nicho. No hay tabla que consultar

**Una tabla de paletas hace fallar entregas.** Por ejemplo: una tabla que diga
«IA para profesión (varios oficios juntos) → dorado» generaliza desde una
referencia de *otro* nicho. Si con esa tabla se arma una oferta para un oficio
de precisión en navy + oro sin medir un solo competidor de ese oficio, puede
pasar que al medirlos **el nicho entero sea azul** (el software dominante del
oficio y la mayoría de las ofertas), **nadie use dorado**, y el oro resulte ser
código de *otro* oficio —toga, balanza, biblioteca—, no del de cerrar números.
Antes de elegir paleta, chequear el color dominante del nicho. La paleta no se
hereda de una oferta validada de otro nicho ni sale de una lista: **se mide,
cada vez.**

### El procedimiento, sobre dos ejes

1. **Qué usa el nicho.** Correr `~/herramientas/paleta.py` sobre **4-6 ofertas
   que estén vendiendo** en ese nicho (salen de `/espia-ofertas`). Anotar fondo
   dominante, acento, familias de tono y el veredicto diseñada/acumulación.
2. **Qué mira el avatar todo el día.** Medir el **software o entorno** de su
   oficio — por ejemplo, el sistema de gestión que usa todo el día, o la planilla de su rubro.
   Ese color es su definición de «trabajo», y por eso *no le llama la atención*.
3. **Elegir por diferenciación fundamentada.** El fondo lo dicta el eje
   emocional del oficio (abajo); el acento se busca lejos de lo que ya mira,
   idealmente en el **complementario** del color dominante del nicho.

### El eje emocional decide el fondo, antes que el color

Preguntarse **qué compra ese profesional**, que no es lo mismo que qué vende:

- Compra **autoridad** (escribano, consultor) → fondo oscuro, serif, penumbra.
  Gana por cómo lo perciben.
- Compra **precisión y control** (perito, auditor, liquidador) → **fondo claro**,
  alto contraste, sans. Su miedo no es parecer poco importante: es que un
  número esté mal. Su mundo no es la biblioteca, es la hoja con las cuentas
  claras.
- Compra **alivio** (salud, crianza) → claro y aireado, semántica de calma.

### Compuertas, no gustos

- **Saturación del acento ≤60%** en nichos que venden prestigio o precisión.
  ≥80% es la firma visual del descuento ([[la-paleta-se-mide-no-se-elige]]).
  Verificable: las paletas que miden «diseñada» traen acentos bajos (terracota
  43%); las de «acumulación» los traen altos (ámbar 78%).
- **1-2 familias de tono, nunca 4.** Las de cuatro se ven armadas de a pedazos.
- **Los neutros son el acento desaturado**, no grises. Un gris de saturación 0%
  delata que nadie lo eligió.
- Método completo en [[la-paleta-se-mide-no-se-elige]]; cómo elegir el tono de
  un nicho nuevo, en [[elegir-la-paleta-de-un-nicho]].

### Casos ya medidos — son evidencia, NO prescripción

Sirven para comparar contra lo que midas, jamás para saltear la medición:

| Nicho | Medido | Fondo · acento |
|---|---|---|
| Autoridad (ejemplo) | referencia ajena | navy `#0E1219` · oro `#BE9B4C` (47% sat) |
| Precisión, nicho azul (ejemplo) | 4-6 ofertas + el software del oficio | papel `#FBFAF8` · naranja quemado — si el nicho es azul, hay que salir de ahí |
| Salud / alivio (ejemplo) | desarme de una referencia | blanco azulado `#F5FBFF` · azul `#397AA1` |
| Oficio / biblioteca | falegname | papel `#faf7f1` · burdeos `#8a2f3b` |
| Software / agentes | — | azul eléctrico. Único caso donde el azul se justifica: el producto **es** software |

## Las 3 preguntas de arranque

Hacerlas SIEMPRE antes de escribir, en este orden. No son opcionales y no
dependen de que el dueño se acuerde de contestarlas:

1. **¿Qué referencia validada del registro modelamos?** (si hay una obvia,
   proponerla y que confirme — no preguntar en abstracto)
2. **¿Cuál es la promesa cuantificable y con plazo?** Depende de qué entrega
   el producto de verdad; no se puede adivinar.
3. **¿Ticket y mercado?** Define estructura y, sobre todo, front solo vs
   front + backend.

## Antes de escribir una sola línea

Leer, en este orden:

1. `references/arnes.html` — el orden de bloques de las dos estructuras (E1 y E6).
2. Si la oferta cae en E6: [[2026-07-28-marco-copy-visual-gatillos-solved]]
   — doctrina de naming, léxico Solved, gatillos.
3. `~/cerebro/02-notas/playbook-landings-escaladas.md` — lo que hacen las 21
   escaladas verificadas.

Son **hipótesis derivadas de ganadores reales**, no teoría. Si el vault
contradice a un manual de copywriting, gana el vault.

## Los dos datos que hay que pedir sí o sí

**Ticket y mercado.** Con eso queda definida la estructura y, sobre todo, si
vamos **front solo o front + backend**. No arrancar sin eso: cambia el tamaño
de todo lo demás.

- **E1 · PDP express** — compra rápida desde el celular, ticket bajo (hasta ~20 USD),
  producto que se entiende en una mirada.
- **E6 · Solved** — producto sistema con una transformación que hay que explicar
  (práctica profesional, método, oficio), lectura más larga.

El mismo nicho **puede cambiar de estructura según mercado y ticket**: nunca asignar
por producto solo. Si la oferta no encaja en ninguna de las dos, se parte de la más
cercana y se ajusta el orden de bloques con lo que muestren las referencias ganadoras.

Proponer una estructura con fundamento **y la otra como alternativa**. Elige el dueño.

## Pipeline

0. **`anatomia.py` sobre la referencia. Obligatorio, antes que nada.**

   ```
   python3 ~/herramientas/anatomia.py <url-referencia>
   ```

   Devuelve lo que ningún análisis por texto puede dar: stack, checkout,
   tipografías reales con sus pesos y tamaños, paleta pesada por área pintada,
   cada imagen con su tamaño natural y su relación de aspecto, carruseles
   (librería, slides, autoplay, desvanecimiento lateral), y el `en_pct` de cada
   botón — que resuelve la pregunta del tobogán con dato, no con opinión.

   También delata el origen de cada asset: ChatGPT y DALL-E dejan el nombre
   literal, Higgsfield arranca con `hf_`. Eso dice con qué se replica.

   Después `ojos.py foto` para VERLA. Los dos, siempre. La medición sin la foto
   no alcanza y la foto sin la medición tampoco.

1. `/landing-xray` sobre la referencia — stack, funnel, precio, bump, OTOs.
2. `/espia-ofertas` — los ángulos ocupados se leen en los **anuncios**, no en
   la landing.
3. `/investigar-mercado` — avatar, creencias, offer-audit → veredicto de
   cuello: OFERTA / CREATIVO / FUNNEL. **Si el cuello es OFERTA, maquetar es
   perder el tiempo**: decírselo y arreglar la oferta primero.
4. Elegir estructura (arriba) y confirmar con el dueño.
5. Escribir el copy con `direct-response-copy`, bloque por bloque, respetando
   el orden de la estructura elegida.
6. Pasarlo por `copychief` antes de mostrarlo. Sin excepción.
7. `compliance-checker` si hay claims de salud, plata o resultados.
8. Renderizar en el arnés (abajo) y publicar el artifact.
9. Verificar con `python3 ~/herramientas/ojos.py ver --url <artifact>` — mirar
   lo publicado, no asumir que salió bien.
10. Iterar por número de bloque hasta el OK.
11. Recién ahí, traducir a secciones del theme de Shopify.

## Reglas transversales (12+ de 14 ganadoras)

No son opcionales. Si una se rompe, tiene que ser una decisión declarada:

- **Ancla tachada 2-10x** antes del precio impulso.
- **Regalos valorizados UNO A UNO**, cada uno con su precio, condicionados a
  HOY. Nunca en bloque.
- **Timer / escasez** arriba de todo.
- **Prueba social numérica manual** ("+2.480 clientes"), sin logos.
- **FAQ al pie**, corta, que mata fricción sin abrir debate nuevo.
- **CTA imperativo en primera persona que nombra el producto** ("QUIERO MIS
  150 PROTOCOLOS", no "Comprar").
- **Cero VSL** — 0 de 21 escaladas usan VSL. El ad va directo a la PDP, nunca
  al home.

Vocabulario: **se dice "bonus"** — es el término de la casa. No usar
"ñapa" ni "regalos apilados": son jerga de otras tiendas y la casa las
rechazó explícitamente.

En E6, además: el nombre **es la promesa cumplida** (participio de resultado,
nunca gerundio de esfuerzo), todo entregable lleva nombre propio + ™, y los
números de completitud van en el nombre o el subtítulo (6 volúmenes, 360+
páginas, 365).

## El arnés

`references/arnes.html` — página autocontenida. **Lo único que se reemplaza es
el objeto `VARIANTES`** en el bloque DATOS; de `// RENDER` para abajo no se
toca.

Cada variante:

```js
E1: {
  nombre:"E1 · PDP express",
  pie:"Cuándo usarla — una línea",
  url:"tutienda.com",
  bloques:[ {n:"Nombre del bloque", q:"Qué trabajo hace", html:`...`}, ... ]
}
```

- `n` y `q` alimentan el **modo esqueleto** y el índice. `q` es el *trabajo*
  del bloque, no su descripción.
- Las marcas `B1..Bn` se numeran solas por posición.
- Cargar **dos variantes** cuando la elección de estructura esté abierta: se
  comparan con el selector, sobre la misma oferta.

**Imágenes:** el CSP del artifact bloquea todo lo externo. Van como
`ph("SPEC")` — un placeholder rayado con el spec exacto de qué tiene que
mostrar la foto ("mockup de 6 volúmenes sobre tablet, fondo crema, luz suave").
Ese spec **es** el brief para generar el creativo con Higgsfield después. Las
definitivas se incrustan como data URI.

Publicar con `Artifact`, favicon 📐. Para actualizar: republicar **el mismo
path** — mantiene el link, el dueño no tiene que abrir uno nuevo cada vez.

## Cómo se itera

La devolución del dueño viene por número: *"B4 fuera, B7 antes de B5, el titular
de B2 no me cierra"*. Aplicar y republicar en el mismo path. No pedirle que
describa; si algo no se entiende, mirarlo con `ojos.py`.

## Dónde termina esto

La maqueta **no es la tienda**. Shopify no come HTML suelto: una vez aprobada,
se traduce a secciones del theme. Y para medir de verdad hace falta el dato de
Shopify — Meta es piso, Shopify es la verdad
(`~/cerebro/02-notas/reglas-de-lectura-de-metricas-meta.md`).
