---
name: meta-ads
description: Opera las cuentas publicitarias de Meta del dueño del cerebro de punta a punta — sube videos desde el disco, crea campañas y conjuntos, carga tandas de anuncios en pausado, lee métricas y mueve presupuestos, siempre dentro de sus criterios y de los límites reales de la API. Usar cuando diga /meta-ads, "cargá estos creativos", "subí los videos a la campaña", "cómo viene la campaña", "bajale el presupuesto a X", "pausá lo que no rinde", "creá una campaña para Y", o cuando una tanda de creativos esté lista para entrar a la cuenta. Jamás prende nada y JAMÁS mueve un presupuesto —ni arriba ni abajo— sin orden explícita del dueño.
allowed-tools: Bash(python3 ~/herramientas/meta_ads.py:*), Bash(python3 ~/herramientas/meta-cli.py:*), Bash(python3 ~/herramientas/clonar-conjunto.py:*), Bash(python3 ~/herramientas/probar-freno.py:*), Bash(python3 ~/herramientas/guardian-meta.py:*), Bash(ls:*), Bash(find:*), Read, mcp__claude_ai_Meta_Ads_MCP__ads_get_ad_accounts, mcp__claude_ai_Meta_Ads_MCP__ads_get_ad_entities, mcp__claude_ai_Meta_Ads_MCP__ads_get_pages_for_business, mcp__claude_ai_Meta_Ads_MCP__ads_get_ad_images, mcp__claude_ai_Meta_Ads_MCP__ads_get_ad_videos, mcp__claude_ai_Meta_Ads_MCP__ads_creative_upload_image, mcp__claude_ai_Meta_Ads_MCP__ads_creative_upload_video, mcp__claude_ai_Meta_Ads_MCP__ads_create_campaign, mcp__claude_ai_Meta_Ads_MCP__ads_create_ad_set, mcp__claude_ai_Meta_Ads_MCP__ads_create_ad, mcp__claude_ai_Meta_Ads_MCP__ads_get_ad_preview, mcp__claude_ai_Meta_Ads_MCP__ads_update_entity, mcp__claude_ai_Meta_Ads_MCP__ads_insights_performance_trend
---

# Operar Meta Ads

Hay **tres puertas** a la misma API de Meta, y puede haber una cuarta boca que no
es tuya pero come del mismo cupo. No son competencia: cubren huecos distintos y la
elección es por lo que necesitás hacer, no por preferencia.

## Cuál usar

| Necesitás | Vía | Por qué |
|---|---|---|
| Cargar creativos, crear campañas/conjuntos/anuncios, leer métricas, mover presupuestos | **Conector MCP** (`ads_*`) | No pide token propio: ya está autorizado. Empezá siempre por acá. |
| Subir un video o imagen **desde el disco** | `meta_ads.py` | El conector solo acepta **URL pública** — ver abajo. |
| Correr desatendido (cron, launchd, sin chat abierto) | `meta_ads.py` | El conector vive dentro de la sesión. |
| Lo que el CLI oficial de Meta haga mejor | `meta-cli.py` | Envuelve el binario oficial (`meta`, paquete `meta-ads` de PyPI) con el freno de la casa. **Nunca llames al binario pelado**: no trae ninguna protección. |

**La cuarta boca:** cualquier panel o tablero propio que lea métricas de la misma
cuenta por su lado (por ejemplo, uno que consulte cada hora). No lo toques, pero
**contá con su tráfico**: el cupo es por cuenta y se comparte.

## Las tres puertas comparten UN freno

Un solo archivo de enfriamiento, una cola por cuenta y un solo libro contable. Si
Meta frena por una puerta, las tres quedan cerradas — el conector incluido, vía el
hook `hook-freno-meta.py`, que lo bloquea antes de que salga la llamada.

**El contrato de esos archivos está escrito**: `~/herramientas/CONTRATO-FRENO.md`.
Leelo antes de tocar cualquiera de los tres, y sobre todo antes de sumar un cuarto
escritor. Se prueba a demanda con `python3 ~/herramientas/probar-freno.py`
(19 casos, sin tocar la red).

Confirmá siempre con `ads_get_ad_accounts` que la cuenta destino traiga
`is_ads_mcp_enabled: true` — algunas cuentas pueden estar todavía fuera del
despliegue del conector, y lo dicen explícito.

### El único límite del conector: los uploads piden URL pública

`ads_creative_upload_image` y `ads_creative_upload_video` **descargan el archivo
de una URL**; no leen bytes del disco. Y la doc del conector avisa que **Drive y
Dropbox NO sirven**: devuelven una página de login en vez del archivo.

Los creativos del dueño viven en el disco (`~/Desktop/`, `~/fuentes/creativos/`).
Para pasarlos al conector, en este orden:

1. **El CDN de su propia tienda**, con un comando:
   ```bash
   python3 ~/herramientas/shopify.py subir-archivo ~/Desktop/creativos-X/01-hero_4x5.jpg
   ```
   Sube, espera a que Shopify lo procese, comprueba que la URL responda 200 y te
   la imprime lista para pasarle al conector. Los creativos no salen de su
   infraestructura propia. Necesita `~/.config/shopify.json` con `write_files` o
   `write_themes`.
2. `meta_ads.py subir-video` / `subir-imagen`, que sí leen del disco. El token
   sale solo del Llavero una vez conectado. Verificá después por la otra puerta
   (el conector) que imagen y video estén en la cuenta: es la única forma de
   saber que entraron de verdad y no solo que el POST devolvió 200.

Si ninguna está disponible, **decilo y frená**: no inventes hosting temporal ni
subas creativos del dueño a un servicio de terceros sin que él lo sepa.

### La vía del script

`~/herramientas/meta_ads.py` (Graph API v26.0, sin dependencias). **21 comandos**:
`conectar · salud · diagnostico · limites · ascenso · cuentas · paginas ·
campanas · conjuntos · anuncios · subir-video · subir-imagen · miniaturas ·
crear-campana · crear-conjunto · crear-anuncio · cargar-tanda · metricas ·
presupuesto · pausar · prender`. Corre siempre con `python3`.

**El token vive en el Llavero** una vez que corriste `conectar` (ver abajo). Con
eso no hace falta pedirle nada al dueño para operar, ni exportar `META_TOKEN` a
mano. Anotá cuándo vence (lo muestra `conectar`) y agendá renovarlo antes. Lo que sí conviene fijar por entorno es el destino:

```
export META_AD_ACCOUNT=act_…   META_PAGE_ID=…
```

Si algún día hay que rehacer el permanente: **va usuario de sistema EMPLEADO con
los activos asignados uno por uno, NUNCA ADMIN.** Doc oficial: un ADMIN *"puede
acceder a todos los activos pertenecientes al negocio"* y Meta agrega *"no
recomendamos administrar los activos del negocio a través de un usuario
administrador del sistema"*. La ruta es `POST /{system-user-id}/access_tokens`
(sin prefijo de negocio) y pide `appsecret_proof` — en una operación real varios
intentos fallaron justamente por no mandarlo.

**El token no se exporta a mano**: sale del Llavero de macOS. Si faltara, no le
pidas al dueño "el token del usuario de sistema" — mandalo al comando que lo fabrica:

```bash
python3 ~/herramientas/meta_ads.py conectar --app-id <ID de la app>
```

Le pide el secreto y el token corto **por pantalla** (no por argumento: quedarían
en el historial). Con `--negocio <ID>` saca uno que no vence. Standard Access
alcanza para cuentas propias: **no hace falta App Review ni verificación de
negocio** (doc de Meta).

Lo único que el dueño tiene que hacer a mano son dos pantallas: crear la app en
`developers.facebook.com/apps` (Configuración → Básica trae el ID y el secreto) y
sacar un token en `developers.facebook.com/tools/explorer` con los permisos
`ads_management`, `ads_read` y —si quiere el permanente— `business_management`.

Nunca manejar el navegador logueado para suplir el token — esa es la vía que hace
que Meta marque la cuenta (ver *La línea roja*, abajo).

## Las guardas duras

No se negocian. Por el script están en el código. **Por el conector ahora también
hay código**: el hook `hook-freno-meta.py` corre antes de cada llamada `ads_*`, lee
el mismo freno, espacia con la misma cola y anota en el mismo libro. Si el freno
está puesto, **deniega la llamada** — no depende de que vos te acuerdes.

Lo que el hook NO cubre y sigue siendo tuyo:

- **Simulacro** → no existe por el conector. Escribí en el chat exactamente qué vas
  a crear (campaña, conjunto, cada anuncio con su creativo) y recién después llamá.
- **Salud primero** → antes de escribir, una lectura (`ads_get_ad_accounts` o
  `ads_get_ad_entities`).
- **Escribir el freno cuando te frenan a vos.** El hook lo *lee*; si el conector te
  devuelve un código de freno, escribilo con
  `python3 ~/herramientas/meta_ads.py salud`. Leer y no escribir es media
  compuerta: sirve cuando el que se pasa es otro, no cuando sos vos. Una
  herramienta que lee el freno pero no lo escribe puede encadenar códigos 17
  justo por eso.
- **Todo nace pausado** → `ads_create_campaign`, `ads_create_ad_set` y
  `ads_create_ad` crean en PAUSED por diseño del propio conector. No lo revierta
  nadie con `ads_update_entity` sin OK explícito del dueño en este turno.
- **Techo de escrituras**: el hook corta a las 25 por hora. Si te frena ahí, no
  busques rodeos — escaloná en otra sesión.

1. **Chequeo de salud primero, siempre.** `salud` antes de cualquier operación.
   Si hay enfriamiento activo, no se llama a nada.
2. **Simulacro antes que real.** Toda tanda corre primero con `--simulacro`, que
   muestra exactamente qué escribiría sin escribir nada. El modo real recién
   cuando la corrida en seco se ve bien.
3. **Todo nace PAUSADO.** Anuncios, conjuntos y campañas. Sin excepción.
   **Prender es decisión humana, en el Administrador de Anuncios.**
4. **Prender o subir un presupuesto exige `--confirmar`**, y ese `--confirmar`
   solo se pone cuando el dueño lo dijo *en este turno*. Un "dale" de hace tres
   mensajes sobre otra cosa no lo autoriza.
5. **NADA que cambie el estado de una campaña se hace sin orden del dueño.**
   Presupuesto —ni arriba ni abajo— y **pausar** también: subir, bajar o pausar
   siempre se pregunta.
   Ojo con la tentación de deducir lo contrario ("frenar gasto es reversible, no
   hace falta preguntar"): es un razonamiento del agente, no un criterio del dueño,
   y contradice las reglas duras 11 y 14 de CLAUDE.md.
   Lo hace cumplir el código (`presupuesto` exige `--confirmar`) y, por afuera y
   sin compartir código con él, el hook `hook-plata-pide-confirmar.py`.
6. **Avisá qué vas a crear o cambiar antes de hacerlo**, en una línea. Y al
   arrancar un armado decí de entrada qué va a tener que terminar él a mano
   (ver *Lo que la API no toca*), para que no lo descubra a mitad de camino.

## Nunca reintentar ante un freno

Esto mató una app en una operación real: `code 200 · API access blocked`,
no por hacer algo prohibido sino **por velocidad y por reintentar en bucle**. La
doc de Meta lo dice textual: *"If you reach the limit, stop making API calls. If
you continue making calls, the call count won't stop increasing."*

El cliente ya lo implementa y no hay que pensarlo: ante un código de freno
(4, 17, 32, 613, 80000-80014) escribe un **archivo de enfriamiento en disco** que
hasta un proceso nuevo respeta, y aborta. **Si ves un FRENO: no busques rodeos, no
regeneres el token, no cambies de cuenta.** Avisale al dueño y esperá.

## Los dos sistemas de riesgo

El rate limit y **otro separado que vigila el patrón de la cuenta publicitaria**:
30+ cambios de presupuesto en una hora, ediciones masivas en minutos, pausar y
reactivar muchas cosas de golpe. Salta **aunque la vía sea 100% oficial**, porque
mira el comportamiento, no la legitimidad de la app.

### El límite es POR CUENTA, y lo comparte todo

Doc oficial, textual: *"Rate limiting is at the ad account level"*, y cada cuenta
mantiene su propio score. Dos consecuencias que casi nadie ve:

- **Ese cupo lo comparte TODO lo que le pegue a esa cuenta**: las tres puertas, cualquier
  panel propio, y el Administrador de Anuncios que el dueño tenga abierto en el
  navegador. Medir solo tu propio tráfico y concluir "estoy muy por debajo del
  techo" **no dice nada del total**. Pasó en una operación real: un panel lo midió
  así y se comió una seguidilla de estrangulamientos.
- **La cuota es el MÁXIMO de tres contadores**, no `call_count`: `call_count`,
  `total_cputime` y `total_time`. Cualquiera que llegue a 100 dispara el freno, así
  que mirar solo `call_count` es la lectura optimista. `meta_ads.py` ya toma el
  máximo de los cinco campos (esos tres + `app_id_util_pct` y `acc_id_util_pct`,
  que son los del header de insights).

### El espaciado sale del TIER, no de un número fijo

| Tier | Lectura | Escritura |
|---|---|---|
| `development_access` | **5 s** | **15 s** |
| `standard_access` / `advanced_access` | 1 s | 6 s |

En `development_access` son 60 puntos por cuenta cada 300 s (lectura 1, escritura
3): 20 escrituras × 3 = 60 = el techo exacto. **Sin dato del tier se asume el más
restrictivo.** El tier real vive en `logs/meta-ads-tier.txt` y lo actualiza solo el
cliente leyendo el header `ads_api_access_tier`.

La cola de espera es **por cuenta publicitaria**, no global: la cuenta B no espera
lo que solo debe la cuenta A.

| Límite | Valor | Se puede levantar |
|---|---|---|
| Cambios de presupuesto por conjunto | **4 por hora** | no, es de la cuenta |
| Cambios de gasto en la cuenta | **10 por día** | no, es de la cuenta |
| `ads_management` por hora (Limited) | 300 + 40 × anuncios activos | sí, Full: 100.000 |
| `ads_insights` por hora (Limited) | 600 + 400 × anuncios activos | sí, Full: 190.000 |
| Puntaje por 300 s (Limited) | 60 · lectura 1, escritura 3 | sí, con Full Access |

**Insights tiene cupo propio**, aparte del de gestión. Es el que quema un reporte
diario de métricas. Y **el cupo crece con los anuncios activos**: la cuenta chica
—justo cuando estás probando— es la que menos margen tiene para equivocarse.

**Consecuencia de diseño, no detalle:** un criterio automático decide **pocas
veces y con convicción** — una pasada a la mañana y una a la tarde, no un lazo
continuo. Cada cambio de presupuesto reinicia el aprendizaje del conjunto.

## El 15 % de error es una condición permanente

El ascenso a Full Access no es automático: cuando el volumen y el error dan, el
dueño lo pide a mano en el panel de la app (Marketing API → Access Tier →
*+Upgrade*). `python3 ~/herramientas/meta_ads.py ascenso` muestra el estado real en
cualquier momento.

**Ojo con la ventana móvil**: si, por ejemplo, de 600 llamadas casi todas son de un
solo día, cuando esas envejezcan el conteo se desploma. La elegibilidad es perecedera — si el `ascenso` dice que el
volumen está, **conviene pedirlo esa misma semana**, no "en algún momento".

Full Access pide ≥500 llamadas en 15 días con **menos de 15 % de error medido
sobre las últimas 500 llamadas**. Dos cosas que cambian cómo se trabaja:

- **Es ventana móvil, no examen.** El error de hoy pesa durante las próximas 500
  llamadas. No hay borrón y cuenta nueva: se gasta caminando.
- **También se aplica para MANTENER el acceso.** Se puede caer para atrás.

15 % de 500 son 75 errores, y **los errores vienen en manada**: un campo mal
escrito sobre 40 creativos son 40 errores en tres segundos. Por eso `cargar-tanda`
**corta sola a los 3 fallos seguidos** — tres seguidos significa que el problema
es la receta, no los archivos.

`salud` te dice en qué porcentaje andás, leyendo el libro contable
(`logs/meta-ads-libro.jsonl`), que anota cada llamada con su resultado.

## Un solo escritor

Si dos procesos llaman a la vez, ninguno sabe cuánto cupo queda de verdad. El
cliente toma un **cerrojo exclusivo** al arrancar: si hay otra corrida en curso,
aborta con `CERROJO:` en vez de sumarse. El ritmo entre llamadas también vive en
disco, no en memoria, así que se comparte entre procesos.

Esto importa más si el dueño trabaja con **varias sesiones de Claude en
simultáneo**. Si ves `CERROJO:`, no lo esquives — esperá.

## El orden real de operaciones

```bash
T=~/herramientas/meta_ads.py

# 0 · SIEMPRE primero
python3 $T salud

# 1 · reconocimiento (barato, lectura = 1 punto)
python3 $T cuentas
python3 $T paginas
python3 $T campanas
python3 $T conjuntos --campana <id>

# 2 · estructura, si hace falta crearla
python3 $T crear-campana --nombre "…" --objetivo OUTCOME_SALES
python3 $T crear-conjunto --nombre "…" --campana <id> --paises AR \
    --diario 15000 --pixel <id> --evento PURCHASE --advantage

# 3 · creativos: la carpeta entera de una — SIEMPRE en seco primero
python3 $T --simulacro cargar-tanda ~/Desktop/creativos-x/ --conjunto <id> \
    --link https://… --texto "…" --titular "…" --cta SHOP_NOW --confirmar
python3 $T cargar-tanda ~/Desktop/creativos-x/ --conjunto <id> \
    --link https://… --texto "…" --titular "…" --cta SHOP_NOW --confirmar

# 4 · lectura de resultados
python3 $T metricas --nivel adset --periodo last_7d
python3 $T metricas --objeto <campaña> --nivel ad --periodo last_14d

# 5 · ajuste
python3 $T presupuesto --conjunto <id> --diario 20000 --confirmar
python3 $T pausar --anuncio <id>
```

`cargar-tanda` toma cada `.mp4`/`.mov` de la carpeta, lo sube por subida
resumible, espera la transcodificación, arma el creativo con la miniatura que
Meta prefiere y crea el anuncio pausado — nombrado con el nombre del archivo, así
el reporte de métricas se lee sin traducir nada. Si uno falla, sigue con el resto
y lista los que fallaron al final.

## Estrategias de puja — LAS ELIGE EL DUEÑO, NUNCA VOS

`crear-conjunto` acepta las cuatro de Meta. **Sin `--puja` no se manda nada** y el
conjunto queda con el default de la cuenta, que es lo correcto por omisión.

| `--puja` | Qué exige | Qué hace |
|---|---|---|
| `LOWEST_COST_WITHOUT_CAP` | nada | el default: gasta todo buscando el menor costo |
| `LOWEST_COST_WITH_BID_CAP` | `--tope <importe>` | techo duro por puja |
| `COST_CAP` | `--tope <importe>` | costo promedio objetivo |
| `LOWEST_COST_WITH_MIN_ROAS` | `--roas-min <n>` | piso de ROAS (ej. `2.5`) |

`--tope` va en moneda normal y el cliente lo pasa a centavos. `--roas-min` se
escala ×10000 para `bid_constraints.roas_average_floor`. Hay 7 guardas que abortan
si la combinación no cierra (tope sin estrategia que lo use, ROAS fuera de rango,
etc.): si una salta, **leé el mensaje, no fuerces**.

El dueño elige en qué campañas y en qué conjuntos se aplica cada estrategia, y
cuándo. Podés **proponer** una estrategia con los números al lado; aplicarla sin
que él la haya nombrado en este turno, no.

## Criterios de partida (los confirma el dueño)

**Cerrados — aplicalos sin preguntar:**
- Los creativos entran **en pausado**, siempre. Él revisa y prende.
- **Un ángulo por conjunto.** No mezclar ángulos en el mismo conjunto: si están
  mezclados no se sabe cuál ángulo funcionó, y el aprendizaje no sirve de nada.
- El nombre del anuncio es el nombre del archivo. Nada de "Anuncio 1".
- Formato: **9:16 a 1080×1920** para Reels y Stories, **4:5 a 1080×1350** como
  master de feed. Si hay uno solo, que sea el 9:16.

**Umbrales de partida** — números orientativos de un operador con experiencia,
para producto low ticket. Si el dueño ya tiene los suyos en el vault, mandan los
suyos:

| Umbral | Valor | Nota |
|---|---|---|
| Costo por agregado al carrito | **1-3 USD** | por ejemplo, para un producto de ~15 USD |
| Costo por pago iniciado | **4-7 USD** | mismo ejemplo |
| ROAS de equilibrio | **1/margen** | por ejemplo, con 8% de comisión da ~1,09 |
| ROAS piso de ganancia | **2** | **no** es el equilibrio, es piso con colchón |
| El CTR | **fuera de la decisión** | hay campañas con CTR bajo que igual dejan mucha ganancia |

**Las dos advertencias van pegadas a los números, no son opcionales:**

1. **Son de terceros, no del dueño.** Sirven de **punto de partida**, no de
   veredicto. El canon es comparar contra **los ganadores propios de la cuenta**,
   no contra estándares externos. Sin histórico propio, 1-3 y 4-7 se usan igual.
2. **Para escalar se usa el ROAS MARGINAL**, no el mezclado:
   `(ingreso2 - ingreso1) / (gasto2 - gasto1)` entre dos períodos estables. El
   mezclado siempre exagera. Y Meta pide *"promedios semanales en lugar de
   resultados diarios"* con un rango que capture **50-100 conversiones**.

**Lo que suele faltar es volumen propio.** Si tenés, por ejemplo, 30 ventas
en una semana repartidas en 70 conjuntos, con apenas un puñado de conjuntos
con n≥3, con eso no se construye el umbral de la cuenta, sea cual sea el
criterio. No es "definir umbrales": es "todavía no hay con qué".

**Regla de pausa de un operador con experiencia, para proponer — no para aplicar
sola:** un conjunto se corta a las **48 h sin venta**, o cuando el **CPA triplica
el objetivo**. Ni antes (no le diste chance al algoritmo) ni después (regalás
plata). No es criterio del dueño: sirve como propuesta con números al lado, y se
convierte en automática recién cuando él la haga suya.

Si te piden una decisión automática que dependa de un umbral que no está cerrado:
**calculá y mostrá los números, proponé el umbral, y pará ahí.** No lo fijes vos.
El precio y los umbrales son decisiones de negocio del dueño.

## Lo que la API no toca (y termina a mano)

Decilo **al arrancar** el armado, no al final:

| Qué | Quién |
|---|---|
| Anuncios multianunciante | el dueño, en la interfaz, en lote |
| Mejoras automáticas de creativo | el dueño, editor múltiple (no alcanza a carruseles) |
| Versión por ubicación (editar el 9:16 aparte) | el dueño, o se acepta el recorte |
| Identidad de Instagram | suele autocompletarse con la cuenta de la página — verificar |

**Los creativos son inmutables.** No existe "cambiarle el CTA" o "el link" a un
creativo ya creado: cualquier cambio es creativo nuevo + anuncio nuevo. Por eso
la corrida en simulacro importa: el copy y el link se revisan **antes**.

Sobre las mejoras automáticas: **verificado en una cuenta real**.
`standard_enhancements` es **asimétrico** y esa es la trampa: Meta lo **devuelve al
leer** un creativo viejo, pero **lo rechaza al crear** uno nuevo con
`error 100 / 3858504`. O sea, clonar un creativo existente copiando su
`degrees_of_freedom_spec` tal cual **falla siempre**.

Por eso `clonar-conjunto.py` filtra la clave antes de mandar:

```python
OBSOLETAS = {"standard_enhancements"}
cfs = {k: v for k, v in (dof.get("creative_features_spec") or {}).items()
       if k not in OBSOLETAS}
```

Si aparece otro campo que se lee pero no se escribe, va a esa misma lista. Los
toggles por función los sigue apagando el dueño a mano en el primer anuncio, y se
duplica desde ese.

## Nombres: no invitar a una categoría restringida

Palabras sensibles (religión, salud, política, dinero) en nombres de campaña,
conjunto, anuncio o producto pueden ponerle una **categoría restringida al píxel
de la cuenta**, con semanas de límite. Puede pasar, por ejemplo, con ciertas palabras
sensibles en los nombres.
El nombre del anuncio sale del nombre del archivo: si un archivo trae una palabra
así, **avisá antes de cargar la tanda**, no después.

## Leer las métricas sin engañarse

`metricas` devuelve gasto, impresiones, CTR, CPM, compras, CPA y ROAS.

- **Menos de ~50 resultados en la ventana, no concluyas nada.** Un CPA de dos
  compras es ruido.
- ROAS 0.00 con gasto alto suele ser **el píxel**, no el creativo. Antes de
  declarar muerta una campaña, chequeá que el evento esté llegando.
- Compará **al mismo período**: `last_7d` contra `last_7d`, nunca contra `today`.
- **Meta solo no decide nada.** Puede sub o sobrereportar ventas ~50 %. Toda
  decisión de plata se cruza con lo cobrado de verdad en Shopify, casando por
  `utm_id` campaña por campaña. Herramienta al lado: `~/herramientas/shopify.py`.
- Cerrá la aritmética antes de acusar a la plataforma: `gasto × ROAS = valor`.
  Si un número no cierra, el error casi siempre está en cómo se midió.
- **Meta corta el día en el huso de la cuenta, no en UTC.** Si el tablero usa
  otro huso, el gasto de la noche cae en el renglón equivocado. Y el reloj de la
  computadora no es el huso de la cuenta (por ejemplo, si el dueño está de viaje).
- En **CBO se juzga la campaña entera**; no pausar conjuntos sueltos, que el
  algoritmo ya reparte el gasto. En ABO sí se evalúa conjunto por conjunto.
- Ventanas grandes o desgloses pesados → endpoint asíncrono (`POST /insights`
  devuelve un `report_run_id` que vive 30 días; se consulta el avance). Tarda,
  pero no quema cupo. Con `--desglose`, fijá el período a mano: `date_preset`
  amplio arrastra historial e infla todo.

**Cómo no gastar el cupo al pedo** — todo esto sale de las buenas prácticas
oficiales y baja el riesgo de freno:

- Las métricas se actualizan cada 15 min y **ya no cambian después de 28 días**.
  Lo viejo se guarda y no se vuelve a pedir: pedir dos veces el mismo dato de
  hace un mes es regalar cupo.
- **Nunca una llamada por anuncio dentro de un bucle.** Primero los IDs a nivel
  cuenta, después las métricas por ID en tanda. `metricas --nivel ad` ya hace
  una sola llamada para todos.
- Preferir `date_preset` antes que rangos de fecha armados a mano.
- Nada de desgloses pesados a nivel cuenta: `action_target_id` y compañía son
  los que más cuestan.
- Espaciar las consultas a lo largo del día, no dispararlas todas juntas a las
  nueve de la mañana.

## La línea roja

Los términos de Meta separan **automatizar por la API** (permitido, es para lo que
existe) de **automatizar manejando el navegador logueado** (prohibido, dispara
suspensiones). Todo lo de esta skill es lo primero.

`ojos.py` y `espia_fb.py` manejan Chrome por CDP. Sobre la **Biblioteca de
Anuncios**, que es pública, está bien. **Nunca apuntarlos al Administrador de
Anuncios logueado.**

## Cuando algo falla

Los errores de Meta salen ya legibles (`[código/subcódigo] mensaje`). Los que vas
a ver:

| Código | Qué pasa | Qué hacer |
|---|---|---|
| 4, 17, 32, 613, 80000-80014 | freno de Meta | **parada dura**, ya queda el enfriamiento en disco. No reintentar |
| **200** | **API access blocked: la APP quedó bloqueada** | la cuenta suele estar viva; verificarlo contra la API antes de asustarse. App nueva (son descartables) y **borrar el token muerto del entorno** |
| 190 / 464 | checkpoint del Facebook personal | entrar a Facebook y confirmar la cuenta |
| 190 / 465 | la app no pertenece al negocio del usuario de sistema | configuración: conectar la app en Business Settings → Apps |
| 190 (otro) | token vencido o revocado | avisarle al dueño; regenerar el del usuario de sistema |
| 10 | falta un permiso en el token | regenerar con los scopes correctos |
| 100 | parámetro mal | leer `error_user_msg`, suele decir cuál |
| 352 / 382 | formato o tamaño de video | reencodear a MP4 H.264, mínimo 1080p |
| 1487xxx | política de anuncios | es el contenido, no la herramienta |

**Token muerto = token que se borra del entorno.** En una operación real
dejaron los tokens de la app bloqueada "de registro histórico" y un script de
diagnóstico los leyó y les disparó llamadas — cada llamada de una app bloqueada
suma señal negativa sobre la cuenta. El historial va a una nota, nunca donde un
script lo pueda encontrar.

**Las apps son descartables; la cuenta publicitaria no.** Todo este protocolo
protege la cuenta, no la app.

Nunca escondas un fallo parcial: si de 15 creativos entraron 12, decí cuáles tres
no y por qué.
