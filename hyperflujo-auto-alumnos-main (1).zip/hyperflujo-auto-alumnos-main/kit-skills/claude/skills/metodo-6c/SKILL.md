---
name: metodo-6c
description: El método 6C. Produce VSL y anuncios con una persona de IA que habla a cámara y pasa por real (foto base hecha en ChatGPT, cara que habla con Omni por ApiMart, montaje en toma continua, subtítulo de una palabra, verificación con la vara humana y revisor obligatorio). Usar cuando el alumno diga /metodo-6c, "método 6C", "hacé un VSL con la persona", "quiero un video con una persona de IA que hable", "hacé hablar a la persona", "anuncio con cara que habla", "VSL de post-compra con cara", o cuando una oferta necesite un video con alguien hablando a cámara. Nunca gasta saldo de ApiMart sin un sí explícito del alumno y nunca entrega un video sin la revisión.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# El método 6C: una persona de IA que habla a cámara y pasa por real

Las **6C** son los seis bloques del prompt de la foto base: **C1 personaje · C2 cámara · C3 ropa · C4 lugar ·
C5 luz · C6 anclas** (los detalles chicos que una IA no pondría sola: un reloj gastado, un mechón suelto, un anillo
fino). De esa foto sale todo el realismo; por eso el método entero lleva ese nombre, desde la foto hasta la revisión.

Cada regla de este archivo salió de un error que ya se pagó. Seguí el orden y no saltees mediciones: así no los
volvés a pagar vos.

## Cómo le hablás al alumno

- En español simple, sin jerga. Si un término técnico hace falta, explicalo en media línea.
- **Nunca gastes saldo sin un sí.** Antes de cada corrida de `vsl_cadena.py` decí cuántos clips se van a generar y
  cuánto cuesta más o menos (ver «Costos»), y esperá que el alumno diga que sí. Todo lo demás (montaje, mediciones,
  revisión) es gratis y lo hacés sin preguntar.
- Al alumno solo le mostrás un video que el revisor dio por **APROBADO** (o un RECHAZADO que solo se arregla
  regenerando, con el costo de regenerar).

## Dónde está todo

| Qué | Dónde |
|---|---|
| El método (scripts, Remotion, modelos, Python propio) | `~/herramientas/metodo-6c/` (llega con el cerebro y con cada `/actualizar`) |
| Lanzador de scripts | `~/herramientas/metodo-6c/6c.py` (abajo: `$M6`) |
| Plantillas | `~/herramientas/metodo-6c/plantillas/` |
| Ejemplo completo en castellano | `~/herramientas/metodo-6c/ejemplo/` |
| Proyectos del alumno | `~/herramientas/metodo-6c/proyectos/<nombre>/` |
| Clave de ApiMart | `APIMART_KEY=` en `~/herramientas/.env` (la carga el alumno; nunca la muestres, pidas ni copies) |
| Revisor | instrucciones en `~/herramientas/metodo-6c/revisor.md` |

Antes de cada comando: **Mac** `M6="python3 $HOME/herramientas/metodo-6c/6c.py"` · **Windows** `M6="py -3 $HOME/herramientas/metodo-6c/6c.py"`
(si en Windows `py` no existe, `python`). El lanzador corre cada script con el Python propio del método, igual en los
dos sistemas: `$M6 vsl_cadena.py <carpeta>`, `$M6 revision_humana.py <video> --carpeta <carpeta>`, etc.

### Paso 0 · Preparar la computadora (solo la primera vez; lo hacés vos, sin pedirle nada al alumno)

Mirá `~/herramientas/metodo-6c/.preparado.json`. Si no existe o no dice `"listo": true`, corré
**Mac** `python3 ~/herramientas/metodo-6c/preparar.py` · **Windows** `py -3 ~/herramientas/metodo-6c/preparar.py`
(con un tiempo de espera largo: la primera vez baja Python 3.12, las librerías, ffmpeg, node, Remotion y unos 2 GB
de modelos; son 5 a 20 minutos según la conexión). Avisale al alumno que en Windows puede aparecer un cartel pidiendo
permiso para instalar node o ffmpeg: que acepte. Lo único que hace el alumno a mano es la clave: si `preparar.py`
dice que falta, pedile que abra `~/herramientas/.env` y complete `APIMART_KEY=su-clave` (la saca en apimart.ai →
API keys). **Nunca le pidas que la pegue en el chat.** Después volvé a correr `preparar.py` hasta que diga «Listo».

**Herramientas:** la foto base sale de **ChatGPT** (lo hace el alumno a mano en chatgpt.com, con su plan Plus); la
cara que habla, del modelo **Omni** (`gemini-omni-1.1-flash-ext`) por **ApiMart**, en 1080p vertical 9:16; el
montaje, la voz, el color y el subtítulo los arman los scripts con ffmpeg y Remotion. ApiMart no recibe archivos:
`apimart.py` sube cada imagen solo al depósito oficial de ApiMart (`POST /v1/uploads/images`) y usa la dirección
que devuelve, que dura 72 horas (`vsl_cadena.py` la renueva sola).

## La carpeta de un proyecto

```
~/herramientas/metodo-6c/proyectos/<nombre>/
  base.jpg       la foto base (1080x1920)
  persona.txt    cómo es la persona y el lugar (un párrafo en inglés, igual en cada clip)
  voz.txt        cómo habla (una línea en inglés)
  idioma.json    idioma del video (es, pt, en: hay plantillas)
  cola.txt       qué hace al terminar cada frase (ya viene escrita: no se toca)
  guion.json     el guion partido en clips de 8 s
```

Para arrancar uno: creá `~/herramientas/metodo-6c/proyectos/<nombre>` y copiá ahí `persona.txt`, `voz.txt`, `cola.txt` e
`idioma.json` desde `plantillas/` (para portugués o inglés, copiá `idioma-pt.json` o `idioma-en.json` **con el nombre**
`idioma.json`). Mirá `~/herramientas/metodo-6c/ejemplo/` para ver todo completo.

## El proceso (en este orden; no se avanza si la medición no pasa)

### Paso 1 · La foto base (la hace el alumno en ChatGPT)

1. Completá con el alumno `plantillas/foto-base.txt` (persona, lugar, oficio, ropa, objetos). El prompt va en
   inglés porque lo lee el generador. El ejemplo lleno está en `ejemplo/prompt-base.txt`.
2. El alumno lo pega en chatgpt.com, pide la imagen **vertical 9:16**, la mira al 100 % y la baja. Que haga 2 o 3 y
   elija la más «filmada con el celular» (si parece de catálogo, se rehace: no se anima).
3. Pasala a 1080x1920 en la carpeta del proyecto: `$M6 foto_base.py <foto bajada> <carpeta>` (deja `base.jpg`).
4. Medila: `$M6 aceptar_caras.py --caras base.jpg` → inclinación de cabeza menor a 5°.
   Mirala vos también (Read de la imagen): dientes marfil (no blancos parejos), piel con poros, cinco dedos, nada
   escrito en los objetos, ninguna cámara, celular ni trípode a la vista, y **fondo visible arriba y a los costados de
   la cabeza** (el montaje iguala el color midiendo ese fondo).

Lo que NO se hace con la foto: pegar pedazos de dos imágenes (queda una costura en las manos) ni «expandirla» con IA
(rearma la escena y cambia la cara). Si sale muy abierta, se **recorta**; si sale mal, se pide otra.

### Paso 2 · Persona, voz, idioma y cola

- `persona.txt`: un párrafo en inglés con la misma persona, ropa y lugar de la foto (C1 a C6), igual en cada clip.
  **La persona es una mujer:** las partes fijas del prompt de cada clip están escritas en femenino («She says…»,
  «Her hands…»). Un hombre no está probado: no lo prometas.
- `voz.txt`: completá solo lo que está entre corchetes. **No cambies «roughly 2.7 words per second» ni el resto**.
- `idioma.json`: el de la plantilla de su idioma (el acento se puede ajustar al país).
- `cola.txt`: ya viene escrita y medida. No se toca.
- `vsl_cadena.py` se frena antes de gastar si queda algún `[corchete]` sin completar.

### Paso 3 · El guion en clips de 8 segundos

`guion.json` = `{"tramos": [[clip, clip, ...], [clip, ...]]}`; cada clip:
`{"escrito": "lo que se lee en pantalla", "dicho": "lo que dice", "duracion": 8}`
(ejemplo: `plantillas/guion-ejemplo.json`). Reglas:
- **16 a 20 palabras por clip**, cortando donde una persona haría una pausa (fin de oración). `duracion` 8; 6 si la
  frase es corta; 4 solo para la última frase corta.
- **Números en letras en `dicho`** («treinta y nueve dólares») y en cifras en `escrito` («39 dólares»).
- **Un minuto = 2 tramos de 5 a 7 clips.** Los tramos se generan en paralelo y cada uno arranca en la foto base.
- **`"reanclar": true` cada 3 clips: en el 4 y en el 7 de cada tramo.** Más lejos de la foto base, la cara se aleja tanto que el control la descarta y se pagan intentos de más.
- Si un clip necesita algo especial (por ejemplo, manos quietas), va en `"extra"`:
  `"extra": "her hands rest still and relaxed on the table, no hand gestures"`.

### Paso 4 · Generar (esto cuesta saldo: pedí el sí antes)

1. **Primero un solo clip** para ver voz, cara y acento por el precio de un clip:
   `$M6 vsl_cadena.py <carpeta> --solo-tramo 0 --max-clips 1 --corte-extra 0.06`
   Mostrale al alumno `clips/t0-c01.mp4` (Mac: `open <archivo>` · Windows: `start "" "<archivo>"`). Si la voz o el acento no son lo que quiere, se cambia `voz.txt` o
   `idioma.json` acá, cuando sale barato.
2. **Todo el video:** `$M6 vsl_cadena.py <carpeta> --corte-extra 0.06`
   Lo que ya está bajado no se vuelve a pagar (queda anotado en `clips/estado.json`). Cada clip se controla solo: que
   diga la frase palabra por palabra (transcripción literal) y que sea la misma persona (parecido con la base ≥ 0,65
   al principio, al medio y al final). Si falla, lo regenera una vez y, si la frase no entró, una vez más con 2 s más.
3. Si un clip queda «FALLÓ», mirá en `clips/estado.json` por qué (ver «El filtro de contenido» en las reglas).

### Paso 5 · La línea de tiempo (sin video de referencia: el caso normal)

`$M6 ritmo_natural.py <carpeta>` → escribe `ritmo.json` y devuelve el `total` en segundos.
Acelera la voz pareja hasta unas 160 palabras por minuto (lo de una persona que vende hablando natural; Omni habla
más lento) y pone los clips uno detrás del otro con una pausa corta. Nunca acelera más de ×1,35: más se nota.

### Paso 6 · El montaje

```
$M6 montar_warp.py <carpeta> --ref-json <carpeta>/ritmo.json --total <total> --cada 2 \
   --enfoque 0.12 --grano 0.6 --audio-limpio --nr 10 --brillo-voz 4 --lufs -13.2 --retraso-audio 0.04
```
Sale `<carpeta>/final.mp4` (tarda varios minutos; es gratis y se puede repetir las veces que haga falta).
Hace todo esto solo: toma continua (cada clip arranca en el último cuadro del anterior), tiempo deformado por anclas
para un ritmo parejo, cuadros intermedios por flujo óptico donde va más lento (nunca repite cuadros), color igualado
clip por clip, pase suave a la foto base en los reanclajes, audio sin cortes ni golpes, volumen y el subtítulo de una
palabra (Poppins 800, 89 px, borde negro, al 74,4 % del alto).

Ajustes que se suman solo si la revisión los pide (ver «Arreglos según la revisión»):
`--dientes-hacia L a b`, `--labios-hacia L a b`, `--lut color.cube`, `--zoom Z X Y --zoom-destino X Y`.

### Paso 7 · Verificar (gratis, siempre)

1. **La vara humana:** `$M6 revision_humana.py <carpeta>/final.mp4 --carpeta <carpeta>`
   Compara 16 medidas contra un video real de una persona filmada con el celular (cuadros repetidos, saltos,
   parpadeo, boca, sonrisa, cabeza, piel, nitidez, ritmo, volumen, ruido, brillo de voz, saltos de color y, si está
   instalado, SyncNet) y deja imágenes en `<carpeta>/revision/` (empalmes, boca de cerca y una hoja de 12 cuadros).
   **Esta es la medida principal** cuando no hay video de referencia. «NO MEDIDO» en SyncNet es normal: es opcional.
2. **El texto:** `$M6 transcribir_literal.py <carpeta>/final.mp4 --idioma <es|pt|en> --guion "<todo el escrito>"`
   → «coincide palabra por palabra» (una palabra comida, agregada o repetida no pasa).

### Paso 8 · El revisor (obligatorio)

Lanzá un agente (subagente de uso general) con estas instrucciones: «Leé ~/herramientas/metodo-6c/revisor.md y
seguilo al pie de la letra» + el video final, la carpeta del proyecto y el idioma. Él mide, abre las imágenes
y devuelve **APROBADO** o **RECHAZADO** con los arreglos. Si dice RECHAZADO: se arregla (primero lo gratis: montaje)
y se vuelve a revisar. Recién con APROBADO se lo mostrás al alumno (Mac `open`, Windows `start ""`) junto con el dictamen.

## En Windows

Todo lo de arriba funciona igual. Lo único distinto:
- `py -3` en lugar de `python3` (si no existe, `python`), y `start "" "<archivo>"` en lugar de `open`.
- Si la carpeta de usuario tiene acentos o eñes (C:\Users\Agustín), el método ya lo resuelve solo
  (`scripts/compat.py`): no muevas nada.
- La primera vez que se monta, Remotion baja su propio navegador para dibujar el subtítulo (unos 100 MB).
- Si `preparar.py` dice que falta ffmpeg o node y no pudo instalarlos solo, los comandos son
  `winget install -e --id Gyan.FFmpeg` y `winget install -e --id OpenJS.NodeJS.LTS`; después se cierra y se vuelve a
  abrir Claude Code (para que vea el PATH nuevo) y se corre `preparar.py` otra vez.

## Opcional: copiar el ritmo de un video tuyo de referencia

Si el alumno tiene un video propio (filmado por él o con permiso) cuyo ritmo quiere copiar palabra por palabra:
1. `$M6 transcribir_literal.py ref.mp4 --idioma es --json <carpeta>/ref.json` (tiempos por palabra).
2. El guion tiene que tener **las mismas palabras** que la referencia, en el mismo orden, cortadas en sus pausas
   largas; a cada clip le podés anotar `"ref_ini"` y `"ref_fin"` (segundos de su frase en la referencia).
3. Montaje: igual que el paso 6 pero con `--ref-json <carpeta>/ref.json --total <duración de la referencia>`.
4. Color: `$M6 hacer_lut.py --nuestro <carpeta>/montaje/crudo.mov --referencia ref.mp4 --histograma --salida color.cube`
   y volver a montar con `--lut color.cube`.
5. Comparación: `$M6 comparar_clon.py ref.mp4 <carpeta>/final.mp4 --json comparacion.json` (45 medidas, cada
   una IGUAL o DISTINTO, con la sincronía de palabras). Se itera el montaje (gratis) hasta que solo queden distintas
   las que vienen de la generación. Igual se corre la vara humana y el revisor.

`montar_sincro.py` es la versión anterior (cada clip empieza en su `ref_ini`); `montar_warp.py` la reemplaza.

## Las reglas que salieron caras (error → cómo se ve → qué lo evita)

**Foto base y prompt**
- **Nombrar el trípode o el celular.** → Omni dibuja un trípode negro con un celular en el borde del cuadro. → En
  ningún prompt se dice «on a tripod» ni «the phone is fixed»: solo «fixed camera at eye level (not a selfie)» y «No
  tripod, no phone and no camera anywhere in the frame» (ya está así en los scripts y en las plantillas).
- **Dientes blancos de la IA.** → Dientes blancos parejos tipo carillas: se ve falso en el primer segundo. → La foto
  base se pide con dientes marfil («slightly ivory/off-white with soft shadows between them; NOT bright white, NOT
  veneers»). Una base con buenos dientes ya trae el video casi bien.
- **Cabeza ocupando todo el ancho.** → El montaje no encuentra fondo para medir el color, el eslabón sale azul y Omni
  inventa otra persona. → En la foto base la cámara un poco lejos (cabeza ~23 % del alto) y fondo visible.
- **Componer o expandir la foto.** → Costura en las manos, o una escena y una cara distintas. → Recortar o pedir otra.

**Guion y generación**
- **Una frase corta por clip (clips de 4 s).** → Muchos empalmes: en cada uno la boca cierra y sonríe (se ve un
  «reinicio» en medio de una oración), el tono de la piel y del pelo salta, y la cara se aleja de la original. →
  Clips de 8 s con 16-20 palabras, cortados en las pausas naturales.
- **Cola con sonrisa.** → Si la persona termina cada frase sonriendo, ese cuadro es el primero del clip siguiente:
  una sonrisa en cada empalme y la persona habla sonriendo de más. → `cola.txt` (pausa relajada entre dos frases,
  sin sonrisa, mirando a cámara) y `--corte-extra 0.06`. Medido: la sonrisa en los empalmes bajó a la mitad.
- **La cara se aleja en cada eslabón.** → Cada clip que arranca en el último cuadro del anterior se parece un poco
  menos: al tercero la cara se oscurece y envejece. → `"reanclar": true` en el clip 4 y en el 7 de cada tramo (vuelve a
  arrancar en la foto base); el montaje hace ahí un pase por flujo óptico de 8 cuadros, sin cara doble.
- **Pedir la voz «rápida».** → Pedirle «FAST, lively, 3 words per second» o «articular cada sílaba» desincroniza la
  boca y la abre de más: se ve IA. → La línea de voz tal cual («roughly 2.7 words per second»); la velocidad se gana
  en el montaje (`ritmo_natural.py`), no en la voz.
- **El filtro de contenido.** → Una frase queda frenada (sin cobrar) dos veces seguidas. → No se reintenta igual: se
  parte en dos clips o se reescribe. La frase que frena va sola.
- **Clip con otra persona.** → La transcripción da bien pero la cara es otra. → Ya está resuelto: cada clip se mide
  contra la base al principio, medio y final; con parecido menor a 0,65 se descarta.
- **Manos raras.** → Una mano deformada en un clip. → Regenerar ese clip con `"extra"` de manos quietas (ver
  «Regenerar un clip suelto», abajo).
- **Regenerar un clip suelto.** → Si regenerás un clip del medio y dejás los que siguen, el siguiente arranca en un
  cuadro que ya no existe: salto de pose en el empalme. → Borrá en `clips/estado.json` la entrada de ese clip **y la
  de los que le siguen en su tramo hasta el próximo `reanclar`** (cada uno arranca en el último cuadro del anterior) y
  volvé a correr `vsl_cadena.py`: lo demás no se repaga. Decile al alumno cuántos clips son antes.

**Montaje**
- **Duplicar cuadros para pasar de 24 a 30.** → La boca va «a saltitos». → El montaje genera cuadros intermedios por
  flujo óptico; la vara humana mide `repetidos_%` (tiene que dar menos de 2).
- **Fundir dos poses.** → «Cara doble» o fantasma en el pase a la foto base. → Pase por flujo óptico (morph), no
  fundido; y arranca en un cuadro con los **ojos abiertos** (si arranca en un parpadeo, aparecen ojos grises
  fantasma). Lo hace solo.
- **Estirar la cola antes de un reanclaje.** → Parpadeos y ruidos raros de Omni. → Máximo +0,35 s (ya está así).
- **Audio de los empalmes.** → Cortes secos, ceros absolutos que se oyen con auriculares, o un golpe de boca antes de
  la primera palabra (se oye una sílaba de más). → Fundidos de 15 ms, cola apagada después del corte, tono de
  ambiente continuo debajo de todo y arranque limpio. Todo automático: no pongas `--ambiente 0`.
- **Subtítulo armado con lo que oye Whisper.** → «$39» se come «dólares» y la palabra nunca aparece en pantalla. →
  El subtítulo sale de tu guion ESCRITO con los tiempos de la transcripción (automático): dice siempre tu texto.
- **Golpe de boca o cola cortada en un empalme.** → Una sílaba de más («eh») entre dos oraciones, o la última palabra
  cortada. → El montaje limpia el arranque de todos los clips y busca el fin real de la voz por energía (automático).
- **La última palabra de un clip pisada por el siguiente.** → «un solo pago» se oye «un solo pa». → Ya está resuelto:
  el audio se corta de una copia sin comprimir de cada clip y la línea de tiempo deja una pausa más larga antes de cada
  vuelta a la foto base. Si lo ves igual, revisá que no hayas editado los clips en otro programa.
- **Cara congelada, franja gris, salto de imagen o «grietas» en las manos en un pase.** → Ya está resuelto en el
  montaje (duración real de cada clip, bordes repetidos, el fondo se alinea antes de volver a la foto base, las manos
  no se mezclan). La vara humana marca `cara_quieta_con_voz` y `borde_oscuro_en_pase`; las manos de cada pase igual se
  miran a tamaño real.
- **Audio que se corre.** → Recortar el audio por partes en AAC pierde milésimas en cada empalme y al final la voz
  va atrasada de la boca. → Las partes van en audio sin comprimir con el largo exacto del video; AAC una sola vez al
  final. No edites los clips en otro programa antes del montaje.
- **Enfoque fuerte o grano de más.** → Cara blanda, o un fondo que «hierve». → `--enfoque 0.12` (subir hasta 0,4 si
  la nitidez da baja) y `--grano 0.6`.
- **Color igualado una sola vez para todo.** → Saltos de tono en los empalmes. → El montaje iguala el color clip por
  clip antes de cualquier LUT; la vara humana cuenta los `saltos_de_color`.
- **Sincronía de labios.** → Con el audio un poco adelantado, la boca parece doblada. → `--retraso-audio 0.04`.
  Si el alumno instaló SyncNet (opcional), tiene que dar desfase ≤ 1 cuadro y confianza ≥ 6.
- **Volumen.** → Remotion baja ~0,8 dB al final. → `--lufs -13.2` deja el final en −14 (lo que normalizan las redes).

**Color y boca (solo si la revisión lo marca)**
- **Corregir los dientes con un ajuste general.** → Se blanquea también la ropa clara y todo se ve lavado. →
  Dientes SOLO dentro de la boca: `--dientes-hacia 155 141 143` (marfil medido en un video real; escala LAB de
  OpenCV). Medí antes con `$M6 dientes.py <video>`: muchas veces el crudo ya está bien y la corrección lo arruina.
- **LUT por media y desvío.** → Quema dientes y blancos. → `hacer_lut.py --histograma`. La LUT general deja la piel
  pálida: corrección aparte de piel con `--piel` (medí con `$M6 piel.py`). Las luces altas sin tinte celeste:
  `--altas` y `--altas-tinte`.
- **Calibrar la LUT contra una prueba.** → El acabado y Remotion apagan las luces altas y corren la piel: lo que daba
  bien en la prueba sale distinto al final. → Se mide sobre el `final.mp4` y se corrige por la diferencia; dos vueltas
  bastan. Cada tanda nueva de clips pide su LUT.

**Medición**
- **Transcribir sin decir el idioma.** → Whisper cambia de idioma a mitad del video e inventa texto (parece un
  desastre de audio y no lo es). → Siempre `--idioma` o `idioma.json` en la carpeta.
- **Creerle a Whisper con los precios.** → Escribe «$39» y se come «dólares»: la verificación marca una palabra que
  falta y no falta. → Antes de regenerar, medí la energía de ese segundo o escuchalo: si hay habla continua, la
  palabra está. Lo mismo con cualquier número con moneda.
- **Medir textura y nitidez contra la cara de otra persona.** → Fallas falsas: cada cara tiene su textura y su
  sonrisa. → `revision_humana.py --carpeta` mide textura y nitidez contra la `base.jpg` de tu persona (el video no
  puede quedar más liso ni más blando que su foto) y la sonrisa solo falla si es de más.
- **Confiar en un solo número.** → Un promedio no ve un reinicio de boca ni una cara doble. → Siempre las imágenes de
  `revision/` (el revisor las abre una por una).

## Arreglos según la revisión

| La vara humana marca | Qué se ve | Arreglo (gratis salvo que diga lo contrario) |
|---|---|---|
| `repetidos_%` alto | boca a saltitos | volver a montar con `montar_warp.py` (no con otro programa) |
| `sonrisa` alta | habla sonriendo | ¿hay `cola.txt` en la carpeta? Si faltó, regenerar con `cola.txt` (cuesta) |
| `apertura` alta o baja | boca exagerada o que murmura | viene de la generación; ¿se tocó `voz.txt`? volver a la de la plantilla y regenerar (cuesta) |
| `pal_min` fuera de rango | muy lento o acelerado | `ritmo_natural.py --pal-min 150` (o 165) y volver a montar |
| `nitidez` baja | cara blanda | `--enfoque 0.3` |
| `textura_piel` baja | piel plástica | `--enfoque 0.2`, `--grano 0.8`; si sigue, la base es muy lisa (rehacer foto) |
| `saltos_de_color` | el tono cambia de golpe | revisar el empalme marcado; si un clip salió muy distinto, regenerarlo con los que le siguen hasta el reanclaje (cuesta) |
| `lufs` | volumen | `--lufs` (−13,2 deja −14 al final) |
| `ruido_fondo_db` alto | soplido en las pausas con auriculares | `--nr 18` |
| `brillo_hz` bajo | voz opaca | `--brillo-voz 5` |
| dientes muy blancos (en `revision/boca/`) | carillas | `--dientes-hacia 155 141 143` |
| color lejos de la foto base | más frío o pálido que la base | `$M6 hacer_lut.py --nuestro <carpeta>/montaje/crudo.mov --referencia <carpeta>/base.jpg --histograma --salida <carpeta>/color.cube` y montar con `--lut <carpeta>/color.cube` |
| cara chica o corrida | encuadre raro | `--zoom 1.06 0.5 0.35 --zoom-destino 0.5 0.33` (agranda 6 % y lleva el punto 0,5/0,35 del cuadro a 0,5/0,33) |

## Lo que puede seguir midiendo distinto (y a ojo no se ve)

Aun con todo bien, lo que nace en Omni puede quedar un poco fuera de lo humano: parpadeo algo alto, la cabeza que
se inclina menos que una persona real, la boca que abre o redondea un poco de más, un piso de ruido en las pausas
que solo se oye con auriculares, y un parecido con la base que baja un poco a lo largo del video. Si la vara humana
lo marca como FALLA, el revisor rechaza y dice si se arregla en el montaje (gratis) o solo regenerando (con el costo):
en ese último caso, el alumno decide.

## Costos

Solo cuesta la generación en ApiMart: unos USD 0,35 por clip de 8 s (tarifa de ApiMart al escribir esto: confirmala
en su panel). Un VSL de un minuto son 11 a 13 clips: unos USD 4 a 5 si todo sale al primer intento. Montar,
medir, revisar y volver a montar es gratis. Por eso: un clip de prueba primero, y regenerar solo lo que nace en la
generación.

## Lo que este método NO hace

- No publica ni sube nada a ninguna red: el video queda en la carpeta del proyecto.
- No usa la cara de una persona real sin su permiso. Si la persona de IA representa a alguien real (un experto, el
  dueño de la marca), tiene que estar de acuerdo con lo que dice.
- No promete nada que el producto no cumpla: la persona dice el guion del alumno, y el alumno es responsable de que
  sea verdad y de respetar las reglas de cada plataforma sobre contenido hecho con IA.
