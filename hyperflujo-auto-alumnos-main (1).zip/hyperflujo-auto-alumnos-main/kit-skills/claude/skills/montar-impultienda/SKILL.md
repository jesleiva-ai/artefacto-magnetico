---
name: montar-impultienda
description: Monta una tienda de producto digital en Impultienda de punta a punta y la deja publicada, cobrando y entregando. Cubre el alta de la tienda (idioma y moneda), el procesador de cobro, los métodos de pago locales (en ON después de recargar), Markets con precio por mercado, los productos con precio, mockup 4:5 y archivo de entrega, la landing entera en el bloque Custom HTML, el dominio propio con www, el píxel de Meta con su token y Clarity, el order bump y la oferta post-compra (OTO) si la oferta los tiene, los correos al comprador y la verificación final del checkout como comprador. Usar cuando el dueño diga /montar-impultienda, "montá la tienda", "subí el producto a Impultienda", "armá la tienda de X", "cargá la landing en Impultienda", "conectá el dominio", "poné el píxel", "cargá el order bump / el upsell / el OTO", "pasá esta maqueta a Impultienda", o cuando una oferta con precio y landing aprobada tenga que salir a la venta. Regla dura: ningún guardado sin releer el formulario antes y después. Decide sola lo operativo. Nunca toca plata, dominios, procesadores ni funnels activos sin OK del dueño.
---

# /montar-impultienda: la tienda publicada, cobrando y entregando

**Por qué existe.** Impultienda es un panel que **miente al guardar**. El botón responde
sin error, el campo muestra el valor nuevo, y al recargar vuelve el viejo. Peor: un
guardado puede **pisar campos que no tocaste**, como el token del píxel, que el panel
carga tarde y que borrás si guardás antes de tiempo. Encima, varios pasos del alta no
tienen vuelta atrás. Esta skill monta la tienda en el orden que no rompe nada y verifica
cada paso donde importa: en la tienda publicada, mirando como comprador.

**Qué entrega:** la tienda publicada con `www`, con el checkout cobrando en la moneda de
cada mercado y con los medios de pago locales, con cada producto entregando su archivo,
con el píxel y Clarity midiendo, y un informe con la evidencia de cada paso.

En Windows usá `py -3` donde abajo dice `python3`.

---

## Reglas duras

1. **Ningún guardado sin releer.** Antes de guardar cualquier formulario, sacale una
   foto **también a los campos que NO vas a tocar**. Después guardás, **recargás**,
   reabrís el mismo modal o la misma solapa y sacás otra foto. Comparás las dos:
   lo que tocaste tiene que haber cambiado y **todo lo demás tiene que seguir igual**.
   ```bash
   python3 ~/herramientas/impultienda-releer-formulario.py foto --marca s=mio7 \
       --tienda tutienda.impultienda.ar --salida antes.json --esperar-secretos 20
   #   ... escribís, guardás, RECARGÁS, reabrís ...
   python3 ~/herramientas/impultienda-releer-formulario.py foto --marca s=mio7 \
       --tienda tutienda.impultienda.ar --salida despues.json
   python3 ~/herramientas/impultienda-releer-formulario.py comparar antes.json despues.json --toque "Precio"
   ```
   Si sale `[PISADO]`, restaurás el campo con el valor de `antes.json` y volvés a
   releer. Si sale `[NO QUEDÓ]`, repetís con tipeo real. Los campos secretos se ven
   solo por su largo, nunca por su valor. Si la foto de antes muestra un secreto en 0
   caracteres, **no guardes esa pantalla** hasta que una foto nueva muestre largo > 0.
2. **Así miente el guardado** (en todo el panel):
   - Cargar el valor por JS no persiste. Va **tipeo real**: clic real en el campo,
     `Input.insertText` y la pestaña al frente (`Page.bringToFront`). Las herramientas
     del kit ya lo hacen así.
   - Para vaciar un campo se usa **Backspace**, una vez por carácter. Cmd+A por CDP no
     selecciona y el valor nuevo se pega al viejo (`19` + `2990`).
   - Hay varios «Guardar» en pantalla. El bueno es **el primero después de «Cancelar»**.
   - Los índices de los botones se corren: cada tarjeta y cada modal se identifica
     **por el texto que muestra**, nunca por su posición.
   - En diálogos con dos precios a veces persiste uno solo. Apretá Tab después de cada
     campo y releé.
3. **El slug de la URL no elige la tienda.** Las pantallas `/personalizacion/*` muestran
   la tienda **activa** de la sesión y reescriben la URL sin avisar. Antes de escribir:
   `impultienda-tienda.py <slug> --esperado "<parte del nombre del producto>"`. Si sale
   distinto de 0, no escribís nada.
4. **La verdad es la tienda publicada, no el panel.** Todo se cierra mirando la URL
   pública con `?nc=<número al azar>`, porque la tienda y el checkout guardan caché.
   Los cambios tardan unos 20 a 30 segundos en publicarse.
5. **Con www, siempre.** Todo link que salga (anuncios, correos, instructivos) va con
   `https://www.`. Para verificar el dominio en Meta va la raíz sin www.
6. **Métodos de pago locales en ON, releído después de recargar**, en cada tienda.
   Nacen apagados, y apagados el checkout ofrece solo tarjeta.
7. **El orden no se negocia** (paso 2 en adelante). Idioma y moneda no tienen vuelta.
8. **No le preguntes nada al dueño** salvo en los *momentos de manos humanas*. Decidí
   lo operativo con los valores de la ficha y avisá en una línea. Ahí le pedís **una
   acción concreta** («iniciá sesión en la ventana de Chrome que se abrió y escribime
   listo»), no una opinión.
9. **Nunca tipeás ni pedís una contraseña, un código 2FA, un dato de tarjeta ni un
   token.** El dueño inicia sesión, autoriza o pega el secreto directo en el panel, y vos
   seguís.
10. **Nada inventado.** Sin testimonios, cifras ni resultados que el dueño no tenga
    probados. La landing no promete nada que el producto no traiga.

## Qué nunca hace sin OK explícito del dueño
- Fijar o cambiar un **precio**, un descuento o un precio tachado que no esté en la ficha.
- **Comprar** un dominio, un cupo de tienda, upsells extra o cualquier add-on del plan.
- Conectar, desconectar o cambiar el **procesador de cobro** (Stripe, Mercado Pago,
  Impul Pay) de una tienda.
- **Activar** un funnel post-compra. Nacen pausados, y activarlo empieza a cobrar.
- Borrar una tienda, un producto, un dominio o un market.
- Tocar idioma, moneda o dominio de una tienda **que ya vende**.
- Pasarle a nadie un link de la tienda antes de que la verificación final esté aprobada.

Leer, fotografiar, ensayar (`--ensayo`) y verificar lo hacés sin preguntar.

---

## Entrada: la ficha

Antes de tocar el panel, armá `~/tiendas/<slug>/ficha.md`. Buscá cada dato en este orden:
(1) lo que el dueño escribió al pedir la tienda; (2) su cerebro (la oferta, el pricing,
la maqueta aprobada); (3) los valores por defecto.

| Campo | Si no está |
|---|---|
| Producto y promesa | **Sin valor por defecto.** Es la única pregunta permitida, en tu primer mensaje |
| Precio y precio tachado | **Sin valor por defecto: es plata.** Misma regla |
| Mercado: idioma y países | El idioma y los países que diga la oferta |
| Bonos | Los de la oferta. Si superan el cupo del plan, el excedente va adentro del archivo principal |
| Order bump / upsells / OTO | Solo si la oferta los trae **con precio**. Sin precio no se crean |
| Garantía | 7 días |
| Nombre de la tienda y slug | Derivados del producto, en minúsculas y sin acentos |
| Dominio propio | Ninguno: la tienda anda en `<slug>.impultienda.ar` |
| ID del píxel de Meta y proyecto de Clarity | Quedan pendientes en el informe |
| Archivos de entrega y landing | Las rutas locales. Si falta la landing, primero corré `/maqueta-landing` |

Lo que falte y tenga valor por defecto se marca **A CONFIRMAR** en el informe y seguís.

**Bitácora:** todo va en `~/tiendas/<slug>/`. Actualizá `estado.md` después de cada paso
con qué hiciste, cómo lo verificaste y qué falta. Si la sesión se corta, la próxima
arranca leyendo ese archivo.

## Momentos de manos humanas (los únicos)

| | Qué hace el dueño | Paso |
|---|---|---|
| A | Inicia sesión en Impultienda en la ventana del Chrome de trabajo | 1 |
| B | Autoriza la conexión del procesador de cobro | 3 |
| C | Carga los DNS en su registrador, si no hay acceso por API | 10 |
| D | Genera el token del píxel en Meta y lo pega en el panel, e inicia sesión en Clarity | 11 |
| E | Da el OK para lo que esté en la lista de «nunca sin OK» | cuando toque |

Mientras esperás un momento humano, **seguí con todo lo que no dependa de él**.

## Herramientas

Todas viven en `~/herramientas/`. Las que escriben en el panel tienen `--ensayo` o
verifican antes de escribir: **usá el ensayo la primera vez en cada pantalla.**

| Herramienta | Para qué |
|---|---|
| `ojos.py abrir · estado · pestanias · ver --url · foto --url` | Chrome de trabajo aparte: leer pantallas y sacar capturas a 390 px |
| `manos.py js · clic --red · subir · limpiar` | Correr JS, clic real con traza de red, subir archivos, cerrar tus pestañas |
| `impultienda-tienda.py` | Deja activa la tienda correcta, o falla cerrado |
| `impultienda-releer-formulario.py` | Foto de un formulario antes y después de guardar (regla 1) |
| `impultienda-editar-ebook.py` | Título, descripción y mockup de una tarjeta de producto |
| `impultienda-subir-pdf.py` | Archivo de entrega de hasta 50 MB |
| `impultienda-pegar-link.py` | Link de entrega (archivos más pesados) |
| `market-precio-impultienda.py` | Precio por market con teclas de verdad |
| `pegar-landing-impultienda.py` | La landing entera en Custom HTML, verificada después de recargar |
| `verificar-tienda-impultienda.py` | Revisión pública de la tienda y del checkout por país |
| `~/.claude/skills/cobro-por-mercado/scripts/leer_checkout.py` | El checkout por país, también con IP real |

**Pestaña propia:** cada pantalla que operes abrila con una marca única en la URL
(`?s=mio1`, `?s=mio2`…). Las herramientas se enganchan a la pestaña por esa marca. Al
terminar, `manos.py limpiar --buscar "s=mio"` cierra solo las tuyas. Nunca cierres ni
reinicies el Chrome de trabajo entero.

---

## Pasos

### 1. Chrome de trabajo y sesión (momento A)
```bash
python3 ~/herramientas/ojos.py abrir
python3 ~/herramientas/ojos.py ver --url "https://impultienda.ar/dashboard?s=login"
```
- Abre un Chrome aparte con perfil propio (`~/herramientas/chrome-ojos`, puerto 9222). El
  Chrome de siempre del dueño queda intacto.
- **Windows:** si `ojos.py abrir` no encuentra Chrome, abrilo a mano con
  `"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir="%USERPROFILE%\herramientas\chrome-ojos" https://impultienda.ar/dashboard`
  y seguí con las demás herramientas igual.
- Decile al dueño: **«Se abrió una ventana de Chrome nueva. Iniciá sesión ahí en
  Impultienda (no en tu Chrome de siempre) y escribime listo.»** El ingreso tiene un
  chequeo de Cloudflare: lo hace él.
- Verificá que entró: `ver` tiene que devolver el panel (tiendas o «Crear nueva
  tienda»), no el formulario de ingreso.
- **Dos cuentas de Impultienda no conviven en el mismo Chrome**: una desloguea a la otra.
  Trabajá una cuenta por vez. Si tu `ojos.py --help` muestra perfiles (`OJOS_PERFIL`),
  usá uno por cuenta.
- **Panel en «Cargando…» eterno:** no está caído. El DNS de `impultienda.ar` a veces
  devuelve IPs que no responden, y las buenas son las de Cloudflare. Comprobá una con
  `curl -s -o /dev/null -w "%{http_code}" --resolve impultienda.ar:443:172.67.163.251 https://impultienda.ar/`
  (tiene que dar 200) y relanzá **solo ese** Chrome, si recién lo abriste y está vacío,
  con `--host-resolver-rules="MAP impultienda.ar 172.67.163.251, MAP www.impultienda.ar 172.67.163.251"`.

### 2. Alta de la tienda (el idioma es para siempre)
Panel general → **«Crear nueva tienda»**: un asistente de 5 pasos.
- **El idioma se elige acá y no se cambia nunca más.** Rige la landing, los correos y la
  página de descarga, y cada idioma ocupa un cupo de tienda. Ojo con las variantes:
  `es-AR` escribe con voseo y `es-419` es español neutro.
- El paso «Contenido» no avanza hasta que aprietes **«Generar copys con IA»**. Antes poné
  el título y la descripción reales, porque la IA los usa para nombrar los bonos.
  Después reemplazás todo con tu landing.
- Los colores del asistente son los del checkout y las partes nativas, no los de tu landing.
- Anotá en `estado.md` el slug que quedó (`<slug>.impultienda.ar`).

### 3. Moneda y procesador de cobro (momento B)
Configuraciones → Pagos → **«Comenzar»**: un asistente de 3 pasos (Moneda → Procesador →
Conectar).
- **Toda tienda nace en pesos argentinos.** Para vender afuera elegí **Multidivisa**
  (cada visitante ve su moneda, convertida).
- **La moneda no se guarda hasta terminar el paso 3.** Si recargás a mitad de camino,
  vuelve a pesos. Moneda y procesador van juntos y de una.
- Cambiar la moneda más tarde **desactiva Markets** y deja los importes mal leídos
  (queda el mismo número, leído en la moneda nueva).
- Stripe se conecta con la autorización de Stripe Connect, y el panel avisa que pide
  cuenta de EE. UU. Al llegar ahí: «Se abrió la conexión con Stripe en la ventana de
  Chrome de trabajo. Autorizá con tu cuenta y escribime listo.» Qué procesador usar lo
  decide el dueño: si no está en la ficha, es un OK pendiente.
- Mercado Pago es una decisión: si se conecta, los compradores argentinos siempre ven
  pesos y pagan por ahí.
- Sin procesador conectado, la landing muestra «AR$» para cualquier país. Seguí con todo
  lo demás y anotalo como pendiente.

### 4. Métodos de pago locales: ON y releído
Aparece cuando termina el asistente del paso 3: interruptor **«Métodos de pago locales»**.
Foto antes → interruptor → **«Listo»** en el diálogo → **«Guardar cambios»** (el botón
de arriba) → **recargar** → foto después → comparar. Sin «Guardar cambios» se vuelve a
apagar. Después corré **`/cobro-por-mercado`** para los países de la ficha: dice qué
medios tiene que ver cada país y si tu cuenta los puede cobrar.

### 5. Markets: precio fijo por mercado (solo si la ficha lo pide)
Con Markets prendido, **todo país que no esté en un market ve pesos argentinos**. Si la
ficha no pide precios exactos por país, dejalo apagado.
1. `/dashboard/<slug>/markets` → activar → nuevo market (hay atajos por región) con su
   moneda. Ejemplo: «mercado A» en su moneda local.
2. **El market solo no alcanza:** hay que cargar el monto en **cada** producto, bono y
   upsell (acordeón «Precios por mercado»). En los bonos el acordeón nace cerrado y ahí
   van enteros. Esos campos piden teclas de verdad:
   ```bash
   python3 ~/herramientas/market-precio-impultienda.py "s=mio3" "Producto digital 1" "<etiqueta del campo>=19.90"
   ```
   `<etiqueta del campo>` es el texto exacto que el diálogo muestra junto al campo de ese
   market: leelo antes con `ojos.py ver`. Esta herramienta **guarda sola** (no tiene
   ensayo): sacá la foto de antes con el modal abierto y comparala después.
3. Releé cada tarjeta después de recargar y verificá con `?country=XX` (el código del mercado) en el paso 14.

### 6. Productos: título, descripción, mockup y precio
Pantalla **Diseño de ebooks** (`/dashboard/<slug>/personalizacion/ebooks`): una tarjeta
por producto (el principal, los bonos y los upsells).
```bash
python3 ~/herramientas/impultienda-tienda.py <slug> --esperado "<parte del nombre del principal>"
python3 ~/herramientas/ojos.py ver --url "https://impultienda.ar/dashboard/<slug>/personalizacion/ebooks?s=mio3"
python3 ~/herramientas/impultienda-editar-ebook.py --marca mio3 --tienda <slug>.impultienda.ar \
    --producto "Nombre que muestra hoy la tarjeta" --titulo "Producto digital 1" \
    --descripcion "…" --mockup ~/tiendas/<slug>/mockups/principal.png --ensayo   # sin --ensayo para guardar
```
- La tarjeta se busca por el **nombre que muestra hoy**, nunca por su posición.
- **Mockups 4:5 parados, siempre.** El checkout los muestra en huecos de 56×70 y 44×55 px
  con recorte: una imagen cuadrada pierde los costados y una apaisada queda en una tira.
  Sin mockup queda peor: la plataforma dibuja un recuadro gris con un emoji que parece una
  tapa rota. El texto de una tapa **nunca lo genera una IA de imagen** (cambia letras): el
  arte de fondo puede ser generado, el título lo pone un HTML. Abrí cada mockup y leelo
  letra por letra.
- **Precios** (modal «Precio, título y más»): tipeo real, Backspace para vaciar, el
  Guardar después de Cancelar, foto antes y después.
  - El **«Valor percibido» de los bonos borra el punto decimal** (`20.87` queda `2087`):
    ahí van enteros.
  - **El tachado del checkout es el precio original MÁS la suma de los valores de los
    bonos.** Si querés que el tachado mida solo el producto, poné los bonos en 0.
- **Cupos del plan:** mirá el contador del panel («Agregar bono 3/5»). Si «Agregar bono»
  no suma (clic real con `--red` y cero llamadas), usá las tarjetas que creó el asistente
  y meté el excedente adentro del archivo principal. Ampliar el cupo es compra: OK del dueño.

### 7. Entrega: sin esto la tienda cobra y no entrega
Cada tarjeta, incluidos bonos y upsells, necesita su archivo.
```bash
# hasta 50 MB: se sube al panel y cada producto entrega exactamente su archivo
python3 ~/herramientas/impultienda-subir-pdf.py --marca mio3 --tienda <slug>.impultienda.ar \
    --producto "Producto digital 1" --pdf ~/tiendas/<slug>/entrega/principal.pdf
# más pesado: link externo, UN archivo por link (nunca una carpeta con todo adentro)
python3 ~/herramientas/impultienda-pegar-link.py --marca mio3 --tienda <slug>.impultienda.ar \
    --producto "Producto digital 1" --link "https://…" --ensayo
```
- El link tiene que abrir **sin sesión**: `curl -sIL "<link>" | grep -i "^HTTP"` no puede
  terminar en una pantalla de login.
- Si la entrega es una página o una app (no un archivo), el link de la tarjeta apunta a
  esa página, y esa página no lleva el píxel de los anuncios.
- Al final **ninguna tarjeta puede seguir mostrando «Pegar link» o «Subir PDF» vacío.**

### 8. Imágenes de la landing → Recursos
`/dashboard/<slug>/personalizacion/diseno/recursos`. Acepta varios archivos, los pasa a
`.webp` y devuelve **una URL pública por archivo**: esa URL va en el `src` de la landing.
Subilas a 3 veces el tamaño en que se muestran, no más. Para subir:
`manos.py subir --buscar "s=mio4" --archivo <ruta>`, y después leé las URLs
con `ojos.py ver`. (Los mockups de producto no van acá: van en la tarjeta, paso 6.)

### 9. La landing, en el bloque Custom HTML
Hay **dos** lugares para pegar HTML y **no son intercambiables**:
- Contenido → «Secciones HTML insertadas»: cada sección corre dentro de un iframe. Sirve
  para un bloque suelto, **no para una landing entera**.
- **Estilo y paleta → tarjeta «Custom HTML».** Este es el bueno. Al activarlo, la pantalla
  Contenido pasa a ser un único campo con el HTML completo de la tienda.

**Cómo tiene que venir `landing.html`** (si viene de `/maqueta-landing`, pasala antes por
`/evaluar-landing`):
- Un documento completo, pensado primero para celular (390 px), con el CSS adentro.
- **El botón de compra lleva a `/checkout`**: `<a href="/checkout">…</a>`.
- **Precios con tokens, nunca a mano:** el servidor reemplaza `{{price}}` y
  `{{original_price}}` por los valores de la tienda en la moneda de cada visitante. Un
  número escrito a mano rompe la multidivisa. Si mostrás un porcentaje de descuento,
  calculalo en el navegador desde los dos precios servidos. Al leer importes en JS, ojo
  con los miles: si después del separador vienen 3 dígitos, es separador de miles.
- **Mirala antes de pegarla:** `python3 ~/herramientas/ojos.py foto --url "file://<ruta>/landing.html"`,
  y mirá cada tira.

**Pegarla:**
```bash
python3 ~/herramientas/ojos.py ver --url "https://impultienda.ar/dashboard/<slug>/personalizacion/diseno/contenido?s=mio5"
python3 ~/herramientas/pegar-landing-impultienda.py --marca mio5 --tienda <slug>.impultienda.ar \
    --html ~/tiendas/<slug>/landing.html --ensayo      # después, sin --ensayo
```
La herramienta vacía el campo, tipea en trozos de 60 KB, guarda, **recarga y compara la
huella**. Solo sale `[ok]` si lo que quedó después de recargar es idéntico al archivo.
- **El SEO (título y descripción) no se edita en Custom HTML.** Pasá a «Clásico», editá
  el SEO, guardá (con foto antes y después) y volvé a «Custom HTML». El HTML sobrevive.
- Confirmá en la publicada: `verificar-tienda-impultienda.py` tiene que decir «landing en
  modo Custom HTML».

### 10. Dominio propio, con www (momento C)
`/dashboard/<slug>/configuracion` → pestaña **Dominio** → «Conectar» con
**`www.tudominio.com`**. El panel muestra los registros a cargar, normalmente:

| Tipo | Nombre | Valor |
|---|---|---|
| CNAME | `www` | `ssl.impultienda.ar` |
| A | la raíz (el registrador la muestra como arroba o vacía) | **la IP que muestre el panel en ese momento** |

- La IP del registro A **se lee del panel**, no se copia de ningún lado: cambia.
- Si el registrador tiene API configurada por el dueño, cargalos vos. Si no, pasale la
  tabla exacta y esperá el «listo». Comprar el dominio es plata: OK del dueño.
- El certificado tarda de 2 a 5 minutos. El panel muestra «pending» y reintenta solo.
- El panel acepta **un solo** dominio. Mudar una tienda que ya vende no mueve los links de
  entrega escritos en las tarjetas: hay que revisarlos uno por uno.
- Si la raíz sin www no llega, ningún link se publica sin www (ya es la regla).

### 11. Píxel de Meta, su token y Clarity (momento D)
Configuraciones → **Meta / Tracking**. **Esta es la pantalla donde un guardado borra
secretos:** el campo del token de la API de conversiones carga tarde y recién abierto
puede mostrar 0 caracteres aunque el token exista.
1. Foto antes con `--esperar-secretos 20`. Si el token sigue en 0 y el dueño dice que
   ya lo había cargado, no guardes: recargá y repetí.
2. **ID del píxel:** sale de la ficha. Lo escribís vos con tipeo real.
3. **Token de la API de conversiones:** lo genera el dueño en el Administrador de
   eventos (el conjunto de datos del píxel → Configuración → API de conversiones →
   Generar token) y **lo pega él directo en el campo del panel**. No pasa por el chat ni
   por un archivo.
4. Guardar → recargar → foto después → comparar con `--toque` sobre lo que cambió. El
   token tiene que tener largo > 0 y la misma huella que antes si no lo tocaste.
5. **Verificación del dominio en Meta:** va la **raíz sin www** (`tudominio.com`), nunca el
   subdominio de la plataforma, que no se puede verificar. El campo «Verificación de
   dominio» del panel solo agrega el meta tag a las páginas; lo más firme es el TXT en el
   DNS, en la raíz del dominio. Orden: Meta primero y DNS después (si borrás y volvés a agregar el
   dominio en Meta, el token cambia). Comprobá que el TXT y el meta tag traigan el
   mismo valor antes de tocar «Verificar» en Meta.
6. **Clarity, en toda tienda:** el dueño inicia sesión en clarity.microsoft.com en el
   Chrome de trabajo, se crea el proyecto para el dominio con www, se carga el ID en el
   panel y **se verifica viendo tu propia visita en Clarity → Recordings**. «Instalado» no
   alcanza.

### 12. Order bump y oferta post-compra (OTO), solo si la oferta los trae
Los productos extra son las tarjetas de **upsell** de Diseño de ebooks (título, mockup
4:5, precio y entrega como en los pasos 6 y 7). Un interruptor decide dónde aparecen:
- **«Disponible solo en post-compra» APAGADO** → aparece **en el checkout, antes de
  pagar**: es el **order bump**. Su descripción entra en unas 3 líneas a 390 px (unos 126
  caracteres): más larga, se corta a mitad de palabra.
- **ENCENDIDO** → sale del checkout y solo se puede ofrecer en un **funnel post-compra**
  (el OTO, después del pago).
Confundirlo es cobrar el bump donde iba el OTO. Foto antes y después del interruptor.

**El funnel post-compra:** `/dashboard/<slug>/marketing/post-compra`. Tres pasos:
1. **Triggers:** el funnel dispara si el carrito contiene **exactamente** los productos
   que elijas. Un funnel cubre una sola combinación. Hay un modo «disparar siempre» para
   toda venta.
2. **Upsells:** un mapa de nodos. Cada oferta tiene dos salidas, **aceptó** y **rechazó**,
   y cada salida se conecta a otro nodo. La que queda libre cae en la página de
   agradecimiento. El modo automático arma un par oferta + downsell por cada upsell y les
   pone descuentos solo: **revisá cada descuento contra la ficha**, que es plata.
3. **Página de agradecimiento:** título, mensaje, botón (siempre vuelve al inicio de la
   tienda) y links libres.

**El editor de cada oferta** son widgets en acordeón (texto, timer, descuento, badge,
botones, HTML personalizado, imagen, video…). Abrir uno reemplaza la lista por su panel,
y para volver se clickea el título del panel. Ubicá cada widget **por su texto**, nunca por
índice. Tokens vivos: `{price}`, `{compare}`, `{discount}`, `{timer}`, `{first-name}`. El
copy no dice «tu pedido no está completo»: el pedido ya está completo. Cada widget se
guarda con foto antes y después.

**Los funnels nacen PAUSADOS.** Dejalos armados y verificados, y **activarlos es un OK del
dueño**.

### 13. Correos al comprador
`/dashboard/<slug>/personalizacion/diseno/emails`: en el idioma del mercado, con el nombre
final del producto y sin textos del asistente. Foto antes y después de cada guardado.

### 14. Verificación final como comprador
Todo sobre la **tienda publicada**, con `?nc=` para saltar la caché. Pegá esta lista en
`estado.md` y tachá cada renglón con la evidencia al lado.
```bash
python3 ~/herramientas/verificar-tienda-impultienda.py tudominio.com --paises XX YY \
    --titulo "Producto digital 1" --pixel <ID del píxel de la ficha>
```
- [ ] La landing con www responde 200 y el `<title>` es el de esta tienda (no otra ni una
      página de estacionamiento).
- [ ] Modo Custom HTML, sin `{{price}}` crudos y con botón a `/checkout`.
- [ ] Se ve bien en el celular: `ojos.py foto --url "https://www.tudominio.com/?nc=<n>"`,
      tira por tira (textos, imágenes, botones).
- [ ] **Checkout por país:** cada país de la ficha **y uno de afuera**, con
      `/checkout?country=XX`: la moneda del mercado, el precio de la ficha, los medios
      locales en ON y nada apagado a mano. Antes de culpar a la tienda por una moneda
      rara, fijate por dónde sale tu conexión (`curl -s ipinfo.io/json`).
- [ ] **Con IP real del país** (`?country` es una aproximación): `/cobro-por-mercado`,
      pasos 4 y 5, con `proxy_pais.py` y `leer_checkout.py --proxy`. Si no hay proxy
      limpio, queda anotado como pendiente.
- [ ] Order bump visible en el checkout con su mockup entero, y miniaturas en 4:5:
      `manos.py js` con `naturalWidth/naturalHeight` de cada imagen tiene que dar 0,8.
- [ ] Métodos de pago locales en ON, releído después de recargar.
- [ ] **Cada producto entrega:** ninguna tarjeta vacía y cada link externo abre sin sesión.
- [ ] Píxel cargado (el ID de la ficha), token con largo > 0 y Clarity grabó tu visita.
- [ ] Funnel post-compra armado y en PAUSA esperando el OK (si aplica).
- [ ] Correos en el idioma del mercado.

No hace falta una compra de prueba: la prueba de cobro la hacés vos mirando el checkout
como comprador, desde cada país. Si el dueño igual quiere hacer una, es decisión suya.

## Entregar
El informe va a `estado.md` y al chat:
1. Arriba de todo, un bloque **A CONFIRMAR**: precios, nombres y cualquier decisión de
   plata o de marca que tomaste por defecto, más los OK pendientes (activar el funnel,
   procesador, compras).
2. El link de la tienda **con www**.
3. Qué quedó hecho, cada cosa con **cómo se verificó** (la salida de la herramienta o la
   captura).
4. Lo pendiente, con **quién lo tiene que hacer** (vos o el dueño).
Si apareció una trampa nueva del panel, guardala con `/orden` para la próxima tienda.

## Si algo no anda

| Síntoma | Causa | Arreglo |
|---|---|---|
| Guardó sin error y al recargar está el valor viejo | Valor cargado por JS | Tipeo real (las herramientas del kit) y releer |
| Un campo que no tocaste cambió | El guardado pisó un campo que cargaba tarde | Restaurar desde la foto de antes y releer |
| El precio quedó con dígitos de más | Cmd+A no seleccionó | Vaciar con Backspace |
| El bono vale 100 veces más | «Valor percibido» no acepta decimales | Enteros |
| Los datos son de otra tienda | El slug de la URL no elige la tienda | `impultienda-tienda.py <slug> --esperado "…"` |
| Un botón no hace nada | Control roto o clic que no llega | `manos.py clic --texto "…" --red`: cero llamadas = control muerto del lado de ellos |
| El proceso quedó colgado después de un clic | Se abrió un `confirm()` nativo | Antes del clic: `manos.py js --expr "window.confirm=()=>true"` |
| La landing muestra «AR$» | No se terminó el asistente de Pagos | Paso 3 |
| El checkout ofrece solo tarjeta | Métodos locales apagados | Paso 4, con «Guardar cambios» y recarga |
| Un país ve pesos argentinos | Markets prendido y ese país sin market | Crear el market o apagar Markets |
| La tapa sale cortada en el checkout | El mockup no es 4:5 | Rehacerlo en 4:5 (rellenar, no recortar) |
| El cambio no aparece en la tienda | Caché o publicación en curso | `?nc=<n>` y esperar 30 s |
| El panel queda en «Cargando…» | DNS que devuelve IPs muertas | Paso 1 |

## Rutas del panel
```
/dashboard                                            todas las tiendas
/dashboard/<slug>/configuracion                       General · Pagos · Meta/Tracking · Dominio
/dashboard/<slug>/markets                             markets
/dashboard/<slug>/personalizacion/ebooks              productos, bonos, upsells: precio, mockup, entrega
/dashboard/<slug>/personalizacion/diseno              estilo y paleta (acá se activa Custom HTML)
/dashboard/<slug>/personalizacion/diseno/contenido    el HTML de la landing
/dashboard/<slug>/personalizacion/diseno/recursos     imágenes
/dashboard/<slug>/personalizacion/diseno/emails       correos al comprador
/dashboard/<slug>/personalizacion/diseno-checkout     diseño del checkout
/dashboard/<slug>/marketing/post-compra               funnels post-compra (OTO)
```
`/configuracion` y `/markets` respetan el slug. Las de `/personalizacion/*` muestran la
tienda activa: se cambia con el selector de tiendas **y una recarga**, nunca escribiendo
la URL. El panel cambia seguido: si una pantalla no coincide con esta guía, mirala con
`ojos.py ver`, adaptate y anotá la diferencia en `estado.md`. No inventes el botón que
«debería» estar.
