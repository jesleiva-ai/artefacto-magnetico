---
name: montar-landing-shopify
description: >-
  Convierte una maqueta aprobada en el montaje completo de Shopify con el método
  de los módulos: tema Dawn, la landing en la página de producto, y una sección
  de Liquid personalizado por bloque — más el CSS escopado, el JS y el
  instructivo como artifact con sello de versión y botón de copiar. Usar cuando
  el dueño del cerebro diga /montar-landing-shopify, "pasá esto a
  Shopify", "armale el instructivo al que monta", "necesito el código para montarla",
  "regenerá los archivos", o cuando una maqueta pase la compuerta de
  evaluar-landing y haya que entregarla al que monta. También cuando una oferta
  vieja tenga que actualizarse a esta metodología. La maqueta es la fuente
  única: los archivos se GENERAN, nunca se editan a mano.
---

# Montar una landing en Shopify

Existe porque en una operación real quien montaba estuvo horas montando una landing que ya
no existía. La maqueta había cambiado varias veces en pocos días y los archivos de
Shopify se mantenían a mano, en paralelo. Nadie se equivocó: el armado
garantizaba que pasara.

**Regla que la hace existir: si un archivo se puede derivar de otro, se genera.**

Lectura previa obligatoria: `02-notas/montar-una-landing-en-shopify-sin-app.md`,
sección «Ampliacion». Ahí está el método completo y el porqué de
cada decisión.

## Lo que produce

| Archivo | Dónde va | Quién lo toca |
|---|---|---|
| `secciones/00-cargador.liquid` | Personalizador → Agregar sección → Liquid personalizado | quien monta |
| `secciones/b01..b14-*.liquid` | ídem, una sección por bloque, en orden | quien monta |
| `secciones/99-pie.liquid` | ídem, última | quien monta |
| `<id>.css` | Contenido → Archivos | quien monta |
| `<id>.js` | Contenido → Archivos | quien monta |
| `<id>-bloque.html` | solo como referencia y para el guardián | nadie |
| INSTRUCTIVO (artifact) | link fijo | quien monta |

**DOS links fijos por oferta, no tres**: **maqueta** (el dueño aprueba) e
**instructivo** (quien monta, monta). Los prompts de imagen van **DENTRO del
instructivo**, como una sección más — nunca como artifact aparte.

> Por qué: antes los prompts salían en su propio artifact. A quien
> monta le pasan un solo link, el del instructivo, y ahí los prompts no estaban:
> quedó frenado pidiéndolos. Un entregable partido en dos siempre llega por la
> mitad, y además las dos mitades se desincronizan. **El instructivo se entrega
> 100% completo o no se entrega.**

## EL CONTRATO DEL ENTREGABLE — las 9 partes, se tachan una por una

**Antes de pasarle el link al que monta, recorré esta lista tachando.** No es un
resumen de lo que suele llevar: es la compuerta. Si falta una, no se entrega.

Existe porque en una operación real un instructivo se entregó tres veces y las
tres volvió con un hueco: sin el link a la maqueta, sin el paso de crear el
producto, sin dónde subir los archivos. Ninguno era difícil; los tres se veían
mirando el documento contra una lista.

| # | Parte | Cómo sabés que está |
|---|---|---|
| 1 | **El camino numerado**, en orden de ejecución | Cada paso dice **cuándo está listo**, no solo qué hacer |
| 2 | **Link a la maqueta aprobada** | Está arriba y en la sección de la maqueta |
| 3 | **Todo lo que se pega** | Cada bloque con botón de copiar |
| 4 | **Todo lo que se sube** | Se descarga **desde el mismo artifact**, sin ir a buscarlo |
| 5 | **Todo lo que hay que crear** | Con su prompt y su referencia adentro |
| 6 | **Dónde va cada cosa** | Con el **nombre del menú** tal como se ve en pantalla |
| 7 | **Los nombres exactos de archivo** | Y qué pasa si se equivoca uno |
| 8 | **Qué hacer si algo falla** | Tabla síntoma → causa → arreglo |
| 9 | **Lo que decide el dueño** | Separado y rotulado, no mezclado con lo ejecutable |

**La prueba no es leerlo: es poder recorrer el camino sin abrir otra pestaña ni
preguntar nada.** Si en algún paso quien monta tendría que buscar algo afuera o
adivinar, esa es la parte que falta.

### Si estás REHACIENDO un artifact que ya existía

**Traé la versión publicada y diffeala antes de reemplazarla** — `WebFetch`
sobre la URL del artifact la devuelve entera. La versión anterior es la mejor
lista de requisitos que hay: cada cosa que tiene está porque alguien la
necesitó. Lo que desaparece, desaparece **a propósito y dicho**, o es un bug.

Se perdió así el link a la maqueta: se rehízo el instructivo de cero y nadie
miró qué traía el anterior.

## Cómo llegan los archivos a la tienda — dos caminos

El generador es siempre la fuente única; lo que cambia es cómo viajan los archivos.
**El camino 1 es el recomendado. El 2 es el que existía antes y sigue como respaldo.**

### 1 · Publicar por API (recomendado)

```bash
python3 ~/herramientas/shopify.py temas                              # sacar el ID
python3 ~/herramientas/shopify.py publicar --tema <ID> --dir <salida>              # simulacro
python3 ~/herramientas/shopify.py publicar --tema <ID> --dir <salida> --confirmar  # escribe
```

Sube las secciones y el CSS de una, verifica archivo por archivo contra la tienda,
y **nadie pega código a mano**. Mata de raíz el error que originó esta skill: que
quien monta monte una versión que ya no existe. También mata el problema del sello — no
hay dos versiones posibles si nadie copia nada.

**Antes de usarlo, una sola vez**: el token de `~/.config/shopify.json` necesita
`read_themes` + `write_themes`. Comprobalo con
`shopify.py probar-escritura --tema <ID de un tema NO vivo>`, que escribe una marca,
la relee y te dice si el camino existe. Si da acceso denegado, andá al camino 2 y
avisale al dueño — no pierdas el turno peleándote con permisos.

**Nunca sobre el tema vivo.** El comando se niega solo, y está bien que se niegue:
se publica sobre un duplicado y el dueño lo activa cuando lo miró.

### 2 · Instructivo para que otra persona monte (respaldo)

Cuando no hay token con `write_themes`, o cuando quien monta es alguien sin acceso
a la Mac. Es el flujo de abajo: artifact con sello, botón de copiar, y la ficha del
producto. **Si usás este camino, decilo explícito en el reporte**, porque reintroduce
el riesgo de versión vieja que el camino 1 elimina.

## Cómo se corre

```bash
python3 ~/.claude/skills/montar-landing-shopify/scripts/generar.py --config montaje.json
```

`montaje.json`:
```json
{
  "maqueta": "_staging/landing-X/maqueta.html",
  "salida":  "_staging/landing-X",
  "id":      "oferta-a",
  "cdn":     "https://cdn.shopify.com/s/files/1/XXXX/XXXX/XXXX/files/",
  "prefijo_img": "ej",
  "mockup":  "nombre-del-mockup-en-shopify.png"
}
```

`slugs` y `piezas` son opcionales; por defecto usa los del molde de 13 bloques.
El `cdn` sale de Contenido → Archivos → subir cualquier archivo → copiar enlace,
quedándose con todo lo anterior al nombre, barra final incluida.

## El reconocimiento se adapta por oferta. Es la norma, no la excepción

**El script corre tal cual en 1 de 3 maquetas reales.** No es una falla: cada
maqueta se escribió distinto y el parser no puede adivinar.

| maqueta | cómo marca los bloques | cómo marca las imágenes |
|---|---|---|
| oferta A | `<!-- ═ Bn · -->` | `.tapa > .hueco` |
| oferta B | inline, sin marcadores | base64 embebido |
| oferta C | `<section id="bN">` | `.ph` con la spec adentro |

Lo que se comparte de verdad es **el método y los guardianes**, no el parser.
Antes de correrlo, abrí la maqueta y mirá con qué marca sus bloques y sus
huecos. Si no coincide, copiá el adaptador más parecido
(`_staging/landing-oferta-b/` o `_staging/landing-oferta-c/`) y
cambiale el reconocimiento — nunca aflojes los guardianes para que "pase".

Si no encuentra marcadores, el script **aborta con `[error]` y código 1**. Antes
avisaba y seguía, y terminaba imprimiendo `[ok]` sin haber escrito un solo
snippet: una corrida que no cambió nada reportando éxito (regla dura 9).

## Las cinco cosas que no se saltean

**1 · El guardián del namespace.** El script se niega a escribir si queda un
selector sin `#<id>`. No lo desactives. Lo que atrapa: `@media(min-width:760px)`
no tiene espacios, y un detector que parte por espacios deja su cuerpo sin
prefijar — la landing pierde el estilo en escritorio **y pisa los `h1` y
`section` de la tienda entera**. A ancho de celular se ve perfecto.

Si escribís un guardián propio: **no puede compartir código con lo que vigila**.
Uno que reusaba el detector de at-rules del prefijador informó «0 selectores
sueltos» con el CSS filtrándose entero. Detección propia, fallando **cerrado**
(lo que no reconoce, lo inspecciona igual), y **probalo rompiendo a propósito lo
que tiene que atrapar**: un guardián que nunca falló está sin estrenar.

**2 · Render dentro del tema hostil, arriba Y abajo del breakpoint.** El script
deja `_test-tema-hostil.html`: un tema que fuerza Georgia, bordes punteados,
`.wrap` angosto y viñetas cuadradas. Servilo y mirálo con `ojos.py foto`. Leer
el CSS no alcanza: los selectores del tema le ganan a la **herencia**, así que un
`h1` sin `font-family` propio sale en la serif del tema.

**3 · Secciones contra bloque, carácter por carácter.** Ya está en `generar.py` y
**aborta la corrida** si no coinciden. Arma la página **leyendo las secciones de
vuelta del disco** — que es lo que Shopify va a renderizar — y la compara contra
el bloque monolítico. Compararlo contra lo que el generador todavía tiene en
memoria da verdadero por construcción: no prueba nada y parece que la compuerta
está puesta. Atrapó dos bugs reales el mismo día que se escribió: el pie que no
cerraba el `<div>` de `#<id>` (8 caracteres, el pie del tema se metía adentro de
la landing) y un salto de línea de diferencia en el cargador.
Ojo con el comparador: hay que sacar `{% comment %}…{% endcomment %}` **antes**
que las demás etiquetas, o el cuerpo del comentario queda como texto y da un
falso negativo.

**4 · Mirar el artifact publicado.** Regla dura 10 del vault. Una URL perfecta no
prueba que se vea.

**5 · ¿La landing cobra lo que promete?** `scripts/guardian-cobro.py`. Le pregunta
a la tienda —`/products/<handle>.js`— cuáles son las variantes REALES de ese
producto, y marca todo `VARIANT_ID` del código que no esté en esa lista.

```bash
scripts/guardian-cobro.py --url https://tienda.com/products/<handle> --probar-carrito
scripts/guardian-cobro.py <bloque>.html --handle <handle> --tienda <dominio>
```

Lo que atrapa: **duplicaste un producto para reusar su landing y el `VARIANT_ID`
viajó con el código**. La página dice un producto y el carrito entrega otro. No da
error, no deja hueco, se ve perfecta. Pasó en una operación real: estuvo publicada
una landing que ofrecía un producto (por ejemplo, «Producto A, US$ 10») y cobraba
otro distinto (por ejemplo, «Producto B, US$ 20»).

Detección propia —no comparte una línea con `generar.py`— y **falla cerrada**: si
no puede bajar el producto, si no deduce el handle o si no encuentra ningún
`VARIANT_ID`, aborta con código 1 en vez de reportar `[ok]` por no haber mirado.
Probado contra sus dos extremos reales: la landing sana pasa, la duplicada falla.

Con `--probar-carrito` hace el POST a `/cart/add.js` y **te dice el `product_title`
y el precio de lo que realmente se agrega**. Ése es el artefacto real; el resto es
inferencia.

## El método es el de la casa: Dawn + página de producto

**Esto no se improvisa: sale del método de la casa** (las clases de tienda y de
código que tenga el dueño, si las tiene en sus fuentes).
Pasó en una operación real: se entregó un método inventado desde cero — plantilla del tema,
snippets, layout propio — porque **el canon no estaba destilado en el vault y
nadie lo consultó**. Funcionaba, pero no era el método de la casa.
Antes de reinventar un procedimiento, buscá si la casa ya tiene uno.

El canon, medido de las clases:

1. **Tema Dawn**, gratis. Si la tienda trae Horizon, se cambia.
2. **Siempre en vista móvil.**
3. La landing vive en la **página de producto** (`/products/handle`), nunca en una
   Página ni en la home. El tráfico de los anuncios va a ese link.
4. Header, pie y barra de anuncios: **se ocultan desde el personalizador**, con el
   ojito. Sin JS y sin `layout blank`.
5. Se limpia la ficha: fuera el selector de cantidad, el de variante, compartir y
   la lupa; **queda un solo botón de compra**.
6. El código entra como **secciones de «Liquid personalizado»** que se arrastran a
   su lugar. **Nadie toca «Editar código».**

### Por qué el canon gana, y no es cuestión de gusto

El botón de compra es **el nativo de Dawn**, así que la compra pasa por el carrito
real. Eso dispara los Web Pixels — el de Meta incluido — y deja vivos el order
bump y los descuentos. La landing la acciona con un click al botón nativo, no con
una redirección a `/cart/ID:1`, que se saltea eventos que después le faltan a la
campaña para optimizar.

De paso mueren dos problemas: **no hay variable `CHECKOUT`** que completar a mano
(era el último pendiente de todo montaje) y **no hay discusión de layout**, porque
Dawn maneja el suyo y `content_for_header` nunca estuvo en riesgo.

### La numeración va con dos dígitos

`b01`…`b14`, no `b1`…`b14`. En cualquier lista ordenada por nombre, `b10` tiene que
caer después de `b09` y no entre `b01` y `b02`. Lo mismo para el cargador (`00-`) y
el pie (`99-`), que además **deben ir primero y último**: el cargador abre los dos
`<div>` de la landing y el pie los cierra.

## Las imágenes: cero código

Las URLs del CDN se escriben **antes de que existan los archivos**, porque
Shopify sirve todo en `<prefijo>/<nombre>` y la dirección es predecible. Mientras
la imagen no está, el `<img>` falla, el JS le pone `vacio` y se ve el cartel con
el nombre que falta. **Al subirla con ese nombre exacto, aparece sola.**

Cargar 30 imágenes es arrastrarlas al navegador. Nadie edita código. Las dos
reglas: nombre idéntico, y si Shopify le agrega un sufijo porque ya existía uno
igual, borrar el viejo y volver a subir.

## Cómo cobra el botón: AJAX al carrito, no URL directa

**Método probado en producción en una operación real.** El botón de la caja de
precio **no navega**: agrega al carrito por AJAX y después manda a `/cart`.

```
clic en #<slug>-comprar
  → fetch('/cart/add.js', {id: VARIANT_ID, quantity: 1})
  → window.location = '/cart'
  → el /cart personalizado muestra el producto y "Pagar pedido"
  → submit con name="checkout" → checkout nativo de Shopify
```

**Los dos caminos más obvios NO funcionan** y ya se probaron — no los reintentes:

| Camino | Qué pasa |
|---|---|
| `/products/<handle>` | va a la página del producto, y con «Comprar ahora» activado puede saltear el carrito |
| `/cart/<VARIANT_ID>:1` | agrega, pero en muchas configuraciones redirige al checkout salteando el carrito |
| `fetch /cart/add.js` → `/cart` | **funciona**: el AJAX no redirige, así que el destino lo elegimos nosotros |

**Tampoco sirve el botón nativo de Dawn** si la ficha del producto se limpió: si
se borró «Botones de compra» del personalizador, no hay `product-form` en la
página y cualquier cosa que lo busque falla en silencio.

### Lo que genera la skill

- **`VARIANT_ID` va en el cargador** (`00-cargador`), no en el `.js`. El JS se
  sirve cacheado desde el CDN y es igual para toda la tienda; el ID cambia por
  landing, así que vive en el Liquid. Sale con el valor de `variant_id` del
  config, o `0` si no está cargado — y con 0 el botón avisa por consola.
- **El botón se clona antes de conectarlo.** Si quedó cacheada una versión vieja
  del `.js` que le puso su propio handler, el clon lo deja afuera.
- El `.js` **ya no maneja la compra**. Si ves `botonNativo` en un archivo, es de
  una versión vieja del método.

### El carrito personalizado: setup único por tienda

Se hace **una vez** y sirve para todas las landings: en el editor de tema,
página **Carrito** → ocultar las secciones nativas con el ojito → agregar un
**Liquid personalizado** con el markup del carrito. De ahí en más, cada landing
nueva solo necesita su `VARIANT_ID`.

**El VARIANT_ID** se saca de `tutienda.myshopify.com/products/<handle>.json` →
`variants` → el primer `id`. Es un número de 14 cifras y va **sin comillas**.

### Dos cosas del documento original que NO se copian

1. **`el.closest('#' + SLUG)` para no ocultar los h1 propios.** En el método
   actual el namespace es una **clase**, no un id: `closest('#oferta-a')`
   devuelve null para todos y **oculta también el titular de la landing**. Si se
   usa esa función, va `closest('.' + SLUG)`.
2. **Ocultar el header con JavaScript.** El canon lo hace desde el
   personalizador, con el ojito. El JS deja un parpadeo y hay que mantener una
   lista de selectores del tema que cambia con cada versión de Dawn.

## La ficha del producto: dos cosas que SIEMPRE van

En una operación real se olvidaron las dos y las pidió quien montaba, a mitad del montaje. **No son
parte de la landing: son parte de la ficha del producto de Shopify**, y por eso
se escapan. Van en todas las ofertas, sin excepción.

### 1 · El nombre exacto del producto

Es lo que el comprador ve **en el carrito, en el checkout y en el mail de
confirmación**. Si no se define, queda el que haya puesto quien creó el
producto.

**Regla de la casa: `<Nombre del producto> + <N> bonus`.**
Ejemplo ilustrativo: `Método Ejemplo Pro + 5 bonus`. La cantidad de bonus sale
del stack, así que si cambia el stack, cambia el nombre.

**Si el nombre no está definido, preguntáselo ANTES de publicar el
instructivo** — no lo inventes y no lo dejes en blanco. Va en el instructivo,
en la tabla de estado, para que quien monta lo copie tal cual.

### 2 · La imagen de producto, cuadrada

Misma ubicación, mismos tres lugares. **2048 × 2048, 1:1, JPG o PNG.**

No es el mockup del hero recortado: **esa imagen se ve a 100-150px** y un
mockup de seis piezas se vuelve una mancha. La versión cuadrada conserva la
identidad —misma tapa, misma paleta, misma foto de quien firma— y simplifica:
la pieza central ocupa ~70% del alto y detrás asoman **dos** piezas, no seis.

Compuerta antes de entregarla: **achicala a 120px. Si no se lee el título del
producto, no sirve.**

El prompt se genera junto con los de las tapas y va en la sección de prompts
**del instructivo**. Plantilla: guardala en
`_staging/landing-<id>-shopify/prompt-imagen-producto-shopify.md` y se
adapta cambiando nombre, paleta, iconos y las dos piezas de atrás.

## Microsoft Clarity: va en TODA tienda, sin excepción

**Paso obligatorio de todo montaje. No es opcional, no se saltea, no se deja
"para cuando haya tráfico".** Se instala **antes** del primer peso de anuncio: la
sesión que no se grabó no se recupera, y las primeras 200 visitas son las que
dicen dónde se cae la gente ([[clarity-y-embudo-puntos-de-fuga]]).

Sin Clarity, cuando la conversión no acompaña solo queda adivinar. Con Clarity
el diagnóstico es dato: se exporta el CSV y se lee dónde muere el scroll, qué
botón nadie toca y en qué bloque se van. Es gratis y se instala en Shopify.

**Activo Y vinculado son dos cosas distintas.** Un proyecto de Clarity creado
pero apuntando a otro dominio, o el script instalado en un tema que no es el
publicado, se ve idéntico a uno que funciona: el panel abre, no tira error, y no
graba nada. Por eso el paso no termina en "lo instalé".

**Compuerta, y es la misma regla dura 10 de siempre: se verifica mirando.**
Entrá a la landing desde el celular, esperá unos minutos y abrí Clarity →
Recordings. **Si tu propia sesión no aparece, no está instalado.** Recién ahí el
paso está hecho.

Es **setup único por tienda**, como el carrito personalizado: si la tienda ya lo
tiene, el paso se cumple verificando que grabe la landing nueva — la URL de
producto es distinta y tiene que aparecer en el panel.

En el instructivo va **como paso propio, con su casilla**, nunca como nota al
pie. Si el dato para vincularlo no lo tenés (cuenta de Clarity, dominio de la
tienda), **preguntáselo al dueño antes de publicar el instructivo**, igual que el
nombre del producto: no lo inventes ni lo dejes en blanco.

## El instructivo

Se publica como artifact y lleva **sello**: un hash corto de los archivos, arriba
de todo. Al pedir un cambio se pasa «cambió el snippet X, sello Y»; si el que
monta ve otro sello, sabe que tiene la versión vieja antes de pegar nada.

Además del código, el instructivo lleva **la ficha del producto**: el nombre
exacto para el checkout y la imagen cuadrada de 2048×2048 (ver la sección de
arriba). Sin eso, quien monta arma la landing y el checkout sale con el nombre
por defecto y sin imagen.

Estructura que funcionó:
1. Sello + una línea de «este documento es el único que necesitás» + link a la maqueta
2. Alerta de reemplazar-no-parchear, con la lista de qué cambió
3. «Cómo funciona, en una frase»
4. Los pasos, con lo único que hay que completar marcado (`CHECKOUT`)
5. Los tres archivos con botón de copiar
6. Las imágenes: la tabla de nombres exactos
7. **Los prompts de las imágenes, completos, con botón de copiar** — uno por
   pieza que la tabla del punto 6 nombra, más el de la imagen de producto 1:1.
   Compuerta: **toda imagen que la landing pida tiene que tener su prompt acá**.
   Si la tabla nombra `x-frentes.jpg` y no hay prompt que lo produzca, el
   instructivo está incompleto — se escribe el prompt, no se entrega igual.
8. La migración a Liquid, con los snippets
9. **Microsoft Clarity activo y vinculado**, con la compuerta de ver la
   grabación propia en el panel. Va siempre, en toda tienda (ver arriba)
10. Lo que no hay que tocar: el aviso flotante apagado, los testimonios vacíos

Con un índice de anclas arriba: el documento pasa las 1.000 líneas y sin índice
quien monta scrollea a ciegas.

## Actualizar una oferta que ya está en manos de quien monta

**Se actualiza EN SU MISMA URL.** Pasá el parámetro `url` a la herramienta
Artifact; nunca publiques uno nuevo, o quien monta termina con once links y en
algún momento agarra el viejo.

Si al publicar da conflicto porque otra sesión lo modificó: **leé la versión
anterior antes de pisarla**. En una operación real ese bloqueo evitó destruir un sistema de
slots entero que la regeneración no contemplaba. `force:true` solo si el dueño lo
pide.

## Lo que esta skill NO hace

No escribe copy ni decide estructura — para eso está `/maqueta-landing`. No
juzga si la landing está lista — eso es `/evaluar-landing`, y corre **antes**.
No genera imágenes — eso es ChatGPT con los prompts, o
`/higgsfield-product-photoshoot`. Toma una maqueta ya aprobada y la convierte en
algo que quien monta puede montar sin preguntarte nada.
