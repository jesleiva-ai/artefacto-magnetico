#!/usr/bin/env python3
"""Genera el montaje en Shopify de una landing, desde su maqueta.

  python3 generar.py --config montaje.json

Fuente unica: el HTML de la maqueta. Todo lo demas se genera:
  <id>-bloque.html        HTML para pegar en la pagina (camino rapido)
  <id>.css                hoja escopada bajo #<id>, con reset contra el tema
  <id>.js                 slots de imagen + tobogan + aviso apagado
  liquid/                 un snippet por bloque + page.<id>.liquid
  _test-tema-hostil.html  banco de pruebas: simula un tema que pisa todo

Por que existe: paso en una operacion real: en pocos dias la maqueta cambio
varias veces y los archivos de Shopify quedaron congelados. Quien montaba estuvo
horas montando una landing que ya no existia. Un generador convierte eso en
imposible ([[productos-digitales-dos-fuentes-de-verdad]]).

CONFIG (json):
{
  "maqueta": "ruta/maqueta.html",
  "salida":  "ruta/de/salida",
  "id":      "oferta-a",
  "cdn":     "https://cdn.shopify.com/s/files/1/XXXX/files/",
  "prefijo_img": "ej",
  "ext": "jpg",
  "no_pisar": ["11"],
  "slugs":   {"1":"hero", "2":"cifras"},
  "piezas":  [["Modulo 0(\\\\d)", "modulo-%s", "Modulo %s"]]
}
slugs y piezas son opcionales: si faltan, se usan los del molde de 13 bloques.
"""
import argparse, io, json, os, re, sys

NS = CDN = PREF = EXT = VARIANT = None
# MODO: 'file_url' (por defecto) o 'cdn' (viejo, solo si la config trae "cdn").
#
# El modo 'cdn' colgaba el CSS, el JS y TODAS las imagenes de una sola linea que
# completaba a mano quien monta. Si quedaba sin completar no cargaba nada y la
# landing se veia como texto pelado. Quien monta perdio tiempo ahi mas de una vez
# y pidio volver atras. En 'file_url' no hay nada que completar: lo
# resuelve Shopify con el nombre del archivo. Queda UN dato a mano, el VARIANT_ID.
MODO = 'file_url'
SEL = None          # el prefijo real del CSS: ".<id>.<id>" (ver namespacear)

RESET = """
/* ═══ RESET CON ALCANCE ═════════════════════════════════════════
   El tema define h1, section, ul, button, a... y esos selectores le ganan a la
   HERENCIA de %(sel)s. Sin esto el titular sale en la serif del tema y cada
   <section> se come su padding y su borde. Va PRIMERO: las reglas propias
   vienen despues y le ganan por orden.
   ═══════════════════════════════════════════════════════════════ */
%(sel)s,%(sel)s *,%(sel)s *::before,%(sel)s *::after{
  box-sizing:border-box;
  font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif}
%(sel)s h1,%(sel)s h2,%(sel)s h3,%(sel)s h4,%(sel)s p,
%(sel)s ul,%(sel)s ol,%(sel)s li,%(sel)s figure,%(sel)s blockquote,
%(sel)s q,%(sel)s dl,%(sel)s dd,%(sel)s details,%(sel)s summary{
  margin:0;padding:0}
%(sel)s ul,%(sel)s ol{list-style:none}
%(sel)s section,%(sel)s div,%(sel)s article,%(sel)s aside,%(sel)s footer{
  margin:0;padding:0;border:0;background:none}
%(sel)s h1,%(sel)s h2,%(sel)s h3,%(sel)s h4{
  font-size:inherit;font-weight:inherit;color:inherit;text-align:inherit}
%(sel)s button,%(sel)s input,%(sel)s select,%(sel)s textarea{
  font:inherit;color:inherit;background:none;border:0;margin:0;padding:0;
  -webkit-appearance:none;appearance:none;cursor:pointer}
%(sel)s a{color:inherit;text-decoration:none}
%(sel)s img{display:block;max-width:100%%;height:auto;border:0}
%(sel)s q{quotes:none}
%(sel)s q::before,%(sel)s q::after{content:none}
%(sel)s summary{list-style:none;cursor:pointer}
%(sel)s summary::-webkit-details-marker{display:none}
%(sel)s s{text-decoration:line-through}
%(sel)s b,%(sel)s strong{font-weight:800}
%(sel)s em,%(sel)s i,%(sel)s cite{font-style:normal}
/* ═══ EL ELEMENTO VACIO NO SE ESCONDE ═══════════════════════════
   Dawn trae esta regla en base.css:
     a:empty,ul:empty,dl:empty,div:empty,section:empty,article:empty,
     p:empty,h1:empty...{display:none}
   Nuestros mockups son <div> VACIOS a proposito: no llevan <img>, la imagen
   entra por background-image. Dawn los ocultaba enteros y el hero quedaba sin
   mockup — sin error, sin hueco, sin nada que mirar. Nuestras reglas no
   declaraban `display`, asi que la de Dawn ganaba sin competencia.
   `revert` devuelve el display del navegador (block para div, inline para a),
   que es lo que habia antes de que el tema se metiera. */
%(sel)s a:empty,%(sel)s ul:empty,%(sel)s dl:empty,%(sel)s div:empty,
%(sel)s section:empty,%(sel)s article:empty,%(sel)s p:empty,
%(sel)s h1:empty,%(sel)s h2:empty,%(sel)s h3:empty,%(sel)s h4:empty,
%(sel)s h5:empty,%(sel)s h6:empty{display:revert}
"""

SLOTS_CSS = """
/* ═══ SLOTS DE IMAGEN ══════════════════════════════════════════
   La maqueta usa .hueco porque ahi las imagenes van embebidas. En Shopify no
   sirve: hay que poder cargar imagenes sin tocar codigo. Cada hueco pasa a ser
   .slot con un <img> cuya URL YA apunta al CDN, aunque el archivo todavia no
   exista. Mientras no este, falla, el JS le pone "vacio" y se ve el nombre que
   falta. Al subirla con ESE nombre exacto, aparece sola.
   ═══════════════════════════════════════════════════════════════ */
/* La sonda del cargador: si esta regla se aplica, la hoja cargo. Es la
   UNICA forma honesta de saberlo — preguntar por la URL no prueba nada. */
%(sel)s .sonda-css{outline-style:dotted}
/* El cartel que reemplaza a una imagen que todavia no se subio. */
%(sel)s .falta{
  display:flex;align-items:center;justify-content:center;text-align:center;
  width:100%%;height:100%%;min-height:110px;padding:12px;
  background:repeating-linear-gradient(45deg,#efe9e2,#efe9e2 10px,#e4dbd0 10px,#e4dbd0 20px);
  color:#6b4a52;font:700 11.5px/1.4 ui-monospace,Menlo,monospace;
  word-break:break-all;border-radius:inherit}
%(sel)s .slot{position:relative;overflow:hidden}
%(sel)s .slot img{width:100%%;height:100%%;object-fit:cover;display:block}
%(sel)s .slot.vacio img{display:none}
%(sel)s .slot.vacio::after{
  content:attr(data-pieza);position:absolute;inset:0;display:grid;
  place-items:center;text-align:center;padding:8px;
  background:repeating-linear-gradient(135deg,rgba(190,155,76,.055) 0 9px,transparent 9px 18px),var(--claro,#1B1A13);
  border:1px dashed rgba(190,155,76,.34);border-radius:inherit;
  color:var(--ambar-tx,#D8BC72);font-size:9.5px;font-weight:800;
  letter-spacing:.04em;text-transform:uppercase;line-height:1.35}
"""

JS = """/* ═══════════════════════════════════════════════════════════════
   %(id)s — comportamiento de la landing. GENERADO, no editar a mano.
     1. Slots de imagen: muestran el nombre del archivo que falta.
     2. El tobogan: los botones de arriba y abajo NO cobran, bajan a la oferta.
     3. El aviso de compra flotante — APAGADO a proposito.
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ═══ CONFIGURACION ════════════════════════════════════════════
     No hay nada que completar a mano. La landing vive en la PAGINA DE
     PRODUCTO del tema Dawn, asi que la compra la maneja Shopify.
     ═══════════════════════════════════════════════════════════════ */

  /* El prefijo del CDN. Ya esta puesto y verificado; se repite en la seccion
     del cargador porque el CSS tiene que empezar a bajar antes que este
     archivo. Si algun dia cambia la tienda, se cambia en los dos lugares. */
  var CDN = '%(cdn)s';

  /* ═══ FIN DE LA CONFIGURACION ══════════════════════════════════ */

  /* La landing esta partida en SECCIONES de Shopify, y cada seccion trae su
     propio <div class="%(id)s">. No hay una raiz unica: hay una por seccion.
     (Antes esto hacia getElementById y agarraba solo la primera.) */
  var raices = document.querySelectorAll('.%(id)s');
  if (!raices.length) return;
  function cada(sel, fn) {
    raices.forEach(function (r) { r.querySelectorAll(sel).forEach(fn); });
  }

  /* SEGUNDO INTENTO CON EL NOMBRE QUE SANITIZA SHOPIFY.
     Windows viene con "ocultar las extensiones conocidas": el archivo ya se
     llamaba foto.jpg, el Explorador mostraba "foto", el usuario le agrega
     ".jpg" y queda "foto.jpg.jpg". Shopify no admite dos puntos y guarda
     "foto_jpg.jpg". El HTML busca "foto.jpg" y no encuentra nada: 31 imagenes
     invisibles de un saque (paso en una operacion real).

     En vez de obligar a re-subir 31 archivos o a re-pegar las secciones, el
     slot reintenta UNA vez con el nombre sanitizado. Prueba primero el nombre
     limpio, asi que cuando las imagenes esten bien subidas sigue funcionando
     igual y esto no estorba. */
  function sanitizado(src) {
    return src.replace(/\\/([^\\/?]+)\\.(jpe?g|png|webp|gif)(\\?|$)/i,
      function (_, base, ext, fin) { return '/' + base + '_' + ext + '.' + ext + fin; });
  }

  cada('.slot', function (slot) {
    var img = slot.querySelector('img');
    if (!img) { slot.classList.add('vacio'); return; }
    function vacio() { slot.classList.add('vacio'); }
    function lleno() { slot.classList.remove('vacio'); }
    var src = img.getAttribute('src');
    if (!src || !src.trim()) { vacio(); return; }
    var reintento = false;
    function fallo() {
      var alt = sanitizado(img.getAttribute('src'));
      if (!reintento && alt !== img.getAttribute('src')) {
        reintento = true;
        img.setAttribute('src', alt);   // dispara load o error de nuevo
        return;
      }
      vacio();
    }
    if (img.complete) { img.naturalWidth > 0 ? lleno() : fallo(); }
    img.addEventListener('load', function () { img.naturalWidth > 0 ? lleno() : fallo(); });
    img.addEventListener('error', fallo);
  });

  /* EL HUECO DICE SU NOMBRE. Una imagen que todavia no se subio se ve como
     un icono roto, y quien monta no tiene forma de saber CUAL falta de las 18.
     Un <img> no admite ::before ni ::after —es un elemento reemplazado—, asi
     que el que falla se cambia por un cartel que dice el nombre exacto del
     archivo. Se sube con ese nombre a Contenido > Archivos y aparece solo. */
  function huecoConNombre(img) {
    var d = document.createElement('div');
    d.className = 'falta';
    d.textContent = img.getAttribute('data-pieza');
    if (img.parentNode) img.parentNode.replaceChild(d, img);
  }
  cada('img[data-pieza]', function (img) {
    var src = img.getAttribute('src');
    if (!src || !src.trim() || src.indexOf('{{') === 0) {
      huecoConNombre(img); return;
    }
    img.addEventListener('error', function () { huecoConNombre(img); });
    if (img.complete && img.naturalWidth === 0) huecoConNombre(img);
  });

  /* Regla de la casa ("la landing es un tobogan"): cero botones de COMPRA arriba
     del bloque de precio. El unico que cobra es #%(id)s-comprar. */
  var oferta = document.getElementById('%(id)s-oferta');
  cada('[data-ir]', function (b) {
    b.addEventListener('click', function () {
      if (oferta) oferta.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });

  /* LA COMPRA NO SE MANEJA ACA: la maneja el CARGADOR, que es donde vive el
     VARIANT_ID (ver la seccion 00-cargador). Este archivo se sirve cacheado
     desde el CDN y es igual para todas las landings de la tienda; el ID del
     producto cambia por landing, asi que va en el Liquid, no aca.
     Metodo probado en produccion. */

  /* ⚠ APAGADO A PROPOSITO. Las referencias lo tienen con nombres inventados: si
     se prende, la pagina afirma una compra que no ocurrio y contradice el cartel
     de la seccion de testimonios. Decision de la casa. */
  var AVISO_ACTIVO = false;
  if (AVISO_ACTIVO) {
    var caja = document.getElementById('%(id)s-aviso');
    if (caja) setTimeout(function () {
      caja.classList.add('on');
      setTimeout(function () { caja.classList.remove('on'); }, 8000);
    }, 14000);
  }
})();
"""

# ═══ EL CARGADOR ══════════════════════════════════════════════════════════
# Es la seccion 00, la primera de la pagina. Trae el estilo, el comportamiento
# y el boton de compra. Existen dos versiones porque hubo dos metodos.

LOADER_FILE_URL = """{%% comment %%}
  %(ns)s · cargador. GENERADO. Va PRIMERO, arriba de todos los bloques.

  Lo unico que se completa a mano en toda la landing es el VARIANT_ID de aca
  abajo. El estilo, el comportamiento y las imagenes los resuelve Shopify solo,
  por el NOMBRE del archivo: subilos a Contenido > Archivos y aparecen.
{%% endcomment %%}

{%% comment %%} El estilo. Sale de Contenido > Archivos, no hay URL que pegar. {%% endcomment %%}
<link rel="stylesheet" href="{{ '%(ns)s.css' | file_url }}">

<script>
(function () {

  /* ═══ LO UNICO QUE HAY QUE COMPLETAR ══════════════════════════
     VARIANT_ID: el ID numerico de la variante del producto.
     Se saca de  tutienda.myshopify.com/products/%(ns)s.json
     -> variants -> el primer  id. Va SIN comillas: es un numero.
     Mientras valga 0 el boton no compra y lo dice en pantalla. */
  var VARIANT_ID = %(variant)s;
  /* ═════════════════════════════════════════════════════════════ */

  var SLUG = '%(ns)s';

  /* En el personalizador, una seccion recien agregada se inyecta DESPUES de
     que DOMContentLoaded ya paso: el listener no dispara nunca. Por eso se
     pregunta por readyState en vez de escuchar seco. */
  function alAbrir(fn) {
    if (document.readyState === 'loading')
      document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  function avisar(texto) {
    alAbrir(function () {
      var a = document.createElement('div');
      a.setAttribute('style', 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#9B1B1B;color:#fff;font:700 14px/1.45 system-ui,sans-serif;padding:13px 16px;text-align:center');
      a.textContent = texto;
      document.body.appendChild(a);
    });
  }

  /* GUARDIAN 1, FALLA ABIERTA Y A LA VISTA. Si el .css no esta subido, la
     landing se ve como texto pelado y SIN UN SOLO ERROR que lo explique.
     No se pregunta por la URL: se pregunta por el efecto. Se mide una
     propiedad que solo existe si la hoja cargo de verdad. */
  alAbrir(function () {
    var sonda = document.createElement('div');
    sonda.className = SLUG;
    sonda.setAttribute('style', 'position:absolute;left:-9999px');
    sonda.innerHTML = '<div class="sonda-css"></div>';
    document.body.appendChild(sonda);
    var ok = getComputedStyle(sonda.firstChild).outlineStyle === 'dotted';
    sonda.remove();
    if (!ok) avisar('FALTA SUBIR %(ns)s.css a Contenido > Archivos (paso 4 del camino, en el instructivo). Hasta que este, la landing se ve sin estilo.');
  });

  /* GUARDIAN 2: el numero que hace cobrar. */
  if (!VARIANT_ID) avisar('FALTA COMPLETAR EL VARIANT_ID en la seccion 00-cargador (paso 5 del camino, en el instructivo). Hasta que este, el boton no cobra.');

  /* El comportamiento. Se inyecta a mano, no con <script src>, para poder
     enganchar el boton recien cuando el archivo termino de cargar. */
  alAbrir(function () {
    var s = document.createElement('script');
    s.src = "{{ '%(ns)s.js' | file_url }}";
    s.onload = function () {
      /* El boton se CLONA antes de conectarlo: si quedo cacheada una version
         vieja del .js que le puso su propio handler, el clon lo deja afuera y
         no hay dos comportamientos peleando. */
      var btn = document.getElementById(SLUG + '-comprar');
      if (!btn) return;
      var nuevo = btn.cloneNode(true);
      btn.parentNode.replaceChild(nuevo, btn);
      nuevo.addEventListener('click', function () {
        if (!VARIANT_ID) return;
        /* AJAX y despues /cart a mano. Con /cart/ID:1 o /products/handle
           Shopify saltea el carrito y va al checkout cuando la tienda tiene
           Comprar ahora activado (probado en produccion). */
        fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: VARIANT_ID, quantity: 1 })
        }).then(function () { window.location.href = '/cart'; });
      });
    };
    document.body.appendChild(s);
  });
})();
</script>

"""

LOADER_CDN = """{%% comment %%}
  %(ns)s · cargador. GENERADO (modo CDN, viejo).
  Va PRIMERO, arriba de todos los bloques.
{%% endcomment %%}
<script>
(function () {
  var CDN        = '%(cdn)s';
  var SLUG       = '%(ns)s';
  var VARIANT_ID = %(variant)s;

  function alAbrir(fn) {
    if (document.readyState === 'loading')
      document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }
  if (CDN.indexOf('XXXX') !== -1) {
    alAbrir(function () {
      var a = document.createElement('div');
      a.setAttribute('style', 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#9B1B1B;color:#fff;font:700 14px/1.45 system-ui,sans-serif;padding:13px 16px;text-align:center');
      a.textContent = 'FALTA COMPLETAR LA URL DEL CDN en la seccion 00-cargador.';
      document.body.appendChild(a);
    });
    return;
  }
  var v = '?v=' + Date.now();
  var hoja = document.createElement('link');
  hoja.rel = 'stylesheet'; hoja.href = CDN + SLUG + '.css' + v;
  document.head.appendChild(hoja);
  alAbrir(function () {
    var s = document.createElement('script');
    s.src = CDN + SLUG + '.js' + v;
    s.onload = function () {
      var btn = document.getElementById(SLUG + '-comprar');
      if (!btn) return;
      var nuevo = btn.cloneNode(true);
      btn.parentNode.replaceChild(nuevo, btn);
      nuevo.addEventListener('click', function () {
        if (!VARIANT_ID) {
          console.warn('[' + SLUG + '] falta cargar VARIANT_ID en el cargador');
          return;
        }
        fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: VARIANT_ID, quantity: 1 })
        }).then(function () { window.location.href = '/cart'; });
      });
    };
    document.body.appendChild(s);
  });
})();
</script>

"""


PIEZAS_DEFECTO = [
    [r"Frente 0(\d)",     "frente-%s",      "Frente %s"],
    [r"M[oó]dulo 0(\d)",  "modulo-%s",      "Modulo %s"],
    [r"Bonus 0(\d)",      "bonus-%s",       "Bonus %s"],
    [r"Ficha 0?(\d+)",    "ficha-%s",       "Ficha %s"],
    [r"testimonio 0(\d)", "testimonio-%s",  "Testimonio %s"],
    [r"Sello de garant",  "sello-garantia", "Sello de garantia"],
    [r"Retrato",          "retrato",        "Retrato"],
]

SLUGS_DEFECTO = {
    "1": "hero", "2": "cifras", "3": "antes-con", "4": "escenas", "5": "mecanismo",
    "6": "modulos", "7": "fichas", "8": "bonus", "9": "oferta", "10": "garantia",
    "11": "testimonios", "12": "quien-firma", "13": "faq", "14": "cierre",
}


def prefijar(prelude, especiales):
    fuera = []
    for sel in prelude.split(","):
        s = sel.strip()
        if not s:
            continue
        if s in especiales:
            fuera.append(especiales[s])
        elif s.startswith(SEL):
            fuera.append(s)
        else:
            fuera.append(SEL + " " + s)
    return ",".join(fuera)


def namespacear(texto, especiales):
    """Prefija todo selector, entrando en @media / @supports / @container.

    OJO: la at-rule se detecta con REGEX, no partiendo por espacios.
    `@media(min-width:760px)` no tiene espacios; con split() se lo tomaba entero
    como nombre y su cuerpo quedaba sin prefijar — la landing perdia el estilo en
    escritorio y encima pisaba los h1 de la tienda entera
    ([[productos-digitales-namespace-tambien-las-at-rules]]).
    """
    salida, i, n = [], 0, len(texto)
    while i < n:
        j = texto.find("{", i)
        if j == -1:
            salida.append(texto[i:]); break
        prelude = texto[i:j]
        k, prof = j, 0
        while k < n:
            if texto[k] == "{":
                prof += 1
            elif texto[k] == "}":
                prof -= 1
                if prof == 0:
                    break
            k += 1
        cuerpo, pl = texto[j + 1:k], prelude.strip()
        pos = pl.find("@")
        es_atrule = pos != -1 and pl[:pos].strip("\x00C0123456789 \n\t") == ""
        if es_atrule:
            m = re.match(r"@[a-zA-Z-]+", pl[pos:])
            arroba = m.group(0).lower() if m else ""
            if arroba in ("@media", "@supports", "@layer", "@container"):
                salida.append(prelude + "{" + namespacear(cuerpo, especiales) + "}")
            else:
                salida.append(prelude + "{" + cuerpo + "}")
        else:
            m = re.match(r"^((?:\x00C\d+\x00|\s)*)(.*)$", prelude, re.S)
            salida.append(m.group(1) + prefijar(m.group(2), especiales) + "{" + cuerpo + "}")
        i = k + 1
    return "".join(salida)


def clases_de(selector):
    """Las clases que menciona un selector. Detección propia y GROSERA a
    proposito: no reusa nada del prefijador ni de namespacear (regla dura 12 —
    un guardian que comparte codigo con lo que vigila hereda su punto ciego)."""
    return set(re.findall(r"\.([A-Za-z0-9_-]+)", selector))


def guardian_shorthand(css, html):
    """Aborta si el atajo `background` puede borrar una `background-image`.

    Que atrapa (paso de verdad: lo encontro quien montaba, montando):
      .mock-sistema      { background-image:url(...) }   -> (0,1,0)
      .oferta .mini-mock { background:var(--claro) }     -> (0,2,0), GANA
    y el elemento <div class="mini-mock mock-sistema"> quedaba como un
    rectangulo liso. El atajo `background` resetea background-image a none.
    En el hero no pasaba de casualidad: misma especificidad y .mock-sistema
    venia despues en el archivo. Un bug que se ve en UNA de las dos.

    Metodo: cruza el CSS con el HTML REAL. Para cada elemento, si una de sus
    clases trae background-image y otra regla que tambien le aplica usa el
    atajo sin imagen, es riesgo. Falla CERRADA: la regla que no puede parsear
    la reporta igual, no la saltea.
    """
    # los comentarios se sacan ACA con su propio regex, no con el de main():
    # varios hablan de `background` y de `background-image` en prosa y darian
    # falso positivo. Un guardian que grita cuando no pasa nada se apaga.
    css = re.sub(r"/\*.*?\*/", " ", css, flags=re.S)
    con_imagen, con_atajo, dudosas = set(), {}, []
    for m in re.finditer(r"([^{}]+)\{([^{}]*)\}", css):
        sel, cuerpo = m.group(1).strip(), m.group(2)
        if sel.startswith("@") or "\x00" in sel:
            continue
        clases = clases_de(sel)
        if not clases:
            continue
        if re.search(r"background-image\s*:", cuerpo):
            con_imagen |= clases
        for d in re.finditer(r"(?:^|;)\s*background\s*:([^;]*)", cuerpo):
            valor = d.group(1)
            if re.search(r"url\(|gradient", valor):
                continue          # el atajo TRAE imagen: no borra nada
            if "none" in valor:
                dudosas.append((sel, valor.strip()))
            for c in clases:
                con_atajo.setdefault(c, sel)

    riesgos = []
    for m in re.finditer(r'class="([^"]+)"', html):
        propias = set(m.group(1).split())
        if not (propias & con_imagen):
            continue
        for c in propias & set(con_atajo):
            if c not in con_imagen:
                riesgos.append((c, con_atajo[c], sorted(propias & con_imagen)[0]))

    if riesgos:
        print("[error] el atajo `background` va a borrar una imagen de fondo.")
        print("        Usa `background-color:` en estos selectores:")
        for clase, sel, img in sorted(set(riesgos))[:8]:
            print("          %-34s pisa la imagen de .%s" % (sel, img))
        sys.exit(1)
    if dudosas:
        print("     [aviso] %d reglas con `background:...none`, revisalas:" % len(dudosas))
        for sel, val in dudosas[:3]:
            print("          %s { background:%s }" % (sel, val))
    print("     guardian del atajo background: sin riesgos")


def huecos_a_slots(html, piezas):
    patron = re.compile(
        r'<div class="(tapa|marco|sello|shot|retrato)"><div class="hueco">(.*?)</div></div>',
        re.S)

    def cambiar(m):
        clase, texto = m.group(1), m.group(2)
        plano = re.sub(r"<[^>]+>", " ", texto)
        for rx, archivo, alt in piezas:
            g = re.search(rx, plano)
            if g:
                num = g.group(1) if g.groups() else None
                base = (archivo % num) if num else archivo
                nombre = "%s-%s.%s" % (PREF, base, EXT)
                rotulo = (alt % num) if num else alt
                fuente = ("{{ '%s' | file_url }}" % nombre) if MODO == 'file_url' \
                         else (CDN + nombre)
                return ('<div class="%s slot" data-pieza="%s">'
                        '<img src="%s" alt="%s" loading="lazy"></div>'
                        % (clase, nombre, fuente, rotulo))
        raise SystemExit("[error] hueco sin nombre de pieza: %r" % plano[:70])

    html, n = patron.subn(cambiar, html)
    print("     %d huecos -> slots" % n)
    return html


def guardian_andamiaje(html, permitidos=()):
    """Aborta si la maqueta trae texto escrito para el que APRUEBA, no para el
    que compra.

    Por que existe: una maqueta tiene dos capas —el copy y los carteles que le
    hablan al que aprueba— y el generador se lleva las dos. Paso en una operacion
    real (varias notas publicadas, una anunciando que los precios eran
    inventados) y VOLVIO A PASAR en otra oferta, con la leccion ya
    escrita: varios fragmentos, incluido un recuadro que decia que la imagen del
    hero habia que regenerarla. Leer el HTML no alcanza: ahi se ven como un <p>
    mas. Por eso deja de depender de que alguien se acuerde.

    Deteccion PROPIA: no reusa el parser de bloques ni el de huecos, para no
    heredar su punto ciego. Falla CERRADA: lo que no reconoce, lo inspecciona
    igual. Escape declarado via "andamiaje_ok" en el config, que obliga a
    nombrar lo que se deja pasar.
    """
    limpio = re.sub(r"<!--.*?-->", " ", html, flags=re.S)      # marcadores del generador
    limpio = re.sub(r"<(script|style)\b.*?</\1>", " ", limpio, flags=re.S | re.I)
    visible = re.sub(r"<[^>]+>", "\n", limpio)                  # solo texto que se LEE
    visible = re.sub(r"&[a-z]+;|&#\d+;", " ", visible)

    # OJO con el case: "TODO" en mayusculas es un marcador de trabajo, pero
    # "todo" y "Todo" son la palabra mas comun del copy en espaniol. Con re.I
    # este guardian bloqueaba maquetas limpias por "Todo lo que vas a aprender"
    # — y un guardian que grita siempre termina desactivado. Por eso los
    # marcadores van case-SENSITIVE y en mayusculas completas.
    firmas = [
        (r"\b(HUECO|TODO|FIXME|PENDIENTE|BORRADOR|PLACEHOLDER|LOREM)\b", "marcador de trabajo", True),
        (r"(?m)^\s*[\u2191\u2193\u2190\u2192\u25c0\u25b6]", "nota con flecha de referencia", False),
        (r"\b(la maqueta|el artifact|el instructivo|este documento)\b", "habla del proceso, no del producto", False),
        (r"\b(data-ir|namespace|wireframe|bloque B\d)\b", "vocabulario tecnico del armado", False),
        (r"\.(liquid)\b", "nombre de archivo de codigo en el copy", False),
        (r"\b(regla del tobog[aá]n|evaluar-landing)\b", "criterio interno del vault", False),
    ]
    hallazgos = []
    for linea in visible.splitlines():
        t = " ".join(linea.split())
        if len(t) < 3 or any(ok in t for ok in permitidos):
            continue
        for rx, motivo, sensible in firmas:
            if re.search(rx, t, 0 if sensible else re.I):
                hallazgos.append((motivo, t[:110]))
                break

    if hallazgos:
        print("[error] ANDAMIAJE en la maqueta: %d fragmento(s) le hablan al que"
              " aprueba, no al comprador. No escribo nada." % len(hallazgos))
        for motivo, t in hallazgos[:8]:
            print("        · %-38s %s" % (motivo, t))
        print("        Sacalos de la maqueta, o declaralos en \"andamiaje_ok\" del config.")
        sys.exit(1)
    print("     guardian de andamiaje: la maqueta solo le habla al comprador")


def partir_en_secciones(html, salida, slugs, no_pisar=()):
    """Parte la landing en SECCIONES de Liquid personalizado, una por bloque.

    Metodo de la casa: la landing vive
    en la PAGINA DE PRODUCTO del tema Dawn y el codigo entra como bloques de
    "Liquid personalizado" que se arrastran a su lugar en el personalizador.
    Nadie toca "Editar codigo".

    Por que este camino y no una plantilla del tema:
      · la compra usa el boton NATIVO de Dawn, asi que pasa por el carrito real
        y dispara los Web Pixels (Meta incluido). Sin URL cargada a mano;
      · no hace falta layout propio: el header y el pie se ocultan desde el
        personalizador, con el ojito. Nada que romper en el tema;
      · es el metodo estandar, el que cualquiera que monta ya sabe hacer.

    no_pisar: numeros de bloque cuyo archivo es de quien monta (los testimonios).
    Se escriben UNA vez y despues se respetan.
    """
    carpeta = os.path.join(salida, "secciones")
    os.makedirs(carpeta, exist_ok=True)

    # LIMPIEZA DE HUERFANOS. Si cambia la numeracion —porque se inserto un
    # bloque nuevo en el medio— los archivos de la corrida anterior quedan al
    # lado de los nuevos: b04-escenas junto a b04-prueba. La carpeta pasa a
    # tener dos verdades y quien monta puede pegar la vieja.
    # Se guardan en _reemplazadas/ en vez de borrarse, por si hay que mirar
    # que decia la version anterior (los testimonios cargados a mano viven aca).
    viejos = [f for f in os.listdir(carpeta) if f.endswith(".liquid")]
    if viejos:
        morgue = os.path.join(carpeta, "_reemplazadas")
        os.makedirs(morgue, exist_ok=True)
        for f in viejos:
            os.replace(os.path.join(carpeta, f), os.path.join(morgue, f))
        print("     %d secciones de la corrida anterior → secciones/_reemplazadas/"
              % len(viejos))
    marcas = [(m.start(), m.group(1)) for m in re.finditer(r"<!-- ═+ B(\d+) · ", html)]
    if not marcas:
        print("[error] no encontre marcadores de bloque <!-- ═ Bn · --> en la maqueta.")
        print("        Sin eso no se escribe NI UNA seccion. Adapta el")
        print("        reconocimiento de bloques a esta maqueta.")
        sys.exit(1)

    # El cargador va en su propia seccion, la primera. SOLO trae el CSS y el JS:
    # no abre ningun <div>. Shopify envuelve cada seccion en su propio
    # contenedor, asi que un div abierto aca se cierra aca y los bloques de las
    # otras secciones quedarian afuera del alcance del CSS. Trae el CSS
    # y el JS desde Archivos. El ?v=Date.now() es rompe-cache: al subir una
    # version nueva se toma al instante, sin limpiar nada.
    if MODO == 'file_url':
        loader = LOADER_FILE_URL % {"ns": NS, "variant": VARIANT}
    else:
        loader = LOADER_CDN % {"ns": NS, "cdn": CDN, "variant": VARIANT}
    io.open(os.path.join(carpeta, "00-cargador.liquid"), "w",
            encoding="utf-8").write(loader)

    # numeracion de DOS digitos: en la lista del personalizador y en cualquier
    # orden alfabetico, b10 tiene que caer despues de b09, no entre b01 y b02.
    escritas = ["00-cargador.liquid"]
    fin = html.find("<footer")
    for i, (ini, num) in enumerate(marcas):
        hasta = marcas[i + 1][0] if i + 1 < len(marcas) else (fin if fin != -1 else len(html))
        slug = slugs.get(num, "bloque")
        nombre = "b%02d-%s.liquid" % (int(num), slug)
        ruta = os.path.join(carpeta, nombre)
        escritas.append(nombre)

        # Los bloques cargados a mano se siguen por SLUG, no por numero. Si se
        # inserta un bloque nuevo mas arriba, los testimonios pasan de b11 a
        # b13 y buscarlos por numero los daria por inexistentes: el generador
        # los reescribiria y borraria las citas que cargo quien monta.
        if num in no_pisar:
            morgue = os.path.join(carpeta, "_reemplazadas")
            previo = os.path.join(morgue, nombre)
            if not os.path.exists(previo) and os.path.isdir(morgue):
                iguales = [f for f in os.listdir(morgue) if f.endswith("-%s.liquid" % slug)]
                previo = os.path.join(morgue, iguales[0]) if iguales else previo
            if os.path.exists(previo):
                os.replace(previo, ruta)
                print("     [respeto] b%s (%s) es de quien monta — recuperado de %s"
                      % (num, slug, os.path.basename(previo)))
                continue
        propio = num in no_pisar
        cab = ("{%% comment %%}\n  %s · bloque B%s.\n  %s\n{%% endcomment %%}\n"
               % (NS, num,
                  ("ESTE ARCHIVO ES TUYO. El generador lo escribio una vez y no\n"
                   "  lo vuelve a tocar: edita las citas y los nombres aca."
                   if propio else
                   "GENERADO. Para cambiar este bloque se reemplaza SOLO esta seccion.")))
        # AUTOCONTENIDA: abre y cierra su propio wrapper. Es lo que hace que el
        # CSS alcance a esta seccion, porque Shopify la va a envolver en un
        # <div id="shopify-section-..."> propio y nada cruza ese borde.
        io.open(ruta, "w", encoding="utf-8").write(
            cab + '<div class="%s"><div class="pagina">\n' % NS
            + html[ini:hasta].rstrip() + "\n</div></div>\n")

    # El pie y el aviso flotante, tambien autocontenidos. La cola de la maqueta
    # trae el </div> que cerraba .pagina en el artifact: se saca, porque aca el
    # wrapper lo abre y lo cierra esta misma seccion.
    cola = (html[fin:] if fin != -1 else "").rstrip()
    if cola.endswith("</div>"):
        cola = cola[:-len("</div>")].rstrip()
    io.open(os.path.join(carpeta, "b99-pie.liquid"), "w", encoding="utf-8").write(
        "{%% comment %%}\n  %s · pie y aviso flotante. Va ULTIMO.\n"
        "{%% endcomment %%}\n" % NS
        + '<div class="%s"><div class="pagina">\n' % NS + cola + "\n</div></div>\n")
    escritas.append("b99-pie.liquid")

    print("     %d secciones de Liquid personalizado" % len(escritas))
    return escritas



def main():
    global NS, CDN, PREF, EXT, SEL, VARIANT, MODO
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    cfg = json.load(io.open(ap.parse_args().config, encoding="utf-8"))

    # Sin "cdn" en la config -> modo file_url, que es el bueno. El modo viejo
    # sigue disponible para no romper las landings ya montadas con el.
    NS, PREF = cfg["id"], cfg.get("prefijo_img", "ej")
    CDN = cfg.get("cdn") or ""
    MODO = 'cdn' if CDN else 'file_url'
    print("     modo: %s" % ("CDN a mano (viejo)" if MODO == 'cdn'
                             else "file_url · solo se completa el VARIANT_ID"))
    SEL = ".%s.%s" % (NS, NS)
    VARIANT = cfg.get("variant_id", 0)   # 0 = sin cargar; lo completa quien monta
    # macOS no trae conversor a webp (ni sips, ni PIL, ni cwebp). Si no hay
    # con que convertir, va "jpg": el nombre del archivo y el <img src> tienen
    # que coincidir, y una extension que no existe deja todos los slots vacios.
    EXT = cfg.get("ext", "webp")
    salida = cfg["salida"]
    os.makedirs(salida, exist_ok=True)
    slugs = cfg.get("slugs") or SLUGS_DEFECTO
    piezas = cfg.get("piezas") or PIEZAS_DEFECTO
    especiales = {":root": SEL, "html": SEL, "body": SEL,
                  "*": "%s,%s *" % (SEL, SEL)}

    src = io.open(cfg["maqueta"], encoding="utf-8").read()
    css = re.search(r"<style>(.*?)</style>", src, re.S).group(1)
    html = src.split("</style>", 1)[1].split("<script>", 1)[0].strip()

    css = re.sub(r"@font-face\{[^}]*\}", "", css)   # la fuente va por Google Fonts
    mock = cfg.get("mockup")
    incrustadas = list(re.finditer(r"url\(data:image/[a-z]+;base64,[^)]+\)", css))
    if incrustadas and MODO == 'file_url':
        print("[error] la maqueta trae %d imagen(es) embebida(s) en el CSS."
              % len(incrustadas))
        print("        El .css se sirve como archivo estatico: NO pasa por Liquid,")
        print("        asi que ahi dentro `file_url` no existe y la URL no se puede")
        print("        resolver sola. Sacala del CSS y ponela como <img> en el HTML.")
        sys.exit(1)
    for m in incrustadas:
        destino = CDN + (mock or "MOCKUP-PRINCIPAL.webp")
        css = css.replace(m.group(0), "url('%s')" % destino, 1)
        if not mock:
            print("     [aviso] data URI -> %s · poner 'mockup' en la config" % destino)

    com = []
    css = re.sub(r"/\*.*?\*/",
                 lambda m: (com.append(m.group(0)), "\x00C%d\x00" % (len(com) - 1))[1],
                 css, flags=re.S)
    css = namespacear(css, especiales)
    for i, c in enumerate(com):
        css = css.replace("\x00C%d\x00" % i, c)

    # GUARDIAN: un solo selector suelto y no se escribe nada
    sueltos = [s.strip() for s in re.findall(
        r"(?:^|[};])\s*((?!\." + NS + r")[.a-zA-Z*:\[][^{};@]*?)\{", css)
        if s.strip() and not s.strip().startswith("@") and "\x00" not in s]
    if sueltos:
        print("[error] selectores sin namespace, no escribo nada:", sueltos[:8])
        sys.exit(1)

    # va ANTES de escribir un solo archivo, igual que el de namespace
    guardian_shorthand(css, html)
    guardian_andamiaje(html, cfg.get("andamiaje_ok", []))

    cab = ('@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400..900&display=swap");\n'
           "/* %s · GENERADO por la skill montar-landing-shopify.\n"
           "   Fuente: %s. No editar a mano: se pisa en la proxima corrida. */\n"
           % (NS, os.path.basename(cfg["maqueta"])))
    io.open(os.path.join(salida, "%s.css" % NS), "w", encoding="utf-8").write(
        cab + (RESET % {"sel": SEL}) + "\n" + css.strip() + "\n" + (SLOTS_CSS % {"sel": SEL}))
    io.open(os.path.join(salida, "%s.js" % NS), "w", encoding="utf-8").write(
        JS % {"id": NS, "cdn": CDN or "(no se usa: las imagenes van por file_url)"})

    for viejo in ("oferta", "comprar", "aviso"):
        html = html.replace('id="%s"' % viejo, 'id="%s-%s"' % (NS, viejo))
    html = huecos_a_slots(html, piezas)

    # ═══ LAS IMAGENES PROPIAS SE PIDEN POR NOMBRE ═════════════════════════
    # Regla de lectura de la maqueta (salio de un pedido de quien monta):
    #   · src con XXXX  = imagen NUESTRA, todavia no subida  -> file_url
    #   · src absoluta  = imagen que YA vive en una tienda    -> se deja quieta
    # La segunda es la que arregla el hero y el carrusel: son las mismas fotos
    # en todas las versiones de la oferta, ya estan cargadas en la primera tienda,
    # y no tiene ningun sentido volver a subirlas tienda por tienda.
    if MODO == 'file_url':
        propias = []
        def porNombre(m):
            propias.append(m.group(1))
            return ("data-pieza=\"%s\" src=\"{{ '%s' | file_url }}\""
                    % (m.group(1), m.group(1)))
        html, n = re.subn(
            r'src="https://cdn\.shopify\.com/s/files/1/(?:XXXX/)+files/([^"]+)"',
            porNombre, html)
        fijas = len(re.findall(r'src="https://cdn\.shopify\.com/', html))
        print("     %d imagenes por nombre (hay que subirlas) · %d ya cargadas"
              % (n, fijas))
        # Shopify le agrega sufijos a estos nombres y despues no los encuentra.
        prohibidos = ("pico", "icon", "thumb", "testing", "small", "compact",
                      "medium", "large", "grande")
        malas = [a for a in propias
                 if a.rsplit(".", 1)[0].split("_")[-1].lower() in prohibidos]
        if malas:
            print("[error] Shopify no admite nombres terminados en %s:"
                  % ", ".join(prohibidos))
            for a in malas: print("          %s" % a)
            sys.exit(1)

    if MODO == 'file_url':
        cargador = ('<!-- %(ns)s · la landing entera en un bloque. GENERADO.\n'
                    '     Es la version de REFERENCIA y la que revisa el guardian.\n'
                    '     Lo que se pega en Shopify son las secciones de secciones/. -->\n'
                    '<link rel="stylesheet" href="{{ \'%(ns)s.css\' | file_url }}">\n'
                    '<script src="{{ \'%(ns)s.js\' | file_url }}" defer></script>\n\n'
                    '<div class="%(ns)s">\n%(html)s\n</div>\n'
                    ) % {"ns": NS, "html": html}
    else:
        cargador = ("<!-- %(ns)s · bloque para pegar en la pagina de Shopify. GENERADO.\n"
                    "     Contenido > Paginas > (la pagina) > vista de codigo <>.\n"
                    "     El prefijo del CDN ya esta puesto. Nada que editar aca. -->\n"
                    "<script>\n(function () {\n  var CDN = '%(cdn)s';\n"
                    "  var v = '?v=' + Date.now();\n"
                    "  var hoja = document.createElement('link');\n"
                    "  hoja.rel = 'stylesheet';\n  hoja.href = CDN + '%(ns)s.css' + v;\n"
                    "  document.head.appendChild(hoja);\n"
                    "  document.addEventListener('DOMContentLoaded', function () {\n"
                    "    var s = document.createElement('script');\n"
                    "    s.src = CDN + '%(ns)s.js' + v;\n    document.body.appendChild(s);\n"
                    "  });\n})();\n</script>\n\n<div class=\"%(ns)s\">\n%(html)s\n</div>\n"
                    ) % {"ns": NS, "cdn": CDN, "html": html}
    io.open(os.path.join(salida, "%s-bloque.html" % NS), "w", encoding="utf-8").write(cargador)

    secciones = partir_en_secciones(html, salida, slugs, set(cfg.get("no_pisar", [])))

    cuerpo = cargador[cargador.find('<div class="%s">' % NS):]
    io.open(os.path.join(salida, "_test-tema-hostil.html"), "w", encoding="utf-8").write(
        '<!doctype html><html lang="es"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<style>body{margin:0;font-family:Georgia,serif;background:#fff;font-size:18px}'
        'h1,h2,h3{color:crimson;font-family:Georgia;font-size:22px}'
        'section{padding:60px;border:4px dashed crimson}.wrap{max-width:300px}'
        'button{background:crimson;color:#fff;padding:20px}'
        'ul{list-style:square;padding-left:60px}</style>'
        '<link rel="stylesheet" href="%s.css"></head><body>'
        '<p style="padding:20px">Texto del tema.</p>%s'
        '<script src="%s.js"></script></body></html>' % (NS, cuerpo, NS))

    # ═══ GUARDIAN: CADA SECCION TIENE QUE CERRAR LO QUE ABRE ═══════════════
    # Esta es LA compuerta de este metodo, y se escribio despues de romper la
    # landing en produccion. Shopify envuelve cada seccion en su
    # propio <div id="shopify-section-...">: un <div> abierto en una seccion y
    # cerrado en otra NO se anida — el navegador lo cierra al final de la
    # primera, y todo lo que viene despues queda FUERA del alcance del CSS.
    # Sintoma: la landing se ve como texto plano, sin un solo estilo.
    #
    # El guardian anterior comparaba la CONCATENACION de los archivos, que da
    # HTML valido y pasaba feliz. Shopify no concatena: envuelve. Un guardian
    # que valida algo distinto de lo que hace produccion no valida nada.
    for nombre in secciones:
        txt = io.open(os.path.join(salida, "secciones", nombre), encoding="utf-8").read()
        txt = re.sub(r"\{%.*?%\}", "", txt, flags=re.S)
        txt = re.sub(r"<!--.*?-->", "", txt, flags=re.S)
        abren = len(re.findall(r"<div\b", txt))
        cierran = len(re.findall(r"</div>", txt))
        if abren != cierran:
            print("[error] %s abre %d <div> y cierra %d." % (nombre, abren, cierran))
            print("        Shopify envuelve cada seccion aparte: lo que no cierra")
            print("        aca, se cierra solo, y el resto de la landing queda")
            print("        fuera del CSS. Se ve todo como texto plano.")
            sys.exit(1)

    # Cobertura: el texto visible de las secciones tiene que ser el mismo que el
    # del bloque. Detecta que no se haya perdido ni duplicado un bloque entero.
    # OJO con el orden: el {% comment %}...{% endcomment %} ENTERO va primero.
    # Si se sacan antes las etiquetas sueltas, el cuerpo del comentario queda
    # como texto y da un falso negativo. (Pasa de verdad: son ~90 caracteres de
    # cabecera por seccion, 1.400 en total.)
    def solo_texto(t_):
        t_ = re.sub(r"\{%\s*comment\s*%\}.*?\{%\s*endcomment\s*%\}", " ", t_, flags=re.S)
        t_ = re.sub(r"\{%.*?%\}|<!--.*?-->|<script.*?</script>", " ", t_, flags=re.S)
        return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", t_)).strip()
    armada = "".join(
        io.open(os.path.join(salida, "secciones", n), encoding="utf-8").read()
        for n in secciones)
    if solo_texto(armada) != solo_texto(cargador):
        print("[error] las secciones no cubren el mismo texto que el bloque.")
        print("        secciones %d chars · bloque %d chars"
              % (len(solo_texto(armada)), len(solo_texto(cargador))))
        sys.exit(1)
    print("     guardian de secciones: cada una cierra sus <div> y no falta texto")

    k = lambda p: os.path.getsize(os.path.join(salida, p)) // 1024
    print("[ok] %s.css %d KB · %s.js %d KB · %d secciones"
          % (NS, k("%s.css" % NS), NS, k("%s.js" % NS), len(secciones)))
    print("     banco de pruebas: _test-tema-hostil.html")


if __name__ == "__main__":
    main()
