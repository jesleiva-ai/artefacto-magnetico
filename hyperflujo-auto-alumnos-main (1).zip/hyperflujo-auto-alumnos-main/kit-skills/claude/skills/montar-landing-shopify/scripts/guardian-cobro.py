#!/usr/bin/env python3
"""guardian-cobro.py — la landing, ¿cobra lo que promete?

QUE ATRAPA
  El error de duplicar un producto para reusar su landing: el VARIANT_ID viaja
  dentro del codigo y la pagina nueva sigue cobrando el producto viejo. No da
  error, no deja hueco, se ve perfecta. Paso en una operacion real: estuvo
  publicada una landing que decia un producto (por ejemplo "Producto A, US$ 10")
  y entregaba al carrito otro (por ejemplo "PRODUCTO B, US$ 20").
  Leccion: [[productos-digitales-dawn-rompe-en-silencio]] (recurrencia 2).

COMO LO MIDE
  No le cree al codigo. Le pregunta a la tienda: /products/<handle>.js devuelve
  las variantes REALES de ese producto. Todo VARIANT_ID que aparezca en el codigo
  y no este en esa lista es un cobro cruzado.

DETECCION PROPIA, FALLA CERRADA
  No comparte una linea con generar.py (si compartiera el parser, heredaria su
  punto ciego). Si no puede bajar el producto, si no encuentra ningun VARIANT_ID,
  o si el handle no se puede deducir: ABORTA con codigo 1. Nunca reporta [ok]
  por no haber podido mirar.

USO
  guardian-cobro.py --url https://tienda.com/products/handle      # ya publicada
  guardian-cobro.py archivo.html --handle <handle> --tienda <dominio>   # antes de pegar
"""
import argparse, json, re, sys, urllib.request, urllib.error

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"


def morir(msg):
    print(f"  [error] {msg}")
    sys.exit(1)


def bajar(url, como_json=False):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=30) as r:
            crudo = r.read().decode("utf-8", "replace")
    except Exception as e:
        morir(f"no pude bajar {url}: {e}")
    if como_json:
        try:
            return json.loads(crudo)
        except Exception:
            morir(f"{url} no devolvio JSON (¿el handle existe?)")
    return crudo


def variants_del_codigo(html):
    """Deteccion propia: los tres lugares donde Shopify acepta una variante."""
    encontrados = {}
    for etq, patron in (
        ("var VARIANT_ID",   r"VARIANT_ID\s*=\s*(\d{6,})"),
        ("href /cart/N:N",   r"/cart/(\d{6,}):\d+"),
        ('input name="id"',  r'name=["\']id["\'][^>]*value=["\'](\d{6,})["\']'),
        ("items[].id",       r'"id"\s*:\s*(\d{6,})\s*,\s*"quantity"'),
    ):
        for vid in re.findall(patron, html):
            encontrados.setdefault(vid, set()).add(etq)
    return encontrados


def precios_del_codigo(html):
    """Numeros con dos decimales, coma o punto. Sin contexto: se usan solo para avisar."""
    return {p.replace(",", ".") for p in re.findall(r"\d{1,5}[.,]\d{2}", html)}


def main():
    ap = argparse.ArgumentParser(description="¿La landing cobra lo que promete?")
    ap.add_argument("archivo", nargs="?", help="HTML local (antes de pegar)")
    ap.add_argument("--url", help="landing ya publicada")
    ap.add_argument("--handle", help="handle del producto (si se pasa archivo)")
    ap.add_argument("--tienda", help="dominio, ej: mitienda.com (si se pasa archivo)")
    ap.add_argument("--probar-carrito", action="store_true",
                    help="agrega la variante a un carrito anonimo y reporta que cobra de verdad")
    a = ap.parse_args()

    # ── de donde sale el HTML y contra que producto se compara
    if a.url:
        m = re.match(r"(https?://[^/]+)(?:/[a-z]{2}(?:-[a-z]{2})?)?/products/([^/?#]+)", a.url, re.I)
        if not m:
            morir("la --url no parece una pagina de producto (.../products/<handle>)")
        base, handle = m.group(1), m.group(2)
        html = bajar(a.url)
    elif a.archivo:
        if not (a.handle and a.tienda):
            morir("con un archivo local hacen falta --handle y --tienda")
        base = a.tienda if a.tienda.startswith("http") else "https://" + a.tienda
        handle = a.handle
        try:
            html = open(a.archivo, encoding="utf-8").read()
        except Exception as e:
            morir(f"no pude leer {a.archivo}: {e}")
    else:
        morir("pasame --url o un archivo con --handle y --tienda")

    print(f"  producto : {base}/products/{handle}")

    # ── la verdad la tiene la tienda, no el codigo
    prod = bajar(f"{base}/products/{handle}.js", como_json=True)
    reales = {str(v["id"]): v for v in prod.get("variants", [])}
    if not reales:
        morir(f"«{handle}» no declara variantes")
    titulo = prod.get("title", "?")
    print(f"  titulo   : {titulo}")
    for vid, v in reales.items():
        print(f"  variante : {vid} · {v['price']/100:.2f}")

    # ── lo que el codigo intenta cobrar
    delcodigo = variants_del_codigo(html)
    if not delcodigo:
        morir("no encontre NINGUN VARIANT_ID en el codigo — no puedo verificar "
              "(¿el boton cobra por el form nativo del tema?)")

    print()
    fallo = False
    for vid, donde in sorted(delcodigo.items()):
        sitios = ", ".join(sorted(donde))
        if vid in reales:
            print(f"  [ok]    {vid} pertenece a este producto        ({sitios})")
        else:
            fallo = True
            print(f"  [error] {vid} NO pertenece a «{titulo}»       ({sitios})")

    if len(delcodigo) > 1:
        print(f"  [error] el codigo mezcla {len(delcodigo)} variantes distintas")
        fallo = True

    # ── aviso (no bloquea): el precio real deberia leerse en el bloque.
    #    Solo en modo archivo: sobre la pagina publicada, Shopify inyecta su
    #    propio JSON con el precio y el chequeo se autoenganiaria.
    if a.archivo:
        precios = precios_del_codigo(html)
        for vid, v in reales.items():
            pr = f"{v['price']/100:.2f}"
            if pr not in precios:
                print(f"  [aviso] el precio real ({pr}) no aparece escrito en el bloque")

    # ── regla dura 10: el artefacto real. Opt-in porque hace un POST.
    if a.probar_carrito:
        print()
        for vid in sorted(delcodigo):
            cuerpo = json.dumps({"items": [{"id": int(vid), "quantity": 1}]}).encode()
            req = urllib.request.Request(f"{base}/cart/add.js", data=cuerpo,
                                         headers={"User-Agent": UA, "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=30) as r:
                    d = json.loads(r.read().decode("utf-8", "replace"))
                it = (d.get("items") or [d])[0]
                real = it.get("product_title") or it.get("title", "?")
                print(f"  carrito  : {vid} agrega «{real}» a {it.get('price',0)/100:.2f}")
                if real.strip() != titulo.strip():
                    print(f"  [error] el carrito entrega OTRO producto: «{real}» en vez de «{titulo}»")
                    fallo = True
            except Exception as e:
                morir(f"no pude probar el carrito con {vid}: {e}")

    print()
    if fallo:
        print("  [error] ESTA LANDING COBRA OTRO PRODUCTO. No la publiques asi.")
        sys.exit(1)
    print("  [ok] la landing cobra el producto de su propia pagina")


if __name__ == "__main__":
    main()
