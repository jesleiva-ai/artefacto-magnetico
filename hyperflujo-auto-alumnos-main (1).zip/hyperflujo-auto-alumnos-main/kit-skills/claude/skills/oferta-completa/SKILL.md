---
name: oferta-completa
description: >-
  Arma la OFERTA terminada de un producto low ticket a partir de una
  investigación ya corrida y una referencia desarmada: promesa, mecanismo único
  con nombre propio verificado, stack de bonus atado a objeciones reales,
  garantía en lenguaje del mercado, ancla y auditoría final de las 5 claridades.
  Usar cuando el usuario diga /oferta-completa, "armá la oferta", "cerrá la oferta de
  X", "pasá de la investigación a la oferta", "armame el stack", o cuando
  /investigar-mercado terminó sus 4 archivos y falta producir la oferta final
  antes de /pricing y /maqueta-landing. Cada regla acá sale MEDIDA de ganadoras
  reales, no de teoría de marketing. Solo
  escribe borradores en _staging; jamás muta plataformas ni fija decisiones de
  negocio.
---

# Oferta completa — armado medido sobre ganadoras desarmadas

Esta skill existe porque las skills genéricas de oferta no alcanzan: se apoya en
las notas de [[moc-landings-y-ofertas]] y en una compra real desglosada de punta a punta
([[2026-07-28-nutritionsolved-front-y-backend]]). **Todo lo que esta
skill afirma se rastrea al corpus o a la investigación del producto. Si un
paso te tienta a escribir un consejo que no podés citar, no va.**

Encuadre que manda: **low ticket, compra por impulso, sin llamada de venta.**
Nada de lógica de mentoría, autoridad personal ni VSL larga.

## Frontera con las otras skills (el reparto, explícito)

- **/investigar-mercado** (pasos 3-4) produce la HIPÓTESIS: el archivo
  `3. Oferta - <Producto>.md` con promesa borrador, mecanismo candidato,
  candidatos a bonus, banda de precio, y el offer-audit con veredicto de
  cuello de botella. Eso es diagnóstico en amplitud. **No lo dupliques: lo
  profundizás.**
- **/oferta-completa** (esta) toma esa hipótesis + el desarme de la referencia
  modelada y produce la OFERTA TERMINADA, pieza por pieza, auditada. Escribe
  `5. Oferta armada - <Producto>.md` en la misma carpeta de staging.
- **/pricing** fija después el precio del front y la estructura económica
  (bump, upsells, downsell, AOV). Acá solo VALORIZÁS el stack (valores
  unitarios y ancla como suma); el precio final es de /pricing y la decisión
  es del dueño del cerebro.
- **/maqueta-landing** convierte la oferta en landing; **/evaluar-landing** la
  audita. Esta skill entrega una oferta que ya pasa las compuertas de oferta
  de evaluar-landing (2, 8, 10, 11, 12) para que la landing no nazca muerta.

**Compuerta de entrada:** si no existe `_staging/investigacion/<producto>/`
con los archivos 1-4, o no hay referencia desarmada/rayo-X, frená y corré
/investigar-mercado (o /desarme-completo) primero. Armar oferta sin
investigación es inventar; armarla sin referencia validada viola la compuerta
3 de evaluar-landing (la investigación produce hipótesis; el registro produce
validación).

## Arranque (barato, en orden)

1. HOT.md del cerebro y `04-lecciones/INDEX.md` (solo el índice; abrí una
   lección solo si su señal matchea). Regla dura 11: el hallazgo es tuyo, la
   decisión sobre su negocio es del dueño del cerebro.
2. Los 4 archivos de `_staging/investigacion/<producto>/`.
3. El desarme de la referencia que se modela, si lo hay (el copy verbatim, no un
   resumen).
4. [[formulas-de-copy-de-las-ganadoras]] y
   [[2026-07-28-marco-copy-visual-gatillos-solved]] — el criterio de
   frecuencia y la doctrina de naming.

## El criterio de frecuencia (qué es obligatorio y qué es opcional)

De [[formulas-de-copy-de-las-ganadoras]], medido sobre el copy verbatim de 13
referencias: **lo que aparece en 8-10 de 13 es ley del mercado** y va sí o sí;
**lo que aparece en 3 o menos es firma de un molde** — opcional, y ahí está el
diferencial si el molde matchea el avatar. En la oferta, son ley: la tríada de
fricción (8/13), el antes/con 5 y 5 sin features (9/13), el precio que mata
dos objeciones en una línea (8/13), el CTA en primera persona con el nombre
del producto (10/13), testimonios que citan el mecanismo (9/13). Son firma
de molde (frecuencia baja): culpa invertida (3/13), dolores bautizados,
garantía nombrada (1/13), bonus con precios alternados, ™ en todo, FAQ de
identidad profesional (4/13).

## Las piezas, en orden de construcción

### 1. Promesa

- Los 4 atributos, checklist uno por uno: cuantificable, sencilla, creíble
  para ESE mercado, transformadora ([[promesa-cuatro-atributos]], criterio
  validado de la casa). Si falla credibilidad local, se reformula antes de
  seguir.
- Transformación, nunca características ([[producto-vs-oferta-transformacion]]):
  si arranca en modo "PDF de 800 páginas", reescribila.
- Molde medido del hero (nutritionsolved, kinesiologiaresuelta): [resultado
  total] + [ventana mínima] + [prueba de pares con rol y número]. "Organize a
  Full Year of Nutrition Sessions In Just 5 Minutes · +500 nutritionists have
  already stopped improvising."
- En avatares profesionales la promesa nunca es plata: es tiempo recuperado y
  orgullo profesional (léxico Solved, marco §2). La monetización aparece solo
  en oficios/hobby (falegname, kits de manualidades).
- La promesa lleva número y plazo en el H1 o no pasa la compuerta 2 de
  evaluar-landing.

### 2. Mecanismo único con nombre propio

Sin nombre propio no es mecanismo, es promesa intercambiable (offer-audit de
investigar-mercado; acá se ejecuta el bautismo).

- Doctrina de naming medida (marco Solved §1): **el nombre es la promesa
  cumplida** — participio de resultado, nunca gerundio de esfuerzo
  ("Kinesiología Resuelta™", no "Curso de kinesiología"). Cuatro familias
  medidas en un censo de 155 landings ([[2026-07-28-marco-copy-visual-gatillos-solved]] §8): resultado declarado (X Solved/Resuelta),
  Sistema/Método + dominio + adjetivo aspiracional, Biblioteca/Megapack/Kit +
  dominio, franquicia numerada (X Ready: System 365).
- Número de completitud en nombre o subtítulo: 6 volúmenes, 360+ páginas,
  365, +6.000 proyectos — patrón transversal del registro entero.
- Jerarquía de sufijos (para que /pricing pueda anclar después): front =
  System/Toolkit; upsell = System/Pack (par del front, puede anclarse más
  caro); bonus = Guide/Mini System (subordinado, no canibaliza).
- ™ en producto, volúmenes y bonus: convierte una lista de PDFs en un
  catálogo de activos (firma del molde, 3/13 — usarla si el molde es
  infoproducto de sistema).

**Verificación de que el nombre no esté ocupado (obligatoria, en orden de
costo):**
1. Grep por el nombre y sus variantes en el cerebro (`02-notas/` y `_staging/`).
2. Biblioteca de Anuncios por el nombre exacto (MCP `ads_library_search` o
   /espia-ofertas): si un anunciante ACTIVO ya lo corre, hay colisión y se
   renombra.
3. Búsqueda web del nombre exacto entre comillas + chequeo del dominio.
Ojo con la inversa: que NADIE lo use no valida el ángulo
([[2026-07-28-ofertas-ausencia-no-es-oportunidad]]) — la verificación es solo
anti-colisión.

El nombre final es **decisión de marca del dueño del cerebro**: entregá 3-5 candidatos
verificados con su familia de naming, no uno elegido (regla dura 11; si él
pide N, van N).

### 3. Dolores bautizados (el activo diagnóstico de la oferta)

Tomá los 3-5 dolores CON CITA del archivo 2 (Avatar) y bautizalos: fórmula
medida `[artículo] "[sustantivo del oficio] + [estado negativo]"` + escena en
segunda persona (el "plan de rehab en blanco", la "búsqueda infinita de
ejercicios"; en EN: The Blank Plan Panic, The After-Hours Trap). Bautizar el
dolor lo vuelve diagnóstico: el lector se reconoce y la oferta pasa a ser el
tratamiento. Es firma del molde infoproducto (fórmula 9), no ley: usala
cuando el avatar es profesional o el dolor es recurrente y nombrable. Cada
escena tiene que trazarse a una cita real de la investigación — un dolor
bautizado sin cita es un dolor inventado.

### 4. Stack de bonus

Regla madre ([[stack-bonuses-oferta-irresistible]]): cada
bonus resuelve un problema FUTURO y concreto del cliente; bonus de relleno =
oferta diluida. Y la regla de diseño medida (fórmula 12 + marco §3.5): **cada
bonus ataca una microtarea DISTINTA del flujo del avatar** (entrada /
planificación / progresión / comunicación / seguimiento). Si dos bonus atacan
la misma etapa, uno sobra. Cada bonus se ata a una objeción o dolor CITADO de
la investigación — escribí al lado de cada uno qué objeción mata.

**Contención — cuántos van:** el canon del programa dice 5-7, hasta 10-15 si
se justifican ([[stack-bonuses-oferta-irresistible]]). El corpus medido dice
otra cosa: de las 14 desarmadas, 3 no muestran bonus, 3 usan 3, 2 usan 4, 4
usan 5, 1 usa 6 y solo una (megapack-pack-ia, que es bundle) usa 10. Como regla general, 5 bonus con landing corta alcanzan.
**Regla de la skill: 5 por defecto, rango 3-6; más de 6 solo con OK del dueño
del cerebro y solo si la oferta es bundle.** [PROPUESTA derivada del corpus —
el canon dice otra cosa; la decisión de fondo es del dueño.]

**Valorización medida:** unitarios US$10-17, variados entre sí y con total
no redondo (kinesio alterna 15/17/15/17/15 = 79 — la firma más fina, "nunca
redondo"; nutrition usa 10/12/15/10/12 = 59; también se ve el aplanado, por ejemplo 5×17 = 85).
Total del stack de bonus entre 1.5x y 3.5x el precio esperable del front
(medido: falegname 1.5x, nutrition 2.2x, megapack-claude 2.9x, ia-inmo 3.1x,
kinesio 3.4x; ~5x como tope). Presentación: [Nombre propio™] +
[beneficio de 1 línea] + [precio tachado] + GRATIS + [valor total].

**Bonus ≠ upsell**: el bonus va sobre la OFERTA — gratis, en
la landing, mata objeciones de la promesa principal. El upsell va sobre el
AVATAR — pago, post-checkout, deseo adyacente. Lo adyacente se reserva para
/pricing; regalarlo acá es regalar lo cobrable.

**Escuela alternativa medida** (fotofana): bonus de continuidad (updates,
comunidad, pedidos de diseños nuevos) en vez de bonus de contenido — sirve
cuando el producto es una biblioteca visual. Anotala como opción, no como
default.

### 5. Garantía

- **En lenguaje del mercado, nombrada, repitiendo la promesa** — fórmula
  medida: [VERBO DE LA PROMESA] O TE DEVOLVEMOS EL DINERO ("ORGANIZÁ TU
  PRÁCTICA O TE DEVOLVEMOS EL DINERO", "RECLAIM YOUR TIME OR YOUR MONEY
  BACK"). Es firma del molde (1/13) y "el detalle más barato de copiar de
  todos" (fórmula 11). Jamás "garantía de devolución" a secas.
- Plazo: 7 días es la moda del corpus (8+ de las 14); 15 días cuando el
  consumo del producto lo pide (falegname: "usalo de verdad 15 días
  completos"). Regla dura de evaluar-landing (compuerta 11): **la garantía
  cubre la entrega completa** — si algo se entrega el día 8, no puede ser de
  7 días.
- Canon de la casa ([[seguridad-prueba-social-garantia]]): la devolución en low
  ticket es bajísima — no tener miedo. Y el plazo en letra chica abajo, la
  promesa en mayúsculas arriba.

### 6. Ancla del front (la valorización; el precio lo fija /pricing)

- El ancla es el **valor apilado del stack**: suma creíble de componentes
  valorizados uno a uno, con razón del descuento declarada ("precio de
  lanzamiento" es la razón medida en el corpus).
- Banda medida sobre las 14: **2x a 5x para producto único** (recetas 2.0x,
  megapack-claude 2.1x, falegname 2.4x, zentrad 3.1x, screenfree 3.2x,
  ia-inmo 3.5x, cutify 3.75x, nutrition 4.8x, inventores 5x). Por encima de
  5x solo cuando la oferta es biblioteca/bundle y el ancla es suma de partes
  compradas por separado (fotofana 10.6x, megapack-pack-ia 15x "sueltos
  superan los $1.500"). La compuerta 8 de evaluar-landing acepta hasta 10x:
  apuntá a la mediana medida (~3.2x), no al tope de la compuerta.
- **Ancla externa de costo real verificable como refuerzo** (por ejemplo, un pack de planillas de finanzas personales:
  "un asesor financiero cobra, por ejemplo, $50-100 por consulta"; fotofana: "$350 por
  sesión de estudio"; megapack: "afuera $100-500 por curso"). Si es externa,
  tiene que ser comprobable (compuerta 4 de evaluar-landing).
- Contraejemplo medido para no repetir: kinesiologiaresuelta muestra
  RD$4.934.851 tachados contra RD$1.363 — un ancla rota por conversión de
  moneda (~3.600x). El molde no es infalible: verificá la conversión en cada
  moneda que se muestre.

### 7. Bloque de cierre de la oferta

Stack con ✓ (5 líneas: sistema + bonus + alcance + acceso + garantía) +
ancla + razón del descuento + "Pago único · Pagá en tu moneda local" (fórmula
5: mata suscripción y moneda en una línea) + CTA en primera persona que
nombra el producto ("QUIERO [NOMBRE]™" — 10/13, ley). Tríada de fricción
arriba de todo: Descarga inmediata · Sin suscripción · Acceso de por vida
(8/13, ley).

## Auditoría final (antes de entregar)

Corré las **5 claridades** del offer-audit — outcome concreto · entregable
claro · mecanismo único (por qué esto y no lo gratis) · para quién exactamente
· precio y alcance sin ambigüedad — pero acá en profundidad: cada una con la
frase exacta de la oferta que la responde. Si una claridad no tiene frase, la
oferta no está terminada. Sumá la ecuación de valor (el resultado soñado ya
viene alto: mové TIEMPO y ESFUERZO) y el chequeo de conciencia/sofisticación
contra el archivo 1.

Chequeo cruzado con evaluar-landing (para que la maqueta no nazca muerta):
promesa con número y plazo (2) · ancla en banda y comprobable (8) · bonus
nichados por microtarea (10) · garantía que cubre la entrega completa (11) ·
vocabulario de la casa (12).

## Entregable

`_staging/investigacion/<producto>/5. Oferta armada - <Producto>.md` con:
promesa final + 3 variantes, candidatos de nombre verificados (3-5), dolores
bautizados con su cita, stack de bonus con objeción atada y valorización,
garantía redactada, ancla con multiplicador declarado, bloque de cierre, y la
auditoría de 5 claridades respondida frase por frase.

**Cada afirmación marcada:** [V] medida en el corpus (con la referencia) ·
[I] inferida de la investigación (con la cita) · [DUEÑO] decisión pendiente
del dueño del cerebro. Nombres, valores del ancla y alcance del producto van SIEMPRE como
propuesta con alternativas — tocan marca y plata.

## Lo que JAMÁS hacés

- Escribir un consejo genérico de oferta que no puedas rastrear al corpus o a
  la investigación. "Usá un ancla atractiva" no vale; "2-5x medido en 9 de 14,
  mediana 3.2x" vale.
- Fijar vos un nombre, un precio de referencia o un alcance como decisión
  tomada: van como propuesta marcada [DUEÑO]
  (regla dura 11). Si pide N
  opciones, van N.
- Armar oferta sin investigación corrida o sin referencia desarmada: esta
  skill profundiza, no reemplaza a /investigar-mercado.
- Duplicar lo que ya hace investigar-mercado (investigación, avatar,
  creencias, veredicto de cuello de botella) o meterte en precio final, bump
  y upsells: eso es /pricing.
- Inventar dolores, testimonios, números de prueba social o anclas externas
  no comprobables: hueco marcado en ámbar, nunca contenido.
- Poner más de 6 bonus sin OK explícito del dueño del cerebro, o dos bonus que ataquen la
  misma microtarea.
- Decir "regalos apilados" o "ñapa": se dice **bonus** — la otra jerga es de
  un tercero y está rechazada explícitamente.
- Aplicar lógica high ticket: autoridad personal, discovery story, VSL larga,
  objeciones profundas de creencia.
- Escribir en el vault fuera de `_staging/`, hacer git commit/push, o tocar
  plataformas: /orden integra, vos dejás borradores.
