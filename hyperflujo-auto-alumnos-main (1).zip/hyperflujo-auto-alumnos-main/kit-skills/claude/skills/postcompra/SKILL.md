---
name: postcompra
description: >-
  Diseña y produce el funnel POSTCOMPRA de una oferta low ticket de producto
  digital: la escalera de upsells (OTO) y downsells con sus guiones, la página de
  cada oferta, el VSL de postcompra si aplica, la página de gracias y la entrega
  100 % digital (interactiva, sin depender de un PDF), los mails de carrito
  abandonado y de pago rechazado con tiempos y descuentos escalonados, los mails
  al comprador, y la medición (qué % toma cada pantalla, ticket promedio, neto a
  30 días). Usar cuando el alumno diga /postcompra, "armá el postcompra",
  "armá los upsells", "la página de gracias", "los mails de carrito",
  "recuperar carritos", "rescatar pagos rechazados", "OTO", "downsell",
  "cómo entrego el producto", o cuando /pricing terminó y falta producir las
  piezas del backend. Con compuertas: se diseña sobre una referencia que ya
  convierte, se audita antes de montar y no se publica, prende ni envía nada
  sin OK del dueño de la oferta.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Skill
---

# Postcompra: lo que pasa entre el pago y el acceso

El postcompra es la parte del negocio que más ticket agrega por comprador y la
única que la competencia no puede espiar: para verla te tiene que comprar
([[el-post-compra-es-lo-unico-que-no-te-copian]]). Con más ticket promedio
podés pagar más por cliente en Meta y ganar la puja
([[upsells-unit-economics]]).

**Pero solo multiplica lo que ya entra.** Si el frente no vende, el postcompra
multiplica cero. Por eso esta skill tiene compuertas y no se saltean.

Cada regla de este archivo viene de un postcompra de terceros que ya convierte,
desarmado pantalla por pantalla con sus videos transcriptos y sus tiempos
medidos, y de una secuencia de recuperación de carritos operada en vivo. Se
destiló la **estructura y el criterio**, no el caso. Procedencia de cada número:
**[V]** medido en un funnel de referencia · **[C]** canon del kit (nota del
cerebro citada) · **[P]** fuente pública citada · **[I]** hipótesis tuya, a
validar. Mezclarlas es el error que esta skill existe para evitar.

## Frontera con las otras skills

| Skill | Qué deja | Qué hace esta |
|---|---|---|
| /oferta-completa | promesa, mecanismo, stack, garantía | usa la MISMA garantía y el mismo mecanismo en todo el postcompra |
| /pricing | precio del front, bump, 3 upsells en tres dimensiones, downsells, escalera de fricción, AOV objetivo | **no vuelve a fijar precios**: toma la tabla de /pricing y produce las piezas. Si al escribir los guiones un precio no cierra, se devuelve a /pricing |
| /voz-cliente | frases reales del mercado | las usa en guiones y en el mail de objeciones |
| /metodo-6c | videos con persona de IA | produce los videos de los OTO si no los graba el alumno |
| /cobro-por-mercado | medios de pago por país | los mails de pago rechazado ofrecen esos medios |
| /maqueta-landing y /evaluar-landing | maqueta navegable y auditoría | las páginas de oferta se maquetan igual, como link privado |
| /compliance-checker | chequeo de políticas | pasada obligatoria sobre páginas y mails antes del OK |

**Orden de la cadena:** /investigar-mercado → /oferta-completa → /pricing →
**/postcompra** → /maqueta-landing → montaje.

**Entrada:** `_staging/investigacion/<producto>/6. Pricing - <Producto>.md`
(o la tabla de precios de una tienda que ya vende) + el desarme de la
referencia de postcompra. **Salida:** `7. Postcompra - <Producto>.md` en la
misma carpeta, más la subcarpeta `postcompra/` con guiones, maquetas y mails
(ver «Entregable»). Moldes listos para llenar en `moldes.md`; la lista de la
auditoría en `auditoria.md` (los dos en esta carpeta).

## Las cuatro compuertas

**C0 · La oferta ya vende.** Tasa de conversión del frente sostenida en banda
24-72 h ([[validacion-oferta-tasa-conversion]]; la vara está en /pricing). Sin
eso, frená: lo que falta es oferta, creativo o landing, no backend. Excepción
única: el alumno pide armarlo antes a sabiendas; se anota en una línea y se
sigue.

**C1 · Hay una referencia que ya convierte, desarmada.** El postcompra de un
tercero solo se ve comprando su oferta. Comprala, recorré cada pantalla diciendo
que sí y que no (en dos compras si hace falta) y guardá en
`~/fuentes/desarmes/<referencia>/postcompra/`: la escalera (producto, precio,
tachado, ancla dicha en voz, hueco que tapa), el segundo exacto en que aparece
el botón, los guiones transcriptos, el texto de cada downsell y las
inconsistencias. Usá /desarme-completo y /landing-xray para la parte pública.
**Sin referencia no se diseña**: un postcompra inventado es hipótesis pura.
Si el alumno no puede comprar ninguna, se usa la estructura de esta skill y se
marca todo el entregable como [I].

**C2 · Auditoría antes de montar.** Antes de cargar una sola pantalla en la
plataforma, el diseño completo pasa `auditoria.md` punto por punto. Un punto
en rojo frena el montaje.

**C3 · Nada sale sin OK del dueño.** Ni prender embudos, ni publicar páginas,
ni activar secuencias de mails, ni mandar un solo mail real (tampoco reenviar
carritos viejos). Los embudos se dejan creados en pausa y las secuencias en
borrador. Precios, descuentos, nombres de producto y gatillos de presión son
decisiones del dueño, siempre (reglas duras 10 y 14 del cerebro).

## Paso 1 · El mapa de huecos (antes de pensar en productos)

La palanca de un postcompra que multiplica el ticket no es la ruleta ni la
actuación: **el frente resuelve una parte a propósito y nombra la otra, y cada
oferta tapa el hueco siguiente en el orden en que le va a pasar al comprador**
[V]. Ninguna oferta compite con otra.

1. Escribí qué resuelve el frente y qué deja **a la vista sin resolver**. Si
   el frente ya resuelve todo, el OTO 1 va a sonar a extra y no a «la otra
   mitad»: avisale al alumno, es una decisión de oferta (va a /oferta-completa).
2. Listá 4 huecos en orden de aparición. Un orden que funciona [V]:
   **el resultado** (la otra mitad) → **lo que lo hace abandonar** (miedo a
   hacerlo mal, a no poder solo) → **hoy mismo** (algo que puede usar antes de
   empezar) → **la duda que no se anima a preguntar** (lo que el comprador
   no pregunta en voz alta). Para un producto de oficio o de hobby que factura, otro orden:
   qué vender siempre nuevo → a quién → dónde mostrarlo → cuánto cobrar.
3. Cruzá cada hueco con los seis tipos de oferta de postcompra (complemento
   necesario, acelerador, prevención de errores, versión hecha por vos,
   paquete, membresía) de [[las-seis-ofertas-del-post-compra]] y con las tres
   dimensiones de /pricing. Si dos huecos caen en el mismo tipo, sobra uno.
4. Cada producto se decide en ~30 caracteres de título + un mockup chico, y
   cada título dice algo distinto ([[upsell-treinta-caracteres-y-mockup]]).

## Paso 2 · La escalera

Cada «sí» salta al OTO siguiente; cada «no» va a su downsell y de ahí al OTO
siguiente. El último «no» lleva al acceso.

- **El OTO 1 es «más de lo mismo» o «la otra mitad», nunca un tema nuevo.** Es
  el que trae casi toda la plata: en un funnel medido, cerca de 9 de cada 10
  dólares del postcompra salieron del OTO 1 y su downsell [V].
- **La oferta más cara va segunda**, con la confianza arriba, y vende
  **acceso** (acompañamiento, revisión, grupo) comparado contra una consulta,
  no contra un ebook [V]. **Pero sobre el mismo tema:** en otro funnel medido,
  un servicio caro y distinto en el paso 2 lo tomó menos del 1 % y cortó la
  escalera [V]. Lo caro y distinto no vende.
- **La más barata va última**, cuando ya está cansado de decidir [V].
- **El downsell es el MISMO producto más barato**, con un ángulo nuevo, no la
  misma promesa repetida. El porcentaje lo fija /pricing (la referencia medida
  usa la mitad [V]). Alternativa de practicantes: una versión reducida en vez
  de descuento, para que el «no» no le enseñe que rechazar abarata [I].
- En un funnel medido, **el downsell 1 convirtió igual que el OTO 1** [V]:
  quien dice que no está diciendo «es caro», no «no me interesa». Por eso el
  downsell aísla el precio.
- **Nunca le ofrezcas lo que ya tiene.** Si la plataforma dispara el embudo
  por carrito exacto, armá un embudo por cada combinación posible de
  checkout (con y sin bump) ([[el-embudo-post-compra-en-impultienda]]).
- **Los videos se acortan** pantalla tras pantalla: el primero 2-5 min con
  todos los golpes; desde el tercero, ~1 min [V].
- **Ningún video da por hecho que compró el anterior**: lo escucha también el
  que dijo que no [V].

## Paso 3 · El guion de cada OTO

Golpes en orden (molde completo en `moldes.md`): **frenar** («tu acceso ya
está confirmado», pedir un rato) → **un problema que lo comprado NO
resuelve** → **una escena que reconoce** → **sacarle la culpa** → **el
mecanismo con nombre propio** que explica el fracaso → **nombre del producto**
atado a lo que ya compró → **por qué existe solo acá** → **contenido
numerado** → **escena de futuro** → **ancla y precio** («por separado
costaría…, hoy solo…», pago único) → **sin fricción** (un clic, sin volver a
poner la tarjeta) → **garantía, la misma de todo el funnel** → **por qué
ahora, con razón verdadera** → **cierre: qué botón tocar** y una cita a
futuro.

- Desde el OTO 3 se saltean mecanismo y «por qué ahora»; esos golpes pasan a
  la página. Nunca se saltean: frenar, problema, nombre, ancla, precio,
  garantía y botón [V].
- El tono sube de a poco y promete el final («es la penúltima cosa que te
  muestro», «una última cosa y te dejo ir») [V]. Prometer el final y cumplirlo.
- Las escenas salen de /voz-cliente: escenas concretas venden, conceptos no.
- **Downsell en 4 golpes**: reconocer el «no» y darle permiso de irse →
  aislar el precio («pero si fue por el precio…») → **una razón NUEVA** (el
  momento exacto en que le va a doler) → el descuento + «es exactamente lo
  mismo, solo cambia el precio» [V].
- El «no» de cada pantalla es chico, gris, y dice lo que pierde («No, gracias:
  sigo haciéndolo a ojo»). El último «no» dice adónde lleva («llevame a mi
  acceso») [V].

## Paso 4 · La página de cada oferta

| Elemento | Para qué | Cómo |
|---|---|---|
| Barra de pago aprobado | calmar: ya pagó y es suyo | franja verde arriba, solo en la primera pantalla |
| Pasos | que vea que falta poco | «Compra ✓ · Pago ✓ · Tu regalo · 2 · 3 · 4 · Acceso»: la oferta se llama «Tu regalo», nunca «upsell» [V] |
| Aviso de arriba | que no cierre | versión honesta: «Tu acceso ya es tuyo. Esta página aparece una sola vez» (ver «Gatillos») |
| Video | que arranque solo | arranca sin sonido con «Tocá para escucharlo»; al tocar **vuelve a 0:00** con sonido [V] |
| Bloque de compra escondido | que decida después de escuchar el precio | aparece cuando el video dice el precio, con respaldo por reloj si no mira (ver abajo) |
| Reloj de reserva | urgencia sin mentir | minutos de reserva; al llegar a 0, «tu reserva se mantuvo» |
| Botón de sí en dos líneas | arriba lo que quiere, abajo el cobro | «SÍ, SUMALO A MI PEDIDO» / «Agregar [producto] por [precio]» [V] |
| Sellos al pie | confianza | pago seguro · misma garantía · acceso inmediato |
| Aviso al cerrar la pestaña | — | **apagado**: molesta más de lo que retiene [V] |

**Cuándo aparece el botón (lo que más cambia el resultado).** Dos opciones
medidas: (a) con el producto, por reloj desde que carga, 47-64 s antes de que
se diga el precio [V]; (b) con el precio, ~1 s antes del número, con respaldo
por reloj. En un funnel medido, adelantar el botón ~60 s bajó la toma del
OTO 1 de cerca de 4 de cada 10 a 3 de cada 10 [V] (antes y después, no
experimento controlado). **Por defecto, opción (b)**; si el alumno quiere
probar la (a), con el mismo tráfico y midiendo las dos. Ojo: si el reloj no
se reinicia cuando el comprador activa el sonido, el botón cae antes en el
guion de lo planeado [V].

**Precios: la página no cobra, cobra el panel.** Si los precios están escritos
a mano en la página, cargá los mismos en la plataforma y verificá en el
recorrido real que muestra lo que cobra [V]. Tachados = el precio «por
separado» que dice el video; tachado y voz distintos es una inconsistencia
[V]. Tuteo o voseo: uno solo, igual en video y página.

## Paso 5 · El VSL de postcompra (si aplica)

- Formato medido [V]: vertical, una sola toma cara a cámara, misma persona en
  todos los OTO, sin música, sin cortes, subtítulo de una palabra en
  mayúsculas. La persuasión está en el guion y la mecánica, no en la
  producción.
- Los downsells no llevan video: texto + oferta [V].
- Si el alumno no graba, /metodo-6c. Una persona de IA cuenta la experiencia
  del método; **nunca se atribuye títulos, consultas ni credenciales que no
  tiene**.
- Sin video también funciona: los golpes pasan al texto de la página, con el
  bloque de compra después del precio.

## Paso 6 · La página de gracias y la entrega 100 % digital

El acceso es la última pantalla del postcompra y la primera experiencia del
producto. Criterio [C]: el formato no es el valor
([[el-formato-del-entregable-no-es-el-valor]]) y todo debe aguantar 100
ventas por día sin tocarlo ([[el-low-ticket-se-entrega-una-sola-vez]]).

- **Entrega como página interactiva, no como PDF.** Cada producto y cada bonus
  es una página web con la estética del producto: índice que marca lo leído,
  herramientas que se usan en el momento (cronómetro, lista para tildar,
  tarjetas, calculadora, ejercicio paso a paso), lo marcado guardado en el
  teléfono. Cero botones de «descargar el PDF»: si el alumno decide entregar
  todo digital, barré después que ninguna página enlace un PDF.
- **Una sola página de acceso** con todo lo comprado y, debajo, lo que no
  compró como bloque bloqueado con botón para comprarlo suelto a precio de
  lista. Es un backend sin tope de productos [C, [[upsells-unit-economics]]].
- **Desbloqueo:** si lo comprado se marca solo en el teléfono, quien abre el
  mail en un navegador y vuelve desde otro ve «comprar» aunque pagó. Plan
  sano: desbloqueo por el mail de compra [I].
- **Nunca se cobra algo que todavía no existe.** Un producto del postcompra
  que entrega «en preparación» es una promesa sin entrega: o se arma antes de
  prenderlo, o se avisa en la oferta el plazo real y se cumple.
- **Una cita a futuro** (el primer paso, el día 1) que le dé a todo el
  postcompra un «antes de que empieces» real [V].
- **El canal propio va acá**: la página de gracias suele ser el único lugar
  donde la plataforma deja poner links libres (comunidad, WhatsApp, soporte)
  ([[el-embudo-post-compra-en-impultienda]]).
- Si la tienda vende en varios idiomas, cada pieza la adapta un nativo; un
  texto que comparten dos países del mismo idioma va sin regionalismos de uno
  solo.

## Paso 7 · Los mails

Tres secuencias distintas, porque son tres problemas distintos. La herramienta
es la de mails del alumno (ej. Brevo o MailerLite), conectada a la tienda por
eventos. Si la plataforma no deja editar sus propios mails, la base se exporta
y todo se hace afuera ([[el-embudo-post-compra-en-impultienda]]).

### 7a · Carrito abandonado: convencer, el mismo día

Es una compra por impulso: se enfría en horas. Estructura de tiempos desde el
abandono [V]: **10 min · 1 h · 2 h · 12 h · 24 h**, y ahí se termina. El primer
mail dentro de la primera hora convierte cerca de 20 % contra cerca de 12 % a
las 24 h o más [P: Barilliance, 200 tiendas].

Descuento escalonado: **sube en los tres primeros mails y se queda en el techo**
(ejemplo, a decidir por el dueño: 20 % · 30 % · 40 % · 40 % · 40 %). El techo
se dice («más que esto no damos») y es verdad.

| Mail | Rol |
|---|---|
| 1 · 10 min | cierra lo que quedó abierto mientras está caliente; nombra el freno real; caja «¿el pago no pasó?» con los medios de pago del país |
| 2 · 1 h | **regala un pedazo real del producto** (una lección, una herramienta, la primera parte completa): el que lo prueba ya sabe lo que compra. Es el mail estrella |
| 3 · 2 h | el dolor en movimiento, paso a paso; descuento al techo |
| 4 · 12 h | la frase textual del mercado (de /voz-cliente, citada como «lo leímos en foros», nunca como testimonio propio) + las 4 objeciones de siempre resueltas |
| 5 · 24 h | el último, honesto: aversión a la pérdida, dice que es el último y lo es |

### 7b · Pago rechazado: destrabar, no convencer

Quien recibe este mail ya quiso comprar y el banco lo frenó. **2 mails, sin
descuento: 30 min y 2 h** [V]. A los 30 min y no a los 5, porque mucha gente
reintenta sola en la primera media hora. Mail 1: «no se te cobró nada» (es lo
que frena el segundo intento), la causa en criollo y los medios locales del
país (/cobro-por-mercado). Mail 2: escrito como una persona, ofrece otro medio
(si falló dos veces con el mismo, el tercero no es con ese) y pide una captura
del error para resolverlo a mano. Si la plataforma no manda el evento de
rechazo a la herramienta de mails, hace falta un aviso propio (webhook).

### 7c · Al comprador [I, estructura propuesta, no medida]

Inmediato: el acceso y cómo abrirlo en otro dispositivo · día 1: «¿pudiste
entrar?» + el primer paso · día 3: un resultado rápido + lo que no tomó en el
postcompra, a precio de lista · día 7: pedido de testimonio real (es la única
fuente legítima de prueba social, [[seguridad-prueba-social-garantia]]).

### Reglas de todos los mails

- Un solo botón por mail, con link de respaldo debajo.
- El descuento ya aplicado en el link, nunca un código para copiar.
- **La salida por «compra hecha» es lo primero que se configura**: nadie
  recibe «te quedaste a mitad de camino» después de pagar.
- UTM por mail (fuente, secuencia, número). Si la plataforma redirige el link,
  probá que la UTM llegue al pedido: hay redirecciones que la pierden [V].
- Fuera de Promociones: sin «gratis», «regalo» ni precios en el asunto; una
  imagen grande sin texto adentro.
- Nicho sensible: leé la política pública de la herramienta de mails antes de
  escribir; varias suspenden la cuenta entera por contenido explícito [P].
- Nada inventado: la prueba social es un número real redondeado para abajo;
  la urgencia, el vencimiento real del link.
- Consentimiento: si el checkout no tiene casilla y se vende en mercados con
  ley de datos estricta, mandar igual es un riesgo legal que decide el dueño.
- Probá cada secuencia con un contacto de prueba y **leé el mail entregado**
  (remitente, link, descuento, idioma), no el «activo» del panel.
- Reenviar carritos viejos: antes, cruzá contra pedidos aprobados por mail
  (muchos rechazados reintentaron y pagaron). Nunca envío masivo sin OK.

## Paso 8 · La medición

| Qué | Cómo | Para qué |
|---|---|---|
| Toma por pantalla | aceptadas ÷ mostradas, OTO por OTO y downsell por downsell | la que da cero se itera (título, mockup, guion), no se saca [C] |
| Retención del video | % que sigue mirando en el segundo del botón | si se van antes del precio, el problema es el guion |
| Ticket promedio | ingresos totales (frente + bump + postcompra) ÷ pedidos | la vara contra el CPA ([[primero-el-ticket-promedio-despues-la-escala]]) |
| $ por visita de cada nodo | ingresos del nodo ÷ vistas | compara pantallas de precios distintos |
| **Neto por comprador a 30 días** | postcompra − reembolsos − contracargos − comisión | el número que decide; un gatillo que sube la toma y los contracargos puede restar |
| Toma por medio de pago | separado | algunos medios locales no permiten el sí de un clic: quien paga así no puede tomar el upsell con un toque |
| Mails: ventas rescatadas | recibió mail y compró, cruzando por mail (techo) y compró por el link del mail (piso) | las dos cifras, siempre |
| Mails: clic sobre entregados | mail por mail | la apertura miente (hay proxies que abren solos) |
| Mails: bajas y spam | por mail y por mercado | un mercado que se da de baja de más pide otro tono |
| Grupo de control | una parte de los carritos no recibe nada | la única forma de saber cuántos habrían comprado igual |

Referencias [C, [[el-post-compra-es-lo-unico-que-no-te-copian]]]: OTO 1 low
ticket 10-30 %; más del 10 % de toma del postcompra es piso sano; el techo
visto ronda 45 % y no conviene apuntar ahí. **Prendelo y no lo toques 72 h**
antes de sacar conclusiones.

## Gatillos de presión: la versión honesta por defecto

| Lo que hacen muchos funnels | Riesgo | La versión que conserva el efecto |
|---|---|---|
| «Si salís, se te puede cobrar dos veces», avisos que suben de tono (bloqueo de acceso, días de soporte) | no es cierto: el pago ya entró. Publicidad engañosa según leyes de defensa del consumidor y criterio de dark patterns; más contracargos | «Tu acceso ya es tuyo. Esta página aparece una sola vez» (en postcompra es verdad: no vuelve) |
| Ruleta que siempre cae en el mismo número, con «casi ganás» | aparenta azar donde no lo hay | el descuento directo, o una ruleta que dice que el premio es fijo |
| Precio «normal» de algo que nunca se vendió suelto | ancla inventada | «por separado costaría…», y que sea el precio al que se vende suelto en la página de acceso |
| Presentadora con títulos o consulta que no tiene | usurpación de título; con persona de IA, peor | la experiencia del método, sin credenciales |
| Garantía distinta en video y página | reclamos | la misma en todos lados |

**Por defecto se arma la versión honesta** (coincide con /pricing: la
estructura se copia, la amenaza no). Usar gatillos fuertes es **decisión del
dueño**, por escrito, con el riesgo a la vista y en una línea al lado del
entregable. **Si el dueño ya lo decidió con el riesgo a la vista, no se le
vuelve a proponer la versión suave en cada pasada**: se anota como dato en una
línea, no como falla. Siempre afuera, decida lo que decida: promesas de salud
o resultados garantizados, credenciales falsas, contenido explícito en
plataformas que lo prohíben, testimonios inventados.

## Entregable

`_staging/investigacion/<producto>/7. Postcompra - <Producto>.md` con:

1. **Mapa de huecos** y la referencia usada (ruta del desarme).
2. **Tabla de la escalera**: pantalla · producto · título de 30 caracteres ·
   hueco · tipo de oferta · precio y tachado (de /pricing) · si dice no ·
   largo del video · segundo del botón · procedencia de cada número.
3. **Guiones** de cada OTO marcados golpe por golpe (dónde aparece el botón) y
   texto de cada downsell, en `postcompra/guiones/`.
4. **Maqueta** de cada página como link privado (con /maqueta-landing).
5. **Plan de entrega**: página de acceso, piezas interactivas, desbloqueo.
6. **Mails**: las tres secuencias con asunto, vista previa, cuerpo, botón,
   espera y descuento, en `postcompra/mails/`.
7. **Plan de medición** con fecha de la primera lectura (72 h después de
   prender).
8. **Auditoría** (`auditoria.md`) respondida punto por punto.
9. **Decisiones del dueño**, en bloque aparte: precios, descuentos, nombres,
   gatillos, consentimiento de mails, fecha de encendido.

## Lo que JAMÁS hacés

- Diseñar el postcompra de una oferta que no vende, o sin referencia
  desarmada, sin marcarlo todo como hipótesis.
- Prender un embudo, publicar una página, activar una secuencia o mandar un
  mail real sin el OK del dueño. Los embudos quedan en pausa; los mails, en
  borrador.
- Fijar precios o descuentos: vienen de /pricing y los decide el dueño.
- Un OTO 1 de tema nuevo, o un paso 2 caro y distinto.
- Videos que dan por hecha la compra anterior, garantías distintas entre
  pantallas, tachados que no coinciden con lo que dice la voz.
- Cobrar un producto que todavía no existe o entregar con «llega en unos
  días» sin decirlo en la oferta.
- Entregar con PDF como pieza principal cuando la entrega puede ser
  interactiva, o dejar botones de PDF después de decidir «todo digital».
- Inventar prueba social, anclas, testimonios o contadores.
- Usar gatillos fuertes sin decisión escrita del dueño, o reabrirle esa
  decisión una vez tomada.
- Dar por funcionando algo porque el panel dice «activo»: se verifica con el
  recorrido real (pantalla, cobro, mail entregado).
- Escribir fuera de `_staging/`, hacer git commit o push, o tocar
  plataformas por tu cuenta: /orden integra, vos dejás borradores.
