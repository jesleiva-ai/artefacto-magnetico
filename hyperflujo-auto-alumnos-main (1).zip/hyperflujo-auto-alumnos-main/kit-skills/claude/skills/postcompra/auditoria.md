# Auditoría del postcompra (compuertas C2 y C3)

Se responde punto por punto, con la evidencia al lado (la frase del guion, la
captura de la pantalla, el mail entregado). Un punto en rojo frena. «No
aplica» se justifica en una línea.

## C2 · Antes de montar (sobre el diseño)

**Base**
- [ ] El frente vende en banda 24-72 h (o el alumno aceptó por escrito armarlo antes).
- [ ] Hay referencia que convierte, desarmada, con su ruta anotada (o todo el entregable está marcado [I]).
- [ ] Los precios salen de /pricing y están en el bloque «Decisiones del dueño».

**Escalera**
- [ ] El OTO 1 es «más de lo mismo» o «la otra mitad», no un tema nuevo.
- [ ] La oferta más cara va segunda y sobre el mismo tema.
- [ ] La más barata va última.
- [ ] Cada oferta tapa un hueco distinto, en el orden en que le pasa al comprador.
- [ ] Cada downsell es el mismo producto que su OTO, con un ángulo nuevo.
- [ ] Hay un embudo por cada carrito posible: nadie ve un producto que ya tiene.

**Guiones y páginas**
- [ ] Cada video tiene frenar, problema, nombre, ancla, precio, garantía y botón.
- [ ] Ningún video da por hecha la compra anterior.
- [ ] Los videos se acortan pantalla tras pantalla.
- [ ] La garantía dice lo mismo en todos los videos, páginas y mails.
- [ ] El tachado de cada página es el «por separado» que dice la voz.
- [ ] Un solo trato (tuteo o voseo) en video y página.
- [ ] El botón aparece donde dice el diseño (con el precio por defecto), con respaldo por reloj.
- [ ] Cada «no» dice lo que pierde; el último dice adónde lleva.
- [ ] Aviso al cerrar la pestaña apagado.
- [ ] Gatillos: versión honesta, o decisión escrita del dueño anotada en una línea.
- [ ] Ninguna persona (real o de IA) se atribuye títulos o credenciales que no tiene.
- [ ] Ninguna promesa de salud ni resultado garantizado.

**Entrega**
- [ ] Cada producto del postcompra existe y se entrega hoy (nada «en preparación» sin plazo dicho en la oferta).
- [ ] La entrega es una página interactiva; si se decidió «todo digital», cero links a PDF.
- [ ] La página de acceso muestra lo comprado y ofrece lo no comprado a precio de lista.
- [ ] Todo aguanta 100 ventas por día sin intervención manual.

**Mails**
- [ ] Carrito y pago rechazado son secuencias separadas.
- [ ] Salida por «compra hecha» configurada antes que cualquier mail.
- [ ] Descuento aplicado en el link; un botón por mail; UTM por mail.
- [ ] Asuntos sin «gratis», «regalo» ni precio.
- [ ] Nada inventado: prueba social real, vencimiento real.
- [ ] Contenido dentro de la política de la herramienta de mails.
- [ ] Consentimiento revisado para los mercados donde se vende (el riesgo, si queda, lo decidió el dueño).
- [ ] /compliance-checker corrido sobre páginas y mails.

## C3 · Antes de pedir el OK (sobre lo montado, todavía en pausa)

- [ ] Recorrido real completo diciendo que sí a todo y otro diciendo que no a todo, en celular: cada pantalla aparece en orden y el último paso lleva al acceso.
- [ ] El precio que muestra cada pantalla es el que cobra la plataforma.
- [ ] El sí de un clic cobra sin volver a pedir la tarjeta (con una compra real o el modo de prueba de la pasarela), y anotado con qué medios de pago no funciona.
- [ ] Los links de entrega de cada producto abren (sin 404) desde un navegador distinto al de la compra.
- [ ] Cada secuencia de mails probada con un contacto de prueba: el mail entregado se leyó entero (remitente, idioma, link, descuento, UTM que llega al pedido).
- [ ] Plan de medición con fecha de primera lectura a las 72 h, cargada en el calendario del alumno.
- [ ] Bloque «Decisiones del dueño» presentado: precios, descuentos, nombres, gatillos, consentimiento, fecha de encendido.

Recién con todo en verde se pide el OK. Con el OK, se prende lo que el dueño
dijo, se relee el estado en la plataforma (prendido de verdad) y se deja
anotado qué se prendió y cómo volver atrás.
