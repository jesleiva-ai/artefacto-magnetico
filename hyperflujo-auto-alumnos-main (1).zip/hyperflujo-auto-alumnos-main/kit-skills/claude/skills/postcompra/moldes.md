# Moldes del postcompra

Moldes para llenar. Todo lo que va entre [corchetes] sale de la investigación,
de /voz-cliente, de /oferta-completa o de /pricing; si no tenés de dónde
sacarlo, se deja el hueco marcado, nunca se inventa. Los ejemplos están
marcados como ejemplo y son de un producto ficticio (un curso de cerámica en
casa).

## 1 · Guion de un OTO (golpe por golpe)

| # | Golpe | Qué hace | Molde |
|---|---|---|---|
| 1 | Frenar | lo para antes de que busque la salida | «Esperá, no cierres esta página. Tu acceso a [frente] ya está confirmado y va camino a tu correo. Te pido [N] minutos: hay algo que muestro solo ahora.» |
| 2 | Problema | algo que lo comprado NO resuelve y que va a aparecer sí o sí; completa el producto, no lo critica | «Con [frente] vas a [primer resultado]. Pero al [momento] va a pasar algo que nadie te avisa: [problema].» |
| 3 | Escena | una escena concreta que reconoce | «[escena con objetos, lugar y momento del día, en palabras del mercado]» |
| 4 | Sacar la culpa | si el problema es suyo se defiende; si es del mundo, escucha | «No es falta de ganas. Es [causa externa].» |
| 5 | Mecanismo | le pone nombre al problema | «Yo lo llamo [nombre propio del problema].» |
| 6 | Nombre | el producto como respuesta, atado a lo que compró | «Por eso armé [producto]. Usa el mismo [método/material] que ya tenés: no aprendés nada de cero.» ← **acá puede aparecer el botón si usás la opción (a)** |
| 7 | Solo acá | razón lógica para que exista solo en esta página | «No lo vendo suelto: recién tiene sentido cuando ya tenés [frente].» |
| 8 | Contenido | qué se lleva, numerado, con un dato vendedor por punto | «Uno: [ítem + dato]. Dos: […]. Tres: […]. Y de regalo, [bonus chico].» |
| 9 | Futuro | la escena del principio, resuelta | «Imaginate [la misma escena], pero [resuelta].» |
| 10 | Ancla y precio | primero «por separado», después el precio de hoy | «Por separado costaría [tachado]. Para quienes recién entran, solo [precio].» ← **opción (b): el bloque de compra aparece ~1 s antes del número** |
| 11 | Sin fricción | saca la última excusa | «Un solo pago, sin suscripción. Como tu pedido ya está hecho, lo sumás con un toque: no volvés a poner la tarjeta.» |
| 12 | Garantía | la misma de todo el funnel | «Tiene la misma garantía de [N] días que [frente]. Si no te sirve, nos escribís y te devolvemos todo.» |
| 13 | Comparación (opcional) | contra un gasto que ya conoce | «Una [clase/consulta/servicio] cuesta más que eso por una sola vez.» |
| 14 | Por qué ahora | razón verdadera | «Esta página aparece una sola vez.» |
| 15 | Cierre | qué botón tocar y una cita a futuro | «Tocá el botón que dice "sí, sumalo a mi pedido". Nos vemos en [primer paso].» |

- OTO 1: todos los golpes, 2-5 minutos.
- OTO 2: frenar, escena, culpa, nombre, contenido, comparación, precio,
  garantía, cierre. ~1-2 min.
- OTO 3 y 4: frenar, problema, nombre, contenido, precio, cierre. ~1 min.
  Prometé el final: «es la penúltima cosa que te muestro» / «una última cosa
  y te dejo ir».

**Ejemplo (producto ficticio), golpe 2-3:** «Tus primeras piezas van a salir
lindas. Pero al segundo mes, las mismas personas que te compraron dejan de
pedir: tenés el estante lleno y nada nuevo para mostrar.»

## 2 · Texto de un downsell (sin video)

```
[ARRIBA, chico]   Esperá. Una última cosa.
[TITULAR]         [El momento exacto en que le va a doler, en una línea].
                  Llevate [producto] a [precio del downsell].
[RAZÓN]           Si no te interesa, cerrá tranquilo. Pero si fue por el precio:
[GOLPE NUEVO]     [Ángulo nuevo: no la misma promesa más barata, sino cuándo le va a hacer falta].
[LISTA ✓]         [3 ítems: lo mismo que el OTO]
[TRANQUILIDAD]    Es exactamente lo mismo. Solo cambia el precio.
[BOTÓN SÍ]        SÍ, LO QUIERO A [precio]
                  Agregar [producto] por [precio]
[NO, chico]       No, gracias: [lo que pierde, mismo texto que en su OTO]
```

El tono de arriba sube de a poco: «Una última cosa» → «Antes de irte, una
última opción» → «Última página. Último precio».

## 3 · Ficha de cada página de oferta

```
Pantalla:         OTO [n] / DS [n]
Barra arriba:     [solo OTO 1: «Pago aprobado · [frente] ya es tuyo»]
Pasos:            Compra ✓ · Pago ✓ · Tu regalo · 2 · 3 · 4 · Acceso
Aviso:            [versión honesta o la que decidió el dueño por escrito]
Rótulo del video: [«Un mensaje corto de [persona]»]
Video:            [archivo] · [duración] · arranca sin sonido · al tocar vuelve a 0:00
Bloque escondido: aparece en [segundo del precio] · respaldo por reloj: [segundos]
Título (≤30):     [título]
Resultado:        [una frase]
Lista ✓:          [4 ítems]
Precio:           [tachado] → [precio] · «pago único»
Reloj de reserva: [minutos]
Botón sí:         [línea 1 en mayúsculas] / [Agregar … por …]
No:               [lo que pierde] → va a [pantalla siguiente]
Sellos:           Pago seguro · [N] días de garantía · Acceso inmediato
Cargado en panel: [precio igual al de la página: sí/no]
```

## 4 · Mails de carrito abandonado

Ficha por mail:

```
Mail [n] · espera [10 min | 1 h | 2 h | 12 h | 24 h] · descuento [x %, lo decide el dueño]
Asunto:        [≤45 caracteres, sin «gratis», «regalo» ni precio]
Vista previa:  [completa el asunto, no lo repite]
Imagen:        [una, grande, sin texto adentro]
Cuerpo:        [según el rol de abajo]
Botón:         [verbo en primera persona] · link con el descuento aplicado + UTM
Respaldo:      [link en texto debajo del botón]
Salida:        si hay compra, sale de la secuencia
```

| Mail | Rol | Molde del cuerpo |
|---|---|---|
| 1 | cerrar lo abierto | Hola [nombre]. Te quedaste a un paso de [resultado]. [El freno real, nombrado]. [La pregunta que duele]. Te dejamos [x %] ya aplicado. Caja: «¿El pago no pasó? Probá con [medios locales]». |
| 2 | probar un pedazo real | [Un pedazo real y usable del producto, copiado del producto]. «Esto es [la parte 1]. Imaginate [la parte final].» Cómo sigue el producto en etapas. [x %]. |
| 3 | dolor en movimiento | [El problema, contado como proceso, paso a paso]. Lo que trae, en lista. «[x %]: más que esto no damos.» Vence [fecha real del link]. |
| 4 | voz del cliente | Título = [frase textual del mercado, de /voz-cliente]. «Lo leímos en foros, en todos lados.» El mecanismo que saca el peso. Las 4 dudas de siempre: [la duda de confianza, la de formato o entrega, si es suscripción, garantía]. |
| 5 | el último, honesto | [La escena del dolor]. «Dentro de un año vas a tener [el después] o [lo mismo de siempre].» «Es el último mail.» El descuento vence. |

## 5 · Mails de pago rechazado (sin descuento)

| Mail | Espera | Asunto (molde) | Cuerpo |
|---|---|---|---|
| 1 | 30 min | «Tu pago no pasó (y no es tu culpa)» | «No se te cobró nada.» La causa en criollo (el banco frena compras online o al exterior). «Si llegaste hasta el pago, lo más difícil ya lo hiciste.» Medios locales del país. Botón: «Intentar de nuevo». |
| 2 | 2 h | «¿Pudiste resolver lo del pago?» | Escrito como persona. Otro medio de pago. «Respondé con una captura del error y lo resolvemos con vos.» Botón: «Terminar mi compra». |

## 6 · Mails al comprador [I, estructura a validar]

| Cuándo | Qué |
|---|---|
| Inmediato | El acceso (un botón), cómo abrirlo desde otro dispositivo, a quién escribir. |
| Día 1 | «¿Pudiste entrar?» + el primer paso concreto (la cita a futuro del postcompra). |
| Día 3 | Un resultado rápido + lo que no tomó en el postcompra, a precio de lista. |
| Día 7 | Pedido de testimonio real (texto o foto del resultado), con permiso explícito para usarlo. |
