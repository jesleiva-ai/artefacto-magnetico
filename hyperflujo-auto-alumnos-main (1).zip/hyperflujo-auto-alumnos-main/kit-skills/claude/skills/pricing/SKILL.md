---
name: pricing
description: >-
  Arma el precio y la estructura económica completa de una oferta low ticket:
  precio del front, ancla, order bump, 3 upsells en tres dimensiones, downsell,
  escalera de fricción descendente, ticket promedio (AOV) objetivo y compuertas
  de validación — con los números medidos del corpus (compra real desglosada de
  nutritionsolved, censo de 155 landings) y el criterio del dueño del cerebro.
  Usar cuando el usuario diga /pricing,
  "ponele precio", "armá los upsells", "estructura económica", "cómo subo el
  ticket promedio / AOV", "qué cobro por esto", o cuando /oferta-completa
  terminó y falta la economía antes de montar la tienda. Entrega la estructura
  como propuesta con procedencia por número; el precio final lo decide el dueño del cerebro.
  Jamás muta plataformas.
---

# Pricing — la estructura económica, medida

El diferencial de esta skill es que casi ningún número acá es teoría: hay una
compra REAL de una oferta ajena con el backend desglosado paso a paso
([[2026-07-28-nutritionsolved-front-y-backend]]), un censo de 155 landings del
ecosistema ([[2026-07-28-marco-copy-visual-gatillos-solved]] §8) y el
criterio del dueño del cerebro. **Cada número que entregues lleva su
procedencia: [V] medido en el corpus · [C] canon/criterio del dueño del cerebro ya validado
· [I] hipótesis tuya.** Mezclarlos es el error que esta skill existe para
evitar.

Encuadre: low ticket, compra por impulso. La lógica entera es de subasta de
Meta: **el que más AOV tiene puede pagar más CPA y gana la puja**
([[upsells-unit-economics]]: "le comés cruda a la competencia").

## Frontera con las otras skills

- **/investigar-mercado** deja en su offer-audit un "plan de AOV" de una
  línea y los benchmarks: es la hipótesis de que la economía cierra. No lo
  repitas: esta skill lo convierte en la estructura completa con números y
  procedencia.
- **/oferta-completa** ya valorizó el stack y el ancla del front. Vos fijás
  los precios reales y verificás que el múltiplo del ancla quede en banda; si
  el precio que elegís lo saca de banda (2-5x producto único), devolvés la
  valorización a oferta-completa para recalibrar, no estirás el ancla.
- La compuerta de deseo adyacente ya se pasó en investigar-mercado (pregunta
  asesina 6: sin bump/upsell posible no hay AOV y la oferta no cierra). Si
  llegás acá y no hay deseo adyacente identificado, algo se salteó: volvé.

**Entrada esperada:** `_staging/investigacion/<producto>/5. Oferta armada` (o
una oferta ya existente de una tienda corriendo). Salida:
`6. Pricing - <Producto>.md` en la misma carpeta.

## Orden de las palancas (criterio de la casa)

De [[primero-el-ticket-promedio-despues-la-escala]]: ante una oferta que
convierte, **primero el precio del front, después los upsells, después la
escala**. Subir el precio es la palanca más rápida (se valida en 1-3 días; por ejemplo:
con la misma cantidad de pedidos, un ticket que pasa de 20 a 26 USD es ganancia
neta del día sin gastar un peso más en anuncios).
Y todo esto aplica SOLO con oferta validada: tasa de conversión >=2% sostenida
24-72 h ([[validacion-oferta-tasa-conversion]]; umbrales 1,5% mejorar / 2%
tranquilo / 2,5%+ escalar o subir AOV). Si la TC no responde, el problema no
es el ticket y subir el precio esconde el diagnóstico.

## 1. El front

- **Banda del ecosistema [V]** (censo 155 landings, molde brasilera):
  US$7-27, modas $17 y $27, ningún front visible arriba de $27. Escalones:
  $7 entrada impulso · $9-15 ES y nichos blandos · $17 sistemas EN ·
  $24.99-27 tope del molde A en EN.
- **Banda del corpus completo [V]** (14 desarmes, incluye moldes no-Solved):
  €9,99 a US$47 (recetas 9,99 € · falegname 19,90 € · screenfree $21.99 ·
  kinesio ~US$23 · nutrition $27 · megapacks $29.99 · cutify $39.97 ·
  fotofana $47). Los fronts de $40-47 son bibliotecas visuales masivas, no
  sistemas.
- **Regla de lanzamiento [C]**: lanzar a USD 15-20 y validar los
  aumentos con el mercado. Iterar precio sin miedo: "¿qué es lo peor que
  puede pasar? No se valida, vuelvo al precio anterior."
- **El precio viaja con el idioma [V]**: el espejo bilingüe traduce también
  el precio (screenfree $21.99 EN ≈ zentrad AR$27.386 ES; y la banda de AOV cambia
  por mercado con la misma oferta — por ejemplo, un mismo SKU puede venderse
  bastante más caro en EEUU que en España). Al proponer precio, decí para QUÉ mercado e idioma.
- **El front no es donde se gana [V]**: front barato compra clientes; el
  backend paga el CPA (nutritionsolved: front 26.6, techo con backend 70).
- Moneda local siempre visible ("Pagá en tu moneda local", ley 8/13) con
  ancla en USD; verificá la conversión — el ancla rota de kinesio
  (RD$4,9M tachados) salió de ahí.

## 2. El ancla

- **Producto único: 2x-5x [V]**, mediana ~3.2x (recetas 2.0 · megapack-claude
  2.1 · falegname 2.4 · zentrad 3.1 · screenfree 3.2 · ia-inmo 3.5 · cutify
  3.75 · nutrition 4.8 · inventores 5.0).
- **Bundle/biblioteca: el ancla es la suma de partes compradas por separado
  [V]** y puede superar 10x (fotofana 10.6x, megapack-pack-ia 15x con "cada
  curso afuera $97-497"). Solo ahí.
- **1.4x es viable únicamente con ancla externa de costo real**: por ejemplo,
  un pack de planillas de finanzas personales anclado, por ejemplo, 14→10 (1.4x)
  se sostiene si la escena de dolor dice "un asesor financiero cobra, por ejemplo,
  $50-100 por consulta". El ancla externa tiene que ser comprobable.
- La razón del descuento medida en el corpus es "precio de lanzamiento";
  la urgencia del front es sobria (solo eso) — la presión se concentra en el
  backend [V].

## 3. El order bump (pre-compra)

- Atado al **deseo adyacente** del avatar detectado en la investigación —
  bump y upsell van sobre el AVATAR, no sobre la promesa (el bonus ya cubrió
  la promesa; [[stack-bonuses-oferta-irresistible]]).
- Dónde vive [C] ([[upsells-unit-economics]]): los 3 momentos pre-compra —
  pop-up en la landing al clickear comprar, carrito (app tipo SellEasy),
  checkout.
- Benchmark de toma: 30-40% [C] (canon del método, fijado en el offer-audit
  de investigar-mercado; NO está medido en el corpus — el único backend
  medido no usa bump pre-compra, todo su AOV es post-compra). Marcá esta
  distinción siempre.
- Precio [I]: fracción del front (el corpus no lo mide; propuesta: 30-50%
  del front, a validar). Título corto — la regla de 30 caracteres del punto 4
  aplica igual acá.

## 4. Los upsells post-compra (lo mejor medido del corpus)

Modelo completo de la compra real ([[2026-07-28-nutritionsolved-front-y-backend]]):

- **Tres upsells que cubren TRES DIMENSIONES DISTINTAS del mismo trabajo
  [V]**: más contenido listo (U1: planes+recetas) · el flujo interno (U2:
  plantillas de organización) · lo que se muestra o entrega al cliente (U3:
  visuals). No es "más de lo mismo": es el sistema completándose. Si tus 3
  upsells atacan la misma dimensión, dos sobran.
- **Anclados MÁS CAROS que el front [V]**: tachados US$58-87 contra un front
  de $27. El comprador percibe acceso privilegiado post-compra, no un extra
  barato. (Coherente con el canon [C]: "el upsell puede valer igual o más
  que el front — el cliente está en éxtasis de compra".)
- **Escalera DESCENDENTE de fricción [V]**: 18.7 → 14.8 → 9.9 → 9.9 → 5.9.
  Cada "no" recibe una oferta más fácil. Descuentos crecientes: 79% → 78% →
  86% → 83% → 90%.
- **Downsell = el MISMO producto con 7-10 puntos más de descuento [V]**, sin
  cambiar el entregable (78%→86% y 83%→90% medidos). El copy subraya que no
  pierde nada: "Same... Same... Same...".
- **One-click post-pago [V]**: el pago ya está autorizado, cada paso es un
  botón. La urgencia se disfraza de proceso de entrega ("read this while we
  send your purchase" → FINAL UPGRADE → FINAL STEP → LAST CHANCE), no de
  contador comercial.
- **ADN de la casa obligatorio**: la retención por amenaza ("you risk being
  charged twice") NO se replica — es retención gris que la plataforma puede
  castigar. Nuestra retención: barra de progreso y timer, sin amenaza.
- Techo del checkout [C]: AfterSell/Shopify aguanta 3 upsells. El backend
  (app de entrega con productos bloqueados) no tiene tope: como principio, mover todo al backend con
  6-7 productos puede acercarse a duplicar el ticket (por ejemplo, de 20 a 40 USD) [C]. Requisito no negociable: el producto
  principal tiene que ser bueno — ahí compran porque ya te probaron.

**Operativa de upsells [C]** ([[upsell-treinta-caracteres-y-mockup]]): el
upsell se decide en ~30 caracteres de título + un mockup chiquito, y tienen
que decir cosas DISTINTAS. Testeo: 4-5 en simultáneo, 48 h; se agregan 1-2;
los que no convierten se ITERAN (título/mockup/valor percibido), no se sacan.
Si un upsell convierte más que el front, se asciende a producto principal.

## 5. AOV: objetivo, techo y lectura

- **Medido [V]**: front 26.6 → techo del funnel completo 70 (+163%). Caso
  real de esa misma compra tomando 1 de 3 upsells: 45.3 (**+70%**). El
  escenario de proyección honesto es el +70%, no el techo.
- **Objetivo [C]**: AOV arriba de USD 30 (banda afuera con buenos upsells:
  33-37; objetivo declarado 30-45). MATIZ: estar abajo de 30 no es
  malo en sí — **el veredicto real es la relación CPA vs ticket**. Y no hay
  techo: con AOV alto aparecen compradores que se llevan todo el backend
  ("el ticket promedio tiene niveles").
- **Qué banca [C]**: con AOV 30+ se pagan CPAs de hasta ~19 USD que el 90%
  no puede pagar. Lectura siempre CPA + ROAS, no CPA solo; tramos de ROAS
  low ticket: <1 pierde · 1-1,5 mejora · 1,5-2 aprobada · >2 escalar
  ([[roas-benchmarks-low-ticket]]).
- **Deducción fija [C]**: 8% de comisiones (Shopify + pasarela) en todo
  cálculo de profit.
- Benchmarks del funnel [C] (offer-audit): front frío 1.5-3% · bump 30-40% ·
  upsell 1 15-25%.

## 6. El entregable

`6. Pricing - <Producto>.md` con:

1. **Tabla de estructura**: pieza (front / bump / U1 / U2+DS2 / U3+DS3) ·
   precio propuesto · ancla y % OFF · dimensión que cubre · procedencia
   [V]/[C]/[I] de cada número.
2. **Proyección de AOV en tres escenarios**: conservador (solo front) · real
   (+70%, el caso medido) · techo (+163%) — y qué CPA banca cada uno neto del
   8%, con el veredicto de puja (contra qué CPA compite el nicho según la
   investigación).
3. **Plan de validación**: compuerta TC >=2% 24-72 h → precio del front (1-3
   días) → test de 4-5 upsells 48 h → recién ahí hablar de escala.
4. **Decisiones del dueño del cerebro**, en bloque aparte: el precio final del front, los
   precios de upsells, y cualquier cambio de alcance. La skill entrega bandas
   medidas + una recomendación con procedencia; **fijar el precio es decisión
   del dueño, siempre** (regla dura 11).

## Lo que JAMÁS hacés

- Dar un número sin procedencia, o mezclar lo medido con lo inferido. "El
  bump convierte 30-40%" sin el [C] al lado es exactamente el error.
- Presentar el techo (+163%) como proyección: el escenario honesto es el
  +70% real. El número que reportás nunca es el de la pasada más optimista.
- Fijar un precio como decisión tomada, publicarlo, o tocar
  Shopify/Meta/pasarelas: entregás propuesta con bandas; decide el dueño del
  cerebro.
- Trabajar el ticket de una oferta que no pasó la compuerta de TC >=2%:
  antes de eso solo se valida el front.
- Proponer 3 upsells que sean variaciones del mismo ángulo: tres dimensiones
  distintas o no son tres upsells.
- Replicar la retención gris ("te van a cobrar dos veces") del molde
  original: la estructura se roba, la amenaza no.
- Sacar un upsell que no convierte en vez de iterarlo, o bifurcar el front
  en dos formatos ([[no-le-des-opciones-al-comprador]]: el formato
  alternativo vive como upsell, nunca como opción en la landing).
- Decir "regalos apilados" o "ñapa": se dice **bonus**.
- Aplicar economía de high ticket (llamadas, cuotas de mentoría, anclas de
  programas): esto es impulso puro.
- Escribir fuera de `_staging/` o hacer git commit/push: /orden integra.
