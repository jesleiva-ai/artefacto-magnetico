---
name: programar-reels-organicos
description: Programa creativos ya aprobados como REELS ORGÁNICOS en tu página de Facebook y tu Instagram, tal cual están en Drive, 3 por día (horarios configurables), con una descripción propia por video que cierra con tu llamado a comentar una palabra clave — Facebook por API y Instagram por el editor de reels de Meta Business Suite (la API de Instagram no programa). Verifica todo contando el Planificador. Usar cuando digas "programá contenido", "programá los reels", "subí esto a reels", "subilo a Instagram y Facebook", "que queden programados", "¿hasta qué día tengo contenido?", "seguí programando", o pases una carpeta de Drive para publicar orgánico. NO es para anuncios (eso es /carga-creativos).
allowed-tools: Bash, Read, Write, Edit, Monitor, mcp__claude_ai_Google_Drive__search_files, mcp__claude_ai_Google_Drive__get_file_permissions, mcp__claude_ai_Google_Drive__get_file_metadata
---

# Programar reels orgánicos

Decís **«programá contenido»** (o pasás una carpeta) y quedan programados los
reels en tu página de Facebook y tu Instagram, día por día, siguiendo al último
que ya estaba programado.

## Paso 0 — Configuración (la primera vez)

Completá con el usuario `config.json` al lado de esta skill:

```json
{
  "pagina_facebook_id": "<ID de tu página>",
  "instagram_usuario": "<@tu_cuenta>",
  "zona_horaria": "<tu zona horaria, ej. Europe/Madrid>",
  "horarios": ["12:00", "18:00", "21:30"],
  "palabra_clave": "GUIA",
  "cta": "📩 Comentá GUIA y te mandamos más info por mensaje. También la tenés completa en el enlace de la bio 🔗",
  "carpeta_drive_por_defecto": "<ID de la carpeta de videos aprobados>",
  "cola": "~/reels/cola.json"
}
```

Y montá estas tres cosas:

1. **Token de página de Facebook** con permisos `pages_manage_posts`,
   `pages_read_engagement` y `publish_video`, guardado en el llavero del sistema o
   en un `.env` con permisos 600. **Nunca se pide ni se pega por el chat.**
2. **Un navegador controlable** (Claude in Chrome) con la sesión de Meta Business
   Suite abierta: es la única vía para programar en Instagram.
3. **ffprobe** para revisar los videos sin bajarlos enteros.

Si tenés una automatización de respuesta por palabra clave (ManyChat o similar),
confirmá que escucha la misma palabra que pusiste en `palabra_clave`.

## Criterio (no se vuelve a preguntar; la cola sí se muestra antes de programar)

- **Tal cual.** El video va como está en Drive: no se recorta, no se le pega placa,
  no se re-codifica (la API de Instagram rechaza videos re-codificados con otros
  cuadros por segundo).
- **Directo desde Drive.** Las copias de paso se borran apenas se confirma cada una.
- **El CTA va en el copy**, nunca en el video. Cada video lleva **su propia
  descripción**, interesante y sobre lo que dice ese video (se escribe desde el
  guion; si no hay guion en disco, se transcribe el audio), y **todas cierran con
  el `cta` de la configuración**. Tené 5 textos genéricos de respaldo para cuando
  no haya guion ni audio legible.
- **3 por día en los horarios configurados**, sin huecos, **siguiendo al último que
  ya está programado**. **Programados**, nunca publicados en el momento.
- **No se excluye nada por criterio propio.** Si una pieza choca con algo que sabés
  del negocio (una garantía que ya no existe, «el precio sube», la marca mal
  escrita), va una línea de aviso con su fecha de salida, para que la saques vos si
  querés.
- Solo videos `video/mp4`: las fotos no son reels.

## Pasos

**0. ¿Hasta cuándo hay?** Leé la cola y decí la última fecha programada. Si solo
preguntaste eso, se contesta y listo.

**1. La llave.** Probá el token con `GET /{pagina}?fields=name` en la Graph API.
Si falla, decí qué permiso falta; el token lo cargás vos.

**2. La lista de Drive.** Con el conector: `search_files` con
`parentId = '<carpeta>' and mimeType = 'video/mp4'`. Revisá con
`get_file_permissions` que diga `anyone · reader` (si no, Meta no lo puede bajar:
pedí pasar la carpeta a «cualquiera con el enlace»). Guardá la lista a disco como
`[["TEST 7", "<id>", <bytes>], ...]` y **contala con código**, no a ojo.

**3. La cola.** Primero en simulacro, después de verdad. Por cada video: verificá
tipo y bytes contra Drive y la cabecera con `ffprobe` (sin bajarlo entero),
salteá lo que ya está en la cola, **no toques la cola si uno falla**, marcá
«solo Instagram» lo que no es 9:16 o pasa de 90 s, y asigná los horarios que
siguen al último programado.

**3b. OK del dueño.** Antes de programar nada, mostrale la cola completa (fecha, hora, red, video
y descripción de cada reel) y esperá su OK en el chat. Publicar es irreversible para el público.

**4. Facebook (API).** Subí cada reel a `/{pagina}/video_reels` con
`video_state=SCHEDULED` y `scheduled_publish_time` (epoch). ~1 min por video: si
son muchos, en segundo plano con un Monitor sobre el log. Nunca publica en el
momento. Si un reel ya salió programado con otro texto, `POST /{video_id}` con
`description` lo corrige.

**5. Instagram (Business Suite).** Primero UNO, a mano con el navegador: Crear
reel → subir el video → copy → en «Publicar en» dejar **solo Instagram** (Facebook
ya va por API; no tocar «Guardar preferencia») → **«Programar»** (el botón de
abajo; el de «Compartir» publica EN EL MOMENTO) → fecha y hora → confirmar hasta
ver el cartel «Se ha programado el reel». Si salió bien, seguí con el resto
uno por uno y frená en el primero que no verifica, con una captura de pantalla.
Antes de reintentar, mirá la captura: si no llegó al cartel, ese video NO está
programado y se reintenta sin duplicar.

**6. Verificar por artefacto.** Contá las tarjetas de Facebook y de Instagram en
el Planificador de Business Suite, día por día, contra la cola (para Facebook
también sirve `GET /{pagina}/scheduled_posts`). Solo con todo `[ok]` se dice que
está hecho.

**7. Contar.** Corto: cuántos quedaron, de qué fecha a qué fecha, a qué horarios,
**hasta qué día tenés contenido**, y la línea de aviso de lo marcado.

## Trampas medidas (no volver a descubrirlas)

- Instagram **no se programa por API**: no hay parámetro. Quien dice que sí,
  publica a la hora con un robot. La vía es Business Suite.
- Una pestaña del navegador **en segundo plano no se dibuja** (la subida se queda
  en 9 %): traé la pestaña al frente y abrí una por video.
- El botón «Programar» hay que traerlo al centro de la ventana antes del clic.
- Business Suite puede mostrar la hora en otra zona horaria: confirmá cuál usa
  antes de cargar horarios.
- `/videos` y `/video_reels` no muestran los programados: para contarlos,
  `/{pagina}/scheduled_posts`.
- Una pestaña del Planificador cargada antes de programar muestra la semana vieja:
  navegá de nuevo antes de contar.
- Si corrés la cola en un servidor además de en tu compu, **pausá el servidor
  antes de tocar la cola a mano** y devolvela recién después: si se pisan, un reel
  sale duplicado.
