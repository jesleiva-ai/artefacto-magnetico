---
name: quien-cobra-kit
description: Averigua de QUIÉN es una oferta ajena — quién cobra, bajo qué empresa o LLC, con qué píxel y desde qué Business Manager — cuando el WHOIS está anonimizado y la landing no tiene datos legales. Usar cuando el usuario diga /quien-cobra, "¿de quién es esta oferta?", "¿quién está corriendo esto?", "averiguá el titular", "¿esto es de alguien que conozco?", "quién está atrás de esta landing", o cuando aparezca un competidor que huela a copia y haya que ponerle nombre antes de decidir qué hacer. Entra por la capa de cobro, no por el dominio. Solo fuentes públicas; jamás compra ni toca el backend ajeno.
---

# `/quien-cobra` — a quién le cae la plata de esta oferta

## El principio, en una línea

**La identidad no vive en el dominio, vive en la capa de cobro.**

Desde que Cloudflare anonimiza el WHOIS por defecto, preguntar *"¿quién registró
el dominio?"* es un callejón sin salida garantizado. Pero el checkout **tiene que
decirle al navegador a qué cuenta cobrar**, así que el identificador del vendedor
viaja en el HTML que te entregan a vos. Cambiá la pregunta:

> ~~¿Quién registró el dominio?~~ → **¿A qué cuenta cae la plata?**

## La regla que no se negocia (piso de ruido)

Un identificador aislado **no identifica a nadie**. Antes de usarlo como huella,
medí en cuántos inquilinos de la plataforma aparece:

| Cardinalidad | Lectura |
|---|---|
| 1 (solo el objetivo) | Todavía no discrimina |
| **2–3** | **FIRMA** — mismo dueño. Ahí está la respuesta |
| Muchas / todas | **Ruido de plataforma**. Descartalo y no lo menciones |

Esto no es teoría: en un censo real de una plataforma de tiendas (Impultienda)
el mismo Clarity ID aparecía en **todas** las tiendas, porque lo inyecta la
plataforma. Tomarlo como huella habría entregado decenas de tiendas como "del
mismo dueño".
Es la misma lógica con la que `/cloaker-xray` mide el piso de ruido de una página
antes de gritar "cloaking". `quien_cobra.py cruzar` **te obliga** a mirar la
cardinalidad: nunca devuelve coincidencias sueltas.

## El motor

`~/herramientas/quien_cobra.py` — stdlib, sin dependencias.

```bash
quien_cobra.py huellas <url>     # identificadores de una página
quien_cobra.py censo <dominio>   # todos los inquilinos de una plataforma (CT logs)
quien_cobra.py cruzar <url>      # pipeline completo + cardinalidad
```

## El pipeline

### 0. Arranque barato (declaralo en tu primera línea)
Bajá la landing y su `/checkout` con `curl` y mirá el HTML crudo. La mitad de las
veces el pie legal, el mail o la razón social están ahí y no hace falta nada más.
Probá también `/terminos`, `/privacidad`, `/legal`, `/contacto`, `robots.txt`.
Si están todas en 404, ya sabés algo: **eligieron no identificarse**.

### 1. Cadena de resolución → la plataforma
```bash
dig +short CNAME <host>
```
El CNAME te dice sobre qué SaaS está montado. Ese es el objetivo real del paso 2:
**no investigues la tienda, investigá la plataforma.**

### 2. Censo de la plataforma (Certificate Transparency)
`crt.sh` lista todos los subdominios para los que se emitió certificado. Sobre el
dominio de la plataforma eso es **el padrón completo de sus inquilinos**. Es el
paso multiplicador: sin población no hay cardinalidad y sin cardinalidad no hay
atribución.

> **crt.sh corta por rate-limit sin avisar y devuelve vacío.** Un censo vacío no
> es "no hay inquilinos", es "no pude ver". El script cachea el último censo
> bueno en `~/.cache/quien-cobra/` y **aborta** si quedan menos de 5 inquilinos o
> menos de 5 tiendas vivas, en vez de imprimir una tabla que diría "solo
> objetivo" para todo. Ese falso negativo con cara de conclusión es el error más
> caro de esta skill: si aborta, **no inventes un veredicto** — reintentá en unos
> minutos o pasá el padrón con `--censo-archivo`.

### 3. Huellas del objetivo y de toda la población
Bajá `/checkout` de cada inquilino y extraé identificadores. Los que importan:

| Pasarela | Qué identifica al vendedor |
|---|---|
| **Stripe Connect** | `acct_…` = cuenta conectada del **vendedor**. El `pk_live_…` es de la **plataforma**, no lo confundas |
| **Mercado Pago** | `APP_USR-…` (public key) y `collector_id` |
| **Hotmart / Kiwify** | el id de producto/productor en la URL de pago |
| **PayPal** | `client-id` del SDK |
| **Whop** | el slug de la cuenta |

Tracking (`meta_pixel`, `clarity`, `ga4`, `gtm`) sirve **solo si pasa el filtro de
cardinalidad** — suele ser de la plataforma.

### 4. Cruce → la segunda tienda
La tienda que comparte la cuenta de cobro es del mismo dueño, y **esa suele tener
marca, píxel y BM conocidos**. Ese es el salto que resuelve el caso.

### 5. Lado Meta (acá se cierra)
```
ads_get_dataset_details(dataset_id=<píxel>)   ->  business_id
```
- Si ese `business_id` es un BM al que el dueño del cerebro ya tiene acceso → **ya sabés quién es**,
  y `ads_get_pages_for_business` / `ads_get_ad_account_pages` te dan las páginas
  (nombre comercial y de persona).
- `ads_library_search` con `page_ids` te muestra qué está corriendo esa página.
- Compará el `business_id` del objetivo contra el de la segunda tienda: si son
  distintos, montaron **BM nuevo y limpio** para la oferta nueva. Eso es señal.

### 6. Ficha pública de la página de Facebook
Es donde declaran mail y dirección. **Por `curl` da 403 duro** — hay que ir con
navegador real:
```bash
ojos.py ver --url "https://www.facebook.com/<page_id>/"   # va a fallar el match
ojos.py pestanias                                          # la pestaña SÍ quedó abierta
ojos.py ver --buscar "<título de la página>"               # acá lo leés
```
Ese patrón de tres pasos es obligatorio: `ver --url` falla siempre que el sitio
redirige, y Facebook redirige siempre.

## Trampas del MCP de Meta (te ahorran ~100 llamadas)

- **`ads_get_creatives` ignora `fields` en el listado.** El `link_url` solo vuelve
  pasando `creative_ids`, de a uno. Corolario: *"¿alguna de mis cuentas apunta a
  esta URL?"* **no se contesta escaneando creativos** — se contesta con el
  `business_id` del píxel de la landing.
- **`ads_library_search` y `ads_get_ad_preview` rechazan `client_conversation_id`**,
  que el resto del MCP exige. Mandáselo y la llamada muere.
- **`ABO` en un nombre de campaña es *Ad set Budget Optimization***, no
  una palabra ni un nicho. Igual `CBO`, `COSTCAP` y demás siglas de puja o de nivel de testeo:
  es nomenclatura de estructura, no de contenido. No persigas fantasmas.
- `timeout` no existe en la Mac (userland BSD). Usá el timeout de la tool.

## Señales de riesgo que hay que reportar sí o sí

- **Link de display que no existe.** Si el anuncio muestra `MARCA.COM` y el WHOIS
  dice *"No match"*, están usando un dominio de fantasía. Viola políticas de Meta
  y es causal de baja del BM. Chequealo siempre: `whois <dominio-que-muestra-el-ad>`.
- Fecha de alta del dominio vs. fecha del píxel vs. fecha del primer anuncio: te
  reconstruye el cronograma del lanzamiento.
- Fechas en los nombres de los assets (`chatgpt-image-23-may-2026…`) — dicen desde
  cuándo lo vienen cocinando, que casi nunca coincide con el lanzamiento.

## Formato de salida

Informe corto con **cadena de evidencia**, cada eslabón con su procedencia
(`verificado en vivo` / `doc oficial` / `terceros` / `inferencia`). Estructura:

1. **Veredicto** — de quién es, en dos líneas.
2. **La cadena** — paso a paso, cada uno con el dato crudo que lo sostiene.
3. **Lo que NO se pudo probar** — explícito, sin rellenar con suposiciones.
4. **Riesgos detectados** (display link falso, políticas, etc.).
5. **Qué falta para el nombre legal** y cuánto costaría conseguirlo.

## Lo que jamás hacés

- **No comprás** para ver el descriptor de la tarjeta sin OK explícito del dueño del cerebro:
  es plata suya y deja rastro suyo del otro lado. Se propone, no se ejecuta.
- **No usás la clave anon/pública ajena** para consultar su Supabase/Firebase ni
  enumerar su base. Leer lo que el servidor le da a cualquiera es investigación;
  consultarles el backend es otra cosa.
- **No perfilás a una persona privada.** El objetivo es la entidad que corre el
  negocio: empresa, LLC, BM, página, cuenta de cobro. Datos personales que no sean
  el contacto comercial publicado, no van.
- **No afirmás un titular sin cardinalidad.** Si la huella no pasó el filtro de
  ruido, se dice "no se pudo determinar" y listo.
