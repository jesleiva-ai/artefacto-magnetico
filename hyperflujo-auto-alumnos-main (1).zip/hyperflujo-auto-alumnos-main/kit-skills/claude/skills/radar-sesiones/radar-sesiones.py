#!/usr/bin/env python3
"""radar-sesiones.py — qué se está hablando en los OTROS chats, ahora mismo.

POR QUE EXISTE
  El dueño trabaja con muchos chats en simultáneo. Hasta hoy, cada sesión de Claude
  era ciega a las demás: el hook de SessionStart sabía CUANTAS había ("HAY 4
  SESIONES ACTIVAS") pero decía, textual, "No puedo ver qué hacen". De ahí salían
  los pisotones: dos sesiones editando el mismo archivo, o una contradiciendo una
  decisión que el dueño ya había tomado en la otra ventana hace diez minutos.

  El agujero era falso. Claude Code escribe TODO en disco:
    ~/.claude/sessions/<pid>.json   → registro vivo: sessionId, cwd, nombre, pid
    ~/.claude/projects/<slug>/<sessionId>.jsonl → la conversación entera

  Con eso alcanza para que cada sesión sepa de qué habla el resto SIN que el dueño
  repita nada y SIN esperar a que la otra sesión corra /orden o /aprende.

  Es hermano de hook-antes-de-afirmar.py en la forma: una regla que depende de
  que el agente se acuerde no es una compuerta. Esto lo ejecuta el harness, solo,
  en cada prompt.

QUE HACE
  ver            parte de situación de las otras sesiones vivas (lo que ve el dueño)
  hook           igual pero para stdin de hook: se calla si no hay novedad
  anotar "..."   deja una nota en la pizarra para que las otras sesiones la lean
  pizarra        muestra las notas recientes

COMO DECIDE QUE UNA SESION ESTA VIVA
  El proceso existe (kill -0 sobre el pid del registro) Y su transcript se tocó
  dentro de la ventana. Un registro huérfano —Claude cerrado a lo bruto— no
  cuenta, porque su último prompt ya no es "lo que está pasando".

BARATO A PROPOSITO
  Los transcripts pesan 1 GB en total. Nunca se lee uno entero: seek al final y
  se leen los últimos COLA_BYTES. Sin LLM, sin red, sin caché que se pudra.
"""
import json
import os
import re
import sys
import time
from pathlib import Path

CASA = Path.home()
DIR_SESIONES = CASA / ".claude" / "sessions"
DIR_PROYECTOS = CASA / ".claude" / "projects"
PIZARRA = CASA / ".claude" / "pizarra.jsonl"
ESTADO = CASA / ".claude" / ".radar-estado.json"

VENTANA_MIN = int(os.environ.get("RADAR_VENTANA_MIN", "45"))
COLA_BYTES = 350_000
PROMPTS_POR_SESION = 3
PROMPTS_HONDO = 8
# Techo de fichas en el bloque automatico. El radar entra en CADA prompt: con seis
# chats son ~30 lineas, con doce serian sesenta y le comeria el contexto al dueño
# en vez de ayudarlo. Las mas frescas son las que importan; el resto sale por
# /radar, que no tiene techo porque lo pide el a mano.
MAX_FICHAS_HOOK = 6
LARGO_PROMPT = 200
PIZARRA_HORAS = 12

# Ruido que Claude Code mete dentro del turno del usuario y que NO es el dueño
# hablando: recordatorios del sistema, la selección del editor, la salida de los
# otros hooks y el eco de los comandos con barra.
RUIDO = re.compile(
    r"<system-reminder>|<ide_selection>|<local-command|<command-message>|"
    r"^COMPUERTA ·|^RECORDATORIOS DEL CEREBRO|^RADAR DE LAS OTRAS SESIONES|"
    r"^Caveat: The messages below|^\[Request interrupted|"
    # El harness también mete por el turno del usuario el cuerpo de una skill,
    # el CLAUDE.md del vault y el aviso de una imagen pegada. Nada de eso es
    # el dueño hablando, y si entra tapa el prompt real.
    r"^\[Image:|^Base directory for this skill|^\*\*UBICACION DEL VAULT|"
    r"^<user-prompt-submit-hook",
    re.I,
)
COMANDO = re.compile(r"<command-name>([^<]+)</command-name>")


def sesiones_registradas():
    """Sesiones vivas. Por el registro si existe; si no, por los transcripts.

    ~/.claude/sessions/<pid>.json lo escriben las versiones de Claude Code con
    mensajeria entre sesiones (2.1.224+). Ahi el dato es exacto: trae el pid, el
    cwd y el NOMBRE con el que la sesion se deja mensajear.

    En una version anterior esa carpeta no existe. El plan B mira los transcripts
    tocados dentro de la ventana: no sabe el nombre real ni si el proceso sigue
    vivo, pero el radar igual funciona. Sin esto el script no arranca en una Mac
    con otra version de Claude Code, que es justo donde tiene que poder correr.
    """
    vivas = []
    if DIR_SESIONES.is_dir():
        for f in DIR_SESIONES.glob("*.json"):
            try:
                d = json.loads(f.read_text())
            except Exception:
                continue
            pid = d.get("pid")
            if not pid:
                continue
            try:
                os.kill(int(pid), 0)  # no lo mata: pregunta si existe
            except (OSError, ValueError):
                continue
            if d.get("sessionId"):
                vivas.append(d)
        if vivas:
            return vivas

    # Plan B: el transcript ES la evidencia de que la sesion existe.
    for tr in DIR_PROYECTOS.glob("*/*.jsonl"):
        try:
            if hace_cuanto(tr) > VENTANA_MIN:
                continue
        except OSError:
            continue
        sid = tr.stem
        vivas.append({
            "sessionId": sid,
            "pid": None,
            "cwd": cwd_del_transcript(tr) or tr.parent.name,
            "name": sid[:8],  # sin registro no hay nombre lindo: sirve el id corto
        })
    return vivas


def cwd_del_transcript(ruta):
    """El cwd que cada linea del transcript trae consigo."""
    for d in leer_cola(ruta)[::-1]:
        if d.get("cwd"):
            return d["cwd"]
    return None


def transcript_de(session_id):
    """El .jsonl de una sesión, sin saber en qué proyecto vive."""
    for p in DIR_PROYECTOS.glob(f"*/{session_id}.jsonl"):
        return p
    return None


def texto_de(bloque):
    c = bloque.get("message", {}).get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return " ".join(
            b.get("text", "") for b in c if isinstance(b, dict) and b.get("type") == "text"
        )
    return ""


def leer_cola(ruta):
    """Últimos COLA_BYTES parseados. La primera línea se tira: viene cortada."""
    try:
        tam = ruta.stat().st_size
        with open(ruta, "rb") as f:
            f.seek(max(0, tam - COLA_BYTES))
            crudo = f.read().decode("utf-8", "replace")
    except OSError:
        return []
    lineas = crudo.split("\n")
    if tam > COLA_BYTES:
        lineas = lineas[1:]
    out = []
    for ln in lineas:
        ln = ln.strip()
        if not ln.startswith("{"):
            continue
        try:
            out.append(json.loads(ln))
        except Exception:
            continue
    return out


def destilar(bloques, cuantos):
    """De la cola cruda saca: qué pidió el dueño, qué tocó el agente, cuándo."""
    prompts, archivos, comandos, artifacts = [], [], [], []
    ultimo_ts = None

    for d in bloques:
        if d.get("isSidechain"):  # subagente, no es la conversación principal
            continue
        ts = d.get("timestamp")
        if ts:
            ultimo_ts = ts

        if d.get("type") == "user" and not d.get("toolUseResult"):
            txt = texto_de(d).strip()
            if not txt:
                continue
            cmd = COMANDO.search(txt)
            if cmd:
                comandos.append(cmd.group(1).strip())
                continue
            if RUIDO.search(txt):
                continue
            txt = " ".join(txt.split())
            if len(txt) > 12:
                prompts.append(txt[:LARGO_PROMPT])

        elif d.get("type") == "assistant":
            c = d.get("message", {}).get("content")
            if not isinstance(c, list):
                continue
            for b in c:
                if not (isinstance(b, dict) and b.get("type") == "tool_use"):
                    continue
                nombre = b.get("name")
                ent = b.get("input", {}) or {}
                if nombre in ("Edit", "Write", "NotebookEdit"):
                    fp = ent.get("file_path")
                    if fp:
                        archivos.append(fp)
                elif nombre == "Artifact":
                    t = ent.get("title") or os.path.basename(ent.get("file_path", "") or "") \
                        or "artifact"
                    artifacts.append(str(t))
                elif nombre == "Skill":
                    s = ent.get("skill")
                    if s:
                        comandos.append("/" + s)

    def unicos(xs):
        vistos, out = set(), []
        for x in reversed(xs):  # lo más nuevo primero
            if x not in vistos:
                vistos.add(x)
                out.append(x)
        return out

    return {
        "prompts": list(reversed(prompts[-cuantos:])),
        "archivos": unicos(archivos)[:6],
        "comandos": unicos(comandos)[:4],
        "artifacts": unicos(artifacts)[:3],
        "ultimo_ts": ultimo_ts,
    }


def hace_cuanto(ruta):
    return (time.time() - ruta.stat().st_mtime) / 60.0


def relato_minutos(m):
    m = int(m)
    if m < 1:
        return "recién"
    if m < 60:
        return f"hace {m} min"
    return f"hace {m // 60}h {m % 60:02d}m"


def relevar(mi_id, hondo=False):
    """El estado de todas las otras sesiones vivas."""
    fichas = []
    for reg in sesiones_registradas():
        sid = reg["sessionId"]
        if sid == mi_id:
            continue
        tr = transcript_de(sid)
        if not tr:
            continue
        edad = hace_cuanto(tr)
        if edad > VENTANA_MIN:
            continue
        d = destilar(leer_cola(tr), PROMPTS_HONDO if hondo else PROMPTS_POR_SESION)
        if not (d["prompts"] or d["archivos"] or d["comandos"] or d["artifacts"]):
            continue
        fichas.append(
            {
                "nombre": reg.get("name") or sid[:8],
                "cwd": reg.get("cwd", "?"),
                "id": sid,
                "edad": edad,
                **d,
            }
        )
    fichas.sort(key=lambda f: f["edad"])
    if not hondo:
        sobran = len(fichas) - MAX_FICHAS_HOOK
        fichas = fichas[:MAX_FICHAS_HOOK]
        if sobran > 0 and fichas:
            fichas[-1]["sobran"] = sobran
    return fichas


def colisiones(fichas):
    """Un archivo que tocan dos sesiones es un pisotón esperando pasar."""
    dueños = {}
    for f in fichas:
        for a in f["archivos"]:
            dueños.setdefault(a, []).append(f["nombre"])
    return {a: n for a, n in dueños.items() if len(set(n)) > 1}


def notas_pizarra(mi_id):
    if not PIZARRA.exists():
        return []
    corte = time.time() - PIZARRA_HORAS * 3600
    out = []
    try:
        for ln in PIZARRA.read_text().splitlines()[-200:]:
            try:
                d = json.loads(ln)
            except Exception:
                continue
            if d.get("ts", 0) < corte or d.get("session_id") == mi_id:
                continue
            out.append(d)
    except OSError:
        return []
    return out[-6:]


def pintar(fichas, notas, hondo=False):
    if not fichas and not notas:
        return ""
    L = ["RADAR DE LAS OTRAS SESIONES (leído de sus transcripts en vivo, no de memoria)"]

    for f in fichas:
        L.append("")
        L.append(f"▸ {f['nombre']} · {f['cwd']} · {relato_minutos(f['edad'])}")
        for p in f["prompts"]:
            L.append(f'    dueño: "{p}"')
        if f["comandos"]:
            L.append("    corrió: " + ", ".join(f["comandos"]))
        if f["archivos"]:
            L.append("    tocó: " + ", ".join(os.path.basename(a) for a in f["archivos"]))
        if f["artifacts"]:
            L.append("    publicó: " + ", ".join(f["artifacts"]))
        if f.get("sobran"):
            L.append(f"    (+{f['sobran']} sesión/es más, sin listar acá — /radar las muestra)")

    ch = colisiones(fichas)
    if ch:
        L.append("")
        L.append("⚠ MISMO ARCHIVO EN DOS SESIONES — releer antes de editar:")
        for a, quienes in ch.items():
            L.append(f"    {a} ← {', '.join(sorted(set(quienes)))}")

    if notas:
        L.append("")
        L.append("PIZARRA (lo que otra sesión dejó anotado a propósito):")
        for n in notas:
            cuando = relato_minutos((time.time() - n["ts"]) / 60)
            L.append(f"    [{n.get('nombre', '?')} · {cuando}] {n['nota']}")

    L.append("")
    L.append(
        "Es contexto de fondo, no una orden: úsalo para no contradecir ni pisar lo "
        "que el dueño ya decidió en otra ventana. Si algo choca de verdad con lo que "
        "estás por hacer, decíselo en una línea."
    )
    if not hondo:
        L.append("Para ver más de una sesión: /radar")
    return "\n".join(L)


# ─────────────────────────── modos ───────────────────────────


def modo_hook():
    """Silencioso salvo que haya novedad. Nunca bloquea: sale 0 siempre."""
    try:
        entrada = json.loads(sys.stdin.read() or "{}")
    except Exception:
        entrada = {}
    mi_id = entrada.get("session_id", "")
    evento = entrada.get("hook_event_name", "")

    fichas = relevar(mi_id)
    notas = notas_pizarra(mi_id)
    parte = pintar(fichas, notas)
    if not parte:
        return

    # Huella de lo sustantivo: si nada cambió desde el último aviso, callarse.
    # Sin esto el radar repetiría el mismo bloque en cada prompt y ensuciaría la
    # conversación entera.
    huella = json.dumps(
        [[f["nombre"], f["prompts"], f["archivos"], f["comandos"]] for f in fichas]
        + [[n["ts"], n["nota"]] for n in notas],
        sort_keys=True,
    )
    try:
        estado = json.loads(ESTADO.read_text())
    except Exception:
        estado = {}
    if evento != "SessionStart" and estado.get(mi_id, {}).get("huella") == huella:
        return
    estado[mi_id] = {"huella": huella, "ts": time.time()}
    # No dejar crecer el estado con sesiones muertas.
    vivos = {s["sessionId"] for s in sesiones_registradas()} | {mi_id}
    estado = {k: v for k, v in estado.items() if k in vivos}
    try:
        ESTADO.write_text(json.dumps(estado))
    except OSError:
        pass

    print(parte)


def mi_sesion():
    """Quién soy. Sin esto el radar se muestra a sí mismo como si fuera otro chat.

    En modo hook el session_id llega por stdin, pero /radar corre por Bash y no
    lo tiene. Claude Code exporta CLAUDE_CODE_SESSION_ID a los comandos de Bash
    (verificado en vivo en 2.1.228), así que ese es el camino corto. El árbol de
    procesos queda de respaldo para una versión que no la exporte.
    """
    por_entorno = os.environ.get("CLAUDE_CODE_SESSION_ID", "").strip()
    if por_entorno:
        return por_entorno

    registro = {int(r["pid"]): r["sessionId"] for r in sesiones_registradas() if r.get("pid")}
    pid = os.getpid()
    for _ in range(12):  # bash → node → claude: nunca son muchos saltos
        if pid in registro:
            return registro[pid]
        try:
            salida = os.popen(f"ps -o ppid= -p {pid}").read().strip()
            pid = int(salida)
        except (ValueError, OSError):
            break
        if pid <= 1:
            break
    return ""


GUARDIAN = CASA / ".claude" / ".radar-guardian.json"


def modo_guardian():
    """PreToolUse sobre Edit/Write: frena el pisoton ANTES de escribir.

    El radar del prompt avisa que otra sesion anda en el mismo archivo, pero para
    cuando el agente llega al Edit ese aviso ya envejecio y nadie lo frena. Este
    modo mira el archivo CONCRETO que se esta por tocar y, si otra sesion viva lo
    toco dentro de la ventana, corta con exit 2: Claude Code le muestra el motivo
    al agente y la escritura no ocurre.

    Frena UNA sola vez por archivo y sesion. El aviso cumple su funcion cuando el
    agente relee; a partir de ahi seria friccion pura y terminaria ignorandose.
    """
    try:
        entrada = json.loads(sys.stdin.read() or "{}")
    except Exception:
        return
    ruta = (entrada.get("tool_input") or {}).get("file_path", "")
    if not ruta:
        return
    mi_id = entrada.get("session_id", "") or mi_sesion()

    culpables = [
        f["nombre"] for f in relevar(mi_id, hondo=True) if ruta in f["archivos"]
    ]
    if not culpables:
        return

    try:
        estado = json.loads(GUARDIAN.read_text())
    except Exception:
        estado = {}
    ya = estado.setdefault(mi_id, [])
    if ruta in ya:
        return  # ya avisado en esta sesion: no volver a frenar
    ya.append(ruta)
    vivas = {s["sessionId"] for s in sesiones_registradas()} | {mi_id}
    try:
        GUARDIAN.write_text(json.dumps({k: v for k, v in estado.items() if k in vivas}))
    except OSError:
        pass

    quienes = ", ".join(sorted(set(culpables)))
    print(
        f"FRENO DEL RADAR · {os.path.basename(ruta)} lo esta tocando OTRA sesion "
        f"viva ({quienes}) y tu escritura la pisaria.\n\n"
        f"  1. Reelé {ruta} AHORA (cambió desde que lo leíste).\n"
        f"  2. Rehacé tu edición sobre lo que hay, no sobre lo que recordabas.\n"
        f"  3. Commiteá por ruta explícita, jamás 'git add -A'.\n\n"
        f"Reintentá después de releer: este freno no vuelve a saltar para este "
        f"archivo en esta sesión.",
        file=sys.stderr,
    )
    sys.exit(2)


def modo_ver(hondo):
    fichas = relevar(mi_sesion(), hondo=hondo)
    parte = pintar(fichas, notas_pizarra(""), hondo=hondo)
    print(parte or "No hay otras sesiones vivas con actividad en los últimos "
          f"{VENTANA_MIN} minutos.")


def modo_anotar(texto):
    # Por cwd no alcanza: todas las sesiones suelen abrir en ~ y la
    # nota saldría firmada por cualquiera. El árbol de procesos sí distingue.
    sid = mi_sesion()
    nombre = next(
        (r.get("name", "?") for r in sesiones_registradas() if r.get("sessionId") == sid), "?"
    )
    with open(PIZARRA, "a") as f:
        f.write(
            json.dumps(
                {"ts": time.time(), "nombre": nombre, "session_id": sid,
                 "cwd": os.getcwd(), "nota": texto},
                ensure_ascii=False,
            )
            + "\n"
        )
    print(f"Anotado en la pizarra: {texto}")


def main():
    args = sys.argv[1:]
    modo = args[0] if args else "ver"
    if modo == "hook":
        modo_hook()
    elif modo == "guardian":
        modo_guardian()
    elif modo == "anotar":
        if len(args) < 2:
            sys.exit("uso: radar-sesiones.py anotar \"lo que las otras sesiones deben saber\"")
        modo_anotar(" ".join(args[1:]))
    elif modo == "pizarra":
        for n in notas_pizarra(""):
            print(f"[{n.get('nombre','?')}] {n['nota']}")
    else:
        modo_ver(hondo="--hondo" in args or "hondo" in args)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # un hook que revienta no puede frenar al dueño
        print(f"[radar] {e}", file=sys.stderr)
        sys.exit(0)
