---
name: skill-finder
description: Encuentra e instala Agent Skills para Claude a partir de una descripción de proyecto. Úsalo cuando el usuario diga "busca una habilidad/skill para X", "qué skills necesito para este proyecto", "instálame skills para...", "encuentra habilidades", o describa algo que quiere construir y no sepa qué skills le sirven. Primero revisa lo ya instalado, luego busca en los catálogos oficiales/comunitarios, recomienda y —con permiso— instala en la carpeta de skills del usuario.
metadata:
  author: local (armado a medida)
  version: 1.0.0
---

# Skill Finder — descubre e instala Agent Skills

Convierte "quiero construir X" en un set de skills instalados y listos.

## Flujo de trabajo

### 1. Entiende el proyecto
Si el usuario no fue específico, pregunta 1–2 cosas clave: qué quiere construir, en qué stack, y para qué plataforma. No adivines.

### 2. Revisa lo que YA está instalado (evita duplicar)
Antes de buscar afuera, lista los skills existentes:
- Skills de usuario: `~/.claude/skills/` (en este equipo: `~/.claude/skills/`)
- Menciona también los skills del proyecto/plugins si aplica.
Si ya hay uno que cubre la necesidad, dilo y no instales de más.

### 3. Busca en los catálogos reales
Usa WebSearch / WebFetch sobre estas fuentes (verificadas, no inventadas):

| Catálogo | URL | Notas |
|---|---|---|
| **Anthropic oficial** | https://github.com/anthropics/skills | Skills firmados por Anthropic (mcp-builder, skill-creator, document-skills, etc.) |
| **Vercel Labs** | https://github.com/vercel-labs/agent-skills | web-design-guidelines, agent-browser, etc. |
| **claudeskills.info** | https://claudeskills.info/skills/ | ~380 skills curados, con procedencia |
| **SkillsMP** | https://skillsmp.com/ | Buscador por keyword, muestra la fuente GitHub |
| **Awesome Claude Skills** | https://awesomeclaude.ai/awesome-claude-skills | Directorio comunitario |

Reglas de búsqueda:
- Prioriza **oficiales** (Anthropic, Vercel) sobre comunitarios.
- Para cada candidato, ubica su repo GitHub y su `SKILL.md` real antes de recomendarlo.
- **Nunca** recomiendes un skill cuyo `SKILL.md` no hayas podido ver.

### 4. Recomienda (antes de instalar)
Presenta una tabla corta: nombre del skill · qué hace · fuente (oficial/comunitario) · por qué encaja con el proyecto. Marca cuáles son imprescindibles y cuáles opcionales. **Pide confirmación** antes de instalar.

### 5. Instala (con permiso)
Método recomendado (idéntico al usado para instalar skills en este equipo):

```bash
# 1) Clonar superficial solo la carpeta del skill (sparse checkout)
git clone --depth 1 --filter=blob:none --sparse <repo-url> "<scratchpad>/skill-clone"
cd "<scratchpad>/skill-clone" && git sparse-checkout set <ruta/al/skill>

# 2) Copiar la carpeta del skill a la carpeta de skills del usuario
#    ~/.claude/skills/<nombre-skill>
# 3) Verificar el frontmatter (name + description) del SKILL.md
# 4) Borrar el clon temporal
```

Alternativas válidas:
- Skills que se instalan vía su propio CLI (p. ej. `npx skills add <owner>/<repo>`).
- Marketplace nativo de Claude Code (lo corre el usuario, no el modelo):
  `/plugin marketplace add anthropics/skills` y luego `/plugin install <skill>@<marketplace>`.

### 6. Cierra el loop
- Los skills de usuario se detectan al arrancar la sesión; si Claude Code no los ve aún, el usuario debe **reiniciar la sesión** o correr `/reload-skills` (si su versión lo soporta).
- Confirma qué quedó instalado y con qué frase se dispara cada uno.

## Seguridad
- Un skill es código/instrucciones que Claude ejecutará. Instala solo de fuentes que el usuario reconoce; prioriza oficiales.
- Ante un skill comunitario dudoso, muestra su `SKILL.md` al usuario antes de instalar.
- No inventes nombres de skills ni URLs: si no lo verificaste, dilo.

## Realidad vs. marketing
Este skill NO "conecta todo solo en un minuto". Busca en catálogos reales, recomienda con criterio y automatiza la instalación con tu permiso. La calidad depende de que el skill exista y esté bien hecho en la fuente.
