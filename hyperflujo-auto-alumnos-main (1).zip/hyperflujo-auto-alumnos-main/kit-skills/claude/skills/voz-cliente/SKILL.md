---
name: voz-cliente
description: >-
  Produce el corpus de VOZ DE CLIENTE de un nicho low ticket: frases textuales
  del mercado, cada una verificada contra su página fuente con verbatim.py,
  ordenadas por dolor / intento fallido / deseo / fricción / desconfianza, para
  que el copy se escriba con las palabras del comprador y no con las del que
  vende. Usar cuando el usuario diga /voz-cliente, "banco de citas", "frases
  textuales del mercado", "voz del cliente", "qué dice la gente de X", "de qué
  se quejan los que compran X", o cuando /investigar-mercado llegue a su paso 2
  y necesite el banco de ≥30 citas: esta skill es la que lo produce. Solo lee
  fuentes públicas; el corpus queda en ~/fuentes/voz-cliente/<nicho>/ y jamás
  muta el vault.
---

# Voz de cliente — el corpus citable

El copy que convierte usa las palabras del comprador: "pisapapeles", "señor
chasco", "los grados no son centigrados". Esa fuerza vive en la ortografía rota,
el modismo y la palabra inesperada — y **muere en cuanto alguien la parafrasea**.
Esta skill produce un corpus de frases que existen, tal cual, en una URL que
cualquiera puede abrir. Rastreable o no entra.

**Acople con `/investigar-mercado`:** esta skill ES la maquinaria del banco de
≥30 citas de su paso 2. No duplica el paso 2b (anuncios): los anuncios dicen qué
COMPRA la gente, los foros y reseñas dicen qué DICE — son dos listas distintas y
esta skill produce solo la segunda. Tampoco escribe avatar ni oferta: entrega
materia prima.

**Encuadre antes de buscar** ([[2026-07-28-ofertas-adaptar-mercado-destino]]):
nombrá el mercado con nicho real, idioma, ticket y modelo de compra (por ejemplo,
"recetarios de repostería sin azúcar, España, español, 9-19 €, compra impulsiva"). "Producto digital"
es el formato, no el nicho: si buscás por el formato, vuelve el prior del modelo.

## Arranque (barato, en orden)
1. HOT.md del cerebro.
2. `04-lecciones/INDEX.md` — solo el índice; abrí una lección solo si su señal
   matchea. Las dos que siempre matchean acá:
   [[2026-07-27-cerebro-ia-el-proxy-miente]] (el buscador da la URL, la cita se
   saca de la página) y [[2026-07-28-ofertas-adaptar-mercado-destino]].
3. `ls ~/fuentes/voz-cliente/` — si el nicho ya tiene corpus, decidí
   ADD / UPDATE / NOOP. Nunca dupliques un barrido que ya está hecho.
4. Grep en `~/cerebro/02-notas/` por el nicho: si hay investigación previa,
   leé su banco de citas para no re-encontrar lo mismo.

## La regla de hierro: cadena de custodia

Una frase es cita **solo si sobrevive esta cadena completa**; si un eslabón
falta, es un recuerdo con comillas:

1. **El buscador solo aporta URLs.** WebSearch resume y traduce; nada de lo que
   devuelve entra al corpus, ni siquiera "retocado". Por ejemplo, en una
   corrida de prueba: quejas escritas en español volvieron en inglés.
2. **La frase se copia del contenido crudo de la página fuente** (curl /
   verbatim.py, o WebFetch pidiendo frases textuales sin corregir ortografía).
   Lo que devuelve WebFetch es un *candidato*: su modelo también puede
   parafrasear sin avisar.
3. **La cita nace cuando `verbatim.py` la encuentra textual en la fuente:**
   `python3 ~/herramientas/verbatim.py check <URL> "frase"` por candidato, y
   `verbatim.py corpus <archivo>` como compuerta final. `[error]` = parafrasis
   o fuente mal anotada: se corrige o se tira, nunca se maquilla. `[skip]`
   (fuente inaccesible) = la frase no es [V]: degradala o conseguí otra fuente.
4. **Verbatim es verbatim.** Ni traducir, ni corregir ortografía, ni pulir
   puntuación, ni [sic]. Si recortás, declarás el corte con `...` — verbatim.py
   exige cada fragmento por separado.

La trampa que esta cadena hace imposible: "encontré la idea en tres lugares,
la redacto prolijo y cito uno". Eso es escribir con las palabras del que vende.

## Dónde se busca, por rendimiento real

Siempre en el idioma del mercado y con las palabras de la gente — "no me sube",
"me quedó duro", "es un timo", "vale la pena", "nunca me llegó" — jamás con
jerga de marketing. La jerga encuentra marketers; las quejas encuentran gente.

1. **Foros de nicho** (phpBB/vBulletin/XenForo viejos). Server-rendered: curl
   los abre y verbatim.py los verifica. Se llega buscando la queja + "foro", y
   los hilos con título quejoso ("La mentira de...", "estoy harta de...") son
   minas enteras: un solo hilo bueno rinde 10-15 citas con réplicas incluidas.
   Por ejemplo: un par de hilos buenos pueden dar 15 o más citas entre los dos.
2. **Comentarios de las recetas/tutoriales gratuitos en blogs** (Blogger y
   WordPress viejos, server-rendered). El sustituto curl-viable de los
   comentarios de YouTube, y rinde lo mismo: dolor, intentos fallidos y **la
   contradicción de lo gratis dicha por la gente** ("en tu esplicacion escrita
   dices X pero en el video haces Y... a cual hago caso???"). Medido: 2 posts →
   84 comentarios → 15 citas. Se llega buscando la receta + "comentarios", o
   desde el blog del operador que ya vende en el nicho.
3. **Reseñas de libros y productos del tema.** Las de 3★ son las honestas; las
   de 1★ traen desconfianza y fricción; las de 5★ van a la categoría "defensa"
   (qué NO contradecir). Casa del Libro rinde y se deja verificar. Goodreads
   también, con trampa: guarda las reseñas en JSON embebido en un `<script>` —
   verbatim.py lo cubre, no lo des por [error] sin mirar. Amazon bloquea
   (404/500/robot): UN intento y seguís.
4. **Preguntas de producto** (MercadoLibre en LATAM, Q&A de Amazon): gente
   preguntando ANTES de comprar = fricción en estado puro. **Verificado
   en una corrida de prueba: ambos levantan bot-wall ante curl** — y sin fetch crudo no hay
   cita [V]. Un intento; si bloquean, van a vetas pendientes de navegador.
5. **Reddit vía `old.reddit.com`** (o el sufijo `.json` en la URL del hilo):
   server-rendered y verificable. En español el volumen suele ser bajo: si dos
   búsquedas dan cero, no insistas.
6. **Autocompletar de Google**:
   `curl 'https://suggestqueries.google.com/complete/search?client=firefox&hl=es&q=FRASE+INCOMPLETA'`.
   No son citas de una persona: son lenguaje agregado de búsqueda. Van en su
   propia sección y NO cuentan para el piso de 30.
7. **Comentarios del tutorial gratuito más visto del tema.** La fuente número
   uno en teoría — dicen por qué lo gratis no alcanza — pero YouTube no se abre
   sin navegador. Anotá título y URL del video como **veta pendiente** para una
   pasada con `ojos.py` cuando el Chrome esté libre. Jamás rellenes con lo que
   "seguro comentan". Mientras tanto, la fuente 2 cubre el mismo hueco.
8. **Trustpilot y reseñas de tiendas del nicho**: fricción post-compra real de
   productos digitales ("nunca me llegó", "me siguen cobrando").
9. **Grupos de Facebook, comentarios de IG/TikTok**: rinden, pero piden sesión
   de navegador. Igual que YouTube: veta pendiente declarada, no adivinada.

## La caza de FRICCIÓN (el hueco que parió esta skill)

Por ejemplo, una corrida de prueba cerró las objeciones de fricción mirando qué responden
las landings ganadoras. Eso es mirar al que vende para deducir al que compra:
**hipótesis [I], nunca cierre**. La fricción con voz real vive en:

- preguntas de producto: "¿cómo me llega?", "¿es libro físico o pdf?", "¿se
  paga una sola vez?", "¿lo puedo ver en el celular?";
- reseñas 1★ que hablan de la ENTREGA y no del contenido;
- hilos y reseñas "es fiable [tienda]" / "[producto] estafa".

Si tras barrer eso una fricción sigue sin voz, queda como hipótesis por
convergencia de copy, marcada [I], en "Preguntas abiertas" — jamás como
resuelta. Por ejemplo, una corrida de validación puede cerrar con 2 citas de
fricción, categoría declarada floja con las vetas bloqueadas nombradas. Ésa es
la salida correcta, no un relleno prolijo.

## El formato del corpus

Archivo: `~/fuentes/voz-cliente/<nicho>/corpus.md` (kebab-case; fecha con
`python3 ~/herramientas/hoy.py`). Cada cita, en el
formato exacto que verbatim.py parsea:

```
> la frase tal cual, en una linea, sin comillas alrededor ni cursivas
— https://url-exacta-de-la-pagina · fecha si esta · idioma
```

La URL es la página donde VIVE la frase (el hilo, la página de opiniones) —
nunca la home, un buscador ni un agregador. Metadato mínimo: fuente, fecha si
está, idioma original.

Una sección por categoría — la categoría es lo que vuelve usable el corpus:
- **Dolor** — lo que le sale mal, con sus palabras.
- **Intento fallido** — qué probó (incluido lo gratis) y cómo fracasó.
- **Deseo** — el resultado como él lo nombra, no como lo nombraría un anuncio.
- **Objeción de fricción** — entrega, cobro, formato, dispositivo, devolución.
- **Desconfianza** — estafa, refrito, "seguro está gratis en YouTube".
- **Defensa (satisfechos)** — qué valoran los contentos: el copy que los
  contradice se pelea con media audiencia.
- **Lenguaje de búsqueda** — autocompletar y queries (no cuenta para el piso).

Marcá **la queja madre** — la cita que condensa el mecanismo del mercado — y los
**pares espejo** (mismo problema, resultado opuesto, una variable de diferencia:
la pareja "salen malas" / "a la temperatura correcta queda practicamente igual"
de un nicho de cocina, por ejemplo). Un par espejo es un anuncio entero.

Corrida de referencia: la tuya propia, cuando la tengas. Por ejemplo,
`~/fuentes/voz-cliente/<nicho>/corpus.md` con todas las citas en [ok].

## Cuándo parar (saturación)

- **Piso:** 30 citas [ok], con al menos 3 de dolor, 3 de deseo y 3 entre
  fricción + desconfianza.
- **Saturación:** barriste una fuente nueva ENTERA (el hilo completo, la página
  de reseñas completa) y no salió ni una frase que el corpus no tuviera ya en
  esa categoría → esa veta se agotó. **Dos vetas distintas agotadas seguidas →
  el corpus está saturado: cerrá**, aunque tengas tiempo y falten fuentes en la
  lista. Más citas iguales no es más señal.
- Categoría que quedó con menos de 3 citas tras saturar → va a "Preguntas
  abiertas" **con la lista de entradas que probaste**
  ([[2026-07-28-cerebro-ia-cero-resultados-no-es-no-existe]]). No se rellena.

## La entrega

1. Compuerta final: `python3 ~/herramientas/verbatim.py corpus <archivo>` con
   veredicto `[ok]`. Con `[error]` no se entrega — se arregla o se tira la cita.
   El veredicto va pegado al final del corpus, con fecha.
2. El corpus cierra con **Fuentes barridas** (citas que rindió cada una, y
   cuáles fueron pérdida de tiempo, para que la próxima corrida no las repita),
   **Vetas pendientes** (YouTube/FB/IG anotadas con URL) y **Preguntas
   abiertas**.
3. Reporte en 4-6 líneas: nicho, cuántas citas verificadas, la queja madre, qué
   categoría quedó floja, qué fuentes rindieron. `/investigar-mercado` consume
   este archivo en su paso 2; qué sube al vault lo deciden `/minar` y `/orden`,
   no vos.

## Lo que JAMÁS hacés

- Citar desde WebSearch, un resumen, una traducción o tu memoria. El buscador
  da la URL; la cita se saca de la página.
- Tomar por voz de cliente: el copy de una landing (propia o de competencia),
  un anuncio, un testimonio curado en una página de ventas (los eligió el que
  vende), un artículo de medio o blog (lo escribió un redactor), o lo que el
  modelo cree que diría la gente. Nada de eso habla como el comprador.
- Cerrar una objeción "por convergencia de copy". Tres landings respondiendo lo
  mismo es una hipótesis [I] sobre qué preguntará la gente, no una pregunta de
  la gente.
- Corregir ortografía, traducir, pulir puntuación o "resumir manteniendo la
  esencia". La ortografía rota es dato.
- Buscar con jerga de marketing ("pain points", "avatar", "nicho X objeciones").
- Entregar sin correr verbatim.py, o entregar con `[error]` adentro. 22 citas
  verificadas valen más que 30 con 8 dudosas.
- Rellenar una categoría vacía o estirar el piso con frases plausibles: lo que
  falta se declara, no se fabrica.
- Tomar el Chrome de trabajo (ojos.py/CDP) si otro proceso lo usa: esta skill
  corre entera con curl, WebSearch y WebFetch. Lo que pide navegador queda como
  veta pendiente.
- Escribir en el vault o hacer git commit/push: el corpus vive en `~/fuentes/`.
- Confundir formato con mercado: si en tu salida aparecen "emprendedor",
  "escalar" o "libertad financiera" sin que el nicho real sea ése, te fuiste de
  mercado.
