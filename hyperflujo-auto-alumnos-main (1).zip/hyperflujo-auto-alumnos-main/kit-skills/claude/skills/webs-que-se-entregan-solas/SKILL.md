---
name: webs-que-se-entregan-solas
description: Construye y opera un servicio de páginas web para negocios locales que se entregan solas — el cliente paga, llena un formulario (o manda todo por WhatsApp), la IA lee su material, un molde propio arma una web de una sola página, un control automático la revisa, se publica en un subdominio con candado y se entrega por WhatsApp y mail con un panel donde el cliente aprueba o pide cambios. Usar cuando diga "armemos el servicio de webs", "/webs", "quiero entregar webs automáticas", "conectá el cobro con la app", "entregale la web a este cliente", o pegue una venta nueva.
---

# Webs que se entregan solas

Objetivo: del pago a la web publicada en minutos, sin trabajo a mano salvo lo dudoso.

**Ojo:** este servicio manda WhatsApp y mails automáticos a clientes reales. Antes de prenderlo en
real, probalo con compradores de prueba y con el OK del dueño. Es una receta: las piezas se construyen.
Vos (Claude) construís y operás todo. El dueño solo decide precios, aprueba lo dudoso y hace lo que pide su cara o su tarjeta.

## Reglas que no se discuten
1. La web se vende como EXTRA de una entrada barata, no como producto de entrada en frío (medido: la entrada en frío convierte muy poco frente al extra; la mayoría de los que compran suman el extra).
2. Una sola página. El menú baja a cada sección; la ficha del producto se abre encima (dialog). Lo único que saca de la página: WhatsApp, redes y mapa.
3. Ningún producto sin foto. Si no hay, foto provisoria del MISMO rubro (nunca de otro), marcada como provisoria.
4. El texto que escribió el cliente va LITERAL. Nunca inventar citas, testimonios ni datos de su negocio. Lo que redactás vos va solo donde él no escribió nada.
5. La app es el lugar; WhatsApp avisa con links a la app.
6. Si el control falla, NO se entrega: va a una cola humana con alerta.
7. El dominio propio es siempre del cliente. No se compran dominios ni se cobra mantenimiento.
8. Con clientes: mensajes de ~300 caracteres, una cosa por vez, se agradece («¡Gracias por tu paciencia!»), nunca «perdón por la demora». Ningún «lo reviso» sin volver en menos de 1 hora.
9. Secretos (tokens, claves) en `.env` con permisos 600 o en el llavero del sistema. Nunca en el chat, en el código ni en un commit.

## Fase 0 · Lo que tiene que dar el dueño (pedilo de una, en una sola lista)
- Nombre de la marca y un dominio comprado (ej. `tumarca.com`) con acceso al panel DNS.
- Un servidor VPS con Ubuntu 24.04 (2 núcleos y 8 GB alcanzan) y acceso por ssh.
- Plataforma de cobro con API o webhook de ventas (y la URL de la página de gracias editable).
- Cuenta de WhatsApp Business en Meta (portafolio verificado si puede) y un número que NO esté usado en la app de WhatsApp.
- Cuenta de un servicio de envío de mails (ej. Brevo) y una llave de API.
- Llaves de IA: un modelo con visión para leer listas y fotos, un servicio de voz a texto, y uno de imágenes para fotos provisorias.
- Un bot de Telegram (token + chat id) para las alertas al equipo.
Compuerta: todo guardado en el llavero / `.env`, nada pegado en archivos del proyecto.

## Fase 1 · Servidor y subdominios
- Node 22+ (trae SQLite: `node:sqlite`), sin dependencias si se puede. Base SQLite en `data/`, archivos de clientes en `data/pedidos/<id>/`.
- Servicio systemd que reinicia solo. Puerto interno (ej. 8795).
- Caddy adelante, con TLS **on demand**: antes de emitir un certificado le pregunta a la app `GET /api/dominio/ask?domain=...`; la app responde 200 solo si el nombre es `<slug>.tumarca.com` de un cliente existente o un dominio propio registrado. Así nadie fabrica subdominios.
- DNS: registro `A *` (comodín) → IP del servidor, y `A @` / `A www` para la portada.
- La app resuelve el Host: `<slug>.tumarca.com` → la web de ese cliente.
Compuerta: un subdominio de prueba abre con candado; uno inventado no obtiene certificado.

## Fase 2 · Cobro → pedido
- Robot (cron cada 5 min) que lee las ventas aprobadas de la plataforma (o webhook) y crea/completa el PEDIDO por email. Idempotente: correrlo dos veces no duplica. Trae el teléfono del checkout a la ficha si está vacío. Un pedido por cliente con sus productos (entrada, web, extras).
- Cada pedido tiene un token largo aleatorio → link personal `/mi/<token>`.
- Página de gracias de la plataforma → `https://tumarca.com/empezar?email={email}`: si es compra reciente, entra directo al formulario.
- Entrada al panel sin contraseña: link de un solo uso (firmado y con vencimiento) o código de 6 dígitos que llega al mail del comprador. Nunca alcanza con saber el mail.
- Compradores de prueba (un dominio de mail tuyo) nunca reciben mensajes ni cuentan en métricas.
Compuerta: una compra de prueba aparece como pedido en menos de 5 min y el link de gracias abre el formulario.

## Fase 3 · El formulario (asistente)
- Una pregunta por pantalla, barra de avance, se guarda cada paso (si cierra, sigue donde quedó). En cada paso: «Mandá un audio» (se transcribe y se guarda como respuesta).
- Preguntas: negocio, rubro, ciudad, logo (o «no tengo» → ofrecer el extra de marca), fotos (local, productos, trabajos), productos y precios (foto de la lista, escribirla o audio), estilo (eligiendo entre 6 ejemplos visuales), WhatsApp, dirección, horarios, redes, historia, dominio propio (opcional, solo se guarda).
- Subida de fotos/PDF/Word/Excel hasta ~40 MB.
- Camino B (al que le cuesta): todo por WhatsApp; el equipo carga lo que manda y le pasa muestras simples («¿Te gusta así?»).
Compuerta: en un celular real (390 px) se completa en ~5 minutos sin trabarse.

## Fase 4 · La IA lee
- Esperar a que el cliente termine de mandar: 10 minutos sin archivos nuevos.
- Modelo con visión: fotos/PDF de la lista → JSON fijo `{secciones:[{nombre, productos:[{nombre, precio, descripcion}]}]}`. Solo lo que dice el material.
- Clasificar cada archivo: local / producto / logo / flyer. Asignar a cada producto SU foto. Recortar 4:3 y mejorar con ffmpeg.
- Tope de lecturas por pedido por día (ej. 8) para no quemar plata.
Compuerta: la lista leída coincide con la foto (precios incluidos) en 3 pruebas reales.

## Fase 5 · El molde
- Un script (Python o Node) recibe la ficha del pedido (brief JSON) y escribe un `index.html` estático.
- CSS propio con tokens (colores, tipografías por rubro), Google Fonts, sin frameworks pesados. `<dialog>` nativo para la ficha, scroll-snap para carruseles, IntersectionObserver para animaciones suaves. Nada que se adueñe del scroll.
- Secciones: portada con SU foto y SU logo, quiénes somos (su historia literal), productos/servicios, galería, horarios, contacto + mapa. Menú fijo con la sección activa, WhatsApp flotante, volver arriba.
- El rubro pone el estilo; lo escrito por el cliente manda sobre el estilo.
- Fotos provisorias: banco del mismo rubro (la primera palabra del nombre del producto tiene que coincidir) o generada con IA.
Compuerta: captura con Chrome headless a 390 y a 1280 px, mirada antes de seguir.

## Fase 6 · El control (antes de entregar, automático)
Chequear: portada con foto del cliente (si mandó), logo visible (o «no tengo»), 0 productos sin foto, botón de WhatsApp con su número, secciones mínimas, ningún link externo salvo wa.me / redes / maps, sin texto de relleno ni citas inventadas.
Si algo falla: NO entregar → ticket en la cola de `/admin` + alerta a Telegram + mensaje corto al cliente («Estamos terminando tu web, te avisamos apenas esté»).

## Fase 7 · Publicar y entregar
- Publicar en `<slug>.tumarca.com`.
- Entrega agrupada: 1 WhatsApp + 1 mail con 3 datos: link de la web, link del panel, cómo entra (email + número de orden COMPLETO, «guardalo»). Cerrar con «Desde ahí tocás lo que quieras cambiar».
- WhatsApp por la Cloud API de Meta: número conectado, usuario del sistema con token que no vence (permisos whatsapp_business_management y whatsapp_business_messaging), webhook para recibir. Dentro de las 24 h de su último mensaje se manda texto libre; fuera, solo PLANTILLAS aprobadas (bienvenida, entrega lista, cambios listos). Una plantilla por número cada 24 h como máximo.
- Mail desde el dominio propio autenticado (SPF, DKIM, DMARC) en el servicio de envío.

## Fase 8 · El panel del cliente
- Vista previa celular/compu, «Me encanta, aprobar» y «Quiero un cambio».
- «Quiero un cambio»: la web en un iframe del mismo origen; el cliente toca el elemento y el pedido llega ANCLADO (producto/sección), con audio o captura.
- Historial de versiones (autor cliente/equipo, ediciones seguidas en 10 min se juntan, tope 40).
- Editor propio: botón grande ARRIBA; barra fija ABAJO con «Guardar cambios» siempre visible en el celular; al guardar se toma del servidor lo que el cliente no tocó (no pisa al equipo); mover, ocultar sin borrar.
- Descargar la web en ZIP. Dominio propio en 3 pasos: lo consigue donde quiera → apunta `A @` y `A www` a la IP → «Avisarles»; un vigía mira el DNS y cuando apunta lo activa y avisa.
- Tarjetas «Sumá más a tu negocio» con los extras no comprados → checkout con su email.
Compuerta: probar el editor en iPhone y Android reales (o emulados con toques) y confirmar que guarda.

## Fase 9 · Vigías y atención
- Cron cada 2 min: bienvenidas (una sola vez), armado, dominios. Telegram por cada mensaje o pedido de cambio, con link al pedido.
- Cambios simples (precio, producto, foto, horario, destacado) los aplica un editor automático y avisa una vez. Lo dudoso, reembolsos y diseño a medida → cola humana; alerta si pasa 4 h sin resolver; resumen diario a la mañana.
- Pedidos repetidos se agrupan en uno.
- Respondedor de WhatsApp con IA que lee la ficha del pedido (no reglas fijas): espera la ráfaga y contesta una vez, no repregunta lo que ya sabe, no contesta «ok» ni reacciones. Clientes marcados «solo humano» no reciben respuestas automáticas.
- Todos los días: pedidos pagos sin entregar = 0 y tickets abiertos revisados. Una entrega fallida no espera a que el cliente reclame.

## Desplegar sin romper
- Respaldar la base antes de cada cambio. Correr las pruebas. Subir solo los archivos tocados (cuidado con `rsync --delete` si se editó algo en vivo en el servidor). Reiniciar sin corte.
- Nunca mandar mensajes ni cobros desde pruebas.

## Errores que ya se pagaron
Entrega sin fotos y sin logo · texto del cliente reescrito con una cita inventada · «lo reviso» con 4 h de silencio · formulario de 9 puntos a una clienta mayor · botón Guardar invisible en el celular · botón de editar escondido al fondo · el guardado del cliente pisaba al equipo · pedidos pagos sin entregar porque el armado falló en silencio · el mismo cambio pedido 4 veces · respuesta automática repetida.
