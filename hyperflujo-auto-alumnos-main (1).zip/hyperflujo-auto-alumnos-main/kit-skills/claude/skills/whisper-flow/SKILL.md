---
name: whisper-flow
description: Dictado por voz local tipo Wispr Flow que corre 100% en la Mac (MLX sobre la GPU de Apple Silicon), con puntuacion y acentos automaticos, parrafos, filtro anti-musica/anti-alucinacion/anti-bucle, captura del audio del sistema y un portapapeles con el historial de todo lo dictado. Usar cuando el dueño diga "whisper flow", "dictado por voz", "quiero hablar en vez de escribir", "transcribir lo que digo", "que escriba lo que hablo", "dictar en el chat", "no me agarro lo que dicte", "el dictado no pone acentos", "escribe la misma palabra muchas veces", "el dictado esta lento", "instalar/compartir el dictado", "/whisper-flow". NO es para transcribir un link o un archivo de video (eso es /transcribir y reel-xray).
---

# Whisper Flow local — edicion macOS

Dictado por voz que corre entero en la Mac: nada sube a la nube, no hay API key
ni suscripcion. Es un Whisper Flow pensado para Windows, portado a Apple
Silicon. La redaccion, los filtros y la poda de bucles son los del original, con
sus numeros medidos; lo que cambio es la maquina de abajo.

Todo vive en `~/herramientas/whisper-flow/`:

```
whisper_flow.py      el motor (unico archivo de codigo)
config.json          todo lo ajustable
diccionario.txt      correcciones de palabras propias (marcas, nombres)
historial.jsonl      lo que se fue dictando (lo lee el panel)
whisper-flow.log     lo que fue pasando (lo primero ante cualquier queja)
iniciar.command      arranca con consola visible
parar.command        lo corta, corra como corra
reparar.command      BOTON DE PANICO del dueño (alias en el Escritorio)
guardian.sh          el vigilante: corre solo cada 60 s
guardian.log         cada vez que el vigilante tuvo que reiniciar
.venv/               Python 3.12 propio (uv)
```

Ademas: `~/Applications/Whisper Flow.app` (lanzador para que los permisos
queden a nombre de "Whisper Flow") y `~/Library/LaunchAgents/local.whisperflow.plist`
(arranque automatico).

## Las teclas

| Tecla | Que hace |
|---|---|
| **Mantener `Ctrl` + `Option` izquierdas** | dicta mientras las tenes apretadas; al soltar, escribe |
| `Ctrl+Option+Space` | dictado largo: una vez enciende, otra apaga |
| `Ctrl+Option+S` | transcribe **lo que suena en la Mac** (necesita BlackHole) |
| `Ctrl+Option+V` | abre el **portapapeles**: todo lo dictado, click para copiar |
| `Ctrl+Option+C` | vuelve a copiar lo ultimo |

Se cambian en `config.json`, campos `hotkey*`.

**Por que Ctrl+Option.** En Windows era Ctrl+Win. En un teclado Mac las teclas
que ocupan ESA misma posicion fisica son Ctrl y Option, asi que el gesto del
dedo es identico. `hotkey` acepta tambien los nombres de Windows por
compatibilidad con la config original de Windows: `left windows` se resuelve a Cmd.

## LO PRIMERO ante "no me anda": los permisos

macOS guarda los permisos en una base protegida por el sistema (TCC). **No se
pueden conceder por linea de comandos** ni con un script: los tiene que tildar
el dueño a mano, una vez.

```
.venv/bin/python whisper_flow.py --permisos
```

Si dice FALTA: Ajustes del Sistema > Privacidad y seguridad > **Accesibilidad**
> `+` > agregar **Whisper Flow** (esta en `~/Applications`).

**Sin ese permiso pynput no tira ningun error: simplemente nunca recibe una
tecla.** El programa arranca, loguea "Modelo listo", lista los atajos y parece
sano — pero no reacciona. Es identico al sintoma de la trampa de los scan codes
en Windows, y se diagnostica igual de mal si no se sabe.

## Velocidad: por que esta configurado asi

La decision de motor NO se hereda de Windows, porque el hardware es otro.
Medido en una Mac con Apple Silicon sobre 29,45 s de audio en espanol:

**Un dictado normal (4,8 s de audio) — esto es lo que se siente:**

| motor | espera | |
|---|---|---|
| `parakeet` | **116 ms** | el que quedo puesto |
| `mlx-whisper` | 413 ms | |
| `faster-whisper` | **4.617 ms** | lo que venia de Windows |

**Sobre 29,45 s de audio (donde el RTF ya significa algo):**

| motor | seg | RTF | x tiempo real |
|---|---|---|---|
| `parakeet` | 0,45 | **0,015** | 66x |
| `mlx-whisper` | 0,98 | 0,033 | 30x |
| `faster-whisper` | 5,51 | 0,187 | 5x |

**Precision**, sobre varios audios de prueba
(WER, palabras mal sobre palabras dichas):

| motor | WER |
|---|---|
| `parakeet` | **3,21%** |
| `mlx-whisper` | 4,59% |

O sea que parakeet gana en las dos cosas a la vez: es 2 veces mas rapido que
mlx-whisper y ademas se equivoca menos. Por eso `motor: auto` lo elige primero.

### PERO: parakeet perdio el puesto. Se le va el idioma.

Esos numeros se midieron con **dictados cortos**. En el uso real aparecio un
modo de falla que los invalida: **arriba de ~18 s de audio, parakeet se pasa al
ingles y TRADUCE**. Del historial real de ese dia, sin cherry-pick:

| duracion | salida |
|---|---|
| 1,5 s / 2,0 s / 3,9 s / 5,6 s | espanol perfecto (4 de 4) |
| 18,4 s / 26,9 s / 32,9 s / 76,0 s | ingles roto (4 de 4) |

Hablando en espanol, la salida llegaba en un ingles sin sentido. En el de 76 s se
ve el mecanismo: alterna idioma dentro de la misma frase (media frase en ingles,
media en espanol). Es la identificacion de idioma del modelo oscilando.

**Y no se puede forzar.** El TDT no se condiciona por idioma como Whisper: no
hay `language=` en ningun lado. Verificado en vivo sobre parakeet-mlx 0.5.2 —
`transcribe()` acepta `chunk_duration` y `overlap_duration`, nada mas. El
`idioma` de config.json **nunca le llego** (por eso el `# noqa: ARG002`); el
`[parakeet es]` del log es solo una etiqueta.

Por eso el motor pasa a **`mlx-whisper` con `idioma: "es"`**, que si acepta
`language=` y entonces no puede salirse del espanol. Cuesta ~0,3 s mas por
dictado (0,43 s vs 0,12 s en uno corto; RTF 0,033 sobre audio largo) y se gana
que la jerga en ingles salga bien escrita, cosa que parakeet tampoco podia
(escribio *"Metax"* por Meta Ads y *"UPSEL"* por upsell).

**Limite honesto:** con el idioma clavado en `es`, una frase **entera** en
ingles se traduce al espanol. Palabras sueltas en ingles adentro de una frase
en espanol salen perfectas — que es como se habla en el dia a dia. Si alguna vez hace falta
dictar todo en ingles, `idioma: "auto"`, sabiendo que vuelve la deriva.
El RTF sano en una Mac con Apple Silicon ronda **~0,015**; el 0,03 que da como
sano la version de Windows es el de una placa NVIDIA con Whisper.

**El dato que manda todo esto:** `faster-whisper` corre sobre CTranslate2, y
CTranslate2 **no tiene backend Metal**. Verificado en vivo:

```
ctranslate2.get_supported_compute_types('mps')   -> unsupported device
ctranslate2.get_supported_compute_types('metal') -> unsupported device
```

O sea que el motor de la version de Windows -correcto en una PC con NVIDIA- en
una Mac corre en CPU y nada mas. Copiar esa config tal cual es quedarse con el peor
motor disponible en esta maquina.

**Parakeet vs Whisper.** Parakeet es un transductor, no un decodificador
autorregresivo: no entra en bucles repitiendo una palabra ni inventa
"Subtitulos por la comunidad de Amara.org". Trae puntuacion y mayusculas
propias y detecta el idioma solo (25 idiomas, espanol entre los mejores: 3,41%
WER en CoVoST segun la ficha de NVIDIA). **Lo que NO tiene es hotwords**: el
campo `vocabulario` de `config.json` no lo toca. Las palabras raras se
arreglan igual en `diccionario.txt`, que corre despues y sirve con cualquier
motor. Si el dueño necesita hotwords de verdad, se pasa a `mlx-whisper`.

## El bucle del decodificador

Sintoma: de 5 segundos de audio salen 782 caracteres de "beats, beats,
beats...". El filtro por RMS no lo agarra, y hace bien: el audio **es** voz
clara. El que se trabo fue el decodificador.

Con Parakeet esto practicamente no pasa (no hay decodificador autorregresivo).
Con los motores Whisper si, y se ataca en dos lugares:

1. `repetition_penalty` = 1.1 en el decodificador.
2. `colapsar_repeticiones()` sobre el texto ya armado. Los topes salen de medir
   300 dictados reales: repitiendo de verdad una persona llega a 9; los bucles
   reales fueron x56, x108 y x111. El corte va en 15 para palabras sueltas y en
   5 para frases. Si el bucle muere al final del texto se tira entero — **de un
   bucle no se deja recuerdo**.

## Musica, ruido y etiquetas

`ALUCINACIONES` mata las frases fantasma por substring. `ETIQUETAS_SONIDO` va
**aparte** y solo mata al segmento si es TODO el segmento, porque son palabras
normales del idioma: si "musica" se buscara como substring, dictar *"la musica
esta muy alta"* se perderia entero.

## Trampas de macOS ya pagadas (no las repitas)

- **Con Option apretado, macOS cambia el CARACTER que entrega la tecla.**
  Option+S es "ß", Option+C es "ç". Si el hotkey se compara por caracter,
  `ctrl+alt+s` no dispara NUNCA. Por eso todo se compara por **virtual
  keycode**, que no depende del modificador ni de la distribucion. Es el
  equivalente Mac de la trampa de los scan codes extendidos de Windows.
- **El permiso de Accesibilidad falla en silencio** (ver arriba).
- **El `.app` no es cosmetico.** Si se lanza el binario del venv directo, macOS
  le atribuye los permisos a un ejecutable sin nombre — y se pierden al
  reinstalar el venv. Lanzando `~/Applications/Whisper Flow.app`, el permiso
  queda a nombre de "Whisper Flow" y sobrevive.
- **Al pegar hay que fijar los flags del evento a EXACTAMENTE Cmd.** Si el dueño
  todavia tiene el dedo apoyado en Ctrl/Option, el Cmd+V inyectado sale como
  Ctrl+Cmd+V y no pega nada.
- **En Mac no existe la "Mezcla estereo".** Para `Ctrl+Option+S` hace falta un
  dispositivo virtual: BlackHole (existential.audio/blackhole).
- **Abrir el microfono al momento de grabar mete un chasquido** y el modelo
  alucina con eso. Por eso queda abierto siempre, con anillo de preescucha.
- **Parakeet quiere bfloat16.** `get_logmel` con float32 arriesga un choque de
  tipos contra los pesos. Se castea antes, igual que hace la libreria.

## El guardian (por que el dueño ya no deberia pedir ayuda)

Se instalo despues de encontrarlo colgado varias veces: el log decia
`Grabando... (habla)` y **nunca mas nada**. El proceso estaba vivo, el permiso
concedido, el modelo cargado — pero el key-up jamas llego, asi que `parar()`
no se llamo nunca y el dictado quedo grabando para siempre. Desde afuera se ve
igual que "no anda": apretas las teclas y no pasa nada.

`guardian.sh` corre cada 60 s (`local.whisperflow.guardian`) y reinicia si:

| Sintoma | Como lo detecta | Tope |
|---|---|---|
| el proceso no esta | `pgrep` | — |
| **la Mac durmio** | el hueco entre dos corridas suyas > 150 s | — |
| **quedo grabando** | la ultima linea del log es `Grabando` y el archivo no se toca hace rato | 150 s |
| dictado largo colgado | idem pero la linea dice `[largo]` | 2100 s |

Por eso `empezar()` marca `[largo]` en el log: sin esa marca, un dictado largo
legitimo de 10 minutos era indistinguible de un cuelgue y el guardian lo
mataba. **Si se toca ese log, respetar la marca.**

El guardian **solo reinicia**. No borra `historial.jsonl` ni toca
`config.json`. Cuando actua deja la razon en `guardian.log` — es el primer
archivo a mirar si el dueño dice "se reinicio solo".

**`reparar.command`** es lo mismo pero a mano, para cuando no quiere esperar
los 60 s: corta, arranca, espera a ver `Microfono abierto` en el log y avisa
LISTO o imprime el diagnostico (`--permisos` + las ultimas lineas). Resuelve
su propia ruta con `${0:A:h}`, asi que anda igual desde el alias del
Escritorio. Es lo que hay que decirle que toque ante cualquier queja, **antes**
de ponerse a diagnosticar.

## Como opera Claude sobre esto

1. **Arrancar / parar**: `iniciar.command` / `parar.command`. Como servicio:
   `launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/local.whisperflow.plist`.
2. **Diagnostico**: `--permisos` primero (es la causa mas comun), despues
   `--probar` (graba 5s, imprime nivel de senal y texto) y `--dispositivos`.
3. **Volver a medir**: `--banco archivo.wav` (wav mono de 16 kHz) mide los tres
   motores en la maquina de hoy. Para generar el wav de prueba:
   `say -v "Monica" -f texto.txt -o p.wav --data-format=LEF32@16000 --file-format=WAVE`
4. **Ajustar**: siempre `config.json` o `diccionario.txt`, nunca el .py.
   Despues de editar hay que reiniciar.
   **`prompt_inicial` se escribe como FRASE, no como lista de palabras.**
   Whisper imita el estilo del prompt: con una lista pelada sin tildes ni
   puntos, transcribe sin tildes ni puntos. Medido sobre el mismo audio,
   cambiando solo el prompt: lista -> *"como viene ... Fijate ... Avisame que
   te parece"*; frase -> *"cómo viene ... Fíjate ... Avísame qué te parece"*.
   La jerga en ingles sale igual de bien con los dos.
5. **Audio de diagnostico**: `guardar_audio: true` deja el .wav en `debug/`.
   Se poda solo a `debug_maximo` (40). Apagarlo al terminar.

## Sintomas y arreglo

| Lo que dice el dueño | Que tocar |
|---|---|
| "no reacciona a las teclas" | **`--permisos`**. Es esto el 90% de las veces |
| "aprieto y no pasa nada" (pero el log dice `Grabando...` y despues NADA) | se colgo grabando: nunca llego el key-up. Desde que existe el guardian, lo arregla solo en <60 s; a mano, `reparar.command` |
| "no me pega en la app" | mismo permiso de Accesibilidad; o `salida` en `portapapeles` |
| "tarda mucho" | mirar el RTF en el log ANTES de tocar nada. Si `motor` quedo en `faster-whisper`, ese es el problema: no usa la GPU |
| "se come palabras" | con motores Whisper, subir `beam_size` a 5 en el .py |
| "repite la misma palabra 50 veces" | pasar a `parakeet` (no tiene ese modo de falla) o bajar `repeticiones_tope` a 10 |
| "me borra repeticiones que si dije" | subir `repeticiones_tope` (15) y `repeticiones_tope_frase` (5) |
| "inventa texto cuando hay musica" | subir `vad_umbral` a 0.65-0.7 y `umbral_no_habla` a 0.8 |
| "no me toma las palabras de mi rubro" | `prompt_inicial` (frase, no lista) + `diccionario.txt` |
| **"hablo en espanol y me lo escribe en ingles"** | era parakeet arriba de 18 s. `motor` a `mlx-whisper` + `idioma: "es"`. Ver arriba |
| "no agarra nada / sale vacio" | `--probar`: si el pico es < 0.006 el micro no entra. Revisar Ajustes > Privacidad > Microfono |
| "el dictado largo me lo corto" | `duracion_maxima` (1800). OJO: no avisa, **RECORTA** |
| "quiero otra combinacion" | `hotkey` acepta cualquier combo sostenido |
| "a veces no agarra aunque sostuve" | rozo otra tecla y el seguro lo cancelo; o sostuvo menos de `duracion_minima` |
| "me corta cuando pienso" | subir `pausa_parrafo`, o usar `Ctrl+Option+Space` |
| "todo sale en un solo bloque" | bajar `pausa_parrafo` a 1.0-1.2 |
| "quiero transcribir un video que veo" | `Ctrl+Option+S`, y hace falta BlackHole instalado |
| "hablo en ingles y lo escribe en espanol" | con parakeet detecta solo; con Whisper, `idioma` a `auto` |

## Reglas

- **No proponer servicios en la nube.** El punto es que el audio nunca sale de
  la maquina.
- **El primer arranque descarga el modelo** y queda en `~/.cache/huggingface`.
  Avisar antes, no dejarlo colgado sin explicacion.
- **Nunca borrar `historial.jsonl`** sin preguntar: es el portapapeles del dueño.
- **Si existe una copia de la version original para Windows, no se toca.**
  Es otra plataforma y sirve tal cual para quien use PC.
