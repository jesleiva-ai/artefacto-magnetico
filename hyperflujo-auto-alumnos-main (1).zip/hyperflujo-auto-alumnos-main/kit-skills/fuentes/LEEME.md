# FUENTES — dónde tirar el material crudo para que el cerebro aprenda

Esta carpeta vive AFUERA del cerebro (es hermana de `cerebro/`) y NUNCA se
commitea. Acá va el material pesado y crudo; el cerebro guarda solo las
destilaciones.

## El circuito

1. Tirás archivos en la carpeta que corresponda (abajo).
2. Corrés `/minar <carpeta>` en Claude Code (parado en `cerebro/`).
3. Yo destilo: notas atómicas, lecciones y avances de proyecto, con su tag.
4. Los archivos ya minados se mueven a `procesado/` (nunca se borran).

## Las 3 carpetas

### mentorias/ → unidad "formaciones y mentorías"
Clases (las que das y las de las formaciones que tomás), formularios de
onboarding, materiales de las mentorías o cursos a los que asistís, procesos
de tu propio negocio.
→ Áreas del vault: `aprendizaje`, `ventas`, `marca-personal`

### productos/ → unidad "infoproductor / tiendas propias"
Landings ganadoras, swipe files, métricas de campañas escaladas (tuyas y de
terceros, sin datos personales), investigaciones de mercado, kits de oferta, creativos de referencia.
→ Áreas del vault: `productos-digitales`, `ofertas`, `meta-ads`

### llamadas/ → tu criterio en bruto
Transcripciones de tus llamadas (con clientes, socios, tu comunidad, 1:1 o
grupales). De acá sale lo más valioso: tus respuestas técnicas, tu criterio y
tu filosofía, en tus propias palabras.
→ Áreas: la que corresponda + `mentalidad` para tu forma de ver las cosas

## Formatos que puedo leer
`.md` `.txt` `.pdf` `.csv` `.json` `.vtt` `.srt` (transcripciones), imágenes
(capturas de métricas, creativos). Si es video o audio, primero necesito la
transcripción en texto.

## Reglas que respeto siempre
- Tu criterio (lo que decís vos) le gana a cualquier material de terceros.
- Anti-duplicado antes de escribir: nunca dos versiones de la misma regla.
- Nada se borra: lo minado se mueve a `procesado/`.
- Filtro de valor: si no le sirve a tu futuro yo ni al agente, no se convierte
  en nota. Se queda acá sin culpa.
