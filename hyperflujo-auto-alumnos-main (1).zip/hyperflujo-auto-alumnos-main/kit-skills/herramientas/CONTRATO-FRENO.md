# Contrato del freno compartido de Meta

Este archivo describe un **protocolo entre procesos**, no una función. Lo leen y
lo escriben cosas distintas, escritas en lenguajes distintos, por sesiones
distintas. Si lo cambiás, cambiás el contrato de todos.

Escrito después de que, en una operación real, el mismo bug apareciera **tres
veces**, una por cada implementación, y las tres pruebas dieran verde porque cada lado probó
su propio dialecto.

---

## Por qué existe el freno

En una operación real se perdió una app con `code 200 · API access blocked`. No
por hacer algo prohibido: por **velocidad** y por **reintentar después de que Meta ya lo
había frenado**. La doc de Meta es textual:

> *"If you reach the limit, stop making API calls. If you continue making calls,
> the call count won't stop increasing."*

**Parar, no esperar y reintentar.** Un reintento cortés sigue siendo un reintento.

---

## Quiénes participan

| Proceso | Qué hace con Meta | Freno | Ritmo | Libro |
|---|---|---|---|---|
| `meta_ads.py` (+ `clonar-conjunto.py`) | crea y edita | lee **y escribe** | lee y escribe | escribe |
| `hook-freno-meta.py` | compuerta del conector MCP | lee | lee y escribe | escribe |
| `meta-cli.py` (CLI oficial de Meta) | lo que le pidan | lee | lee y escribe | escribe |
| un panel propio (opcional, si lo armás) | solo lee métricas | lee **y escribe** | no lo toca | escribe (`quien`) |

**Cualquiera que reciba un código de estrangulamiento escribe el freno.** Es la
corrección más importante del documento: en una operación real, un panel de
métricas solo *leía* el freno. Media compuerta — sirve cuando el que se pasa es
otro, no sirve cuando el que se pasa es uno mismo. Ese panel se comió una
seguidilla de códigos 17 **sin escribir el freno una sola vez**, y las tres
puertas siguieron abiertas porque nadie les avisó.

Códigos que obligan a frenar y **cortar la corrida en el acto**, sin reintentos:
`4, 17, 32, 613, 80000, 80003, 80004, 80014`.

Cuidado con los `.catch(() => [])` y los `except: pass`: se tragan el corte y
convierten un freno en un log.

## Los archivos

| Archivo | Quién escribe | Quién lee |
|---|---|---|
| `logs/meta-ads-enfriamiento.json` | `meta_ads.py`, el panel propio (si hay) | todos |
| `logs/meta-ads-ritmo` | `meta_ads.py`, `hook-freno-meta.py` | los mismos |
| `logs/meta-ads-libro.jsonl` | todos | `salud`, `ascenso`, el hook |
| `logs/meta-ads-tier.txt` | `meta_ads.py` | `meta_ads.py`, el hook |

Las tres puertas a Meta: el script (`meta_ads.py`), el conector MCP (vigilado por
`hook-freno-meta.py`) y el CLI oficial (envuelto por `meta-cli.py`). Un panel
propio, si lo tenés, es una cuarta boca, de solo lectura, pero consume del mismo
cupo.

---

## `meta-ads-enfriamiento.json` — el freno

```json
{"hasta": 1786654312.05, "motivo": "code 17 en act_123", "escrito": "..."}
```

### La regla que se rompió tres veces

**`hasta` puede llegar en tres formatos, y todo lector tiene que aceptar los
tres.** No porque sea elegante: porque puede haber varios escritores y ninguno
se puso de acuerdo antes.

| Forma | Ejemplo | Quién la produce | Cómo se distingue |
|---|---|---|---|
| epoch en **segundos** | `1786654312.05` | `meta_ads.py` (`time.time() + n`) | número ≤ `1e11` |
| epoch en **milisegundos** | `1786654312052` | JavaScript (`Date.now() + n`) | número > `1e11` |
| **ISO** | `2030-01-15T17:51:52-03:00` | cualquiera, y `POST /api/freno` | texto |

El corte en `1e11` separa limpio: `1e11` segundos es el año 5138 y `1e11`
milisegundos es 1973. Ningún valor real cae del lado equivocado.

Y dentro de ISO hay **tres husos distintos**: `Z`, `-03:00`, y **`-0300` pegado**.
El último es el que produce `strftime('%z')` de Python — o sea el formato con el
que esta misma casa escribe el libro— y **no lo parsea ninguno de los dos
lenguajes sin normalizar**: ni `fromisoformat` de Python 3.9 ni `Date.parse` de
JavaScript. Normalizar `±HHMM` → `±HH:MM` antes de parsear, en los dos lados.

### Los tres bugs, para que no vuelvan

1. **Un lector en JavaScript leía segundos como milisegundos.** `new Date(1786654312)`
   da **1970** → el freno figuraba siempre vencido → ese proceso seguía
   llamando con el freno puesto.
2. **El hook fallaba ABIERTO.** `float(hasta)` sobre un ISO tiraba `ValueError`,
   la excepción subía hasta un `except: pass` y el hook **salía sin denegar**. La
   compuerta cuyo único trabajo es fallar cerrada, fallaba abierta.
3. **El huso compacto no lo parsea nadie.** `strftime('%z')` produce `-0300`
   *pegado*. Ni el `fromisoformat` de Python 3.9 ni el `Date` de JavaScript lo
   aceptan: los dos quieren `-03:00`. Y `-0300` es justamente el formato con el
   que esta misma casa escribe las fechas del libro. **Hay que normalizarlo
   antes de parsear, en los dos lenguajes.**

### Las dos reglas duras del lector

- **FALLA CERRADA.** Si el archivo existe pero `hasta` no se entiende —basura,
  `null`, un booleano, un ISO raro— se asume **freno ACTIVO**. Perder un turno
  es barato. Seguir llamando después de que Meta frenó cuesta la app.
- **Archivo ausente = sin freno.** Esa es la única forma de "no hay freno". Un
  archivo presente e ilegible **no** es lo mismo que un archivo ausente.

### Cómo se prueba

| Lector | Prueba | Casos |
|---|---|---|
| script + hook | `~/herramientas/probar-freno.py` | 19 |
| panel propio (si hay) | su propia prueba, con los mismos casos | — |

A demanda, no una sola vez. Un guardián que nunca volvió a fallar está sin
estrenar.

**Comparar el valor entendido contra el escrito, no `deny`/`allow`.** Un valor
ilegible *también* frena, y un `hasta` de 5 minutos leído como 5 años frena
igual y está roto. Mirar solo el veredicto no distingue *"lo entendió"* de *"no
lo entendió y se asustó"*. Esa ceguera dejó pasar el bug 3.

**Y la prueba NO puede tocar la red.** En una operación real, la prueba del
freno de un panel corría contra su endpoint de refresco, y cada caso "sin freno"
disparaba decenas de llamadas reales: la matriz completa, dos veces, más las
corridas de desarrollo, gastaron cientos de llamadas en media hora y terminaron
en una seguidilla de códigos 17. Una prueba de
freno que le pega a Meta gasta exactamente el recurso que el freno protege. Se
prueba contra el archivo o contra un doble. Lo que se está probando es el
**parser**, no el motor.

---

## `meta-ads-ritmo` — la cola

```json
{"_global": 1786654312.0, "act_000000000000000": 1786654315.0}
```

**Una cola POR CUENTA PUBLICITARIA**, no global. Doc oficial de Meta:

> *"Rate limiting is at the ad account level."* Cada cuenta mantiene su propio
> score.

Una cola global hacía esperar a la cuenta B lo que solo debía la cuenta A: más
lento sin proteger más. Se podan las claves de más de 1 hora. El formato viejo
(un número suelto) se migra solo a `{"_global": <n>}`.

Ritmo según el tier real que informa Meta (`logs/meta-ads-tier.txt`):

| Tier | Lectura | Escritura |
|---|---|---|
| `development_access` | 5 s | 15 s |
| `standard_access` / `advanced_access` | 1 s | 6 s |

En `development_access` son 60 puntos cada 300 s (lectura 1, escritura 3): 20
escrituras × 3 = 60 = el techo exacto. **Sin dato del tier se asume el más
restrictivo.**

---

## `meta-ads-libro.jsonl` — el libro

```json
{"t": "2030-01-15T17:51:52-0300", "m": "POST", "ruta": "...", "ok": true, "code": null, "via": "mcp"}
```

`t` es **ISO con huso, no un número**. La clave del método es **`m`**, no
`metodo`. Leerlas mal fue un bug real: el hook contaba cero escrituras y el techo
horario quedaba desactivado.

Las tres puertas anotan en el mismo libro, porque el sistema de riesgo de Meta
que vigila el patrón de la cuenta (30+ cambios/hora) **mira la cuenta, no la
puerta**. Techo propio: 25 escrituras/hora.

---

## Opcional: `POST /api/freno` (si tenés una herramienta propia en la nube)

Viene **apagado**. Solo aplica si armaste un panel o un cron propio que corre en
un servidor y consulta la misma cuenta: ese servidor no ve este disco. Sin
propagación, Meta nos frena, el script para y el cron remoto sigue llamando.

```
POST https://<panel>/api/freno
Authorization: Bearer $CRON_SECRET
{"segundos": 300, "motivo": "code 17 en act_123"}
```

Soltar con `{"segundos": 0}`. Acepta también `{"hasta": <epoch s|ms|ISO>}`.
Local y remoto se consultan los dos: **cualquiera de los dos frena.**

Del lado de `meta_ads.py` lo hace `_avisar_al_panel()`, y el orden importa:
**el freno local se escribe ANTES del POST**, el POST tiene timeout de 5 s y
cualquier fallo es silencioso. Un remoto caído nunca puede desfrenar el script.

Duerme hasta que estén las dos claves en el Llavero:

```sh
security add-generic-password -a cerebro -s meta-freno-remoto-url    -w
security add-generic-password -a cerebro -s meta-freno-remoto-secret -w
```

---

## Si agregás un cuarto escritor

1. Leé este archivo entero antes de escribir código.
2. Probá **con el formato de los otros**, no con el tuyo. Los tres bugs de arriba
   pasaron las pruebas de su propio autor.
3. Compará **valores**, no veredictos.
4. Ante la duda, frená.
