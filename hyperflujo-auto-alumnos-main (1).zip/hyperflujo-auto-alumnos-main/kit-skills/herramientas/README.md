# Herramientas del cerebro

Los scripts que hacen funcionar el cerebro por fuera de Claude Code. Conviene
tenerlos bajo control de versiones: son el codigo del que dependen el hook de
arranque y los pipelines automaticos.

## Que hay
| Script | Que hace |
|---|---|
| `pipeline-jardin.sh` | Corre el jardinero del vault los domingos |
| `ojos.py` | Control de Chrome por CDP: ver artifacts y paginas tras login |
| `espia_fb.py` | Biblioteca de Anuncios de Meta |
| `bajar_creativos.py` | Descarga de creativos ganadores |
| `ocr.swift` | OCR local con Vision (sin API, sin costo). **Solo Mac** |
| `hoy.py` | La fecha de hoy en la zona del cerebro, igual en Mac, Linux y Windows |
| `guardar-artifact.py` | Congela artifacts fechados en `~/fuentes/artifacts/` |
| `fuente-artifact.sh` | Baja el HTML COMPLETO de un artifact ajeno (ver limitacion abajo) |
| `paleta.py` | Mide la paleta REAL de una pagina desde su render y cuenta familias de tono. **Solo Mac** (usa `sips`) |
| `hook-ver-artifact.sh` | Hook `PostToolUse` sobre Artifact: fotografia lo publicado y corta el turno hasta mirarlo |

| `shopify.py` | Admin API: lee ventas/PDP **y publica landings + sube creativos al CDN** |
| `meta_ads.py` | Graph API de Meta. Ver abajo: hay una segunda via, el conector MCP |

## Las dos vias a Meta Ads

`meta_ads.py` **no es la unica**. El conector oficial **Meta Ads MCP** ya esta
autorizado en las sesiones de Claude y cubre casi todo sin token propio: crear
campanias, conjuntos y anuncios (nacen en PAUSED por diseno), leer metricas,
mover presupuestos. Confirma con `ads_get_ad_accounts` que la cuenta destino
traiga `is_ads_mcp_enabled: true`.

El conector tiene **un solo hueco**: sus dos uploads (`ads_creative_upload_image`
y `_video`) descargan de una **URL publica** y no leen del disco — su doc avisa
que Drive y Dropbox no sirven. Para eso esta:

    shopify.py subir-archivo <ruta>   # -> URL del CDN de tu tienda, ya verificada

Asi los creativos no salen de la infraestructura propia. `meta_ads.py` sigue
siendo necesario para correr **desatendido** (cron/launchd, sin chat abierto).

## Publicar landings sin que nadie pegue codigo

    shopify.py temas                                        # cual es el vivo
    shopify.py probar-escritura --tema <ID no vivo>          # el token, puede?
    shopify.py publicar --tema <ID> --dir <salida>           # SIMULACRO
    shopify.py publicar --tema <ID> --dir <salida> --confirmar

Tres guardas en el codigo: simulacro por defecto, se niega sobre el tema VIVO, y
**relee de la tienda archivo por archivo** despues de escribir. Que Shopify diga
"escrito" no es que este escrito.

Requiere `read_themes` + `write_themes` en el token de `~/.config/shopify.json`.
La exencion de Shopify para `write_themes` aplica a apps **distribuidas en el App
Store**; una app personalizada del propio admin recibe el permiso del dueno.
`probar-escritura` lo confirma escribiendo de verdad, que es la unica prueba.

## Trabajar con artifacts: dos trampas que ya nos costaron tiempo
**1. El contenido no esta en la URL que ves.** Se pinta en un iframe de otro
origen: `<uuid>.frame.claudeusercontent.com/_f/<token>/`. Para artifacts AJENOS
ese frame responde a `curl` sin cookies — eso hace `fuente-artifact.sh`. Para los
PROPIOS devuelve **403**, porque su token es de sesion: ahi va `ojos.py ver`.

**2. La version vive en el path del frame, no en un cache con vencimiento.** Cada
republicacion acuna un path nuevo. Un cliente que quedo agarrado al path viejo
muestra esa version **para siempre**, y ni el modo incognito lo suelta. Pasa de
verdad: la PC muestra la ultima y el celular una vieja.
Regla: iterar sobre la misma URL esta bien mientras se prueba, pero **cuando la
pieza se va a mirar en otro dispositivo o mandar a alguien, publicar URL nueva**.
Y verificar con un marcador de texto concreto, nunca preguntando "se ve bien?".

## Credenciales
**Ningun secreto esta en el codigo.** las herramientas los leen del
llavero de macOS (`del_llavero("nombre-del-secreto")`). Mantener ese patron:
nada de tokens en los archivos.

## Que NO se versiona
`chrome-ojos/` (perfil de Chrome con la sesion de FB iniciada),
`venv-notebooklm/`, `logs/` y los JSON de datos scrapeados. Pesan mucho y no son
codigo. El `.gitignore` es una whitelist: solo entra codigo.

## Backup
Solo local, igual que `~/.claude`. Para respaldo externo hace falta un repo
privado — decision del dueño.
