#!/usr/bin/env python3
"""anatomia.py — la radiografia tecnica de una landing ajena.

QUE RESUELVE
  ojos.py 'ver' da el texto y 'foto' da los pixeles. Falta la capa del medio:
  como esta CONSTRUIDA. Que stack, que tipografias reales, la paleta pesada por
  area pintada, cada imagen con su tamano natural y su relacion de aspecto
  (16:9 / 3:2 / 1:1 / 4:5), como estan armados los carruseles (libreria,
  cantidad de slides, segundos de autoplay, desvanecimiento en los bordes), y
  de donde salio cada asset.

  El pedido que la origina: entrar a cada landing que se quiere replicar y ver
  como esta estructurada, como esta el diseno del HTML, que tiene de front, que
  tamano de imagen usa, si es 16:9 o 3:2, como estan armados los carruseles,
  cuantos segundos duran, si tienen desvanecimiento a los costados, y que
  tamano tienen los mockups.

  Sin esto, replicar es adivinar.

HUELLAS DE ORIGEN DE ASSETS
  Los nombres de archivo delatan con que se genero cada imagen y casi nunca los
  renombran:
    ChatGPT / DALL-E  -> el nombre queda literal ("ChatGPT Image ...", "DALL-E")
    Higgsfield        -> arranca con "hg" o vive en dominio higgsfield
    Midjourney        -> patron UUID largo + "_" en el nombre
    Canva             -> "canva" o hash con guiones bajos
  Saber el origen dice con que herramienta se replica el asset.

USO
  anatomia.py <url>                 # informe legible
  anatomia.py <url> --json          # crudo, para guardar en el vault
  anatomia.py <url> --escritorio    # mide en 1280px en vez de celular

Solo lectura. No toca la pagina, no envia nada.
"""

import argparse
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ojos  # reutiliza el cliente CDP sin dependencias


SONDA = r"""
(() => {
  const out = {};
  const abs = (u) => { try { return new URL(u, location.href).href } catch(e){ return u } };

  // ── stack ────────────────────────────────────────────────────────────────
  const html = document.documentElement.outerHTML;
  const pistas = {
    "Next.js": /__NEXT_DATA__|\/_next\//, "React": /react|_reactRoot|data-reactroot/i,
    "Vue": /__vue__|data-v-[0-9a-f]{8}/, "Svelte": /svelte-[a-z0-9]{6}/,
    "Shopify": /cdn\.shopify\.com|Shopify\.theme/, "WordPress": /wp-content|wp-includes/,
    "Elementor": /elementor/i, "Webflow": /webflow/i, "Wix": /wix(static|apps)/i,
    "Lovable": /lovable\.(app|dev)/i, "Framer": /framerusercontent/i,
    "Vercel": /vercel\.(app|com)/i, "Impultienda": /impultienda/i,
    "Tailwind": /(^|\s)(bg-|text-|flex |grid |px-\d|py-\d)/,
    "Hotmart": /hotmart/i, "Kiwify": /kiwify/i, "MercadoPago": /mercadopago/i,
    "Stripe": /js\.stripe\.com/, "Meta Pixel": /connect\.facebook\.net|fbq\(/,
    "GA4": /googletagmanager|gtag\(/, "TikTok Pixel": /analytics\.tiktok/,
  };
  out.stack = Object.keys(pistas).filter(k => pistas[k].test(html));

  // ── checkout / links de pago ─────────────────────────────────────────────
  const pago = /hotmart|kiwify|stripe|mercadopago|paypal|gumroad|payhip|lemonsqueezy|checkout|\/cart|\/pay/i;
  out.checkout = [...new Set([...document.querySelectorAll("a[href]")]
    .map(a => a.href).filter(h => pago.test(h)))].slice(0, 10);

  // ── tipografias realmente pintadas ───────────────────────────────────────
  const fam = {};
  const rol = (el) => { const t = el.tagName; return /^H[1-3]$/.test(t) ? "titulo"
    : (t === "BUTTON" || /\bbtn|cta\b/i.test(el.className||"")) ? "boton" : "texto" };
  document.querySelectorAll("h1,h2,h3,p,li,button,a,span,div").forEach(el => {
    if (!el.textContent || !el.textContent.trim()) return;
    const r = el.getBoundingClientRect(); if (r.width < 8 || r.height < 8) return;
    const c = getComputedStyle(el);
    const k = c.fontFamily.split(",")[0].replace(/["']/g, "").trim();
    if (!k) return;
    fam[k] = fam[k] || { usos: 0, pesos: {}, tams: {}, roles: {} };
    fam[k].usos++;
    fam[k].pesos[c.fontWeight] = (fam[k].pesos[c.fontWeight] || 0) + 1;
    const px = Math.round(parseFloat(c.fontSize));
    fam[k].tams[px] = (fam[k].tams[px] || 0) + 1;
    const rr = rol(el); fam[k].roles[rr] = (fam[k].roles[rr] || 0) + 1;
  });
  out.tipografias = Object.entries(fam).sort((a,b) => b[1].usos - a[1].usos).slice(0,6)
    .map(([n,v]) => ({ familia:n, usos:v.usos,
      pesos:Object.entries(v.pesos).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]),
      tamanos:Object.entries(v.tams).sort((a,b)=>b[1]-a[1]).slice(0,4).map(x=>x[0]+"px"),
      roles:Object.entries(v.roles).sort((a,b)=>b[1]-a[1]).map(x=>x[0]) }));

  // ── paleta pesada por area pintada (no por cantidad de reglas) ───────────
  const area = {}, tinta = {};
  document.querySelectorAll("*").forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return;
    const c = getComputedStyle(el);
    const bg = c.backgroundColor;
    if (bg && !/rgba\(0, 0, 0, 0\)|transparent/.test(bg))
      area[bg] = (area[bg] || 0) + r.width * r.height;
    if (el.textContent && el.textContent.trim() && el.children.length === 0)
      tinta[c.color] = (tinta[c.color] || 0) + r.width * r.height;
  });
  const hex = (s) => { const m = s.match(/\d+/g); return m
    ? "#" + m.slice(0,3).map(n => (+n).toString(16).padStart(2,"0")).join("") : s };
  const top = (o, n) => Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,n)
    .map(([c,a]) => ({ color: hex(c), rgb: c, area_px2: Math.round(a) }));
  out.paleta = { fondos: top(area, 8), tintas: top(tinta, 5) };

  // ── imagenes: tamano natural, aspecto, origen ────────────────────────────
  const rec = {};
  try { performance.getEntriesByType("resource").forEach(e => {
    rec[e.name] = e.transferSize || e.encodedBodySize || 0 }) } catch(e){}

  const aspecto = (w,h) => {
    if (!w || !h) return "?";
    const r = w/h, tabla = [["1:1",1],["4:5",0.8],["3:4",0.75],["9:16",0.5625],
      ["16:9",1.7778],["3:2",1.5],["2:3",0.6667],["4:3",1.3333],["21:9",2.3333],["2:1",2]];
    let mej = tabla[0], dif = 9;
    tabla.forEach(t => { const d = Math.abs(r - t[1]) / t[1]; if (d < dif) { dif = d; mej = t } });
    return dif < 0.04 ? mej[0] : r.toFixed(2) + ":1";
  };
  const origen = (u) => {
    const n = decodeURIComponent(u.split("/").pop().split("?")[0]);
    if (/chatgpt|dall[\-_ ]?e/i.test(n)) return "ChatGPT / DALL-E";
    // verificado 2026-07-28 contra una generacion propia: el prefijo real es "hf_"
    if (/^h[fg][-_][0-9]/i.test(n) || /higgsfield|d8j0ntlcm91z4/i.test(u)) return "Higgsfield";
    if (/midjourney|^[0-9a-f]{8}-[0-9a-f]{4}-.*_\d/i.test(n)) return "Midjourney";
    if (/canva/i.test(n) || /canva/i.test(u)) return "Canva";
    if (/unsplash|pexels|istock|shutterstock|freepik/i.test(u)) return "banco de imagenes";
    if (/cdn\.shopify/i.test(u)) return "subida a Shopify";
    if (/lovable|r2\.dev/i.test(u)) return "Lovable / R2";
    return "";
  };

  const vistas = new Set();
  out.imagenes = [...document.querySelectorAll("img")].map(im => {
    const r = im.getBoundingClientRect();
    const src = abs(im.currentSrc || im.src || "");
    if (!src || vistas.has(src)) return null; vistas.add(src);
    return {
      url: src.length > 130 ? src.slice(0,130) + "…" : src,
      archivo: decodeURIComponent(src.split("/").pop().split("?")[0]).slice(0,70),
      natural: im.naturalWidth + "×" + im.naturalHeight,
      aspecto: aspecto(im.naturalWidth, im.naturalHeight),
      mostrada: Math.round(r.width) + "×" + Math.round(r.height),
      kb: rec[src] ? Math.round(rec[src]/1024) : null,
      formato: (src.match(/\.(png|jpe?g|webp|avif|svg|gif)/i) || [,"?"])[1].toLowerCase(),
      loading: im.loading || "",
      origen: origen(src),
      alt: (im.alt || "").slice(0,60),
    };
  }).filter(Boolean);

  // fondos CSS grandes (los heroes suelen ir por background-image)
  out.fondos_css = [];
  document.querySelectorAll("*").forEach(el => {
    const c = getComputedStyle(el), m = c.backgroundImage.match(/url\(["']?(.+?)["']?\)/);
    if (!m) return; const r = el.getBoundingClientRect();
    if (r.width * r.height < 20000) return;
    out.fondos_css.push({ url: abs(m[1]).slice(0,120), caja: Math.round(r.width)+"×"+Math.round(r.height),
      size: c.backgroundSize, position: c.backgroundPosition, origen: origen(abs(m[1])) });
  });
  out.fondos_css = out.fondos_css.slice(0, 12);

  // ── carruseles ───────────────────────────────────────────────────────────
  const libs = { swiper:".swiper", slick:".slick-slider", embla:"[class*=embla]",
    glide:".glide", splide:".splide", keen:"[class*=keen-slider]",
    flickity:".flickity-enabled", owl:".owl-carousel", tiny:".tns-slider" };
  out.carruseles = [];
  Object.entries(libs).forEach(([nom, sel]) => {
    document.querySelectorAll(sel).forEach(el => {
      const slides = el.querySelectorAll(
        ".swiper-slide,.slick-slide,[class*=embla__slide],.glide__slide,.splide__slide,[class*=keen-slider__slide],.carousel-cell,.owl-item,.tns-item");
      const cs = getComputedStyle(el);
      let seg = null;
      const inst = el.swiper || el.__vue__ || null;
      if (inst && inst.params && inst.params.autoplay && inst.params.autoplay.delay)
        seg = inst.params.autoplay.delay / 1000;
      if (seg === null) { const d = el.getAttribute("data-interval") || el.getAttribute("data-autoplay");
        if (d && !isNaN(+d)) seg = +d > 100 ? +d/1000 : +d }
      const prim = slides[0];
      const pr = prim ? prim.getBoundingClientRect() : null;
      out.carruseles.push({
        libreria: nom, slides: slides.length,
        autoplay_seg: seg,
        transicion_ms: inst && inst.params ? inst.params.speed : null,
        efecto: inst && inst.params ? inst.params.effect : null,
        por_vista: inst && inst.params ? inst.params.slidesPerView : null,
        gap_px: inst && inst.params ? inst.params.spaceBetween : null,
        loop: inst && inst.params ? !!inst.params.loop : null,
        slide_caja: pr ? Math.round(pr.width)+"×"+Math.round(pr.height) : null,
        // el "desvanecimiento a los costados" vive en mask-image o en un ::before con gradiente
        mask: cs.maskImage !== "none" ? cs.maskImage.slice(0,90)
            : (cs.webkitMaskImage && cs.webkitMaskImage !== "none" ? cs.webkitMaskImage.slice(0,90) : null),
        overflow: cs.overflow,
      });
    });
  });
  // carruseles a mano: scroll horizontal con snap
  document.querySelectorAll("*").forEach(el => {
    const c = getComputedStyle(el);
    if (!/auto|scroll/.test(c.overflowX)) return;
    if (el.scrollWidth <= el.clientWidth + 40) return;
    if (el.children.length < 2) return;
    const r = el.getBoundingClientRect(); if (r.width < 150) return;
    out.carruseles.push({ libreria: "scroll nativo (sin libreria)",
      slides: el.children.length, snap: c.scrollSnapType,
      autoplay_seg: null,
      slide_caja: Math.round(el.children[0].getBoundingClientRect().width)+"×"+
                  Math.round(el.children[0].getBoundingClientRect().height),
      mask: c.maskImage !== "none" ? c.maskImage.slice(0,90) : null,
      gap_px: c.gap });
  });
  out.carruseles = out.carruseles.slice(0, 10);

  // ── secciones y botones (donde cae la linea de oferta) ────────────────────
  const alto = document.body.scrollHeight;
  out.alto_total_px = alto;
  out.secciones = [...document.querySelectorAll("section,main>div,body>div>div")]
    .map(el => { const r = el.getBoundingClientRect();
      if (r.height < 120) return null;
      const c = getComputedStyle(el);
      return { alto: Math.round(r.height),
        desde_pct: Math.round((r.top + scrollY) / alto * 100),
        fondo: hex(c.backgroundColor),
        texto: (el.innerText || "").trim().slice(0, 60).replace(/\s+/g," ") } })
    .filter(Boolean).slice(0, 30);

  out.botones = [...document.querySelectorAll("a,button")].map(b => {
    const t = (b.innerText || "").trim(); if (!t || t.length > 60) return null;
    const r = b.getBoundingClientRect(); if (r.height < 24 || r.width < 60) return null;
    const c = getComputedStyle(b);
    // un CTA puede pintarse con color solido, con gradiente, o ser un <button> pelado
    const solido = !/rgba\(0, 0, 0, 0\)|transparent/.test(c.backgroundColor);
    const grad = /gradient/i.test(c.backgroundImage);
    const borde = parseFloat(c.borderTopWidth) > 0;
    if (!solido && !grad && !borde && b.tagName !== "BUTTON") return null;
    const y = r.top + scrollY;
    return { texto: t.replace(/\s+/g," "),
      fondo: grad ? c.backgroundImage.slice(0,46) : hex(c.backgroundColor),
      radio: c.borderRadius, alto: Math.round(r.height),
      en_pct: Math.round(y / alto * 100),
      destino: b.tagName === "A" ? (b.getAttribute("href")||"").slice(0,80) : "" } })
    .filter(Boolean).slice(0, 25);

  out.titulo = document.title;
  out.url = location.href;
  return out;
})()
"""


def sonda(url, escritorio, espera):
    if not ojos.vivo():
        sys.exit("Chrome de trabajo apagado. Arrancalo con: ojos.py abrir")
    ancho, alto = (1280, 900) if escritorio else (390, 844)
    cdp = ojos.CDP(ojos.http_json("/json/version")["webSocketDebuggerUrl"])
    tid = None
    try:
        tid = cdp.cmd("Target.createTarget", {"url": url})["targetId"]
        ses = cdp.cmd("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]
        cdp.cmd("Page.enable", sesion=ses)
        cdp.cmd("Runtime.enable", sesion=ses)
        cdp.cmd("Emulation.setDeviceMetricsOverride",
                {"width": ancho, "height": alto, "deviceScaleFactor": 2,
                 "mobile": not escritorio}, sesion=ses)
        time.sleep(espera)
        # bajar hasta el fondo para que carguen lazy y se instancien los carruseles
        cdp.cmd("Runtime.evaluate",
                {"expression": "window.scrollTo(0,document.body.scrollHeight)"}, sesion=ses)
        time.sleep(3)
        cdp.cmd("Runtime.evaluate", {"expression": "window.scrollTo(0,0)"}, sesion=ses)
        time.sleep(1.5)
        r = cdp.cmd("Runtime.evaluate",
                    {"expression": SONDA, "returnByValue": True, "awaitPromise": False},
                    sesion=ses, espera=60)
        if "exceptionDetails" in r:
            sys.exit("La sonda fallo: " + json.dumps(r["exceptionDetails"])[:400])
        return r["result"]["value"]
    finally:
        if tid:
            try:
                cdp.cmd("Target.closeTarget", {"targetId": tid})
            except Exception:
                pass
        cdp.cerrar()


def informe(d):
    P = print
    P(f"\n╔═ {d.get('titulo','')[:70]}")
    P(f"╚═ {d.get('url','')[:90]}\n")

    P("── STACK " + "─" * 52)
    P("  " + (", ".join(d["stack"]) or "no identificado"))
    if d["checkout"]:
        P("  checkout:")
        for c in d["checkout"]:
            P(f"    {c[:88]}")

    P("\n── TIPOGRAFIAS (por uso real pintado) " + "─" * 24)
    for t in d["tipografias"]:
        P(f"  {t['familia'][:26]:<26} {t['usos']:>4} usos · pesos {','.join(t['pesos'])}"
          f" · {' '.join(t['tamanos'])} · {'/'.join(t['roles'][:2])}")

    P("\n── PALETA (por area pintada) " + "─" * 33)
    for c in d["paleta"]["fondos"]:
        P(f"  fondo  {c['color']:<9} {c['rgb']:<22} {c['area_px2']:>12,} px²")
    for c in d["paleta"]["tintas"]:
        P(f"  tinta  {c['color']:<9} {c['rgb']:<22} {c['area_px2']:>12,} px²")

    P(f"\n── IMAGENES ({len(d['imagenes'])}) " + "─" * 44)
    P(f"  {'archivo':<40} {'natural':<12} {'asp':<7} {'kb':>5}  origen")
    for i in d["imagenes"]:
        P(f"  {i['archivo'][:40]:<40} {i['natural']:<12} {i['aspecto']:<7} "
          f"{(str(i['kb']) if i['kb'] else '?'):>5}  {i['origen']}")
    aspectos = {}
    for i in d["imagenes"]:
        aspectos[i["aspecto"]] = aspectos.get(i["aspecto"], 0) + 1
    if aspectos:
        P("  → aspectos usados: " + ", ".join(
            f"{k} ×{v}" for k, v in sorted(aspectos.items(), key=lambda x: -x[1])))
    orig = {}
    for i in d["imagenes"]:
        if i["origen"]:
            orig[i["origen"]] = orig.get(i["origen"], 0) + 1
    if orig:
        P("  → origen de assets: " + ", ".join(f"{k} ×{v}" for k, v in orig.items()))

    if d["fondos_css"]:
        P(f"\n── FONDOS CSS ({len(d['fondos_css'])}) " + "─" * 40)
        for f in d["fondos_css"]:
            P(f"  {f['caja']:<12} {f['size']:<14} {f['origen']:<18} {f['url'][:60]}")

    P(f"\n── CARRUSELES ({len(d['carruseles'])}) " + "─" * 41)
    if not d["carruseles"]:
        P("  ninguno")
    for c in d["carruseles"]:
        P(f"  {c['libreria']}: {c['slides']} slides · slide {c.get('slide_caja')}")
        det = []
        if c.get("autoplay_seg") is not None: det.append(f"autoplay {c['autoplay_seg']}s")
        if c.get("transicion_ms"): det.append(f"transicion {c['transicion_ms']}ms")
        if c.get("efecto"): det.append(f"efecto {c['efecto']}")
        if c.get("por_vista"): det.append(f"{c['por_vista']} por vista")
        if c.get("gap_px") not in (None, "normal"): det.append(f"gap {c['gap_px']}")
        if c.get("loop") is not None: det.append("loop" if c["loop"] else "sin loop")
        if c.get("snap"): det.append(f"snap {c['snap']}")
        if det: P("     " + " · ".join(str(x) for x in det))
        P("     desvanecimiento lateral: " + (c["mask"] if c.get("mask") else "NO"))

    P(f"\n── ESTRUCTURA · {d['alto_total_px']}px de alto " + "─" * 26)
    for s in d["secciones"]:
        P(f"  {s['desde_pct']:>3}%  {s['alto']:>5}px  {s['fondo']:<9} {s['texto'][:44]}")

    P(f"\n── BOTONES ({len(d['botones'])}) — donde cae la linea de oferta " + "─" * 12)
    for b in d["botones"]:
        P(f"  {b['en_pct']:>3}%  {b['fondo']:<9} r{b['radio'][:6]:<7} {b['texto'][:44]}")
    P("")


def main():
    ap = argparse.ArgumentParser(description="Radiografia tecnica de una landing (solo lectura).")
    ap.add_argument("url")
    ap.add_argument("--escritorio", action="store_true", help="medir en 1280px")
    ap.add_argument("--espera", type=float, default=7)
    ap.add_argument("--json", action="store_true", help="salida cruda")
    a = ap.parse_args()

    d = sonda(a.url if a.url.startswith("http") else "https://" + a.url, a.escritorio, a.espera)
    if a.json:
        print(json.dumps(d, indent=2, ensure_ascii=False))
    else:
        informe(d)


if __name__ == "__main__":
    main()
