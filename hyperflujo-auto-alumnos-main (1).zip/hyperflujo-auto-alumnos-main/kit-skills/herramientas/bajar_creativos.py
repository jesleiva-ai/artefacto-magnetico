#!/usr/bin/env python3
"""Baja los creativos extraidos por espia_fb.py y saca frames.

Salida: ~/fuentes/creativos/<carpeta>/
  <id>-<tienda>.mp4 / <id>-<tienda>-img<N>.jpg / poster
  frames/<id>-<tienda>/f-XXXX.jpg  (1 frame cada 3 s)
  tarjetas.json (copia del JSON fuente con el texto de cada tarjeta)
"""
import json
import re
import subprocess
import sys
from pathlib import Path

from imageio_ffmpeg import get_ffmpeg_exe

FFMPEG = get_ffmpeg_exe()


def slug(texto):
    s = re.sub(r"[^a-z0-9]+", "-", texto.lower()).strip("-")
    return s[:28].rstrip("-") or "x"


def tienda_de(texto):
    m = re.search(r"^([A-Z0-9.\-]+\.IMPULTIEND?A?)", texto, re.M)
    if m:
        return slug(m.group(1).split(".")[0])
    return "sin-tienda"


def curl(url, destino):
    r = subprocess.run(["curl", "-sL", "--max-time", "120", "-o", str(destino), url])
    return r.returncode == 0 and destino.exists() and destino.stat().st_size > 5000


def main():
    fuente = Path(sys.argv[1])
    carpeta = Path.home() / "fuentes" / "creativos" / sys.argv[2]
    carpeta.mkdir(parents=True, exist_ok=True)
    (carpeta / "frames").mkdir(exist_ok=True)

    datos = json.loads(fuente.read_text())
    (carpeta / "tarjetas.json").write_text(
        json.dumps(datos, ensure_ascii=False, indent=1))

    ok_v = ok_i = fallos = 0
    for t in datos:
        base = f"{t['id'][-6:]}-{tienda_de(t['texto'])}"
        if t.get("video"):
            mp4 = carpeta / f"{base}.mp4"
            if not mp4.exists() and not curl(t["video"], mp4):
                print(f"[error] video {base}")
                fallos += 1
                continue
            fdir = carpeta / "frames" / base
            fdir.mkdir(exist_ok=True)
            if not any(fdir.iterdir()):
                subprocess.run(
                    [FFMPEG, "-loglevel", "error", "-i", str(mp4),
                     "-vf", "fps=1/3", str(fdir / "f-%03d.jpg")])
            ok_v += 1
            if t.get("poster"):
                curl(t["poster"], carpeta / f"{base}-poster.jpg")
        for n, u in enumerate(t.get("imgs", [])[:3]):
            dest = carpeta / f"{base}-img{n}.jpg"
            if dest.exists() or curl(u, dest):
                ok_i += 1

    print(f"[ok] videos:{ok_v} imagenes:{ok_i} fallos:{fallos} → {carpeta}")


if __name__ == "__main__":
    main()
