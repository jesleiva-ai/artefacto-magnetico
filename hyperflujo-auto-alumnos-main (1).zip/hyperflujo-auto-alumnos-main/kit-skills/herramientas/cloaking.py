#!/usr/bin/env python3
"""cloaking.py — ¿la página que TE sirven es la misma que le sirven al comprador?

POR QUE EXISTE
  `rompe_placebos.py` contesta una pregunta: ¿los anuncios activos apuntan a
  ESTA URL? Falta la capa de arriba. Aunque la URL sea la correcta, un operador
  puede devolver contenido DISTINTO según quién pide: qué dispositivo declarás,
  de dónde decís que venís, en qué idioma, o si parecés un revisor de la
  plataforma. Si medís, copiás y modelás la versión "de vidriera", todo el
  desarme queda construido sobre la página equivocada
  ([[pagina-placebo-blindaje-y-espionaje]]).

EL METODO: COMPARAR
  Una sola visita no detecta nada. Se pide la MISMA URL con varias identidades
  ("personas") y la señal es la DIFERENCIA entre ellas.

    comprador-anuncio   celular Android + Referer de Facebook + fbclid  ← REFERENCIA
    comprador-ig        navegador embebido de Instagram + fbclid
    visitante-directo   mismo celular, sin referer ni fbclid (el espía)
    escritorio-directo  Chrome de escritorio, sin referer
    revisor-meta        facebookexternalhit/1.1 (el scraper de Meta)
    buscador            Googlebot/2.1
    idioma-en           celular con Accept-Language en-US (eje de i18n)
    control             idéntica a la referencia, al final de la corrida ← PISO DE RUIDO

  Todas piden la MISMA URL: lo único que cambia es quién dice ser cada una. Si
  dos pidieran URLs distintas, la diferencia sería del pedido y no del trato.

  Más dos renders con JavaScript (Chrome por CDP) para el comprador y para el
  visitante directo: lo que se ve SIN JS vs lo que se ve CON JS.

DIFERENCIA NO ES CLOAKING (esta es la parte difícil)
  Un test A/B, un banner de cookies, un precio en otra moneda o un idioma
  distinto dan diferencias legítimas. Por eso:

  1. El `control` es una repetición EXACTA de la referencia. Lo que se mueva
     entre dos pedidos idénticos es ruido de la página, no cloaking, y fija el
     umbral del resto de la corrida. Si el control ya viene inestable, las
     diferencias blandas dejan de ser atribuibles y el veredicto baja a
     indeterminado en vez de gritar.
  2. Las señales DURAS (destino final distinto, una versión que cobra y otra
     que no, el checkout apuntando a otro lado, otra oferta en el H1) pesan;
     las BLANDAS (texto que se mueve, idioma, moneda) solo avisan.
  3. Si el texto cambia pero el idioma o la moneda también, se clasifica como
     LOCALIZACION y no como cloaking.

LO QUE NO SE PUEDE VER DESDE ACA
  El geo real por IP. Cambiar de país exige salir por una IP de ese país y no
  tenemos exit nodes; `Accept-Language` y el locale del navegador solo tocan la
  rama de idioma, que es la que muchos sitios usan — pero no todos. Un sitio que
  ramifica por IP en el servidor NO se detecta desde esta Mac: eso se reporta
  como límite, nunca como "limpio".

USO
  cloaking.py <url> [--desde <url-real-del-anuncio>] [--sin-js] [--guardar <dir>] [--json]
  cloaking.py --autotest        # prueba el detector contra un cloaker local

EXIT CODES (contrato: otro agente puede llamarlo)
  0  limpio         — todas las identidades reciben la misma oferta
  1  sospechoso     — hay contenido diferencial que cambia la oferta
  2  indeterminado  — no se pudo determinar. NUNCA se reporta como limpio.

Solo lectura: pide páginas, no manda formularios ni toca ninguna plataforma.
"""

import os
import argparse
import http.server
import json
import re
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import urllib.parse
from pathlib import Path

sys.path.insert(0, os.path.expanduser("~/herramientas"))

UA_MOVIL = ("Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
UA_ESCRITORIO = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
                 "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
UA_IG = ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 "
         "(KHTML, like Gecko) Mobile/21E236 Instagram 329.0.0.41.93")
UA_REVISOR = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
UA_BUSCADOR = ("Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)")

FBCLID = "IwZXh0bgNhZW0BMABhZGlkAasdQfakeCLICK0000000000000000"

# ─────────────────────────────────────────────────────────── las identidades ──
# orden importa: la referencia va primera y el control último, para que la
# deriva de la página durante la corrida quede DENTRO del piso de ruido.
PERSONAS = [
    # nombre,             UA,             referer,                       fbclid, idioma,   movil
    ("comprador-anuncio", UA_MOVIL,       "https://l.facebook.com/",     True,  "es-AR,es;q=0.9", True),
    ("comprador-ig",      UA_IG,          "https://l.instagram.com/",    True,  "es-AR,es;q=0.9", True),
    ("visitante-directo", UA_MOVIL,       None,                          False, "es-AR,es;q=0.9", True),
    ("escritorio-directo", UA_ESCRITORIO, None,                          False, "es-AR,es;q=0.9", False),
    ("revisor-meta",      UA_REVISOR,     None,                          False, "en-US,en;q=0.9", False),
    ("buscador",          UA_BUSCADOR,    None,                          False, "en-US,en;q=0.9", False),
    ("idioma-en",         UA_MOVIL,       None,                          False, "en-US,en;q=0.9", True),
    ("control",           UA_MOVIL,       "https://l.facebook.com/",     True,  "es-AR,es;q=0.9", True),
]
REFERENCIA = "comprador-anuncio"
CONTROL = "control"

# ───────────────────────────────────────────────────── marcas de la página ──
CHECKOUT_MARCAS = [
    "checkout", "/cart", "add to cart", "agregar al carrito", "añadir al carrito",
    "comprar ahora", "compra ahora", "buy now", "lo quiero", "quiero mi",
    "hotmart", "kiwify", "kirvano", "mercadopago", "mercado pago", "stripe",
    "paypal", "product-form", 'name="add"', "descargar ahora", "obtener acceso",
    "acceso inmediato", "finalizar compra", "get instant access", "añadir al pedido",
]
PASARELAS = ("hotmart.com", "kiwify.com", "kirvano.com", "pay.", "checkout.",
             "mercadopago", "stripe.com", "paypal.com", "gumroad.com",
             "ticto.com", "monetizze", "payhip.com", "lastlink")

PRECIO_RE = re.compile(
    r"(?:US\$|USD|R\$|AR\$|MXN|CLP|COP|S/|€|£|\$)\s?(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)"
    r"|(\d{1,4}(?:[.,]\d{2})?)\s?(?:USD|EUR|€|£|dólares|dolares|reais|soles)", re.I)

MONEDAS = [("US$", "USD"), ("USD", "USD"), ("R$", "BRL"), ("€", "EUR"), ("£", "GBP"),
           ("AR$", "ARS"), ("ARS", "ARS"), ("MXN", "MXN"), ("CLP", "CLP"),
           ("COP", "COP"), ("S/", "PEN"), ("EUR", "EUR"), ("BRL", "BRL")]

# huellas de código que RAMIFICA por quién pide (evidencia de intención, no
# veredicto: `document.referrer` lo usa media internet para analítica).
HUELLA_COND = re.compile(
    r"(document\.referrer|navigator\.userAgent|navigator\.platform|fbclid|utm_source"
    r"|navigator\.webdriver|navigator\.languages)", re.I)
HUELLA_SALTO = re.compile(
    r"(location\.href\s*=|location\.replace|location\.assign|window\.location\s*="
    r"|\.submit\(\)|meta\s+http-equiv=[\"']?refresh)", re.I)

# ── la firma de un CLOAKER de verdad ─────────────────────────────────────────
# No es "código condicional": es la maquinaria completa. Un cloaker esconde el
# body mientras decide, te toma las huellas digitales (UA, referrer, huso,
# pantalla, idiomas, fbclid, GPU), chequea si sos un navegador automatizado,
# manda todo a su servidor y aplica la sentencia que ese servidor devuelve.
# Analytics hace lo primero y lo segundo; nunca lo último.
SIGNOS_CLOAKER = {
    "chequea si sos un navegador automatizado":
        re.compile(r"navigator\.webdriver|HeadlessChrome|PhantomJS|Selenium|Puppeteer",
                   re.I),
    "esconde la página mientras decide":
        re.compile(r"visibility\s*:\s*hidden\s*!?\s*important|"
                   r"body\s*\{\s*visibility\s*:\s*hidden", re.I),
    "te toma las huellas digitales":
        re.compile(r"resolvedOptions\(\)\.timeZone|WEBGL_debug_renderer_info|"
                   r"UNMASKED_VENDOR_WEBGL|navigator\.languages|devicePixelRatio", re.I),
    "manda el perfil a un servidor":
        re.compile(r"keepalive\s*:\s*true|sendBeacon|credentials\s*:\s*['\"]omit", re.I),
    "el servidor decide y te muda":
        re.compile(r"\.then\s*\([^)]{0,400}location\.(replace|href|assign)|"
                   r"location\.replace\s*\(\s*(to|d\.to|data\.to|[a-z]{1,3}\.to)\b", re.I | re.S),
    "guarda la sentencia para no re-preguntar":
        re.compile(r"sessionStorage\.setItem[^;]{0,200}(ttl|expir|x\s*:\s*Date\.now)", re.I),
    "modo verificación para el revisor":
        re.compile(r"_vchk|gh_verify|verify-ping", re.I),
}
OBLIGATORIO = "el servidor decide y te muda"


def detectar_cloaker(html, base, max_scripts=8):
    """Busca la firma del cloaker en el HTML y en los scripts de primera parte.

    Los cloakers viven en un script propio servido desde un subdominio del
    mismo sitio (track.midominio.com) justo para no verse como tercero. Por eso
    hay que ABRIR los scripts, no solo mirar el HTML."""
    host = norm_url(base)[0]
    raiz = ".".join(host.split(".")[-2:])
    piezas = [("html", html)]
    srcs = []
    for m in re.finditer(r"<script[^>]+src=[\"']([^\"']+)[\"']", html, re.I):
        u = urllib.parse.urljoin(base, m.group(1))
        h = norm_url(u)[0]
        if h.endswith(raiz) and "shopifycloud" not in u and "cdn.shopify" not in u:
            srcs.append(u)
    for u in list(dict.fromkeys(srcs))[:max_scripts]:
        r = subprocess.run(["curl", "-sL", "--max-time", "15", "--max-filesize", "400000",
                            "-A", UA_MOVIL, u], capture_output=True, text=True,
                           errors="replace")
        if r.stdout:
            piezas.append((u, r.stdout))

    marcas, donde = [], {}
    for pieza, cuerpo in piezas:
        for nombre, rx in SIGNOS_CLOAKER.items():
            if rx.search(cuerpo):
                if nombre not in marcas:
                    marcas.append(nombre)
                    donde[nombre] = pieza
    token = None
    m = re.search(r"<script[^>]+src=[\"']([^\"']*(?:track|sdk|tag)[^\"']*)[\"']"
                  r"[^>]*data-(?:ref|token|key)=[\"']([^\"']+)", html, re.I)
    if m:
        token = {"script": m.group(1), "param": m.group(2)}
    fuentes = sorted({donde[x] for x in marcas if donde[x] != "html"})
    return {
        "detectado": OBLIGATORIO in marcas and len(marcas) >= 4,
        "sospecha": OBLIGATORIO in marcas and len(marcas) == 3,
        "marcas": marcas,
        "scripts": fuentes,
        "token": token,
    }


# ────────────────────────────────────────────────────────────── utilidades ──
def norm_url(u):
    """(host, path) sin www, sin query, sin barra final."""
    p = urllib.parse.urlsplit(u if "://" in u else "https://" + u)
    host = p.netloc.lower().removeprefix("www.")
    path = urllib.parse.unquote(p.path or "/").rstrip("/") or "/"
    return host, path.lower()


def texto_visible(html):
    t = re.sub(r"<(script|style|noscript|template)[^>]*>.*?</\1>", " ", html,
               flags=re.S | re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", '"')
    t = re.sub(r"&#?\w{2,8};", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def normalizar(t):
    """Texto comparable: sin acentos, sin dígitos, sin puntuación.

    Los dígitos se van a propósito: relojes, contadores de stock, precios y
    fechas cambian entre dos pedidos idénticos y son la fuente número uno de
    falsos positivos."""
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()
    t = re.sub(r"[^a-z\s]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def shingles(t, n=5):
    w = normalizar(t).split()
    if len(w) < n * 3:                      # texto corto: comparar por palabras
        return set(w)
    return {" ".join(w[i:i + n]) for i in range(len(w) - n + 1)}


def jaccard(a, b):
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def detectar_idioma(texto):
    t = " " + texto.lower()[:20000] + " "
    p = {
        "es": sum(t.count(f" {w} ") for w in
                  ["que", "para", "con", "los", "las", "una", "este", "esta", "mas",
                   "tu", "ya", "como", "ahora", "por", "del"])
              + t.count("ñ") * 3 + t.count("¿") * 5,
        "en": sum(t.count(f" {w} ") for w in
                  ["the", "and", "your", "with", "you", "for", "this", "get",
                   "now", "our", "from", "how", "of"]),
        "pt": sum(t.count(f" {w} ") for w in
                  ["voce", "não", "nao", "uma", "mais", "seu", "sua", "com",
                   "para", "ja"]) + t.count("ç") * 3 + t.count("ã") * 4,
        "it": sum(t.count(f" {w} ") for w in
                  ["che", "per", "con", "della", "sono", "tuo", "gli", "gli"]),
    }
    idioma, punt = max(p.items(), key=lambda kv: kv[1])
    return idioma if punt >= 5 else "??"


def detectar_monedas(texto):
    v = {cod for marca, cod in MONEDAS if marca in texto}
    if not v and re.search(r"\$\s?\d", texto):
        v.add("$?")
    return sorted(v)


def numeros_de(texto):
    """El esqueleto numérico de la página.

    Sirve para separar una TRADUCCION de OTRA PAGINA sin depender del detector
    de idioma: la misma oferta traducida conserva sus números (3.000 diseños,
    7 días de garantía, 12 categorías); una página distinta trae otros."""
    return {n.lstrip("0") or "0"
            for n in re.findall(r"\d{1,7}", texto.replace(".", "").replace(",", ""))}


def precios_de(texto):
    """Magnitudes numéricas de precio, normalizadas a float."""
    out = []
    for m in PRECIO_RE.finditer(texto):
        crudo = m.group(1) or m.group(2) or ""
        s = crudo.replace(" ", "")
        if s.count(",") and s.count("."):
            s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") \
                else s.replace(",", "")
        elif s.count(","):
            s = s.replace(",", ".") if len(s.split(",")[-1]) == 2 else s.replace(",", "")
        elif s.count(".") and len(s.split(".")[-1]) == 3:
            s = s.replace(".", "")
        try:
            v = float(s)
        except ValueError:
            continue
        if 0.5 <= v <= 1_000_000:
            out.append(round(v, 2))
    return sorted(set(out))


def destinos_de_pago(html, base):
    """A dónde va el dinero: forms de compra y links a pasarelas."""
    d = set()
    for m in re.finditer(r"<form[^>]+action=[\"']([^\"']+)", html, re.I):
        a = m.group(1)
        if any(k in a.lower() for k in ("cart", "checkout", "pay", "order", "buy")):
            d.add(norm_url(urllib.parse.urljoin(base, a)))
    for m in re.finditer(r"href=[\"'](https?://[^\"']+)", html, re.I):
        u = m.group(1)
        if any(p in u.lower() for p in PASARELAS):
            d.add(norm_url(u))
    return sorted(f"{h}{p}" for h, p in d)


def huellas_cloaking(html):
    """Condicional por identidad del visitante CERCA de un salto de página."""
    hallazgos = []
    for m in HUELLA_COND.finditer(html):
        ventana = html[m.start(): m.start() + 400]
        s = HUELLA_SALTO.search(ventana)
        if s:
            frag = re.sub(r"\s+", " ", ventana[:160])
            hallazgos.append(f"{m.group(1)} → {s.group(1)} :: {frag}")
        if len(hallazgos) >= 4:
            break
    return hallazgos


def titulo_de(html):
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I)
    return re.sub(r"\s+", " ", texto_visible(m.group(1))).strip()[:160] if m else ""


def encabezados_de(html):
    hs = re.findall(r"<h[12][^>]*>(.*?)</h[12]>", html, re.S | re.I)
    return [re.sub(r"\s+", " ", texto_visible(h)).strip()[:180] for h in hs if h.strip()][:6]


# ───────────────────────────────────────────────────────── el pedido crudo ──
def pedir(url, ua, referer, fbclid, idioma, timeout=40):
    """Un pedido con identidad declarada. Devuelve la ficha o None."""
    u = url
    if fbclid:
        sep = "&" if urllib.parse.urlsplit(u).query else "?"
        u = f"{u}{sep}fbclid={FBCLID}"
    cab = ["-H", f"Accept-Language: {idioma}",
           "-H", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"]
    if referer:
        cab += ["-H", f"Referer: {referer}"]
    with tempfile.NamedTemporaryFile("w+", suffix=".hdr", delete=True) as hf:
        r = subprocess.run(
            ["curl", "-sL", "--max-time", str(timeout), "--compressed",
             "-A", ua, *cab, "-D", hf.name,
             "-w", "\n===META=== %{url_effective} %{http_code}", u],
            capture_output=True, text=True, errors="replace")
        try:
            cabeceras = Path(hf.name).read_text(errors="replace")
        except OSError:
            cabeceras = ""
    out = r.stdout or ""
    if "===META===" not in out:
        return None
    html, _, cola = out.rpartition("===META===")
    partes = cola.split()
    url_final = partes[0] if partes else u
    estado = int(partes[1]) if len(partes) > 1 and partes[1].isdigit() else 0
    saltos = re.findall(r"^[Ll]ocation:\s*(\S+)", cabeceras, re.M)
    return ficha(html, url_final, estado, saltos, url_pedida=u, motor="html")


def ficha(html, url_final, estado, saltos, url_pedida, motor, texto=None):
    # `html` puede venir del servidor (curl) o del DOM ya renderizado (CDP). Las
    # dos capas se miden con los MISMOS extractores a propósito: si una buscara
    # el checkout en el HTML crudo y la otra solo en el texto visible, cualquier
    # página con el botón dibujado por JS saldría "dejó de cobrar" — un falso
    # positivo del método, no de la página.
    texto = texto if texto is not None else texto_visible(html)
    h, p = norm_url(url_final)
    return {
        "motor": motor,
        "url_pedida": url_pedida,
        "url_final": url_final,
        "destino": f"{h}{p}",
        "estado": estado,
        "saltos": saltos,
        "titulo": titulo_de(html),
        "encabezados": encabezados_de(html),
        "palabras": len(texto.split()),
        "idioma": detectar_idioma(texto),
        "monedas": detectar_monedas(texto + " " + html[:200000]),
        "precios": precios_de(texto),
        "checkout": sorted({m for m in CHECKOUT_MARCAS if m in (html + " " + texto).lower()})[:8],
        "pago": destinos_de_pago(html, url_final),
        "huellas": huellas_cloaking(html),
        "_texto": texto,
        "_html": html,
    }


def cobra(f):
    return bool(f["checkout"]) and bool(f["precios"])


def identidad_oferta(f):
    """Con qué se identifica la OFERTA (no la página entera)."""
    return shingles(" ".join([f["titulo"]] + f["encabezados"][:4]), n=2)


# ───────────────────────────────────────────────────── la capa con JavaScript ──
JS_LECTURA = r"""
(() => JSON.stringify({
  url: location.href,
  txt: (document.body ? document.body.innerText : '').slice(0, 400000),
  html: (document.documentElement ? document.documentElement.outerHTML : '').slice(0, 900000)
}))()
"""


def render_js(url, ua, referer, fbclid, idioma, movil, espera=11):
    """Render real en el Chrome de trabajo, con la identidad declarada."""
    try:
        import ojos
    except Exception:
        return None
    if not ojos.vivo():
        return None
    u = url
    if fbclid:
        sep = "&" if urllib.parse.urlsplit(u).query else "?"
        u = f"{u}{sep}fbclid={FBCLID}"
    cdp = ojos.CDP(ojos.http_json("/json/version")["webSocketDebuggerUrl"])
    tid = None
    try:
        tid = cdp.cmd("Target.createTarget", {"url": "about:blank"})["targetId"]
        ses = cdp.cmd("Target.attachToTarget",
                      {"targetId": tid, "flatten": True})["sessionId"]
        cdp.cmd("Page.enable", sesion=ses)
        cdp.cmd("Network.enable", sesion=ses)
        cdp.cmd("Emulation.setUserAgentOverride",
                {"userAgent": ua, "acceptLanguage": idioma.split(",")[0]}, sesion=ses)
        cdp.cmd("Emulation.setDeviceMetricsOverride",
                {"width": 390 if movil else 1280, "height": 844 if movil else 900,
                 "deviceScaleFactor": 1, "mobile": movil}, sesion=ses)
        if referer:
            cdp.cmd("Network.setExtraHTTPHeaders",
                    {"headers": {"Referer": referer}}, sesion=ses)
        cdp.cmd("Page.navigate", {"url": u}, sesion=ses, espera=45)
        time.sleep(espera)
        r = cdp.cmd("Runtime.evaluate",
                    {"expression": JS_LECTURA, "returnByValue": True},
                    sesion=ses, espera=45)
        d = json.loads(r.get("result", {}).get("value") or "{}")
        if not d or not d.get("html"):
            return None
        # el DOM renderizado entra por el MISMO extractor que el HTML del
        # servidor: es la única forma de que las dos capas sean comparables
        return ficha(d["html"], d.get("url", u), 200, [], url_pedida=u,
                     motor="js", texto=d.get("txt", ""))
    except Exception:
        return None
    finally:
        if tid:
            try:
                cdp.cmd("Target.closeTarget", {"targetId": tid})
            except Exception:
                pass
        cdp.cerrar()


# ──────────────────────────────────────────────────────────── comparación ──
DURA, BLANDA = "dura", "blanda"


def comparar(ref, otra, umbral, inestable):
    """Qué separa a `otra` de la referencia. (nivel, etiqueta, detalle) o None."""
    if ref["destino"] != otra["destino"]:
        return (DURA, "destino distinto",
                f"termina en {otra['destino']} y no en {ref['destino']}")
    if cobra(ref) != cobra(otra):
        quien = "la referencia" if cobra(ref) else "esta identidad"
        return (DURA, "solo una versión cobra",
                f"{quien} tiene checkout+precio y la otra no "
                f"(checkout {otra['checkout'][:2] or 'NO'} · precio {otra['precios'][:2] or 'NO'})")
    if ref["pago"] and otra["pago"] and not set(ref["pago"]) & set(otra["pago"]):
        return (DURA, "el dinero va a otro lado",
                f"{otra['pago'][:2]} vs {ref['pago'][:2]}")

    # "otra oferta" solo si el titular Y los encabezados cambian EN EL MISMO
    # IDIOMA. Una página traducida cambia las dos cosas sin cambiar la oferta:
    # exigir mismo idioma es lo que evita gritar lobo en cada sitio bilingüe.
    otro_idioma = (otra["idioma"] != ref["idioma"]
                   and "??" not in (otra["idioma"], ref["idioma"]))
    sim_titulo = jaccard(shingles(ref["titulo"], 2), shingles(otra["titulo"], 2))
    sim_oferta = jaccard(identidad_oferta(ref), identidad_oferta(otra))
    if sim_oferta < 0.34 and sim_titulo < 0.5 and (ref["titulo"] or ref["encabezados"]):
        if not otro_idioma:
            return (DURA, "otra oferta",
                    f"titular «{(otra['titulo'] or (otra['encabezados'] or [''])[0])[:70]}» "
                    f"vs «{(ref['titulo'] or (ref['encabezados'] or [''])[0])[:70]}»")

    sim = jaccard(shingles(ref["_texto"]), shingles(otra["_texto"]))
    if sim >= umbral:
        return None
    if otro_idioma:
        return (BLANDA, "localización (idioma)",
                f"idioma {otra['idioma']} vs {ref['idioma']} · parecido {sim:.0%}")
    if otra["monedas"] and ref["monedas"] and not set(otra["monedas"]) & set(ref["monedas"]):
        return (BLANDA, "localización (moneda)",
                f"moneda {otra['monedas']} vs {ref['monedas']} · parecido {sim:.0%}")
    # el texto cambió pero el esqueleto numérico y el checkout son los mismos:
    # es la misma oferta con otra piel (traducción, skin regional), no otra oferta
    na, nb = numeros_de(ref["_texto"]), numeros_de(otra["_texto"])
    if len(na) >= 6 and len(nb) >= 6 and jaccard(na, nb) >= 0.70 \
            and (set(ref["pago"]) & set(otra["pago"]) or not ref["pago"]):
        return (BLANDA, "misma oferta, otra piel",
                f"el texto cambia ({sim:.0%}) pero los números de la oferta son los "
                f"mismos ({jaccard(na, nb):.0%}) y el checkout no se movió — "
                "traducción o variante regional")
    if inestable:
        return (BLANDA, "no atribuible",
                f"parecido {sim:.0%}, pero la página ya se movía sola entre pedidos idénticos")
    return (BLANDA, "mismo producto, otro contenido",
            f"parecido {sim:.0%} con la misma oferta — huele a test A/B o a bloque rotativo")


def agrupar(fichas, umbral):
    """Agrupa identidades que recibieron la misma versión."""
    grupos = []
    for nombre, f in fichas:
        for g in grupos:
            if g["destino"] == f["destino"] and \
                    jaccard(g["_sh"], shingles(f["_texto"])) >= umbral:
                g["personas"].append(nombre)
                break
        else:
            grupos.append({"personas": [nombre], "destino": f["destino"],
                           "titulo": f["titulo"] or (f["encabezados"] or [""])[0],
                           "palabras": f["palabras"], "precios": f["precios"][:5],
                           "cobra": cobra(f), "idioma": f["idioma"],
                           "_sh": shingles(f["_texto"])})
    for g in grupos:
        g.pop("_sh", None)
    return grupos


# ────────────────────────────────────────────────────────────────── informe ──
def analizar(url, desde=None, con_js=True, guardar=None):
    R = {"url": url, "url_anuncio": desde, "veredicto": None, "motivo": None,
         "piso_de_ruido": None, "umbral": None, "identidades": {}, "versiones": [],
         "diferencias": [], "avisos": [], "limites": [], "cloaker": None,
         "version_que_cobra": None, "receta": None}

    # TODAS las identidades piden la MISMA URL. Lo único que varía es quién dice
    # ser cada una. Si dos identidades pidieran URLs distintas, cualquier
    # diferencia sería del pedido y no del trato: no habría experimento.
    url_ref = desde or url
    if desde and norm_url(desde) != norm_url(url):
        R["avisos"].append(
            f"se chequea la URL del anuncio ({norm_url(desde)[0]}{norm_url(desde)[1]}), "
            f"no la que pasaste ({norm_url(url)[0]}{norm_url(url)[1]}): son rutas "
            "distintas y la que compran los anuncios es la que importa. Que sean "
            "distintas es asunto de rompe_placebos.py, no de acá")
    fichas = {}
    for nombre, ua, ref, fb, idi, movil in PERSONAS:
        f = pedir(url_ref, ua, ref, fb, idi)
        # Una ficha vacía NO es una ficha: si el dominio no resuelve o devuelve
        # un error, las ocho identidades "coinciden" en la nada y el veredicto
        # saldría limpio. Ocho silencios idénticos no son ocho respuestas
        # iguales ([[2026-07-27-cerebro-ia-el-proxy-miente]]).
        malo = None
        if f is None:
            malo = "sin conexión"
        elif not (200 <= f["estado"] < 400):
            malo = f"HTTP {f['estado'] or 'sin respuesta'}"
        elif f["palabras"] < 30 and len(f["_html"]) < 2000:
            malo = (f"respuesta vacía ({f['palabras']} palabras, "
                    f"{len(f['_html'])} bytes)")
        if malo:
            R["avisos"].append(f"{nombre}: no cuenta — {malo}")
            continue
        fichas[nombre] = f
        R["identidades"][nombre] = {
            k: f[k] for k in ("destino", "estado", "saltos", "titulo", "palabras",
                              "idioma", "monedas", "precios", "checkout", "pago")}
        R["identidades"][nombre]["cobra"] = cobra(f)

    if REFERENCIA not in fichas or len(fichas) < 3:
        R["veredicto"], cod = "indeterminado", 2
        R["motivo"] = (f"solo {len(fichas)} de {len(PERSONAS)} identidades recibieron "
                       "una página con contenido: sin comparación no hay detección. "
                       "Si ninguna respondió, la URL está caída o no resuelve — que "
                       "no es lo mismo que estar limpia")
        R["version_que_cobra"] = None
        return R, cod

    ref = fichas[REFERENCIA]

    # 1 · el piso de ruido: dos pedidos IDENTICOS
    if CONTROL in fichas:
        piso = jaccard(shingles(ref["_texto"]), shingles(fichas[CONTROL]["_texto"]))
    else:
        piso = None
        R["avisos"].append("el control no respondió: sin piso de ruido medido, "
                           "se usa el umbral por defecto")
    R["piso_de_ruido"] = None if piso is None else round(piso, 3)
    inestable = piso is not None and piso < 0.90       # rota bloques
    caotica = piso is not None and piso < 0.65         # ni consigo misma coincide
    umbral = 0.92 if piso is None else max(0.55, min(0.92, piso - 0.03))
    R["umbral"] = round(umbral, 3)
    if inestable:
        R["avisos"].append(
            f"la página se mueve sola: dos pedidos IDENTICOS dieron {piso:.0%} de "
            "parecido. Las diferencias blandas dejan de ser atribuibles")

    # 2 · cada identidad contra la referencia
    for nombre, f in fichas.items():
        if nombre in (REFERENCIA, CONTROL):
            continue
        d = comparar(ref, f, umbral, inestable)
        if d:
            R["diferencias"].append({"identidad": nombre, "nivel": d[0],
                                     "que": d[1], "detalle": d[2]})

    # 3 · la capa con JavaScript (lo que se ve sin JS vs con JS)
    js = {}
    if con_js:
        for nombre in (REFERENCIA, "visitante-directo"):
            if nombre not in fichas:
                continue
            _, ua, rf, fb, idi, movil = next(p for p in PERSONAS if p[0] == nombre)
            r = render_js(url_ref, ua, rf, fb, idi, movil)
            if r:
                js[nombre] = r
                R["identidades"][nombre + "+js"] = {
                    k: r[k] for k in ("destino", "titulo", "palabras", "idioma",
                                      "precios", "checkout", "pago")}
                R["identidades"][nombre + "+js"]["cobra"] = cobra(r)
        if not js:
            R["limites"].append("no hubo render con JavaScript (Chrome de trabajo "
                                "apagado o CDP ocupado): la capa JS quedó sin mirar")
    else:
        R["limites"].append("render con JavaScript desactivado por --sin-js")

    for nombre, r in js.items():
        base = fichas[nombre]
        if r["destino"] != base["destino"]:
            R["diferencias"].append({
                "identidad": nombre + " (JS)", "nivel": DURA,
                "que": "el JavaScript te muda de página",
                "detalle": f"sin JS quedás en {base['destino']}; con JS terminás "
                           f"en {r['destino']}"})
        elif cobra(r) and not cobra(base):
            R["avisos"].append(f"{nombre}: la página solo cobra cuando corre el "
                               "JavaScript (checkout inyectado) — normal en SPA, "
                               "pero el HTML crudo no alcanza para medirla")
        elif cobra(base) and not cobra(r):
            R["diferencias"].append({
                "identidad": nombre + " (JS)", "nivel": DURA,
                "que": "con JavaScript deja de cobrar",
                "detalle": "el checkout está en el HTML pero desaparece al renderizar"})
        else:
            so = jaccard(identidad_oferta(base), identidad_oferta(r))
            st = jaccard(shingles(base["titulo"], 2), shingles(r["titulo"], 2))
            if so < 0.34 and st < 0.5 and (base["titulo"] or base["encabezados"]):
                R["diferencias"].append({
                    "identidad": nombre + " (JS)", "nivel": DURA,
                    "que": "el JavaScript reescribe la oferta",
                    "detalle": f"con JS: «{(r['titulo'] or (r['encabezados'] or [''])[0])[:70]}»"})

    if REFERENCIA in js and "visitante-directo" in js:
        a, b = js[REFERENCIA], js["visitante-directo"]
        if a["destino"] != b["destino"]:
            R["diferencias"].append({
                "identidad": "visitante-directo (JS)", "nivel": DURA,
                "que": "el JS separa al que viene del anuncio",
                "detalle": f"con anuncio termina en {a['destino']}; directo en {b['destino']}"})

    # 4 · la firma del cloaker en el código (evidencia, no inferencia)
    C = detectar_cloaker(ref["_html"], ref["url_final"])
    R["cloaker"] = C
    if C["detectado"]:
        R["diferencias"].append({
            "identidad": "el código de la página", "nivel": DURA,
            "que": "cloaker declarado",
            "detalle": "la página trae la maquinaria completa para servir contenido "
                       "según quién pide: " + " · ".join(C["marcas"])
                       + (f" · en {', '.join(C['scripts'][:2])}" if C["scripts"] else "")})
    elif C["sospecha"]:
        R["avisos"].append("hay parte de la firma de un cloaker (" +
                           ", ".join(C["marcas"]) + ") pero no la completa: puede ser "
                           "un anti-bot o un A/B server-side")
    if C["token"]:
        R["avisos"].append(
            f"el script {C['token']['script']} espera un token propio "
            f"(?ref={C['token']['param']}): es la marca de «vengo del anuncio». "
            "Probá la URL con ese parámetro")
    if not C["detectado"]:
        for nombre, f in fichas.items():
            for h in f["huellas"][:2]:
                aviso = f"código condicional en {nombre}: {h[:150]}"
                if aviso not in R["avisos"]:
                    R["avisos"].append(aviso)

    # 5 · versiones servidas
    R["versiones"] = agrupar(list(fichas.items()), umbral)

    # 6 · límites honestos
    R["limites"].append("geo por IP: no se probó — cambiar de país exige salir por "
                        "una IP de ese país. Un sitio que ramifica por IP en el "
                        "servidor no se ve desde acá")

    # 7 · veredicto
    duras = [d for d in R["diferencias"] if d["nivel"] == DURA]
    blandas = [d for d in R["diferencias"] if d["nivel"] == BLANDA]
    sin_atribuir = [d for d in blandas if d["que"] == "no atribuible"]
    reales = [d for d in blandas if d["que"] == "mismo producto, otro contenido"]

    if duras:
        R["veredicto"], cod = "sospechoso", 1
        R["motivo"] = (f"{len(duras)} diferencia(s) dura(s): "
                       + " · ".join(f"{d['identidad']} → {d['que']}" for d in duras[:3]))
    elif reales:
        R["veredicto"], cod = "sospechoso", 1
        R["motivo"] = ("mismo producto pero contenido distinto según quién pide, por "
                       "encima del ruido medido de la propia página: "
                       + " · ".join(f"{d['identidad']} ({d['detalle']})" for d in reales[:3]))
    elif caotica or sin_atribuir:
        R["veredicto"], cod = "indeterminado", 2
        R["motivo"] = ("la página cambia entre dos pedidos IDENTICOS "
                       f"({piso:.0%} de parecido consigo misma): con ese ruido no se "
                       "puede separar un test A/B de un cloaker. Ninguna señal DURA "
                       "salió positiva, pero eso no alcanza para firmar limpio")
    elif len(fichas) < 5:
        R["veredicto"], cod = "indeterminado", 2
        R["motivo"] = (f"solo respondieron {len(fichas)} identidades de {len(PERSONAS)}: "
                       "la comparación es demasiado flaca para firmar limpio")
    else:
        R["veredicto"], cod = "limpio", 0
        legit = " · ".join(f"{d['identidad']}: {d['que']}" for d in blandas[:3])
        R["motivo"] = (f"{len(fichas)} identidades recibieron la misma oferta"
                       + (f". Variación legítima: {legit}" if legit else ""))

    # 8 · cuál versión recibe el dinero (lo que después se desarma)
    R["version_que_cobra"] = version_del_dinero(R, fichas, js)
    _, ua_r, rf_r, fb_r, idi_r, _ = PERSONAS[0]
    u_r = url_ref + ((("&" if urllib.parse.urlsplit(url_ref).query else "?")
                      + "fbclid=" + FBCLID) if fb_r else "")
    R["receta"] = (f"curl -sL --compressed -A '{ua_r}' -H 'Referer: {rf_r}' "
                   f"-H 'Accept-Language: {idi_r}' '{u_r}'")

    if guardar:
        volcar(guardar, fichas, js)
        R["volcado"] = str(guardar)
    return R, cod


def version_del_dinero(R, fichas, js):
    """Cuál de las versiones es la que recibe el dinero, y por qué.

    El caso difícil es el salto por JavaScript. Hay dos arquitecturas opuestas:
      · funnel legítimo → el salto LLEVA al comprador al paso que cobra, así que
        la que cobra es el destino;
      · cloaker → el salto SACA al que no calificó y lo deposita en un señuelo,
        así que la que cobra es la que estaba antes del salto, en la URL que
        compran los anuncios.
    Distinguirlas a ojo es adivinar. Se distinguen por la firma del cloaker: si
    la maquinaria está en el código, el salto es una sentencia, no un paso."""
    ref = fichas[REFERENCIA]
    ref_js = js.get(REFERENCIA)
    hubo_salto = bool(ref_js and ref_js["destino"] != ref["destino"])
    con_cloaker = bool(R.get("cloaker", {}).get("detectado"))
    grupo = next((g for g in R["versiones"] if REFERENCIA in g["personas"]), None)

    if hubo_salto and con_cloaker:
        # nos clasificaron y nos sacaron: lo que vemos renderizado es el señuelo
        return {
            "cual": "la que sirve el servidor en la URL que compran los anuncios, "
                    "ANTES de que el cloaker decida sacarte",
            "url": ref["url_final"],
            "cobra": cobra(ref),
            "precios": ref["precios"][:6],
            "checkout": ref["checkout"][:4],
            "titulo": ref["titulo"] or (ref["encabezados"] or [""])[0],
            "identidades_que_la_ven": grupo["personas"] if grupo else [REFERENCIA],
            "confianza": "media",
            "senuelo": ref_js["url_final"],
            "nota": (f"OJO: el cloaker nos clasificó y nos mandó a {ref_js['destino']} "
                     f"(«{(ref_js['titulo'] or '')[:50]}») — ESE es el señuelo, no la "
                     "oferta. La versión de arriba es la que sirve el servidor en la "
                     "URL del anuncio y la que hay que medir. NO la vimos renderizada: "
                     "cualquier navegador nuestro se la come el cloaker, así que medila "
                     "con la receta de abajo (sin JavaScript) y tratala como "
                     "«sin confirmar» hasta cruzarla con el creativo del anuncio"),
        }

    paga = ref_js if (ref_js and cobra(ref_js)) else ref
    v = {
        "cual": "la que ve quien llega desde el anuncio (celular + referer de "
                "Facebook + fbclid)",
        "url": paga["url_final"],
        "cobra": cobra(paga),
        "precios": paga["precios"][:6],
        "checkout": paga["checkout"][:4],
        "titulo": paga["titulo"] or (paga["encabezados"] or [""])[0],
        "identidades_que_la_ven": grupo["personas"] if grupo else [REFERENCIA],
        "confianza": "alta",
    }
    if hubo_salto:
        v["confianza"] = "media"
        v["nota"] = (f"el JavaScript te mueve de {ref['destino']} a {paga['destino']}; "
                     "sin firma de cloaker se lee como paso de funnel, pero confirmalo "
                     "contra el creativo del anuncio")
    if not cobra(paga):
        otra = [(n, f) for n, f in fichas.items() if cobra(f) and n != REFERENCIA]
        v["confianza"] = "baja"
        v["nota"] = ("OJO: la versión que recibe el que viene del anuncio NO cobra"
                     + (f"; sí cobra la que ven {[n for n, _ in otra][:3]}. Puede ser "
                        "un puente (advertorial/quiz) o que el checkout lo inyecte "
                        "un JS que no corrió" if otra else
                        ". Ninguna versión mostró checkout+precio: o es puente, o no "
                        "llegamos a la página real"))
    elif R["veredicto"] == "sospechoso":
        v["nota"] = ("hay contenido diferencial: TODO lo que se mida sin esta receta "
                     "puede ser la versión de vidriera")
    elif R["veredicto"] == "indeterminado":
        v["confianza"] = "media"
        v["nota"] = "no se pudo cerrar el chequeo: tratala como sin confirmar"
    return v


def volcar(destino, fichas, js):
    d = Path(destino)
    d.mkdir(parents=True, exist_ok=True)
    for nombre, f in fichas.items():
        (d / f"{nombre}.html").write_text(f["_html"], encoding="utf-8")
        (d / f"{nombre}.txt").write_text(f["_texto"], encoding="utf-8")
    for nombre, f in js.items():
        (d / f"{nombre}+js.txt").write_text(f["_texto"], encoding="utf-8")


def imprimir(R, cod):
    print(f"\n  {R['url']}")
    if R["url_anuncio"]:
        print(f"  URL del anuncio: {R['url_anuncio']}")
    piso = R["piso_de_ruido"]
    if R["umbral"] is not None:
        print(f"  piso de ruido (2 pedidos idénticos): "
              f"{f'{piso:.0%}' if piso is not None else '?'} de parecido · "
              f"umbral usado: {R['umbral']:.0%}")
    print()
    for nombre, i in R["identidades"].items():
        print(f"  {nombre:22} {i['destino'][:52]:52} "
              f"{i.get('palabras', 0):>6} pal · {i.get('idioma', '?')} · "
              f"{'cobra' if i.get('cobra') else 'NO cobra':9} · "
              f"{', '.join(str(p) for p in i.get('precios', [])[:3]) or '-'}")
    if len(R["versiones"]) > 1:
        print(f"\n  {len(R['versiones'])} VERSIONES distintas servidas:")
        for n, g in enumerate(R["versiones"], 1):
            print(f"    v{n}: {', '.join(g['personas'])}")
            print(f"        «{g['titulo'][:70]}» · {g['palabras']} pal · "
                  f"{'cobra' if g['cobra'] else 'NO cobra'} · {g['precios'][:3]}")
    if R["diferencias"]:
        print()
        for d in R["diferencias"]:
            marca = "[DURA] " if d["nivel"] == DURA else "[blanda]"
            print(f"  {marca} {d['identidad']}: {d['que']} — {d['detalle']}")
    for a in R["avisos"]:
        print(f"  [aviso] {a}")
    for l in R["limites"]:
        print(f"  [límite] {l}")

    marca = {"limpio": "[limpio]", "sospechoso": "[sospechoso]",
             "indeterminado": "[indeterminado]"}[R["veredicto"]]
    print(f"\n  {marca} {R['motivo']}")

    v = R.get("version_que_cobra")
    if v:
        print(f"\n  LA QUE RECIBE EL DINERO ({v['confianza']} confianza): {v['cual']}")
        print(f"    → {v['url']}")
        print(f"    «{(v['titulo'] or '')[:76]}»")
        print(f"    cobra: {'sí' if v['cobra'] else 'NO'} · precios {v['precios'][:4]} "
              f"· checkout {v['checkout'][:3] or '-'}")
        print(f"    la ven: {', '.join(v['identidades_que_la_ven'])}")
        if v.get("nota"):
            print(f"    {v['nota']}")
        print(f"\n  Medí SIEMPRE con esta receta:\n    {R['receta']}")
    if cod == 2:
        print("\n  Indeterminado NO es limpio: el desarme queda marcado "
              "'sin confirmar' hasta resolverlo.")
    print()


# ───────────────────────────────────────────────────────────────── autotest ──
# Bancos de prueba. El vocabulario tiene que ser VARIADO: si el relleno es una
# frase repetida, el set de shingles colapsa y la medición deja de parecerse a
# una página real.
_ES = ("planilla finanzas presupuesto ahorro imprimible editable excel gasto "
       "deuda ingreso cuenta tarjeta meta mes cuota interes banco "
       "sueldo factura alquiler hogar familia recibo registro control resumen "
       "fondo plan color papel diseno formato archivo carpeta acceso "
       "que para con los las una este esta mas tu ya como ahora por del").split()
_EN = ("spreadsheet finance budget saving printable editable excel expense debt "
       "income account card goal month installment interest bank salary bill "
       "rent home family receipt record tracker summary fund plan color paper "
       "design format file folder access "
       "the and your with you for this get now our from how of").split()
# los números de la oferta: iguales en las dos versiones, como en una traducción
# (oferta inventada, por ejemplo: pack de planillas de finanzas personales)
_CIFRAS = "150 12 7 3 40 48 500 10 5 30 24 15".split()


def _lorem(banco, semilla, n=260):
    """Texto pseudoaleatorio determinista: varía de verdad, sin depender de random."""
    x = semilla * 2654435761 % 2 ** 32 or 7
    out = []
    for i in range(n):
        x = (x * 1103515245 + 12345) % 2 ** 31
        out.append(banco[x % len(banco)])
        if i % 20 == 19:                       # el esqueleto numérico de la oferta
            out.append(_CIFRAS[(i // 20) % len(_CIFRAS)])
    return " ".join(out)


def _pagina(titulo, h1, cuerpo, cobra=True):
    compra = ('<form action="/checkout"><button>COMPRAR AHORA</button></form>'
              '<p>Precio: US$ 10 antes US$ 40. Pago seguro con tarjeta. '
              'Descargar ahora, acceso inmediato.</p>') if cobra else ""
    return (f"<html><head><title>{titulo}</title></head><body><h1>{h1}</h1>"
            f"<h2>{'Acceso inmediato por US$ 10' if cobra else 'Sobre nosotros'}</h2>"
            f"<p>{cuerpo}</p>{compra}</body></html>").encode()


def _servir(handler_get):
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            r = handler_get(self)
            if isinstance(r, tuple):                    # ("302", destino)
                self.send_response(302)
                self.send_header("Location", r[1])
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(r)))
            self.end_headers()
            self.wfile.write(r)

    srv = socketserver.TCPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _cloaker():
    """Sirve la posta solo al celular que llega del anuncio. Al resto, vidriera."""
    def get(req):
        ua = req.headers.get("User-Agent", "")
        ref = (req.headers.get("Referer") or "").lower()
        movil = "Mobile" in ua or "iPhone" in ua
        desde_ad = "facebook" in ref or "instagram" in ref or "fbclid" in req.path
        if movil and desde_ad:
            return _pagina("Pack de Finanzas - 150 planillas",
                           "El pack que te ordena la plata",
                           _lorem(_ES, 11), cobra=True)
        return _pagina("Blog de consejos",
                       "Ideas para ordenar tu mes",
                       _lorem(_ES, 99), cobra=False)
    return _servir(get)


def _honesto(ab=False):
    """Página normal. Con ab=True rota un bloque entre pedidos IDENTICOS."""
    n = {"i": 0}

    def get(req):
        n["i"] += 1
        en = "en-US" in (req.headers.get("Accept-Language") or "")
        banco = _EN if en else _ES
        h1 = ("The pack that sorts out your money" if en
              else "El pack que te ordena la plata")
        cuerpo = _lorem(banco, 5)
        if ab and n["i"] % 2 == 0:                 # variante B del test A/B
            cuerpo += " " + _lorem(banco, 4242, 220)
        return _pagina("Pack de Finanzas - 150 planillas", h1, cuerpo)
    return _servir(get)


def _mudanza():
    """Al que NO viene del anuncio lo redirige: mismo pedido, otro destino."""
    def get(req):
        ref = (req.headers.get("Referer") or "").lower()
        if "facebook" in ref or "instagram" in ref or "fbclid" in req.path:
            return _pagina("Pack de Finanzas - 150 planillas",
                           "El pack que te ordena la plata",
                           _lorem(_ES, 11), cobra=True)
        if req.path.startswith("/blog"):
            return _pagina("Pack de Finanzas - 150 planillas",
                           "El pack que te ordena la plata",
                           _lorem(_ES, 11), cobra=True)   # MISMO texto y oferta
        return ("302", "/blog/bienvenida")
    return _servir(get)


def _moneda():
    """Localización de verdad: misma oferta, otra moneda y otro monto."""
    def get(req):
        en = "en-US" in (req.headers.get("Accept-Language") or "")
        p = ('<form action="/checkout"><button>COMPRAR AHORA</button></form>'
             + ("<p>Price: US$ 10. Secure checkout, instant access.</p>" if en
                else "<p>Precio: AR$ 12.000. Pago seguro, acceso inmediato.</p>"))
        return (f"<html><head><title>Pack de Finanzas - 150 planillas</title>"
                f"</head><body><h1>El pack que te ordena la plata</h1>"
                f"<h2>Acceso inmediato</h2><p>{_lorem(_ES, 5)}</p>{p}"
                f"</body></html>").encode()
    return _servir(get)


def autotest():
    """El detector tiene que gritar con el cloaker y callarse con el honesto."""
    casos = [
        ("cloaker por dispositivo+referer (la posta solo al que viene del anuncio)",
         _cloaker, "sospechoso"),
        ("cloaker por redirección (al directo lo manda a otra ruta)",
         _mudanza, "sospechoso"),
        ("honesto, misma oferta para todos, traducido por Accept-Language",
         lambda: _honesto(False), "limpio"),
        ("honesto, misma oferta en otra moneda por región",
         _moneda, "limpio"),
        ("honesto CON test A/B (cambia entre dos pedidos IDENTICOS)",
         lambda: _honesto(True), "indeterminado"),
    ]
    fallos = 0
    for nombre, fabrica, esperado in casos:
        srv, puerto = fabrica()
        try:
            R, cod = analizar(f"http://127.0.0.1:{puerto}/oferta", con_js=False)
            ok = R["veredicto"] == esperado
            fallos += 0 if ok else 1
            print(f"  [{'ok' if ok else 'FALLA'}] {nombre}")
            print(f"        esperado {esperado} · dio {R['veredicto']} (exit {cod})")
            print(f"        piso de ruido {R['piso_de_ruido']} · umbral {R['umbral']}")
            print(f"        {R['motivo'][:160]}")
            for d in R["diferencias"][:3]:
                print(f"          · [{d['nivel']}] {d['identidad']}: {d['que']}")
            if R["veredicto"] == "sospechoso":
                v = R["version_que_cobra"]
                print(f"        dinero → «{v['titulo'][:60]}» "
                      f"· la ven {v['identidades_que_la_ven']}")
        finally:
            srv.shutdown()
    print(f"\n  {len(casos) - fallos}/{len(casos)} casos correctos")
    return 0 if fallos == 0 else 1


# ────────────────────────────────────────────────────────────────────── cli ──
def main():
    ap = argparse.ArgumentParser(
        description="¿Te sirven la misma página que al comprador real?")
    ap.add_argument("url", nargs="?", help="URL a chequear")
    ap.add_argument("--desde", help="URL exacta del anuncio (la que da rompe_placebos)")
    ap.add_argument("--sin-js", action="store_true", dest="sin_js",
                    help="no usar el Chrome de trabajo (solo HTML crudo)")
    ap.add_argument("--guardar", help="carpeta donde volcar cada versión servida")
    ap.add_argument("--json", action="store_true", dest="como_json")
    ap.add_argument("--autotest", action="store_true",
                    help="prueba el detector contra un cloaker local")
    args = ap.parse_args()

    if args.autotest:
        return autotest()
    if not args.url:
        ap.error("falta la URL (o usá --autotest)")

    R, cod = analizar(args.url, desde=args.desde, con_js=not args.sin_js,
                      guardar=args.guardar)
    if args.como_json:
        R["exit"] = cod
        print(json.dumps(R, ensure_ascii=False, indent=1))
    else:
        imprimir(R, cod)
    return cod


if __name__ == "__main__":
    sys.exit(main())
