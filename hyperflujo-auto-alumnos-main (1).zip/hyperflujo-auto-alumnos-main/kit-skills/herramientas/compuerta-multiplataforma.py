#!/usr/bin/env python3
"""compuerta-multiplataforma.py — frena un kit que solo corre en la maquina propia.

POR QUE EXISTE
  Cuarta vez que se entrega una herramienta instalable y se rompe del otro lado
  por un supuesto invisible del sistema operativo. Las tres anteriores se
  arreglaron escribiendo mejor la leccion. La cuarta pide maquina.
  Ver 04-lecciones/cerebro-ia-lo-tuyo-no-corre-en-otra-maquina.md

QUE MIRA (cuatro cosas, todas deterministas)
  A. re.sub con reemplazo interpolado  -> el reemplazo INTERPRETA backslashes.
     Una ruta de Windows (C:\\Users\\...) trae \\U y tira "bad escape". Es el
     bug que rompio un instalador en una maquina real: silencioso en Mac, fatal en Windows.
  B. binarios de macOS sin guardia     -> swift, pbpaste, osascript, sips, open.
  C. docs con comandos de un solo SO   -> python3/pbpaste/zshrc sin su par Windows.
  D. el instalador con BOM y CRLF      -> lo que deja PowerShell 5.1. Se fabrica
     y se compila de verdad, no se supone.
  E. modulos que Windows no tiene      -> import fcntl/termios/pwd/grp/resource
     fuera de un try/except ImportError. El script ni arranca (08/10: el freno
     de escrituras de Meta quedaba apagado en Windows sin avisar).
  F. hooks registrados con python3     -> en Windows `python3` es el acceso
     directo de la Microsoft Store: el hook no corre y nadie se entera.
  G. la fecha con TZ=... date          -> el Git Bash de Windows ignora TZ y da UTC.

CONTROL SEPARADO DE LO CONTROLADO (regla dura 12)
  No importa nada del kit que audita: lee los archivos como texto y usa su
  propio parser. Falla CERRADA: lo que no puede decidir, lo reporta.

USO
  compuerta-multiplataforma.py <carpeta-del-kit> [--instalador <archivo.py>]
  compuerta-multiplataforma.py --autoprueba     # se rompe a proposito

Sale 0 solo si no encontro nada. Cualquier hallazgo -> 1.
"""

import argparse
import ast
import io
import pathlib
import re
import subprocess
import sys
import tarfile
import tempfile

# Windows: con la salida redirigida Python escribe en cp1252 y revienta al
# imprimir → o ✓. Se fuerza UTF-8.
for _flujo in (sys.stdin, sys.stdout, sys.stderr):
    try:
        _flujo.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

# Binarios que solo existen en macOS. Si aparecen en un subprocess sin una
# guardia de plataforma en el mismo archivo, el kit no corre en Windows.
SOLO_MAC = ("swift", "pbpaste", "pbcopy", "osascript", "sips", "afplay",
            "sw_vers", "diskutil", "defaults")

# Pares comando-de-un-SO -> como se dice del otro lado. Si el doc menciona el
# primero y en ningun lado el segundo, al que lee le falta la mitad.
PARES_DOC = [
    ("pbpaste", "Get-Clipboard"),
    ("~/.zshrc", "SetEnvironmentVariable"),
    ("brew install", "pip install"),
]

IGNORAR = {"__pycache__", ".git", ".DS_Store", "node_modules", ".venv"}


class Hallazgos:
    def __init__(self):
        self.items = []

    def add(self, sev, archivo, linea, que, arreglo):
        self.items.append((sev, str(archivo), linea, que, arreglo))

    def __len__(self):
        return len(self.items)


def _archivos(raiz, sufijo):
    for p in sorted(raiz.rglob(f"*{sufijo}")):
        if p.is_file() and not any(x in p.parts for x in IGNORAR):
            yield p


# ── A · el reemplazo de re.sub interpreta backslashes ────────────────────────
def revisar_resub(raiz, h):
    """El caso fatal: re.sub(patron, <algo interpolado>, texto).

    Si el reemplazo no es un literal plano, puede traer una ruta con backslash
    y re lo lee como escape. La forma segura es pasar una funcion (lambda),
    que re no interpreta.
    """
    for p in _archivos(raiz, ".py"):
        try:
            arbol = ast.parse(p.read_text(encoding="utf-8", errors="replace"))
        except SyntaxError as e:
            h.add("ERROR", p, e.lineno or 0, "no parsea, no lo puedo auditar",
                  "arreglá la sintaxis y volvé a correr la compuerta")
            continue
        for n in ast.walk(arbol):
            if not isinstance(n, ast.Call):
                continue
            f = n.func
            nombre = getattr(f, "attr", None) or getattr(f, "id", None)
            if nombre not in ("sub", "subn") or len(n.args) < 2:
                continue
            repl = n.args[1]
            # Seguro: un literal sin backslashes, o una funcion.
            if isinstance(repl, ast.Constant) and isinstance(repl.value, str):
                if "\\" not in repl.value:
                    continue
                h.add("AVISO", p, repl.lineno, "re.sub con backslash literal en el reemplazo",
                      "revisá que sea un grupo (\\1) y no una ruta")
                continue
            if isinstance(repl, (ast.Lambda, ast.Name)):
                continue  # funcion: re no interpreta nada
            h.add("BLOQUEA", p, repl.lineno,
                  "re.sub con reemplazo interpolado: si ahí entra una ruta de "
                  "Windows (C:\\Users\\...) tira 'bad escape \\U' y aborta",
                  "pasá una función: re.sub(pat, lambda _m: f'...', txt)")


# ── B · binarios de macOS sin guardia de plataforma ──────────────────────────
def revisar_binarios_mac(raiz, h):
    for p in _archivos(raiz, ".py"):
        txt = p.read_text(encoding="utf-8", errors="replace")
        tiene_guardia = ("sys.platform" in txt or "platform.system" in txt
                         or "os.name" in txt)
        for i, linea in enumerate(txt.splitlines(), 1):
            if linea.lstrip().startswith("#"):
                continue
            for b in SOLO_MAC:
                if re.search(rf'["\']{re.escape(b)}["\']', linea) and "subprocess" in txt:
                    if tiene_guardia:
                        continue
                    h.add("BLOQUEA", p, i, f"usa «{b}» (solo macOS) sin guardia de plataforma",
                          "envolvelo en `if sys.platform == \"darwin\"` y decí qué "
                          "se pierde en Windows, no lo saltees en silencio")


# ── C · documentos escritos para un solo sistema ─────────────────────────────
def revisar_docs(raiz, h):
    for p in _archivos(raiz, ".md"):
        txt = p.read_text(encoding="utf-8", errors="replace")
        for mac, win in PARES_DOC:
            if mac in txt and win not in txt:
                linea = next((i for i, l in enumerate(txt.splitlines(), 1) if mac in l), 0)
                h.add("AVISO", p, linea, f"dice «{mac}» y en ningún lado «{win}»",
                      "el que recibe puede estar en el otro sistema: van los dos")
        if "python3" in txt and not any(x in txt for x in ("python ", "escribí `python`", "py -3", "`python`")):
            linea = next((i for i, l in enumerate(txt.splitlines(), 1) if "python3" in l), 0)
            h.add("AVISO", p, linea, "dice «python3» y no aclara el equivalente de Windows",
                  "en Windows el comando es `python`: decilo una vez, arriba")


# ── D · el instalador tal como lo deja PowerShell ────────────────────────────
def revisar_instalador(ruta, h):
    """PowerShell 5.1 escribe UTF-8 CON BOM y saltos CRLF. Se fabrica ese
    archivo exacto y se compila. No alcanza con suponer que Python lo tolera."""
    crudo = ruta.read_bytes()
    win = b"\xef\xbb\xbf" + crudo.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
    with tempfile.TemporaryDirectory() as d:
        f = pathlib.Path(d) / "estilo-powershell.py"
        f.write_bytes(win)
        r = subprocess.run([sys.executable, "-c",
                            f"compile(open({str(f)!r},'rb').read(), 'x', 'exec')"],
                           capture_output=True, text=True)
        if r.returncode != 0:
            h.add("BLOQUEA", ruta, 0, "con BOM+CRLF (lo que deja PowerShell) no compila",
                  r.stderr.strip().splitlines()[-1] if r.stderr else "revisá la codificación")
            return
    # y que el payload embebido siga siendo extraible con esa codificacion
    m = re.search(rb'KIT = """\s*(.*?)"""', win, re.S)
    if m:
        import base64
        try:
            datos = base64.b64decode(b"".join(m.group(1).split()))
            with tarfile.open(fileobj=io.BytesIO(datos), mode="r:gz") as tar:
                n = sum(1 for x in tar.getmembers() if x.isfile())
            print(f"  · payload extraíble con BOM+CRLF: {n} archivos")
        except Exception as e:
            h.add("BLOQUEA", ruta, 0, f"el payload no se extrae con BOM+CRLF: {e}",
                  "revisá cómo se decodifica el base64")


# ── E · módulos que solo existen en Mac y Linux ──────────────────────────────
SOLO_UNIX = {"fcntl", "termios", "pwd", "grp", "resource", "tty", "pty"}


def _protegido(arbol, nodo):
    """¿El import está dentro de un try que atrapa ImportError?"""
    for t in ast.walk(arbol):
        if not isinstance(t, ast.Try):
            continue
        if not any(nodo is x for b in t.body for x in ast.walk(b)):
            continue
        for hdl in t.handlers:
            nombres = [hdl.type] if not isinstance(hdl.type, ast.Tuple) else hdl.type.elts
            if hdl.type is None or any(getattr(n, "id", "") in ("ImportError", "ModuleNotFoundError",
                                                                  "Exception") for n in nombres):
                return True
    return False


def revisar_modulos_unix(raiz, h):
    for p in _archivos(raiz, ".py"):
        try:
            arbol = ast.parse(p.read_text(encoding="utf-8", errors="replace"))
        except SyntaxError:
            continue   # ya lo reporta revisar_resub
        for n in ast.walk(arbol):
            mods = []
            if isinstance(n, ast.Import):
                mods = [a.name.split(".")[0] for a in n.names]
            elif isinstance(n, ast.ImportFrom) and n.module:
                mods = [n.module.split(".")[0]]
            for m in mods:
                if m in SOLO_UNIX and not _protegido(arbol, n):
                    h.add("BLOQUEA", p, n.lineno, f"import {m} sin alternativa: en Windows "
                          "el script no arranca", "envolvelo en try/except ImportError con "
                          "el equivalente de Windows (fcntl → msvcrt.locking)")


# ── F · hooks registrados con python3 pelado ─────────────────────────────────
def revisar_hooks_python3(raiz, h):
    """Un hook con `python3 "..."` anda en Mac y en Windows no corre nunca. Vale
    si el instalador reescribe el intérprete al registrarlo (marca: _comando())."""
    for p in list(_archivos(raiz, ".py")) + list(_archivos(raiz, ".json")):
        txt = p.read_text(encoding="utf-8", errors="replace")
        if "_comando(" in txt:
            continue
        for i, linea in enumerate(txt.splitlines(), 1):
            if re.search(r'"command"\s*:\s*[\'"]python3\s', linea):
                h.add("BLOQUEA", p, i, "hook registrado con «python3»: en Windows es el "
                      "acceso directo de la Microsoft Store y el hook no corre",
                      "registrá el intérprete que DE VERDAD ejecuta (py -3 o la ruta real)")


# ── G · la fecha con TZ=... date ─────────────────────────────────────────────
def revisar_fecha_tz(raiz, h):
    for p in list(_archivos(raiz, ".md")) + list(_archivos(raiz, ".py")):
        for i, linea in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if re.search(r"TZ=\S+\s+date\b", linea) and "NO uses" not in linea:
                h.add("AVISO", p, i, "fecha con «TZ=... date»: en el Git Bash de Windows "
                      "ignora la zona y da la hora UTC", "usá python3 ~/herramientas/hoy.py")


# ── autoprueba: la compuerta tiene que ATRAPAR el bug real ───────────────────
def autoprueba():
    """Un guardián que nunca falló está sin estrenar, no probado (regla dura 12).
    Se le da el código EXACTO que rompió en Windows y tiene que bloquearlo."""
    roto = 'import re\nff = "C:/x"\nnuevo = re.sub(r"^F = .*$", f\'F = r"{ff}"\', t, flags=re.M)\n'
    sano = 'import re\nff = "C:/x"\nnuevo = re.sub(r"^F = .*$", lambda _m: f\'F = r"{ff}"\', t, flags=re.M)\n'
    ok = True
    with tempfile.TemporaryDirectory() as d:
        for nombre, src, debe_bloquear in (("roto.py", roto, True), ("sano.py", sano, False)):
            sub = pathlib.Path(d) / nombre.replace(".py", "")
            sub.mkdir()
            (sub / nombre).write_text(src, encoding="utf-8")
            h = Hallazgos()
            revisar_resub(sub, h)
            bloqueo = any(s == "BLOQUEA" for s, *_ in h.items)
            estado = "ok" if bloqueo == debe_bloquear else "FALLA"
            if bloqueo != debe_bloquear:
                ok = False
            print(f"  [{estado}] {nombre}: "
                  f"{'bloqueado' if bloqueo else 'pasa'} "
                  f"(esperado: {'bloqueado' if debe_bloquear else 'pasa'})")
    casos = [
        ("fcntl-roto.py", "import fcntl\n", revisar_modulos_unix, True),
        ("fcntl-sano.py", "try:\n    import fcntl\nexcept ImportError:\n    import msvcrt\n",
         revisar_modulos_unix, False),
        ("hook-roto.py", 'H = {"command": \'python3 "~/herramientas/x.py"\'}\n',
         revisar_hooks_python3, True),
        ("hook-sano.py", 'H = {"command": \'python3 "~/x.py"\'}\nc = _comando(H)\n',
         revisar_hooks_python3, False),
    ]
    with tempfile.TemporaryDirectory() as d:
        for nombre, src, fn, debe_bloquear in casos:
            sub = pathlib.Path(d) / nombre.replace(".py", "")
            sub.mkdir()
            (sub / nombre).write_text(src, encoding="utf-8")
            h = Hallazgos()
            fn(sub, h)
            bloqueo = any(s == "BLOQUEA" for s, *_ in h.items)
            if bloqueo != debe_bloquear:
                ok = False
            print(f"  [{'ok' if bloqueo == debe_bloquear else 'FALLA'}] {nombre}: "
                  f"{'bloqueado' if bloqueo else 'pasa'} "
                  f"(esperado: {'bloqueado' if debe_bloquear else 'pasa'})")
    print("\nautoprueba:", "la compuerta atrapa el caso real y no marca el sano"
          if ok else "LA COMPUERTA NO SIRVE")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("kit", nargs="?", help="carpeta del kit a auditar")
    ap.add_argument("--instalador", help="el .py autoextraíble, si hay")
    ap.add_argument("--autoprueba", action="store_true",
                    help="rompe a propósito y verifica que la compuerta atrape")
    a = ap.parse_args()

    if a.autoprueba:
        return autoprueba()
    if not a.kit:
        ap.error("falta la carpeta del kit (o usá --autoprueba)")

    raiz = pathlib.Path(a.kit).expanduser().resolve()
    if not raiz.is_dir():
        print(f"no existe la carpeta {raiz}")
        return 1

    print(f"Compuerta multiplataforma · {raiz}")
    h = Hallazgos()
    revisar_resub(raiz, h)
    revisar_binarios_mac(raiz, h)
    revisar_docs(raiz, h)
    revisar_modulos_unix(raiz, h)
    revisar_hooks_python3(raiz, h)
    revisar_fecha_tz(raiz, h)
    if a.instalador:
        revisar_instalador(pathlib.Path(a.instalador).expanduser().resolve(), h)

    if not h:
        print("\n[ok] nada que frene la instalación en el otro sistema.")
        return 0

    bloqueos = [x for x in h.items if x[0] == "BLOQUEA"]
    print()
    for sev, arch, ln, que, arreglo in sorted(h.items, key=lambda x: (x[0] != "BLOQUEA", x[1])):
        rel = pathlib.Path(arch)
        try:
            rel = rel.relative_to(raiz)
        except ValueError:
            pass
        print(f"  [{sev}] {rel}:{ln}\n      {que}\n      → {arreglo}")
    print(f"\n{len(bloqueos)} bloqueo(s) · {len(h) - len(bloqueos)} aviso(s)")
    return 1 if bloqueos else 0


if __name__ == "__main__":
    sys.exit(main())
