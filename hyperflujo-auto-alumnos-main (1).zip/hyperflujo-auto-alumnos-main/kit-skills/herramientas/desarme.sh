#!/bin/bash
# desarme.sh — el paso a paso completo de una landing ganadora, en un comando.
#
# QUE RESUELVE
#   Cada vez que aparece una referencia nueva hay que correr siempre lo mismo, en
#   el mismo orden, y ninguna pasada sirve sola: medir sin ver da numeros sin
#   criterio, ver sin medir da impresiones sin poder replicar, las dos sin el
#   copy dejan afuera el 90% de lo que hace vender — y todo junto no sirve de
#   nada si la pagina es una PLACEBO que no cobra —o si es la posta pero nos
#   sirve a NOSOTROS otra version (cloaking). Esto corre las ocho pasadas.
#
# USO
#   desarme.sh <slug> <url> [page_id]
#   desarme.sh recetas-ejemplo https://recetas-ejemplo.com/
#   El page_id del anunciante (opcional) afila la pasada 0; lo da
#   ads_library_search del MCP de Meta. Sin el, se busca por dominio.
#
# QUE DEJA en ~/fuentes/desarmes/<slug>/
#   00-posta.txt             veredicto rompe-placebos: ¿es la pagina que cobra?
#                            [posta] sigue · [placebo] FRENA el pipeline ·
#                            [indeterminado] sigue con advertencia en mayusculas
#   00b-cloaking.txt         veredicto cloaking.py: ¿el contenido que nos sirven
#                            es el que recibe el comprador? Compara la misma URL
#                            pedida con 8 identidades + el render con JS, contra
#                            el piso de ruido de la propia pagina. NO frena (la
#                            URL puede ser la correcta y el contenido no), pero
#                            deja la advertencia en mayusculas.
#   01-fuente/               index.html + css/ + TOKENS.txt (colores HSL,
#                            tipografias con pesos, escala, letter-spacing,
#                            radios, sombras, breakpoints). Contra TOKENS.txt
#                            se valida un calco por DIFF: replicar pide el
#                            fuente, no la impresion.
#   02-forense-celular.txt   pliegue real, presupuesto del hero, secciones con %,
#                            escala tipografica, gradientes, sombras, botones
#   03-anatomia.txt          stack, checkout, paleta por area pintada, aspectos,
#                            carruseles, origen de assets
#   04-copy.txt              el texto verbatim completo
#   05-paleta.txt            la paleta MEDIDA del render: familias de tono con
#                            piso de 0.4%, saturacion del acento, veredicto
#                            disenada/acumulada. El CSS da valores; esto da ROLES.
#   06-fotos/                tiras de pantalla del alto real del dispositivo
#   VEREDICTO.txt            [ok]/[error] por pasada — "corrio y no midio" es error
#
#   (Los desarmes anteriores al 2026-07-30 usan la numeracion vieja
#    00-forense/01-anatomia/02-copy/03-fotos, sin posta ni fuente ni paleta.)
#
# Despues de correr esto quedan los pasos manuales que no se automatizan:
#   A · Mirar las fotos. No listarlas: abrirlas.
#   B · Desarmar los anuncios del anunciante (grilla de la Biblioteca por foto).
#   C · Escribir los tres entregables: IDENTIDAD-VISUAL.md, ANGULO.md y
#       GATILLOS.md (rejillas en la skill desarme-completo).
#
# Solo lectura. No toca ninguna pagina.

set -uo pipefail
SLUG="${1:-}"; URL="${2:-}"; PAGEID="${3:-}"
[ -z "$SLUG" ] || [ -z "$URL" ] && { echo "uso: desarme.sh <slug> <url> [page_id]"; exit 1; }

D=~/fuentes/desarmes/"$SLUG"
mkdir -p "$D/06-fotos"
V="$D/VEREDICTO.txt"
: > "$V"

ok(){ echo "[ok] $1" | tee -a "$V"; }
err(){ echo "[error] $1" | tee -a "$V"; }

echo "═══ desarme de $SLUG"
echo "    $URL"
echo "    → $D"
echo

# ── 0 · rompe-placebos: ¿esta es la pagina que recibe el dinero? ─────────────
# El criterio duro: la que cobra es la que apuntan los anuncios que corren.
# Placebo → FRENA: no tiene sentido medir una pagina que no cobra.
echo "0/6 · rompe-placebos (¿es la pagina que cobra?)…"
if [ -n "$PAGEID" ]; then
  python3 ~/herramientas/rompe_placebos.py "$URL" --page-id "$PAGEID" > "$D/00-posta.txt" 2>&1
else
  python3 ~/herramientas/rompe_placebos.py "$URL" > "$D/00-posta.txt" 2>&1
fi
PB=$?
LINEA=$(grep -m1 -E '^[[:space:]]*\[(posta|placebo|indeterminado)\]' "$D/00-posta.txt" | sed -E 's/^[[:space:]]*\[[a-z]+\][[:space:]]*//')
case $PB in
  0) ok "posta — $LINEA" ;;
  1) err "posta — PLACEBO: $LINEA"
     POSTA=$(grep -m1 'URL POSTA' "$D/00-posta.txt" | sed 's/.*→ //')
     {
       echo "PIPELINE FRENADO EN LA PASADA 0: esta pagina no es la que cobra."
       [ -n "$POSTA" ] && echo "La que cobra es: $POSTA"
     } | tee -a "$V"
     echo
     echo "═══ VEREDICTO"; cat "$V"
     [ -n "$POSTA" ] && { echo; echo "Rearrancá sobre la posta:"; echo "  desarme.sh $SLUG $POSTA${PAGEID:+ $PAGEID}"; }
     exit 1 ;;
  *) echo "POSTA SIN CONFIRMAR — ${LINEA:-no se pudo determinar} — TODO LO MEDIDO ABAJO PUEDE SER DE UNA PLACEBO (detalle en 00-posta.txt)" | tee -a "$V" ;;
esac

# ── 0b · cloaking: ¿el contenido que NOS sirven es el que recibe el comprador? ─
# La pasada 0 confirma la URL; esta confirma el CONTENIDO. Aunque los anuncios
# apunten aca, el operador puede devolver otra pagina segun dispositivo,
# procedencia o si parecemos un revisor. No frena el pipeline (a diferencia del
# placebo, la URL puede ser la correcta), pero si hay contenido diferencial todo
# lo medido abajo es la version que nos sirvieron A NOSOTROS.
echo "0b/6 · cloaking (¿es el contenido que ve el comprador?)…"
# Si la pasada 0 llego al destino real de los anuncios, se lo pasamos con sus
# parametros: la identidad "comprador-anuncio" pide esa URL tal cual en vez de
# una con fbclid inventado. Es la diferencia entre imitar al comprador y serlo.
ADURL=$(grep -m1 -oE 'destino: https?://[^ ]+' "$D/00-posta.txt" 2>/dev/null | sed 's/^destino: //')
if [ -n "$ADURL" ]; then
  python3 ~/herramientas/cloaking.py "$URL" --desde "$ADURL" > "$D/00b-cloaking.txt" 2>&1
else
  python3 ~/herramientas/cloaking.py "$URL" > "$D/00b-cloaking.txt" 2>&1
fi
CL=$?
CLINEA=$(grep -m1 -E '^[[:space:]]*\[(limpio|sospechoso|indeterminado)\]' "$D/00b-cloaking.txt" | sed -E 's/^[[:space:]]*\[[a-z]+\][[:space:]]*//')
case $CL in
  0) ok "cloaking — limpio: ${CLINEA:-todas las identidades ven la misma oferta}" ;;
  1) err "cloaking — CONTENIDO DIFERENCIAL: ${CLINEA:-hay diferencias duras}"
     {
       echo "OJO: TODO LO MEDIDO ABAJO ES LA VERSION QUE NOS SIRVIERON A NOSOTROS,"
       echo "no necesariamente la que ve el comprador. Receta y version que cobra"
       echo "en 00b-cloaking.txt. El rayo-X se marca 'medido sobre la version servida'."
       grep -m1 -A2 'LA QUE RECIBE EL DINERO' "$D/00b-cloaking.txt" | sed 's/^/  /'
     } | tee -a "$V" ;;
  *) echo "CLOAKING SIN DESCARTAR — ${CLINEA:-no se pudo determinar} — no es limpio (detalle en 00b-cloaking.txt)" | tee -a "$V" ;;
esac

# ── 1 · el FUENTE: HTML + CSS + tokens (replicar pide el fuente) ─────────────
echo "1/6 · fuente (HTML + CSS + tokens)…"
if python3 ~/herramientas/tokens.py "$URL" --dir "$D/01-fuente" > "$D/.t1" 2>&1; then
  if grep -q "## COLORES" "$D/01-fuente/TOKENS.txt" 2>/dev/null; then
    NC=$(ls "$D/01-fuente/css/"*.css 2>/dev/null | wc -l | tr -d ' ')
    FAM=$(grep -m1 'familias de tono' "$D/01-fuente/TOKENS.txt" | sed 's/^ *//')
    ok "fuente — index.html + $NC css + TOKENS.txt · $FAM"
  else err "fuente — bajo pero no extrajo tokens"; fi
else err "fuente — $(tail -1 "$D/.t1" 2>/dev/null)"; fi

# ── 2 · forense en el PEOR caso movil (Samsung, pliegue real 681px) ──────────
# Se mide contra 384 y no contra 430: el peor caso manda, y el 99% de las
# conversiones entran por celular.
echo "2/6 · forense (celular, peor caso)…"
if python3 ~/herramientas/forense.py "$URL" --ancho 384 > "$D/02-forense-celular.txt" 2>"$D/.e2"; then
  if grep -q "PRESUPUESTO DEL PRIMER PANTALLAZO" "$D/02-forense-celular.txt"; then
    CORTE=$(grep -c "SE CORTA" "$D/02-forense-celular.txt" || true)
    ok "forense — $(grep -m1 'MAPA DE SECCIONES' "$D/02-forense-celular.txt" | sed 's/.*· //;s/ ─.*//') · cortados por el pliegue: $CORTE"
  else err "forense — corrio y no midio el hero"; fi
else err "forense — $(head -1 "$D/.e2" 2>/dev/null)"; fi

# ── 3 · anatomia comparativa ─────────────────────────────────────────────────
echo "3/6 · anatomia (stack, paleta, aspectos, carruseles)…"
if python3 ~/herramientas/anatomia.py "$URL" > "$D/03-anatomia.txt" 2>"$D/.e3"; then
  if grep -q "PALETA" "$D/03-anatomia.txt"; then
    ok "anatomia — $(grep -m1 '→ aspectos usados' "$D/03-anatomia.txt" | cut -c1-70)"
  else err "anatomia — corrio y no midio la paleta"; fi
else err "anatomia — $(head -1 "$D/.e3" 2>/dev/null)"; fi

# ── 4 · copy verbatim ────────────────────────────────────────────────────────
echo "4/6 · copy verbatim…"
if python3 ~/herramientas/ojos.py ver --url "$URL" --cerrar > "$D/04-copy.txt" 2>"$D/.e4"; then
  W=$(wc -w < "$D/04-copy.txt" | tr -d ' ')
  if [ "$W" -gt 150 ]; then ok "copy — $W palabras"; else err "copy — solo $W palabras"; fi
else err "copy — $(head -1 "$D/.e4" 2>/dev/null)"; fi

# ── 5 · paleta MEDIDA del render (roles, no nombres de variables) ────────────
# El CSS dice que valores existen; esto dice cuales MANDAN en pantalla y cual
# queda reservado para el boton que cobra. La variable --primary puede mentir.
echo "5/6 · paleta medida (render)…"
if python3 ~/herramientas/paleta.py "$URL" > "$D/05-paleta.txt" 2>"$D/.e5"; then
  if grep -q "FAMILIAS DE TONO" "$D/05-paleta.txt"; then
    ok "paleta — $(grep -m1 'VEREDICTO:' "$D/05-paleta.txt" | sed 's/^ *VEREDICTO: //' | cut -c1-70)"
  else err "paleta — corrio y no midio familias"; fi
else err "paleta — $(head -1 "$D/.e5" 2>/dev/null)"; fi

# ── 6 · fotos en tiras del alto real ─────────────────────────────────────────
echo "6/6 · fotos (tiras de 844px)…"
if python3 ~/herramientas/ojos.py foto --url "$URL" --max 12 --cerrar > "$D/.fotos" 2>"$D/.e6"; then
  N=$(grep -c "\.png" "$D/.fotos" || true)
  if [ "$N" -gt 0 ]; then
    grep -oE "/Users/[^ ]+\.png" "$D/.fotos" | while read -r f; do mv "$f" "$D/06-fotos/" 2>/dev/null; done
    ok "fotos — $N tira(s) en 06-fotos/"
  else err "fotos — no genero ninguna"; fi
else err "fotos — $(head -1 "$D/.e6" 2>/dev/null)"; fi

rm -f "$D"/.t1 "$D"/.e2 "$D"/.e3 "$D"/.e4 "$D"/.e5 "$D"/.e6 "$D"/.fotos

echo
echo "═══ VEREDICTO"
cat "$V"
FALLOS=$(grep -c "^\[error\]" "$V" || true)
echo
if [ "$FALLOS" -gt 0 ]; then
  echo "⚠ $FALLOS pasada(s) fallaron. Una corrida que no midio nada es un error, no un exito."
else
  echo "✅ las 8 pasadas midieron."
fi
echo
echo "AHORA, A MANO (no se automatiza):"
echo "  A · Abrir las fotos de $D/06-fotos/ y MIRARLAS."
echo "  B · Desarmar los anuncios del anunciante (copy primario por FOTO de la grilla):"
echo "      ojos.py foto --url 'https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&view_all_page_id=<PAGE_ID>&search_type=page&media_type=all' --escritorio --max 8"
echo "  C · Escribir los tres entregables en $D/:"
echo "      IDENTIDAD-VISUAL.md · ANGULO.md · GATILLOS.md  (rejillas en la skill desarme-completo)"