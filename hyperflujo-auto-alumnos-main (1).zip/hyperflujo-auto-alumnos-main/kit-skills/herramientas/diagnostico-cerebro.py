#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""diagnostico-cerebro.py — ¿está el cerebro instalado y GUARDANDO?

Corre solo, sin instalar nada y sin tocar nada. Mira esta máquina y dice qué
pieza falta, con la línea exacta de qué hacer para arreglarla.

    python3 diagnostico-cerebro.py

Por qué existe: un cerebro puede verse instalado y no guardar nada. Pasó el
2026-09-05 — la versión vieja de /orden arrancaba con `git pull --ff-only` y se
detenía ahí en cualquier vault sin remoto, que es como queda toda instalación
nueva. La carpeta estaba llena y el sistema no escribía una línea. Por eso acá
no alcanza con contar archivos: se prueba la CADENA DE GUARDADO entera.
"""

from __future__ import annotations   # que ande en el Python 3.9 que trae macOS

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# Windows: con la salida redirigida (así la lee Claude Code) Python escribe en
# cp1252: revienta al imprimir ✓ o →, y lee mal (o se cae) con el texto en UTF-8.
for _flujo in (sys.stdin, sys.stdout, sys.stderr):
    try:
        _flujo.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


HOME = Path.home()
CEREBRO = HOME / "cerebro"
CLAUDE = HOME / ".claude"
HERR = HOME / "herramientas"
WINDOWS = os.name == "nt"
MAC = sys.platform == "darwin"
INSTALAR = (("py -3 instalar.py  (o  python instalar.py)" if WINDOWS else "python3 instalar.py")
            + " (parado en la carpeta cerebro-kit)")

V, R, A, G, F = "\033[92m", "\033[91m", "\033[93m", "\033[90m", "\033[0m"
if not sys.stdout.isatty():
    V = R = A = G = F = ""

faltas: list[str] = []      # rompe el sistema
avisos: list[str] = []      # anda, pero conviene mirarlo


def ok(t):    print(f"  {V}[ok]{F}     {t}")
def falta(t, arreglo):
    print(f"  {R}[falta]{F}  {t}")
    faltas.append(arreglo)
def aviso(t, arreglo):
    print(f"  {A}[ojo]{F}    {t}")
    avisos.append(arreglo)
def titulo(n, t):
    print(f"\n{G}── {n} · {t} {'─' * max(0, 52 - len(t))}{F}")


def contar(carpeta: Path, patron: str) -> int:
    return len(list(carpeta.glob(patron))) if carpeta.is_dir() else 0


def git(*args, cwd=CEREBRO) -> tuple[int, str]:
    if not shutil.which("git"):
        return 127, "git no está instalado"
    try:
        r = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                           text=True, timeout=25)
        return r.returncode, (r.stdout + r.stderr).strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)


print(f"""
{G}╭──────────────────────────────────────────────────────────────╮{F}
  DIAGNÓSTICO DEL CEREBRO
  {G}Qué hay, qué falta y por qué no está guardando{F}
{G}╰──────────────────────────────────────────────────────────────╯{F}
  Máquina: {HOME}""")

# ───────────────────────────── 1. la base ─────────────────────────────
titulo("01", "Lo que hace falta para que algo funcione")

v = sys.version_info
if v >= (3, 9):
    ok(f"Python {v.major}.{v.minor}.{v.micro}")
else:
    falta(f"Python {v.major}.{v.minor} es viejo (hace falta 3.9+)",
          "Instalá Python 3.9 o mayor desde python.org.")

if shutil.which("git"):
    ok("git instalado")
else:
    falta("git NO está instalado — sin git el cerebro no guarda NADA",
          "Instalá git: abrí la Terminal y corré  xcode-select --install")

if shutil.which("claude"):
    ok("el comando `claude` está en el PATH")
else:
    aviso("no encuentro el comando `claude` en el PATH (puede estar igual: "
          "si Claude Code te abre, ignorá esta línea)",
          "Si `claude` no te abre en la Terminal: npm install -g @anthropic-ai/claude-code")

# ─────────────────────────── 2. el vault ──────────────────────────────
titulo("02", "El cerebro (~/cerebro)")

if not CEREBRO.is_dir():
    falta("NO existe ~/cerebro: el cerebro no está instalado en esta máquina",
          "Corré el instalador:  " + INSTALAR + "")
else:
    n_notas = contar(CEREBRO / "02-notas", "*.md")
    n_lecc = contar(CEREBRO / "04-lecciones", "*.md")
    n_mocs = contar(CEREBRO / "03-mocs", "*.md")
    n_plan = contar(CEREBRO / "_plantillas", "*.md")
    # Este cerebro nace VACIO: notas, lecciones y MOCs los escribe el dueño trabajando.
    ok(f"contenido propio: {n_notas} nota(s), {max(n_lecc - 1, 0)} lección(es), {n_mocs} MOC(s) — nace vacío, se llena trabajando")
    for etiqueta, n, minimo in (("plantillas en _plantillas/", n_plan, 7),):
        if n >= minimo:
            ok(f"{etiqueta}: {n}")
        elif n == 0:
            falta(f"{etiqueta}: 0 — la carpeta está vacía",
                  "Corré el instalador:  " + INSTALAR + "")
        else:
            aviso(f"{etiqueta}: {n} (el paquete al día trae {minimo} o más)",
                  "Tenés una versión vieja. Volvé a correr el instalador: "
                  "" + INSTALAR + "")

    if (CEREBRO / "CLAUDE.md").is_file():
        ok("CLAUDE.md (la constitución) está en su lugar")
    else:
        falta("falta ~/cerebro/CLAUDE.md: sin constitución tu Claude no sabe "
              "ninguna de las reglas",
              "Corré el instalador:  " + INSTALAR + "")

# ───────────────────── 3. comandos, skills, herramientas ──────────────
titulo("03", "Comandos, skills y herramientas")

n_cmd = contar(CLAUDE / "commands", "*.md")
if n_cmd >= 7:
    ok(f"comandos en ~/.claude/commands/: {n_cmd}  (/orden, /aprende, /minar…)")
elif n_cmd:
    aviso(f"comandos: {n_cmd} de 7", "Volvé a correr el instalador.")
else:
    falta("no hay comandos en ~/.claude/commands/ — /orden no existe en tu Claude",
          "Corré el instalador:  " + INSTALAR + "")

n_sk = contar(CLAUDE / "skills", "*/SKILL.md")
if n_sk >= 25:
    ok(f"skills en ~/.claude/skills/: {n_sk}")
elif n_sk:
    aviso(f"skills: {n_sk} de 25", "Volvé a correr el instalador.")
else:
    falta("no hay skills instaladas", "Corré el instalador.")

n_h = contar(HERR, "*.*")
if n_h >= 30:
    ok(f"herramientas en ~/herramientas/: {n_h}")
elif n_h:
    aviso(f"herramientas: {n_h} (el paquete trae 30 o más)",
          "Volvé a correr el instalador.")
else:
    falta("no hay herramientas en ~/herramientas/", "Corré el instalador.")

rotas = [s.parent.name for s in sorted((CLAUDE / "skills").glob("*/SKILL.md"))
         if not s.read_text(encoding="utf-8", errors="replace")[:400]
         .lstrip().startswith("---")]
if rotas:
    aviso(f"skills sin cabecera válida (Claude no las ve): {', '.join(rotas)}",
          "Volvé a correr el instalador con --forzar.")

# ─────────────────────────── 4. los hooks ─────────────────────────────
titulo("04", "Los hooks (lo que hace que el cerebro te hable solo)")

st = CLAUDE / "settings.json"
if not st.is_file():
    falta("no existe ~/.claude/settings.json: ningún hook registrado",
          "Corré el instalador: registra los hooks sin pisar tu configuración.")
else:
    try:
        datos = json.loads(st.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        datos = None
        falta("~/.claude/settings.json está roto (no es JSON válido)",
              "Abrí ~/.claude/settings.json y arreglá el JSON, o pasáselo a Claude.")
    if datos is not None:
        registrados = []
        for bloques in (datos.get("hooks") or {}).values():
            for b in bloques:
                for h in b.get("hooks", []):
                    registrados.append(h.get("command", ""))
        cuantos = sum(1 for c in registrados if "herramientas" in c)
        if cuantos >= 4:
            ok(f"{cuantos} hooks del cerebro registrados en settings.json")
        elif cuantos:
            aviso(f"solo {cuantos} hook(s) registrados (el paquete trae 4)",
                  "Volvé a correr el instalador: suma los que falten sin tocar los tuyos.")
        else:
            falta("ningún hook del cerebro está registrado",
                  "Corré el instalador:  " + INSTALAR + "")

        if any("recordatorios" in c for c in registrados):
            ok("el hook de recordatorios corre al abrir cada chat")
        else:
            aviso("falta el hook de recordatorios (es el que te canta los comandos)",
                  "Volvé a correr el instalador.")

# se PRUEBAN como los corre Claude Code: el comando EXACTO de settings.json, en
# su shell, con una entrada de prueba. Probar el archivo con el Python de este
# script daba verde en Windows con los cuatro hooks muertos (`python3` ahí es el
# acceso directo de la Microsoft Store, que no ejecuta nada).
def shell_de_claude() -> list:
    """Doc oficial: Git Bash en Windows (PowerShell si no hay Git); bash en Mac/Linux.
    El bash.exe de System32 es el de WSL: otro sistema, no sirve."""
    if not WINDOWS:
        return [shutil.which("bash") or "/bin/sh", "-c"]
    cands = [os.environ.get("CLAUDE_CODE_GIT_BASH_PATH", "")]
    g = shutil.which("git")
    if g:
        cands.append(str(Path(g).resolve().parent.parent / "bin" / "bash.exe"))
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", ""),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs")):
        if base:
            cands.append(os.path.join(base, "Git", "bin", "bash.exe"))
    for c in cands:
        if c and Path(c).is_file():
            return [c, "-c"]
    return ["powershell", "-NoProfile", "-Command"]


rotos, probados = [], 0
try:
    _datos = json.loads(st.read_text(encoding="utf-8")) if st.is_file() else {}
except ValueError:
    _datos = {}
_shell = shell_de_claude()
for _bloques in (_datos.get("hooks") or {}).values():
    for _b in _bloques if isinstance(_bloques, list) else []:
        for _h in _b.get("hooks", []):
            _cmd = _h.get("command", "")
            if "/herramientas/" not in _cmd.replace("\\", "/"):
                continue
            _nombre = Path(_cmd.split('"')[-2] if _cmd.count('"') >= 2 else _cmd).name
            probados += 1
            try:
                r = subprocess.run(_shell + [_cmd], input="{}", capture_output=True,
                                   text=True, timeout=30)
                if r.returncode not in (0, 2):
                    _m = (r.stderr or r.stdout).strip().splitlines()
                    rotos.append(f"{_nombre} (código {r.returncode}: {_m[0][:80] if _m else 'sin mensaje'})")
            except (OSError, subprocess.TimeoutExpired) as e:
                rotos.append(f"{_nombre} ({type(e).__name__})")
if rotos:
    for x in rotos:
        print(f"  {R}[FALLA]{F}  {x}")
    falta(f"{len(rotos)} hook(s) registrados NO corren: el guardián está apagado sin avisar",
          "Volvé a correr el instalador nuevo: registra los hooks con el Python que de verdad "
          "anda en esta máquina:  " + INSTALAR)
elif probados:
    ok(f"los {probados} hooks corren de verdad (probados con el comando exacto de settings.json)")

# ────────────────── 5. LA CADENA DE GUARDADO (lo que falló) ───────────
titulo("05", "¿Puede GUARDAR? (acá estaba el problema)")

if CEREBRO.is_dir():
    hay_remoto = False
    if not (CEREBRO / ".git").is_dir():
        falta("~/cerebro NO es un repositorio git: /orden no tiene dónde guardar",
              "Arreglo:  git -C ~/cerebro init && git -C ~/cerebro add . && "
              "git -C ~/cerebro commit -m 'cerebro: instalacion inicial'")
    else:
        ok("~/cerebro es un repositorio git")
        cod, sal = git("log", "-1", "--format=%h %ad %s", "--date=format:%Y-%m-%d %H:%M")
        if cod == 0 and sal:
            ok(f"último commit: {sal[:70]}")
        else:
            falta("el repositorio no tiene ni un commit: nunca se guardó nada",
                  "Arreglo:  git -C ~/cerebro add . && git -C ~/cerebro commit "
                  "-m 'cerebro: primer guardado'")

        cod, sal = git("config", "user.email")
        if cod == 0 and sal:
            ok(f"git sabe quién sos ({sal})")
        else:
            falta("git no tiene tu nombre ni tu mail: TODO commit va a fallar",
                  'Arreglo:  git config --global user.name "Tu Nombre" && '
                  'git config --global user.email "TU-MAIL"')

        cod, sal = git("remote")
        hay_remoto = bool(cod == 0 and sal.strip())
        if hay_remoto:
            ok(f"remoto configurado ({sal.strip()}): el vault también va a la nube")
        else:
            print(f"  {G}[info]{F}   sin remoto: el vault es local. Está BIEN — "
                  f"guarda igual, en commits locales.")

    orden = CLAUDE / "commands" / "orden.md"
    if orden.is_file():
        t = orden.read_text(encoding="utf-8", errors="replace")
        if "Sincronizá solo si hay con quién" in t or "git -C ~/cerebro remote" in t:
            ok("/orden está en la versión corregida (guarda aunque no haya remoto)")
        elif "git pull --ff-only" in t:
            if hay_remoto:
                aviso("/orden es la versión vieja (arranca con `git pull --ff-only`). "
                      "Acá funciona porque tenés remoto, pero conviene actualizarlo.",
                      "Volvé a correr el instalador para traer /orden corregido.")
            else:
                falta("TU /orden ES LA VERSIÓN VIEJA: arranca con `git pull --ff-only` "
                      "y, como el vault no tiene remoto, se detiene ahí y NO GUARDA "
                      "NADA. ESTA ES LA CAUSA de que el cerebro no se llene.",
                      "Corré el instalador nuevo: " + INSTALAR + " "
                      "(trae /orden arreglado)")
        else:
            ok("/orden instalado")

# ──────────────────────── 6. material crudo ───────────────────────────
titulo("05b", "Esta máquina (" + ("Windows" if WINDOWS else "Mac" if MAC else "Linux") + ")")
hoy = HERR / "hoy.py"
if hoy.is_file():
    r = subprocess.run([sys.executable, str(hoy), "--hora"], capture_output=True, text=True, timeout=20)
    if r.returncode == 0 and len(r.stdout.strip()) == 16:
        ok(f"la fecha sale bien en tu zona horaria: {r.stdout.strip()}")
    else:
        aviso("hoy.py no da la fecha: las notas pueden quedar con el día equivocado",
              "Pasale esta salida a Claude: " + (r.stderr or r.stdout).strip()[:120])
else:
    aviso("falta ~/herramientas/hoy.py (la fecha que anda igual en todos los sistemas)",
          "Volvé a correr el instalador nuevo:  " + INSTALAR)
if WINDOWS:
    if str((_datos.get("env") or {}).get("PYTHONUTF8", "")) == "1":
        ok("Python en modo UTF-8 para todo lo que corre Claude (PYTHONUTF8=1)")
    else:
        aviso("falta PYTHONUTF8=1 en settings.json: los scripts que imprimen ✓ o → se pueden caer",
              "Volvé a correr el instalador nuevo:  " + INSTALAR)
if WINDOWS and _shell[0] == "powershell":
    aviso("no encontré Git Bash: Claude Code va a correr los hooks con PowerShell",
          "Instalá Git para Windows (git-scm.com) y reiniciá VS Code.")
if not MAC:
    solo_mac = [n for n in ("ocr.swift", "paleta.py") if (HERR / n).is_file()]
    if (HERR / "whisper-flow").is_dir():
        solo_mac.append("whisper-flow/")
    if solo_mac:
        ok("solo para Mac (acá no corren, y está bien): " + ", ".join(solo_mac))

titulo("06", "Carpetas de trabajo")
for carpeta, para in ((HOME / "fuentes", "material crudo a destilar con /minar"),
                      (CEREBRO / "00-inbox", "captura cruda"),
                      (CEREBRO / "_staging", "banco de trabajo")):
    if carpeta.is_dir():
        ok(f"{carpeta.name}/ — {para}")
    else:
        aviso(f"falta {carpeta}/ — {para}", "Volvé a correr el instalador.")

# ────────────────────────── veredicto ─────────────────────────────────
print(f"\n{G}{'═' * 66}{F}")
if faltas:
    print(f"  {R}[NO ESTÁ LISTO]{F}  {len(faltas)} cosa(s) rotas o ausentes:\n")
    for i, f_ in enumerate(dict.fromkeys(faltas), 1):
        print(f"    {i}. {f_}")
    print(f"\n  {G}Pegale esta salida entera a Claude Code y decile:{F}")
    print('    «arreglá esto» — sabe qué hacer con cada línea.')
    salida = 1
elif avisos:
    print(f"  {A}[ANDA, CON AVISOS]{F}  {len(avisos)} cosa(s) para mirar:\n")
    for i, a in enumerate(dict.fromkeys(avisos), 1):
        print(f"    {i}. {a}")
    salida = 0
else:
    print(f"  {V}[TODO OK]{F}  El cerebro está instalado, completo y puede guardar.")
    print(f"\n  Probalo ya: abrí Claude Code, escribí algo tuyo del negocio y cerrá")
    print(f"  con {V}/orden{F}. Después mirá que haya quedado:")
    print(f"    git -C ~/cerebro log -1")
    salida = 0
print(f"{G}{'═' * 66}{F}\n")
sys.exit(salida)
