#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dominio-hostinger.py — busca, compra, verifica y apunta un dominio con la API de Hostinger.

Lo usa la skill /comprar-dominio. Biblioteca estándar, cero dependencias.
Funciona en Mac, Linux y Windows (en Windows: `py -3` en lugar de `python3`).

ES LA API DE HOSTINGER. Con otro registrador los pasos son los mismos
(buscar, chequear restricción, comprar, verificar en el registro, DNS) pero los
endpoints y los campos cambian: no uses este script contra otro registrador.

Endpoints verificados contra el OpenAPI oficial (v2.2.0, octubre 2026):
  https://developers.hostinger.com/openapi/openapi.json
  https://docs.hostinger.com/api-reference/endpoints/domains/portfolio.md
  POST /api/domains/v1/availability            disponibilidad + `restriction`
  GET  /api/billing/v1/catalog?category=DOMAIN precios en centavos
  GET  /api/domains/v1/whois                   perfiles de titular
  GET  /api/billing/v1/payment-methods         medios de pago
  GET  /api/domains/v1/portfolio               tu portafolio
  POST /api/domains/v1/portfolio               COMPRA (cobra apenas se llama)
  POST /api/domains/v1/portfolio/{d}/setup     registra uno ya pagado, sin cobrar
  POST /api/dns/v1/zones/{d}/validate          valida registros sin aplicarlos
  PUT  /api/dns/v1/zones/{d}                   escribe registros
  POST /api/domains/v1/forwarding              redirige la raíz a otra URL

CREDENCIAL
  Token en hpanel.hostinger.com/profile/api. Se lee, en este orden, de:
    1. la variable de entorno HOSTINGER_API_TOKEN
    2. el archivo ~/herramientas/.env  (HOSTINGER_API_TOKEN=...)
    3. el llavero de macOS (servicio «hostinger-token»), si existe
  Nunca por argumento ni pegado en el chat.

TOPE DE GASTO (lo define el dueño en ~/herramientas/.env)
  DOMINIO_TOPE_SIN_PREGUNTAR=0     # por defecto 0: SIEMPRE pregunta antes de pagar
  DOMINIO_TOPE_MONEDA=USD          # moneda del tope
  Si el precio del alta supera el tope, o viene en otra moneda que la del tope,
  `comprar --confirmar` se niega salvo que se agregue --ok-del-duenio (el dueño
  lo dijo en ESTE turno, para ESTE dominio y ESTE precio).

USO
  dominio-hostinger.py perfiles
  dominio-hostinger.py buscar tutienda --tlds shop,com,store
  dominio-hostinger.py comprar tutienda.shop --perfil <id> --pago <id>               # simulacro
  dominio-hostinger.py comprar tutienda.shop --perfil <id> --pago <id> --confirmar   # cobra
  dominio-hostinger.py setup tutienda.shop --perfil <id>       # ya pagado, falta registrar
  dominio-hostinger.py verificar tutienda.shop                 # registro (RDAP) + DNS público
  dominio-hostinger.py dns tutienda.shop --plataforma shopify                         # simulacro
  dominio-hostinger.py dns tutienda.shop --plataforma impultienda --www <host> --confirmar
  dominio-hostinger.py dns tutienda.shop --www <host> --raiz-ip <ip> --confirmar      # otra plataforma

REGLAS QUE SALEN DE ERRORES PAGADOS (están en el código, no solo acá)
  · Un error (500, 502, timeout) en la compra NO quiere decir que no se cobró.
    El script NUNCA reintenta: relee el portafolio y te dice qué pasó.
  · Cada intento queda anotado en ~/herramientas/logs/compras-dominio.jsonl.
    Si hay un intento anterior del mismo dominio, no se vuelve a comprar sin
    --reintento-verificado (y solo después de ver con `verificar` que no está).
  · Que el panel diga «active» no prueba nada: la prueba es el registro del TLD
    (RDAP) y que el DNS público responda.
  · Sin --pago el mismo rechazo de tarjeta llega como un 500 mudo; con --pago
    explícito llega como 422 con el motivo. Por eso --pago es obligatorio.
"""
import argparse
import getpass
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

BASE = "https://developers.hostinger.com"
UA = "kit-cerebro/dominio-hostinger"
CARPETA = Path.home() / "herramientas"
ENV = CARPETA / ".env"
LIBRO = CARPETA / "logs" / "compras-dominio.jsonl"

# Registros que pide Shopify para un dominio de terceros (help.shopify.com,
# "Connect a domain manually", octubre 2026). Verificalo en su ayuda si cambió.
SHOPIFY_RAIZ_IP = "23.227.38.65"
SHOPIFY_WWW = "shops.myshopify.com"


# ── configuración y credencial ───────────────────────────────────────────
def leer_env():
    datos = {}
    try:
        for linea in ENV.read_text(encoding="utf-8").splitlines():
            linea = linea.strip()
            if not linea or linea.startswith("#") or "=" not in linea:
                continue
            k, v = linea.split("=", 1)
            datos[k.strip()] = v.strip().strip('"').strip("'")
    except FileNotFoundError:
        pass
    return datos


def config(clave, defecto=""):
    return os.environ.get(clave) or leer_env().get(clave) or defecto


def token():
    t = config("HOSTINGER_API_TOKEN")
    if not t and sys.platform == "darwin":
        try:
            out = subprocess.run(
                ["security", "find-generic-password", "-a", getpass.getuser(),
                 "-s", "hostinger-token", "-w"],
                capture_output=True, text=True, check=True)
            t = out.stdout.strip()
        except Exception:
            t = ""
    if not t:
        sys.exit("[error] Falta el token de Hostinger.\n"
                 "  1. Sacalo en hpanel.hostinger.com/profile/api\n"
                 "  2. Guardalo en ~/herramientas/.env como HOSTINGER_API_TOKEN=...\n"
                 "  Nunca lo pegues en el chat.")
    return t


# ── transporte ───────────────────────────────────────────────────────────
class ErrorApi(Exception):
    def __init__(self, codigo, detalle):
        super().__init__(f"HTTP {codigo}: {detalle}")
        self.codigo = codigo
        self.detalle = detalle


def pedir(metodo, ruta, params=None, cuerpo=None, timeout=60):
    """Único camino HTTP a Hostinger. No reintenta NUNCA."""
    url = BASE + ruta + ("?" + urllib.parse.urlencode(params) if params else "")
    datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
    req = urllib.request.Request(url, data=datos, method=metodo, headers={
        "Authorization": f"Bearer {token()}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": UA,
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            crudo = r.read().decode()
            cuerpo_resp = json.loads(crudo) if crudo.strip() else {}
            return r.status, cuerpo_resp
    except urllib.error.HTTPError as e:
        detalle = e.read().decode(errors="replace")[:600]
        if e.code == 401:
            sys.exit("[error] 401: el token no sirve o venció. Generá otro en "
                     "hpanel.hostinger.com/profile/api y actualizá ~/herramientas/.env")
        if e.code == 429:
            sys.exit("[freno] 429: pasaste el límite de la API (90 por minuto). "
                     "Pará; no reintentes en loop.")
        raise ErrorApi(e.code, detalle)


def lista(r):
    return r if isinstance(r, list) else (r.get("data") or []) if isinstance(r, dict) else []


def portafolio():
    _, r = pedir("GET", "/api/domains/v1/portfolio")
    return lista(r)


def en_portafolio(dominio):
    for d in portafolio():
        if str(d.get("domain", "")).lower() == dominio.lower():
            return d
    return None


def partir(dominio):
    dominio = dominio.strip().lower().rstrip(".")
    if dominio.startswith("www."):
        dominio = dominio[4:]
    if "." not in dominio:
        sys.exit(f"[error] «{dominio}» no tiene TLD. Ejemplo: tutienda.shop")
    base, tld = dominio.split(".", 1)
    return dominio, base, tld


def precio(tld, anios=1):
    """(item_id, alta, renovacion, moneda) del catálogo de ESTA cuenta, en unidades."""
    _, r = pedir("GET", "/api/billing/v1/catalog",
                 params={"category": "DOMAIN", "name": f".{tld.upper()}*"})
    for it in lista(r):
        nombre = str(it.get("name", "")).strip().lower()
        if not (nombre == f".{tld.lower()}" or nombre.startswith(f".{tld.lower()} ")):
            continue
        for p in it.get("prices", []):
            if p.get("period") == anios and p.get("period_unit") == "year":
                alta = p.get("first_period_price")
                renov = p.get("price")
                if alta is None and renov is None:
                    continue
                return (p.get("id"),
                        (alta if alta is not None else renov) / 100,
                        (renov or 0) / 100,
                        p.get("currency", "?"))
    return (None, None, None, None)


def disponibilidad(base, tlds):
    _, r = pedir("POST", "/api/domains/v1/availability",
                 cuerpo={"domain": base, "tlds": tlds})
    return lista(r)


def perfiles_whois(tld=None):
    _, r = pedir("GET", "/api/domains/v1/whois", params={"tld": tld} if tld else None)
    return lista(r)


def nombre_perfil(p):
    d = p.get("whois_details") or {}
    partes = [d.get("first_name"), d.get("last_name")]
    org = d.get("company_name") or d.get("organization")
    return (" ".join(x for x in partes if x) or org or "?")


# ── registro real y DNS público ──────────────────────────────────────────
def rdap(dominio):
    """True / False / None (no se pudo saber) según el REGISTRO del TLD."""
    urls = [f"https://rdap.org/domain/{dominio}"]
    try:
        tld = dominio.rsplit(".", 1)[-1]
        boot = json.load(urllib.request.urlopen(urllib.request.Request(
            "https://data.iana.org/rdap/dns.json", headers={"User-Agent": UA}), timeout=20))
        for tlds, servidores in boot.get("services", []):
            if tld in tlds and servidores:
                urls.append(servidores[0].rstrip("/") + f"/domain/{dominio}")
    except Exception:
        pass
    vio_404 = False
    for u in urls:
        try:
            req = urllib.request.Request(u, headers={"Accept": "application/rdap+json",
                                                     "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=25) as r:
                if r.status == 200:
                    return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                vio_404 = True
        except Exception:
            pass
    return False if vio_404 else None


def dns_publico(nombre, tipo):
    """Pregunta a un resolvedor público (DNS sobre HTTPS). Sirve igual en Windows."""
    try:
        u = "https://dns.google/resolve?" + urllib.parse.urlencode({"name": nombre, "type": tipo})
        r = json.load(urllib.request.urlopen(urllib.request.Request(
            u, headers={"User-Agent": UA}), timeout=20))
        return [a.get("data", "").rstrip(".") for a in r.get("Answer", []) or []]
    except Exception:
        return None


# ── libro de intentos (anti cobro doble) ─────────────────────────────────
def anotar(evento):
    LIBRO.parent.mkdir(parents=True, exist_ok=True)
    evento["t"] = datetime.now().astimezone().isoformat(timespec="seconds")
    with LIBRO.open("a", encoding="utf-8") as f:
        f.write(json.dumps(evento, ensure_ascii=False) + "\n")


def intentos_previos(dominio):
    if not LIBRO.exists():
        return []
    out = []
    for linea in LIBRO.read_text(encoding="utf-8").splitlines():
        try:
            e = json.loads(linea)
        except Exception:
            continue
        if e.get("dominio") == dominio and e.get("paso") == "intento":
            out.append(e)
    return out


# ── comandos ─────────────────────────────────────────────────────────────
def cmd_perfiles(a):
    print("\n  PERFILES DE TITULAR (WHOIS) — mirá A NOMBRE DE QUIÉN y de QUÉ PAÍS.")
    print("  Puede haber perfiles de otras personas en la cuenta: no agarres el primero.\n")
    ps = perfiles_whois(a.tld)
    if not ps:
        print("    (no hay perfiles; crealo en hPanel o con POST /api/domains/v1/whois)")
    for p in ps:
        defecto = " (por defecto)" if p.get("is_default") else ""
        print(f"    --perfil {p.get('id'):<10} tld={str(p.get('tld')):<6} "
              f"país={str(p.get('country')):<3} {str(p.get('entity_type')):<12} "
              f"{nombre_perfil(p)}{defecto}")
    _, r = pedir("GET", "/api/billing/v1/payment-methods")
    print("\n  MEDIOS DE PAGO\n")
    for m in lista(r):
        marcas = []
        if m.get("is_default"):
            marcas.append("por defecto")
        if m.get("is_expired"):
            marcas.append("VENCIDO")
        if m.get("is_suspended"):
            marcas.append("SUSPENDIDO")
        print(f"    --pago {m.get('id'):<12} {m.get('payment_method', '')} "
              f"{m.get('identifier', '')} vence {str(m.get('expires_at'))[:10]}"
              f"{'  (' + ', '.join(marcas) + ')' if marcas else ''}")
    print("\n  El dueño elige perfil y medio de pago. Estos números no se guardan en notas.\n")


def cmd_buscar(a):
    base = a.nombre.strip().lower().split(".")[0]
    tlds = [t.strip().lstrip(".").lower() for t in a.tlds.split(",") if t.strip()]
    filas = disponibilidad(base, tlds)
    print(f"\n  DISPONIBILIDAD de «{base}»\n")
    for f in filas:
        dom = f.get("domain") or "?"
        tld = dom.split(".", 1)[-1] if "." in dom else "?"
        libre = f.get("is_available")
        linea = f"    {'[libre]' if libre else '[ocupado]':<10} {dom:<34}"
        if libre and tld != "?":
            try:
                _, alta, renov, mon = precio(tld)
                if alta is not None:
                    linea += f" alta {mon} {alta:,.2f} · renovación {mon} {renov:,.2f}/año"
            except ErrorApi:
                pass
        print(linea)
        if f.get("restriction"):
            print(f"               RESTRICCIÓN: {f['restriction']}")
    if a.alternativas and len(tlds) == 1:
        alt = [x for x in lista(pedir("POST", "/api/domains/v1/availability", cuerpo={
            "domain": base, "tlds": tlds, "with_alternatives": True})[1])
               if x.get("is_alternative") and x.get("is_available")]
        if alt:
            print("\n  Alternativas libres que sugiere Hostinger:")
            for x in alt[:10]:
                print(f"    {x.get('domain')}")
    print("\n  Antes de elegir un TLD con RESTRICCIÓN, cruzala con el país del perfil "
          "(`perfiles`).\n  Si el titular no cumple, se cobra igual y el registro lo rechaza: "
          "elegí otro TLD.\n")


def cmd_comprar(a):
    dominio, base, tld = partir(a.dominio)
    simulacro = a.simulacro or not a.confirmar

    # 0 · ¿ya hubo un intento? (un error en la compra no prueba que no se cobró)
    previos = intentos_previos(dominio)
    if previos and not a.reintento_verificado:
        print(f"[freno] Ya hubo {len(previos)} intento(s) de comprar {dominio} "
              f"(último {previos[-1].get('t')}).")
        print("  NO se reintenta a ciegas: puede estar cobrado.")
        print(f"  1. Corré:  dominio-hostinger.py verificar {dominio}")
        print("  2. Mirá en hPanel → Facturación si hay un cargo.")
        print("  3. Solo si NO está en el portafolio ni cobrado, repetí con --reintento-verificado.")
        return 2

    # 1 · ¿ya es tuyo?
    ya = en_portafolio(dominio)
    if ya:
        print(f"[ya está] {dominio} ya figura en tu portafolio con estado «{ya.get('status')}».")
        print("  No se compra de nuevo. Si dice pending_setup: usá `setup`. "
              "Si no, seguí con `verificar`.")
        return 0

    # 2 · disponibilidad y restricción del TLD
    filas = [f for f in disponibilidad(base, [tld])
             if str(f.get("domain", "")).lower() == dominio or not f.get("is_alternative")]
    if not filas or not any(f.get("is_available") for f in filas):
        print(f"[no] {dominio} no está disponible.")
        return 1
    restriccion = next((f.get("restriction") for f in filas if f.get("restriction")), None)

    # 3 · precio real de ESTA cuenta (puede venir en moneda local)
    item, alta, renov, mon = precio(tld, a.anios)
    if not item:
        print(f"[no] No encontré precio de .{tld} a {a.anios} año(s) en el catálogo.")
        return 1

    # 4 · titular y medio de pago, mirados a mano
    perfil = next((p for p in perfiles_whois() if p.get("id") == a.perfil), None)
    if not perfil:
        print(f"[no] El perfil {a.perfil} no existe en la cuenta. Corré `perfiles`.")
        return 1
    if str(perfil.get("tld", "")).lower() not in ("", tld):
        print(f"[ojo] El perfil {a.perfil} es para .{perfil.get('tld')}, no para .{tld}. "
              "Puede rechazarse: buscá o creá uno para este TLD.")

    print(f"\n  dominio     : {dominio}  ({a.anios} año/s)")
    print(f"  titular     : {nombre_perfil(perfil)} · país {perfil.get('country')} "
          f"· {perfil.get('entity_type')}  (perfil {a.perfil})")
    print(f"  alta        : {mon} {alta:,.2f}   (sin impuestos; el cargo puede sumar IVA)")
    print(f"  renovación  : {mon} {renov:,.2f} por año  <- lo que se paga los años siguientes")
    print(f"  medio pago  : {a.pago}")
    if restriccion:
        print(f"  RESTRICCIÓN : {restriccion}")

    if restriccion and not a.cumple_restriccion:
        print("\n[freno] Este TLD tiene restricción. Si el titular no cumple, Hostinger cobra")
        print("  y el registro lo rechaza. Leé la restricción, cruzala con el país del perfil")
        print("  y, si cumple, repetí con --cumple-restriccion. Si no cumple: otro TLD (.shop).")
        return 2

    if simulacro:
        print("\n  [simulacro] NO se cobró nada.")
        print("  Mostrale al dueño dominio, titular, alta y RENOVACIÓN. Para comprar:")
        print(f"    dominio-hostinger.py comprar {dominio} --perfil {a.perfil} --pago {a.pago}"
              f"{' --cumple-restriccion' if restriccion else ''} --confirmar")
        return 0

    # 5 · tope de gasto del dueño (falla cerrado)
    try:
        tope = float(config("DOMINIO_TOPE_SIN_PREGUNTAR", "0").replace(",", "."))
    except ValueError:
        tope = 0.0
    tope_mon = config("DOMINIO_TOPE_MONEDA", "USD").upper()
    dentro = tope > 0 and str(mon).upper() == tope_mon and alta <= tope
    if not dentro and not a.ok_del_duenio:
        if tope <= 0:
            motivo = "no hay tope configurado (DOMINIO_TOPE_SIN_PREGUNTAR=0): siempre se pregunta"
        elif str(mon).upper() != tope_mon:
            motivo = f"el precio viene en {mon} y tu tope está en {tope_mon}"
        else:
            motivo = f"el alta ({mon} {alta:,.2f}) supera tu tope ({tope_mon} {tope:,.2f})"
        print(f"\n[freno] No se compra: {motivo}.")
        print("  Esto lo decide el dueño. Con su OK en ESTE turno, para ESTE dominio y ESTE precio,")
        print("  repetí agregando --ok-del-duenio.")
        return 2

    # 6 · comprar — UNA sola llamada, sin reintentos
    cuerpo = {
        "domain": dominio,
        "item_id": item,
        "payment_method_id": a.pago,
        "domain_contacts": {k: a.perfil for k in
                            ("owner_id", "admin_id", "billing_id", "tech_id")},
    }
    anotar({"paso": "intento", "dominio": dominio, "item_id": item,
            "alta": alta, "moneda": mon})
    try:
        codigo, r = pedir("POST", "/api/domains/v1/portfolio", cuerpo=cuerpo, timeout=120)
    except (ErrorApi, urllib.error.URLError, TimeoutError, OSError) as e:
        codigo_err = getattr(e, "codigo", None)
        anotar({"paso": "error", "dominio": dominio, "detalle": str(e)[:300]})
        print(f"\n[error] La compra respondió: {str(e)[:300]}")
        if codigo_err == 422:
            print("  422 = la rechazaron con motivo (fondos, datos del titular, TLD). "
                  "Leé el detalle de arriba.")
        print("\n  UN ERROR NO QUIERE DECIR QUE NO SE COBRÓ. No reintentes.")
        print("  Releyendo el portafolio (3 veces, cada 30 s)...")
        for i in range(3):
            time.sleep(30)
            d = en_portafolio(dominio)
            if d:
                print(f"  [ESTÁ] {dominio} entró al portafolio con estado «{d.get('status')}».")
                print("  La compra SÍ pasó. Seguí con `verificar` (y `setup` si dice pending_setup).")
                anotar({"paso": "aparecio-tras-error", "dominio": dominio,
                        "estado": d.get("status")})
                return 0
            print(f"    {i + 1}/3 · todavía no aparece")
        print(f"\n  No aparece. Igual NO reintentes ahora: mirá Facturación en hPanel y volvé a")
        print(f"  correr `verificar {dominio}` en unos minutos. El libro de intentos frena")
        print("  la próxima compra de este dominio hasta que lo confirmes.")
        return 1

    anotar({"paso": "respuesta", "dominio": dominio, "http": codigo,
            "estado": r.get("status") if isinstance(r, dict) else None})
    estado = r.get("status") if isinstance(r, dict) else None
    print(f"\n  respuesta HTTP {codigo} · orden {r.get('id') if isinstance(r, dict) else '?'} "
          f"· estado «{estado}»")
    if codigo == 202 or estado == "payment_initiated":
        print("  202 = el pago se está procesando y el dominio TODAVÍA NO está registrado")
        print("  (lo dice la doc oficial). Cuando entre al portafolio en pending_setup:")
        print(f"    dominio-hostinger.py setup {dominio} --perfil {a.perfil}")
    print(f"\n  Ahora, siempre:  dominio-hostinger.py verificar {dominio}")
    return 0


def cmd_setup(a):
    dominio, _, _ = partir(a.dominio)
    d = en_portafolio(dominio)
    if not d:
        print(f"[no] {dominio} no está en tu portafolio todavía. Si la orden sigue "
              "procesándose, esperá a que aparezca.")
        return 1
    print(f"  {dominio} figura como «{d.get('status')}».")
    if d.get("status") != "pending_setup" and not a.forzar:
        print("  No está en pending_setup: no hace falta setup. Corré `verificar`.")
        return 0
    perfil = next((p for p in perfiles_whois() if p.get("id") == a.perfil), None)
    if not perfil:
        print(f"[no] El perfil {a.perfil} no existe. Corré `perfiles`.")
        return 1
    print(f"  Se registra a nombre de: {nombre_perfil(perfil)} · país {perfil.get('country')}")
    if a.simulacro:
        print("  [simulacro] no se mandó nada.")
        return 0
    # La doc oficial: no crea orden ni cobra; usa la suscripción ya pagada.
    codigo, r = pedir("POST", f"/api/domains/v1/portfolio/{dominio}/setup", cuerpo={
        "domain_contacts": {k: a.perfil for k in
                            ("owner_id", "admin_id", "billing_id", "tech_id")}})
    print(f"  HTTP {codigo}: {r}")
    print("  «Aceptado» no es «registrado»: en unos minutos corré `verificar`.")
    return 0


def cmd_verificar(a):
    dominio, _, _ = partir(a.dominio)
    d = en_portafolio(dominio)
    reg = rdap(dominio)
    ns = dns_publico(dominio, "NS")
    print(f"\n  {dominio}")
    print(f"    Hostinger dice : {d.get('status') if d else 'no está en el portafolio'}")
    print(f"    el registro    : "
          f"{'EXISTE' if reg else 'NO lo conoce' if reg is False else 'no se pudo consultar (probá el whois web del registro del TLD)'}")
    print(f"    DNS público NS : {', '.join(ns) if ns else 'sin respuesta'}")
    raiz = dns_publico(dominio, "A")
    www = dns_publico("www." + dominio, "CNAME") or dns_publico("www." + dominio, "A")
    print(f"    raíz (A)       : {', '.join(raiz) if raiz else '-'}")
    print(f"    www            : {', '.join(www) if www else '-'}")
    if reg and ns:
        print("\n  [ok] Existe de verdad. Si falta, seguí con `dns`.")
    elif d and d.get("status") == "pending_setup":
        print("\n  [pendiente] Pagado y SIN registrar. Corré `setup` con el perfil del dueño,")
        print("  o confirmá los datos del titular en hPanel (Dominios → el dominio).")
    elif d and reg is False:
        print("\n  [ojo] Está en el portafolio pero el registro no lo conoce. Normal los primeros")
        print("  minutos. Si a las 24 h sigue igual, la compra está colgada: se reclama en el chat")
        print("  de hPanel (la API no cancela ni reembolsa).")
    print()
    return 0


def zona_de(dominio, plataforma, www, raiz_ip):
    zona = []
    if plataforma == "shopify":
        www = www or SHOPIFY_WWW
        raiz_ip = raiz_ip or SHOPIFY_RAIZ_IP
    if www:
        zona.append({"name": "www", "type": "CNAME", "ttl": 300,
                     "records": [{"content": www.rstrip(".") + "."}]})
    if raiz_ip:
        zona.append({"name": "@", "type": "A", "ttl": 300,
                     "records": [{"content": raiz_ip}]})
    return zona


def cmd_dns(a):
    dominio, _, _ = partir(a.dominio)
    if a.plataforma == "impultienda" and not a.www:
        sys.exit("[error] Impultienda: pasá --www con el destino que muestra tu panel en "
                 "Configuraciones → Dominio (la tienda va CON www).")
    if a.plataforma == "otra" and not (a.www or a.raiz_ip):
        sys.exit("[error] Decime --www <host> y/o --raiz-ip <ip> que pide tu plataforma.")
    zona = zona_de(dominio, a.plataforma, a.www, a.raiz_ip)
    redirigir = a.plataforma == "impultienda" and not a.raiz_ip and not a.sin_redireccion

    print(f"\n  DNS de {dominio} — lo que se va a escribir:")
    for z in zona:
        print(f"    {z['type']:<6} {z['name']:<5} -> {z['records'][0]['content']}")
    if redirigir:
        print(f"    raíz   {dominio} -> 301 a https://www.{dominio}/  (redirección de Hostinger)")
    print("  (overwrite=true reemplaza SOLO los registros con el mismo nombre y tipo; "
          "el resto queda)")

    try:
        pedir("POST", f"/api/dns/v1/zones/{dominio}/validate",
              cuerpo={"overwrite": True, "zone": zona})
        print("  [ok] Hostinger validó los registros.")
    except ErrorApi as e:
        print(f"[no] Hostinger rechazó los registros: {e.detalle[:300]}")
        return 1

    if a.simulacro or not a.confirmar:
        print("\n  [simulacro] No se escribió nada. Para aplicarlo agregá --confirmar.\n")
        return 0

    pedir("PUT", f"/api/dns/v1/zones/{dominio}", cuerpo={"overwrite": True, "zone": zona})
    print("  [ok] zona escrita.")
    if redirigir:
        try:
            pedir("POST", "/api/domains/v1/forwarding", cuerpo={
                "domain": dominio, "redirect_type": "301",
                "redirect_url": f"https://www.{dominio}/"})
            print("  [ok] raíz redirigida a www.")
        except ErrorApi as e:
            print(f"  [aviso] no pude crear la redirección de la raíz: {e.detalle[:200]}")
            print("  Hacela en hPanel → Dominios → Redirigir, o pedile a tu plataforma la IP de la raíz.")

    # Releer: que la API diga «aceptado» no es que esté escrito.
    _, actual = pedir("GET", f"/api/dns/v1/zones/{dominio}")
    print("\n  Zona releída de Hostinger:")
    for x in lista(actual):
        if x.get("name") in ("@", "www") and x.get("type") in ("A", "CNAME", "ALIAS"):
            print(f"    {x.get('type'):<6} {x.get('name'):<5} -> "
                  f"{', '.join(c.get('content', '') for c in x.get('records', []))}")
    print("\n  Falta lo último en la plataforma: cargar www." + dominio +
          " en su panel y tocar Verificar cuando propague (minutos a unas horas).")
    print(f"  Después: dominio-hostinger.py verificar {dominio}\n")
    return 0


def main():
    ap = argparse.ArgumentParser(description="Dominios con la API de Hostinger (kit del cerebro).")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("perfiles", help="perfiles de titular y medios de pago")
    p.add_argument("--tld", help="filtrar perfiles por TLD (sin punto)")
    p.set_defaults(f=cmd_perfiles)

    b = sub.add_parser("buscar", help="disponibilidad, restricción y precio")
    b.add_argument("nombre", help="sin TLD, ej: tutienda")
    b.add_argument("--tlds", default="shop,com,store,online")
    b.add_argument("--alternativas", action="store_true", help="con un solo TLD")
    b.set_defaults(f=cmd_buscar)

    c = sub.add_parser("comprar", help="compra (sin --confirmar es simulacro)")
    c.add_argument("dominio")
    c.add_argument("--perfil", type=int, required=True, help="id del perfil de titular")
    c.add_argument("--pago", type=int, required=True, help="id del medio de pago")
    c.add_argument("--anios", type=int, default=1)
    c.add_argument("--simulacro", action="store_true", help="muestra todo y no cobra")
    c.add_argument("--confirmar", action="store_true", help="COBRA")
    c.add_argument("--cumple-restriccion", action="store_true",
                   help="el titular cumple la restricción del TLD (leída y cruzada)")
    c.add_argument("--ok-del-duenio", action="store_true",
                   help="el dueño aprobó ESTE dominio y ESTE precio en este turno")
    c.add_argument("--reintento-verificado", action="store_true",
                   help="hubo un intento previo y se verificó que NO quedó comprado")
    c.set_defaults(f=cmd_comprar)

    s = sub.add_parser("setup", help="registra un dominio ya pagado (no cobra)")
    s.add_argument("dominio")
    s.add_argument("--perfil", type=int, required=True)
    s.add_argument("--simulacro", action="store_true")
    s.add_argument("--forzar", action="store_true", help="aunque no diga pending_setup")
    s.set_defaults(f=cmd_setup)

    v = sub.add_parser("verificar", help="portafolio vs registro (RDAP) vs DNS público")
    v.add_argument("dominio")
    v.set_defaults(f=cmd_verificar)

    d = sub.add_parser("dns", help="apunta el dominio a la tienda (sin --confirmar es simulacro)")
    d.add_argument("dominio")
    d.add_argument("--plataforma", choices=["shopify", "impultienda", "otra"], default="otra")
    d.add_argument("--www", help="destino del CNAME de www")
    d.add_argument("--raiz-ip", help="IP del registro A de la raíz")
    d.add_argument("--sin-redireccion", action="store_true",
                   help="Impultienda: no redirigir la raíz a www")
    d.add_argument("--simulacro", action="store_true")
    d.add_argument("--confirmar", action="store_true")
    d.set_defaults(f=cmd_dns)

    a = ap.parse_args()
    try:
        sys.exit(a.f(a) or 0)
    except ErrorApi as e:
        sys.exit(f"[error] {e}")


if __name__ == "__main__":
    main()
