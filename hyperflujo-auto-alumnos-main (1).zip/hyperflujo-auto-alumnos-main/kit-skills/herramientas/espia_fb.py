#!/usr/bin/env python3
"""espia_fb.py — extrae tarjetas de la Biblioteca de Anuncios de Meta via CDP.

Reutiliza el cliente WebSocket/CDP de ojos.py (perfil chrome-ojos, puerto 9222).
Scrollea para forzar el lazy-load y devuelve JSON por tarjeta:
  {id, texto, video, poster, imgs[]}
Uso:
  espia_fb.py <url> [--scrolls 8] [--espera 6] [--cerrar]
"""
import os
import argparse
import json
import sys
import time

sys.path.insert(0, os.path.expanduser("~/herramientas"))
import ojos  # noqa: E402

JS_EXTRAER = r"""
(() => {
  const hojas = [...document.querySelectorAll('div,span')].filter(
    e => e.childElementCount === 0 &&
         /(Identificador de la biblioteca|Library ID)\s*:?\s*\d{6,}/.test(e.textContent||''));
  const vistos = new Set();
  const out = [];
  for (const h of hojas) {
    const m = (h.textContent||'').match(/\d{6,}/);
    if (!m || vistos.has(m[0])) continue;
    vistos.add(m[0]);
    let card = h;
    for (let i = 0; i < 14 && card.parentElement; i++) {
      card = card.parentElement;
      if ((card.querySelector('video') || card.querySelectorAll('img').length > 1)
          && (card.innerText||'').length > 150) break;
    }
    const v = card.querySelector('video');
    const srcs = v ? [...v.querySelectorAll('source')].map(s => s.src) : [];
    const imgs = [...card.querySelectorAll('img')]
      .map(i => i.src)
      .filter(u => u && u.includes('fbcdn') && !u.includes('emoji') && !u.includes('rsrc'));
    out.push({
      id: m[0],
      texto: (card.innerText || '').slice(0, 4000),
      video: v ? (v.currentSrc || v.src || srcs[0] || null) : null,
      poster: v ? (v.poster || null) : null,
      imgs: [...new Set(imgs)].slice(0, 6),
    });
  }
  return JSON.stringify(out);
})()
"""


def evaluar(cdp, ses, expr, espera=25):
    r = cdp.cmd("Runtime.evaluate",
                {"expression": expr, "returnByValue": True, "awaitPromise": True},
                sesion=ses, espera=espera)
    return r.get("result", {}).get("value")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--scrolls", type=int, default=8)
    ap.add_argument("--espera", type=float, default=6)
    ap.add_argument("--cerrar", action="store_true")
    args = ap.parse_args()

    if not ojos.vivo():
        print("Chrome de ojos apagado", file=sys.stderr)
        return 1

    cdp = ojos.CDP(ojos.http_json("/json/version")["webSocketDebuggerUrl"])
    tid = cdp.cmd("Target.createTarget", {"url": args.url})["targetId"]
    ses = cdp.cmd("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]
    try:
        time.sleep(args.espera)  # primer render
        for _ in range(args.scrolls):
            evaluar(cdp, ses, "window.scrollTo(0, document.body.scrollHeight); 1")
            time.sleep(args.espera / 2)
        # pausa para que carguen posters/videos de lo visible
        evaluar(cdp, ses, "window.scrollTo(0, 0); 1")
        time.sleep(2)
        crudo = evaluar(cdp, ses, JS_EXTRAER, espera=40)
        datos = json.loads(crudo or "[]")
        print(json.dumps(datos, ensure_ascii=False, indent=1))
        print(f"[extraidas {len(datos)} tarjetas]", file=sys.stderr)
        return 0
    finally:
        if args.cerrar:
            try:
                cdp.cmd("Target.closeTarget", {"targetId": tid})
            except Exception:
                pass
        cdp.cerrar()


if __name__ == "__main__":
    sys.exit(main())
