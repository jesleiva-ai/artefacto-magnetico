# Esqueletos

Pseudocódigo limpio de los robots más reusables. No son los scripts reales: no traen IDs, rutas, cuentas ni números del negocio. Los umbrales están como parámetros arriba de cada archivo para que los ajustes a tu ticket y tu presupuesto de testeo.

Las funciones marcadas `# TODO` son las que dependen de tu plataforma (leer gasto de Meta, leer órdenes cobradas de tu tienda, mandar un aviso).

| Archivo | Qué es |
|---|---|
| [auditor_y_freno_de_reglas.py](auditor_y_freno_de_reglas.py) | Juzga cada decisión de los robots con las 3 h siguientes/anteriores y frena la regla que viene errando, con sombra y rehabilitación. Falla abierto. |
| [palanca_acotada.py](palanca_acotada.py) | La única palanca de un agente de IA nocturno: límites duros en el código, candado, escritura atómica, bitácora. |
| [cola_diaria.py](cola_diaria.py) | Prende N conjuntos por mercado por día desde una cola, copiando la segmentación del vivo más reciente y verificando releyendo. |
| [escalera_topes.py](escalera_topes.py) | La canilla: busca el tope de costo donde la campaña gasta y vende, con memoria y freno de subidas. |
| [freno_de_mano.py](freno_de_mano.py) | Corta a la mitad la escala que pierde fuerte en el día, una vez por día, en el huso de la cuenta. |
| [guardia_candados.sh](guardia_candados.sh) | Guardia mecánico: candados tomados de más, robots quietos, aviso una vez por noche. |

Reglas que valen para todos:
1. Modo `--seco` que muestra qué haría sin tocar nada.
2. Toda escritura en la plataforma se **relee** para verificar.
3. Toda decisión se anota en una bitácora JSONL (para que el auditor la juzgue).
4. Si no pudo leer todo, el informe dice "incompleto", nunca "0".
5. Ante el freno de la API: parar, esperar y reintentar después; nunca insistir.
6. **Ningún robot prende, sube ni baja nada en real sin haber corrido días en simulacro y sin el
   OK explícito del dueño.** Los esqueletos que tocan plata (`cola_diaria.py` prende conjuntos,
   `escalera_topes.py` mueve topes, `freno_de_mano.py` baja presupuestos) arrancan en `--seco`.
   Si le pedís a Claude que los complete, el paso a real lo decidís vos, por escrito.
