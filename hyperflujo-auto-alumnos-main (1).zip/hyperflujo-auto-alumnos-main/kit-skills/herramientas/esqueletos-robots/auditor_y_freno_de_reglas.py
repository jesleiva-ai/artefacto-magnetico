"""Auditor de decisiones + freno de reglas (esqueleto).

Idea: cada regla de un robot es una hipótesis. Después de cada decisión se mira qué pasó:
  - SUBA acertada  <=> ROAS cobrado de las VENTANA_H horas SIGUIENTES >= meta del mercado
  - CORTE acertado <=> ROAS cobrado de las VENTANA_H horas ANTERIORES <  meta del mercado
Se cuenta UNA decisión por (campaña, regla, ventana): varias decisiones en la misma ventana miden las mismas ventas.

Antes de ejecutar, cada robot llama a frenar(). Si la regla viene errando en ese mercado:
  - una suba no se ejecuta;
  - un corte solo se ejecuta si las últimas horas vienen de verdad bajo la meta.
Lo frenado queda como SOMBRA y se juzga igual: si habría acertado, la regla se rehabilita sola.
Nunca frena reglas de seguridad. Falla ABIERTO: sin datos, el robot hace lo de siempre.
"""
import json, time

VENTANA_H = 3            # horas para juzgar
P = None                 # TODO: tu presupuesto diario de testeo
GASTO_MIN_P = 3          # gasto mínimo en la ventana para que la decisión cuente, en múltiplos de P
DIAS = 7                 # ventana de acierto
MIN_DEC = 4              # decisiones independientes mínimas para opinar
ACIERTO_MIN = 0.60
ROAS_EQUILIBRIO = 1.2    # una suba que no llega a la meta pero deja >= esto todavía gana plata
MAX_EDAD_RESUMEN_H = 36
NUNCA = {"freno_mano", "disparo_salvavidas", "techo", "arranque", "reset", "freno_cpa"}

SUBAS = {"sube", "pico", "sube_tope", "canilla_pico"}
CORTES = {"baja", "baja_tope", "freno_tarde"}


# ---------- datos (TODO: conectalos a tus bitácoras) ----------
def serie(campania, desde, hasta):
    """Lista ordenada de (t, gasto_acumulado, cobrado_acumulado) de las fotos cada 30 min."""
    raise NotImplementedError

def decisiones_de_los_robots(dias):
    """Lista de dicts: robot, regla, tipo ('sube'|'corta'), t, campania, mercado."""
    raise NotImplementedError

def meta_del_mercado(mercado):
    return 1.4


# ---------- juicio ----------
def tramo(pts, t0, t1):
    """Suma incrementos entre fotos; si el acumulado baja, la cuenta cambió de día."""
    pts = [p for p in pts if t0 - 1200 <= p[0] <= t1 + 1200]
    if len(pts) < 2:
        return None
    g = v = 0.0
    for a, b in zip(pts, pts[1:]):
        if b[1] < a[1]:
            g += b[1]; v += b[2]
        else:
            g += b[1] - a[1]; v += max(0.0, b[2] - a[2])
    return g, v

def juzgar(d):
    meta = meta_del_mercado(d["mercado"])
    h = VENTANA_H * 3600
    if d["tipo"] == "sube":
        r = tramo(serie(d["campania"], d["t"], d["t"] + h), d["t"], d["t"] + h)
        if not r or r[0] < GASTO_MIN_P * P:
            return "sin_efecto", r
        return ("acierta" if r[1] / r[0] >= meta else "erra"), r
    r = tramo(serie(d["campania"], d["t"] - h, d["t"]), d["t"] - h, d["t"])
    if not r or r[0] < GASTO_MIN_P * P:
        return "sin_muestra", r
    return ("acierta" if r[1] / r[0] < meta else "erra"), r

def estado(tipo, n, pct, gasto, valor, meta):
    roas = valor / gasto if gasto else 0
    if tipo == "sube":
        if (n >= MIN_DEC and pct < ACIERTO_MIN and roas < ROAS_EQUILIBRIO) or (n >= 3 and gasto >= 20 * P and roas < 1):
            return "a_revisar"
        if n >= MIN_DEC and pct < ACIERTO_MIN:
            return "rentable"           # no llega a la meta pero deja plata: no se frena
    elif (n >= MIN_DEC and pct < ACIERTO_MIN) or (n >= 3 and gasto >= 20 * P and roas >= meta):
        return "a_revisar"              # corta lo que venía bien
    return "confiable" if n >= MIN_DEC else "poca_muestra"

def resumir():
    """Agrupa por (robot, regla, mercado, clase real|sombra), una decisión por ventana, y escribe resumen.json."""
    # 1. juzgar pendientes  2. deduplicar por (campania, regla, floor(t / ventana))
    # 3. contar aciertos, gasto y valor  4. estado()  5. escribir con fecha
    # 6. avisar SOLO si una regla cambió de estado
    raise NotImplementedError


# ---------- lo que consultan los robots ----------
def _resumen():
    try:
        r = json.load(open("resumen.json"))
        if time.time() - r["t"] > MAX_EDAD_RESUMEN_H * 3600:
            return None
        return {(f["robot"], f["regla"], f["mercado"], f["clase"]): f["estado"] for f in r["filas"]}
    except Exception:
        return None

def frenar(robot, regla, tipo, mercado, campania, roas_ultimas_horas=None):
    """True = NO ejecutar (queda como sombra). Nunca levanta excepciones."""
    try:
        if regla in NUNCA:
            return False
        est = _resumen()
        if not est or est.get((robot, regla, mercado, "real")) != "a_revisar":
            return False
        if est.get((robot, regla, mercado, "sombra")) in ("confiable", "rentable"):
            return False                # lo frenado habría acertado: rehabilitada
        if tipo == "corta" and (roas_ultimas_horas is None or roas_ultimas_horas < meta_del_mercado(mercado)):
            return False                # viene mal de verdad (o sin datos): se corta
        anotar_sombra(robot, regla, tipo, mercado, campania)
        return True
    except Exception as e:
        print("[aprendizaje] falla abierto:", e)
        return False

def anotar_sombra(*a):
    with open("sombras.jsonl", "a") as f:
        f.write(json.dumps(dict(t=time.time(), datos=a)) + "\n")
