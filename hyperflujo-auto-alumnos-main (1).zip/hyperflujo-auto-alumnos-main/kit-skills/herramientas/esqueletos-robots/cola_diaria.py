"""Cola de testeo: N conjuntos nuevos por mercado por día (esqueleto).

Todo creativo nuevo se carga en PAUSA y entra al final de la cola de su mercado. Este robot, una vez por día,
prende los siguientes N de cada mercado a presupuesto P. Se puede volver a correr: completa hasta N.

Uso: cola_diaria.py [--seco] [--solo MERCADO1,MERCADO2]
     cola_diaria.py estado
     cola_diaria.py pendientes <mercado>     # la fábrica no produce si hay STOCK_MAX o más
"""
import json, sys

N_POR_DIA = 5
P = None                  # TODO: tu presupuesto diario de testeo
GASTO_NUNCA_CORRIO_P = 0.2   # gastó menos de esta fracción de P = nunca corrió
STOCK_MAX = 10
MALOS = {"DISAPPROVED", "WITH_ISSUES", "DELETED", "ARCHIVED"}
SECO = "--seco" in sys.argv


# ---------- plataforma (TODO) ----------
def leer_conjunto(id_): ...            # status, gasto histórico, anuncios con su effective_status
def conjunto_vivo_mas_reciente(campania_testeo): ...   # de donde se copia la segmentación
def conjuntos_pausados_nuevos(campania_testeo, desde): ...
def escribir(id_, campos): ...
def avisar(texto): ...


def sumar_nuevos(cola, mercado, campania, desde):
    """Todo conjunto pausado, sin gasto, creado desde `desde` en la campaña de testeo entra al final."""
    ya = set(cola[mercado])
    for c in conjuntos_pausados_nuevos(campania, desde):
        if c["id"] not in ya and c["gasto"] < GASTO_NUNCA_CORRIO_P * P:
            cola[mercado].append(c["id"])

def prender_uno(id_, molde):
    c = leer_conjunto(id_)
    if c["status"] != "PAUSED" or c["gasto"] >= GASTO_NUNCA_CORRIO_P * P:
        return "salteado"                               # alguien ya lo prendió: no cuenta
    if c.get("auditoria") == "pendiente":
        return "espera_auditoria"                       # compuerta: no se prende sin auditoría de idioma
    sanos = [a for a in c["anuncios"] if a["effective_status"] not in MALOS]
    if not sanos:
        return "excluido"
    if SECO:
        return "seco"
    escribir(id_, {"targeting": molde["targeting"],    # geo, exclusiones y filtro de idioma del vivo más reciente
                   "daily_budget": P})
    for a in sanos:
        escribir(a["id"], {"status": "ACTIVE"})
    escribir(id_, {"status": "ACTIVE"})
    v = leer_conjunto(id_)                              # verificar releyendo
    return "prendido" if v["status"] == "ACTIVE" else "no_verifico"

def correr(cola, mercados):
    resumen = {}
    for m, campania in mercados.items():
        sumar_nuevos(cola, m, campania, desde=cola.get("_alta_desde"))
        molde = conjunto_vivo_mas_reciente(campania)
        hechos = cola.setdefault("_hoy", {}).get(m, 0)
        while hechos < N_POR_DIA and cola[m]:
            r = prender_uno(cola[m][0], molde)
            if r == "espera_auditoria":
                break                                   # respeta el orden: no saltea al que espera
            cola[m].pop(0)
            hechos += r == "prendido"
        cola["_hoy"][m] = hechos
        resumen[m] = (hechos, len(cola[m]))
    avisar("Cola de testeo: " + ", ".join(f"{m} {h} prendidos / {q} en cola" for m, (h, q) in resumen.items()))
    return resumen
