"""Escalera de topes de costo: «la canilla» (esqueleto).

Con puja de tope, el presupuesto no empuja el gasto: lo abre el tope. Este robot, cada media hora, busca el tope
donde la campaña gasta de verdad y trae ventas, y lo deja un escalón por encima de ese punto.

Fases por conjunto:  BUSCA  -> (la campaña gasta UMBRAL por media hora y hay ventas) ->  IMPRIME
Toda subida sobre una campaña que vende queda A PRUEBA: si sale cara con muestra mínima, vuelve al último tope probado.
El presupuesto lo maneja OTRO robot. Este no lo toca.
"""
import time

TICKET = None                 # TODO
ESCALON = 0.07                # un escalón = ~7 % del ticket
TOPE_ARRANQUE = 0.25          # arranque del día como fracción del ticket (bajo: el tope de arranque es el CPA que vas a pagar)
TECHO = 0.65                  # techo del tope (fracción del ticket), según el modo
UMBRAL_MEDIA_HORA = None      # TODO: cuánto tiene que gastar la campaña EN TOTAL por media hora para decir «se abrió»
LINEA_FRENO = 0.85            # CPA cobrado por encima de esto (fracción del ticket) = subida cara
MUESTRA_FRENO = None          # TODO: gasto mínimo desde la subida para juzgarla (~10 P)
HORAS_CASTIGO = 3
HORA_RESET, HORA_FIN, HORA_NO_BAJA_ANTES = 1, 17, 6   # por campaña, en el huso de su mercado


# ---------- plataforma y estado (TODO) ----------
def conjuntos(campania): ...           # id, tope actual, gasto última media hora
def gasto_campania_media_hora(campania): ...
def ventas_desde(campania, t): ...     # (gasto, ventas cobradas, valor) desde t: el MAYOR entre Meta y lo cobrado
def poner_tope(conjunto, valor): ...   # escribir + releer; si quedó pausado por la edición, reprender
def memoria(): ...                     # punto de apertura de ayer por conjunto
def estado(): ...                      # fase, último tope probado, subidas a prueba, castigos


def reset(campania, est, mem):
    """Antes del pico: topes bajos escalonados, o donde se abrió la canilla ayer."""
    for i, c in enumerate(conjuntos(campania)):
        base = mem.get(c["id"]) or (TOPE_ARRANQUE * TICKET + i * ESCALON * TICKET)
        poner_tope(c["id"], round(base))
        est[c["id"]] = {"fase": "busca", "probado": round(base)}

def vuelta(campania, est, mem, hora):
    paso = max(1, round(ESCALON * TICKET))
    gasta = gasto_campania_media_hora(campania)           # TOTAL: en una CBO Meta puede dárselo todo a uno
    for c in conjuntos(campania):
        e = est[c["id"]]
        # 1) freno de subidas a prueba
        if e.get("a_prueba"):
            g, n, v = ventas_desde(campania, e["a_prueba"])
            if g >= MUESTRA_FRENO and (n == 0 or g / n > LINEA_FRENO * TICKET):
                poner_tope(c["id"], e["probado"]); e["castigo_hasta"] = time.time() + HORAS_CASTIGO * 3600
                e.pop("a_prueba"); continue
            if n >= 2 and g / n <= LINEA_FRENO * TICKET:
                e["probado"] = c["tope"]; e.pop("a_prueba")
        castigado = time.time() < e.get("castigo_hasta", 0)
        # 2) fases
        if e["fase"] == "busca":
            if gasta >= UMBRAL_MEDIA_HORA and ventas_desde(campania, time.time() - 1800)[1] > 0:
                e["fase"] = "imprime"; mem[c["id"]] = c["tope"]
                poner_tope(c["id"], min(c["tope"] + paso, TECHO * TICKET))      # un escalón arriba del punto
            elif hora < HORA_FIN and not castigado and c["tope"] + paso <= TECHO * TICKET:
                poner_tope(c["id"], c["tope"] + paso); e["a_prueba"] = time.time()
        else:   # imprime: trabajo fino
            g, n, v = ventas_desde(campania, time.time() - 3 * 1800)
            caro = (n == 0 and g >= 3 * c["tope"]) or (n and g / n > 1.3 * c["tope"])
            if caro and hora >= HORA_NO_BAJA_ANTES:                              # de madrugada temprano, Meta atribuye tarde
                poner_tope(c["id"], max(round(TOPE_ARRANQUE * TICKET), c["tope"] - 1))
            elif c.get("frenado_2_vueltas") and not caro and hora < HORA_FIN and not castigado:
                poner_tope(c["id"], min(c["tope"] + 1, TECHO * TICKET)); e["a_prueba"] = time.time()
    # anotar cada decisión en la bitácora: el auditor la juzga
