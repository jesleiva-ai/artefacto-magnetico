"""Freno de mano de una escala (esqueleto).

Una escala que en el día ya gastó lo suficiente y cobró muy por debajo de lo gastado se frena en el día,
no al día siguiente. Una vez por día por escala. Lo llama el robot de presupuesto en la vuelta de cada hora.
"""
import datetime

GASTO_MIN = None         # TODO: gasto del día a partir del cual se juzga (~60 P)
ROAS_MIN = 0.8           # por debajo de esto, freno
FACTOR_PRESUPUESTO = 0.5
PISO_PRESUPUESTO = None  # TODO
MODOS_DONDE_NO_CORRE = {"ofensivo"}


# ---------- plataforma (TODO) ----------
def huso_de_la_cuenta(cuenta): ...           # horas respecto de UTC
def gasto_de_hoy(campania, desde_utc): ...   # con rango explícito, nunca «today» en código que queda corriendo
def cobrado_desde(desde_utc): ...            # {id_o_nombre_de_campania: valor}; la tienda a veces guarda el NOMBRE en el UTM
def presupuesto(campania): ...
def poner_presupuesto(campania, valor): ...
def avisar(texto): ...


def medianoche_de(cuenta):
    tz = datetime.timezone(datetime.timedelta(hours=huso_de_la_cuenta(cuenta)))
    hoy = datetime.datetime.now(tz).date()
    return datetime.datetime.combine(hoy, datetime.time(0), tz).astimezone(datetime.timezone.utc)

def correr(config, hoy):
    if config.get("modo") in MODOS_DONDE_NO_CORRE:
        return
    avisos = []
    cobros = {}
    for c in config["escalas"]:
        if c.get("freno_mano_dia") == hoy:
            continue                                        # una vez por día
        desde = medianoche_de(c["cuenta"])                  # gasto y cobrado en el MISMO huso
        if desde not in cobros:
            cobros[desde] = cobrado_desde(desde)
        g = gasto_de_hoy(c["id"], desde)
        v = cobros[desde].get(c["id"], 0) + cobros[desde].get(c["nombre"], 0)
        if g < GASTO_MIN or v / g >= ROAS_MIN:
            continue
        p = presupuesto(c["id"])
        nuevo = max(PISO_PRESUPUESTO, round(p * FACTOR_PRESUPUESTO))
        poner_presupuesto(c["id"], nuevo)
        c["tope"] = c["tope_base"] if c.get("pico_activo") else c["tope"] - c["escalon"]
        c["pico_activo"] = False
        c["freno_mano_dia"] = hoy
        avisos.append(f"{c['nombre']}: gastó {g:.0f}, cobró {v:.0f} (ROAS {v / g:.2f}) -> presupuesto {p:.0f}->{nuevo}")
    if avisos:
        # guardar config con escritura atómica bajo candado, anotar en la bitácora (el auditor lo juzga)
        avisar("Freno de mano:\n" + "\n".join(avisos))
