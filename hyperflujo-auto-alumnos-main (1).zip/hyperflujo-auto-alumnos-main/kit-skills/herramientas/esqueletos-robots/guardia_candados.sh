#!/bin/bash
# Guardia mecánico (esqueleto). Cron cada 15 min durante la franja crítica.
# 1) candado de un robot tomado hace más de MAX_LOCK_MIN -> matar al dueño y avisar
# 2) robot que no corrió en MAX_QUIETO_MIN -> correrlo (esperando su candado) y avisar
# 3) avisar UNA vez por problema y por noche
#
# Ojo: el cron no es tu terminal. PATH y huso explícitos.
set -u
export PATH="/ruta/a/tus/herramientas/compat:/usr/local/bin:/usr/bin:/bin"   # TODO
export TZ="Zona/DelEquipo"                                                   # TODO
MAX_LOCK_MIN=50
MAX_QUIETO_MIN=40
NOCHE=$(date -d '-12 hours' +%F 2>/dev/null || date -v-12H +%F)              # una «noche» va de 12 a 12
AVISADOS="/var/tmp/guardia-$NOCHE.txt"; touch "$AVISADOS"

avisar() {   # $1 = clave, $2 = texto
  grep -qx "$1" "$AVISADOS" && return
  echo "$1" >> "$AVISADOS"
  ./avisar.sh "$2"                                                           # TODO: Telegram o lo que uses
}

# robot | candado | archivo de estado que el robot toca en cada vuelta | comando
while IFS='|' read -r NOMBRE LOCK ESTADO CMD; do
  [ -z "$NOMBRE" ] && continue
  # 1) candado tomado de más
  if [ -e "$LOCK" ]; then
    PID=$(fuser "$LOCK" 2>/dev/null | awk '{print $1}')
    if [ -n "$PID" ]; then
      EDAD=$(( ( $(date +%s) - $(stat -c %Y /proc/$PID 2>/dev/null || date +%s) ) / 60 ))
      if [ "$EDAD" -gt "$MAX_LOCK_MIN" ]; then
        # Por defecto solo avisa. Matar procesos se habilita a propósito con MATAR=1,
        # después de haberlo probado en seco con tus propios robots.
        if [ "${MATAR:-0}" = "1" ]; then
          kill "$PID" && avisar "lock-$NOMBRE" "🔓 $NOMBRE: candado tomado $EDAD min por $PID; lo maté"
        else
          avisar "lock-$NOMBRE" "🔒 $NOMBRE: candado tomado $EDAD min por $PID (no lo toqué; MATAR=1 para que lo mate)"
        fi
      fi
    fi
  fi
  # 2) robot quieto
  if [ -e "$ESTADO" ]; then
    QUIETO=$(( ( $(date +%s) - $(stat -c %Y "$ESTADO" 2>/dev/null || stat -f %m "$ESTADO") ) / 60 ))
    if [ "$QUIETO" -gt "$MAX_QUIETO_MIN" ]; then
      ( flock -w 600 "$LOCK" $CMD >> "logs/$NOMBRE.log" 2>&1 & )             # nunca envolver con el candado un script que adentro pide el mismo
      avisar "quieto-$NOMBRE" "⏰ $NOMBRE no corría hace $QUIETO min; lo relancé"
    fi
  fi
done <<'EOF'
escala-presupuesto|/var/lock/escala.lock|logs/escala/estado-hoy.json|python3 escala_presupuesto.py
escala-topes|/var/lock/escala.lock|logs/topes/estado-hoy.json|python3 escalera_topes.py
EOF

# 3) extra: escala en su pico con presupuesto debajo de su piso de pico, cuenta con pago frenado -> avisar (no tocar)
