"""La única palanca de un agente de IA sin supervisión (esqueleto).

El agente (por ejemplo, un guardia nocturno) NO llama a la plataforma. Solo puede correr este script, que cambia
UN valor de UNA campaña en la configuración compartida. Los límites viven ACÁ, en el código, no en el prompt:
un prompt se puede malinterpretar; un `sys.exit` no.

Uso: palanca_acotada.py "<campaña exacta>" <nuevo_valor> "<motivo con números>"
     palanca_acotada.py --ver
"""
import json, os, sys, time, fcntl

CONFIG = "config-escala.json"
CANDADO = "config-escala.lock"
BITACORA = "palancas.jsonl"
TICKET = None                # TODO: tu ticket promedio por comprador
ESCALON = 0.07               # un escalón de tope = ~7 % del ticket
PISO_FRAC = 0.33             # nunca por debajo de ~1/3 del ticket
TECHO_FRAC = {"ganancia": 0.65, "ofensivo": 0.72}   # techo del tope como fracción del ticket, según el modo
ESPERA_S = 3600              # una vez por hora por campaña


def techo(conf):
    return round(TICKET * TECHO_FRAC.get(conf.get("modo"), min(TECHO_FRAC.values())))

def main():
    conf = json.load(open(CONFIG))
    if sys.argv[1:2] == ["--ver"]:
        for c in conf["campanas"]:
            print(f'{c["nombre"]:40} tope {c.get("tope")}')
        return
    nombre, nuevo, motivo = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    hist = [json.loads(l) for l in open(BITACORA)] if os.path.exists(BITACORA) else []

    with open(CANDADO, "a") as lk:
        for _ in range(90):                       # espera hasta 15 min el candado, después se rinde
            try:
                fcntl.flock(lk, fcntl.LOCK_EX | fcntl.LOCK_NB); break
            except BlockingIOError:
                time.sleep(10)
        else:
            sys.exit("[error] candado ocupado; probá en la próxima vuelta")

        conf = json.load(open(CONFIG))            # releer DENTRO del candado
        c = next((x for x in conf["campanas"] if x["nombre"] == nombre), None)
        if not c:
            sys.exit(f"[error] no existe {nombre!r} (mirá --ver)")
        viejo = int(c.get("tope") or 0)
        paso, piso = max(1, round(TICKET * ESCALON)), round(TICKET * PISO_FRAC)
        if abs(nuevo - viejo) > paso:
            sys.exit(f"[error] {viejo}->{nuevo}: máximo ±{paso} (un escalón)")
        if not piso <= nuevo <= techo(conf):
            sys.exit(f"[error] {nuevo} fuera de [{piso}, {techo(conf)}]")
        if any(h["nombre"] == nombre and time.time() - h["t"] < ESPERA_S for h in hist):
            sys.exit("[error] ya se tocó hace menos de 1 h")

        c["tope"] = nuevo
        c["ultima_palanca"] = {"t": time.time(), "de": viejo, "a": nuevo, "motivo": motivo}
        json.dump(conf, open(CONFIG + ".tmp", "w"), indent=1, ensure_ascii=False)
        os.replace(CONFIG + ".tmp", CONFIG)       # escritura atómica

    with open(BITACORA, "a") as f:                # el auditor la juzga después
        f.write(json.dumps({"t": time.time(), "nombre": nombre, "de": viejo, "a": nuevo, "motivo": motivo}, ensure_ascii=False) + "\n")
    print(f"[ok] {nombre}: {viejo} -> {nuevo} ({motivo})")
    # El robot de topes lleva el valor nuevo a la plataforma en su próxima vuelta: la palanca no habla con Meta.


if __name__ == "__main__":
    main()
