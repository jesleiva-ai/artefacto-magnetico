#!/usr/bin/env python3
"""forense.py — desarme profundo de UNA landing, con el celular como unidad de medida.

QUE RESUELVE
  anatomia.py hace el barrido comparativo (que stack, que paleta, que aspectos).
  Esto es la otra mitad: el desarme de una sola pagina hasta el pixel, contra el
  pliegue REAL de un telefono. En low ticket casi todas las conversiones entran
  por celular, asi que la unidad de medida es el primer pantallazo, no el scroll.

LA CALIBRACION, QUE ES LO QUE CASI TODOS HACEN MAL
  El emulador entrega el viewport CSS completo. El telefono real descuenta la
  barra del navegador, y dentro del navegador embebido de Instagram o Facebook
  descuenta todavia mas. Medir contra el numero del emulador corre todo.

      iPhone 14 Pro Max · Safari   430 x 932 CSS  ->  745 visibles  (-187)
      Samsung S24 Ultra · Chrome   384 x 854 CSS  ->  681 visibles  (-173)

  Se disena contra 681. El peor caso manda. Este script mide contra los dos y
  avisa que elementos del hero cruzan el pliegue.
  (Umbrales tomados del desarme de Kinesiology Solved, 2026-07-28.)

QUE DEVUELVE QUE NO DA anatomia.py
  - Presupuesto del primer pantallazo: cada elemento del hero con desde/hasta/alto
    y si cruza el pliegue en cada dispositivo.
  - Mapa de secciones con inicio, alto y % de pagina.
  - Escala tipografica completa + los roles clave con interlineado como PROPORCION
    y tracking en px y em.
  - Gradientes descompuestos y sombras (avisa si son negras o tenidas de marca).
  - Densidad de imagen: ancho servido vs ancho mostrado; marca el desperdicio.
  - Animaciones: keyframes propios y si existe prefers-reduced-motion.
  - Peso: nodos del DOM y KB de HTML.

USO
  forense.py <url>                 # informe legible
  forense.py <url> --json
  forense.py <url> --ancho 384     # medir en el peor caso (default 430)

Solo lectura.
"""

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ojos

# alto CSS y alto realmente visible, por dispositivo
DISPOSITIVOS = {
    430: ("iPhone 14 Pro Max · Safari", 932, 745),
    384: ("Samsung S24 Ultra · Chrome", 854, 681),
}

SONDA = r"""
(() => {
  const O = {};
  const cs = (el) => getComputedStyle(el);
  const hex = (s) => { const m = String(s).match(/\d+/g); return m
    ? "#" + m.slice(0,3).map(n => (+n).toString(16).padStart(2,"0")).join("") : String(s) };
  const y = (el) => Math.round(el.getBoundingClientRect().top + scrollY);
  const h = (el) => Math.round(el.getBoundingClientRect().height);

  O.alto_total = document.body.scrollHeight;
  O.nodos_dom  = document.getElementsByTagName("*").length;
  O.html_kb    = Math.round(document.documentElement.outerHTML.length / 1024);
  O.titulo     = document.title;
  O.url        = location.href;

  // ── 1 · presupuesto del primer pantallazo ────────────────────────────────
  // todo lo que pinta algo en los primeros 1000px, en orden vertical
  const vistos = new Set();
  O.hero = [];
  document.querySelectorAll("h1,h2,h3,p,img,button,a,span,div,section,ul,li").forEach(el => {
    const r = el.getBoundingClientRect();
    const top = r.top + scrollY;
    if (top > 1000 || r.height < 12 || r.width < 24) return;
    const txt = (el.innerText || "").trim().replace(/\s+/g," ").slice(0,54);
    const esImg = el.tagName === "IMG";
    if (!txt && !esImg) return;
    // quedarse con el nodo mas profundo que tenga ese texto (evita los wrappers)
    if (txt && el.querySelector("h1,h2,h3,p,button,img")) return;
    const k = txt + "|" + Math.round(top);
    if (vistos.has(k)) return; vistos.add(k);
    const c = cs(el);
    O.hero.push({
      tag: el.tagName.toLowerCase(),
      clase: (el.className && typeof el.className === "string" ? el.className : "").slice(0,28),
      desde: Math.round(top), hasta: Math.round(top + r.height), alto: Math.round(r.height),
      texto: esImg ? ("IMG " + (el.naturalWidth||"?") + "x" + (el.naturalHeight||"?")) : txt,
      es_cta: /button/i.test(el.tagName) || /btn|cta|comprar|quiero|buy|want/i.test(
                (el.className||"") + " " + txt),
      tam: Math.round(parseFloat(c.fontSize)) || null,
    });
  });
  O.hero.sort((a,b) => a.desde - b.desde);

  // ── 2 · mapa de secciones ────────────────────────────────────────────────
  let secs = [...document.querySelectorAll("section")];
  if (secs.length < 4) secs = [...document.querySelectorAll("main > div, body > div > div")];
  O.secciones = secs.map(el => {
    const alto = h(el);
    if (alto < 140) return null;
    return { clase: (typeof el.className === "string" ? el.className : "").slice(0,34) || el.tagName.toLowerCase(),
      desde: y(el), alto,
      pct: +(alto / document.body.scrollHeight * 100).toFixed(1),
      fondo: hex(cs(el).backgroundColor),
      texto: (el.innerText || "").trim().replace(/\s+/g," ").slice(0,60) };
  }).filter(Boolean);

  // ── 3 · tipografia: escala completa + roles clave con proporciones ────────
  const tams = new Set(); const fams = {};
  document.querySelectorAll("*").forEach(el => {
    if (!el.innerText || !el.innerText.trim() || el.children.length) return;
    const c = cs(el), r = el.getBoundingClientRect();
    if (r.height < 6) return;
    tams.add(Math.round(parseFloat(c.fontSize) * 10) / 10);
    const f = c.fontFamily.split(",")[0].replace(/["']/g,"").trim();
    fams[f] = (fams[f] || 0) + 1;
  });
  O.escala = [...tams].sort((a,b) => a - b);
  O.familias = Object.entries(fams).sort((a,b) => b[1]-a[1]).slice(0,5)
    .map(([n,v]) => ({familia:n, usos:v}));

  const rol = (sel, nombre) => {
    const el = document.querySelector(sel); if (!el) return null;
    const c = cs(el); const fs = parseFloat(c.fontSize);
    const lh = c.lineHeight === "normal" ? fs*1.2 : parseFloat(c.lineHeight);
    const ls = c.letterSpacing === "normal" ? 0 : parseFloat(c.letterSpacing);
    return { rol: nombre, tam: +fs.toFixed(1), peso: c.fontWeight,
      interlineado: +lh.toFixed(1), proporcion: +(lh/fs).toFixed(2),
      tracking_px: +ls.toFixed(2), tracking_em: +(ls/fs).toFixed(3),
      color: hex(c.color), familia: c.fontFamily.split(",")[0].replace(/["']/g,"") };
  };
  O.roles = [rol("h1","H1"), rol("h1 + p, h1 ~ p","Subtitulo del hero"),
             rol("button, .btn, [class*=btn]","Texto del boton"),
             rol("h2","H2"), rol("p","Cuerpo")].filter(Boolean);

  // ── 4 · gradientes y sombras ─────────────────────────────────────────────
  const grads = new Map(), shadows = new Map();
  document.querySelectorAll("*").forEach(el => {
    const c = cs(el), r = el.getBoundingClientRect();
    if (r.width * r.height < 900) return;
    if (/gradient/i.test(c.backgroundImage)) {
      const g = c.backgroundImage.replace(/\s+/g," ");
      grads.set(g, (grads.get(g)||0) + 1);
    }
    if (c.boxShadow && c.boxShadow !== "none") {
      const s = c.boxShadow.replace(/\s+/g," ");
      shadows.set(s, (shadows.get(s)||0) + 1);
    }
  });
  const ordenar = (m,n) => [...m.entries()].sort((a,b)=>b[1]-a[1]).slice(0,n)
    .map(([v,c]) => ({valor: v.slice(0,190), usos: c}));
  O.gradientes = ordenar(grads, 6);
  O.sombras = ordenar(shadows, 6).map(s => ({...s,
    negra: /rgba?\(0, ?0, ?0/.test(s.valor)}));

  // ── 5 · radios ───────────────────────────────────────────────────────────
  const radios = new Set();
  document.querySelectorAll("*").forEach(el => {
    const r = cs(el).borderRadius;
    if (r && r !== "0px") r.split(" ").forEach(v => { const n = parseFloat(v);
      if (!isNaN(n) && n > 0) radios.add(n > 500 ? 999 : Math.round(n)) });
  });
  O.radios = [...radios].sort((a,b)=>a-b);

  // ── 6 · densidad de imagen: servido vs mostrado ──────────────────────────
  const vis = new Set();
  O.imagenes = [...document.querySelectorAll("img")].map(im => {
    const r = im.getBoundingClientRect();
    const src = im.currentSrc || im.src || "";
    if (!src || vis.has(src) || r.width < 8) return null; vis.add(src);
    const mostrado = Math.round(r.width);
    const dens = mostrado ? +(im.naturalWidth / mostrado).toFixed(1) : null;
    const pedido = (src.match(/[?&](?:sz=)?w(\d{3,4})/i) || src.match(/[?&]width=(\d{3,4})/i) || [])[1];
    return { archivo: decodeURIComponent(src.split("/").pop().split("?")[0]).slice(0,44),
      host: (src.split("/")[2]||"").slice(0,34),
      pedido: pedido ? "w"+pedido : "",
      natural: im.naturalWidth + "x" + im.naturalHeight,
      aspecto: im.naturalHeight ? +(im.naturalWidth/im.naturalHeight).toFixed(3) : null,
      mostrado: mostrado + "x" + Math.round(r.height),
      densidad: dens,
      veredicto: dens === null ? "" : dens > 4 ? "DESPERDICIO" : dens < 2 ? "POBRE" : "ok",
      fit: cs(im).objectFit, radio: cs(im).borderRadius };
  }).filter(Boolean);

  // ── 7 · animaciones ──────────────────────────────────────────────────────
  O.animaciones = [];
  const nombres = new Set();
  document.querySelectorAll("*").forEach(el => {
    const c = cs(el);
    if (c.animationName && c.animationName !== "none") {
      c.animationName.split(",").forEach(n => {
        n = n.trim(); if (nombres.has(n)) return; nombres.add(n);
        O.animaciones.push({ nombre: n, duracion: c.animationDuration,
          timing: c.animationTimingFunction, iteracion: c.animationIterationCount,
          sobre: (typeof el.className === "string" ? el.className : el.tagName).slice(0,30) });
      });
    }
  });
  // los keyframes propios, del CSS accesible
  O.keyframes = [];
  try {
    for (const hoja of document.styleSheets) {
      let reglas; try { reglas = hoja.cssRules } catch(e) { continue }
      if (!reglas) continue;
      for (const r of reglas) if (r.type === 7) O.keyframes.push(r.cssText.replace(/\s+/g," ").slice(0,300));
    }
  } catch(e) {}
  O.keyframes = O.keyframes.slice(0, 6);
  O.reduced_motion = /prefers-reduced-motion/.test(
    [...document.querySelectorAll("style")].map(s=>s.textContent).join(" "));

  // ── 8 · botones ──────────────────────────────────────────────────────────
  O.botones = [...document.querySelectorAll("a,button")].map(b => {
    const t = (b.innerText||"").trim().replace(/\s+/g," "); if (!t || t.length > 60) return null;
    const r = b.getBoundingClientRect(); if (r.height < 26 || r.width < 70) return null;
    const c = cs(b);
    const grad = /gradient/i.test(c.backgroundImage);
    if (!grad && /rgba\(0, 0, 0, 0\)|transparent/.test(c.backgroundColor) && b.tagName !== "BUTTON") return null;
    const top = r.top + scrollY;
    return { texto: t, desde: Math.round(top), alto: Math.round(r.height),
      pct: +(top / document.body.scrollHeight * 100).toFixed(1),
      fondo: grad ? c.backgroundImage.replace(/\s+/g," ").slice(0,90) : hex(c.backgroundColor),
      radio: c.borderRadius, tam: Math.round(parseFloat(c.fontSize)),
      peso: c.fontWeight };
  }).filter(Boolean).slice(0, 14);

  return O;
})()
"""


def sondear(url, ancho, espera):
    if not ojos.vivo():
        sys.exit("Chrome de trabajo apagado. Arrancalo con: ojos.py abrir")
    nombre, alto_css, visible = DISPOSITIVOS.get(ancho, ("personalizado", 900, 900))
    cdp = ojos.CDP(ojos.http_json("/json/version")["webSocketDebuggerUrl"])
    tid = None
    try:
        tid = cdp.cmd("Target.createTarget", {"url": url})["targetId"]
        ses = cdp.cmd("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]
        cdp.cmd("Page.enable", sesion=ses)
        cdp.cmd("Runtime.enable", sesion=ses)
        cdp.cmd("Emulation.setDeviceMetricsOverride",
                {"width": ancho, "height": alto_css, "deviceScaleFactor": 3, "mobile": True},
                sesion=ses)
        time.sleep(espera)
        cdp.cmd("Runtime.evaluate",
                {"expression": "window.scrollTo(0,document.body.scrollHeight)"}, sesion=ses)
        time.sleep(3)
        cdp.cmd("Runtime.evaluate", {"expression": "window.scrollTo(0,0)"}, sesion=ses)
        time.sleep(1.5)
        r = cdp.cmd("Runtime.evaluate",
                    {"expression": SONDA, "returnByValue": True}, sesion=ses, espera=90)
        if "exceptionDetails" in r:
            sys.exit("La sonda fallo: " + json.dumps(r["exceptionDetails"])[:500])
        d = r["result"]["value"]
        d["_disp"] = {"ancho": ancho, "nombre": nombre, "alto_css": alto_css, "visible": visible}
        return d
    finally:
        if tid:
            try: cdp.cmd("Target.closeTarget", {"targetId": tid})
            except Exception: pass
        cdp.cerrar()


def informe(d):
    P = print
    dd = d["_disp"]
    P(f"\n╔═ {d['titulo'][:72]}")
    P(f"╚═ {d['url'][:92]}\n")

    P("── CALIBRACION " + "─" * 50)
    P(f"  Medido en {dd['nombre']} · {dd['ancho']}x{dd['alto_css']} CSS")
    P(f"  PLIEGUE REAL: {dd['visible']} px  (la barra del navegador come "
      f"{dd['alto_css']-dd['visible']} px)")
    P(f"  En el navegador embebido de Instagram/Facebook come todavia mas.")
    otro = 384 if dd['ancho'] == 430 else 430
    P(f"  Peor caso del set: {DISPOSITIVOS[otro][2]} px ({DISPOSITIVOS[otro][0]}).")

    P(f"\n── PRESUPUESTO DEL PRIMER PANTALLAZO " + "─" * 28)
    P(f"  {'desde':>6} {'hasta':>6} {'alto':>5}  elemento")
    pliegue = dd["visible"]
    cruzado = False
    for e in d["hero"]:
        if not cruzado and e["desde"] >= pliegue:
            P(f"  {'':>6} {'':>6} {'':>5}  ── PLIEGUE {pliegue}px " + "─" * 26)
            cruzado = True
        marca = ""
        if e["desde"] < pliegue < e["hasta"]:
            vis = pliegue - e["desde"]
            marca = f"   ⚠ SE CORTA: se ven {vis} de {e['alto']} px"
        if e["es_cta"]:
            marca += "   ← CTA"
        P(f"  {e['desde']:>6} {e['hasta']:>6} {e['alto']:>5}  {e['texto'][:44]}{marca}")
    if not cruzado:
        P(f"  {'':>6} {'':>6} {'':>5}  ── PLIEGUE {pliegue}px (todo el hero entra) ──")

    P(f"\n── MAPA DE SECCIONES · {d['alto_total']:,} px · {len(d['secciones'])} secciones "
      .replace(",", ".") + "─" * 12)
    P(f"  {'#':>3} {'desde':>7} {'alto':>6} {'%':>5}  clase / contenido")
    for i, s in enumerate(d["secciones"], 1):
        P(f"  {i:>3} {s['desde']:>7} {s['alto']:>6} {s['pct']:>4}%  "
          f"{s['clase'][:20]:<20} {s['texto'][:34]}")

    P(f"\n── TIPOGRAFIA " + "─" * 51)
    P("  familias: " + ", ".join(f"{f['familia']} ({f['usos']})" for f in d["familias"]))
    P(f"  escala hallada: {' · '.join(str(x) for x in d['escala'])}")
    P(f"\n  {'rol':<22} {'tam':>5} {'peso':>5} {'inter':>6} {'prop':>5} {'track':>7}  color")
    for r in d["roles"]:
        P(f"  {r['rol'][:22]:<22} {r['tam']:>5} {r['peso']:>5} {r['interlineado']:>6} "
          f"{r['proporcion']:>5} {r['tracking_px']:>6}px  {r['color']}")
    h1 = next((r for r in d["roles"] if r["rol"] == "H1"), None)
    if h1 and h1["proporcion"] < 1.05:
        P(f"  → El H1 tiene interlineado MENOR que el tamano ({h1['proporcion']}): "
          "las lineas casi se tocan. Es lo que produce el bloque compacto que golpea.")

    P(f"\n── FONDO Y SOMBRAS " + "─" * 46)
    for g in d["gradientes"]:
        P(f"  gradiente ×{g['usos']}: {g['valor'][:96]}")
    for s in d["sombras"]:
        P(f"  sombra ×{s['usos']} {'[NEGRA]' if s['negra'] else '[tenida]'}: {s['valor'][:80]}")
    if d["sombras"] and not any(s["negra"] for s in d["sombras"]):
        P("  → Ninguna sombra usa negro puro: todas llevan el color de marca con opacidad baja.")
    P(f"  radios: {' · '.join(str(x) for x in d['radios'])}")

    P(f"\n── IMAGENES · densidad servida vs mostrada " + "─" * 22)
    P(f"  {'archivo':<34} {'ped':>5} {'natural':<11} {'muestra':<11} {'dens':>5}  veredicto")
    for i in d["imagenes"][:24]:
        P(f"  {i['archivo'][:34]:<34} {i['pedido']:>5} {i['natural']:<11} "
          f"{i['mostrado']:<11} {str(i['densidad'] or ''):>5}  {i['veredicto']}")
    desp = [i for i in d["imagenes"] if i["veredicto"] == "DESPERDICIO"]
    if desp:
        P(f"  → {len(desp)} de {len(d['imagenes'])} sobre 4x de densidad. "
          "Arriba de 3x el ojo no distingue y en datos moviles se siente.")

    P(f"\n── MOVIMIENTO " + "─" * 51)
    if d["animaciones"]:
        for a in d["animaciones"]:
            P(f"  {a['nombre']} · {a['duracion']} · {a['timing']} · x{a['iteracion']} "
              f"· sobre .{a['sobre']}")
    else:
        P("  sin animaciones propias")
    for k in d["keyframes"]:
        P(f"  {k[:150]}")
    P(f"  prefers-reduced-motion: {'SI' if d['reduced_motion'] else 'NO — no lo contemplan'}")

    P(f"\n── BOTONES " + "─" * 54)
    for b in d["botones"]:
        P(f"  {b['pct']:>5}%  {b['desde']:>6}px  alto {b['alto']:>3}  "
          f"r{b['radio'][:5]:<6} {b['tam']}/{b['peso']}  {b['texto'][:40]}")

    P(f"\n── PESO " + "─" * 57)
    P(f"  {d['nodos_dom']:,} nodos de DOM · {d['html_kb']} KB de HTML".replace(",", "."))
    P("")


def main():
    ap = argparse.ArgumentParser(description="Desarme forense de una landing (solo lectura).")
    ap.add_argument("url")
    ap.add_argument("--ancho", type=int, default=430, choices=[430, 384],
                    help="430 = iPhone 14 Pro Max (default) · 384 = Samsung S24 Ultra (peor caso)")
    ap.add_argument("--espera", type=float, default=8)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    d = sondear(a.url if a.url.startswith("http") else "https://" + a.url, a.ancho, a.espera)
    print(json.dumps(d, indent=2, ensure_ascii=False)) if a.json else informe(d)


if __name__ == "__main__":
    main()
