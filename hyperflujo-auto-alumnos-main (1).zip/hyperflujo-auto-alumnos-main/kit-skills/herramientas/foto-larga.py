#!/usr/bin/env python3
"""foto-larga.py — UNA sola foto de toda la pagina, sin scrollear.

CUANDO USAR ESTA Y NO `ojos.py foto`
  `ojos.py foto` corta en tiras scrolleando, y para una landing de 12.000 px eso
  es lo correcto: cada tira se lee al alto real del dispositivo. Pero si la
  pagina maneja su propio scroll -un checkout con columna sticky, un panel con
  el contenido dentro de un contenedor- el `window.scrollTo` no la mueve y salen
  dos tiras IDENTICAS. Pasa, por ejemplo, con algunos checkouts: dos
  capturas iguales que parecian una pagina de dos pantallas, y casi se reporta
  asi.

  Aca no se scrollea: se agranda el viewport hasta el alto del documento y se
  dispara una sola vez con `captureBeyondViewport`. Sirve hasta unos 6.000 px de
  alto; mas que eso, volver a las tiras.

COMO SE USA
  foto-larga.py <url> <salida.png> [ancho]      # ancho por defecto 390 (celular)
"""

import base64, importlib.util, os, sys, time
_s = importlib.util.spec_from_file_location("ojos", os.path.expanduser("~/herramientas/ojos.py"))
ojos = importlib.util.module_from_spec(_s); _s.loader.exec_module(ojos)

url, salida = sys.argv[1], sys.argv[2]
ancho = int(sys.argv[3]) if len(sys.argv) > 3 else 390
cdp = ojos.CDP(ojos.http_json("/json/version")["webSocketDebuggerUrl"])
cdp.ws.s.settimeout(180)
t = cdp.cmd("Target.createTarget", {"url": "about:blank"})["targetId"]
try:
    ses = cdp.cmd("Target.attachToTarget", {"targetId": t, "flatten": True})["sessionId"]
    cdp.cmd("Page.enable", sesion=ses); cdp.cmd("Runtime.enable", sesion=ses)
    cdp.cmd("Emulation.setDeviceMetricsOverride",
            {"width": ancho, "height": 900, "deviceScaleFactor": 2, "mobile": True}, sesion=ses)
    cdp.cmd("Page.navigate", {"url": url}, sesion=ses)
    time.sleep(15)
    alto = int(cdp.cmd("Page.getLayoutMetrics", sesion=ses)["contentSize"]["height"])
    cdp.cmd("Emulation.setDeviceMetricsOverride",
            {"width": ancho, "height": min(alto + 40, 6000), "deviceScaleFactor": 2, "mobile": True}, sesion=ses)
    time.sleep(3)
    png = cdp.cmd("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": True},
                  sesion=ses, espera=90)["data"]
    open(salida, "wb").write(base64.b64decode(png))
    print(f"{alto}px -> {salida}")
finally:
    cdp.cmd("Target.closeTarget", {"targetId": t}); cdp.cerrar()
